#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

/* Compatibility with this runtime: /proc/self/exe is readable, whereas
   numeric /proc/PID/exe paths are unavailable even for the current process.
   Redirect only the current process's executable path. All other reads
   retain their original behavior. No Lean proof-checking code is changed. */
ssize_t readlink(const char *path, char *buffer, size_t size) {
    static ssize_t (*original)(const char *, char *, size_t) = NULL;
    if (!original) original = dlsym(RTLD_NEXT, "readlink");
    char own_path[64];
    snprintf(own_path, sizeof own_path, "/proc/%ld/exe", (long)getpid());
    if (strcmp(path, own_path) == 0) path = "/proc/self/exe";
    return original(path, buffer, size);
}
