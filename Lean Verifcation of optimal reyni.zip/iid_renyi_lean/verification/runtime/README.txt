The execution environment allowed /proc/self/exe but denied readlink of
/proc/<current process id>/exe, which Lean uses to locate its installation.
The included small compatibility shim changes only that current-process
readlink request to /proc/self/exe. It does not alter Lean terms, tactics,
the kernel, or proof results, and it does not read another process.

It was compiled as a shared library and set in LD_PRELOAD for the local
Lean and Lake processes. Normal Lean installations do not need this shim.
The library binary and toolchain are omitted from this source archive.
