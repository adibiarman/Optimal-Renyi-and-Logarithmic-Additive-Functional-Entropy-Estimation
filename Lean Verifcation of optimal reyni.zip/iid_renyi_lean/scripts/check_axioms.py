"""Validate the Lean-generated environment audit and preserve its inventory.

Lean itself checks dependencies. Python checks report completeness/shape and
records source files that were not imported and therefore were not audited.
The capstone is type-checked by Lean; Python validates the audit inventory.
"""
from pathlib import Path
import json
import re

root = Path(__file__).resolve().parents[1]
log = (root / "verification/axioms.log").read_text()
reports = re.findall(r"AXIOM_AUDIT_JSON (\{[^\n]*\})", log)
if len(reports) != 1:
    raise SystemExit("Expected exactly one Lean-generated axiom report")
report = json.loads(reports[0])
if report.get("status") != "PASS":
    raise SystemExit("The Lean axiom audit did not pass")
names = report["theorems"]
if not names or len(names) != report["checked_theorem_count"] or len(set(names)) != len(names):
    raise SystemExit("Invalid theorem inventory in Lean audit")
if report.get("full_minimax_theorem_proved") is not True:
    raise SystemExit("The full iid minimax theorem was not verified")
if report.get("capstone_theorem") != "Renyi.iid_renyi_full_verified" or report["capstone_theorem"] not in names:
    raise SystemExit("The full iid minimax capstone is absent from the audited theorem inventory")
allowed = {"propext", "Classical.choice", "Quot.sound"}
if set(report["transitive_axioms"]) - allowed:
    raise SystemExit("Unapproved axiom dependencies in Lean audit")
if "sorryAx" in log or re.search(r"\berror:", log):
    raise SystemExit("The Lean axiom audit contains an error or sorryAx")
source_modules = {"Renyi." + path.stem for path in (root / "Renyi").glob("*.lean")}
report["source_modules_not_imported"] = sorted(source_modules - set(report["imported_project_modules"]))
(root / "verification/theorem-inventory.json").write_text(json.dumps(report, indent=2) + "\n")
print(f"PASS: {len(names)} imported project theorem declarations; only standard axioms.")
if report["source_modules_not_imported"]:
    print("Not checked by this aggregate build: " + ", ".join(report["source_modules_not_imported"]))
print("PASS: FullManuscriptClaim is proved by Renyi.iid_renyi_full_verified.")
