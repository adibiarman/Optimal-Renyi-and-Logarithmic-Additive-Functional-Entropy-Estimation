#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
mkdir -p verification
python3 scripts/generate_audit.py
lake build 2>&1 | tee verification/build.log
lake env lean -DwarningAsError=true Audit.lean 2>&1 | tee verification/axioms.log
python3 scripts/check_axioms.py | tee verification/audit-summary.log
lake env lean -DwarningAsError=true KernelAudit.lean 2>&1 | tee verification/kernel-audit.log
