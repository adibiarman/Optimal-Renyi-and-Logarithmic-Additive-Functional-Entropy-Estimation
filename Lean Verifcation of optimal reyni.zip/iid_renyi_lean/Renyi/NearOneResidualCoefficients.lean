import Renyi.NearOneActualAffine

/-! The full residual coefficient array used by the actual near-one count statistic. -/
noncomputable section
open Polynomial
namespace Renyi

lemma affine_residual_coefficient_budget (P : ℝ[X]) {β t b L K0 K1 : ℝ}
    (hβ : 0<β) (ht : 0<t) (htb : t≤b) (hL : 0≤L) (hK0 : 0≤K0) (hK1 : 0≤K1)
    (hzero : |P.coeff 0|≤K0*β*t^(1+β))
    (hone : |P.coeff 1-t^β|≤K0*β*t^β)
    (hhigh : ∀j:ℕ,2≤j→|P.coeff j| * b^j≤K1*β*b^(1+β)*Real.exp (K1*L)) (j : ℕ) :
    |(P-C (t^β)*X).coeff j| * b^j≤
      (K0+K1+1)*β*b^(1+β)*Real.exp ((K0+K1+1)*L) := by
  have hb : 0<b := ht.trans_le htb
  have hK : 0≤K0+K1+1 := by positivity
  have hK0' : K0≤K0+K1+1 := by linarith only [hK1]
  have hK1' : K1≤K0+K1+1 := by linarith only [hK0]
  have he1 : 1≤Real.exp ((K0+K1+1)*L) := Real.one_le_exp_iff.mpr (mul_nonneg hK hL)
  have he2 : Real.exp (K1*L)≤Real.exp ((K0+K1+1)*L) :=
    Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_right hK1' hL)
  have hbase : K0*β*b^(1+β)≤(K0+K1+1)*β*b^(1+β)*Real.exp ((K0+K1+1)*L) := by
    have hh := mul_le_mul_of_nonneg_right hK0' (show 0≤β*b^(1+β) by positivity)
    have hh2 := mul_le_mul_of_nonneg_left he1 (show 0≤(K0+K1+1)*β*b^(1+β) by positivity)
    nlinarith only [hh,hh2]
  rcases j with _ | j
  · simp only [coeff_sub,mul_coeff_zero,coeff_X_zero,mul_zero,sub_zero,pow_zero,mul_one]
    apply hzero.trans
    apply le_trans _ hbase
    have hp := Real.rpow_le_rpow ht.le htb (by linarith only [hβ] : 0≤1+β)
    exact mul_le_mul_of_nonneg_left hp (mul_nonneg hK0 hβ.le)
  rcases j with _ | j
  · simp only [Nat.reduceAdd,coeff_sub,coeff_C_mul,coeff_X_one,mul_one,pow_one]
    have hmul := mul_le_mul_of_nonneg_right hone hb.le
    have hp := mul_le_mul_of_nonneg_right (Real.rpow_le_rpow ht.le htb hβ.le) hb.le
    have hid : b^β*b=b^(1+β) := by rw [←Real.rpow_add_one hb.ne'];congr 1;ring
    rw [hid] at hp
    have hm := mul_le_mul_of_nonneg_left hp (mul_nonneg hK0 hβ.le)
    apply hmul.trans
    apply le_trans _ hbase
    nlinarith only [hm]
  · have hj : 2≤j+1+1 := by omega
    simp only [coeff_sub,coeff_C_mul,coeff_X,if_neg (by omega : ¬1=j+1+1),mul_zero,sub_zero]
    apply (hhigh (j+1+1) hj).trans
    have hh := mul_le_mul_of_nonneg_right hK1' (show 0≤β*b^(1+β) by positivity)
    have hm := mul_le_mul hh he2 (Real.exp_pos _).le (show 0≤(K0+K1+1)*(β*b^(1+β)) by positivity)
    nlinarith only [hm]

/-- All actual residual coefficients carry beta, including the constant and linear terms. -/
theorem actual_near_one_residual_coefficients_uniform {eps cb lambda CL cL cmin q Q M cw f cu u0 : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcL : 0<cL) (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hf : 0≤f) (hf1 : f≤1)
    (hcu : 0≤cu) (hu0 : 0<u0) :
    ∃ K : ℝ, 0<K ∧ ∀ (k N j : ℕ) (alpha Ch D c : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) →
      let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
        (upperRescaling k alpha eps cu u0)
      let t := upperB k alpha eps D cb CL cL/(N:ℝ)^2
      |(P-C (t^(alpha-1))*X).coeff j|≤
        K*(alpha-1)*(upperB k alpha eps D cb CL cL)^(alpha-(j:ℝ))*
          Real.exp (K*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)) := by
  obtain ⟨K0,hK0,haff⟩ := actual_near_one_affine_uniform (f:=f) heps hcb hlambda hCL hcL hcmin hq hQ hM hcw hcw1 hcu hu0
  obtain ⟨K1,hK1,hhigh⟩ := actual_near_one_coefficients_uniform heps hcb hlambda hCL hcL hcmin hq hQ hM hcw hcw1 hf hf1
  refine ⟨K0+K1+1,by positivity,?_⟩
  intro k N j alpha Ch D c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
  dsimp only
  have hβ : 0<alpha-1 := sub_pos.mpr halpha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order halpha halpha1).2];exact hβ
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order halpha halpha1).2];linarith only [halpha1]
  have hL := upperDegree_pos halpha hCL hcL (one_le_rootMultiplier (k:=k) (ε:=eps) halpha hg hg1)
  have hNr : 0<(N:ℝ) := (mul_pos hq hL).trans_le hNlo
  have hN : 0<N := by exact_mod_cast hNr
  have hN1 : (1:ℝ)≤N := by exact_mod_cast hN
  have hb := upperB_pos (ε:=eps) hk halpha hg hg1 hD hcb hCL hcL
  have ht : 0<upperB k alpha eps D cb CL cL/(N:ℝ)^2 := div_pos hb (sq_pos_of_pos hNr)
  have htb : upperB k alpha eps D cb CL cL/(N:ℝ)^2≤upperB k alpha eps D cb CL cL := by
    apply (div_le_iff₀ (sq_pos_of_pos hNr)).mpr
    nlinarith only [mul_le_mul_of_nonneg_left (show (1:ℝ)≤(N:ℝ)^2 by nlinarith only [hN1]) hb.le]
  have hs := upperRescaling_near_one (k:=k) (eps:=eps) halpha halpha1 hcu hu0
  have ha := haff k N alpha Ch D c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
  dsimp only at ha
  have hh (j : ℕ) (hj : 2≤j) := hhigh k N j alpha Ch D c (upperRescaling k alpha eps cu u0)
    hk halpha halpha1 hCh hD hc hc1 hNlo hNhi hs.1.le hs.2.1 hj
  have hzero : |(actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
      (upperRescaling k alpha eps cu u0)).coeff 0|≤K0*(alpha-1)*
      (upperB k alpha eps D cb CL cL/(N:ℝ)^2)^(1+(alpha-1)) := by
    simpa only [show 1+(alpha-1)=alpha by ring] using ha.1
  have hh' (j : ℕ) (hj : 2≤j) :
      |(actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
        (upperRescaling k alpha eps cu u0)).coeff j| * (upperB k alpha eps D cb CL cL)^j≤
      K1*(alpha-1)*(upperB k alpha eps D cb CL cL)^(1+(alpha-1))*
        Real.exp (K1*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)) := by
    simpa only [show 1+(alpha-1)=alpha by ring] using hh j hj
  have h := affine_residual_coefficient_budget _ hβ ht htb hL.le hK0.le hK1.le hzero ha.2.1 hh' j
  rw [show 1+(alpha-1)=alpha by ring] at h
  have hdiv := (le_div_iff₀ (pow_pos hb j)).mpr h
  apply hdiv.trans_eq
  rw [Real.rpow_sub hb,Real.rpow_natCast]
  ring

end Renyi
