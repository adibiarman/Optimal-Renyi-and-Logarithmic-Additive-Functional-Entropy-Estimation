import Renyi.AnalyticAffine
import Renyi.PoissonPoincareKernel
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# Direct Poisson Poincare inequality

The proof uses telescoping Cauchy--Schwarz and the exact Poisson path kernel.
The argument does not assume completeness of the Charlier polynomials.
-/

noncomputable section
open scoped BigOperators NNReal ENNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- Absolute summability is a consequence of actual Poisson integrability. -/
theorem poisson_integrable_norm_summable (lam : ℝ≥0) (f : ℕ → ℝ)
    (hf : Integrable f (poissonMeasure lam)) :
    Summable (fun n => ‖f n‖ * poissonPMFReal lam n) := by
  have hfin := hf.2
  rw [hasFiniteIntegral_iff_norm, lintegral_countable'] at hfin
  have hmass (n : ℕ) : poissonMeasure lam {n} = ENNReal.ofReal (poissonPMFReal lam n) :=
    PMF.toMeasure_apply_singleton _ _ (MeasurableSet.singleton _)
  simp_rw [hmass, ← ENNReal.ofReal_mul (norm_nonneg _)] at hfin
  have hs := ENNReal.summable_toReal hfin.ne
  simpa only [ENNReal.toReal_ofReal (mul_nonneg (norm_nonneg _) poissonPMFReal_nonneg)] using hs

theorem poisson_integrable_summable (lam : ℝ≥0) (f : ℕ → ℝ)
    (hf : Integrable f (poissonMeasure lam)) :
    Summable (fun n => f n * poissonPMFReal lam n) := by
  apply Summable.of_norm
  simpa only [norm_mul, Real.norm_of_nonneg poissonPMFReal_nonneg] using
    poisson_integrable_norm_summable lam f hf

/-- A finite path is controlled by its squared increments and its length. -/
theorem sq_sub_le_path_energy (v : ℕ → ℝ) (m n : ℕ) (hmn : m ≤ n) :
    (v n - v m) ^ 2 ≤ ((n : ℝ) - m) *
      ∑ k ∈ Finset.Ico m n, (forwardDifference v k) ^ 2 := by
  have htel : (∑ k ∈ Finset.Ico m n, forwardDifference v k) = v n - v m := by
    unfold forwardDifference
    rw [Finset.sum_Ico_eq_sub _ hmn, Finset.sum_range_sub, Finset.sum_range_sub]
    ring
  have hCS := Finset.sum_mul_sq_le_sq_mul_sq (Finset.Ico m n)
    (fun _ : ℕ => (1 : ℝ)) (forwardDifference v)
  simp only [one_mul, one_pow, Finset.sum_const, nsmul_eq_mul, mul_one,
    Nat.card_Ico, Nat.cast_sub hmn] at hCS
  rw [htel] at hCS
  exact hCS

/-- The weighted pairwise squared difference has exactly twice the Poisson variance. -/
theorem poisson_pairwise_variance_hasSum (lam : ℝ≥0) (v : ℕ → ℝ)
    (hv : MemLp v 2 (poissonMeasure lam)) :
    HasSum (fun mn : ℕ × ℕ => poissonPMFReal lam mn.1 * poissonPMFReal lam mn.2 *
      (v mn.2 - v mn.1) ^ 2) (2 * variance v (poissonMeasure lam)) := by
  let M := ∫ n, v n ∂poissonMeasure lam
  let S := ∫ n, v n ^ 2 ∂poissonMeasure lam
  have h1 : HasSum (fun n => v n * poissonPMFReal lam n) M := by
    rw [show M = ∑' n, v n * poissonPMFReal lam n from
      poisson_integral_eq_tsum lam v (hv.integrable one_le_two)]
    exact (poisson_integrable_summable lam v (hv.integrable one_le_two)).hasSum
  have h2 : HasSum (fun n => v n ^ 2 * poissonPMFReal lam n) S := by
    rw [show S = ∑' n, v n ^ 2 * poissonPMFReal lam n from
      poisson_integral_eq_tsum lam _ hv.integrable_sq]
    exact (poisson_integrable_summable lam _ hv.integrable_sq).hasSum
  let D : ℕ × ℕ → ℝ := fun mn => poissonPMFReal lam mn.1 * poissonPMFReal lam mn.2 *
      (v mn.2 - v mn.1) ^ 2
  let g : ℕ → ℝ := fun m => poissonPMFReal lam m * S -
      2 * poissonPMFReal lam m * v m * M + poissonPMFReal lam m * v m ^ 2
  have hi (m : ℕ) : HasSum (fun n => D (m, n)) (g m) := by
    have h := ((h2.mul_left (poissonPMFReal lam m)).sub
      (h1.mul_left (2 * poissonPMFReal lam m * v m))).add
      ((poissonPMFRealSum lam).mul_left (poissonPMFReal lam m * v m ^ 2))
    convert h using 1
    · funext n
      dsimp [D]
      ring
    · dsimp [g]
      ring
  have ho : HasSum g (2 * S - 2 * M ^ 2) := by
    have h := (((poissonPMFRealSum lam).mul_left S).sub (h1.mul_left (2 * M))).add h2
    convert h using 1
    · funext m
      dsimp [g]
      ring
    · ring
  have hD : Summable D := by
    apply (summable_prod_of_nonneg (fun mn => by exact mul_nonneg (mul_nonneg poissonPMFReal_nonneg poissonPMFReal_nonneg) (sq_nonneg _))).mpr
    refine ⟨fun m => (hi m).summable, ?_⟩
    simp_rw [(hi _).tsum_eq]
    exact ho.summable
  have hsum : HasSum D (2 * S - 2 * M ^ 2) := by
    have ht := hD.tsum_prod' (fun m => (hi m).summable)
    simp_rw [(hi _).tsum_eq] at ht
    rw [ho.tsum_eq] at ht
    exact ht ▸ hD.hasSum
  convert hsum using 1
  rw [variance_eq_sub hv]
  simp only [Pi.pow_apply]
  dsimp [M, S]
  ring

def poissonPathEnergy (lam : ℝ≥0) (e : ℕ → ℝ) (mn : ℕ × ℕ) : ℝ :=
  poissonPMFReal lam mn.1 * poissonPMFReal lam mn.2 * ((mn.2 : ℝ) - mn.1) *
    ∑ k ∈ Finset.Ico mn.1 mn.2, e k

theorem poissonPathEnergy_nonneg (lam : ℝ≥0) (e : ℕ → ℝ) (he : ∀ k, 0 ≤ e k)
    (mn : ℕ × ℕ) : 0 ≤ poissonPathEnergy lam e mn := by
  by_cases h : mn.1 ≤ mn.2
  · unfold poissonPathEnergy
    exact mul_nonneg (mul_nonneg (mul_nonneg poissonPMFReal_nonneg poissonPMFReal_nonneg)
      (sub_nonneg.mpr (by exact_mod_cast h))) (Finset.sum_nonneg (fun k _ => he k))
  · have hempty : Finset.Ico mn.1 mn.2 = ∅ := Finset.Ico_eq_empty_of_le (Nat.le_of_not_ge h)
    simp [poissonPathEnergy, hempty]

/-- Summing all directed paths gives exactly the Poisson Dirichlet energy. -/
theorem poissonPathEnergy_hasSum (lam : ℝ≥0) (e : ℕ → ℝ)
    (he : ∀ k, 0 ≤ e k) (hs : Summable (fun k => e k * poissonPMFReal lam k)) :
    HasSum (poissonPathEnergy lam e) ((lam : ℝ) * ∑' k, e k * poissonPMFReal lam k) := by
  let F : ℕ × (ℕ × ℕ) → ℝ := fun z => e z.1 *
    (if z.2.1 ≤ z.1 ∧ z.1 < z.2.2 then
      poissonPMFReal lam z.2.1 * poissonPMFReal lam z.2.2 * ((z.2.2 : ℝ) - z.2.1) else 0)
  have hFnon : 0 ≤ F := by
    intro z
    dsimp [F]
    split_ifs with h
    · exact mul_nonneg (he _) (mul_nonneg (mul_nonneg poissonPMFReal_nonneg poissonPMFReal_nonneg)
        (sub_nonneg.mpr (by exact_mod_cast le_trans h.1 h.2.le)))
    · simp
  have hi (k : ℕ) : HasSum (fun mn => F (k, mn)) ((lam : ℝ) * (e k * poissonPMFReal lam k)) := by
    convert (poisson_poincare_kernel_hasSum lam k).mul_left (e k) using 1
    ring
  have ho : HasSum (fun k => (lam : ℝ) * (e k * poissonPMFReal lam k))
      ((lam : ℝ) * ∑' k, e k * poissonPMFReal lam k) := hs.hasSum.mul_left _
  have hF : Summable F := by
    apply (summable_prod_of_nonneg hFnon).mpr
    refine ⟨fun k => (hi k).summable, ?_⟩
    simp_rw [(hi _).tsum_eq]
    exact ho.summable
  have hv : (∑' z, F z) = (lam : ℝ) * ∑' k, e k * poissonPMFReal lam k :=
    (hF.hasSum.prod_fiberwise hi).unique ho
  have hsw : HasSum (fun z : (ℕ × ℕ) × ℕ => F (z.2, z.1))
      ((lam : ℝ) * ∑' k, e k * poissonPMFReal lam k) := by
    apply ((Equiv.prodComm (ℕ × ℕ) ℕ).hasSum_iff (f := F)).mpr
    exact hv ▸ hF.hasSum
  apply hsw.prod_fiberwise
  intro mn
  have hk := hasSum_sum_of_ne_finset_zero (s := Finset.Ico mn.1 mn.2)
    (L := .unconditional ℕ) (f := fun k => F (k, mn)) (fun k hk => by
      have hnot : ¬ (mn.1 ≤ k ∧ k < mn.2) := by simpa only [Finset.mem_Ico] using hk
      simp [F, hnot])
  convert hk using 1
  unfold poissonPathEnergy
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k hk
  dsimp [F]
  rw [if_pos (Finset.mem_Ico.mp hk)]
  ring

/-- Sharp Poisson Poincare inequality, proved directly by paths and Cauchy--Schwarz. -/
theorem poisson_poincare (lam : ℝ≥0) (v : ℕ → ℝ)
    (hv : MemLp v 2 (poissonMeasure lam))
    (hd : MemLp (forwardDifference v) 2 (poissonMeasure lam)) :
    variance v (poissonMeasure lam) ≤
      (lam : ℝ) * ∫ n, (forwardDifference v n) ^ 2 ∂poissonMeasure lam := by
  let e : ℕ → ℝ := fun k => (forwardDifference v k) ^ 2
  have he : ∀ k, 0 ≤ e k := fun k => sq_nonneg _
  have hs : Summable (fun k => e k * poissonPMFReal lam k) :=
    poisson_integrable_summable lam e hd.integrable_sq
  have hB := poissonPathEnergy_hasSum lam e he hs
  have hBswap : HasSum (fun mn : ℕ × ℕ => poissonPathEnergy lam e mn.swap)
      ((lam : ℝ) * ∑' k, e k * poissonPMFReal lam k) :=
    ((Equiv.prodComm ℕ ℕ).hasSum_iff (f := poissonPathEnergy lam e)).mpr hB
  have hpoint (mn : ℕ × ℕ) :
      poissonPMFReal lam mn.1 * poissonPMFReal lam mn.2 * (v mn.2 - v mn.1) ^ 2 ≤
        poissonPathEnergy lam e mn + poissonPathEnergy lam e mn.swap := by
    have hpmf : 0 ≤ poissonPMFReal lam mn.1 * poissonPMFReal lam mn.2 :=
      mul_nonneg poissonPMFReal_nonneg poissonPMFReal_nonneg
    rcases le_total mn.1 mn.2 with h | h
    · have hp := mul_le_mul_of_nonneg_left (sq_sub_le_path_energy v mn.1 mn.2 h) hpmf
      have hBnon := poissonPathEnergy_nonneg lam e he mn.swap
      dsimp [poissonPathEnergy, e] at *
      nlinarith
    · have hp := mul_le_mul_of_nonneg_left (sq_sub_le_path_energy v mn.2 mn.1 h) hpmf
      have hBnon := poissonPathEnergy_nonneg lam e he mn
      dsimp [poissonPathEnergy, e] at *
      nlinarith
  have hD := poisson_pairwise_variance_hasSum lam v hv
  have hle := hD.summable.tsum_le_tsum hpoint (hB.summable.add hBswap.summable)
  rw [hD.tsum_eq, (hB.add hBswap).tsum_eq] at hle
  have hint : (∫ n, (forwardDifference v n) ^ 2 ∂poissonMeasure lam) =
      ∑' k, e k * poissonPMFReal lam k := poisson_integral_eq_tsum lam e hd.integrable_sq
  rw [hint]
  linarith

/-- Poincare applied to the actual analytic count after subtracting an affine term. -/
theorem analyticCount_affine_poincare (lam : ℝ≥0) (a c d : ℝ) :
    variance (fun n : ℕ => analyticCount a n - c * (n : ℝ) - d) (poissonMeasure lam) ≤
      (lam : ℝ) * ∫ n, (a * analyticCount (a - 1) n - c) ^ 2 ∂poissonMeasure lam := by
  let v : ℕ → ℝ := fun n => analyticCount a n - c * (n : ℝ) - d
  have hv : MemLp v 2 (poissonMeasure lam) :=
    ((analyticCount_memLp lam a).sub ((poisson_nat_memLp lam).const_mul c)).sub (memLp_const d)
  have heq : forwardDifference v = fun n => a * analyticCount (a - 1) n - c := by
    funext n
    have h := analyticCount_difference a n
    unfold forwardDifference at h ⊢
    dsimp [v]
    push_cast
    linarith
  have hd : MemLp (forwardDifference v) 2 (poissonMeasure lam) := by
    rw [heq]
    exact ((analyticCount_memLp lam (a - 1)).const_mul a).sub (memLp_const c)
  have h := poisson_poincare lam v hv hd
  rw [heq] at h
  exact h

end Renyi
