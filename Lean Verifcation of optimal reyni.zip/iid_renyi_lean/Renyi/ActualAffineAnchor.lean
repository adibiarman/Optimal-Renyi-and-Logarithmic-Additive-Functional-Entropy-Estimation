import Renyi.ActualCountProfile
import Renyi.CommonAnchor
import Renyi.UpperPilotBaseline
import Renyi.UpperRescaling
import Renyi.NearOneLogDecay

/-! Actual source calibration of the common affine anchor for orders at least 3/2. -/
set_option maxHeartbeats 800000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Polynomial
namespace Renyi

theorem upperSample_ge_cube_root {k : ℕ} {alpha eps D : ℝ}
    (hk : 0<k) (ha : 3/2≤alpha) (hg : 0<fractionalPart alpha)
    (hg1 : fractionalPart alpha<1) (hD : 1≤D) :
    (k:ℝ)^(1/3:ℝ)≤upperSample k alpha eps D := by
  have hk1 : (1:ℝ)≤k := by exact_mod_cast hk
  have ha1 : 1<alpha := by linarith
  have ha0 : 0<alpha := by linarith
  have hfrac : (1/3:ℝ)≤1-1/alpha := by
    have hh : 1/alpha≤(2/3:ℝ) := (div_le_iff₀ ha0).2 (by linarith only [ha])
    linarith
  have hp := Real.rpow_le_rpow_of_exponent_le hk1 hfrac
  have hX := one_le_rootMultiplier (k:=k) (ε:=eps) ha1 hg hg1
  have hcoef : 1≤D*alpha*rootMultiplier k alpha eps := by
    have hh := mul_le_mul hD ha1.le (by norm_num : (0:ℝ)≤1) (by linarith : 0≤D)
    have hh' := mul_le_mul hh hX (by norm_num : (0:ℝ)≤1) (by positivity : 0≤D*alpha)
    simpa only [one_mul] using hh'
  have hm := mul_le_mul_of_nonneg_right hcoef (Real.rpow_nonneg (by positivity : (0:ℝ)≤k) (1-1/alpha))
  apply hp.trans
  unfold upperSample
  nlinarith only [hm]

/-- The coefficient is bounded for the canonical completed polynomial, including
its degree-one branch and actual overlap attenuation. -/
theorem actualUpperPolynomial_affine_coefficient {k : ℕ}
    {alpha eps Ch D cb lambda CL cL fL f Mprof cw : ℝ}
    (hk : 0<k) (ha : 3/2≤alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (heps : 0<eps) (hCh : 0≤Ch) (hD : 0<D) (hcb : 0<cb)
    (hlambda : 0<lambda) (hlambda4 : lambda≤4) (hCL : 1≤CL) (hcL : 0<cL) (hcbCL : 1≤cb*CL)
    (hfL : 0≤fL) (hfL1 : fL<1) (hMprof : 0≤Mprof) (hcw : 0<cw) :
    |(actualUpperPolynomial k alpha eps Ch D cb lambda CL cL fL f Mprof cw).coeff 1|≤
      coupledLowCoefficientConstant^(upperOrderFloor alpha+1)*
        upperA k alpha eps Ch D cb lambda CL cL^(alpha-1) := by
  have ha1 : 1<alpha := by linarith
  have hm := upperOrderFloor_one_le ha1
  have hgeometry := upper_actual_count_geometry hk ha hg hg1 heps hCh hD hcb hlambda hlambda4 hCL hcL hcbCL
  rcases hgeometry with ⟨haCut,_hab,hb,hell,hN2,_hellm,hdegree,_hellN,hlocal,_hnb,_hH,_hscale,_hrd,_hdL,_hdH⟩
  have hN : 0<upperDegree alpha CL cL (rootMultiplier k alpha eps) := by omega
  have hell1 : (1:ℝ)≤upperLowResolution alpha := by exact_mod_cast hell
  have hellsq : (1:ℝ)≤(upperLowResolution alpha:ℝ)^2 := by nlinarith only [hell1]
  have hratio0 : 0≤upperA k alpha eps Ch D cb lambda CL cL*
      (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2/upperB k alpha eps D cb CL cL := by positivity
  have hratio := (mul_le_mul_of_nonneg_right hellsq hratio0).trans hlocal
  have hZ : (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2*
      (upperA k alpha eps Ch D cb lambda CL cL/upperB k alpha eps D cb CL cL)≤1 := by
    convert hratio using 1; ring
  have hprofile := upper_actual_count_profile_ranges (k:=k) ha1 hg hg1 heps hCh hMprof hcw hfL1
  rcases hprofile with ⟨hc,hA,hA1,_hB,_hB1,_hw,_hw1⟩
  have hcoeff := completedCoupledPolynomial_low_coefficient_exponential (j:=1) (f:=f)
    (B:=overlapB (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-Mprof*(1-fractionalPart alpha)))
    (ω:=upperOmega k alpha eps Ch cw)
    hell hN hm hdegree hm hg hg1.le haCut hb hc hfL hfL1 hA hA1 hZ
  have hsplit : (upperOrderFloor alpha:ℝ)+fractionalPart alpha-(1:ℕ)=alpha-1 := by
    rw [fractionalPart_eq_upperOrderFloor ha1]; push_cast; ring
  simpa only [actualUpperPolynomial,hsplit] using hcoeff

/-- Rescaling does not enlarge the actual affine coefficient. -/
theorem actualUpperPolynomial_rescaled_affine_coefficient {k : ℕ}
    {alpha eps Ch D cb lambda CL cL fL f Mprof cw cu u0 : ℝ}
    (hk : 0<k) (ha : 3/2≤alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (heps : 0<eps) (hCh : 0≤Ch) (hD : 0<D) (hcb : 0<cb)
    (hlambda : 0<lambda) (hlambda4 : lambda≤4) (hCL : 1≤CL) (hcL : 0<cL) (hcbCL : 1≤cb*CL)
    (hfL : 0≤fL) (hfL1 : fL<1) (hMprof : 0≤Mprof) (hcw : 0<cw) (hcu : 0≤cu) (hu0 : 0<u0) :
    |upperRescaling k alpha eps cu u0 *
        (actualUpperPolynomial k alpha eps Ch D cb lambda CL cL fL f Mprof cw).coeff 1|≤
      coupledLowCoefficientConstant^(upperOrderFloor alpha+1)*
        upperA k alpha eps Ch D cb lambda CL cL^(alpha-1) := by
  have ha1 : 1<alpha := by linarith
  have hs := upperRescaling_range (k:=k) (eps:=eps) ha1 hg hg1 hcu hu0
  rw [abs_mul,abs_of_nonneg hs.1.le]
  exact (mul_le_of_le_one_left (abs_nonneg _) hs.2).trans
    (actualUpperPolynomial_affine_coefficient hk ha hg hg1 heps hCh hD hcb hlambda hlambda4 hCL hcL hcbCL hfL hfL1 hMprof hcw)

lemma exponential_affine_coefficient_baseline {k m : ℕ} {alpha C C0 db a q : ℝ}
    (hk : 0<k) (ha : 3/2≤alpha) (hC : 0≤C) (hCC : C≤C0) (hdb : 0<db) (haCut : 0<a)
    (hm : m=upperOrderFloor alpha) (hq : |q|≤C^(m+1)*a^(alpha-1)) :
    |q|≤(2*C/db)*(upperActualBaseline k alpha C0 db a*(k:ℝ)^(1-alpha)) := by
  rw [upperActualBaseline_power_identity hk haCut.le]
  have hchi : (1/2:ℝ)≤min (alpha-1) 1 := le_min (by linarith only [ha]) (by norm_num)
  have hC0 : 0≤C0 := hC.trans hCC
  have hp := mul_le_mul_of_nonneg_right (pow_le_pow_left₀ hC hCC m) (mul_nonneg hC (Real.rpow_nonneg haCut.le (alpha-1)))
  have hq' : |q|≤C*C0^m*a^(alpha-1) := by rw [pow_succ] at hq; nlinarith only [hq,hp]
  have hnon : 0≤C*C0^m*a^(alpha-1) := by positivity
  have hh := mul_le_mul_of_nonneg_right hchi hnon
  have heq : (2*C/db)*(min (alpha-1) 1*db*C0^upperOrderFloor alpha*a^(alpha-1)) =
      2*min (alpha-1) 1*(C*C0^m*a^(alpha-1)) := by rw [hm]; field_simp
  rw [heq]
  nlinarith only [hq',hh]

variable {Omega : Type*} [MeasurableSpace Omega]

def actualUpperAffineAnchor {k : ℕ} (Counts : Fin k → Omega → ℕ)
    (alpha eps Ch D cb lambda CL cL fL f Mprof cw cu u0 : ℝ) : Omega → ℝ :=
  poissonAffineAnchor Counts (upperSample k alpha eps D)
    (upperRescaling k alpha eps cu u0 *
      (actualUpperPolynomial k alpha eps Ch D cb lambda CL cL fL f Mprof cw).coeff 1)

/-- Uniform source calibration of the actual affine anchor. All polynomial
coefficients, sample sizes, and baseline factors are the source constructions.
The alphabet threshold is chosen before the experiment, order, and D≥1. -/
theorem actual_upper_affine_anchor_variance_uniform
    {eps Ch cb lambda CL cL fL f Mprof cw cu u0 C0 db eta : ℝ}
    (heps : 0<eps) (hCh : 0≤Ch) (hcb : 0<cb) (hlambda : 0<lambda) (hlambda4 : lambda≤4)
    (hCL : 1≤CL) (hcL : 0<cL) (hcbCL : 1≤cb*CL)
    (hfL : 0≤fL) (hfL1 : fL<1) (hMprof : 0≤Mprof) (hcw : 0<cw) (hcu : 0≤cu) (hu0 : 0<u0)
    (hC0 : coupledLowCoefficientConstant≤C0) (hdb : 0<db) (heta : 0<eta) :
    ∃ k0 : ℕ, ∀ k : ℕ, k0≤k → ∀ alpha D : ℝ,
      3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → 1≤D →
      ∀ p : Simplex k, ∀ {Omega : Type*} [MeasurableSpace Omega] (mu : Measure Omega) [IsProbabilityMeasure mu],
      ∀ (Counts : Fin k → Omega → ℕ) (lam : Fin k → ℝ≥0),
      (∀ i, MeasurePreserving (Counts i) mu (poissonMeasure (lam i))) →
      Pairwise (fun i j => IndepFun (Counts i) (Counts j) mu) →
      (∀ i, (lam i : ℝ)=upperSample k alpha eps D*p.mass i) →
      MemLp (actualUpperAffineAnchor Counts alpha eps Ch D cb lambda CL cL fL f Mprof cw cu u0) 2 mu ∧
      (∫ w, actualUpperAffineAnchor Counts alpha eps Ch D cb lambda CL cL fL f Mprof cw cu u0 w ∂mu)=0 ∧
      variance (actualUpperAffineAnchor Counts alpha eps Ch D cb lambda CL cL fL f Mprof cw cu u0) mu ≤
        eta*(upperActualBaseline k alpha C0 db (upperA k alpha eps Ch D cb lambda CL cL)*(k:ℝ)^(1-alpha)+
          upperKappa alpha eps*upperU k alpha eps u0*powerSum p alpha+
          min (alpha-1) 1*upperKappa alpha eps*conditionalCountBonus p.mass alpha (upperSample k alpha eps D)
            (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ))^2 := by
  let C := 2*coupledLowCoefficientConstant/db
  have hcoeff0 : 0≤coupledLowCoefficientConstant := by unfold coupledLowCoefficientConstant; positivity
  have hC : 0≤C := by dsimp [C]; positivity
  obtain ⟨K,hK⟩ := near_one_log_power_decay 0 (C:=C^2) (r:=(1/3:ℝ)) (eta:=eta)
    (sq_nonneg C) (by norm_num) heta
  refine ⟨max 1 K,?_⟩
  intro k hk alpha D ha hg hg1 hD p Omega instOmega mu instMu Counts lam hLaw hpair hlam
  have hkpos : 0<k := (by norm_num : 0<1).trans_le ((le_max_left _ _).trans hk)
  have hk0 : (0:ℝ)<k := by exact_mod_cast hkpos
  have ha1 : 1<alpha := by linarith only [ha]
  have hDpos : 0<D := zero_lt_one.trans_le hD
  let n := upperSample k alpha eps D
  let a := upperA k alpha eps Ch D cb lambda CL cL
  let q := upperRescaling k alpha eps cu u0 *
    (actualUpperPolynomial k alpha eps Ch D cb lambda CL cL fL f Mprof cw).coeff 1
  let Base := upperActualBaseline k alpha C0 db a*(k:ℝ)^(1-alpha)
  let Margin := Base+upperKappa alpha eps*upperU k alpha eps u0*powerSum p alpha+
    min (alpha-1) 1*upperKappa alpha eps*conditionalCountBonus p.mass alpha n
      (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)
  have hn : 0<n := upperSample_pos hkpos ha1 hg hg1 hDpos
  have haCut : 0<a := (upper_actual_count_geometry hkpos ha hg hg1 heps hCh hDpos hcb hlambda hlambda4 hCL hcL hcbCL).1
  have hbase0 : 0≤Base := mul_nonneg
    (upperActualBaseline_nonneg ha1.le (hcoeff0.trans hC0) hdb.le haCut.le) (Real.rpow_nonneg hk0.le _)
  have hsum : ∑ i, (lam i:ℝ)=n := by
    dsimp [n]
    simp only [hlam,←Finset.mul_sum,p.normalized,mul_one]
  have hq := actualUpperPolynomial_rescaled_affine_coefficient (f:=f) hkpos ha hg hg1 heps hCh hDpos
    hcb hlambda hlambda4 hCL hcL hcbCL hfL hfL1 hMprof hcw hcu hu0
  have hqmargin : |q|≤C*Base := exponential_affine_coefficient_baseline hkpos ha hcoeff0 hC0 hdb haCut rfl hq
  have hmoment := common_affine_anchor_moments Counts lam hLaw hpair hn hsum q
  have hvar := common_affine_anchor_variance_bound Counts lam hLaw hpair hn hsum hC hbase0 hqmargin
  have hnlow := upperSample_ge_cube_root hkpos ha hg hg1 hD (eps:=eps)
  have hinv := div_le_div_of_nonneg_left (sq_nonneg C) (Real.rpow_pos_of_pos hk0 (1/3:ℝ)) hnlow
  have hsmall : C^2/(k:ℝ)^(1/3:ℝ)≤eta := by
    simpa only [pow_zero,mul_one] using hK k ((le_max_right _ _).trans hk)
  have hscaled := mul_le_mul_of_nonneg_right (hinv.trans hsmall) (sq_nonneg Base)
  have hbasevar : variance (poissonAffineAnchor Counts n q) mu≤eta*Base^2 :=
    hvar.trans (by simpa only [n,div_mul_eq_mul_div] using hscaled)
  have hkap : 0≤upperKappa alpha eps := (Real.exp_pos _).le
  have hu : 0≤upperU k alpha eps u0 := (upperU_pos ha1 hg hg1 hu0).le
  have hP : 0≤powerSum p alpha := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (p.nonneg i) _)
  have hL : 0≤(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) := Nat.cast_nonneg _
  have hBonus : 0≤conditionalCountBonus p.mass alpha n (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) :=
    conditionalCountBonus_nonneg p.mass p.nonneg hn.le hL
  have hchi : 0≤min (alpha-1) 1 := le_min (by linarith only [ha]) (by norm_num)
  have hbasemargin : Base≤Margin := by dsimp [Margin]; nlinarith only [mul_nonneg (mul_nonneg hkap hu) hP,mul_nonneg (mul_nonneg hchi hkap) hBonus]
  have hmarginSq := mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hbase0 hbasemargin 2) heta.le
  refine ⟨hmoment.1,hmoment.2.1,?_⟩
  exact hbasevar.trans hmarginSq

end Renyi
