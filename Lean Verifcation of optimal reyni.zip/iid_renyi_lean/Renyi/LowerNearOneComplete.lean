import Renyi.LowerNormalizationCalibration
import Renyi.LowerNearOneDistance

/-! The complete near-one lower bound, with actual calibrated priors and experiments. -/
noncomputable section
open scoped BigOperators NNReal
namespace Renyi

/-- Actual near-one priors imply fixed-size iid impossibility at the root scale.
All count, normalization, alphabet, and availability budgets are proved from
`epsilon` and a uniform alphabet cutoff. No numerical certificate is assumed. -/
theorem lower_near_one_nonachievable {eps : ℝ} (heps : 0 < eps) (heps1 : eps ≤ 1/2) :
    ∃ k0 : ℕ, ∀ k : ℕ, k0 ≤ k → ∀ s : ℝ, 0 < s → s ≤ 1/2 →
      lowerPriorRootCutoff eps ≤ rootMultiplier k (1+s) eps →
      ∀ n : ℕ, (n : ℝ) ≤
        (lowerPriorIntensityConstant eps*(1+s)*(k : ℝ)^(-1/(1+s))*rootMultiplier k (1+s) eps)*
          (k : ℝ)/8 → ¬ Achievable k n (1+s) eps := by
  let ct := lowerPriorIntensityConstant eps*nearOneQConstant eps/Real.exp 1
  let C := max 1 (1/ct)
  have hct : 0 < ct := by
    dsimp [ct, lowerPriorIntensityConstant]
    exact div_pos (mul_pos (Real.exp_pos _) (nearOneQConstant_pos eps)) (Real.exp_pos _)
  have hC : 1 ≤ C := le_max_left _ _
  have hEnv : 0 < nearOneNormalizationEnvelope C := nearOneNormalizationEnvelope_pos hC
  obtain ⟨k0,hk0⟩ := lower_near_one_exception_cutoff hct hEnv
  refine ⟨max 64 k0, ?_⟩
  intro k hk s hs hs1 hx n hn
  have hk64 : 64 ≤ k := (le_max_left _ _).trans hk
  have hkN : 0 < k := by omega
  have hk1 : 1 ≤ k := by omega
  have hkR : (0 : ℝ) < k := by exact_mod_cast hkN
  obtain ⟨hbudget, hsupport, havailable⟩ := hk0 k ((le_max_right _ _).trans hk)
  let alpha := 1+s
  let x := rootMultiplier k alpha eps
  let L := Nat.ceil (10*alpha*(1+Real.log x))
  let theta := lowerPriorIntensityConstant eps*alpha*(k : ℝ)^(-1/alpha)*x
  let B := ((L : ℝ)/100)/theta
  let w := s*(1-s)+s/alpha*x^(-alpha)
  have ha : 1 < alpha := by dsimp [alpha]; linarith
  have ha1 : alpha ≤ 3/2 := by dsimp [alpha]; linarith
  have ha0 : 0 < alpha := by linarith
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hx1 : 1 ≤ x := by linarith
  have hx0 : 0 < x := by linarith
  have htheta : 0 < theta := by
    dsimp [theta, lowerPriorIntensityConstant]
    exact mul_pos (mul_pos (mul_pos (Real.exp_pos _) ha0) (Real.rpow_pos_of_pos hkR _)) hx0
  have hL : (0 : ℝ) < L := (show 0 < 10*alpha*(1+Real.log x) by
    have hlog := Real.log_nonneg hx1
    positivity).trans_le (Nat.le_ceil _)
  have hB0 : 0 < B := by dsimp [B]; positivity
  have hv0 : 0 ≤ s/alpha*x^(-alpha) := by positivity
  have hwm : (alpha-1)/2 ≤ w := by
    dsimp [w,alpha]
    nlinarith
  have hw0 : 0 < w := lt_of_lt_of_le (by linarith : 0 < (alpha-1)/2) hwm
  have hxp : x^(-alpha) ≤ 1 := by
    simpa only [Real.rpow_zero] using Real.rpow_le_rpow_of_exponent_le hx1 (show -alpha ≤ (0 : ℝ) by linarith)
  have hsdiv : s/alpha ≤ s := (div_le_iff₀ ha0).mpr (by dsimp [alpha]; nlinarith)
  have hv1 : s/alpha*x^(-alpha) ≤ s :=
    (mul_le_of_le_one_right (by positivity) hxp).trans hsdiv
  have hw1 : w ≤ 1 := by dsimp [w]; nlinarith
  obtain ⟨P0,P1,hsupp0,hsupp1,hmean0,hmean1,hgap,hD⟩ :=
    lower_actual_near_one_count_priors hkN hs hs1 heps heps1 hx
  change ∀ i, P0.value i=0 ∨ (1 ≤ P0.value i ∧ P0.value i ≤ B) at hsupp0
  change ∀ i, P1.value i=0 ∨ (1 ≤ P1.value i ∧ P1.value i ≤ B) at hsupp1
  have hvalues0 : ∀ i, 0 ≤ P0.value i := fun i =>
    (hsupp0 i).elim (fun h => h ▸ le_rfl) (fun h => zero_le_one.trans h.1)
  have hvalues1 : ∀ i, 0 ≤ P1.value i := fun i =>
    (hsupp1 i).elim (fun h => h ▸ le_rfl) (fun h => zero_le_one.trans h.1)
  have hB : 1 ≤ B := by
    have hsum : (∑ i, P0.mass i * P0.value i) ≤ B := by
      calc
        _ ≤ ∑ i, P0.mass i * B := by
          apply Finset.sum_le_sum
          intro i _
          have hvi : P0.value i ≤ B := (hsupp0 i).elim (fun h => h ▸ hB0.le) (fun h => h.2)
          exact mul_le_mul_of_nonneg_left hvi (P0.mass_nonneg i)
        _ = B := by rw [← Finset.sum_mul, P0.mass_sum, one_mul]
    have hm0 : (∑ i, P0.mass i * P0.value i) = 1 := by
      simpa only [priorMoment, Real.rpow_one] using hmean0
    rwa [hm0] at hsum
  have hBupper : B ≤ C*(1+Real.log k)^2 := by
    have h := lower_near_one_support_upper hkN ha ha1 heps hx4
    have hC' : 1/ct ≤ C := le_max_right _ _
    exact h.trans (mul_le_mul_of_nonneg_right hC' (sq_nonneg _))
  let b : ℝ≥0 := ⟨(k : ℝ)/2, by positivity⟩
  let thetaNN : ℝ≥0 := ⟨theta, htheta.le⟩
  have hb : (b : ℝ) = (k : ℝ)/2 := rfl
  have hb0 : 0 < (b : ℝ) := by change 0 < (k : ℝ)/2; positivity
  have hzeta0 : priorNormalizationMomentBudget b P0 alpha w ≤ 1/64 :=
    (prior_normalization_near_one_polylog hk1 b hb P0 ha ha1 hB hC hBupper hsupp0 hmean0 hwm).trans hbudget
  have hzeta1 : priorNormalizationMomentBudget b P1 alpha w ≤ 1/64 :=
    (prior_normalization_near_one_polylog hk1 b hb P1 ha ha1 hB hC hBupper hsupp1 hmean1 hwm).trans hbudget
  have hA0 : 0 < priorMoment P0 alpha :=
    zero_lt_one.trans_le (finite_prior_power_bounds P0 alpha B ha hB hsupp0 hmean0).1
  have hA1 : 0 < priorMoment P1 alpha :=
    zero_lt_one.trans_le (finite_prior_power_bounds P1 alpha B ha hB hsupp1 hmean1).1
  have hthetaLower : ct/(1+Real.log k) ≤ theta := lower_near_one_intensity_lower hkN ha ha1 heps hx4
  apply fingerprint_transfer_finite_priors b thetaNN hb0 (by change 2*((k : ℝ)/2) ≤ k; linarith)
    P0 P1 hvalues0 hvalues1 ha hw0 hw1 hA0 hA1 hmean0 hmean1 hgap
  · change ((k : ℝ)/2)*countDistance (poissonMixture P0.mass P0.value theta)
      (poissonMixture P1.mass P1.value theta) ≤ 1/16
    nlinarith only [hD]
  · exact hzeta0
  · exact hzeta1
  · exact hsupport
  · change Real.exp (-theta*((k : ℝ)/2)/16) ≤ 1/128
    convert havailable theta hthetaLower using 1
    congr 1
    ring
  · change (n : ℝ) ≤ theta*((k : ℝ)/2)/4
    change (n : ℝ) ≤ theta*(k : ℝ)/8 at hn
    linarith

/-- The near-one branch has the claimed uniform minimax lower scale, with an
accuracy-dependent constant and no assumed lower-bound certificate. -/
theorem lower_near_one_sample_lower {eps : ℝ} (heps : 0 < eps) (heps1 : eps ≤ 1/2) :
    ∃ c : ℝ, 0 < c ∧ ∃ k0 : ℕ, ∀ k : ℕ, k0 ≤ k → ∀ s : ℝ, 0 < s → s ≤ 1/2 →
      lowerPriorRootCutoff eps ≤ rootMultiplier k (1+s) eps →
      ∀ n : ℕ, Achievable k n (1+s) eps →
        c*(1+s)*(k : ℝ)^(1-1/(1+s))*rootMultiplier k (1+s) eps ≤ n := by
  obtain ⟨k0,hk0⟩ := lower_near_one_nonachievable heps heps1
  let c := lowerPriorIntensityConstant eps/8
  have hc : 0 < c := by dsimp [c,lowerPriorIntensityConstant]; positivity
  refine ⟨c,hc,max 1 k0,?_⟩
  intro k hk s hs hs1 hx n hach
  have hk1 : 1 ≤ k := (le_max_left _ _).trans hk
  have hkR : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  let alpha := 1+s
  have hid : (k : ℝ)^(-1/alpha)*(k : ℝ) = (k : ℝ)^(1-1/alpha) := by
    calc
      _ = (k : ℝ)^(-1/alpha)*(k : ℝ)^(1 : ℝ) := by rw [Real.rpow_one]
      _ = _ := by rw [← Real.rpow_add hkR]; congr 1; ring
  have hscale : (lowerPriorIntensityConstant eps*(1+s)*(k : ℝ)^(-1/(1+s))*rootMultiplier k (1+s) eps)*
      (k : ℝ)/8 = c*(1+s)*(k : ℝ)^(1-1/(1+s))*rootMultiplier k (1+s) eps := by
    change (lowerPriorIntensityConstant eps*alpha*(k : ℝ)^(-1/alpha)*rootMultiplier k (1+s) eps)*
      (k : ℝ)/8 = c*alpha*(k : ℝ)^(1-1/alpha)*rootMultiplier k (1+s) eps
    rw [← hid]
    dsimp [c]
    ring
  by_contra hsmall
  have hn : (n : ℝ) ≤ (lowerPriorIntensityConstant eps*(1+s)*(k : ℝ)^(-1/(1+s))*rootMultiplier k (1+s) eps)*
      (k : ℝ)/8 := by rw [hscale]; exact (lt_of_not_ge hsmall).le
  exact hk0 k ((le_max_right _ _).trans hk) s hs hs1 hx n hn hach

/-- The near-one root tends uniformly to infinity with the alphabet, so its
fixed accuracy-dependent construction cutoff excludes no asymptotic regime. -/
theorem near_one_root_uniform_lower {eps C : ℝ} (heps : 0 < eps) (hC : 1 ≤ C) :
    ∃ k0 : ℕ, ∀ k : ℕ, k0 ≤ k → ∀ alpha : ℝ, 1 < alpha → alpha ≤ 3/2 →
      C ≤ rootMultiplier k alpha eps := by
  let cq := nearOneQConstant eps
  let H := Real.exp 1*C*(1+Real.log C)
  let T := max 1 ((H+1)/cq)
  have hcq : 0 < cq := nearOneQConstant_pos eps
  have hC0 : 0 < C := zero_lt_one.trans_le hC
  have hH : 0 < H := by dsimp [H]; have h := Real.log_nonneg hC; positivity
  have hT1 : 1 ≤ T := le_max_left _ _
  have hT : 0 < T := zero_lt_one.trans_le hT1
  refine ⟨max 1 (Nat.ceil (T^3)), ?_⟩
  intro k hk alpha ha ha1
  have hk1 : 1 ≤ k := (le_max_left _ _).trans hk
  have hkN : 0 < k := by omega
  have hkR : (1 : ℝ) ≤ k := by exact_mod_cast hk1
  have hk0 : (0 : ℝ) < k := zero_lt_one.trans_le hkR
  have ha0 : 0 < alpha := by linarith
  have hceil : T^3 ≤ (k : ℝ) := (Nat.le_ceil _).trans
    (by exact_mod_cast (le_max_right 1 (Nat.ceil (T^3))).trans hk)
  have hpow := Real.rpow_le_rpow (by positivity : (0 : ℝ) ≤ T^3) hceil
    (by norm_num : (0 : ℝ) ≤ 2/3)
  have hid : (T^3)^(2/3 : ℝ) = T^2 := by
    rw [← Real.rpow_natCast_mul hT.le]
    norm_num
  rw [hid] at hpow
  have hT2 : T ≤ T^2 := by nlinarith
  have hTdef : (H+1)/cq ≤ T := le_max_right _ _
  have hlarge : H < cq*(k : ℝ)^(2/3 : ℝ) := by
    have hm := mul_le_mul_of_nonneg_left (hT2.trans hpow) hcq.le
    have hh := (div_le_iff₀ hcq).mp hTdef
    nlinarith
  have he : (2/3 : ℝ) ≤ 1/alpha := (le_div_iff₀ ha0).mpr (by linarith)
  have hpowalpha := Real.rpow_le_rpow_of_exponent_le hkR he
  have hQ := (near_one_Q_bounds hkN ha ha1 heps).1
  have hlow : cq*(k : ℝ)^(2/3 : ℝ) ≤ rootQSquared k alpha eps :=
    (mul_le_mul_of_nonneg_left hpowalpha hcq.le).trans hQ
  have hgamma := (near_one_order ha ha1).2
  have hg0 : 0 < fractionalPart alpha := by rw [hgamma]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [hgamma]; linarith
  have hX1 := one_le_rootMultiplier (k := k) (ε := eps) ha hg0 hg1
  have hX0 : 0 < rootMultiplier k alpha eps := zero_lt_one.trans_le hX1
  have hupper := upper_root_Q_bound (k := k) (eps := eps) ha hg0 hg1
  by_contra hsmall
  have hXC : rootMultiplier k alpha eps ≤ C := (lt_of_not_ge hsmall).le
  have hlog := Real.log_le_log hX0 hXC
  have hprod := mul_le_mul hXC (add_le_add_left hlog 1)
    (show 0 ≤ 1+Real.log (rootMultiplier k alpha eps) by linarith [Real.log_nonneg hX1]) hC0.le
  have hbound := mul_le_mul_of_nonneg_left hprod (Real.exp_pos 1).le
  dsimp [H] at hlarge
  nlinarith [hlow,hupper,hbound]

/-- The full near-one minimax lower bound, including orders that approach one
with the alphabet. The constant is independent of the order and alphabet. -/
theorem lower_near_one_uniform {eps : ℝ} (heps : 0 < eps) (heps1 : eps ≤ 1/2) :
    ∃ c : ℝ, 0 < c ∧ ∃ k0 : ℕ, ∀ k : ℕ, k0 ≤ k → ∀ alpha : ℝ,
      1 < alpha → alpha ≤ 3/2 → ∀ n : ℕ, Achievable k n alpha eps →
        c*alpha*(k : ℝ)^(1-1/alpha)*rootMultiplier k alpha eps ≤ n := by
  obtain ⟨c,hc,k1,hk1⟩ := lower_near_one_sample_lower heps heps1
  have hcut : 1 ≤ lowerPriorRootCutoff eps :=
    (by norm_num : (1 : ℝ) ≤ 4).trans (le_max_left _ _)
  obtain ⟨k2,hk2⟩ := near_one_root_uniform_lower heps hcut
  refine ⟨c,hc,max k1 k2,?_⟩
  intro k hk alpha ha ha1 n hach
  have hs : 0 < alpha-1 := sub_pos.mpr ha
  have hs1 : alpha-1 ≤ 1/2 := by linarith
  have hroot := hk2 k ((le_max_right _ _).trans hk) alpha ha ha1
  have h := hk1 k ((le_max_left _ _).trans hk) (alpha-1) hs hs1
  have heq : 1+(alpha-1)=alpha := by ring
  rw [heq] at h
  exact h hroot n hach

end Renyi
