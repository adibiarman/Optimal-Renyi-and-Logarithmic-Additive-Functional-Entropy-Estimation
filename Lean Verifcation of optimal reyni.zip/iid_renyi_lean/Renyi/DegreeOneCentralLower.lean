import Renyi.DegreeOneLowerBounds

/-! The genuine degree-one completion in the central overlap certificate. -/
noncomputable section
namespace Renyi.DegreeOneCompletion

/-- The two actual sharp endpoint profiles have the required reverse product in the central interval. -/
theorem coupledProfiles_central_product_lower {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z lam0 M fL f ω x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hlam0 : 0<lam0)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hZ : x≤γ) (hY : (N:ℝ)^2*y≤1-γ)
    (hcap : lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤(x)*((N:ℝ)^2*y)) :
    z*Real.exp (-(2*M+1+degreeOneLocalLowerConstant fL+coupledLocalLowerConstant f-Real.log lam0)*(γ*(1-γ)))≤
      (Real.exp (-M*γ)*lowProfile ℓ γ fL x)^(1-γ)*
        (Real.exp (-(M+1)*(1-γ))*highProfile N (1-γ) f ω y)^γ := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hh : 0<γ*(1-γ) := mul_pos hγ hd
  have hlow := mul_le_mul_of_nonneg_left (lowProfile_local_exponential_lower hℓ hγ hγ1.le hfL hfL1 hx hx1 hZ)
    (Real.exp_pos (-M*γ)).le
  have hhigh := mul_le_mul_of_nonneg_left (highProfile_local_exponential_lower hN hd (by linarith only [hγ]) hf hf1 hω hω1 hy hy1 hY)
    (Real.exp_pos (-(M+1)*(1-γ))).le
  have hLid : Real.exp (-M*γ)*(Real.exp (-degreeOneLocalLowerConstant fL*γ)*((x)/γ)^γ)=
      Real.exp (-(M+degreeOneLocalLowerConstant fL)*γ)*((x)/γ)^γ := by
    rw [←mul_assoc,←Real.exp_add]
    congr 2
    ring
  have hRid : Real.exp (-(M+1)*(1-γ))*(Real.exp (-coupledLocalLowerConstant f*(1-γ))*(((N:ℝ)^2*y)/(1-γ))^(1-γ))=
      Real.exp (-(M+1+coupledLocalLowerConstant f)*(1-γ))*(((N:ℝ)^2*y)/(1-γ))^(1-γ) := by
    rw [←mul_assoc,←Real.exp_add]
    congr 2
    ring
  rw [hLid] at hlow
  rw [hRid] at hhigh
  have hu0 := (lowProfile_range (by omega : 0<ℓ) hγ hfL hfL1 hx hx1).1
  have hp := mul_le_mul (Real.rpow_le_rpow (by positivity) hlow hd.le)
    (Real.rpow_le_rpow (by positivity) hhigh hγ.le) (by positivity) (by positivity)
  rw [coupled_lower_power_identity hγ hγ1 (by positivity) (by positivity)] at hp
  have hq : lam0*z^(1/(γ*(1-γ)))≤((x)*((N:ℝ)^2*y))/(γ*(1-γ)) := by
    apply (le_div_iff₀ hh).mpr
    nlinarith only [hcap]
  have hraise := Real.rpow_le_rpow (by positivity) hq hh.le
  have hid : (lam0*z^(1/(γ*(1-γ))))^(γ*(1-γ))=Real.exp (Real.log lam0*(γ*(1-γ)))*z := by
    rw [Real.mul_rpow hlam0.le (Real.rpow_nonneg hz.le _),←Real.rpow_mul hz.le,
      one_div_mul_cancel hh.ne',Real.rpow_one,Real.rpow_def_of_pos hlam0]
  rw [hid] at hraise
  have hm := mul_le_mul_of_nonneg_left hraise
    (Real.exp_pos (-(M+degreeOneLocalLowerConstant fL+(M+1+coupledLocalLowerConstant f))*(γ*(1-γ)))).le
  have heq : Real.exp (-(M+degreeOneLocalLowerConstant fL+(M+1+coupledLocalLowerConstant f))*(γ*(1-γ)))*
      (Real.exp (Real.log lam0*(γ*(1-γ)))*z)=
      z*Real.exp (-(2*M+1+degreeOneLocalLowerConstant fL+coupledLocalLowerConstant f-Real.log lam0)*(γ*(1-γ))) := by
    rw [←mul_assoc,←Real.exp_add,mul_comm]
    congr 2
    ring
  rw [heq] at hm
  exact hm.trans hp

def coupledCentralLoss (fL f M lam0 : ℝ) : ℝ :=
  2*M+1+degreeOneLocalLowerConstant fL+coupledLocalLowerConstant f-Real.log lam0

def coupledReservedBase (ℓ N : ℕ) (γ z M fL f ω x y : ℝ) : ℝ :=
  (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ fL x+
    (overlapB γ z*Real.exp (-(M+1)*(1-γ)))*highProfile N (1-γ) f ω y

/-- The actual reserved two-arm base has its central overlap lower bound. -/
theorem coupledProfiles_central_base_lower {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z lam0 M fL f ω x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1) (hlam0 : 0<lam0)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hZ : x≤γ) (hY : (N:ℝ)^2*y≤1-γ)
    (hcap : lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤(x)*((N:ℝ)^2*y)) :
    overlapG γ z*Real.exp (-coupledCentralLoss fL f M lam0*(γ*(1-γ)))≤
      coupledReservedBase ℓ N γ z M fL f ω x y := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hprod := coupledProfiles_central_product_lower (M:=M) hℓ hN hγ hγ1 hz hlam0 hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hZ hY hcap
  have hu0 := (lowProfile_range (by omega : 0<ℓ) hγ hfL hfL1 hx hx1).1
  have hv0 := (highProfile_range (by omega : 0<N) hd hf hf1.le hω hω1 hy hy1).1
  have h := overlap_approximate_lower_bound
    (D:=coupledCentralLoss fL f M lam0*(γ*(1-γ))) hγ hγ1 hz hz1
    (mul_nonneg (Real.exp_pos (-M*γ)).le hu0)
    (mul_nonneg (Real.exp_pos (-(M+1)*(1-γ))).le hv0)
    (by simpa only [coupledCentralLoss,neg_mul] using hprod)
  unfold coupledReservedBase
  simpa only [neg_mul,mul_assoc] using h


end Renyi.DegreeOneCompletion
