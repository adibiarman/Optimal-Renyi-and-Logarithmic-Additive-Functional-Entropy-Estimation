import Renyi.Foundations

/-!
# Finite-observation testing inequalities

For a fixed number of samples on a finite alphabet, the observation space
is finite. A test may be randomized: `t x` is its probability of choosing
the second hypothesis after observing `x`.
-/

noncomputable section
open scoped BigOperators

namespace Renyi

/-- Half the L1 distance between probability masses. -/
def finiteTV {Ω : Type*} [Fintype Ω] (p q : Ω → ℝ) : ℝ :=
  (∑ x, |p x - q x|) / 2

/-- A pointwise inequality for an arbitrary randomized decision. -/
theorem testing_pointwise (p q t : ℝ) (ht0 : 0 ≤ t) (ht1 : t ≤ 1) :
    (p + q - |p - q|) / 2 ≤ p * t + q * (1 - t) := by
  by_cases hpq : p ≤ q
  · rw [abs_of_nonpos (sub_nonpos.mpr hpq)]
    nlinarith [mul_nonneg (sub_nonneg.mpr hpq) (sub_nonneg.mpr ht1)]
  · rw [abs_of_nonneg (sub_nonneg.mpr (le_of_not_ge hpq))]
    nlinarith [mul_nonneg (sub_nonneg.mpr (le_of_not_ge hpq)) ht0]

/-- Every randomized test has sum of errors at least `1 - TV`.
The hypotheses are exact probability normalization, not a lower-bound
certificate assumed from the manuscript. -/
theorem finite_testing_lower_bound {Ω : Type*} [Fintype Ω]
    (p q t : Ω → ℝ)
    (hp : ∑ x, p x = 1) (hq : ∑ x, q x = 1)
    (ht0 : ∀ x, 0 ≤ t x) (ht1 : ∀ x, t x ≤ 1) :
    1 - finiteTV p q ≤ ∑ x, (p x * t x + q x * (1 - t x)) := by
  have h := Finset.sum_le_sum (s := Finset.univ)
    (fun x _ => testing_pointwise (p x) (q x) (t x) (ht0 x) (ht1 x))
  simp only [← Finset.sum_div, Finset.sum_sub_distrib,
    Finset.sum_add_distrib, hp, hq] at h
  unfold finiteTV
  rw [Finset.sum_add_distrib]
  linarith

/-- At total variation at most 1/4, average testing error is at least 3/8. -/
theorem finite_testing_three_eighths {Ω : Type*} [Fintype Ω]
    (p q t : Ω → ℝ)
    (hp : ∑ x, p x = 1) (hq : ∑ x, q x = 1)
    (ht0 : ∀ x, 0 ≤ t x) (ht1 : ∀ x, t x ≤ 1)
    (hTV : finiteTV p q ≤ 1 / 4) :
    3 / 8 ≤ (∑ x, (p x * t x + q x * (1 - t x))) / 2 := by
  have h := finite_testing_lower_bound p q t hp hq ht0 ht1
  linarith

/-- An accurate estimate near the lower center lies below the midpoint. -/
theorem separated_intervals_left {c₀ c₁ ε z : ℝ}
    (hgap : 2 * ε < c₁ - c₀) (hz : |z - c₀| ≤ ε) :
    z < (c₀ + c₁) / 2 := by
  rcases abs_le.mp hz with ⟨_, hu⟩
  linarith

/-- An accurate estimate near the upper center lies above the midpoint. -/
theorem separated_intervals_right {c₀ c₁ ε z : ℝ}
    (hgap : 2 * ε < c₁ - c₀) (hz : |z - c₁| ≤ ε) :
    (c₀ + c₁) / 2 < z := by
  rcases abs_le.mp hz with ⟨hl, _⟩
  linarith

/-- The normalization reserves leave the two entropy accuracy intervals disjoint. -/
theorem normalization_preserves_separation {β ε m c₀ c₁ H₀ H₁ : ℝ}
    (hβ : 0 < β) (hm : 0 < m)
    (hgap : 2 * ε + m / β ≤ c₁ - c₀)
    (h₀ : |H₀ - c₀| ≤ m / (4 * β))
    (h₁ : |H₁ - c₁| ≤ m / (4 * β)) :
    2 * ε < H₁ - H₀ := by
  rcases abs_le.mp h₀ with ⟨_, h₀u⟩
  rcases abs_le.mp h₁ with ⟨h₁l, _⟩
  have hpos : 0 < m / β := div_pos hm hβ
  have hquarter : m / (4 * β) = (m / β) / 4 := by ring
  rw [hquarter] at h₀u h₁l
  linarith

/-- Algebraic inequality used to bound the fingerprint distance. -/
theorem squared_remainder_bound {a R q : ℝ}
    (hq : 0 < q) (h : |a + R| ≤ q) :
    (a + R) ^ 2 / q ≤ 2 * a ^ 2 / q + 2 * |R| := by
  by_cases hR : |R| ≤ q
  · have hR2 : R ^ 2 ≤ |R| * q := by
      have := mul_le_mul_of_nonneg_left hR (abs_nonneg R)
      nlinarith [sq_abs R]
    apply (div_le_iff₀ hq).2
    have hrewrite : (2 * a ^ 2 / q + 2 * |R|) * q =
        2 * a ^ 2 + 2 * |R| * q := by field_simp
    rw [hrewrite]
    nlinarith [sq_nonneg (a - R)]
  · have hsq : (a + R) ^ 2 ≤ q ^ 2 := by
      nlinarith [sq_abs (a + R), abs_nonneg (a + R)]
    have hdiv : (a + R) ^ 2 / q ≤ q := (div_le_iff₀ hq).2 (by nlinarith)
    have ha : 0 ≤ 2 * a ^ 2 / q := by positivity
    linarith

end Renyi
