import Renyi.LowerCalibrationFinal
import Renyi.EndpointLower

/-! Exhaustive real-order branches for the uniform iid lower theorem. -/
noncomputable section
namespace Renyi

/-- The infimum defining the scalar multiplier is always nonnegative. -/
theorem rootMultiplier_nonneg (k : ℕ) (alpha eps : ℝ) : 0≤rootMultiplier k alpha eps := by
  unfold rootMultiplier
  dsimp only
  exact Real.sInf_nonneg (fun x hx => zero_le_one.trans hx.1)

/-- The public rate is nonnegative in the positive-order, nonnegative-log regime. -/
theorem rate_nonneg {k : ℕ} {alpha eps : ℝ} (ha : 0<alpha) (hk : 1≤k) : 0≤rate k alpha eps := by
  have hkR : (1:ℝ)≤k := by exact_mod_cast hk
  unfold rate extendedMultiplier
  split_ifs
  · exact mul_nonneg (mul_nonneg ha.le (Real.rpow_nonneg (Nat.cast_nonneg _) _))
      (mul_nonneg (div_nonneg (Real.log_nonneg hkR) ha.le) (Real.rpow_nonneg (Nat.cast_nonneg _) _))
  · exact mul_nonneg (mul_nonneg ha.le (Real.rpow_nonneg (Nat.cast_nonneg _) _))
      (zero_le_one.trans (le_max_left _ _))
  · exact mul_nonneg (mul_nonneg ha.le (Real.rpow_nonneg (Nat.cast_nonneg _) _)) (rootMultiplier_nonneg _ _ _)

/-- Every noninteger order above three halves has exactly one of the two
positive-degree nearest-integer representations used by the construction. -/
theorem positive_degree_order_decomposition {alpha : ℝ}
    (ha : 3/2<alpha) (hn : ¬∃r:ℕ,alpha=(r:ℝ)) :
    (∃ r:ℕ, ∃ s:ℝ, 2≤r ∧ 0<s ∧ s≤1/2 ∧ alpha=(r:ℝ)+s) ∨
    (∃ m:ℕ, ∃ s:ℝ, 1≤m ∧ 0<s ∧ s≤1/2 ∧ alpha=(m:ℝ)+(1-s)) := by
  let r := Nat.floor alpha
  let g := fractionalPart alpha
  have ha0 : 0≤alpha := by linarith
  have hcast : (r:ℝ)=(⌊alpha⌋:ℤ) := natCast_floor_eq_intCast_floor ha0
  have hg0 : 0≤g := Int.fract_nonneg alpha
  have hg1 : g<1 := Int.fract_lt_one alpha
  have heq : alpha=(r:ℝ)+g := by
    change alpha=(r:ℝ)+Int.fract alpha
    rw [hcast]
    exact (Int.floor_add_fract alpha).symm
  have hg : 0<g := by
    by_contra h
    have hgzero : g=0 := by linarith
    apply hn
    exact ⟨r,by rw [heq,hgzero,add_zero]⟩
  by_cases hsmall : g≤1/2
  · have hr : 2≤r := by
      have hh : (1:ℝ)<r := by linarith
      have hnat : 1<r := by exact_mod_cast hh
      omega
    exact Or.inl ⟨r,g,hr,hg,hsmall,heq⟩
  · have hr : 1≤r := by
      have hh : (0:ℝ)<r := by linarith
      have hnat : 0<r := by exact_mod_cast hh
      omega
    exact Or.inr ⟨r,1-g,hr,by linarith,by linarith,by rw [heq]; ring⟩

/-- Below the saturation threshold the public noninteger rate is exactly
its root expression. -/
theorem rate_noninteger_low {k : ℕ} {alpha eps : ℝ}
    (hlow : alpha<Real.log k) (hn : ¬∃r:ℕ,alpha=(r:ℝ)) :
    rate k alpha eps=alpha*(k:ℝ)^(1-1/alpha)*rootMultiplier k alpha eps := by
  unfold rate extendedMultiplier
  rw [if_neg (not_le.mpr hlow),if_neg hn]

end Renyi
