import Renyi.NearOneVariance

/-! Summation of the actual near-one Gamma variance over a probability vector. -/
set_option maxHeartbeats 700000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def nearOneGammaLowBudget (Cw xi : ℝ) : ℝ :=
  (6 : ℝ) ^ (6 : ℕ) * Real.exp (Real.exp 1 - 1) * gammaResidualPilotConstant Cw ^ 2 *
    (1 + |Real.log xi|) ^ 2

def nearOneGammaAggregateConstant (Cw : ℝ) : ℝ := 2 * orderOneNoiseConstant + 2 * Cw ^ 2

theorem near_one_gamma_envelope_bound {n t beta Cw : ℝ} (hn : 0 < n) (ht : 0 < t)
    (hnt : n * t ≤ 1) (lam : ℝ≥0) (hlamn : (lam : ℝ) ≤ n) :
    nearOneGammaVarianceEnvelope beta (n * t) Cw lam ≤
      nearOneGammaLowBudget Cw (n * t) +
        nearOneGammaAggregateConstant Cw * (1 + (Real.log (1 / t)) ^ 2) *
          ((lam : ℝ) ^ (1 + 2 * beta) + (n * t) ^ (2 * beta) * (lam : ℝ)) := by
  have hCnoise : 0 ≤ orderOneNoiseConstant := by unfold orderOneNoiseConstant; positivity
  have hlow0 : 0 ≤ nearOneGammaLowBudget Cw (n * t) := by unfold nearOneGammaLowBudget; positivity
  have hagg0 : 0 ≤ nearOneGammaAggregateConstant Cw := by unfold nearOneGammaAggregateConstant; positivity
  have hntr : 0 < n * t := mul_pos hn ht
  by_cases hlam : 1 ≤ (lam : ℝ)
  · have hlam0 : 0 < (lam : ℝ) := by linarith
    have hratio1 : 1 ≤ (lam : ℝ) / (n * t) := (one_le_div hntr).2 (hnt.trans hlam)
    have hratio : (lam : ℝ) / (n * t) ≤ 1 / t := by
      apply (div_le_div_iff₀ hntr ht).2
      nlinarith only [mul_le_mul_of_nonneg_right hlamn ht.le]
    have hlog0 : 0 ≤ Real.log ((lam : ℝ) / (n * t)) := Real.log_nonneg hratio1
    have hlog := Real.log_le_log (div_pos hlam0 hntr) hratio
    have hlogSq : 1 + (Real.log ((lam : ℝ) / (n * t))) ^ 2 ≤ 1 + (Real.log (1 / t)) ^ 2 := by
      nlinarith only [hlog0, hlog]
    have hp : (lam : ℝ) ^ (1 + 2 * beta) = (lam : ℝ) * (lam : ℝ) ^ (2 * beta) := by
      rw [Real.rpow_add hlam0, Real.rpow_one]
    have hm := mul_le_mul_of_nonneg_left hlogSq
      (by positivity : 0 ≤ 2 * orderOneNoiseConstant * (lam : ℝ) *
        ((lam : ℝ) ^ (2 * beta) + (n * t) ^ (2 * beta)))
    have hsecond := mul_le_mul_of_nonneg_left
      (show (1 : ℝ) ≤ 1 + (Real.log (1 / t)) ^ 2 by nlinarith [sq_nonneg (Real.log (1 / t))])
      (by positivity : 0 ≤ 2 * Cw ^ 2 * (n * t) ^ (2 * beta) * (lam : ℝ))
    have hextra : 0 ≤ 2 * Cw ^ 2 * (1 + (Real.log (1 / t)) ^ 2) * (lam : ℝ) ^ (1 + 2 * beta) := by positivity
    simp only [nearOneGammaVarianceEnvelope, if_pos hlam, nearOneGammaAggregateConstant]
    rw [hp] at hextra ⊢
    nlinarith only [hm, hsecond, hextra, hlow0]
  · simp only [nearOneGammaVarianceEnvelope, if_neg hlam, nearOneGammaLowBudget]
    have hhigh0 : 0 ≤ nearOneGammaAggregateConstant Cw * (1 + (Real.log (1 / t)) ^ 2) *
        ((lam : ℝ) ^ (1 + 2 * beta) + (n * t) ^ (2 * beta) * (lam : ℝ)) := by positivity
    linarith

theorem near_one_gamma_envelope_sum {iota : Type*} [Fintype iota]
    {n t beta Cw : ℝ} (hn : 0 < n) (ht : 0 < t) (hnt : n * t ≤ 1)
    (lam : iota → ℝ≥0) (hsum : ∑ i, (lam i : ℝ) = n) :
    (∑ i, nearOneGammaVarianceEnvelope beta (n * t) Cw (lam i)) ≤
      (Fintype.card iota : ℝ) * nearOneGammaLowBudget Cw (n * t) +
        nearOneGammaAggregateConstant Cw * (1 + (Real.log (1 / t)) ^ 2) *
          ((∑ i, (lam i : ℝ) ^ (1 + 2 * beta)) + (n * t) ^ (2 * beta) * n) := by
  have hterm (i : iota) := near_one_gamma_envelope_bound (beta := beta) (Cw := Cw) hn ht hnt (lam i)
    (show (lam i : ℝ) ≤ n by
      rw [← hsum]
      exact Finset.single_le_sum (fun j _ => (lam j).coe_nonneg) (Finset.mem_univ i))
  have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ => hterm i)
  convert h using 1
  simp only [Finset.sum_add_distrib, Finset.sum_const, Finset.card_univ, nsmul_eq_mul,
    ← Finset.mul_sum, hsum]

theorem near_one_gamma_scale_identity {n t beta : ℝ} (hn : 0 < n) (ht : 0 < t) :
    n ^ (-2 * (1 + beta)) * ((n * t) ^ (2 * beta) * n) = t ^ (2 * beta) / n := by
  rw [Real.mul_rpow hn.le ht.le]
  have hp : n ^ (-2 * (1 + beta)) * n ^ (2 * beta) * n = 1 / n := by
    rw [← Real.rpow_add hn, show -2 * (1 + beta) + 2 * beta = -2 by ring]
    rw [Real.rpow_neg hn.le, Real.rpow_two]
    field_simp
  calc
    n ^ (-2 * (1 + beta)) * (n ^ (2 * beta) * t ^ (2 * beta) * n) =
      (n ^ (-2 * (1 + beta)) * n ^ (2 * beta) * n) * t ^ (2 * beta) := by ring
    _ = _ := by rw [hp]; ring

end Renyi
