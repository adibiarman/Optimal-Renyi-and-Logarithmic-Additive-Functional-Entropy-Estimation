import Renyi.Testing

/-!
# Deterministic normalization of the lower-bound priors

This proves the analytic error estimate in `unif:lem:normalization`.
The probability bound for the normalization event is a separate obligation.
-/

noncomputable section
namespace Renyi

/-- A quantitative logarithm bound in a neighborhood of one. -/
theorem abs_log_near_one {x r : ℝ} (_hr0 : 0 ≤ r) (hr1 : r < 1)
    (hx : |x - 1| ≤ r) : |Real.log x| ≤ r / (1 - r) := by
  rcases abs_le.mp hx with ⟨hxl, hxu⟩
  have hxpos : 0 < x := by linarith
  have hden : 0 < 1 - r := by linarith
  have hi : 1 / x ≤ 1 / (1 - r) :=
    one_div_le_one_div_of_le hden (by linarith)
  have hid : 1 - 1 / (1 - r) = -(r / (1 - r)) := by
    field_simp
    ring
  have hlo := Real.one_sub_inv_le_log_of_pos hxpos
  have hhi := Real.log_le_sub_one_of_pos hxpos
  have hr : r ≤ r / (1 - r) := by
    apply (le_div_iff₀ hden).2
    nlinarith [sq_nonneg r]
  rw [abs_le]
  simp only [one_div] at hi hid
  constructor <;> linarith

/-- On the quarter-neighborhood, the logarithm costs a factor of at most 4/3. -/
theorem abs_log_quarter {x t : ℝ} (ht0 : 0 ≤ t) (ht1 : t ≤ 1 / 4)
    (hx : |x - 1| ≤ t) : |Real.log x| ≤ (4 / 3) * t := by
  have h := abs_log_near_one ht0 (by linarith) hx
  have hr : t / (1 - t) ≤ (4 / 3) * t := by
    apply (div_le_iff₀ (by linarith : 0 < 1 - t)).2
    nlinarith [mul_nonneg ht0 (sub_nonneg.mpr ht1)]
  exact h.trans hr

/-- The two deterministic normalization errors fit inside the stated budget.
Here `W` is the centered affine residual `V - A*S`. -/
theorem normalization_log_error {β m A S W : ℝ}
    (hβ : 0 < β) (hm : 0 < m) (hm1 : m ≤ 1) (hA : 0 < A)
    (hS : |S - 1| ≤ min (1 / 4) (m / (16 * β)))
    (hW : |W| ≤ A * (m / 16)) :
    |β * Real.log S - Real.log (1 + W / (A * S))| < m / 4 := by
  let t : ℝ := min (1 / 4) (m / (16 * β))
  have ht0 : 0 ≤ t := le_min (by norm_num) (by positivity)
  have ht1 : t ≤ 1 / 4 := min_le_left _ _
  have ht2 : t ≤ m / (16 * β) := min_le_right _ _
  have hS' : |S - 1| ≤ t := hS
  have hSlow : 3 / 4 ≤ S := by
    have := (abs_le.mp hS').1
    linarith
  have hSpos : 0 < S := by linarith
  have htprod : β * t ≤ m / 16 := by
    have := (le_div_iff₀ (by positivity : 0 < 16 * β)).mp ht2
    nlinarith
  have hlogS := abs_log_quarter ht0 ht1 hS'
  have hfirst : |β * Real.log S| ≤ m / 12 := by
    rw [abs_mul, abs_of_pos hβ]
    have := mul_le_mul_of_nonneg_left hlogS hβ.le
    nlinarith
  have hratio : |W / (A * S)| ≤ m / 12 := by
    rw [abs_div, abs_of_pos (mul_pos hA hSpos)]
    apply (div_le_iff₀ (mul_pos hA hSpos)).2
    have := mul_le_mul_of_nonneg_left hSlow (mul_nonneg hm.le hA.le)
    nlinarith
  have hlog := abs_log_near_one (by positivity : 0 ≤ m / 12)
    (by linarith : m / 12 < 1)
    (show |(1 + W / (A * S)) - 1| ≤ m / 12 by simpa using hratio)
  have hfrac : (m / 12) / (1 - m / 12) ≤ m / 11 := by
    apply (div_le_iff₀ (by linarith : 0 < 1 - m / 12)).2
    nlinarith [mul_nonneg hm.le (sub_nonneg.mpr hm1)]
  calc
    |β * Real.log S - Real.log (1 + W / (A * S))| ≤
        |β * Real.log S| + |Real.log (1 + W / (A * S))| := abs_sub _ _
    _ ≤ m / 12 + m / 11 := add_le_add hfirst (hlog.trans hfrac)
    _ < m / 4 := normalization_budget hm

/-- The actual entropy is within the paper's strict normalization reserve. -/
theorem normalization_entropy_error {α b m A S V : ℝ}
    (hα : 1 < α) (hb : 0 < b) (hm : 0 < m) (hm1 : m ≤ 1)
    (hA : 0 < A) (hSpos : 0 < S) (hV : 0 < V)
    (hS : |S - 1| ≤ min (1 / 4) (m / (16 * (α - 1))))
    (hW : |V - A * S| ≤ A * (m / 16)) :
    |entropyFromPower (α - 1) (b ^ (1 - α) * V / S ^ α) -
      (Real.log b - Real.log A / (α - 1))| < m / (4 * (α - 1)) := by
  have hβ : 0 < α - 1 := sub_pos.mpr hα
  have h := normalization_log_error hβ hm hm1 hA hS hW
  rw [← normalization_identity hα hb hSpos hA hV,
    abs_mul, abs_of_pos hβ] at h
  apply (lt_div_iff₀ (by positivity : 0 < 4 * (α - 1))).2
  nlinarith

end Renyi
