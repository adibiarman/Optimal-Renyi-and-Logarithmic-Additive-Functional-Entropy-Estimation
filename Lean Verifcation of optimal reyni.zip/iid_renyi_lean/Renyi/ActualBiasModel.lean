import Renyi.ActualPowerSumLower
import Renyi.UpperRescaling

/-! The one corrected oracle mean and its explicit deterministic error budget. -/
noncomputable section
namespace Renyi

/-- The known below-cutoff baseline multiplied by the uniform power sum. -/
def actualCutoffBudget (k : ℕ) (alpha eps Ch D cb lambda CL cL C0 d : ℝ) : ℝ :=
  upperActualBaseline k alpha C0 d (upperA k alpha eps Ch D cb lambda CL cL)*(k:ℝ)^(1-alpha)

/-- The margin used by both statistical endpoint tests. -/
def actualBiasBudget {k : ℕ} (p : Simplex k)
    (alpha eps Ch D cb lambda CL cL C0 d u0 : ℝ) : ℝ :=
  actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d+
    upperKappa alpha eps*upperU k alpha eps u0*powerSum p alpha+
      min (alpha-1) 1*upperKappa alpha eps*actualForwardBonus p alpha eps D cb CL cL

/-- The actual oracle mean uses the same rescaling and correction at every order. -/
def actualCorrectedOracleMean {k : ℕ} (p : Simplex k) (light : Fin k→Bool)
    (alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d : ℝ) : ℝ :=
  upperRescaling k alpha eps cu u0*
    actualCoupledHybridMean p light alpha eps Ch D cb lambda CL cL fL f M+
      2*actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d

end Renyi
