import Renyi.CoupledProfileFloors
import Renyi.CoupledUpperGap

/-! Fixed raised floors for the actual normalized primitive. -/
noncomputable section
namespace Renyi

def endpointProfileFloorOrder (q : ℝ) : ℝ :=
  min 1 (min ((-Real.log q/8)^2) (-Real.log q/(2*(Real.log 12+2))))

def endpointProfileFloorTail (q : ℝ) : ℝ := max 1 (endpointTailDefectConstant/(1-q))

def endpointProfileFloorScale (q : ℝ) : ℝ :=
  max 1 (endpointProfileFloorTail q/endpointProfileFloorOrder q)

theorem endpointProfileFloorOrder_pos {q : ℝ} (hq : 0<q) (hq1 : q<1) :
    0<endpointProfileFloorOrder q := by
  have hlog : 0< -Real.log q := neg_pos.mpr (Real.log_neg hq hq1)
  have hC : 0<Real.log 12+2 := by have hl := Real.log_nonneg (by norm_num : (1:ℝ)≤12);linarith only [hl]
  unfold endpointProfileFloorOrder
  positivity

lemma endpointProfile_small_order_floor {N : ℕ} (hN : 0<N) {s q x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hq : 0<q) (hq1 : q<1)
    (_hx : 0≤x) (hx1 : x≤1) (hsmall : s≤endpointProfileFloorOrder q)
    (hY : s≤(N:ℝ)^2*x) : q≤endpointProfile N 6 s x := by
  let E := -Real.log q
  let C := Real.log 12+2
  have hE : 0<E := neg_pos.mpr (Real.log_neg hq hq1)
  have hC : 0<C := by have hl := Real.log_nonneg (by norm_num : (1:ℝ)≤12);dsimp [C];linarith only [hl]
  have hsq : s≤(E/8)^2 := hsmall.trans ((min_le_right _ _).trans (min_le_left _ _))
  have hroot : 8*Real.sqrt s≤E := by
    have hsqrt := (Real.sqrt_le_left (show 0≤E/8 by positivity)).mpr hsq
    linarith only [hsqrt]
  have hlog : 4*s*(-Real.log 1)≤E := by simpa using hE.le
  have hpower := small_order_scaled_power_lower hs (by norm_num : (0:ℝ)<1) hroot hlog
  simp only [one_mul] at hpower
  have hscale : s≤E/(2*C) := hsmall.trans ((min_le_right _ _).trans (min_le_right _ _))
  have hmul := (le_div_iff₀ (show 0<2*C by positivity)).mp hscale
  have he : Real.exp (-E/2)≤Real.exp (-C*s) := Real.exp_le_exp.mpr (by nlinarith only [hmul])
  have heq : Real.exp (-E/2)*Real.exp (-E/2)=q := by
    rw [←Real.exp_add,show -E/2+-E/2=Real.log q by dsimp [E];ring,Real.exp_log hq]
  by_cases hy1 : (N:ℝ)^2*x≤1
  · have hxpos : 0<x := by
      by_contra hn
      have hm := mul_nonpos_of_nonneg_of_nonpos (sq_nonneg (N:ℝ)) (le_of_not_gt hn)
      nlinarith only [hm,hY,hs]
    have hJ := endpointProfile_lower_power hN (by norm_num : 2≤6) (by norm_num : 6≤6) hs hs1 hxpos hx1 hy1
    have hys := Real.rpow_le_rpow hs.le hY hs.le
    have hm := mul_le_mul he (hpower.trans hys) (Real.exp_pos (-E/2)).le (Real.exp_pos (-C*s)).le
    rw [heq] at hm
    exact hm.trans hJ
  · have hxpos : 0<x := by
      by_contra hn
      have hm := mul_nonpos_of_nonneg_of_nonpos (sq_nonneg (N:ℝ)) (le_of_not_gt hn)
      nlinarith only [hm,hY,hs]
    have hJ := endpointProfile_floor hN (by norm_num : 2≤6) (by norm_num : 6≤6) hs hs1 hxpos hx1 (le_of_lt (lt_of_not_ge hy1))
    have he' : Real.exp (-E)≤Real.exp (-C*s) := (Real.exp_le_exp.mpr (by linarith only [hE] : -E≤-E/2)).trans he
    have heq' : Real.exp (-E)=q := by dsimp [E];rw [neg_neg,Real.exp_log hq]
    rw [heq'] at he'
    exact he'.trans hJ

/-- Actual J_s exceeds every fixed q<1 after a fixed multiple of the s-scale, uniformly in N,s. -/
theorem endpointProfile_raised_floor {N : ℕ} (hN : 0<N) {s q x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hq : 0<q) (hq1 : q<1)
    (hx : 0≤x) (hx1 : x≤1) (hY : endpointProfileFloorScale q*s≤(N:ℝ)^2*x) :
    q≤endpointProfile N 6 s x := by
  have horder := endpointProfileFloorOrder_pos hq hq1
  have hYpos : 0<(N:ℝ)^2*x := by
    have hss : s≤endpointProfileFloorScale q*s := by
      exact (by simpa only [one_mul] using mul_le_mul_of_nonneg_right (le_max_left (1:ℝ) _) hs.le)
    exact hs.trans_le (hss.trans hY)
  have hxpos : 0<x := by
    by_contra hn
    have hm := mul_nonpos_of_nonneg_of_nonpos (sq_nonneg (N:ℝ)) (le_of_not_gt hn)
    linarith only [hm,hYpos]
  by_cases hsmall : s≤endpointProfileFloorOrder q
  · apply endpointProfile_small_order_floor hN hs hs1 hq hq1 hx hx1 hsmall
    have hss : s≤endpointProfileFloorScale q*s := by
      simpa only [one_mul] using mul_le_mul_of_nonneg_right (le_max_left (1:ℝ) _) hs.le
    exact hss.trans hY
  · have hscale : endpointProfileFloorTail q≤(N:ℝ)^2*x := by
      have hbase : endpointProfileFloorTail q/endpointProfileFloorOrder q≤endpointProfileFloorScale q := le_max_right _ _
      have htailpos : 0≤endpointProfileFloorTail q := zero_le_one.trans (le_max_left _ _)
      have hm := mul_le_mul_of_nonneg_right hbase hs.le
      have hsorder : (1:ℝ)≤s/endpointProfileFloorOrder q := (le_div_iff₀ horder).mpr
        (by simpa only [one_mul] using (lt_of_not_ge hsmall).le)
      have htail := mul_le_mul_of_nonneg_left hsorder htailpos
      have hid : endpointProfileFloorTail q*(s/endpointProfileFloorOrder q)=
        (endpointProfileFloorTail q/endpointProfileFloorOrder q)*s := by ring
      rw [hid] at htail
      simpa only [mul_one] using htail.trans (hm.trans hY)
    have hunit : 1≤(N:ℝ)^2*x := (le_max_left _ _).trans hscale
    have htail := endpoint_sum_tail_defect hN (by norm_num : 2≤6) (by norm_num : 6≤6) hs hs1 hxpos hx1 hunit
    have hbudget : endpointTailDefectConstant/((N:ℝ)^2*x)≤1-q := by
      apply (div_le_iff₀ hYpos).mpr
      have hscale' : endpointTailDefectConstant/(1-q)≤(N:ℝ)^2*x := (le_max_right _ _).trans hscale
      have hm := (div_le_iff₀ (show 0<1-q by linarith only [hq1])).mp hscale'
      nlinarith only [hm]
    have hK := endpointKernel_nonneg N 6 x
    linarith only [htail,hbudget,hK]

end Renyi
