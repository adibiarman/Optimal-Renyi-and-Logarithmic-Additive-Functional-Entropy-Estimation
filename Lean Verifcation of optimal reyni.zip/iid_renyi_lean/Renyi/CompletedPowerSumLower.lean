import Renyi.CompletedGlobalLower
import Renyi.CompletedBelowCutoff

/-! Actual finite-sum lower certificate for arbitrary pilot assignments. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- The source capacity product does not depend on the evaluation coordinate. -/
lemma coupled_scaled_product_identity {ℓ N : ℕ} {a b p : ℝ} (hp : 0<p) (hb : 0<b) :
    ((ℓ:ℝ)^2*(a/p))*((N:ℝ)^2*(p/b))=((ℓ:ℝ)^2*(N:ℝ)^2)*(a/b) := by
  field_simp

/-- The complete actual lower certificate retains the forward margin even on heavy
coordinates. The only aggregate loss is the proved contribution below the cutoff. -/
theorem completedCoupledPolynomial_power_sum_lower {fL f qL qH Emin ν M lam0 : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hEmin : 0<Emin) (hν : 0<ν) (hM : 1≤M) (hlam0 : 0<lam0) (hlam1 : lam0≤1)
    (hqL : Real.exp (-Emin)<qL) (hqLf : qL<fL)
    (hqH : Real.exp (-7*Emin/8)<qH) (hqHf : qH<f) :
    ∃ C c : ℝ, 0≤C ∧ 0<c ∧
      ∀ (k ℓ N m : ℕ) (γ z E a b : ℝ) (p : Fin k→ℝ) (light : Fin k→Bool),
        0<ℓ → 2≤N → 1≤m → 4*(ℓ-1)≤m → 0<γ → γ<1 → 0<z → z<1 →
        Emin≤E → overlapG γ z=Real.exp (-E) → ν*((ℓ:ℝ)-1)≤E →
        0<a → a≤b → (∀ i, 0≤p i) → (∀ i, light i=true → p i≤b) →
        lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤((ℓ:ℝ)^2*(N:ℝ)^2)*(a/b) →
        ((ℓ:ℝ)^2*(N:ℝ)^2)*(a/b)≤
          Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) →
        let Q := completedCoupledPolynomial ℓ N m γ a b (DegreeOneCompletion.coefficient γ fL) fL f
          (overlapA γ z*Real.exp (-M*γ)) (overlapB γ z*Real.exp (-M*(1-γ))) (Real.exp (-E/8))
        Real.exp (-E)*Real.exp (-C*(γ*(1-γ)))*(∑ i, (p i)^((m:ℝ)+γ))+
          c*Real.exp (-E)*(∑ i, if a≤p i then
            (p i)^((m:ℝ)+γ)*min ((N:ℝ)^2*(p i/b)) 1 else 0)≤
          (∑ i, if light i then Q.eval (p i) else Real.exp (-E/8)*(p i)^((m:ℝ)+γ))+
            (k:ℝ)*(100:ℝ)^(m+1)*a^((m:ℝ)+γ) := by
  obtain ⟨C,c,hC,hc,hlower⟩ := completedCoupledPolynomial_global_lower
    hfL hfL1 hf hf1 hEmin hν hM hlam0 hlam1 hqL hqLf hqH hqHf
  let cH := Real.exp (7*Emin/8)-1
  have hcH : 0<cH := by dsimp [cH]; exact sub_pos.mpr (Real.one_lt_exp_iff.mpr (by positivity))
  refine ⟨C,min c cH,hC,lt_min hc hcH,?_⟩
  intro k ℓ N m γ z E a b p light hℓ hN hm hdegree hγ hγ1 hz hz1 hEE hG henergy ha hab hp hlight hcaplo hcaphi
  dsimp only
  let A := overlapA γ z*Real.exp (-M*γ)
  let B := overlapB γ z*Real.exp (-M*(1-γ))
  let Q := completedCoupledPolynomial ℓ N m γ a b (DegreeOneCompletion.coefficient γ fL) fL f A B (Real.exp (-E/8))
  let base := Real.exp (-E)*Real.exp (-C*(γ*(1-γ)))
  let err := (100:ℝ)^(m+1)*a^((m:ℝ)+γ)
  have hE : 0<E := hEmin.trans_le hEE
  have hh : 0≤γ*(1-γ) := mul_nonneg hγ.le (sub_nonneg.mpr hγ1.le)
  have hκ : 0≤Real.exp (-E) := (Real.exp_pos _).le
  have hbase0 : 0≤base := by dsimp [base]; positivity
  have hbaseκ : base≤Real.exp (-E) := by
    dsimp only [base]
    exact mul_le_of_le_one_right hκ (Real.exp_le_one_iff.mpr (by nlinarith only [hC,hh]))
  have hbase1 : base≤1 := hbaseκ.trans (Real.exp_le_one_iff.mpr (by linarith only [hE]))
  have hω : 0≤Real.exp (-E/8) := (Real.exp_pos _).le
  have hω1 : Real.exp (-E/8)<1 := Real.exp_lt_one_iff.mpr (by linarith only [hE])
  have hweights := overlap_coefficients_unit hγ hγ1 hz hz1
  have hA : 0≤A := mul_nonneg hweights.1.le (Real.exp_pos _).le
  have hB : 0≤B := mul_nonneg hweights.2.2.1.le (Real.exp_pos _).le
  have hA1 : A≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hweights.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hγ]))
  have hB1 : B≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hweights.2.2.2.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hh,hγ,hγ1]))
  have herr : 0≤err := by dsimp [err]; positivity
  have hheavy : (1+cH)*Real.exp (-E)≤Real.exp (-E/8) := by
    dsimp only [cH]
    rw [show 1+(Real.exp (7*Emin/8)-1)=Real.exp (7*Emin/8) by ring,←Real.exp_add]
    exact Real.exp_le_exp.mpr (by linarith only [hEE])
  have hpoint (i : Fin k) :
      base*(p i)^((m:ℝ)+γ)+min c cH*Real.exp (-E)*
        (if a≤p i then (p i)^((m:ℝ)+γ)*min ((N:ℝ)^2*(p i/b)) 1 else 0)≤
      (if light i then Q.eval (p i) else Real.exp (-E/8)*(p i)^((m:ℝ)+γ))+err := by
    have hpα := Real.rpow_nonneg (hp i) ((m:ℝ)+γ)
    have hb : 0<b := ha.trans_le hab
    have hY0 : 0≤min ((N:ℝ)^2*(p i/b)) 1 := le_min (mul_nonneg (sq_nonneg _) (div_nonneg (hp i) hb.le)) (by norm_num)
    have hY1 : min ((N:ℝ)^2*(p i/b)) 1≤1 := min_le_right _ _
    by_cases hl : light i=true
    · by_cases hpa : a≤p i
      · have hscale := coupled_scaled_product_identity (ha.trans_le hpa) hb (ℓ:=ℓ) (N:=N) (a:=a)
        have him := hlower ℓ N m γ z E a b (p i) hℓ hN hm hdegree hγ hγ1 hz hz1 hEE hG henergy ha hpa (hlight i hl)
          (by simpa only [hscale] using hcaplo) (by simpa only [hscale] using hcaphi)
        change (p i)^((m:ℝ)+γ)*(base+c*Real.exp (-E)*min ((N:ℝ)^2*(p i/b)) 1)≤Q.eval (p i) at him
        have hgain := mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_right (min_le_left c cH) hκ) (mul_nonneg hpα hY0)
        simp only [hl,hpa,ite_true]
        nlinarith only [him,hgain,herr]
      · have hi := completedCoupledPolynomial_below_cutoff_exponential hℓ (by omega : 0<N) hm hdegree hγ hγ1 ha hab (hp i) (le_of_lt (lt_of_not_ge hpa))
          (DegreeOneCompletion.coefficient_spec hγ hfL1).1 hfL.le hfL1 hf.le hf1.le hA hA1 hB hB1 hω hω1
        change |Q.eval (p i)|+(p i)^((m:ℝ)+γ)≤err at hi
        have habs := neg_abs_le (Q.eval (p i))
        have hbp := mul_le_of_le_one_left hpα hbase1
        simp only [hl,hpa,ite_true,ite_false,mul_zero,add_zero]
        linarith only [hi,habs,hbp]
    · have hl' : light i=false := Bool.eq_false_iff.mpr hl
      have hg : min c cH*Real.exp (-E)*(if a≤p i then (p i)^((m:ℝ)+γ)*min ((N:ℝ)^2*(p i/b)) 1 else 0)≤cH*Real.exp (-E)*(p i)^((m:ℝ)+γ) := by
        by_cases hpa : a≤p i
        · simp only [hpa,ite_true]
          have h1 := mul_le_mul_of_nonneg_right (min_le_right c cH) hκ
          have h3 := mul_le_of_le_one_right hpα hY1
          exact (mul_le_mul_of_nonneg_right h1 (mul_nonneg hpα hY0)).trans
            (mul_le_mul_of_nonneg_left h3 (mul_nonneg hcH.le hκ))
        · simp only [hpa,ite_false,mul_zero]; positivity
      have hb := mul_le_mul_of_nonneg_right hbaseκ hpα
      have hw := mul_le_mul_of_nonneg_right hheavy hpα
      simp only [hl',Bool.false_eq_true,ite_false]
      nlinarith only [hg,hb,hw,herr]
  have hsum := Finset.sum_le_sum (fun (i : Fin k) (_hi : i∈Finset.univ) => hpoint i)
  simpa only [Finset.sum_add_distrib,Finset.mul_sum,Finset.sum_const,Finset.card_univ,
    Fintype.card_fin,nsmul_eq_mul,base,err,Q,A,B,mul_assoc] using hsum

end Renyi
