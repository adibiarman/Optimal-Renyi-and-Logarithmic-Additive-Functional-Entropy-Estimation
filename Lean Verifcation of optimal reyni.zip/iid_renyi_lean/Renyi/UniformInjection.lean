import Mathlib.Probability.Distributions.Uniform
import Mathlib.Logic.Equiv.Fintype
import Mathlib.Data.Fintype.CardEmbedding

/-!
# Restricting a uniformly random injection

The law of the labels attached to any fixed collection of observed coordinates
is uniform over the injections of that collection. The proof uses permutation
symmetry and does not require an explicit formula for the number of extensions.
-/

noncomputable section
open scoped BigOperators ENNReal

namespace Renyi

/-- A permutation of the target carries any finite injection to any other. -/
theorem embedding_target_permutation {α κ : Type*} [Fintype α] [Fintype κ]
    (a b : α ↪ κ) : ∃ σ : Equiv.Perm κ, ∀ i, σ (a i) = b i := by
  classical
  let e : Set.range a ≃ Set.range b := a.toEquivRange.symm.trans b.toEquivRange
  refine ⟨e.extendSubtype, ?_⟩
  intro i
  rw [Equiv.extendSubtype_apply_of_mem e (a i) (Set.mem_range_self i)]
  simp [e]

/-- Postcomposition by a permutation is a bijection of the full injections. -/
def embeddingPostcompose {β κ : Type*} (σ : Equiv.Perm κ) :
    (β ↪ κ) ≃ (β ↪ κ) where
  toFun f := f.trans σ.toEmbedding
  invFun f := f.trans σ.symm.toEmbedding
  left_inv f := by ext i; simp
  right_inv f := by ext i; simp

/-- A probability mass function with equal masses on a finite nonempty type is
the uniform probability mass function. -/
theorem pmf_eq_uniform_of_constant {α : Type*} [Fintype α] [Nonempty α]
    (p : PMF α) (h : ∀ a b, p a = p b) : p = PMF.uniformOfFintype α := by
  classical
  ext b
  have hs : (Fintype.card α : ℝ≥0∞) * p b = 1 := by
    have hs := p.tsum_coe
    rw [tsum_fintype] at hs
    have heq : (∑ a, p a) = ∑ _ : α, p b :=
      Finset.sum_congr rfl (fun a _ => h a b)
    rw [heq] at hs
    simpa only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul] using hs
  have hzero : (Fintype.card α : ℝ≥0∞) ≠ 0 := by
    exact_mod_cast Fintype.card_ne_zero
  rw [PMF.uniformOfFintype_apply]
  calc
    p b = (Fintype.card α : ℝ≥0∞)⁻¹ * ((Fintype.card α : ℝ≥0∞) * p b) := by
      rw [← mul_assoc, ENNReal.inv_mul_cancel hzero (ENNReal.natCast_ne_top _), one_mul]
    _ = (Fintype.card α : ℝ≥0∞)⁻¹ := by rw [hs, mul_one]

/-- Restriction of a uniform injection to a fixed embedded set of coordinates
has the uniform law on injections of those coordinates. -/
theorem uniform_embedding_restriction {α β κ : Type*}
    [Fintype α] [Fintype β] [Fintype κ]
    [Nonempty (β ↪ κ)] [Nonempty (α ↪ κ)] (s : α ↪ β) :
    (PMF.uniformOfFintype (β ↪ κ)).map (fun f => s.trans f) =
      PMF.uniformOfFintype (α ↪ κ) := by
  classical
  apply pmf_eq_uniform_of_constant
  intro a b
  obtain ⟨σ, hσ⟩ := embedding_target_permutation a b
  rw [PMF.map_apply, PMF.map_apply]
  trans ∑' f : β ↪ κ, if b = s.trans (embeddingPostcompose σ f) then
    PMF.uniformOfFintype (β ↪ κ) (embeddingPostcompose σ f) else 0
  · apply tsum_congr
    intro f
    have heq : b = s.trans (embeddingPostcompose σ f) ↔ a = s.trans f := by
      constructor
      · intro hf
        ext i
        apply σ.injective
        rw [hσ]
        exact congrArg (fun g : α ↪ κ => g i) hf
      · intro hf
        ext i
        simpa [embeddingPostcompose, ← hσ i] using
          congrArg σ (congrArg (fun g : α ↪ κ => g i) hf)
    simp only [heq, PMF.uniformOfFintype_apply]
  · convert (embeddingPostcompose σ).tsum_eq
      (fun f => if b = s.trans f then PMF.uniformOfFintype (β ↪ κ) f else 0) using 1
    apply tsum_congr
    intro f
    split_ifs <;> rfl

/-- Uniform random injection, with existence supplied by the size inequality. -/
def uniformInjection (Q k : ℕ) (hQk : Q ≤ k) : PMF (Fin Q ↪ Fin k) :=
  letI : Nonempty (Fin Q ↪ Fin k) := ⟨Fin.castLEEmb hQk⟩
  PMF.uniformOfFintype (Fin Q ↪ Fin k)

/-- Explicit-size form of the uniform restriction law used by random labeling. -/
theorem uniformInjection_restriction {r Q k : ℕ} (hQk : Q ≤ k)
    (s : Fin r ↪ Fin Q) :
    (uniformInjection Q k hQk).map (fun f => s.trans f) =
      uniformInjection r k ((show r ≤ Q from by simpa using Fintype.card_le_of_embedding s).trans hQk) := by
  letI : Nonempty (Fin Q ↪ Fin k) := ⟨Fin.castLEEmb hQk⟩
  letI : Nonempty (Fin r ↪ Fin k) := ⟨s.trans (Fin.castLEEmb hQk)⟩
  exact uniform_embedding_restriction s

end Renyi
