import Renyi.UpperCompact
import Renyi.NearOneMargins

/-! Calibration of the same estimator parameters as alpha decreases to one. -/

noncomputable section
namespace Renyi

theorem near_one_order {alpha : ℝ} (ha : 1 < alpha) (ha1 : alpha ≤ 3 / 2) :
    upperOrderFloor alpha = 1 ∧ fractionalPart alpha = alpha - 1 := by
  have hm : upperOrderFloor alpha = 1 := by
    apply le_antisymm
    · have hm2 : upperOrderFloor alpha < 2 :=
        (Nat.floor_lt (by linarith : 0 ≤ alpha)).mpr (by norm_num; linarith)
      omega
    · exact upperOrderFloor_one_le ha
  refine ⟨hm, ?_⟩
  rw [fractionalPart_eq_upperOrderFloor ha, hm]
  norm_num

theorem near_one_Q_identity {k : ℕ} {alpha eps : ℝ} (hk : 0 < k)
    (ha : 1 < alpha) (ha1 : alpha ≤ 3 / 2) :
    rootQSquared k alpha eps =
      ((alpha - 1) ^ ((alpha - 1) / (2 - alpha)) *
        (2 - alpha) ^ (1 + 1 / (alpha - 1)) / alpha ^ (2 : ℕ) *
        Real.exp (-2 * eps / (2 - alpha))) * (k : ℝ) ^ (1 / alpha) := by
  have hb : 0 < alpha - 1 := by linarith
  have hd : 0 < 2 - alpha := by linarith
  rw [rootQSquared_factorization hk, (near_one_order ha ha1).2]
  have hex : 1 + 1 / (1 - (alpha - 1)) = 2 + (alpha - 1) / (2 - alpha) := by
    rw [show 1 - (alpha - 1) = 2 - alpha by ring]
    field_simp
    ring
  have hcancel : -(2 * eps * (alpha - 1)) / ((alpha - 1) * (1 - (alpha - 1))) =
      -2 * eps / (2 - alpha) := by
    rw [show 1 - (alpha - 1) = 2 - alpha by ring]
    field_simp
  unfold overlapPsi
  rw [hex, Real.rpow_add hb, Real.rpow_two, hcancel]
  have hdid : 1 - (alpha - 1) = 2 - alpha := by ring
  rw [hdid]
  congr 1
  field_simp

theorem near_one_power_factors {beta : ℝ} (hb : 0 < beta) (hbhalf : beta ≤ 1 / 2) :
    Real.exp (-2) ≤ beta ^ (beta / (1 - beta)) ∧
      beta ^ (beta / (1 - beta)) ≤ 1 ∧
      Real.exp (-3) ≤ (1 - beta) ^ (1 + 1 / beta) ∧
      (1 - beta) ^ (1 + 1 / beta) ≤ 1 := by
  have hd : 0 < 1 - beta := by linarith
  have hblog : -1 ≤ beta * Real.log beta := by
    have h := mul_le_mul_of_nonneg_left (Real.one_sub_inv_le_log_of_pos hb) hb.le
    rw [mul_sub, mul_inv_cancel₀ hb.ne', mul_one] at h
    linarith
  have hdlog : -beta / (1 - beta) ≤ Real.log (1 - beta) := by
    convert Real.one_sub_inv_le_log_of_pos hd using 1
    field_simp
    ring
  have hfirst : -2 ≤ Real.log beta * (beta / (1 - beta)) := by
    have hh : -2 * (1 - beta) ≤ Real.log beta * beta := by nlinarith
    convert (le_div_iff₀ hd).mpr hh using 1
    ring
  have hsecond : -3 ≤ Real.log (1 - beta) * (1 + 1 / beta) := by
    have h := mul_le_mul_of_nonneg_right hdlog (by positivity : 0 ≤ 1 + 1 / beta)
    have hlo : -3 ≤ (-beta / (1 - beta)) * (1 + 1 / beta) := by
      have hid : (-beta / (1 - beta)) * (1 + 1 / beta) = -(beta + 1) / (1 - beta) := by
        field_simp
      rw [hid]
      apply (le_div_iff₀ hd).mpr
      nlinarith
    exact hlo.trans h
  refine ⟨?_, Real.rpow_le_one hb.le (by linarith) (div_pos hb hd).le,
    ?_, Real.rpow_le_one hd.le (by linarith) (by positivity)⟩
  · rw [Real.rpow_def_of_pos hb]
    exact Real.exp_le_exp.mpr hfirst
  · rw [Real.rpow_def_of_pos hd]
    exact Real.exp_le_exp.mpr hsecond

def nearOneQConstant (eps : ℝ) : ℝ := Real.exp (-5 - 4 * eps) / 4

theorem nearOneQConstant_pos (eps : ℝ) : 0 < nearOneQConstant eps := by
  unfold nearOneQConstant
  positivity

theorem near_one_Q_bounds {k : ℕ} {alpha eps : ℝ} (hk : 0 < k)
    (ha : 1 < alpha) (ha1 : alpha ≤ 3 / 2) (heps : 0 < eps) :
    nearOneQConstant eps * (k : ℝ) ^ (1 / alpha) ≤ rootQSquared k alpha eps ∧
      rootQSquared k alpha eps ≤ (k : ℝ) ^ (1 / alpha) := by
  have hb : 0 < alpha - 1 := by linarith
  have hd : 0 < 2 - alpha := by linarith
  have ha0 : 0 < alpha := by linarith
  have hfac := near_one_power_factors hb (by linarith : alpha - 1 ≤ 1 / 2)
  have hdid : 1 - (alpha - 1) = 2 - alpha := by ring
  rw [hdid] at hfac
  have hexplo : Real.exp (-4 * eps) ≤ Real.exp (-2 * eps / (2 - alpha)) := by
    apply Real.exp_le_exp.mpr
    apply (le_div_iff₀ hd).mpr
    nlinarith
  have hexphi : Real.exp (-2 * eps / (2 - alpha)) ≤ 1 :=
    Real.exp_le_one_iff.mpr (div_nonpos_of_nonpos_of_nonneg (by linarith) hd.le)
  have hp0 : 0 ≤ (alpha - 1) ^ ((alpha - 1) / (2 - alpha)) := Real.rpow_nonneg hb.le _
  have hp1 : 0 ≤ (2 - alpha) ^ (1 + 1 / (alpha - 1)) := Real.rpow_nonneg hd.le _
  have hprodlo := mul_le_mul hfac.1 hfac.2.2.1 (Real.exp_pos (-3)).le hp0
  have hprodhi := mul_le_mul hfac.2.1 hfac.2.2.2 hp1 (by norm_num : (0 : ℝ) ≤ 1)
  have hlo : nearOneQConstant eps ≤
      (alpha - 1) ^ ((alpha - 1) / (2 - alpha)) *
        (2 - alpha) ^ (1 + 1 / (alpha - 1)) / alpha ^ (2 : ℕ) *
        Real.exp (-2 * eps / (2 - alpha)) := by
    have h := mul_le_mul hprodlo hexplo (Real.exp_pos _).le (mul_nonneg hp0 hp1)
    have heq : Real.exp (-2) * Real.exp (-3) * Real.exp (-4 * eps) = Real.exp (-5 - 4 * eps) := by
      rw [← Real.exp_add, ← Real.exp_add]
      congr 1
      ring
    rw [heq] at h
    have hαsq : alpha ^ (2 : ℕ) ≤ 4 := by nlinarith
    have hn0 : 0 ≤ Real.exp (-5 - 4 * eps) := (Real.exp_pos _).le
    have hdiv := div_le_div_of_nonneg_left hn0 (sq_pos_of_pos ha0) hαsq
    apply hdiv.trans
    convert (div_le_div_iff_of_pos_right (sq_pos_of_pos ha0)).mpr h using 1
    ring
  have hhi : (alpha - 1) ^ ((alpha - 1) / (2 - alpha)) *
        (2 - alpha) ^ (1 + 1 / (alpha - 1)) / alpha ^ (2 : ℕ) *
        Real.exp (-2 * eps / (2 - alpha)) ≤ 1 := by
    have h := mul_le_mul hprodhi hexphi (Real.exp_pos _).le (by norm_num : (0 : ℝ) ≤ 1 * 1)
    have hn : (alpha - 1) ^ ((alpha - 1) / (2 - alpha)) *
        (2 - alpha) ^ (1 + 1 / (alpha - 1)) * Real.exp (-2 * eps / (2 - alpha)) ≤ alpha ^ (2 : ℕ) := by
      nlinarith
    have hdiv : ((alpha - 1) ^ ((alpha - 1) / (2 - alpha)) *
        (2 - alpha) ^ (1 + 1 / (alpha - 1)) * Real.exp (-2 * eps / (2 - alpha))) /
        alpha ^ (2 : ℕ) ≤ 1 := (div_le_iff₀ (sq_pos_of_pos ha0)).mpr (by simpa using hn)
    convert hdiv using 1
    ring
  rw [near_one_Q_identity hk ha ha1]
  have hkpow : 0 ≤ (k : ℝ) ^ (1 / alpha) := Real.rpow_nonneg (Nat.cast_nonneg _) _
  exact ⟨mul_le_mul_of_nonneg_right hlo hkpow, by simpa using mul_le_mul_of_nonneg_right hhi hkpow⟩

/-- The actual inverse-overlap time stays in a fixed positive interval near order one. -/
theorem near_one_overlap_time_uniform {eps : ℝ} (heps : 0 < eps) :
    ∃ T : ℝ, 0 < T ∧ ∀ (k : ℕ) (alpha Ch : ℝ),
      1 < alpha → alpha ≤ 3 / 2 → 0 ≤ Ch →
      eps ≤ upperOverlapTime (fractionalPart alpha) (upperE0 k alpha eps Ch) ∧
      upperOverlapTime (fractionalPart alpha) (upperE0 k alpha eps Ch) ≤ T := by
  obtain ⟨c, hc, _, hlinear⟩ := overlapF_uniform_linear heps
  refine ⟨4 * eps / c, by positivity, ?_⟩
  intro k alpha Ch ha ha1 hCh
  have hgamma := (near_one_order ha ha1).2
  have hg : 0 < fractionalPart alpha := by rw [hgamma]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [hgamma]; linarith
  have hh : 0 < fractionalPart alpha * (1 - fractionalPart alpha) :=
    mul_pos hg (sub_pos.mpr hg1)
  have hreserved := upper_reserved_interval (k := k) ha hg hg1 heps hCh
  have hE : 0 < upperE0 k alpha eps Ch := (mul_pos heps (sub_pos.mpr ha)).trans_le hreserved.1
  have ht := upperOverlapTime_spec hg hg1 hE
  have hF := overlapF_le_linear hg hg1 ht.1
  rw [ht.2] at hF
  have hmargin : eps * (fractionalPart alpha * (1 - fractionalPart alpha)) ≤
      upperE0 k alpha eps Ch := by
    rw [hgamma]
    nlinarith [mul_nonneg heps.le (sq_nonneg (alpha - 1))]
  have htlo : eps ≤ upperOverlapTime (fractionalPart alpha) (upperE0 k alpha eps Ch) := by
    apply (mul_le_mul_iff_right₀ hh).mp
    nlinarith
  have hFl := hlinear _ _ hg hg1 htlo
  rw [ht.2] at hFl
  have hEhi : upperE0 k alpha eps Ch ≤
      4 * eps * (fractionalPart alpha * (1 - fractionalPart alpha)) := by
    rw [hgamma]
    have hhalf : (alpha - 1) ≤ 2 * ((alpha - 1) * (1 - (alpha - 1))) := by nlinarith
    have := mul_le_mul_of_nonneg_left hhalf (by positivity : 0 ≤ 2 * eps)
    nlinarith
  have hct : c * upperOverlapTime (fractionalPart alpha) (upperE0 k alpha eps Ch) ≤ 4 * eps := by
    apply (mul_le_mul_iff_right₀ hh).mp
    nlinarith
  exact ⟨htlo, (le_div_iff₀ hc).mpr (by nlinarith [hct])⟩

theorem overlapB_at_time {gamma t : ℝ} (hg : 0 < gamma) (hg1 : gamma < 1) :
    overlapB gamma (Real.exp (-gamma * (1 - gamma) * t)) =
      (1 - Real.exp (-gamma * t)) / (1 - Real.exp (-t)) := by
  have hd : 0 < 1 - gamma := sub_pos.mpr hg1
  unfold overlapB
  rw [← Real.exp_mul, ← Real.exp_mul]
  congr 2 <;> congr 1 <;> field_simp

/-- Exact amplitudes vanish at the order gap, using the actual inverse-overlap time. -/
theorem near_one_amplitudes_uniform {eps : ℝ} (heps : 0 < eps) :
    ∃ C : ℝ, 0 < C ∧ ∀ (k : ℕ) (alpha Ch : ℝ),
      1 < alpha → alpha ≤ 3 / 2 → 0 ≤ Ch →
      0 ≤ overlapB (fractionalPart alpha)
        (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)) ∧
      overlapB (fractionalPart alpha)
        (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)) ≤ C * (alpha - 1) ∧
      0 ≤ 1 - overlapA (fractionalPart alpha)
        (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)) ∧
      1 - overlapA (fractionalPart alpha)
        (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)) ≤ C * (alpha - 1) := by
  obtain ⟨T, hT, htime⟩ := near_one_overlap_time_uniform heps
  have he : 0 < 1 - Real.exp (-eps) := one_sub_exp_neg_pos heps
  refine ⟨T / (1 - Real.exp (-eps)), div_pos hT he, ?_⟩
  intro k alpha Ch ha ha1 hCh
  have hgamma := (near_one_order ha ha1).2
  have hg : 0 < fractionalPart alpha := by rw [hgamma]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [hgamma]; linarith
  have ht := htime k alpha Ch ha ha1 hCh
  let t := upperOverlapTime (fractionalPart alpha) (upperE0 k alpha eps Ch)
  let z := upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)
  have ht0 : 0 < t := heps.trans_le ht.1
  have hz := (upperOverlapZ_spec hg hg1
    ((mul_pos heps (sub_pos.mpr ha)).trans_le (upper_reserved_interval (k := k) ha hg hg1 heps hCh).1)).1
  have hB : 0 ≤ overlapB (fractionalPart alpha) z :=
    (hg.trans (overlap_coefficients hg hg1 hz.1 hz.2).2).le
  have hBhi : overlapB (fractionalPart alpha) z ≤ T / (1 - Real.exp (-eps)) * (alpha - 1) := by
    change overlapB (fractionalPart alpha) (Real.exp (-fractionalPart alpha * (1 - fractionalPart alpha) * t)) ≤ _
    rw [overlapB_at_time hg hg1]
    have hnum : 1 - Real.exp (-fractionalPart alpha * t) ≤ fractionalPart alpha * T := by
      have hx := Real.add_one_le_exp (-fractionalPart alpha * t)
      have hh := mul_le_mul_of_nonneg_left ht.2 hg.le
      nlinarith
    have hden : 1 - Real.exp (-eps) ≤ 1 - Real.exp (-t) := by
      have hh := Real.exp_le_exp.mpr (neg_le_neg ht.1)
      linarith
    have hdiv := div_le_div₀ (by positivity : 0 ≤ fractionalPart alpha * T) hnum he hden
    convert hdiv using 1
    rw [hgamma]
    ring
  have hend := (overlap_endpoints hg hg1 hz.1 hz.2).2
  change overlapA (fractionalPart alpha) z + overlapB (fractionalPart alpha) z *
    z ^ (1 / fractionalPart alpha) = 1 at hend
  have hzp : 0 ≤ z ^ (1 / fractionalPart alpha) := Real.rpow_nonneg hz.1.le _
  have hzp1 : z ^ (1 / fractionalPart alpha) ≤ 1 :=
    Real.rpow_le_one hz.1.le hz.2.le (by positivity)
  have hprod := mul_le_mul_of_nonneg_left hzp1 hB
  have hprod0 := mul_nonneg hB hzp
  exact ⟨hB, hBhi, by linarith, by nlinarith⟩

theorem near_one_tangent_ratio {k : ℕ} {alpha eps Ch D cb lambda CL cL N c : ℝ}
    (hk : 0 < k) (ha : 1 < alpha) (ha1 : alpha ≤ 3 / 2)
    (hD : 0 < D) (hcb : 0 < cb) (hCL : 1 ≤ CL) (hcL : 0 < cL) (hN : 0 < N) :
    (c * alpha * upperA k alpha eps Ch D cb lambda CL cL / (alpha - 1)) /
        (upperB k alpha eps D cb CL cL / N ^ 2) =
      c * lambda * (N ^ 2 / (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ^ 2) *
        alpha * (2 - alpha) *
        Real.exp (-upperOverlapTime (fractionalPart alpha) (upperE0 k alpha eps Ch)) := by
  have horder := near_one_order ha ha1
  have hg : 0 < fractionalPart alpha := by rw [horder.2]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [horder.2]; linarith
  have hB := upperB_pos (ε := eps) hk ha hg hg1 hD hcb hCL hcL
  have hL := upperDegree_pos ha hCL hcL (one_le_rootMultiplier (k := k) (ε := eps) ha hg hg1)
  have hb : alpha - 1 ≠ 0 := (sub_pos.mpr ha).ne'
  unfold upperA
  rw [upperOverlapZ_power hg hg1, horder.1, horder.2]
  norm_num
  field_simp
  ring

theorem near_one_tangent_comparison {k : ℕ} {alpha eps Ch D cb lambda CL cL N c q Q T : ℝ}
    (hk : 0 < k) (ha : 1 < alpha) (ha1 : alpha ≤ 3 / 2)
    (hD : 0 < D) (hcb : 0 < cb) (hCL : 1 ≤ CL) (hcL : 0 < cL)
    (hc : 0 < c) (hlambda : 0 < lambda) (hq : 0 < q) (hQ : 0 < Q)
    (hNlo : q * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ≤ N)
    (hNhi : N ≤ Q * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ))
    (ht0 : 0 ≤ upperOverlapTime (fractionalPart alpha) (upperE0 k alpha eps Ch))
    (ht : upperOverlapTime (fractionalPart alpha) (upperE0 k alpha eps Ch) ≤ T) :
    c * lambda * q ^ 2 * (3 / 4) * Real.exp (-T) ≤
      (c * alpha * upperA k alpha eps Ch D cb lambda CL cL / (alpha - 1)) /
        (upperB k alpha eps D cb CL cL / N ^ 2) ∧
    (c * alpha * upperA k alpha eps Ch D cb lambda CL cL / (alpha - 1)) /
        (upperB k alpha eps D cb CL cL / N ^ 2) ≤ c * lambda * Q ^ 2 := by
  have hg : 0 < fractionalPart alpha := by rw [(near_one_order ha ha1).2]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [(near_one_order ha ha1).2]; linarith
  have hL := upperDegree_pos ha hCL hcL (one_le_rootMultiplier (k := k) (ε := eps) ha hg hg1)
  have hN : 0 < N := (mul_pos hq hL).trans_le hNlo
  have hNsqlo := mul_le_mul hNlo hNlo (mul_pos hq hL).le hN.le
  have hNsqhi := mul_le_mul hNhi hNhi hN.le (mul_pos hQ hL).le
  have hlo : q ^ 2 ≤ N ^ 2 / (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ^ 2 :=
    (le_div_iff₀ (sq_pos_of_pos hL)).mpr (by nlinarith)
  have hhi : N ^ 2 / (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ^ 2 ≤ Q ^ 2 :=
    (div_le_iff₀ (sq_pos_of_pos hL)).mpr (by nlinarith)
  have hadlo : (3 : ℝ) / 4 ≤ alpha * (2 - alpha) := by nlinarith
  have hadhi : alpha * (2 - alpha) ≤ 1 := by nlinarith [sq_nonneg (alpha - 1)]
  have hexlo := Real.exp_le_exp.mpr (neg_le_neg ht)
  have hexhi : Real.exp (-upperOverlapTime (fractionalPart alpha) (upperE0 k alpha eps Ch)) ≤ 1 :=
    Real.exp_le_one_iff.mpr (neg_nonpos.mpr ht0)
  have hcl := mul_pos hc hlambda
  have hbase : 0 ≤ c * lambda *
      (N ^ 2 / (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ^ 2) := by positivity
  have hpreflo := mul_le_mul_of_nonneg_left hlo hcl.le
  have hprefhi := mul_le_mul_of_nonneg_left hhi hcl.le
  have hlomid := mul_le_mul hpreflo hadlo (by norm_num : (0 : ℝ) ≤ 3 / 4) hbase
  have hhimid := mul_le_mul hprefhi hadhi (by linarith : 0 ≤ alpha * (2 - alpha))
    (by positivity : 0 ≤ c * lambda * Q ^ 2)
  have hwholelo := mul_le_mul hlomid hexlo (Real.exp_pos _).le
    (mul_nonneg hbase (by linarith : 0 ≤ alpha * (2 - alpha)))
  have hwholehi := mul_le_mul hhimid hexhi (Real.exp_pos _).le
    (by positivity : 0 ≤ c * lambda * Q ^ 2 * 1)
  rw [near_one_tangent_ratio hk ha ha1 hD hcb hCL hcL hN]
  constructor
  · convert hwholelo using 1
    ring
  · convert hwholehi using 1 <;> ring

/-- All three scales in the near-one calibration use the same actual sample rule. -/
theorem near_one_scales_uniform {eps cb lambda CL cL c q Q : ℝ}
    (heps : 0 < eps) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hc : 0 < c) (hq : 0 < q) (hQ : 0 < Q) :
    ∃ C ctau Ctau : ℝ, 0 < C ∧ 0 < ctau ∧ 0 < Ctau ∧
      ∀ (k : ℕ) (alpha Ch D N : ℝ), 0 < k → 1 < alpha → alpha ≤ 3 / 2 →
      0 ≤ Ch → 0 < D →
      q * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ≤ N →
      N ≤ Q * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) →
      (k : ℝ) / (upperSample k alpha eps D *
        (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)) ≤ C / D ∧
      (k : ℝ) * (upperB k alpha eps D cb CL cL / N ^ 2) ≤ C / D ∧
      ctau ≤ (c * alpha * upperA k alpha eps Ch D cb lambda CL cL / (alpha - 1)) /
        (upperB k alpha eps D cb CL cL / N ^ 2) ∧
      (c * alpha * upperA k alpha eps Ch D cb lambda CL cL / (alpha - 1)) /
        (upperB k alpha eps D cb CL cL / N ^ 2) ≤ Ctau := by
  obtain ⟨T, _, htime⟩ := near_one_overlap_time_uniform heps
  let C0 := Real.exp 1 / (nearOneQConstant eps * min CL cL)
  let C := (1 + cb / q ^ 2) * C0
  have hC0 : 0 < C0 := div_pos (Real.exp_pos _)
    (mul_pos (nearOneQConstant_pos eps) (lt_min (by linarith) hcL))
  have hcbq : 0 ≤ cb / q ^ 2 := by positivity
  have hC : 0 < C := mul_pos (by linarith) hC0
  refine ⟨C, c * lambda * q ^ 2 * (3 / 4) * Real.exp (-T), c * lambda * Q ^ 2,
    hC, by positivity, by positivity, ?_⟩
  intro k alpha Ch D N hk ha ha1 hCh hD hNlo hNhi
  have hg : 0 < fractionalPart alpha := by rw [(near_one_order ha ha1).2]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [(near_one_order ha ha1).2]; linarith
  have hqlo := (near_one_Q_bounds hk ha ha1 heps).1
  have hcount := upper_count_scale_of_Q_lower hk ha hg hg1 hD hCL hcL (nearOneQConstant_pos eps) hqlo
  have htcount := upper_tangent_count_scale hk ha hg hg1 hD hcb.le hCL hcL hq hNlo hcount
  have ht := htime k alpha Ch ha ha1 hCh
  have hratio := near_one_tangent_comparison hk ha ha1 hD hcb hCL hcL hc hlambda hq hQ
    hNlo hNhi (heps.le.trans ht.1) ht.2
  have hC0C : C0 ≤ C := by dsimp [C]; nlinarith
  have hCbC : cb / q ^ 2 * C0 ≤ C := by dsimp [C]; nlinarith
  exact ⟨hcount.trans ((div_le_div_iff_of_pos_right hD).mpr hC0C),
    htcount.trans ((div_le_div_iff_of_pos_right hD).mpr hCbC), hratio⟩

/-- Complete source near-one calibration, with no changed estimator or accuracy parameter. -/
theorem upper_near_one_uniform {eps cb lambda CL cL c q Q cω : ℝ}
    (heps : 0 < eps) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hc : 0 < c) (hq : 0 < q) (hQ : 0 < Q)
    (hcω : 0 < cω) (hcω1 : cω < 1) :
    ∃ C c0 : ℝ, 0 < C ∧ 0 < c0 ∧
      ∀ (k : ℕ) (alpha Ch D N : ℝ), 0 < k → 1 < alpha → alpha ≤ 3 / 2 →
      0 ≤ Ch → 0 < D →
      q * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ≤ N →
      N ≤ Q * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) →
      (k : ℝ) / (upperSample k alpha eps D *
        (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)) ≤ C / D ∧
      (k : ℝ) * (upperB k alpha eps D cb CL cL / N ^ 2) ≤ C / D ∧
      c0 ≤ (c * alpha * upperA k alpha eps Ch D cb lambda CL cL / (alpha - 1)) /
        (upperB k alpha eps D cb CL cL / N ^ 2) ∧
      (c * alpha * upperA k alpha eps Ch D cb lambda CL cL / (alpha - 1)) /
        (upperB k alpha eps D cb CL cL / N ^ 2) ≤ C ∧
      overlapB (fractionalPart alpha)
        (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)) ≤ C * (alpha - 1) ∧
      1 - overlapA (fractionalPart alpha)
        (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)) ≤ C * (alpha - 1) ∧
      |overlapA (fractionalPart alpha)
        (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)) - upperOmega k alpha eps Ch cω| ≤
        C * (alpha - 1) ∧
      c0 * (alpha - 1) ≤ min (1 - upperOmega k alpha eps Ch cω)
        (upperOmega k alpha eps Ch cω - upperKappa alpha eps) := by
  obtain ⟨Cs, ctau, Ct, hCs, hctau, _, hscales⟩ :=
    near_one_scales_uniform heps hcb hlambda hCL hcL hc hq hQ
  obtain ⟨Ca, hCa, hamp⟩ := near_one_amplitudes_uniform heps
  let C := max Cs (max Ct (Ca + 2 * cω * eps))
  let c0 := min ctau (nearOneMarginConstant eps cω)
  have hcm := nearOneMarginConstant_pos heps hcω hcω1
  have hCsC : Cs ≤ C := le_max_left _ _
  have hCtC : Ct ≤ C := (le_max_left _ _).trans (le_max_right _ _)
  have hgapC : Ca + 2 * cω * eps ≤ C := (le_max_right _ _).trans (le_max_right _ _)
  have hCaC : Ca ≤ C := le_trans (by nlinarith [mul_pos hcω heps]) hgapC
  refine ⟨C, c0, hCs.trans_le hCsC, lt_min hctau hcm, ?_⟩
  intro k alpha Ch D N hk ha ha1 hCh hD hNlo hNhi
  have hb : 0 < alpha - 1 := sub_pos.mpr ha
  have hg : 0 < fractionalPart alpha := by rw [(near_one_order ha ha1).2]; exact hb
  have hg1 : fractionalPart alpha < 1 := by rw [(near_one_order ha ha1).2]; linarith
  have hs := hscales k alpha Ch D N hk ha ha1 hCh hD hNlo hNhi
  have haamp := hamp k alpha Ch ha ha1 hCh
  have hm := upperOmega_near_one_margins (k := k) ha ha1 hg hg1 heps hCh hcω hcω1
  have hgap1 := hm.1.trans (min_le_left _ _)
  have hdiff : |overlapA (fractionalPart alpha)
      (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)) - upperOmega k alpha eps Ch cω| ≤
      (Ca + 2 * cω * eps) * (alpha - 1) := by
    apply abs_le.mpr
    have hω : upperOmega k alpha eps Ch cω ≤ 1 := by nlinarith [mul_pos hcm hb]
    constructor <;> nlinarith [haamp.2.2.1, haamp.2.2.2, hm.2, mul_pos hCa hb, mul_pos hcω heps]
  refine ⟨hs.1.trans ((div_le_div_iff_of_pos_right hD).mpr hCsC),
    hs.2.1.trans ((div_le_div_iff_of_pos_right hD).mpr hCsC),
    (min_le_left _ _).trans hs.2.2.1, hs.2.2.2.trans hCtC,
    haamp.2.1.trans (mul_le_mul_of_nonneg_right hCaC hb.le),
    haamp.2.2.2.trans (mul_le_mul_of_nonneg_right hCaC hb.le),
    hdiff.trans (mul_le_mul_of_nonneg_right hgapC hb.le), ?_⟩
  exact (mul_le_mul_of_nonneg_right (min_le_right _ _) hb.le).trans hm.1

end Renyi
