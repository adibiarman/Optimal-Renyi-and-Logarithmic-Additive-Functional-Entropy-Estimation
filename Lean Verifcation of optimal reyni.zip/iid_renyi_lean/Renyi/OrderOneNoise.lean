import Renyi.AnalyticNoise
import Renyi.PoissonLogMoments

/-! The complete uniform divided-difference variance bound at order one. -/

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Set
namespace Renyi

/-- The four actual shifted-Poisson moments needed by the noise envelope. -/
def shiftedLogNoiseEnvelope (lam : ℝ≥0) (q : ℝ) (j : ℕ) : ℝ :=
  1 + shiftedCountRatio lam j ^ q + (Real.log (shiftedCountRatio lam j)) ^ 2 +
    shiftedCountRatio lam j ^ q * (Real.log (shiftedCountRatio lam j)) ^ 2

theorem shiftedLogNoiseEnvelope_nonneg {lam : ℝ≥0} (hlam : 0 < (lam : ℝ))
    (q : ℝ) (j : ℕ) : 0 ≤ shiftedLogNoiseEnvelope lam q j := by
  dsimp [shiftedLogNoiseEnvelope]
  have hp : 0 ≤ shiftedCountRatio lam j ^ q := Real.rpow_nonneg (shiftedCountRatio_pos hlam j).le _
  positivity

theorem shiftedLogNoiseEnvelope_integrable {lam : ℝ≥0} (hlam : 0 < (lam : ℝ))
    {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q ≤ 1) :
    Integrable (shiftedLogNoiseEnvelope lam q) (poissonMeasure lam) := by
  have hv := shiftedCountRatio_rpow_integrable hlam hq0 hq1
  have hlog : Integrable (fun j => (Real.log (shiftedCountRatio lam j)) ^ 2) (poissonMeasure lam) := by
    simpa only [Real.rpow_zero, one_mul] using
      (shiftedCountRatio_rpow_log_sq_integrable hlam (q := 0) (by norm_num) (by norm_num))
  exact (((integrable_const 1).add hv).add hlog).add
    (shiftedCountRatio_rpow_log_sq_integrable hlam hq0 hq1)

theorem shiftedLogNoiseEnvelope_integral_le {lam : ℝ≥0} (hlam : 1 ≤ (lam : ℝ))
    {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q ≤ 1) :
    (∫ j, shiftedLogNoiseEnvelope lam q j ∂poissonMeasure lam) ≤ 55 := by
  have hlam0 : 0 < (lam : ℝ) := by linarith
  have hv := shiftedCountRatio_rpow_integrable hlam0 hq0 hq1
  have hlog : Integrable (fun j => (Real.log (shiftedCountRatio lam j)) ^ 2) (poissonMeasure lam) := by
    simpa only [Real.rpow_zero, one_mul] using
      (shiftedCountRatio_rpow_log_sq_integrable hlam0 (q := 0) (by norm_num) (by norm_num))
  have hvlog := shiftedCountRatio_rpow_log_sq_integrable hlam0 hq0 hq1
  unfold shiftedLogNoiseEnvelope
  have hA := integral_add (((integrable_const 1).add hv).add hlog) hvlog
  have hB := integral_add ((integrable_const 1).add hv) hlog
  have hC := integral_add (integrable_const 1) hv
  simp only [Pi.add_apply] at hA hB hC
  rw [hA, hB, hC]
  simp only [integral_const, measureReal_univ_eq_one, smul_eq_mul, one_mul]
  have h1 := shiftedCountRatio_rpow_integral_le hlam hq0 hq1
  have h2 := shiftedCountRatio_rpow_log_sq_integral_le hlam hq0 hq1
  have h3 : (∫ j, (Real.log (shiftedCountRatio lam j)) ^ 2 ∂poissonMeasure lam) ≤ 24 := by
    simpa only [Real.rpow_zero, one_mul] using
      (shiftedCountRatio_rpow_log_sq_integral_le hlam (q := 0) (by norm_num) (by norm_num))
  linarith

/-- A deterministic shift separates the intensity-scale logarithm from count noise. -/
theorem logarithmic_power_envelope {x lam B q : ℝ} (hx : 0 < x) (hlam : 0 < lam)
    (hB : 0 < B) :
    (x ^ q + B ^ q) * (1 + (Real.log (x / B)) ^ 2) ≤
      2 * (lam ^ q + B ^ q) * (1 + (Real.log (lam / B)) ^ 2) *
        (1 + (x / lam) ^ q + (Real.log (x / lam)) ^ 2 +
          (x / lam) ^ q * (Real.log (x / lam)) ^ 2) := by
  have hv : 0 < x / lam := div_pos hx hlam
  have hpow : x ^ q = lam ^ q * (x / lam) ^ q := by
    rw [← Real.mul_rpow hlam.le hv.le, mul_div_cancel₀ _ hlam.ne']
  have hlog : Real.log (x / B) = Real.log (lam / B) + Real.log (x / lam) := by
    rw [Real.log_div hx.ne' hB.ne', Real.log_div hlam.ne' hB.ne', Real.log_div hx.ne' hlam.ne']
    ring
  have hp : lam ^ q * (x / lam) ^ q + B ^ q ≤
      (lam ^ q + B ^ q) * (1 + (x / lam) ^ q) := by
    have h1 : 0 ≤ lam ^ q := (Real.rpow_pos_of_pos hlam _).le
    have h2 : 0 ≤ B ^ q * (x / lam) ^ q := by positivity
    nlinarith
  have hl : 1 + (Real.log (lam / B) + Real.log (x / lam)) ^ 2 ≤
      2 * (1 + (Real.log (lam / B)) ^ 2) * (1 + (Real.log (x / lam)) ^ 2) := by
    have hs := sq_nonneg (Real.log (lam / B) - Real.log (x / lam))
    have hm : 0 ≤ (Real.log (lam / B)) ^ 2 * (Real.log (x / lam)) ^ 2 := by positivity
    nlinarith
  rw [hpow, hlog]
  have ht := mul_le_mul hp hl (by positivity : 0 ≤ 1 + (Real.log (lam / B) + Real.log (x / lam)) ^ 2)
    (by positivity : 0 ≤ (lam ^ q + B ^ q) * (1 + (x / lam) ^ q))
  convert ht using 1
  ring

/-- Squaring the pointwise divided increment preserves a uniform logarithmic envelope. -/
theorem analyticCount_order_one_increment_sq {β B : ℝ} (hβ : 0 < β) (hβ1 : β ≤ 1 / 2)
    (hB : 0 < B) (j : ℕ) :
    (((1 + β) * analyticCount β j - B ^ β) / β) ^ 2 ≤
      4 * smallOrderStepConstant ^ 2 * (((j : ℝ) + 1) ^ (2 * β) + B ^ (2 * β)) *
        (1 + (Real.log (((j : ℝ) + 1) / B)) ^ 2) := by
  let p := ((j : ℝ) + 1) ^ β
  let z := B ^ β
  let t := |Real.log (((j : ℝ) + 1) / B)|
  have hp : 0 ≤ p := Real.rpow_nonneg (by positivity) _
  have hz : 0 ≤ z := (Real.rpow_pos_of_pos hB β).le
  have ht : 0 ≤ t := abs_nonneg _
  have hD : 0 ≤ smallOrderStepConstant := le_trans (by norm_num) smallOrderStepConstant_ge_two
  have hb := analyticCount_order_one_increment hβ hβ1 hB j
  have hsq := (sq_le_sq₀ (abs_nonneg _) (by positivity :
    0 ≤ smallOrderStepConstant * (p + z) * (1 + t))).mpr hb
  rw [sq_abs] at hsq
  have h1 : (p + z) ^ 2 ≤ 2 * (p ^ 2 + z ^ 2) := by nlinarith [sq_nonneg (p - z)]
  have h2 : (1 + t) ^ 2 ≤ 2 * (1 + t ^ 2) := by nlinarith [sq_nonneg (t - 1)]
  have hh := mul_le_mul h1 h2 (sq_nonneg _) (by positivity : 0 ≤ 2 * (p ^ 2 + z ^ 2))
  have hmult := mul_le_mul_of_nonneg_left hh (sq_nonneg smallOrderStepConstant)
  have hp2 : p ^ 2 = ((j : ℝ) + 1) ^ (2 * β) := by
    dsimp [p]
    rw [← Real.rpow_natCast, ← Real.rpow_mul (by positivity : 0 ≤ (j : ℝ) + 1)]
    congr 1
    ring
  have hz2 : z ^ 2 = B ^ (2 * β) := by
    dsimp [z]
    rw [← Real.rpow_natCast, ← Real.rpow_mul hB.le]
    congr 1
    ring
  have ht2 : t ^ 2 = (Real.log (((j : ℝ) + 1) / B)) ^ 2 := sq_abs _
  calc
    _ ≤ (smallOrderStepConstant * (p + z) * (1 + t)) ^ 2 := hsq
    _ = smallOrderStepConstant ^ 2 * ((p + z) ^ 2 * (1 + t) ^ 2) := by ring
    _ ≤ smallOrderStepConstant ^ 2 * (2 * (p ^ 2 + z ^ 2) * (2 * (1 + t ^ 2))) := hmult
    _ = _ := by rw [hp2, hz2, ht2]; ring

def orderOneNoiseConstant : ℝ := 440 * smallOrderStepConstant ^ 2

/-- The full divided-difference noise bound for the actual Poisson observation. -/
theorem order_one_divided_variance {β B : ℝ} (hβ : 0 < β) (hβ1 : β ≤ 1 / 2)
    (hB : 0 < B) (lam : ℝ≥0) (hlam : 1 ≤ (lam : ℝ)) :
    variance (fun j : ℕ => (analyticCount (1 + β) j - B ^ β * (j : ℝ)) / β)
      (poissonMeasure lam) ≤
      orderOneNoiseConstant * (lam : ℝ) * ((lam : ℝ) ^ (2 * β) + B ^ (2 * β)) *
        (1 + (Real.log ((lam : ℝ) / B)) ^ 2) := by
  have hlam0 : 0 < (lam : ℝ) := by linarith
  have hq0 : 0 ≤ 2 * β := by positivity
  have hq1 : 2 * β ≤ 1 := by linarith
  let v : ℕ → ℝ := fun j => (analyticCount (1 + β) j - B ^ β * (j : ℝ)) / β
  let w : ℕ → ℝ := fun j => ((1 + β) * analyticCount β j - B ^ β) / β
  have hv : MemLp v 2 (poissonMeasure lam) := by
    have hnum := (analyticCount_memLp lam (1 + β)).sub ((poisson_nat_memLp lam).const_mul (B ^ β))
    simpa only [v, div_eq_mul_inv] using hnum.mul_const β⁻¹
  have hw : MemLp w 2 (poissonMeasure lam) := by
    have hnum := ((analyticCount_memLp lam β).const_mul (1 + β)).sub (memLp_const (B ^ β))
    simpa only [w, div_eq_mul_inv] using hnum.mul_const β⁻¹
  have hdif : forwardDifference v = w := by
    funext j
    have h := analyticCount_difference (1 + β) j
    rw [show 1 + β - 1 = β by ring] at h
    dsimp [forwardDifference, v, w]
    rw [← sub_div]
    congr 1
    unfold forwardDifference at h
    push_cast
    linarith
  have hd : MemLp (forwardDifference v) 2 (poissonMeasure lam) := by rw [hdif]; exact hw
  let E : ℝ := ((lam : ℝ) ^ (2 * β) + B ^ (2 * β)) *
    (1 + (Real.log ((lam : ℝ) / B)) ^ 2)
  let K : ℝ := 8 * smallOrderStepConstant ^ 2 * E
  have hE : 0 ≤ E := by dsimp [E]; positivity
  have hK : 0 ≤ K := by dsimp [K]; positivity
  have hpoint (j : ℕ) : w j ^ 2 ≤ K * shiftedLogNoiseEnvelope lam (2 * β) j := by
    have h1 := analyticCount_order_one_increment_sq hβ hβ1 hB j
    have h2 := logarithmic_power_envelope (by positivity : 0 < (j : ℝ) + 1) hlam0 hB (q := 2 * β)
    have hmul := mul_le_mul_of_nonneg_left h2 (by positivity : 0 ≤ 4 * smallOrderStepConstant ^ 2)
    calc
      w j ^ 2 ≤ 4 * smallOrderStepConstant ^ 2 *
          ((((j : ℝ) + 1) ^ (2 * β) + B ^ (2 * β)) *
            (1 + (Real.log (((j : ℝ) + 1) / B)) ^ 2)) := by
        convert h1 using 1
        ring
      _ ≤ 4 * smallOrderStepConstant ^ 2 *
          (2 * ((lam : ℝ) ^ (2 * β) + B ^ (2 * β)) *
            (1 + (Real.log ((lam : ℝ) / B)) ^ 2) *
              (1 + (((j : ℝ) + 1) / (lam : ℝ)) ^ (2 * β) +
                (Real.log (((j : ℝ) + 1) / (lam : ℝ))) ^ 2 +
                  (((j : ℝ) + 1) / (lam : ℝ)) ^ (2 * β) *
                    (Real.log (((j : ℝ) + 1) / (lam : ℝ))) ^ 2)) := hmul
      _ = K * shiftedLogNoiseEnvelope lam (2 * β) j := by
        dsimp [K, E, shiftedLogNoiseEnvelope, shiftedCountRatio]
        ring
  have hg := shiftedLogNoiseEnvelope_integrable hlam0 hq0 hq1
  have hmono := integral_mono hw.integrable_sq (hg.const_mul K) hpoint
  rw [integral_const_mul] at hmono
  have hbudget := mul_le_mul_of_nonneg_left (shiftedLogNoiseEnvelope_integral_le hlam hq0 hq1) hK
  have hint := hmono.trans hbudget
  have hpoin := poisson_poincare lam v hv hd
  rw [hdif] at hpoin
  change variance v (poissonMeasure lam) ≤ _
  calc
    _ ≤ (lam : ℝ) * ∫ j, w j ^ 2 ∂poissonMeasure lam := hpoin
    _ ≤ (lam : ℝ) * (K * 55) := mul_le_mul_of_nonneg_left hint lam.coe_nonneg
    _ = _ := by dsimp [K, E, orderOneNoiseConstant]; ring

/-- One absolute constant works for the complete order-one noise proposition. -/
theorem order_one_noise_uniform :
    ∃ C : ℝ, 0 < C ∧ ∀ (β B : ℝ), 0 < β → β ≤ 1 / 2 → 0 < B →
      ∀ lam : ℝ≥0, 1 ≤ (lam : ℝ) →
        variance (fun j : ℕ => (analyticCount (1 + β) j - B ^ β * (j : ℝ)) / β)
          (poissonMeasure lam) ≤
          C * (lam : ℝ) * ((lam : ℝ) ^ (2 * β) + B ^ (2 * β)) *
            (1 + (Real.log ((lam : ℝ) / B)) ^ 2) := by
  have hD : 0 < smallOrderStepConstant := lt_of_lt_of_le (by norm_num) smallOrderStepConstant_ge_two
  refine ⟨orderOneNoiseConstant, by dsimp [orderOneNoiseConstant]; positivity, ?_⟩
  intro β B hβ hβ1 hB lam hlam
  exact order_one_divided_variance hβ hβ1 hB lam hlam

/-- The bias assertion also holds for the actual affine numerator expectation. -/
theorem order_one_numerator_bias {β B : ℝ} (hβ : 0 < β) (hβ1 : β ≤ 1 / 2)
    (lam : ℝ≥0) (hlam : 0 < (lam : ℝ)) :
    |(∫ j : ℕ, analyticCount (1 + β) j - B ^ β * (j : ℝ) ∂poissonMeasure lam) -
      ((lam : ℝ) ^ (1 + β) - B ^ β * (lam : ℝ))| ≤
      2 * β * Real.exp (-(lam : ℝ)) / (lam : ℝ) := by
  have hcount := (poisson_nat_memLp lam).integrable one_le_two
  rw [integral_sub ((analyticCount_memLp lam (1 + β)).integrable one_le_two)
    (hcount.const_mul (B ^ β)), integral_const_mul, poisson_nat_mean]
  have hb := analyticMean_order_one_bias hβ hβ1 lam hlam
  convert hb using 1
  congr 1
  dsimp [analyticMean]
  ring

end Renyi
