import Renyi.LowerAuxiliaryCalibration

/-! The exact observation-transfer interface for constructed finite atomic priors. -/
noncomputable section
open scoped BigOperators NNReal
namespace Renyi

/-- Reindex any finite atomic support by `Fin`, preserving its actual masses and values. -/
def finitePriorReindex {ι : Type*} [Fintype ι] (P : FiniteAtomicPrior ι) :
    FiniteAtomicPrior (Fin (Fintype.card ι)) where
  mass := fun j => P.mass ((Fintype.equivFin ι).symm j)
  value := fun j => P.value ((Fintype.equivFin ι).symm j)
  mass_nonneg := fun _ => P.mass_nonneg _
  mass_sum := ((Fintype.equivFin ι).symm.sum_comp P.mass).trans P.mass_sum

@[simp] theorem finitePriorReindex_moment {ι : Type*} [Fintype ι]
    (P : FiniteAtomicPrior ι) (a : ℝ) : priorMoment (finitePriorReindex P) a = priorMoment P a :=
  (Fintype.equivFin ι).symm.sum_comp (fun i => P.mass i * P.value i ^ a)

@[simp] theorem finitePriorReindex_poissonMixture {ι : Type*} [Fintype ι]
    (P : FiniteAtomicPrior ι) (theta : ℝ) (j : ℕ) :
    poissonMixture (finitePriorReindex P).mass (finitePriorReindex P).value theta j =
      poissonMixture P.mass P.value theta j :=
  (Fintype.equivFin ι).symm.sum_comp
    (fun i => P.mass i * (Real.exp (-(theta * P.value i)) * (theta * P.value i)^j / (j.factorial : ℝ)))

@[simp] theorem finitePriorReindex_residual {ι : Type*} [Fintype ι]
    (P : FiniteAtomicPrior ι) (a : ℝ) :
    priorResidualSecondMoment (finitePriorReindex P) a = priorResidualSecondMoment P a := by
  unfold priorResidualSecondMoment
  rw [finitePriorReindex_moment]
  exact (Fintype.equivFin ι).symm.sum_comp
    (fun i => P.mass i * (P.value i ^ a - priorMoment P a * P.value i)^2)

/-- Explicit normalization budget directly on a constructed finite atomic prior. -/
def priorNormalizationMomentBudget {ι : Type*} [Fintype ι]
    (b : ℝ≥0) (P : FiniteAtomicPrior ι) (alpha m : ℝ) : ℝ :=
  priorMoment P 2 / ((b : ℝ)*(min (1/4) (m/(16*(alpha-1))))^2) +
  priorResidualSecondMoment P alpha / ((b : ℝ)*(priorMoment P alpha)^2*(m/16)^2)

@[simp] theorem finitePriorReindex_normalizationBudget {ι : Type*} [Fintype ι]
    (b : ℝ≥0) (P : FiniteAtomicPrior ι) (a m : ℝ) :
    priorNormalizationMomentBudget b (finitePriorReindex P) a m =
      priorNormalizationMomentBudget b P a m := by
  simp only [priorNormalizationMomentBudget, finitePriorReindex_moment, finitePriorReindex_residual]

def finitePriorMassNN {ι : Type*} [Fintype ι] (P : FiniteAtomicPrior ι) : ι → ℝ≥0 :=
  fun i => ⟨P.mass i, P.mass_nonneg i⟩

def finitePriorValueNN {ι : Type*} [Fintype ι] (P : FiniteAtomicPrior ι)
    (hv : ∀ i, 0 ≤ P.value i) : ι → ℝ≥0 := fun i => ⟨P.value i, hv i⟩

theorem finitePriorMassNN_sum {ι : Type*} [Fintype ι] (P : FiniteAtomicPrior ι) :
    ∑ i, finitePriorMassNN P i = 1 := by
  apply NNReal.coe_injective
  simpa only [NNReal.coe_sum, NNReal.coe_one, finitePriorMassNN] using P.mass_sum

/-- The finite atomic normalization budget is exactly the observation theorem's
budget after representing nonnegative masses and values by `NNReal`. -/
theorem finitePriorNN_normalizationBudget {L : ℕ} (b : ℝ≥0)
    (P : FiniteAtomicPrior (Fin L)) (hv : ∀ i, 0 ≤ P.value i) (a m : ℝ) :
    normalizationMomentBudget b (finitePriorMassNN P) (finitePriorValueNN P hv)
        a (priorMoment P a) m = priorNormalizationMomentBudget b P a m := by
  simp only [normalizationMomentBudget, priorNormalizationMomentBudget, priorResidualSecondMoment,
    priorMoment, finitePriorMassNN, finitePriorValueNN, Real.rpow_two]
  rfl

/-- The full lower observation transfer applies directly to the actual finite
atomic priors built by interpolation, with their explicit moment/noise/count
inequalities. No support encoding or observation-law hypothesis is left implicit. -/
theorem fingerprint_transfer_finite_priors {ι0 ι1 : Type*} [Fintype ι0] [Fintype ι1]
    {k n : ℕ} (b theta : ℝ≥0) (hb : 0 < (b : ℝ)) (hk : 2*(b : ℝ) ≤ k)
    (P0 : FiniteAtomicPrior ι0) (P1 : FiniteAtomicPrior ι1)
    (hv0 : ∀ i, 0 ≤ P0.value i) (hv1 : ∀ i, 0 ≤ P1.value i)
    {alpha eps m : ℝ} (ha : 1 < alpha) (hm : 0 < m) (hm1 : m ≤ 1)
    (hA0 : 0 < priorMoment P0 alpha) (hA1 : 0 < priorMoment P1 alpha)
    (hmean0 : priorMoment P0 1 = 1) (hmean1 : priorMoment P1 1 = 1)
    (hgap : 2*eps*(alpha-1)+m ≤ Real.log (priorMoment P1 alpha / priorMoment P0 alpha))
    (hD : (b : ℝ)*countDistance (poissonMixture P0.mass P0.value theta)
      (poissonMixture P1.mass P1.value theta) ≤ 1/16)
    (hzeta0 : priorNormalizationMomentBudget b P0 alpha m ≤ 1/64)
    (hzeta1 : priorNormalizationMomentBudget b P1 alpha m ≤ 1/64)
    (hsupport : (Real.exp 1/4)^(b : ℝ) ≤ 1/128)
    (havailable : Real.exp (-(theta : ℝ)*b/16) ≤ 1/128)
    (hn : (n : ℝ) ≤ (theta : ℝ)*b/4) : ¬ Achievable k n alpha eps := by
  let R0 := finitePriorReindex P0
  let R1 := finitePriorReindex P1
  have hvR0 : ∀ j, 0 ≤ R0.value j := fun j => hv0 _
  have hvR1 : ∀ j, 0 ≤ R1.value j := fun j => hv1 _
  let p0 := finitePriorMassNN R0
  let p1 := finitePriorMassNN R1
  let z0 := finitePriorValueNN R0 hvR0
  let z1 := finitePriorValueNN R1 hvR1
  have hp0 : ∑ i, p0 i = 1 := finitePriorMassNN_sum R0
  have hp1 : ∑ i, p1 i = 1 := finitePriorMassNN_sum R1
  apply fingerprint_transfer_impossibility b theta hb hk p0 z0 p1 z1 hp0 hp1 ha hA0 hA1 hm hm1
  · change (∑ i, R0.mass i * R0.value i) = 1
    simpa only [priorMoment, Real.rpow_one] using (finitePriorReindex_moment P0 1).trans hmean0
  · change (∑ i, R1.mass i * R1.value i) = 1
    simpa only [priorMoment, Real.rpow_one] using (finitePriorReindex_moment P1 1).trans hmean1
  · exact finitePriorReindex_moment P0 alpha
  · exact finitePriorReindex_moment P1 alpha
  · exact hgap
  · simp only [finite_mixed_count_toReal]
    change (b : ℝ)*countDistance (poissonMixture R0.mass R0.value theta)
      (poissonMixture R1.mass R1.value theta) ≤ _
    have heq0 : poissonMixture R0.mass R0.value theta = poissonMixture P0.mass P0.value theta :=
      funext (fun j => finitePriorReindex_poissonMixture P0 theta j)
    have heq1 : poissonMixture R1.mass R1.value theta = poissonMixture P1.mass P1.value theta :=
      funext (fun j => finitePriorReindex_poissonMixture P1 theta j)
    rw [heq0, heq1]
    exact hD
  · rw [show priorMoment P0 alpha = priorMoment R0 alpha from (finitePriorReindex_moment P0 alpha).symm]
    rw [finitePriorNN_normalizationBudget, finitePriorReindex_normalizationBudget]
    exact hzeta0
  · rw [show priorMoment P1 alpha = priorMoment R1 alpha from (finitePriorReindex_moment P1 alpha).symm]
    rw [finitePriorNN_normalizationBudget, finitePriorReindex_normalizationBudget]
    exact hzeta1
  · exact hsupport
  · exact havailable
  · exact hn

end Renyi
