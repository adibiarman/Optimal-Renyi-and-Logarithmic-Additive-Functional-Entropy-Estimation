import Renyi.CompactBiasBudget
import Renyi.ActualBiasModel
import Renyi.UpperPilotBaseline

/-! Compact-width localization of the one actual corrected source oracle mean. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 900000

/-- Actual source geometry and weights discharge every localization premise. -/
theorem actualCoupledHybridMean_localized {k : ℕ}
    {alpha eps Ch D cb lambda CL cL fL f M sigma : ℝ}
    (hk : 0<k) (ha : 3/2≤alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (heps : 0<eps) (hCh : 0≤Ch) (hD : 0<D) (hcb : 0<cb)
    (hlambda : 0<lambda) (hlambda4 : lambda≤4) (hCL : 1≤CL) (hcL : 0<cL) (hcbCL : 1≤cb*CL)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1) (hM : 0≤M)
    (hs : 0≤sigma) (hs1 : sigma≤1)
    (p : Simplex k) (light : Fin k→Bool)
    (hlight : ∀i,light i=true→p.mass i≤upperB k alpha eps D cb CL cL) :
    |sigma*actualCoupledHybridMean p light alpha eps Ch D cb lambda CL cL fL f M-
      sigma*Real.exp (-upperE0 k alpha eps Ch/8)*powerSum p alpha|≤
      (k:ℝ)*(100:ℝ)^(upperOrderFloor alpha+1)*(upperA k alpha eps Ch D cb lambda CL cL)^alpha+
        2*completedLocalizationConstant*((k:ℝ)*(upperB k alpha eps D cb CL cL/
          (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2))^(min alpha 2)*powerSum p alpha := by
  have ha1 : 1<alpha := by linarith only [ha]
  have hgeom := upper_actual_count_geometry hk ha hg hg1 heps hCh hD hcb hlambda hlambda4 hCL hcL hcbCL
  dsimp only at hgeom
  have hE : 0<upperE0 k alpha eps Ch :=
    (mul_pos heps (sub_pos.mpr ha1)).trans_le (upper_reserved_interval (k:=k) ha1 hg hg1 heps hCh).1
  have hz := upperOverlapZ_spec hg hg1 hE
  have hweights := overlap_coefficients_unit hg hg1 hz.1.1 hz.1.2
  let A := overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*fractionalPart alpha)
  let B := overlapB (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(1-fractionalPart alpha))
  have hA : 0≤A := mul_nonneg hweights.1.le (Real.exp_pos _).le
  have hB : 0≤B := mul_nonneg hweights.2.2.1.le (Real.exp_pos _).le
  have hA1 : A≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hweights.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [mul_nonneg hM hg.le]))
  have hB1 : B≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hweights.2.2.2.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [mul_nonneg hM (sub_pos.mpr hg1).le]))
  have hbound := completed_polynomial_localized_sum hk hgeom.2.2.2.1 (by omega : 0<upperDegree alpha CL cL (rootMultiplier k alpha eps))
    (upperOrderFloor_one_le ha1) hgeom.2.2.2.2.2.2.1 hg hg1 hgeom.1 hgeom.2.1
    hfL hfL1 hf hf1 hA hA1 hB hB1 (Real.exp_pos _).le
    (Real.exp_lt_one_iff.mpr (by linarith only [hE] : -upperE0 k alpha eps Ch/8<0)) hs hs1 p light hlight
  have hid : (upperOrderFloor alpha:ℝ)+fractionalPart alpha=alpha := by
    rw [fractionalPart_eq_upperOrderFloor ha1]
    ring
  dsimp only at hbound
  rw [hid] at hbound
  have hsum : (∑i,if light i then sigma*(actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).eval (p.mass i)
      else sigma*Real.exp (-upperE0 k alpha eps Ch/8)*p.mass i^alpha)=
      sigma*actualCoupledHybridMean p light alpha eps Ch D cb lambda CL cL fL f M := by
    unfold actualCoupledHybridMean
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    split_ifs <;> ring
  change |(∑i,if light i then sigma*(actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).eval (p.mass i)
      else sigma*Real.exp (-upperE0 k alpha eps Ch/8)*p.mass i^alpha)-
      sigma*Real.exp (-upperE0 k alpha eps Ch/8)*powerSum p alpha|≤_ at hbound
  rw [hsum] at hbound
  exact hbound

/-- At bounded width the actual corrected oracle is arbitrarily close to its
strict interior target, uniformly over order, alphabet, and every light assignment. -/
theorem actual_corrected_oracle_compact_bias {eps W Ch cb lambda CL cL fL f M cu u0 C0 d eta : ℝ}
    (heps : 0<eps) (hW : 0<W) (hCh : 0≤Ch) (hcb : 0<cb)
    (hlambda : 0<lambda) (hlambda4 : lambda≤4) (hCL : 1≤CL) (hcL : 0<cL) (hcbCL : 1≤cb*CL)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1) (hM : 0≤M)
    (hcu : 0≤cu) (hu0 : 0<u0) (hC0 : 1≤C0) (hd : 0≤d) (heta : 0<eta) :
    ∃ D0 : ℝ, 0<D0 ∧ ∀ (k : ℕ) (alpha D : ℝ),
      0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → D0≤D →
      2*eps*(alpha-1)/(fractionalPart alpha*(1-fractionalPart alpha))≤W →
      ∀ (p : Simplex k) (light : Fin k→Bool),
        (∀i,light i=true→p.mass i≤upperB k alpha eps D cb CL cL) →
        |actualCorrectedOracleMean p light alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d-
          upperRescaling k alpha eps cu u0*Real.exp (-upperE0 k alpha eps Ch/8)*powerSum p alpha|≤eta*powerSum p alpha := by
  let H := 2+W/(8*eps)
  let K := (100:ℝ)^H+2*completedLocalizationConstant+2*d*C0^(H-1)
  have hK : 0<K := by
    dsimp [K]
    have hc := completedLocalizationConstant_pos
    positivity
  let tau := min 1 (eta/K)
  have htau : 0<tau := lt_min zero_lt_one (div_pos heta hK)
  have htau1 : tau≤1 := min_le_left _ _
  have hKt : K*tau≤eta := by
    have hh := (min_le_right 1 (eta/K))
    exact (mul_le_mul_of_nonneg_left hh hK.le).trans_eq (by field_simp)
  obtain ⟨D0,hD0,hscales⟩ := upper_compact_small_scales heps hW hCh hcb hlambda hCL hcL hu0 (by norm_num : (0:ℝ)<1) htau
  refine ⟨D0,hD0,?_⟩
  intro k alpha D hk ha hg hg1 hDD hwidth p light hlight
  have hD := hD0.trans_le hDD
  have ha1 : 1<alpha := by linarith only [ha]
  have hsc := hscales k alpha D (upperDegree alpha CL cL (rootMultiplier k alpha eps)) hk ha hg hg1 hDD hwidth (by simp)
  have hgeom := upper_actual_count_geometry hk ha hg hg1 heps hCh hD hcb hlambda hlambda4 hCL hcL hcbCL
  dsimp only at hgeom
  have hres := upperRescaling_range (k:=k) (eps:=eps) ha1 hg hg1 hcu hu0
  have hloc := actualCoupledHybridMean_localized hk ha hg hg1 heps hCh hD hcb hlambda hlambda4 hCL hcL hcbCL
    hfL hfL1 hf hf1 hM hres.1.le hres.2 p light hlight
  have horder : (upperOrderFloor alpha:ℝ)+1≤H := by
    have hb := (bounded_width_geometry ha heps hW hg hg1 hwidth).2.2.2
    have hm := upperOrderFloor_le ha1
    dsimp [H]
    linarith only [hb,hm]
  have hbudget := compact_localization_bias_budget hk p ha hgeom.1 (div_nonneg hgeom.2.2.1.le (sq_nonneg _))
    htau htau1 hsc.1 hsc.2 horder hC0 hd
  have hbase : actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d=
      min (alpha-1) 1*d*C0^upperOrderFloor alpha*(upperA k alpha eps Ch D cb lambda CL cL)^(alpha-1) :=
    upperActualBaseline_power_identity hk hgeom.1.le
  have hbase0 : 0≤actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d := by
    rw [hbase]
    have hc : 0≤min (alpha-1) 1 := le_min (by linarith only [ha]) (by norm_num)
    exact mul_nonneg (mul_nonneg (mul_nonneg hc hd) (pow_nonneg (by linarith only [hC0]) _)) (Real.rpow_nonneg hgeom.1.le _)
  have htri := abs_add_le
    (upperRescaling k alpha eps cu u0*actualCoupledHybridMean p light alpha eps Ch D cb lambda CL cL fL f M-
      upperRescaling k alpha eps cu u0*Real.exp (-upperE0 k alpha eps Ch/8)*powerSum p alpha)
    (2*actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d)
  rw [abs_of_nonneg (mul_nonneg (by norm_num) hbase0)] at htri
  have htri' : |actualCorrectedOracleMean p light alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d-
      upperRescaling k alpha eps cu u0*Real.exp (-upperE0 k alpha eps Ch/8)*powerSum p alpha|≤
      |upperRescaling k alpha eps cu u0*actualCoupledHybridMean p light alpha eps Ch D cb lambda CL cL fL f M-
        upperRescaling k alpha eps cu u0*Real.exp (-upperE0 k alpha eps Ch/8)*powerSum p alpha|+
        2*actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d := by
    convert htri using 1
    unfold actualCorrectedOracleMean
    congr 1
    ring
  rw [hbase] at htri'
  have hfinal := mul_le_mul_of_nonneg_right hKt (simplex_powerSum_pos p alpha).le
  nlinarith only [hloc,hbudget,htri',hfinal]

end Renyi
