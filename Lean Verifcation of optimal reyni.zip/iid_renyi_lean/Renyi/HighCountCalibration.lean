import Renyi.LowCountCalibration

/-! Normalize the high count block by the baseline, root reserve, and actual count bonus. -/
set_option maxHeartbeats 1000000
noncomputable section
open scoped NNReal
namespace Renyi

/-- A positive extra margin can only improve the affine monomial estimate. -/
theorem linear_over_larger_affine_margin {E v A M : ℝ}
    (hE : 0 < E) (hv : 0 < v) (hA : 0 ≤ A) (hM : E + v * A ≤ M) :
    A / M ^ 2 ≤ 1 / (E * v) := by
  have hbase : 0 < E + v * A := by positivity
  have hM0 : 0 < M := hbase.trans_le hM
  have hsq : (E + v * A) ^ 2 ≤ M ^ 2 := (sq_le_sq₀ hbase.le hM0.le).mpr hM
  have h := monomial_over_affine_margin_sq hE hv hA (by norm_num : (0 : ℝ) ≤ 1) (by norm_num : (1 : ℝ) ≤ 2)
  norm_num at h
  apply (div_le_div_of_nonneg_left hA (sq_pos_of_pos hbase) hsq).trans
  exact h.trans_eq (by simp only [Real.rpow_neg_one, one_div, mul_inv_rev]; ring)

/-- The large-mean count bonus pays for the selected high-mean component. -/
theorem high_block_affine_margin_bound {V E v kappa tau A Agt Bonus s t : ℝ}
    (hE : 0 < E) (hv : 0 < v) (hkappa : 0 < kappa) (htau : 0 < tau)
    (hA : 0 ≤ A) (hAgt : 0 ≤ Agt) (hBonus : 0 ≤ Bonus)
    (hs : 0 ≤ s) (ht : 0 ≤ t) (hbonus : tau * Agt ≤ Bonus)
    (hV : V ≤ s * A + t * Agt) :
    V / (E + v * A + kappa * Bonus) ^ 2 ≤ s / (E * v) + t / (E * kappa * tau) := by
  have hsmall : A / (E + v * A + kappa * Bonus) ^ 2 ≤ 1 / (E * v) :=
    linear_over_larger_affine_margin hE hv hA (by nlinarith [mul_nonneg hkappa.le hBonus])
  have hlarge : Agt / (E + v * A + kappa * Bonus) ^ 2 ≤ 1 / (E * (kappa * tau)) :=
    linear_over_larger_affine_margin hE (mul_pos hkappa htau) hAgt (by
      nlinarith [mul_nonneg hv.le hA, mul_le_mul_of_nonneg_left hbonus hkappa.le])
  apply (div_le_div_of_nonneg_right hV (sq_nonneg _)).trans
  have h := add_le_add (mul_le_mul_of_nonneg_left hsmall hs) (mul_le_mul_of_nonneg_left hlarge ht)
  convert h using 1 <;> ring

/-- Exact cancellation of dimension in the normalized n^-alpha factor. -/
theorem high_count_sample_normalization {k alpha D X : ℝ}
    (hk : 0 < k) (halpha : 0 < alpha) (hD : 0 < D) (hX : 0 < X) :
    (D * alpha * k ^ (1 - 1 / alpha) * X) ^ (-alpha) / k ^ (1 - alpha) =
      (D * alpha * X) ^ (-alpha) := by
  apply Real.log_injOn_pos (by apply Set.mem_Ioi.mpr; positivity) (by apply Set.mem_Ioi.mpr; positivity)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow]
  field_simp
  ring

/-- Exact cancellation for the b^alpha part when nb=cb L. -/
theorem high_count_cutoff_normalization {k alpha D X cb L : ℝ}
    (hk : 0 < k) (halpha : 0 < alpha) (hD : 0 < D) (hX : 0 < X)
    (hcb : 0 < cb) (hL : 0 < L) :
    (cb * L / (D * alpha * k ^ (1 - 1 / alpha) * X)) ^ alpha / k ^ (1 - alpha) =
      (cb * L / (D * alpha * X)) ^ alpha := by
  apply Real.log_injOn_pos (by apply Set.mem_Ioi.mpr; positivity) (by apply Set.mem_Ioi.mpr; positivity)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow]
  field_simp
  ring

lemma high_tiny_margin_factorization {alpha D X R E0 u0 c : ℝ}
    (halpha : 0 < alpha) (hD : 0 < D) (hX : 0 < X) (hR : 0 < R) (hE0 : 0 < E0) (hu0 : 0 < u0) :
    (D * alpha * X) ^ (-alpha) /
      ((E0 * (R / D) ^ (alpha - 1)) * (u0 * Real.exp (-c * alpha) * X ^ (-alpha))) =
      alpha ^ (-alpha) * R ^ (-(alpha - 1)) * Real.exp (c * alpha) / (E0 * u0 * D) := by
  apply Real.log_injOn_pos (by apply Set.mem_Ioi.mpr; positivity) (by apply Set.mem_Ioi.mpr; positivity)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_exp]
  ring

lemma high_medium_margin_factorization {alpha D X R E0 cb L c Ct : ℝ}
    (halpha : 0 < alpha) (hD : 0 < D) (hX : 0 < X) (hR : 0 < R)
    (hE0 : 0 < E0) (hcb : 0 < cb) (hL : 0 < L) :
    (cb * L / (D * alpha * X)) ^ alpha /
      ((E0 * (R / D) ^ (alpha - 1)) * Real.exp (-c * alpha) * Real.exp (-Ct * L)) =
      (R ^ (-(alpha - 1)) * Real.exp (c * alpha) / (E0 * D)) *
        (Real.exp (Ct * L) * (cb * L / (alpha * X)) ^ alpha) := by
  apply Real.log_injOn_pos (by apply Set.mem_Ioi.mpr; positivity) (by apply Set.mem_Ioi.mpr; positivity)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_exp]
  ring

lemma high_order_power_envelope {alpha q c C : ℝ}
    (ha : 1 ≤ alpha) (hq : 0 < q) (hc : 0 ≤ c) (hC : 1 ≤ C)
    (hqa : q ≤ alpha + c) (hqC : q ≤ C * alpha) :
    q ^ q ≤ Real.exp ((c + C * Real.log C) * alpha) * alpha ^ alpha := by
  have ha0 : 0 < alpha := zero_lt_one.trans_le ha
  have hC0 : 0 < C := zero_lt_one.trans_le hC
  have hloga : 0 ≤ Real.log alpha := Real.log_nonneg ha
  have hlogC : 0 ≤ Real.log C := Real.log_nonneg hC
  have hlogq := Real.log_le_log hq hqC
  rw [Real.log_mul hC0.ne' ha0.ne'] at hlogq
  have h1 := mul_le_mul_of_nonneg_left hlogq hq.le
  have h2 := mul_le_mul_of_nonneg_right hqa hloga
  have h3 := mul_le_mul_of_nonneg_right hqC hlogC
  have h4 := mul_le_mul_of_nonneg_left (Real.log_le_sub_one_of_pos ha0) hc
  rw [Real.rpow_def_of_pos hq, Real.rpow_def_of_pos ha0, ← Real.exp_add]
  apply Real.exp_le_exp.mpr
  nlinarith

def highTinyExponentialConstant (K : ℝ) : ℝ := (2 * K ^ 2 * Real.exp 2 + 2) * Real.exp 8

lemma highTinyExponentialConstant_ge_one (K : ℝ) : 1 ≤ highTinyExponentialConstant K := by
  have h1 : 1 ≤ Real.exp (8 : ℝ) := Real.one_le_exp_iff.mpr (by norm_num)
  unfold highTinyExponentialConstant
  have hP : 1 ≤ 2 * K ^ 2 * Real.exp 2 + 2 := by nlinarith [sq_nonneg K, Real.exp_pos 2]
  have hP0 : 0 ≤ 2 * K ^ 2 * Real.exp 2 + 2 := by positivity
  nlinarith [mul_le_mul_of_nonneg_left h1 hP0]

/-- The exact tiny-mean leading and tail prefactors have a uniform exponential order budget. -/
theorem high_tiny_prefactor_exponential {r : ℕ} {alpha K : ℝ}
    (ha : 3 / 2 ≤ alpha) (hra : (r : ℝ) ≤ alpha + 1) (har : alpha ≤ (r : ℝ)) :
    2 * K ^ 2 * Real.exp 2 * (2 * (r : ℝ)) ^ r + 2 * ((r + 1 : ℕ) : ℝ) ^ (r + 1) ≤
      (highTinyExponentialConstant K) ^ alpha * alpha ^ alpha := by
  have ha0 : 0 < alpha := by linarith
  have ha1 : 1 ≤ alpha := by linarith
  have hr : 0 < (r : ℝ) := ha0.trans_le har
  have h2log : Real.log 2 ≤ 1 := by have := Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 2); linarith
  have h3log : Real.log 3 ≤ 2 := by have := Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 3); linarith
  have hfirst : (2 * (r : ℝ)) ^ r ≤ Real.exp (8 * alpha) * alpha ^ alpha := by
    have hp := high_order_power_envelope ha1 hr (by norm_num : (0 : ℝ) ≤ 1) (by norm_num : (1 : ℝ) ≤ 2)
      hra (by linarith : (r : ℝ) ≤ 2 * alpha)
    have htwo : (2 : ℝ) ^ (r : ℝ) ≤ Real.exp (2 * alpha) := by
      rw [Real.rpow_def_of_pos (by norm_num : (0 : ℝ) < 2)]
      apply Real.exp_le_exp.mpr
      nlinarith [mul_le_mul_of_nonneg_left h2log hr.le]
    rw [← Real.rpow_natCast, Real.mul_rpow (by norm_num : (0 : ℝ) ≤ 2) hr.le]
    apply (mul_le_mul htwo hp (Real.rpow_nonneg hr.le _) (Real.exp_pos _).le).trans
    have hexp : Real.exp (2 * alpha) * Real.exp ((1 + 2 * Real.log 2) * alpha) ≤ Real.exp (8 * alpha) := by
      rw [← Real.exp_add]
      apply Real.exp_le_exp.mpr
      nlinarith
    nlinarith [Real.rpow_nonneg ha0.le alpha]
  have hsecond : ((r + 1 : ℕ) : ℝ) ^ (r + 1) ≤ Real.exp (8 * alpha) * alpha ^ alpha := by
    have hq : 0 < ((r + 1 : ℕ) : ℝ) := by positivity
    have hqa : ((r + 1 : ℕ) : ℝ) ≤ alpha + 2 := by push_cast; linarith
    have hqC : ((r + 1 : ℕ) : ℝ) ≤ 3 * alpha := by push_cast; linarith
    have hp := high_order_power_envelope ha1 hq (by norm_num : (0 : ℝ) ≤ 2) (by norm_num : (1 : ℝ) ≤ 3) hqa hqC
    rw [Real.rpow_natCast] at hp
    apply hp.trans
    exact mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr (by nlinarith)) (Real.rpow_nonneg ha0.le _)
  let P := 2 * K ^ 2 * Real.exp 2 + 2
  have hP : 1 ≤ P := by dsimp [P]; nlinarith [sq_nonneg K, Real.exp_pos 2]
  have hPP : P ≤ P ^ alpha := by simpa using Real.rpow_le_rpow_of_exponent_le hP ha1
  have hid : (highTinyExponentialConstant K) ^ alpha = P ^ alpha * Real.exp (8 * alpha) := by
    change (P * Real.exp 8) ^ alpha = _
    rw [Real.mul_rpow (by linarith : 0 ≤ P) (Real.exp_pos _).le, Real.rpow_def_of_pos (Real.exp_pos _), Real.log_exp]
  calc
    _ ≤ P * Real.exp (8 * alpha) * alpha ^ alpha := by
      have h1 := mul_le_mul_of_nonneg_left hfirst (by positivity : 0 ≤ 2 * K ^ 2 * Real.exp 2)
      have h2 := mul_le_mul_of_nonneg_left hsecond (by norm_num : (0 : ℝ) ≤ 2)
      dsimp [P]
      nlinarith
    _ ≤ P ^ alpha * Real.exp (8 * alpha) * alpha ^ alpha := by gcongr
    _ = _ := by rw [hid]

/-- The tiny-mean high block is absorbed by the same fixed reference baseline. -/
theorem high_tiny_normalized_budget {alpha T C D X R E0 u0 c E v : ℝ}
    (ha : 3 / 2 ≤ alpha) (hT : 0 ≤ T) (hC : 1 ≤ C) (hD : 1 ≤ D) (hX : 1 ≤ X)
    (hE0 : 0 < E0) (hu0 : 0 < u0) (hc : 0 ≤ c)
    (hR : Real.exp (3 * (Real.log C + c)) ≤ R)
    (hTbound : T ≤ C ^ alpha * alpha ^ alpha)
    (hE : E0 * (R / D) ^ (alpha - 1) ≤ E)
    (hv : u0 * Real.exp (-c * alpha) * X ^ (-alpha) ≤ v) :
    T * (D * alpha * X) ^ (-alpha) / (E * v) ≤ 1 / (E0 * u0 * D) := by
  have ha0 : 0 < alpha := by linarith
  have hD0 : 0 < D := zero_lt_one.trans_le hD
  have hX0 : 0 < X := zero_lt_one.trans_le hX
  have hR0 : 0 < R := (Real.exp_pos _).trans_le hR
  let Eref := E0 * (R / D) ^ (alpha - 1)
  let vref := u0 * Real.exp (-c * alpha) * X ^ (-alpha)
  have hEref : 0 < Eref := by dsimp [Eref]; positivity
  have hvref : 0 < vref := by dsimp [vref]; positivity
  have hEpos : 0 < E := hEref.trans_le hE
  have hvpos : 0 < v := hvref.trans_le hv
  have hden := mul_le_mul hE hv hvref.le hEpos.le
  have hfac := high_tiny_margin_factorization ha0 hD0 hX0 hR0 hE0 hu0 (c := c)
  have hTnorm : T * alpha ^ (-alpha) ≤ C ^ alpha := by
    apply (mul_le_mul_of_nonneg_right hTbound (Real.rpow_nonneg ha0.le _)).trans_eq
    rw [mul_assoc, ← Real.rpow_add ha0]
    simp
  have hcal := low_count_exponential_budget ha ha0.le (le_refl alpha) hC hc hR
  norm_num [div_self ha0.ne'] at hcal
  rw [show 1 - alpha = -(alpha - 1) by ring] at hcal
  calc
    _ ≤ T * (D * alpha * X) ^ (-alpha) / (Eref * vref) :=
      div_le_div_of_nonneg_left (by positivity) (mul_pos hEref hvref) hden
    _ = (T * alpha ^ (-alpha)) * R ^ (-(alpha - 1)) * Real.exp (c * alpha) / (E0 * u0 * D) := by
      have h := congrArg (fun z : ℝ => T * z) hfac
      convert h using 1 <;> dsimp [Eref, vref] <;> ring
    _ ≤ (C ^ alpha * R ^ (-(alpha - 1)) * Real.exp (c * alpha)) / (E0 * u0 * D) := by
      gcongr
    _ ≤ _ := div_le_div_of_nonneg_right hcal (by positivity)

def highMediumExponentialConstant (CL Cmed Ct cb : ℝ) : ℝ :=
  max 1 (cb * (CL + 1) * Real.exp ((Cmed + Ct) * (CL + 1)))

/-- The actual logarithmic cutoff controls the medium/large high block, with D chosen last. -/
theorem high_medium_normalized_budget {alpha L T CL cL Cmed Ct cb D X R E0 c E w : ℝ}
    (ha : 3 / 2 ≤ alpha) (hL : L = (upperDegree alpha CL cL X : ℝ))
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hCmed : 0 ≤ Cmed) (hCt : 0 ≤ Ct) (hcb : 0 < cb)
    (_hT : 0 ≤ T) (hTbound : T ≤ Real.exp (Cmed * L)) (hD : 1 ≤ D) (hX : 1 ≤ X)
    (hE0 : 0 < E0) (hc : 0 ≤ c)
    (hsmall : cL * (Cmed + Ct + 1 / (CL + 1)) ≤ 1 / 2)
    (hR : Real.exp (3 * (Real.log (highMediumExponentialConstant CL Cmed Ct cb) + c)) ≤ R)
    (hE : E0 * (R / D) ^ (alpha - 1) ≤ E) (hw : Real.exp (-c * alpha) ≤ w) :
    T * (cb * L / (D * alpha * X)) ^ alpha / (E * w * Real.exp (-Ct * L)) ≤ 1 / (E0 * D) := by
  have ha0 : 0 < alpha := by linarith
  have ha1 : 1 < alpha := by linarith
  have hD0 : 0 < D := zero_lt_one.trans_le hD
  have hX0 : 0 < X := zero_lt_one.trans_le hX
  have hR0 : 0 < R := (Real.exp_pos _).trans_le hR
  have hLpos : 0 < L := by rw [hL]; exact_mod_cast upperDegree_pos ha1 hCL hcL hX
  let Eref := E0 * (R / D) ^ (alpha - 1)
  let F := cb * (CL + 1) * Real.exp ((Cmed + Ct) * (CL + 1))
  let C := highMediumExponentialConstant CL Cmed Ct cb
  have hEref : 0 < Eref := by dsimp [Eref]; positivity
  have hEpos : 0 < E := hEref.trans_le hE
  have hwpos : 0 < w := (Real.exp_pos _).trans_le hw
  have hden := mul_le_mul_of_nonneg_right (mul_le_mul hE hw (Real.exp_pos _).le hEpos.le)
    (Real.exp_pos (-Ct * L)).le
  have hfac := high_medium_margin_factorization ha0 hD0 hX0 hR0 hE0 hcb hLpos (c := c) (Ct := Ct)
  have hdegree := actual_degree_count_budget ha1 hCL hcL (add_nonneg hCmed hCt) hcb
    (by norm_num : (0 : ℝ) < 1) hX hsmall
  rw [← hL] at hdegree
  simp only [one_mul, div_one] at hdegree
  have hXpow : X ^ (-alpha / 2) ≤ 1 := Real.rpow_le_one_of_one_le_of_nonpos hX (by linarith)
  have hFpos : 0 < F := by dsimp [F]; positivity
  have hdegree' : Real.exp ((Cmed + Ct) * L) * (cb * L / (alpha * X)) ^ alpha ≤ C ^ alpha := by
    apply hdegree.trans
    apply (mul_le_mul_of_nonneg_left hXpow (Real.rpow_nonneg hFpos.le _)).trans
    rw [mul_one]
    exact Real.rpow_le_rpow hFpos.le (le_max_right _ _) ha0.le
  have hcal := low_count_exponential_budget ha ha0.le (le_refl alpha) (le_max_left 1 F) hc hR
  norm_num [div_self ha0.ne'] at hcal
  rw [show 1 - alpha = -(alpha - 1) by ring] at hcal
  calc
    _ ≤ Real.exp (Cmed * L) * (cb * L / (D * alpha * X)) ^ alpha /
        (Eref * Real.exp (-c * alpha) * Real.exp (-Ct * L)) :=
      div_le_div₀ (by positivity) (mul_le_mul_of_nonneg_right hTbound (by positivity))
        (by positivity) hden
    _ = (R ^ (-(alpha - 1)) * Real.exp (c * alpha) / (E0 * D)) *
        (Real.exp ((Cmed + Ct) * L) * (cb * L / (alpha * X)) ^ alpha) := by
      have h := congrArg (fun z : ℝ => Real.exp (Cmed * L) * z) hfac
      have he : Real.exp (Cmed * L) * Real.exp (Ct * L) = Real.exp ((Cmed + Ct) * L) := by
        rw [← Real.exp_add]
        congr 1
        ring
      calc
        _ = Real.exp (Cmed * L) * ((R ^ (-(alpha - 1)) * Real.exp (c * alpha) / (E0 * D)) *
            (Real.exp (Ct * L) * (cb * L / (alpha * X)) ^ alpha)) := by
          convert h using 1
          dsimp [Eref]
          ring
        _ = _ := by rw [← he]; ring
    _ ≤ (R ^ (-(alpha - 1)) * Real.exp (c * alpha) / (E0 * D)) * C ^ alpha := by gcongr
    _ ≤ _ := by
      have h := div_le_div_of_nonneg_right hcal (by positivity : 0 ≤ E0 * D)
      convert h using 1
      dsimp [C, F, highMediumExponentialConstant]
      ring

open scoped BigOperators

variable {ι : Type*} [Fintype ι]

def conditionalCountBonus (p : ι → ℝ) (alpha n L : ℝ) : ℝ :=
  ∑ i, p i ^ alpha * min (L * (n * p i)) 1

def powerSumAboveMean (p : ι → ℝ) (alpha n tau : ℝ) : ℝ :=
  ∑ i, if tau < n * p i then p i ^ alpha else 0

lemma conditionalCountBonus_nonneg (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) {alpha n L : ℝ}
    (hn : 0 ≤ n) (hL : 0 ≤ L) : 0 ≤ conditionalCountBonus p alpha n L := by
  exact Finset.sum_nonneg (fun i _ => mul_nonneg (Real.rpow_nonneg (hp i) _)
    (le_min (mul_nonneg hL (mul_nonneg hn (hp i))) (by norm_num)))

lemma powerSumAboveMean_nonneg (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) (alpha n tau : ℝ) :
    0 ≤ powerSumAboveMean p alpha n tau := by
  apply Finset.sum_nonneg
  intro i _
  split_ifs <;> first | positivity | exact Real.rpow_nonneg (hp i) _

/-- The source count bonus controls precisely the coordinates above the exponential split. -/
theorem count_bonus_dominates_large_mean_power (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    {alpha n L tau : ℝ} (hn : 0 ≤ n) (hL : 1 ≤ L) (_htau : 0 ≤ tau) (htau1 : tau ≤ 1) :
    tau * powerSumAboveMean p alpha n tau ≤ conditionalCountBonus p alpha n L := by
  unfold powerSumAboveMean conditionalCountBonus
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i _
  split_ifs with hi
  · have hnpi : 0 ≤ n * p i := mul_nonneg hn (hp i)
    have hscale : tau ≤ L * (n * p i) := by
      nlinarith [mul_le_mul_of_nonneg_right hL hnpi]
    have hmin : tau ≤ min (L * (n * p i)) 1 := le_min hscale htau1
    nlinarith [mul_le_mul_of_nonneg_left hmin (Real.rpow_nonneg (hp i) alpha)]
  · have hmin : 0 ≤ min (L * (n * p i)) 1 :=
      le_min (mul_nonneg (by linarith : 0 ≤ L) (mul_nonneg hn (hp i))) (by norm_num)
    nlinarith [mul_nonneg (Real.rpow_nonneg (hp i) alpha) hmin]

/-- Normalize an actual two-component high-count bound by the full reference margin. -/
theorem high_count_two_component_margin (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    {V alpha n L tau E kappa u tiny medium b : ℝ}
    (hk : (0 : ℝ) < Fintype.card ι) (hn : 0 < n) (hL : 1 ≤ L)
    (htau : 0 < tau) (htau1 : tau ≤ 1) (hE : 0 < E) (hkappa : 0 < kappa) (hu : 0 < u)
    (htiny : 0 ≤ tiny) (hmedium : 0 ≤ medium) (hb : 0 < b)
    (hV : V ≤ tiny * n ^ (-alpha) * (∑ i, p i ^ alpha) +
      medium * b ^ alpha * powerSumAboveMean p alpha n tau) :
    V / (E * (Fintype.card ι : ℝ) ^ (1 - alpha) + kappa * u * (∑ i, p i ^ alpha) +
      kappa * conditionalCountBonus p alpha n L) ^ 2 ≤
      (tiny * n ^ (-alpha) / (Fintype.card ι : ℝ) ^ (1 - alpha)) / (E * (kappa * u)) +
      (medium * b ^ alpha / (Fintype.card ι : ℝ) ^ (1 - alpha)) / (E * kappa * tau) := by
  let Pstar := (Fintype.card ι : ℝ) ^ (1 - alpha)
  let P := ∑ i, p i ^ alpha
  let A := P / Pstar
  let Agt := powerSumAboveMean p alpha n tau / Pstar
  let Bonus := conditionalCountBonus p alpha n L / Pstar
  have hPstar : 0 < Pstar := Real.rpow_pos_of_pos hk _
  have hP : 0 ≤ P := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (hp i) _)
  have hA : 0 ≤ A := div_nonneg hP hPstar.le
  have hAgt : 0 ≤ Agt := div_nonneg (powerSumAboveMean_nonneg p hp _ _ _) hPstar.le
  have hBonus : 0 ≤ Bonus := div_nonneg (conditionalCountBonus_nonneg p hp hn.le (by linarith)) hPstar.le
  have hbonus : tau * Agt ≤ Bonus := by
    have h := div_le_div_of_nonneg_right (count_bonus_dominates_large_mean_power (alpha := alpha) p hp hn.le hL htau.le htau1) hPstar.le
    convert h using 1
    dsimp [Agt, Bonus]
    ring
  have hVnorm : V / Pstar ^ 2 ≤ (tiny * n ^ (-alpha) / Pstar) * A + (medium * b ^ alpha / Pstar) * Agt := by
    apply (div_le_div_of_nonneg_right hV (sq_nonneg _)).trans_eq
    dsimp [A, Agt, P]
    field_simp
  have h := high_block_affine_margin_bound hE (mul_pos hkappa hu) hkappa htau hA hAgt hBonus
    (by positivity : 0 ≤ tiny * n ^ (-alpha) / Pstar) (by positivity : 0 ≤ medium * b ^ alpha / Pstar) hbonus hVnorm
  convert h using 1
  dsimp [A, Bonus, P, Pstar]
  field_simp

/-- Transport the actual selected count-moment bound into probability units. -/
theorem high_count_probability_units (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) (lam : ι → ℝ≥0)
    {alpha n b tau tiny medium : ℝ} (hn : 0 < n) (hb : 0 < b)
    (hlam : ∀ i, (lam i : ℝ) = n * p i) :
    n ^ (-2 * alpha) * (tiny * (∑ i, (lam i : ℝ) ^ alpha) + medium * (n * b) ^ alpha *
      ∑ i, if tau < (lam i : ℝ) then (lam i : ℝ) ^ alpha else 0) =
    tiny * n ^ (-alpha) * (∑ i, p i ^ alpha) + medium * b ^ alpha * powerSumAboveMean p alpha n tau := by
  have hsum : (∑ i, (lam i : ℝ) ^ alpha) = n ^ alpha * (∑ i, p i ^ alpha) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    rw [hlam, Real.mul_rpow hn.le (hp i)]
  have hselected : (∑ i, if tau < (lam i : ℝ) then (lam i : ℝ) ^ alpha else 0) =
      n ^ alpha * powerSumAboveMean p alpha n tau := by
    unfold powerSumAboveMean
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    rw [hlam]
    by_cases hi : tau < n * p i
    · simp only [if_pos hi, Real.mul_rpow hn.le (hp i)]
    · simp only [if_neg hi, mul_zero]
  have hsmall : n ^ (-2 * alpha) * n ^ alpha = n ^ (-alpha) := by
    rw [← Real.rpow_add hn]
    congr 1
    ring
  have hlarge : n ^ (-2 * alpha) * (n * b) ^ alpha * n ^ alpha = b ^ alpha := by
    rw [Real.mul_rpow hn.le hb.le]
    calc
      _ = (n ^ (-2 * alpha) * n ^ alpha * n ^ alpha) * b ^ alpha := by ring
      _ = _ := by rw [hsmall, ← Real.rpow_add hn]; simp
  rw [hsum, hselected]
  calc
    _ = tiny * (n ^ (-2 * alpha) * n ^ alpha) * (∑ i, p i ^ alpha) +
        medium * (n ^ (-2 * alpha) * (n * b) ^ alpha * n ^ alpha) * powerSumAboveMean p alpha n tau := by ring
    _ = _ := by rw [hsmall, hlarge]

/-- Full high-count margin calibration for an actual tiny/medium probability-unit bound. -/
theorem high_count_two_component_calibrated (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    {V alpha n b L E kappa u tiny medium CL cL Cmed Ct cb D X R E0 u0 c Ctiny : ℝ}
    (hk : (0 : ℝ) < Fintype.card ι) (ha : 3 / 2 ≤ alpha)
    (hL : L = (upperDegree alpha CL cL X : ℝ)) (hCL : 1 ≤ CL) (hcL : 0 < cL)
    (hCmed : 0 ≤ Cmed) (hCt : 0 ≤ Ct) (hcb : 0 < cb) (hCtiny : 1 ≤ Ctiny)
    (htiny : 0 ≤ tiny) (hmedium : 0 ≤ medium)
    (htinybound : tiny ≤ Ctiny ^ alpha * alpha ^ alpha) (hmediumbound : medium ≤ Real.exp (Cmed * L))
    (hD : 1 ≤ D) (hX : 1 ≤ X) (hE0 : 0 < E0) (hu0 : 0 < u0) (hc : 0 ≤ c)
    (hsmall : cL * (Cmed + Ct + 1 / (CL + 1)) ≤ 1 / 2)
    (hRtiny : Real.exp (3 * (Real.log Ctiny + c)) ≤ R)
    (hRmedium : Real.exp (3 * (Real.log (highMediumExponentialConstant CL Cmed Ct cb) + c)) ≤ R)
    (hE : E0 * (R / D) ^ (alpha - 1) ≤ E) (hkappa : Real.exp (-c * alpha) ≤ kappa)
    (hu : u0 * X ^ (-alpha) ≤ u)
    (hnsize : n = D * alpha * (Fintype.card ι : ℝ) ^ (1 - 1 / alpha) * X) (hnb : n * b = cb * L)
    (hV : V ≤ tiny * n ^ (-alpha) * (∑ i, p i ^ alpha) +
      medium * b ^ alpha * powerSumAboveMean p alpha n (Real.exp (-Ct * L))) :
    V / (E * (Fintype.card ι : ℝ) ^ (1 - alpha) + kappa * u * (∑ i, p i ^ alpha) +
      kappa * conditionalCountBonus p alpha n L) ^ 2 ≤ (1 / (E0 * u0) + 1 / E0) / D := by
  have ha0 : 0 < alpha := by linarith
  have ha1 : 1 < alpha := by linarith
  have hD0 : 0 < D := zero_lt_one.trans_le hD
  have hX0 : 0 < X := zero_lt_one.trans_le hX
  have hn : 0 < n := by rw [hnsize]; positivity
  have hLpos : 0 < L := by rw [hL]; exact_mod_cast upperDegree_pos ha1 hCL hcL hX
  have hLone : 1 ≤ L := by rw [hL]; exact_mod_cast upperDegree_pos ha1 hCL hcL hX
  have hb : 0 < b := by
    have h : 0 < n * b := by rw [hnb]; positivity
    exact (mul_pos_iff_of_pos_left hn).mp h
  have hR0 : 0 < R := (Real.exp_pos _).trans_le hRtiny
  have hEpos : 0 < E := (by positivity : 0 < E0 * (R / D) ^ (alpha - 1)).trans_le hE
  have hkappapos : 0 < kappa := (Real.exp_pos _).trans_le hkappa
  have hupos : 0 < u := (by positivity : 0 < u0 * X ^ (-alpha)).trans_le hu
  have hvref : u0 * Real.exp (-c * alpha) * X ^ (-alpha) ≤ kappa * u := by
    have h := mul_le_mul hkappa hu (by positivity) hkappapos.le
    convert h using 1
    ring
  have htau1 : Real.exp (-Ct * L) ≤ 1 := Real.exp_le_one_iff.mpr (by nlinarith)
  have hmargin := high_count_two_component_margin p hp hk hn hLone (Real.exp_pos _) htau1 hEpos
    hkappapos hupos htiny hmedium hb hV
  have hnnormal : n ^ (-alpha) / (Fintype.card ι : ℝ) ^ (1 - alpha) = (D * alpha * X) ^ (-alpha) := by
    rw [hnsize]
    exact high_count_sample_normalization hk ha0 hD0 hX0
  have hbexpr : b = cb * L / (D * alpha * (Fintype.card ι : ℝ) ^ (1 - 1 / alpha) * X) := by
    rw [← hnsize]
    apply (eq_div_iff hn.ne').mpr
    nlinarith [hnb]
  have hbnormal : b ^ alpha / (Fintype.card ι : ℝ) ^ (1 - alpha) = (cb * L / (D * alpha * X)) ^ alpha := by
    rw [hbexpr]
    exact high_count_cutoff_normalization hk ha0 hD0 hX0 hcb hLpos
  have hs : tiny * n ^ (-alpha) / (Fintype.card ι : ℝ) ^ (1 - alpha) = tiny * (D * alpha * X) ^ (-alpha) := by
    rw [mul_div_assoc, hnnormal]
  have ht : medium * b ^ alpha / (Fintype.card ι : ℝ) ^ (1 - alpha) = medium * (cb * L / (D * alpha * X)) ^ alpha := by
    rw [mul_div_assoc, hbnormal]
  rw [hs, ht] at hmargin
  have hsmallpart := high_tiny_normalized_budget ha htiny hCtiny hD hX hE0 hu0 hc hRtiny htinybound hE hvref
  have hlargepart := high_medium_normalized_budget ha hL hCL hcL hCmed hCt hcb hmedium hmediumbound
    hD hX hE0 hc hsmall hRmedium hE hkappa
  apply hmargin.trans
  apply (add_le_add hsmallpart hlargepart).trans_eq
  field_simp

end Renyi
