import Renyi.DegreeOneLowBounds

/-! Complete deterministic strict upper margin for the actual degree-one completion.
The high profile and cutoff are the same as in the Chebyshev branch. -/
noncomputable section
namespace Renyi.DegreeOneCompletion

theorem coupledProfiles_product_le {ℓ N : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    {γ fL f ω x y z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hω : 0 ≤ ω) (hω1 : ω < 1) (hx : 0 ≤ x) (hx1 : x ≤ 1)
    (hy : 0 ≤ y) (hy1 : y ≤ 1) (hz : 0 < z)
    (hcap : x*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    (lowProfile ℓ γ fL x)^(1-γ) * (highProfile N (1-γ) f ω y)^γ ≤ z := by
  have hd : 0 < 1-γ := by linarith
  have hu := lowProfile_upper_power hℓ hγ hγ1.le hfL hfL1 hx hx1
  have hv := highProfile_upper_power hN hd (by linarith) hf hf1 hω hω1 hy hy1
  have hu0 := (lowProfile_range hℓ hγ hfL hfL1 hx hx1).1
  have hv0 := (highProfile_range hN hd hf hf1 hω hω1 hy hy1).1
  have hup := Real.rpow_le_rpow hu0 hu hd.le
  have hvp := Real.rpow_le_rpow hv0 hv hγ.le
  have hp := mul_le_mul hup hvp (Real.rpow_nonneg hv0 γ)
    (Real.rpow_nonneg (by positivity) (1-γ))
  exact hp.trans (coupled_power_product_le hγ hγ1 (by positivity) (by positivity) hz hcap)

/-- The manuscript's exact scalar upper envelope now applies to the actual profiles. -/
theorem coupledProfiles_scalar_upper {ℓ N : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    {γ fL f ω x y z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hω : 0 ≤ ω) (hω1 : ω < 1) (hx : 0 ≤ x) (hx1 : x ≤ 1)
    (hy : 0 ≤ y) (hy1 : y ≤ 1) (hz : 0 < z) (hz1 : z < 1)
    (hcap : x*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    overlapA γ z*lowProfile ℓ γ fL x + overlapB γ z*highProfile N (1-γ) f ω y ≤ 1 := by
  apply (overlap_maximum hγ hγ1 hz hz1).1
    (lowProfile ℓ γ fL x) (lowProfile_range hℓ hγ hfL hfL1 hx hx1)
    (highProfile N (1-γ) f ω y) (highProfile_range hN (by linarith) hf hf1 hω hω1 hy hy1)
  exact coupledProfiles_product_le hℓ hN hγ hγ1 hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hz hcap



def coupledDampedExpression (ℓ N : ℕ) (γ z M ω fL f x y : ℝ) : ℝ :=
  (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+
  (overlapB γ z*Real.exp (-M*(1-γ)))*highProfile N (1-γ) f ω y+
  ω*(1-overlapB γ z*Real.exp (-M*(1-γ)))*endpointProfile N 6 (1-γ) y

lemma cutoff_convex_upper {a b u v ω H J r e : ℝ}
    (hH : 0≤H) (hH1 : H≤1) (hb : 0≤b) (hb1 : b≤1)
    (hv1 : v≤1) (hω : 0≤ω) (hS : a*u+b*v≤r) (hJH : J-H≤e) :
    a*u*(1-H)+b*v+ω*(1-b)*J ≤
      max r (ω+(1-ω)*b)+ω*(1-b)*e := by
  have hR : b*v+ω*(1-b)≤ω+(1-ω)*b := by
    have hm := mul_le_mul_of_nonneg_left hv1 hb
    nlinarith only [hm]
  have hm1 := mul_le_mul_of_nonneg_left (hS.trans (le_max_left r (ω+(1-ω)*b))) (sub_nonneg.mpr hH1)
  have hm2 := mul_le_mul_of_nonneg_left (hR.trans (le_max_right r (ω+(1-ω)*b))) hH
  have hm3 := mul_le_mul_of_nonneg_left hJH (mul_nonneg hω (sub_nonneg.mpr hb1))
  nlinarith only [hm1,hm2,hm3]

lemma damped_overlap_upper {A B u v γ M : ℝ} (_hγ : 0<γ) (_hγ1 : γ<1)
    (hM : 0≤M) (hA : 0≤A) (hB : 0≤B) (hu : 0≤u) (hv : 0≤v)
    (hlin : A*u+B*v≤1) :
    (A*Real.exp (-M*γ))*u+(B*Real.exp (-M*(1-γ)))*v ≤
      Real.exp (-M*min γ (1-γ)) := by
  have he1 := Real.exp_le_exp.mpr
    (neg_le_neg (mul_le_mul_of_nonneg_left (min_le_left γ (1-γ)) hM))
  have he2 := Real.exp_le_exp.mpr
    (neg_le_neg (mul_le_mul_of_nonneg_left (min_le_right γ (1-γ)) hM))
  simp only [←neg_mul] at he1 he2
  have hm1 := mul_le_mul_of_nonneg_right he1 (mul_nonneg hA hu)
  have hm2 := mul_le_mul_of_nonneg_right he2 (mul_nonneg hB hv)
  have hm3 := mul_le_mul_of_nonneg_left hlin (Real.exp_pos (-M*min γ (1-γ))).le
  nlinarith only [hm1,hm2,hm3]

/-- The only cutoff price in the actual upper envelope is the proven J_delta-J_1 difference. -/
theorem coupledProfiles_cutoff_upper {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z M ω fL f x y : ℝ} (hγ : 0<γ) (hγhalf : γ≤1/2) (hM : 0≤M)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hω1 : ω<1) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hz1 : z<1)
    (hcap : x*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y ≤
      max (Real.exp (-M*γ)) (ω+(1-ω)*(overlapB γ z*Real.exp (-M*(1-γ))))+
      ω*(1-overlapB γ z*Real.exp (-M*(1-γ)))*(40*Real.exp (Real.log 12+1))*γ := by
  have hγ1 : γ<1 := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hlin := coupledProfiles_scalar_upper hℓ hN hγ hγ1 hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hz hz1 hcap
  have hdamp := damped_overlap_upper hγ hγ1 hM hc.1.le hc.2.2.1.le hu.1 hv.1 hlin
  rw [min_eq_left (by linarith only [hγhalf] : γ≤1-γ)] at hdamp
  have hb0 : 0≤overlapB γ z*Real.exp (-M*(1-γ)) := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have hb1 : overlapB γ z*Real.exp (-M*(1-γ))≤1 := by
    exact (mul_le_of_le_one_right hc.2.2.1.le (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hd]))).trans hc.2.2.2.le
  have hdiff := (endpointProfile_order_one_comparison hN (by norm_num : 2≤6) (by norm_num : 6≤6)
    (by linarith only [hγhalf] : (1:ℝ)/2≤1-γ) (by linarith only [hγ] : 1-γ≤1) hy hy1).2
  have hdiff' : endpointProfile N 6 (1-γ) y-endpointProfile N 6 1 y≤(40*Real.exp (Real.log 12+1))*γ := by
    convert hdiff using 1; ring
  have h := cutoff_convex_upper hH.1 hH.2 hb0 hb1 hv.2 hω hdamp hdiff'
  unfold coupledDampedExpression
  nlinarith only [h]

/-- An explicit strict linear gap for fractional parts close to zero. -/
theorem coupledProfiles_small_fraction_upper_gap {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z M ω ρ fL f x y : ℝ} (hγ : 0<γ) (hγhalf : γ≤1/2)
    (hM2 : 2≤M) (hMC : 4*(40*Real.exp (Real.log 12+1))≤M)
    (hρ : 0<ρ) (hρ1 : ρ≤1) (hscale : M*γ≤ρ)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωρ : ω≤1-ρ) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hz1 : z<1)
    (hcap : x*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y ≤ 1-M*γ/4 := by
  have hM : 0≤M := by linarith only [hM2]
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hγ1 : γ<1 := by linarith only [hγhalf]
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := coupledProfiles_cutoff_upper hℓ hN hγ hγhalf hM hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hz hz1 hcap
  have hMγ : 0≤M*γ := mul_nonneg hM hγ.le
  have he1 : Real.exp (-M*γ)≤1-M*γ/2 := by
    simpa only [neg_mul] using exp_neg_le_linear_half hMγ (hscale.trans hρ1)
  have he2 : Real.exp (-M*(1-γ))≤(1:ℝ)/2 := by
    rw [show -M*(1-γ)=-(M*(1-γ)) by ring,Real.exp_neg]
    have hh : 2≤Real.exp (M*(1-γ)) := by
      have he := Real.add_one_le_exp (M*(1-γ))
      nlinarith only [he,mul_nonneg (by linarith only [hM2] : 0≤M-2) (by linarith only [hγhalf] : 0≤1-γ),hγhalf]
    simpa only [one_div] using one_div_le_one_div_of_le (by norm_num : (0:ℝ)<2) hh
  have hb : overlapB γ z*Real.exp (-M*(1-γ))≤(1:ℝ)/2 :=
    (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans he2
  have hb0 : 0≤overlapB γ z*Real.exp (-M*(1-γ)) := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have hr : ω+(1-ω)*(overlapB γ z*Real.exp (-M*(1-γ)))≤1-M*γ/2 := by
    have hm := mul_le_mul_of_nonneg_left hb (sub_nonneg.mpr hω1.le)
    nlinarith only [hm,hωρ,hscale]
  have hmax := max_le he1 hr
  have hecoef : ω*(1-overlapB γ z*Real.exp (-M*(1-γ)))≤1 := by
    have hm := mul_le_mul_of_nonneg_left (show 1-overlapB γ z*Real.exp (-M*(1-γ))≤1 by linarith only [hb0]) hω
    nlinarith only [hm,hω1]
  have herr := mul_le_mul_of_nonneg_right hecoef
    (show 0≤(40*Real.exp (Real.log 12+1))*γ by positivity)
  have hCM := mul_le_mul_of_nonneg_right hMC hγ.le
  nlinarith only [hu,hmax,herr,hCM]


lemma small_order_scaled_power_lower {δ c E : ℝ} (hδ : 0<δ) (hc : 0<c)
    (hroot : 8*Real.sqrt δ≤E) (hlog : 4*δ*(-Real.log c)≤E) :
    Real.exp (-E/2)≤(c*δ)^δ := by
  have hr := Real.sqrt_pos.mpr hδ
  have hh := Real.one_sub_inv_le_log_of_pos hr
  have hm := mul_le_mul_of_nonneg_left hh (show 0≤2*δ by positivity)
  have hid : δ*(Real.sqrt δ)⁻¹=Real.sqrt δ := by
    apply (mul_right_cancel₀ hr.ne')
    rw [mul_assoc,inv_mul_cancel₀ hr.ne',mul_one,←pow_two,Real.sq_sqrt hδ.le]
  rw [Real.log_sqrt hδ.le] at hm
  have hlogδ : -2*Real.sqrt δ≤δ*Real.log δ := by nlinarith only [hm,hid,hδ]
  rw [Real.rpow_def_of_pos (mul_pos hc hδ),Real.log_mul hc.ne' hδ.ne']
  apply Real.exp_le_exp.mpr
  nlinarith only [hlogδ,hroot,hlog]

lemma product_high_separation {u v γ z E c : ℝ}
    (_hγ : 0<γ) (hγ1 : γ<1) (hu : c≤u) (hc : 0<c)
    (hv : 0≤v) (hv1 : v≤1) (hpow : Real.exp (-E/2)≤c^(1-γ))
    (hprod : u^(1-γ)*v^γ≤z) (hz : z≤Real.exp (-E)) :
    v≤Real.exp (-E/2) := by
  have hd : 0≤1-γ := by linarith only [hγ1]
  have hp := hpow.trans (Real.rpow_le_rpow hc.le hu hd)
  have hm := (mul_le_mul_of_nonneg_right hp (Real.rpow_nonneg hv γ)).trans (hprod.trans hz)
  have hquot : v^γ≤Real.exp (-E/2) := by
    apply (mul_le_mul_iff_right₀ (Real.exp_pos (-E/2))).mp
    have heq : Real.exp (-E/2)*Real.exp (-E/2)=Real.exp (-E) := by
      rw [←Real.exp_add];congr 1;ring
    rw [heq]
    simpa only [mul_comm] using hm
  by_cases hv0 : v=0
  · rw [hv0];exact (Real.exp_pos _).le
  have hvp : 0<v := lt_of_le_of_ne hv (Ne.symm hv0)
  have hself := Real.rpow_le_rpow_of_exponent_ge hvp hv1 hγ1.le
  rw [Real.rpow_one] at hself
  exact hself.trans hquot

/-- A strict linear gap near fractional part one, with an explicit small-order threshold. -/
theorem coupledProfiles_small_complement_upper_gap {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z E M ω ρ fL f x y : ℝ} (hγhalf : (1:ℝ)/2≤γ) (hγ1 : γ<1)
    (hM : 1≤M) (hρ : 0<ρ) (_hρ1 : ρ≤1)
    (hMρ : Real.exp (-M/2)≤ρ/2) (hEρ : Real.exp (-E/2)≤1-ρ)
    (hroot : 8*Real.sqrt (1-γ)≤E) (hlog : 4*(1-γ)*(-Real.log (ρ/4))≤E)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωρ : ω≤1-ρ) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hzE : z≤Real.exp (-E))
    (hcap : x*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y ≤1-ρ*(1-γ)/4 := by
  have hγ : 0<γ := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hM0 : 0≤M := by linarith only [hM]
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hE : 0<E := lt_of_lt_of_le (by positivity : 0<8*Real.sqrt (1-γ)) hroot
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hy hy1
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have hb1 : b≤1-(1-γ)/2 := by
    have he : Real.exp (-M*(1-γ))≤Real.exp (-(1-γ)) := Real.exp_le_exp.mpr (by nlinarith only [hM,hd])
    exact (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      (he.trans (exp_neg_le_linear_half hd.le hd1))
  have hb1' : b≤1 := by linarith only [hb1,hd]
  have ha1 : a≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM0,hγ]))
  have hT : coupledDampedExpression ℓ N γ z M ω fL f x y ≤
      a*lowProfile ℓ γ fL x+b*highProfile N (1-γ) f ω y+ω*(1-b) := by
    have hlow := mul_le_of_le_one_right (mul_nonneg ha0 hu.1) (by linarith only [hH.1] : 1-endpointProfile N 6 1 y≤1)
    have hlast := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hb1')) hJ.2
    unfold coupledDampedExpression
    change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+b*highProfile N (1-γ) f ω y+
      ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
    linarith only [hlow,hlast]
  by_cases hus : lowProfile ℓ γ fL x≤ρ*(1-γ)/4
  · have hlow := (mul_le_of_le_one_left hu.1 ha1).trans hus
    have hhigh := mul_le_mul_of_nonneg_left hv.2 hb0
    have hωb := mul_le_mul_of_nonneg_right hωρ (sub_nonneg.mpr hb1')
    have hgap := mul_le_mul_of_nonneg_left hb1 hρ.le
    nlinarith only [hT,hlow,hhigh,hωb,hgap]
  · have hp := small_order_scaled_power_lower hd (by positivity : 0<ρ/4) hroot hlog
    have hprod := coupledProfiles_product_le hℓ hN hγ hγ1 hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hz hcap
    have hcpos : 0<ρ*(1-γ)/4 := by positivity
    have hp' : Real.exp (-E/2)≤(ρ*(1-γ)/4)^(1-γ) := by convert hp using 1;congr 1;ring
    have hvsep := (product_high_separation hγ hγ1 (lt_of_not_ge hus).le hcpos hv.1 hv.2 hp' hprod hzE).trans hEρ
    have haρ : a≤ρ/2 := by
      apply (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
      apply le_trans _ hMρ
      apply Real.exp_le_exp.mpr
      nlinarith only [mul_le_mul_of_nonneg_left hγhalf hM0]
    have hlow := (mul_le_of_le_one_right ha0 hu.2).trans haρ
    have hhigh := mul_le_mul_of_nonneg_left hvsep hb0
    have hωb := mul_le_mul_of_nonneg_right hωρ (sub_nonneg.mpr hb1')
    have hrδ := mul_le_mul_of_nonneg_left hd1 hρ.le
    nlinarith only [hT,hlow,hhigh,hωb,hrδ,hρ]



/-- Fractional parts in a fixed interior interval have a fixed strict upper margin. -/
theorem coupledProfiles_interior_upper_gap {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z M ω ρ σ fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1)
    (hM : 0≤M) (hσγ : σ≤γ) (hσδ : σ≤1-γ)
    (hρ : 0<ρ) (hω : 0≤ω) (hωρ : ω≤1-ρ)
    (hsmall : Real.exp (-M*σ)≤ρ/4)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hz1 : z<1) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤1-ρ/2 := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hy hy1
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have ha : a≤ρ/4 := by
    exact (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
      ((Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_left hσγ hM])).trans hsmall)
  have hb : b≤ρ/4 := by
    exact (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      ((Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_left hσδ hM])).trans hsmall)
  have hb1 : b≤1 := by
    have hρ1 : ρ≤1 := by linarith only [hω,hωρ]
    linarith only [hb,hρ1]
  have hlow := (mul_le_of_le_one_right ha0 hu.2).trans ha
  have hlowcut := mul_le_of_le_one_right (mul_nonneg ha0 hu.1)
    (by linarith only [hH.1] : 1-endpointProfile N 6 1 y≤1)
  have hhigh := (mul_le_of_le_one_right hb0 hv.2).trans hb
  have hlast := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hb1)) hJ.2
  have hlastω := mul_le_of_le_one_right hω (by linarith only [hb0] : 1-b≤1)
  unfold coupledDampedExpression
  change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+
    b*highProfile N (1-γ) f ω y+ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
  nlinarith only [hlow,hlowcut,hhigh,hlast,hlastω,hωρ]

lemma fractional_power_min_linear {s y C q : ℝ} (hs : 0<s) (hs1 : s≤1)
    (hy : 0≤y) (hC : 0≤C) (hq : 0<q) :
    min q (Real.exp (-C))*min y 1≤min q (Real.exp (-C*s)*(y/s)^s) := by
  have hm0 : 0≤min y 1 := le_min hy (by norm_num)
  have hmq : min q (Real.exp (-C))≤q := min_le_left _ _
  have hme : min q (Real.exp (-C))≤Real.exp (-C) := min_le_right _ _
  have he : Real.exp (-C)≤Real.exp (-C*s) := Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_left hs1 hC])
  have hpow : min y 1≤(y/s)^s := by
    have hscale : y≤y/s := (le_div_iff₀ hs).mpr (mul_le_of_le_one_right hy hs1)
    by_cases hy1 : y≤1
    · rw [min_eq_left hy1]
      have hself : y≤y^s := by
        by_cases hy0 : y=0
        · rw [hy0,Real.zero_rpow hs.ne']
        · have hh := Real.rpow_le_rpow_of_exponent_ge (lt_of_le_of_ne hy (Ne.symm hy0)) hy1 hs1
          simpa only [Real.rpow_one] using hh
      exact hself.trans (Real.rpow_le_rpow hy hscale hs.le)
    · rw [min_eq_right (le_of_not_ge hy1)]
      exact Real.one_le_rpow (by linarith only [hscale,hy1] : 1≤y/s) hs.le
  apply le_min
  · exact (mul_le_of_le_one_right (le_min hq.le (Real.exp_pos _).le) (min_le_right _ _)).trans hmq
  · exact mul_le_mul (hme.trans he) hpow hm0 (Real.exp_pos _).le

lemma small_order_exp_div_linear {δ c E : ℝ} (hδ : 0<δ) (hc : 0<c)
    (hroot : 8*Real.sqrt δ≤E) (hlog : 4*δ*(-Real.log c)≤E) :
    Real.exp (-E/δ)≤c*δ := by
  have hp := small_order_scaled_power_lower hδ hc hroot hlog
  rw [Real.rpow_def_of_pos (mul_pos hc hδ)] at hp
  have he := Real.exp_le_exp.mp hp
  have hE : 0≤E := (by positivity : 0≤8*Real.sqrt δ).trans hroot
  apply (Real.le_log_iff_exp_le (mul_pos hc hδ)).mp
  apply (div_le_iff₀ hδ).mpr
  nlinarith only [he,hE]

/-- Exact capacity makes the actual reverse profile exponentially small past the high transition. -/
theorem lowProfile_capacity_outer_upper {ℓ : ℕ} (hℓ : 0<ℓ) {γ z E f x Y : ℝ}
    (hγ : 0<γ) (hγ1 : γ<1) (hf : 0≤f) (hf1 : f<1)
    (hx : 0≤x) (hx1 : x≤1) (hz : 0<z) (hzE : z≤Real.exp (-E))
    (hY : 1-γ≤Y)
    (hcap : x*Y≤Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    lowProfile ℓ γ f x≤Real.exp (-E/(1-γ)) := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hYp : 0<Y := hd.trans_le hY
  have hu := (lowProfile_upper_power hℓ hγ hγ1.le hf hf1 hx hx1).trans
    (reverse_capacity_power hγ hγ1 (by positivity) hYp hz hcap)
  have hquot := Real.rpow_le_one (div_nonneg hd.le hYp.le) ((div_le_one hYp).mpr hY) hγ.le
  have hzpow := Real.rpow_le_rpow hz.le hzE (one_div_pos.mpr hd).le
  rw [←Real.exp_mul] at hzpow
  have hid : -E*(1/(1-γ))=-E/(1-γ) := by ring
  rw [hid] at hzpow
  exact hu.trans ((mul_le_of_le_one_right (Real.rpow_nonneg hz.le _) hquot).trans hzpow)

/-- Spatial strict margin near fractional part one, outside the high transition neighborhood. -/
theorem coupledProfiles_complement_outer_spatial_gap {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z E M ω ρ fL f x y : ℝ} (hγhalf : (1:ℝ)/2≤γ) (hγ1 : γ<1)
    (hM : 1≤M) (hMd : M*(1-γ)≤1) (hρ : 0<ρ) (hρ1 : ρ≤1)
    (hroot : 8*Real.sqrt (1-γ)≤E) (hlog : 4*(1-γ)*(-Real.log (ρ/4))≤E)
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωρ : ω≤1-ρ) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hzE : z≤Real.exp (-E))
    (hsmall : 1-γ≤lowDeficitOrder (1-ρ))
    (hY : lowDeficitLocalScale (1-ρ)*(1-γ)≤(N:ℝ)^2*y)
    (hcap : x*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤1-
      (ρ/8)*(1-γ)-(Real.exp (-1)/2*lowDeficitConstant (1-ρ))*min ((N:ℝ)^2*y) 1-
      (ρ*lowProfileLinearConstant fL/8)*min x 1 := by
  have hγ : 0<γ := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hM0 : 0≤M := by linarith only [hM]
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hE : 0<E := lt_of_lt_of_le (by positivity : 0<8*Real.sqrt (1-γ)) hroot
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hcoef := overlap_coefficients hγ hγ1 hz hz1
  have hu := lowProfile_range (by omega : 0<ℓ) hγ hfL.le hfL1 hx hx1
  have hv := highProfile_range (by omega : 0<N) hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range (by omega : 0<N) (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range (by omega : 0<N) (by norm_num : 6≤6) hd hy hy1
  have hYd : 1-γ≤(N:ℝ)^2*y := by
    have hscale : 1≤lowDeficitLocalScale (1-ρ) := le_max_left _ _
    simpa only [one_mul] using (mul_le_mul_of_nonneg_right hscale hd.le).trans hY
  have hus := (lowProfile_capacity_outer_upper (by omega : 0<ℓ) hγ hγ1 hfL.le hfL1 hx hx1 hz hzE hYd hcap).trans
    (small_order_exp_div_linear hd (by positivity : 0<ρ/4) hroot hlog)
  have hus' : lowProfile ℓ γ fL x≤1-γ := by nlinarith only [hus,hρ1,hd]
  have hZ := (lowProfile_min_linear_lower hℓ hγ hγ1.le hfL hfL1 hx hx1).trans hus'
  have hvg := highProfile_deficit hN hd hd1 hf hf1 hω hωρ (by linarith only [hρ] : 1-ρ<1) hy hy1 hsmall hY
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have ha1 : a≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM0,hγ]))
  have hb1 : b≤1-(1-γ)/2 := by
    have he : Real.exp (-M*(1-γ))≤Real.exp (-(1-γ)) := Real.exp_le_exp.mpr (by nlinarith only [hM,hd])
    exact (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      (he.trans (exp_neg_le_linear_half hd.le hd1))
  have hb1' : b≤1 := by linarith only [hb1,hd]
  have hblow : Real.exp (-1)/2≤b := by
    have hbc : (1:ℝ)/2≤overlapB γ z := hγhalf.trans hcoef.2.le
    have he : Real.exp (-1)≤Real.exp (-M*(1-γ)) := Real.exp_le_exp.mpr (by nlinarith only [hMd])
    have hm := mul_le_mul hbc he (Real.exp_pos (-1)).le hc.2.2.1.le
    dsimp [b]
    nlinarith only [hm]
  have hlow := (mul_le_of_le_one_left hu.1 ha1).trans hus
  have hlowcut := mul_le_of_le_one_right (mul_nonneg ha0 hu.1)
    (by linarith only [hH.1] : 1-endpointProfile N 6 1 y≤1)
  have hhigh := mul_le_mul_of_nonneg_left hvg hb0
  have hhighgap := mul_le_mul_of_nonneg_right hblow
    (mul_nonneg (lowDeficitConstant_pos (by linarith only [hρ] : 1-ρ<1)).le
      (show 0≤min ((N:ℝ)^2*y) 1 from le_min (by positivity) (by norm_num)))
  have hlast := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hb1')) hJ.2
  have hlastω := mul_le_mul_of_nonneg_right hωρ (sub_nonneg.mpr hb1')
  have hδgap := mul_le_mul_of_nonneg_left hb1 hρ.le
  have hZgap := mul_le_mul_of_nonneg_left hZ (show 0≤ρ/8 by positivity)
  unfold coupledDampedExpression
  change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+
    b*highProfile N (1-γ) f ω y+ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
  nlinarith only [hlow,hlowcut,hhigh,hhighgap,hlast,hlastω,hδgap,hZgap]

/-- Product separation yields a fixed strict margin when the reverse profile exceeds the tiny-order scale. -/
theorem coupledProfiles_complement_separated_gap {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z E M ω ρ fL f x y : ℝ} (hγhalf : (1:ℝ)/2≤γ) (hγ1 : γ<1)
    (hM : 1≤M) (hρ : 0<ρ) (_hρ1 : ρ≤1)
    (hMρ : Real.exp (-M/2)≤ρ/2) (hEρ : Real.exp (-E/2)≤1-ρ)
    (hroot : 8*Real.sqrt (1-γ)≤E) (hlog : 4*(1-γ)*(-Real.log (ρ/4))≤E)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωρ : ω≤1-ρ) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hzE : z≤Real.exp (-E))
    (hus : ρ*(1-γ)/4<lowProfile ℓ γ fL x)
    (hcap : x*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y ≤1-ρ/2 := by
  have hγ : 0<γ := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hM0 : 0≤M := by linarith only [hM]
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hE : 0<E := lt_of_lt_of_le (by positivity : 0<8*Real.sqrt (1-γ)) hroot
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hy hy1
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have hb1 : b≤1-(1-γ)/2 := by
    have he : Real.exp (-M*(1-γ))≤Real.exp (-(1-γ)) := Real.exp_le_exp.mpr (by nlinarith only [hM,hd])
    exact (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      (he.trans (exp_neg_le_linear_half hd.le hd1))
  have hb1' : b≤1 := by linarith only [hb1,hd]
  have ha1 : a≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM0,hγ]))
  have hT : coupledDampedExpression ℓ N γ z M ω fL f x y ≤
      a*lowProfile ℓ γ fL x+b*highProfile N (1-γ) f ω y+ω*(1-b) := by
    have hlow := mul_le_of_le_one_right (mul_nonneg ha0 hu.1) (by linarith only [hH.1] : 1-endpointProfile N 6 1 y≤1)
    have hlast := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hb1')) hJ.2
    unfold coupledDampedExpression
    change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+b*highProfile N (1-γ) f ω y+
      ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
    linarith only [hlow,hlast]
  have hp := small_order_scaled_power_lower hd (by positivity : 0<ρ/4) hroot hlog
  have hprod := coupledProfiles_product_le hℓ hN hγ hγ1 hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hz hcap
  have hcpos : 0<ρ*(1-γ)/4 := by positivity
  have hp' : Real.exp (-E/2)≤(ρ*(1-γ)/4)^(1-γ) := by convert hp using 1;congr 1;ring
  have hvsep := (product_high_separation hγ hγ1 hus.le hcpos hv.1 hv.2 hp' hprod hzE).trans hEρ
  have haρ : a≤ρ/2 := by
    apply (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
    apply le_trans _ hMρ
    apply Real.exp_le_exp.mpr
    nlinarith only [mul_le_mul_of_nonneg_left hγhalf hM0]
  have hlow := (mul_le_of_le_one_right ha0 hu.2).trans haρ
  have hhigh := mul_le_mul_of_nonneg_left hvsep hb0
  have hωb := mul_le_mul_of_nonneg_right hωρ (sub_nonneg.mpr hb1')
  nlinarith only [hT,hlow,hhigh,hωb]

def complementMarginInnerConstant (f ρ : ℝ) : ℝ :=
  ρ*lowProfileLinearConstant f/(4*(lowProfileLinearConstant f*(1+lowDeficitLocalScale (1-ρ))+1))

def complementMarginConstant (f ρ : ℝ) : ℝ :=
  min (complementMarginInnerConstant f ρ)
    (min (ρ/6) (min (ρ/8)
      (min (Real.exp (-1)/2*lowDeficitConstant (1-ρ)) (ρ*lowProfileLinearConstant f/8))))

theorem complementMarginConstant_pos {f ρ : ℝ} (hf : 0<f) (hρ : 0<ρ) :
    0<complementMarginConstant f ρ := by
  have hc := lowProfileLinearConstant_pos hf
  have hD : 0<lowDeficitLocalScale (1-ρ) := zero_lt_one.trans_le (le_max_left _ _)
  have hg := lowDeficitConstant_pos (by linarith only [hρ] : 1-ρ<1)
  unfold complementMarginConstant complementMarginInnerConstant
  positivity

lemma three_margin_sum {T a b c d X Y Z : ℝ} (hX : 0≤X) (hY : 0≤Y) (hZ : 0≤Z)
    (ha : d≤a) (hb : d≤b) (hc : d≤c) (hT : T≤1-a*X-b*Y-c*Z) :
    T≤1-d*(X+Y+Z) := by
  have hx := mul_le_mul_of_nonneg_right ha hX
  have hy := mul_le_mul_of_nonneg_right hb hY
  have hz := mul_le_mul_of_nonneg_right hc hZ
  nlinarith only [hx,hy,hz,hT]

/-- Complete actual strict spatial margin for fractional parts close to one. -/
theorem coupledProfiles_complement_spatial_gap {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z E M ω ρ fL f x y : ℝ} (hγhalf : (1:ℝ)/2≤γ) (hγ1 : γ<1)
    (hM : 1≤M) (hMd : M*(1-γ)≤1) (hρ : 0<ρ) (hρ1 : ρ≤1)
    (hMρ : Real.exp (-M/2)≤ρ/2) (hEρ : Real.exp (-E/2)≤1-ρ)
    (hroot : 8*Real.sqrt (1-γ)≤E) (hlog : 4*(1-γ)*(-Real.log (ρ/4))≤E)
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωρ : ω≤1-ρ) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hzE : z≤Real.exp (-E)) (hsmall : 1-γ≤lowDeficitOrder (1-ρ))
    (hcap : x*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤1-complementMarginConstant fL ρ*
      ((1-γ)+min ((N:ℝ)^2*y) 1+min x 1) := by
  have hγ : 0<γ := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hY0 : 0≤min ((N:ℝ)^2*y) 1 := le_min (by positivity) (by norm_num)
  have hZ0 : 0≤min x 1 := le_min (by positivity) (by norm_num)
  have hc := (complementMarginConstant_pos hfL hρ).le
  by_cases houter : lowDeficitLocalScale (1-ρ)*(1-γ)≤(N:ℝ)^2*y
  · have hca : complementMarginConstant fL ρ≤ρ/8 := by
      unfold complementMarginConstant
      exact (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
    have hcb : complementMarginConstant fL ρ≤Real.exp (-1)/2*lowDeficitConstant (1-ρ) := by
      unfold complementMarginConstant
      exact (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _)))
    have hcc : complementMarginConstant fL ρ≤ρ*lowProfileLinearConstant fL/8 := by
      unfold complementMarginConstant
      exact (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _)))
    exact three_margin_sum hd.le hY0 hZ0 hca hcb hcc
      (coupledProfiles_complement_outer_spatial_gap hℓ hN hγhalf hγ1 hM hMd hρ hρ1 hroot hlog
        hfL hfL1 hf hf1 hω hωρ hx hx1 hy hy1 hz hzE hsmall houter hcap)
  by_cases hus : lowProfile ℓ γ fL x≤ρ*(1-γ)/4
  · have hbase := coupledProfiles_small_complement_upper_gap (by omega : 0<ℓ) (by omega : 0<N)
      hγhalf hγ1 hM hρ hρ1 hMρ hEρ hroot hlog hfL.le hfL1 hf hf1 hω hωρ hx hx1 hy hy1 hz hzE hcap
    have hY := (min_le_left ((N:ℝ)^2*y) 1).trans (le_of_lt (lt_of_not_ge houter))
    have hZ := (lowProfile_min_linear_lower hℓ hγ hγ1.le hfL hfL1 hx hx1).trans hus
    let L := lowProfileLinearConstant fL
    let D := lowDeficitLocalScale (1-ρ)
    let S := (1-γ)+min ((N:ℝ)^2*y) 1+min x 1
    have hL := lowProfileLinearConstant_pos hfL
    have hD : 0<D := zero_lt_one.trans_le (le_max_left _ _)
    have hZ' : L*min x 1≤1-γ := by dsimp [L];nlinarith only [hZ,hρ1,hd]
    have hYs := mul_le_mul_of_nonneg_left hY hL.le
    have hbudget : L*S≤(L*(1+D)+1)*(1-γ) := by dsimp [S];nlinarith only [hYs,hZ']
    have hcoef : complementMarginConstant fL ρ≤complementMarginInnerConstant fL ρ := min_le_left _ _
    have hmul := mul_le_mul_of_nonneg_left hbudget hc
    have hcoefmul := mul_le_mul_of_nonneg_right hcoef
      (mul_nonneg (show 0≤L*(1+D)+1 by positivity) hd.le)
    have hid : complementMarginInnerConstant fL ρ*(L*(1+D)+1)=ρ*L/4 := by
      have hden : 0<L*(1+D)+1 := by positivity
      change (ρ*L/(4*(L*(1+D)+1)))*(L*(1+D)+1)=ρ*L/4
      field_simp [ne_of_gt hden]
    simp only [←mul_assoc] at hcoefmul
    rw [hid] at hcoefmul
    have hfinal : complementMarginConstant fL ρ*S≤ρ*(1-γ)/4 := by
      apply (mul_le_mul_iff_right₀ hL).mp
      nlinarith only [hmul,hcoefmul]
    dsimp [S] at hfinal
    linarith only [hbase,hfinal]
  · have hsep := coupledProfiles_complement_separated_gap (by omega : 0<ℓ) (by omega : 0<N)
      hγhalf hγ1 hM hρ hρ1 hMρ hEρ hroot hlog hfL.le hfL1 hf hf1 hω hωρ hx hx1 hy hy1 hz hzE
      (lt_of_not_ge hus) hcap
    have hsum : (1-γ)+min ((N:ℝ)^2*y) 1+min x 1≤3 := by
      nlinarith only [min_le_right ((N:ℝ)^2*y) 1,min_le_right x 1,hγ]
    have hcoef : complementMarginConstant fL ρ≤ρ/6 := (min_le_right _ _).trans (min_le_left _ _)
    have hm := mul_le_mul_of_nonneg_left hsum hc
    nlinarith only [hsep,hm,hcoef]



def highProfileIntegralConstant (f : ℝ) : ℝ :=
  Real.exp (Real.log 12+289+Real.log (endpointReserveConstant f))

theorem highProfileIntegralConstant_pos (f : ℝ) : 0<highProfileIntegralConstant f := Real.exp_pos _

/-- The high profile controls its actual normalized primitive throughout the sharp endpoint range. -/
theorem highProfile_integral_local_comparison {N : ℕ} (hN : 2≤N) {s f ω x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : (N:ℝ)^2*x≤s) :
    endpointProfile N 6 s x≤highProfileIntegralConstant f*highProfile N s f ω x := by
  let Y := (N:ℝ)^2*x
  let C := Real.log (endpointReserveConstant f)+288
  let B := Real.log 12+1
  have hCf := endpointReserveConstant_pos hf1
  have hCf1 := endpointReserveConstant_one_le hf hf1
  have hC : 0≤C := by have hl := Real.log_nonneg hCf1;dsimp [C];linarith only [hl]
  have hB : 0≤B := by have hl := Real.log_nonneg (by norm_num : (1:ℝ)≤12);dsimp [B];linarith only [hl]
  have hY : 0≤Y := by dsimp [Y];positivity
  have hfirst := highProfile_local_lower hN hs hs1 hf hf1 hω hω1 hx hx1 hy
  rw [profile_rescaled_power hY hCf hs, mul_assoc, ←Real.exp_add] at hfirst
  have hexp : Real.exp (-C)≤Real.exp (-Real.log (endpointReserveConstant f)*s+-288*s) := by
    apply Real.exp_le_exp.mpr
    dsimp [C] at *
    nlinarith only [mul_le_mul_of_nonneg_left hs1 hC]
  have hYscale : Y≤Y/s := (le_div_iff₀ hs).mpr (mul_le_of_le_one_right hY hs1)
  have hp := Real.rpow_le_rpow hY hYscale hs.le
  have hm := mul_le_mul hp hexp (Real.exp_pos (-C)).le (Real.rpow_nonneg (div_nonneg hY hs.le) s)
  have hlower : Y^s*Real.exp (-C)≤highProfile N s f ω x := hm.trans hfirst
  have hraise := mul_le_mul_of_nonneg_left hlower (Real.exp_pos C).le
  have hid : Real.exp C*(Y^s*Real.exp (-C))=Y^s := by
    rw [mul_left_comm,←Real.exp_add,add_neg_cancel,Real.exp_zero,mul_one]
  rw [hid] at hraise
  have hJ := endpointProfile_upper_power (by omega : 0<N) (by norm_num : 6≤6) hs hx hx1
  have heB : Real.exp (B*s)≤Real.exp B := Real.exp_le_exp.mpr (mul_le_of_le_one_right hB hs1)
  have hJ' := hJ.trans (mul_le_mul_of_nonneg_right heB (Real.rpow_nonneg hY s))
  have hlast := hJ'.trans (mul_le_mul_of_nonneg_left hraise (Real.exp_pos B).le)
  have hconst : Real.exp B*Real.exp C=highProfileIntegralConstant f := by
    rw [←Real.exp_add]
    congr 1
    dsimp [B,C,highProfileIntegralConstant]
    ring
  simpa only [←mul_assoc,hconst] using hlast

/-- Uniformly on the half-order range, the actual high profile is at most a constant times sqrt(Y). -/
theorem highProfile_half_order_upper {N : ℕ} (hN : 0<N) {s f ω x : ℝ}
    (hs : (1:ℝ)/2≤s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f≤1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : (N:ℝ)^2*x≤1) :
    highProfile N s f ω x≤Real.exp (coupledProfileConstant+1)*Real.sqrt ((N:ℝ)^2*x) := by
  have hsp : 0<s := by linarith only [hs]
  have hY : 0≤(N:ℝ)^2*x := by positivity
  have hupper := highProfile_upper_power hN hsp hs1 hf hf1 hω hω1 hx hx1
  have hss := endpoint_self_power_lower hsp
  have hscale : (((N:ℝ)^2*x)/s)^s≤Real.exp 1*((N:ℝ)^2*x)^s := by
    rw [Real.div_rpow hY hsp.le]
    apply (div_le_iff₀ (Real.rpow_pos_of_pos hsp s)).mpr
    have he := mul_le_mul_of_nonneg_left hss (Real.exp_pos 1).le
    have hid : Real.exp 1*Real.exp (-1)=1 := by rw [←Real.exp_add];norm_num
    rw [hid] at he
    nlinarith only [mul_le_mul_of_nonneg_right he (Real.rpow_nonneg hY s)]
  have hpower : ((N:ℝ)^2*x)^s≤Real.sqrt ((N:ℝ)^2*x) := by
    rw [Real.sqrt_eq_rpow]
    by_cases hy0 : (N:ℝ)^2*x=0
    · rw [hy0,Real.zero_rpow hsp.ne',Real.zero_rpow (by norm_num : (1/(2:ℝ))≠0)]
    · exact Real.rpow_le_rpow_of_exponent_ge (lt_of_le_of_ne hY (Ne.symm hy0)) hy hs
  have hC : 0≤coupledProfileConstant := by have hl := Real.log_nonneg (by norm_num : (1:ℝ)≤24);unfold coupledProfileConstant;linarith only [hl]
  have he : Real.exp (coupledProfileConstant*s)≤Real.exp coupledProfileConstant :=
    Real.exp_le_exp.mpr (mul_le_of_le_one_right hC hs1)
  have hm := mul_le_mul he (hscale.trans (mul_le_mul_of_nonneg_left hpower (Real.exp_pos 1).le))
    (by positivity) (Real.exp_pos coupledProfileConstant).le
  have hid : Real.exp coupledProfileConstant*(Real.exp 1*Real.sqrt ((N:ℝ)^2*x))=
      Real.exp (coupledProfileConstant+1)*Real.sqrt ((N:ℝ)^2*x) := by rw [←mul_assoc,←Real.exp_add]
  exact hupper.trans (hm.trans_eq hid)

/-- Reverse capacity forces a fixed low-profile gap as soon as the forward scale exceeds gamma. -/
theorem lowProfile_capacity_fraction_outer {ℓ : ℕ} (hℓ : 0<ℓ) {γ z E f x Y : ℝ}
    (hγ : 0<γ) (hγ1 : γ<1) (hf : 0≤f) (hf1 : f<1)
    (hx : 0≤x) (hx1 : x≤1) (hz : 0<z) (hzE : z≤Real.exp (-E))
    (hY : γ≤Y) (hroot : 8*Real.sqrt γ≤E)
    (hcap : x*Y≤Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    lowProfile ℓ γ f x≤Real.exp (-E/2) := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hYp : 0<Y := hγ.trans_le hY
  have hE : 0≤E := (by positivity : 0≤8*Real.sqrt γ).trans hroot
  have hu0 := (lowProfile_range hℓ hγ hf hf1 hx hx1).1
  have hu := (lowProfile_upper_power hℓ hγ hγ1.le hf hf1 hx hx1).trans
    (reverse_capacity_power hγ hγ1 (by positivity) hYp hz hcap)
  have hp := Real.rpow_le_rpow hz.le hzE (one_div_pos.mpr hd).le
  rw [←Real.exp_mul] at hp
  rw [show -E*(1/(1-γ))=-E/(1-γ) by ring] at hp
  have hpe : z^(1/(1-γ))≤Real.exp (-E) := hp.trans (Real.exp_le_exp.mpr (by
    have h := (le_div_iff₀ hd).mpr (mul_le_of_le_one_right hE hd1)
    simpa only [neg_div] using neg_le_neg h))
  have hquot : ((1-γ)/Y)*γ≤1 := by
    have h := mul_le_mul_of_nonneg_left hY hd.le
    have hδY : (1-γ)*γ≤Y := h.trans (mul_le_of_le_one_left hYp.le hd1)
    calc
      _ = ((1-γ)*γ)/Y := by ring
      _ ≤ 1 := (div_le_one hYp).mpr hδY
  have hqp : ((1-γ)/Y)^γ*γ^γ≤1 := by
    rw [←Real.mul_rpow (div_nonneg hd.le hYp.le) hγ.le]
    exact Real.rpow_le_one (mul_nonneg (div_nonneg hd.le hYp.le) hγ.le) hquot hγ.le
  have hm := mul_le_mul_of_nonneg_right hu (Real.rpow_nonneg hγ.le γ)
  have hm' := mul_le_mul_of_nonneg_left hqp (Real.rpow_nonneg hz.le (1/(1-γ)))
  have hprod : lowProfile ℓ γ f x*γ^γ≤Real.exp (-E) := by nlinarith only [hm,hm',hpe]
  have hpow := small_order_scaled_power_lower hγ (by norm_num : (0:ℝ)<1) hroot
    (by simpa using hE : 4*γ*(-Real.log 1)≤E)
  simp only [one_mul] at hpow
  have hlow := mul_le_mul_of_nonneg_left hpow hu0
  apply (mul_le_mul_iff_right₀ (Real.exp_pos (-E/2))).mp
  have hid : Real.exp (-E/2)*Real.exp (-E/2)=Real.exp (-E) := by rw [←Real.exp_add];congr 1;ring
  rw [hid]
  nlinarith only [hprod,hlow]

/-- Actual near-zero-fraction expression outside its forward transition has a fixed strict gap. -/
theorem coupledProfiles_fraction_outer_gap {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z E M ω ρ fL f x y : ℝ} (hγ : 0<γ) (hγhalf : γ≤1/2) (hM : 0≤M)
    (hρ : 0<ρ) (hω : 0≤ω) (hωρ : ω≤1-ρ)
    (hMρ : Real.exp (-M/2)≤ρ/4) (hEρ : Real.exp (-E/2)≤1-ρ)
    (hroot : 8*Real.sqrt γ≤E) (herror : (40*Real.exp (Real.log 12+1))*γ≤ρ/4)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hzE : z≤Real.exp (-E)) (hY : γ≤(N:ℝ)^2*y)
    (hcap : x*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤1-ρ/2 := by
  have hγ1 : γ<1 := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hE : 0<E := lt_of_lt_of_le (by positivity : 0<8*Real.sqrt γ) hroot
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hlow := lowProfile_capacity_fraction_outer hℓ hγ hγ1 hfL hfL1 hx hx1 hz hzE hY hroot hcap
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have ha1 : a≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hγ]))
  have hb : b≤ρ/4 := by
    apply (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
    apply le_trans _ hMρ
    apply Real.exp_le_exp.mpr
    nlinarith only [mul_le_mul_of_nonneg_left hγhalf hM]
  have hb1 : b≤1 := by
    have hρ1 : ρ≤1 := by linarith only [hω,hωρ]
    linarith only [hb,hρ1]
  have hS : a*lowProfile ℓ γ fL x+b*highProfile N (1-γ) f ω y≤1-3*ρ/4 := by
    have hl := (mul_le_of_le_one_left hu.1 ha1).trans (hlow.trans hEρ)
    have hh := (mul_le_of_le_one_right hb0 hv.2).trans hb
    linarith only [hl,hh]
  have hR : ω+(1-ω)*b≤1-3*ρ/4 := by
    have hm := mul_le_of_le_one_left hb0 (by linarith only [hω] : 1-ω≤1)
    linarith only [hm,hb,hωρ]
  have hdiff := (endpointProfile_order_one_comparison hN (by norm_num : 2≤6) (by norm_num : 6≤6)
    (by linarith only [hγhalf] : (1:ℝ)/2≤1-γ) (by linarith only [hγ] : 1-γ≤1) hy hy1).2
  have hdiff' : endpointProfile N 6 (1-γ) y-endpointProfile N 6 1 y≤(40*Real.exp (Real.log 12+1))*γ := by
    convert hdiff using 1;ring
  have hcut := cutoff_convex_upper hH.1 hH.2 hb0 hb1 hv.2 hω hS hdiff'
  have hmax := max_le (le_refl (1-3*ρ/4)) hR
  have hcoef : ω*(1-b)≤1 := by
    have hm := mul_le_of_le_one_right hω (by linarith only [hb0] : 1-b≤1)
    linarith only [hm,hω1]
  have herr := mul_le_mul_of_nonneg_right hcoef (show 0≤(40*Real.exp (Real.log 12+1))*γ by positivity)
  unfold coupledDampedExpression
  change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+
    b*highProfile N (1-γ) f ω y+ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
  nlinarith only [hcut,hmax,herr,herror]

lemma product_exponential_separation {u v γ z E : ℝ}
    (hγ : 0<γ) (hγ1 : γ<1) (hE : 0≤E) (hu : Real.exp (-E/4)≤u)
    (hv : 0≤v) (hprod : u^(1-γ)*v^γ≤z) (hz : z≤Real.exp (-E)) :
    v≤Real.exp (-E/(2*γ)) := by
  have hd : 0≤1-γ := by linarith only [hγ1]
  have hp := Real.rpow_le_rpow (Real.exp_pos (-E/4)).le hu hd
  rw [←Real.exp_mul] at hp
  have hlow : Real.exp (-E/2)≤u^(1-γ) := by
    apply le_trans _ hp
    apply Real.exp_le_exp.mpr
    nlinarith only [hE,mul_nonneg hE hγ.le]
  have hm := (mul_le_mul_of_nonneg_right hlow (Real.rpow_nonneg hv γ)).trans (hprod.trans hz)
  have hpv : v^γ≤Real.exp (-E/2) := by
    apply (mul_le_mul_iff_right₀ (Real.exp_pos (-E/2))).mp
    have hid : Real.exp (-E/2)*Real.exp (-E/2)=Real.exp (-E) := by rw [←Real.exp_add];congr 1;ring
    rw [hid]
    exact hm
  by_cases hv0 : v=0
  · rw [hv0];exact (Real.exp_pos _).le
  have hvp : 0<v := lt_of_le_of_ne hv (Ne.symm hv0)
  rw [Real.rpow_def_of_pos hvp] at hpv
  have hlog := Real.exp_le_exp.mp hpv
  calc
    v = Real.exp (Real.log v) := (Real.exp_log hvp).symm
    _ ≤ Real.exp (-E/(2*γ)) := by
      apply Real.exp_le_exp.mpr
      rw [show -E/(2*γ)=(-E/2)/γ by ring]
      apply (le_div_iff₀ hγ).mpr
      nlinarith only [hlog]

/-- In the actual sharp forward neighborhood the cutoff expression is dominated by its low arm and v. -/
theorem coupledProfiles_fraction_local_upper {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 2≤N)
    {γ z M ω fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hM : 0≤M)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1)
    (hω : 0≤ω) (hω1 : ω<1) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hz1 : z<1) (hY : (N:ℝ)^2*y≤1-γ) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤
      Real.exp (-M*γ)*lowProfile ℓ γ fL x+
      (1+highProfileIntegralConstant f)*highProfile N (1-γ) f ω y := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range (by omega : 0<N) hd hf hf1.le hω hω1 hy hy1
  have hH := endpointProfile_range (by omega : 0<N) (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range (by omega : 0<N) (by norm_num : 6≤6) hd hy hy1
  have hcmp := highProfile_integral_local_comparison hN hd (by linarith only [hγ] : 1-γ≤1) hf hf1 hω hω1 hy hy1 hY
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have ha : a≤Real.exp (-M*γ) := mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le
  have hb : b≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hd]))
  have hlowcut := mul_le_of_le_one_right (mul_nonneg ha0 hu.1)
    (by linarith only [hH.1] : 1-endpointProfile N 6 1 y≤1)
  have hlow := mul_le_mul_of_nonneg_right ha hu.1
  have hhigh := mul_le_of_le_one_left hv.1 hb
  have hcoef : ω*(1-b)≤1 := (mul_le_of_le_one_right hω (by linarith only [hb0] : 1-b≤1)).trans hω1.le
  have hlast := (mul_le_of_le_one_left hJ.1 hcoef).trans hcmp
  unfold coupledDampedExpression
  change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+
    b*highProfile N (1-γ) f ω y+ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
  nlinarith only [hlowcut,hlow,hhigh,hlast]

def fractionSeparationLevel (E : ℝ) : ℝ := max (1/2) (Real.exp (-E/4))

def fractionMarginConstant (f ρ E : ℝ) : ℝ :=
  min (ρ/6) (min ((1-fractionSeparationLevel E)/6)
    (min (1/(8*(2+deficitScale f))) (min (1/16) (deficitConstant f))))

theorem fractionSeparationLevel_lt_one {E : ℝ} (hE : 0<E) : fractionSeparationLevel E<1 := by
  exact max_lt (by norm_num) (Real.exp_lt_one_iff.mpr (by linarith only [hE]))

theorem fractionMarginConstant_pos {f ρ E : ℝ} (hf1 : f<1) (hρ : 0<ρ) (hE : 0<E) :
    0<fractionMarginConstant f ρ E := by
  have hD : 0<deficitScale f := zero_lt_one.trans_le (le_max_left _ _)
  have hg := deficitConstant_pos hf1
  have hr := fractionSeparationLevel_lt_one hE
  have hrr : 0<1-fractionSeparationLevel E := sub_pos.mpr hr
  unfold fractionMarginConstant
  positivity

/-- Complete actual strict spatial margin for fractional parts close to zero. -/
theorem coupledProfiles_fraction_spatial_gap {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z E M ω ρ fL f x y : ℝ} (hγ : 0<γ) (hγhalf : γ≤1/2) (hM : 1≤M)
    (hρ : 0<ρ) (hω : 0≤ω) (hωρ : ω≤1-ρ)
    (hMρ : Real.exp (-M/2)≤ρ/4) (hEρ : Real.exp (-E/2)≤1-ρ)
    (hroot : 16*Real.sqrt γ≤E) (herror : (40*Real.exp (Real.log 12+1))*γ≤ρ/4)
    (hlog : 8*γ*(-Real.log (1/(8*(1+highProfileIntegralConstant f))))≤E)
    (hforward : (1+highProfileIntegralConstant f)*Real.exp (coupledProfileConstant+1)*Real.sqrt γ≤
      (1-fractionSeparationLevel E)/2)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hzE : z≤Real.exp (-E)) (hsmall : γ≤deficitOrder fL)
    (hcap : x*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤1-fractionMarginConstant fL ρ E*
      (γ+min ((N:ℝ)^2*y) 1+min x 1) := by
  have hγ1 : γ<1 := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hM0 : 0≤M := by linarith only [hM]
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hE : 0<E := lt_of_lt_of_le (by positivity : 0<16*Real.sqrt γ) hroot
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  have hc := (fractionMarginConstant_pos hfL1 hρ hE).le
  have hY0 : 0≤min ((N:ℝ)^2*y) 1 := le_min (by positivity) (by norm_num)
  have hZ0 : 0≤min x 1 := le_min (by positivity) (by norm_num)
  have hsum : γ+min ((N:ℝ)^2*y) 1+min x 1≤3 := by
    nlinarith only [min_le_right ((N:ℝ)^2*y) 1,min_le_right x 1,hγhalf]
  by_cases hY : γ≤(N:ℝ)^2*y
  · have hgap := coupledProfiles_fraction_outer_gap (by omega : 0<ℓ) (by omega : 0<N)
      hγ hγhalf hM0 hρ hω hωρ hMρ hEρ
      (by have h := Real.sqrt_nonneg γ;nlinarith only [hroot,h]) herror
      hfL hfL1 hf hf1.le hx hx1 hy hy1 hz hzE hY hcap
    have hcoef : fractionMarginConstant fL ρ E≤ρ/6 := min_le_left _ _
    have hm := mul_le_mul_of_nonneg_left hsum hc
    nlinarith only [hgap,hm,hcoef]
  have hYγ : (N:ℝ)^2*y≤γ := (lt_of_not_ge hY).le
  have hYδ : (N:ℝ)^2*y≤1-γ := by linarith only [hYγ,hγhalf]
  have hlocal := coupledProfiles_fraction_local_upper (by omega : 0<ℓ) hN hγ hγ1 hM0
    hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hz hz1 hYδ
  have hu := lowProfile_range (by omega : 0<ℓ) hγ hfL hfL1 hx hx1
  have hv := highProfile_range (by omega : 0<N) hd hf hf1.le hω hω1 hy hy1
  have hK : 0<1+highProfileIntegralConstant f := by have hp := highProfileIntegralConstant_pos f;linarith only [hp]
  by_cases hur : lowProfile ℓ γ fL x≤fractionSeparationLevel E
  · have hvsmall := highProfile_half_order_upper (by omega : 0<N)
      (by linarith only [hγhalf] : (1:ℝ)/2≤1-γ) (by linarith only [hγ] : 1-γ≤1)
      hf hf1.le hω hω1 hy hy1 (by linarith only [hYγ,hγhalf])
    have hsqrt := Real.sqrt_le_sqrt hYγ
    have hpower := (mul_le_mul_of_nonneg_left hsqrt (Real.exp_pos (coupledProfileConstant+1)).le)
    have hvsmall' := hvsmall.trans hpower
    have hvsmall'' := (mul_le_mul_of_nonneg_left hvsmall' hK.le).trans (by simpa only [mul_assoc] using hforward)
    have hlow : Real.exp (-M*γ)*lowProfile ℓ γ fL x≤fractionSeparationLevel E :=
      (mul_le_of_le_one_left hu.1 (Real.exp_le_one_iff.mpr (by nlinarith only [hM0,hγ]))).trans hur
    have hcoef : fractionMarginConstant fL ρ E≤(1-fractionSeparationLevel E)/6 :=
      (min_le_right _ _).trans (min_le_left _ _)
    have hm := mul_le_mul_of_nonneg_left hsum hc
    nlinarith only [hlocal,hvsmall'',hlow,hm,hcoef]
  have hr : fractionSeparationLevel E≤lowProfile ℓ γ fL x := (lt_of_not_ge hur).le
  have hprod := coupledProfiles_product_le (by omega : 0<ℓ) (by omega : 0<N) hγ hγ1
    hfL hfL1 hf hf1.le hω hω1 hx hx1 hy hy1 hz hcap
  have hvsep := product_exponential_separation hγ hγ1 hE.le ((le_max_right _ _).trans hr) hv.1 hprod hzE
  have hcpos : 0<1/(8*(1+highProfileIntegralConstant f)) := by positivity
  have hvsep' := (small_order_exp_div_linear (E:=E/2) hγ hcpos
    (by nlinarith only [hroot]) (by nlinarith only [hlog]))
  have hid : -(E/2)/γ=-E/(2*γ) := by ring
  rw [hid] at hvsep'
  have hvbudget := mul_le_mul_of_nonneg_left (hvsep.trans hvsep') hK.le
  have hident : (1+highProfileIntegralConstant f)*(1/(8*(1+highProfileIntegralConstant f))*γ)=γ/8 := by
    field_simp [hK.ne']
  rw [hident] at hvbudget
  have he : Real.exp (-M*γ)≤1-γ/2 := by
    exact (Real.exp_le_exp.mpr (by nlinarith only [hM,hγ])).trans (exp_neg_le_linear_half hγ.le hγ1.le)
  have hlow := mul_le_mul_of_nonneg_right he hu.1
  have hurhalf : (1:ℝ)/2≤lowProfile ℓ γ fL x := (le_max_left _ _).trans hr
  have hgap : coupledDampedExpression ℓ N γ z M ω fL f x y≤lowProfile ℓ γ fL x-γ/8 := by
    have hm := mul_le_mul_of_nonneg_left hurhalf hγ.le
    nlinarith only [hlocal,hvbudget,hlow,hm]
  by_cases hZ : deficitScale fL*γ≤x
  · have hdef := lowProfile_deficit hℓ hγ hγ1.le hfL hfL1 hx hx1 hsmall hZ
    have hcoef1 : fractionMarginConstant fL ρ E≤1/16 :=
      (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _)))
    have hcoef2 : fractionMarginConstant fL ρ E≤deficitConstant fL :=
      (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _)))
    have hYmin := (min_le_left ((N:ℝ)^2*y) 1).trans hYγ
    have hmγ := mul_le_mul_of_nonneg_right hcoef1 hγ.le
    have hmY := mul_le_mul_of_nonneg_left hYmin hc
    have hmZ := mul_le_mul_of_nonneg_right hcoef2 hZ0
    nlinarith only [hgap,hdef,hmγ,hmY,hmZ]
  · have hZmin := (min_le_left x 1).trans (le_of_lt (lt_of_not_ge hZ))
    have hYmin := (min_le_left ((N:ℝ)^2*y) 1).trans hYγ
    have hsum' : γ+min ((N:ℝ)^2*y) 1+min x 1≤(2+deficitScale fL)*γ := by
      nlinarith only [hZmin,hYmin]
    have hcoef : fractionMarginConstant fL ρ E≤1/(8*(2+deficitScale fL)) :=
      (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
    have hden : 0<8*(2+deficitScale fL) := by
      have hd : 0<deficitScale fL := zero_lt_one.trans_le (le_max_left _ _)
      positivity
    have hcoef' := (le_div_iff₀ hden).mp hcoef
    have hm := mul_le_mul_of_nonneg_left hsum' hc
    have hmγ := mul_le_mul_of_nonneg_right hcoef' hγ.le
    nlinarith only [hgap,hu.2,hm,hmγ]



lemma exists_fraction_margin_threshold {fL f ρ E : ℝ}
    (hfL : 0≤fL) (hfL1 : fL<1) (hρ : 0<ρ) (hE : 0<E) :
    ∃ σ : ℝ, 0<σ ∧ σ≤1/2 ∧ σ≤deficitOrder fL ∧ 16*Real.sqrt σ≤E ∧
      (40*Real.exp (Real.log 12+1))*σ≤ρ/4 ∧
      8*σ*(-Real.log (1/(8*(1+highProfileIntegralConstant f))))≤E ∧
      (1+highProfileIntegralConstant f)*Real.exp (coupledProfileConstant+1)*Real.sqrt σ≤
        (1-fractionSeparationLevel E)/2 := by
  let K := 1+highProfileIntegralConstant f
  let W := K*Real.exp (coupledProfileConstant+1)
  let R := (1-fractionSeparationLevel E)/2
  let B := -Real.log (1/(8*K))
  let C := 40*Real.exp (Real.log 12+1)
  have hK : 1<K := by have hp := highProfileIntegralConstant_pos f;dsimp [K];linarith only [hp]
  have hW : 0<W := mul_pos (by linarith only [hK]) (Real.exp_pos _)
  have hR : 0<R := by dsimp [R];linarith only [fractionSeparationLevel_lt_one hE]
  have hB : 0<B := by
    have hq : (1:ℝ)/(8*K)<1 := (div_lt_one (by positivity : 0<8*K)).mpr (by linarith only [hK])
    exact neg_pos.mpr (Real.log_neg (by positivity) hq)
  have hC : 0<C := by dsimp [C];positivity
  have horder := deficitOrder_pos hfL hfL1
  let σ := min (1/2) (min (deficitOrder fL)
    (min ((E/16)^2) (min (ρ/(4*C)) (min (E/(8*B)) ((R/W)^2)))))
  have hσ : 0<σ := by dsimp [σ];positivity
  have hσhalf : σ≤1/2 := min_le_left _ _
  have hσorder : σ≤deficitOrder fL := (min_le_right _ _).trans (min_le_left _ _)
  have hσroot : σ≤(E/16)^2 := (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
  have hσerr : σ≤ρ/(4*C) := (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _)))
  have hσlog : σ≤E/(8*B) := (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))))
  have hσforward : σ≤(R/W)^2 := (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _))))
  refine ⟨σ,hσ,hσhalf,hσorder,?_,?_,?_,?_⟩
  · have hs := (Real.sqrt_le_left (show 0≤E/16 by positivity)).mpr hσroot
    linarith only [hs]
  · have hs := (le_div_iff₀ (show 0<4*C by positivity)).mp hσerr
    dsimp [C] at hs
    nlinarith only [hs]
  · have hs := (le_div_iff₀ (show 0<8*B by positivity)).mp hσlog
    dsimp [B,K] at hs
    nlinarith only [hs]
  · have hs := (Real.sqrt_le_left (show 0≤R/W by positivity)).mpr hσforward
    have hm := (le_div_iff₀ hW).mp hs
    dsimp [W,R,K] at hm
    nlinarith only [hm]

lemma exists_complement_margin_threshold {ρ E : ℝ}
    (hρ : 0<ρ) (hρ1 : ρ≤1) (hE : 0<E) :
    ∃ τ : ℝ, 0<τ ∧ τ≤1/2 ∧ τ≤lowDeficitOrder (1-ρ) ∧
      8*Real.sqrt τ≤E ∧ 4*τ*(-Real.log (ρ/4))≤E := by
  let B := -Real.log (ρ/4)
  have hB : 0<B := neg_pos.mpr (Real.log_neg (by positivity) (by linarith only [hρ1] : ρ/4<1))
  have horder := lowDeficitOrder_pos (by linarith only [hρ1] : 0≤1-ρ) (by linarith only [hρ] : 1-ρ<1)
  let τ := min (1/2) (min (lowDeficitOrder (1-ρ)) (min ((E/8)^2) (E/(4*B))))
  have hτ : 0<τ := by dsimp [τ];positivity
  refine ⟨τ,hτ,min_le_left _ _,(min_le_right _ _).trans (min_le_left _ _),?_,?_⟩
  · have hsq : τ≤(E/8)^2 := (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
    have hs := (Real.sqrt_le_left (show 0≤E/8 by positivity)).mpr hsq
    linarith only [hs]
  · have hlog : τ≤E/(4*B) := (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _))
    have hs := (le_div_iff₀ (show 0<4*B by positivity)).mp hlog
    dsimp [B] at hs
    nlinarith only [hs]

lemma exp_neg_le_of_large {t c : ℝ} (hc : 0<c) (ht : 1/c≤t) : Real.exp (-t)≤c := by
  have he : 1/c≤Real.exp t := ht.trans (by have hh := Real.add_one_le_exp t;linarith only [hh])
  rw [Real.exp_neg]
  have h := one_div_le_one_div_of_le (one_div_pos.mpr hc) he
  simpa only [one_div,inv_inv] using h

lemma coupled_spatial_min_le_sum {γ Y Z : ℝ} (hγ : 0≤γ) (hγ1 : γ≤1)
    (_hY : 0≤Y) (hZ : 0≤Z) :
    min (γ*(1-γ)+Y+min Z 1) 1≤γ+min Y 1+min Z 1 ∧
    min (γ*(1-γ)+Y+min Z 1) 1≤(1-γ)+min Y 1+min Z 1 := by
  have hZ0 : 0≤min Z 1 := le_min hZ (by norm_num)
  by_cases hY1 : Y≤1
  · rw [min_eq_left hY1]
    have hm := min_le_left (γ*(1-γ)+Y+min Z 1) 1
    constructor <;> nlinarith only [hm,mul_nonneg hγ hγ,mul_nonneg (sub_nonneg.mpr hγ1) (sub_nonneg.mpr hγ1)]
  · rw [min_eq_right (le_of_not_ge hY1)]
    have hm := min_le_right (γ*(1-γ)+Y+min Z 1) 1
    constructor <;> nlinarith only [hm,hγ,hγ1,hZ0]

lemma strict_margin_weaken {T a c S R : ℝ} (hc : 0≤c) (hca : c≤a)
    (hR : 0≤R) (hRS : R≤S) (hT : T≤1-a*S) : T≤1-c*R := by
  have hm1 := mul_le_mul_of_nonneg_left hRS hc
  have hm2 := mul_le_mul_of_nonneg_right hca (hR.trans hRS)
  nlinarith only [hT,hm1,hm2]

/-- A fixed margin when complement damping is already macroscopic. -/
theorem coupledProfiles_complement_large_damping_gap {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z M ω ρ fL f x y : ℝ} (hγhalf : (1:ℝ)/2≤γ) (hγ1 : γ<1)
    (hM : 0≤M) (hMd : 1≤M*(1-γ)) (hρ : 0<ρ)
    (hMρ : Real.exp (-M/2)≤ρ/4) (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωρ : ω≤1-ρ) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hz1 : z<1) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤1-ρ/4 := by
  have hγ : 0<γ := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hy hy1
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have ha : a≤ρ/4 := by
    apply (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
    apply le_trans _ hMρ
    apply Real.exp_le_exp.mpr
    nlinarith only [mul_le_mul_of_nonneg_left hγhalf hM]
  have hb : b≤(1:ℝ)/2 := by
    apply (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
    have he : Real.exp (-M*(1-γ))≤Real.exp (-1) := Real.exp_le_exp.mpr (by nlinarith only [hMd])
    have hh := Real.add_one_le_exp (1:ℝ)
    have hi := one_div_le_one_div_of_le (by norm_num : (0:ℝ)<2) (show 2≤Real.exp 1 by linarith only [hh])
    have hehalf : Real.exp (-1)≤(1:ℝ)/2 := by simpa only [Real.exp_neg,one_div] using hi
    exact he.trans hehalf
  have hb1 : b≤1 := by linarith only [hb]
  have hlow := (mul_le_of_le_one_right ha0 hu.2).trans ha
  have hlowcut := mul_le_of_le_one_right (mul_nonneg ha0 hu.1)
    (by linarith only [hH.1] : 1-endpointProfile N 6 1 y≤1)
  have hhigh := mul_le_of_le_one_right hb0 hv.2
  have hlast := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hb1)) hJ.2
  have hlastω := mul_le_mul_of_nonneg_right hωρ (sub_nonneg.mpr hb1)
  have hbρ := mul_le_mul_of_nonneg_left hb hρ.le
  unfold coupledDampedExpression
  change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+
    b*highProfile N (1-γ) f ω y+ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
  nlinarith only [hlow,hlowcut,hhigh,hlast,hlastω,hbρ]

/-- The actual coupled construction has the manuscript's global strict upper envelope.
All damping and margin constants are chosen from the fixed floor parameters and energy gap. -/
theorem coupledProfiles_global_strict_upper {fL f E : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) (hE : 0<E) :
    ∃ M c : ℝ, 1≤M ∧ 0<c ∧
      ∀ (ℓ N : ℕ) (γ z ω x y : ℝ), 2≤ℓ → 2≤N → 0<γ → γ<1 →
        0<z → z≤Real.exp (-E) → 0≤ω → ω≤Real.exp (-E/8) →
        0≤x → x≤1 → 0≤y → y≤1 →
        x*((N:ℝ)^2*y)≤
          Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) →
        coupledDampedExpression ℓ N γ z M ω fL f x y≤1-c*
          min (γ*(1-γ)+(N:ℝ)^2*y+min x 1) 1 := by
  let ρ := 1-Real.exp (-E/8)
  have hρ : 0<ρ := by dsimp [ρ];linarith only [Real.exp_lt_one_iff.mpr (show -E/8<0 by linarith only [hE])]
  have hρ1 : ρ≤1 := by dsimp [ρ];linarith only [Real.exp_pos (-E/8)]
  have hEρ : Real.exp (-E/2)≤1-ρ := by
    dsimp [ρ]
    have he : Real.exp (-E/2)≤Real.exp (-E/8) := Real.exp_le_exp.mpr (by linarith only [hE])
    linarith only [he]
  obtain ⟨σ,hσ,hσhalf,hσorder,hσroot,hσerror,hσlog,hσforward⟩ :=
    exists_fraction_margin_threshold (f:=f) hfL.le hfL1 hρ hE
  obtain ⟨τ,hτ,hτhalf,hτorder,hτroot,hτlog⟩ := exists_complement_margin_threshold hρ hρ1 hE
  let θ := min σ τ
  have hθ : 0<θ := lt_min hσ hτ
  let M := max 1 (max (8/ρ) (4/(ρ*θ)))
  have hM : 1≤M := le_max_left _ _
  have hM0 : 0≤M := by linarith only [hM]
  have hMρ0 : 8/ρ≤M := (le_max_left _ _).trans (le_max_right _ _)
  have hMθ0 : 4/(ρ*θ)≤M := (le_max_right _ _).trans (le_max_right _ _)
  have hMρ : Real.exp (-M/2)≤ρ/4 := by
    have hm := (div_le_iff₀ hρ).mp hMρ0
    have hscale : 1/(ρ/4)≤M/2 := by
      apply (div_le_iff₀ (show 0<ρ/4 by positivity)).mpr
      nlinarith only [hm]
    simpa only [neg_div] using exp_neg_le_of_large (by positivity : 0<ρ/4) hscale
  have hMθ : Real.exp (-M*θ)≤ρ/4 := by
    have hm := (div_le_iff₀ (mul_pos hρ hθ)).mp hMθ0
    have hscale : 1/(ρ/4)≤M*θ := by
      apply (div_le_iff₀ (show 0<ρ/4 by positivity)).mpr
      nlinarith only [hm]
    simpa only [neg_mul] using exp_neg_le_of_large (by positivity : 0<ρ/4) hscale
  let c := min (fractionMarginConstant fL ρ E) (min (complementMarginConstant fL ρ) (ρ/4))
  have hc : 0<c := lt_min (fractionMarginConstant_pos hfL1 hρ hE)
    (lt_min (complementMarginConstant_pos hfL hρ) (by positivity))
  refine ⟨M,c,hM,hc,?_⟩
  intro ℓ N γ z ω x y hℓ hN hγ hγ1 hz hzE hω hωE hx hx1 hy hy1 hcap
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hωρ : ω≤1-ρ := by dsimp [ρ];linarith only [hωE]
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  let R := min (γ*(1-γ)+(N:ℝ)^2*y+min x 1) 1
  have hR0 : 0≤R := le_min (add_nonneg (add_nonneg (mul_nonneg hγ.le hd.le) (by positivity))
    (le_min (by positivity) (by norm_num))) (by norm_num)
  have hR1 : R≤1 := min_le_right _ _
  have hRs := coupled_spatial_min_le_sum hγ.le hγ1.le (show 0≤(N:ℝ)^2*y by positivity)
    (show 0≤x by positivity)
  by_cases hγσ : γ≤σ
  · have hroot : 16*Real.sqrt γ≤E := (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hγσ) (by norm_num : (0:ℝ)≤16)).trans hσroot
    have herror := (mul_le_mul_of_nonneg_left hγσ (show 0≤40*Real.exp (Real.log 12+1) by positivity)).trans hσerror
    have hlog := (mul_le_mul_of_nonneg_left hγσ (show 0≤8*(-Real.log (1/(8*(1+highProfileIntegralConstant f)))) by
      have hK := highProfileIntegralConstant_pos f
      have hq : 1/(8*(1+highProfileIntegralConstant f))≤1 := (div_le_one (by positivity)).mpr (by linarith only [hK])
      exact mul_nonneg (by norm_num) (neg_nonneg.mpr (Real.log_nonpos (by positivity) hq))))
    have hlog' : 8*γ*(-Real.log (1/(8*(1+highProfileIntegralConstant f))))≤E := by nlinarith only [hlog,hσlog]
    have hforward := (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hγσ)
      (show 0≤(1+highProfileIntegralConstant f)*Real.exp (coupledProfileConstant+1) by
        have hK := highProfileIntegralConstant_pos f;positivity)).trans hσforward
    have hgap := coupledProfiles_fraction_spatial_gap hℓ hN hγ (hγσ.trans hσhalf) hM hρ hω hωρ
      hMρ hEρ hroot herror hlog' hforward hfL.le hfL1 hf hf1 hx hx1 hy hy1 hz hzE (hγσ.trans hσorder) hcap
    exact strict_margin_weaken hc.le (min_le_left _ _) hR0 hRs.1 hgap
  by_cases hδτ : 1-γ≤τ
  · have hγhalf : (1:ℝ)/2≤γ := by linarith only [hδτ,hτhalf]
    by_cases hMd : M*(1-γ)≤1
    · have hroot : 8*Real.sqrt (1-γ)≤E := (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hδτ) (by norm_num : (0:ℝ)≤8)).trans hτroot
      have hlog := mul_le_mul_of_nonneg_left hδτ (show 0≤4*(-Real.log (ρ/4)) by
        exact mul_nonneg (by norm_num) (neg_nonneg.mpr (Real.log_nonpos (by positivity) (by linarith only [hρ1] : ρ/4≤1))))
      have hlog' : 4*(1-γ)*(-Real.log (ρ/4))≤E := by nlinarith only [hlog,hτlog]
      have hgap := coupledProfiles_complement_spatial_gap hℓ hN hγhalf hγ1 hM hMd hρ hρ1
        (hMρ.trans (by linarith only [hρ] : ρ/4≤ρ/2)) hEρ hroot hlog'
        hfL hfL1 hf hf1.le hω hωρ hx hx1 hy hy1 hz hzE (hδτ.trans hτorder) hcap
      exact strict_margin_weaken hc.le ((min_le_right _ _).trans (min_le_left _ _)) hR0 hRs.2 hgap
    · have hgap := coupledProfiles_complement_large_damping_gap (by omega : 0<ℓ) (by omega : 0<N)
        hγhalf hγ1 hM0 (le_of_lt (lt_of_not_ge hMd)) hρ hMρ hfL.le hfL1 hf hf1.le hω hωρ hx hx1 hy hy1 hz hz1
      exact strict_margin_weaken hc.le ((min_le_right _ _).trans (min_le_right _ _)) hR0 hR1 (by simpa only [mul_one] using hgap)
  · have hσγ : θ≤γ := (min_le_left _ _).trans (le_of_lt (lt_of_not_ge hγσ))
    have hτδ : θ≤1-γ := (min_le_right _ _).trans (le_of_lt (lt_of_not_ge hδτ))
    have hgap := coupledProfiles_interior_upper_gap (by omega : 0<ℓ) (by omega : 0<N)
      hγ hγ1 hM0 hσγ hτδ hρ hω hωρ hMθ hfL.le hfL1 hf hf1.le hx hx1 hy hy1 hz hz1
    have hcoef : c≤ρ/2 := ((min_le_right _ _).trans (min_le_right _ _)).trans (by linarith only [hρ] : ρ/4≤ρ/2)
    exact strict_margin_weaken hc.le hcoef hR0 hR1 (by simpa only [mul_one] using hgap)


end Renyi.DegreeOneCompletion
