import Renyi.AnalyticMean
import Mathlib.Analysis.SpecialFunctions.Gamma.BohrMollerup
import Mathlib.Analysis.Convex.Slope

/-! The actual nonnegative Gamma-count transform: pointwise sandwich and mean.
The cutoff is written `a ≤ j`, equivalent to `ceil a ≤ j` for integer counts. -/

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Set
namespace Renyi

def positiveCount (a : ℝ) (j : ℕ) : ℝ :=
  if a ≤ (j : ℝ) then analyticCount a j else 0

def positiveCountRoot (a : ℝ) (j : ℕ) : ℝ := positiveCount a j ^ (1 / a)

theorem logGamma_unit_increment {x : ℝ} (hx : 0 < x) :
    Real.log (Real.Gamma (x + 1)) - Real.log (Real.Gamma x) = Real.log x := by
  rw [Real.Gamma_add_one hx.ne', Real.log_mul hx.ne' (Real.Gamma_pos_of_pos hx).ne']
  ring

theorem logGamma_ratio_upper {x a : ℝ} (ha : 1 ≤ a) (hxa : a ≤ x) :
    Real.log (Real.Gamma (x + 1)) - Real.log (Real.Gamma (x + 1 - a)) ≤
      a * Real.log x := by
  have hx : 0 < x := by linarith
  rcases ha.eq_or_lt with rfl | ha
  · simpa using (logGamma_unit_increment hx).le
  have h := Real.convexOn_log_Gamma.secant_mono_aux3
    (x := x + 1 - a) (y := x) (z := x + 1)
    (by simp only [mem_Ioi]; linarith) (by simp only [mem_Ioi]; linarith)
    (by linarith) (by linarith)
  simp only [Function.comp_apply] at h
  have hden : x + 1 - (x + 1 - a) = a := by ring
  rw [hden, show x + 1 - x = 1 by ring, div_one, logGamma_unit_increment hx] at h
  exact (div_le_iff₀ (by linarith : 0 < a)).mp h |>.trans_eq (mul_comm _ _)

theorem logGamma_ratio_lower {x a : ℝ} (ha : 0 < a) (hxa : a < x) :
    a * Real.log (x - a) ≤
      Real.log (Real.Gamma (x + 1)) - Real.log (Real.Gamma (x + 1 - a)) := by
  have h := Real.convexOn_log_Gamma.slope_mono_adjacent
    (x := x - a) (y := x + 1 - a) (z := x + 1)
    (by simpa only [mem_Ioi] using sub_pos.mpr hxa)
    (by simp only [mem_Ioi]; linarith) (by linarith) (by linarith)
  simp only [Function.comp_apply] at h
  rw [show x + 1 - a - (x - a) = 1 by ring, div_one,
    show x + 1 - (x + 1 - a) = a by ring] at h
  have hunit := logGamma_unit_increment (sub_pos.mpr hxa)
  rw [show x - a + 1 = x + 1 - a by ring] at hunit
  rw [hunit] at h
  exact (le_div_iff₀ ha).mp h |>.trans' (le_of_eq (mul_comm _ _))

theorem positiveCount_nonneg (a : ℝ) (j : ℕ) : 0 ≤ positiveCount a j := by
  unfold positiveCount
  split_ifs with h
  · exact (analyticCount_pos a j (by linarith)).le
  · exact le_rfl

theorem positiveCount_nat (r j : ℕ) : positiveCount (r : ℝ) j = (j.descFactorial r : ℝ) := by
  unfold positiveCount
  split_ifs with h
  · exact analyticCount_nat r j
  · have hjr : j < r := by exact_mod_cast (lt_of_not_ge h)
    rw [Nat.descFactorial_eq_zero_iff_lt.mpr hjr]
    simp

theorem positiveCount_le_power {a : ℝ} (ha : 1 ≤ a) (j : ℕ) :
    positiveCount a j ≤ (j : ℝ) ^ a := by
  unfold positiveCount
  split_ifs with h
  · have hj : 0 < (j : ℝ) := by linarith
    have hden : 0 < (j : ℝ) + 1 - a := by linarith
    have h := Real.exp_le_exp.mpr (logGamma_ratio_upper ha h)
    rw [Real.exp_sub, Real.exp_log (Real.Gamma_pos_of_pos (by linarith : 0 < (j : ℝ) + 1)),
      Real.exp_log (Real.Gamma_pos_of_pos hden)] at h
    rw [Real.Gamma_nat_eq_factorial] at h
    change (j.factorial : ℝ) / Real.Gamma ((j : ℝ) + 1 - a) ≤ _
    exact h.trans_eq (by rw [Real.rpow_def_of_pos hj]; congr 1; ring)
  · exact Real.rpow_nonneg (Nat.cast_nonneg _) _

theorem positiveCount_lower_power {a : ℝ} (ha : 1 ≤ a) (j : ℕ) :
    (max ((j : ℝ) - a) 0) ^ a ≤ positiveCount a j := by
  have ha0 : 0 < a := by linarith
  by_cases h : a < (j : ℝ)
  · have hden : 0 < (j : ℝ) + 1 - a := by linarith
    rw [positiveCount, if_pos h.le, max_eq_left (sub_pos.mpr h).le]
    have hex := Real.exp_le_exp.mpr (logGamma_ratio_lower ha0 h)
    rw [Real.exp_sub, Real.exp_log (Real.Gamma_pos_of_pos (by linarith : 0 < (j : ℝ) + 1)),
      Real.exp_log (Real.Gamma_pos_of_pos hden), Real.Gamma_nat_eq_factorial] at hex
    change _ ≤ (j.factorial : ℝ) / Real.Gamma ((j : ℝ) + 1 - a)
    convert hex using 1
    rw [Real.rpow_def_of_pos (sub_pos.mpr h)]
    congr 1
    ring
  · rw [max_eq_right (by linarith : (j : ℝ) - a ≤ 0), Real.zero_rpow ha0.ne']
    exact positiveCount_nonneg a j

theorem positiveCountRoot_sandwich {a : ℝ} (ha : 1 ≤ a) (j : ℕ) :
    max ((j : ℝ) - a) 0 ≤ positiveCountRoot a j ∧ positiveCountRoot a j ≤ j := by
  have ha0 : 0 < a := by linarith
  have hlow := Real.rpow_le_rpow (Real.rpow_nonneg (le_max_right ((j : ℝ) - a) 0) a)
    (positiveCount_lower_power ha j) (one_div_nonneg.mpr ha0.le)
  have hupp := Real.rpow_le_rpow (positiveCount_nonneg a j)
    (positiveCount_le_power ha j) (one_div_nonneg.mpr ha0.le)
  rw [← Real.rpow_mul (le_max_right ((j : ℝ) - a) 0),
    mul_one_div_cancel ha0.ne', Real.rpow_one] at hlow
  rw [← Real.rpow_mul (Nat.cast_nonneg j), mul_one_div_cancel ha0.ne', Real.rpow_one] at hupp
  exact ⟨hlow, hupp⟩

theorem positiveCountRoot_error {a : ℝ} (ha : 1 ≤ a) (j : ℕ) :
    |positiveCountRoot a j - j| ≤ a := by
  obtain ⟨hlo, hhi⟩ := positiveCountRoot_sandwich ha j
  have h := (le_max_left ((j : ℝ) - a) 0).trans hlo
  rw [abs_sub_le_iff]
  constructor <;> linarith

theorem positiveCount_memLp (lam : ℝ≥0) (a : ℝ) :
    MemLp (positiveCount a) 2 (poissonMeasure lam) := by
  apply (analyticCount_memLp lam a).norm.mono' (measurable_of_countable _).aestronglyMeasurable
  filter_upwards [] with j
  unfold positiveCount
  split_ifs
  · exact le_rfl
  · simp only [norm_zero]
    exact norm_nonneg _

theorem positiveCount_pmf_summable (lam : ℝ≥0) (a : ℝ) :
    Summable (fun j => positiveCount a j * poissonPMFReal lam j) := by
  apply Summable.of_norm_bounded (analyticCount_pmf_summable lam a).norm
  intro j
  unfold positiveCount
  split_ifs
  · exact le_rfl
  · simp only [zero_mul, norm_zero]
    exact norm_nonneg _

/-- Exact cancellation of the shifted nonnegative Poisson tail with a negative-order mean. -/
theorem positiveCount_poisson_tail_term (lam : ℝ≥0) (m j : ℕ) {g : ℝ}
    (_hg : 0 < g) (hg1 : g < 1) :
    positiveCount ((m : ℝ) + g) (j + m + 1) * poissonPMFReal lam (j + m + 1) =
      (lam : ℝ) ^ (m + 1) *
        (analyticCount (g - 1) j * poissonPMFReal lam j) := by
  have hj : (m : ℝ) + g ≤ ((j + m + 1 : ℕ) : ℝ) := by push_cast; have := Nat.cast_nonneg (α := ℝ) j; linarith
  rw [positiveCount, if_pos hj]
  unfold analyticCount poissonPMFReal
  have hf : ((j + m + 1).factorial : ℝ) ≠ 0 := by positivity
  have hf' : (j.factorial : ℝ) ≠ 0 := by positivity
  have heq : ((j + m + 1 : ℕ) : ℝ) + 1 - ((m : ℝ) + g) = (j : ℝ) + 1 - (g - 1) := by push_cast; ring
  rw [heq, show j + m + 1 = j + (m + 1) by omega, pow_add]
  field_simp

/-- The complete nonnegative-transform mean, before rescaling its beta integral. -/
theorem positiveCount_poisson_mean (lam : ℝ≥0) (m : ℕ) {g : ℝ}
    (hg : 0 < g) (hg1 : g < 1) :
    (∫ j, positiveCount ((m : ℝ) + g) j ∂poissonMeasure lam) =
      (lam : ℝ) ^ (m + 1) * analyticMean lam (g - 1) := by
  rw [poisson_integral_eq_tsum lam _ ((positiveCount_memLp lam _).integrable one_le_two)]
  have hs := (positiveCount_pmf_summable lam ((m : ℝ) + g)).sum_add_tsum_nat_add (m + 1)
  have hz : (∑ j ∈ Finset.range (m + 1), positiveCount ((m : ℝ) + g) j * poissonPMFReal lam j) = 0 := by
    apply Finset.sum_eq_zero
    intro j hj
    have hjm : (j : ℝ) ≤ m := by exact_mod_cast (show j ≤ m by have := Finset.mem_range.mp hj; omega)
    rw [positiveCount, if_neg (by linarith)]
    ring
  rw [hz, zero_add] at hs
  rw [← hs]
  simp_rw [show ∀ j : ℕ, j + (m + 1) = j + m + 1 by omega,
    positiveCount_poisson_tail_term lam m _ hg hg1]
  rw [tsum_mul_left, analyticMean_eq_tsum]

theorem lowerGamma_integral_rescale {l : ℝ} (hl : 0 < l) (g : ℝ) :
    (∫ t : ℝ in 0..l, Real.exp (-t) * t ^ (-g)) =
      l ^ (1 - g) * ∫ u : ℝ in 0..1, Real.exp (-l * u) * u ^ (-g) := by
  have hc := intervalIntegral.smul_integral_comp_mul_left
    (a := 0) (b := 1) (fun t : ℝ => Real.exp (-t) * t ^ (-g)) l
  simp only [mul_zero, mul_one, smul_eq_mul] at hc
  rw [← hc]
  have hi : (∫ u : ℝ in 0..1, Real.exp (-(l * u)) * (l * u) ^ (-g)) =
      l ^ (-g) * ∫ u : ℝ in 0..1, Real.exp (-l * u) * u ^ (-g) := by
    rw [← intervalIntegral.integral_const_mul]
    apply intervalIntegral.integral_congr
    intro u hu
    have hu0 : 0 ≤ u := (show u ∈ Icc (0 : ℝ) 1 by simpa using hu).1
    dsimp only
    rw [Real.mul_rpow hl.le hu0]
    rw [neg_mul]
    ring
  rw [hi]
  have hp : l * l ^ (-g) = l ^ (1 - g) := by
    calc
      l * l ^ (-g) = l ^ (1 : ℝ) * l ^ (-g) := by rw [Real.rpow_one]
      _ = l ^ (1 - g) := by rw [← Real.rpow_add hl]; rfl
  rw [← mul_assoc, hp]

/-- The exact incomplete-Gamma mean in the manuscript, for the actual cutoff transform. -/
theorem positiveCount_poisson_incompleteGamma_mean (lam : ℝ≥0)
    (hlam : 0 < (lam : ℝ)) (m : ℕ) {g : ℝ} (hg : 0 < g) (hg1 : g < 1) :
    (∫ j, positiveCount ((m : ℝ) + g) j ∂poissonMeasure lam) =
      (lam : ℝ) ^ ((m : ℝ) + g) / Real.Gamma (1 - g) *
        ∫ t : ℝ in 0..(lam : ℝ), t ^ (-g) * Real.exp (-t) := by
  rw [positiveCount_poisson_mean lam m hg hg1,
    analyticMean_negative_unit_integral lam (g - 1) (by linarith)]
  have harg : -(g - 1) = 1 - g := by ring
  rw [harg, show 1 - g - 1 = -g by ring]
  have hi : (∫ t : ℝ in 0..(lam : ℝ), t ^ (-g) * Real.exp (-t)) =
      (lam : ℝ) ^ (1 - g) *
        ∫ u : ℝ in 0..1, Real.exp (-(lam : ℝ) * u) * u ^ (-g) := by
    rw [show (fun t : ℝ => t ^ (-g) * Real.exp (-t)) =
      (fun t : ℝ => Real.exp (-t) * t ^ (-g)) by funext t; ring]
    exact lowerGamma_integral_rescale hlam g
  rw [hi]
  have hp : (lam : ℝ) ^ ((m : ℝ) + g) * (lam : ℝ) ^ (1 - g) = (lam : ℝ) ^ (m + 1) := by
    rw [← Real.rpow_add hlam, show ((m : ℝ) + g) + (1 - g) = ((m + 1 : ℕ) : ℝ) by push_cast; ring,
      Real.rpow_natCast]
  calc
    _ = ((lam : ℝ) ^ ((m : ℝ) + g) * (lam : ℝ) ^ (1 - g)) *
        ((Real.Gamma (1 - g))⁻¹ * ∫ u : ℝ in 0..1, Real.exp (-(lam : ℝ) * u) * u ^ (-g)) := by rw [hp]
    _ = _ := by ring

end Renyi
