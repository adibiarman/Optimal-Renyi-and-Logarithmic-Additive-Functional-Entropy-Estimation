import Renyi.OverlapMonotonicity
import Mathlib.Analysis.SpecialFunctions.Pow.Deriv
import Mathlib.Topology.Order.IntermediateValue

/-! Endpoint limits and the bijection for the exact envelope. -/
noncomputable section
open Set Filter
open scoped Topology
namespace Renyi

/-- The envelope dominates its weighted-product parameter. -/
theorem overlapG_ge_parameter {γ z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) : z ≤ overlapG γ z := by
  have hd : 0 < 1-γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients hγ hγ1 hz hz1
  have ha : 1 ≤ overlapA γ z/(1-γ) := (one_le_div hd).2 hc.1.le
  have hb : 1 ≤ overlapB γ z/γ := (one_le_div hγ).2 hc.2.le
  have hpA : 1 ≤ (overlapA γ z/(1-γ))^(1-γ) := by
    simpa using Real.rpow_le_rpow (show (0 : ℝ) ≤ 1 by norm_num) ha hd.le
  have hpB : 1 ≤ (overlapB γ z/γ)^γ := by
    simpa using Real.rpow_le_rpow (show (0 : ℝ) ≤ 1 by norm_num) hb hγ.le
  rw [overlapG_factor hγ hγ1 hz hz1]
  nlinarith [mul_nonneg (sub_nonneg.mpr hpA) (sub_nonneg.mpr hpB)]

theorem overlapF_pos {γ t : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) (ht : 0 < t) :
    0 < overlapF γ t := by
  have hd : 0 < 1-γ := sub_pos.mpr hγ1
  have he : Real.exp (-γ*(1-γ)*t) < 1 := Real.exp_lt_one_iff.mpr (by nlinarith [mul_pos (mul_pos hγ hd) ht])
  rw [overlapF_eq_log hγ hγ1 ht]
  exact neg_pos.mpr (Real.log_neg (overlapG_mem_Ioo hγ hγ1 (Real.exp_pos _) he).1
    (overlapG_mem_Ioo hγ hγ1 (Real.exp_pos _) he).2)

theorem overlapF_le_linear {γ t : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) (ht : 0 < t) :
    overlapF γ t ≤ γ*(1-γ)*t := by
  have hd : 0 < 1-γ := sub_pos.mpr hγ1
  have he : Real.exp (-γ*(1-γ)*t) < 1 := Real.exp_lt_one_iff.mpr (by nlinarith [mul_pos (mul_pos hγ hd) ht])
  have hl := Real.log_le_log (Real.exp_pos (-γ*(1-γ)*t))
    (overlapG_ge_parameter hγ hγ1 (Real.exp_pos _) he)
  rw [Real.log_exp] at hl
  rw [overlapF_eq_log hγ hγ1 ht]
  linarith

private theorem rpow_ratio_limit {p q : ℝ} (hq : q ≠ 0) :
    Tendsto (fun z : ℝ => (1-z^p)/(1-z^q)) (𝓝[<] 1) (𝓝 (p/q)) := by
  have hd (a : ℝ) : HasDerivAt (fun z : ℝ => z^a) a 1 := by
    simpa using Real.hasDerivAt_rpow_const (x := 1) (p := a) (.inl one_ne_zero)
  have hp := (hasDerivAt_iff_tendsto_slope.mp (hd p)).mono_left (nhdsLT_le_nhdsNE (1 : ℝ))
  have hq' := (hasDerivAt_iff_tendsto_slope.mp (hd q)).mono_left (nhdsLT_le_nhdsNE (1 : ℝ))
  have hlim := hp.div hq' hq
  apply hlim.congr'
  filter_upwards [self_mem_nhdsWithin] with z hz
  simp only [Pi.div_apply, slope_def_field, Real.one_rpow]
  have hzne : z - 1 ≠ 0 := (sub_neg.mpr hz).ne
  rw [div_div_div_cancel_right₀ hzne, ← neg_sub 1 (z^p), ← neg_sub 1 (z^q), neg_div_neg_eq]

/-- Coefficients tend to their limiting weights at the right endpoint. -/
theorem overlap_coefficients_tendsto_one {γ : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    Tendsto (overlapA γ) (𝓝[<] 1) (𝓝 (1-γ)) ∧
    Tendsto (overlapB γ) (𝓝[<] 1) (𝓝 γ) := by
  have hd : 0 < 1-γ := sub_pos.mpr hγ1
  have hh : 1/(γ*(1-γ)) ≠ 0 := one_div_ne_zero (mul_ne_zero hγ.ne' hd.ne')
  constructor
  · convert rpow_ratio_limit (p := 1/γ) hh using 1
    field_simp
  · convert rpow_ratio_limit (p := 1/(1-γ)) hh using 1
    field_simp

/-- The right endpoint limit is one. -/
theorem overlapG_tendsto_one {γ : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    Tendsto (overlapG γ) (𝓝[<] 1) (𝓝 1) := by
  have hd : 0 < 1-γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients_tendsto_one hγ hγ1
  have hA := (Real.continuousAt_rpow_const (1-γ) (1-γ) (.inl hd.ne')).tendsto.comp hc.1
  have hB := (Real.continuousAt_rpow_const γ γ (.inl hγ.ne')).tendsto.comp hc.2
  have h := (((tendsto_id.mono_left nhdsWithin_le_nhds).mul hA).mul hB).div_const
    ((1-γ)^(1-γ)*γ^γ)
  convert h using 1
  simp only [one_mul]
  congr 1
  exact (div_self (mul_pos (Real.rpow_pos_of_pos hd _) (Real.rpow_pos_of_pos hγ _)).ne').symm

/-- The left endpoint limit is zero. -/
theorem overlapG_tendsto_zero {γ : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    Tendsto (overlapG γ) (𝓝[>] 0) (𝓝 0) := by
  have hd : 0 < 1-γ := sub_pos.mpr hγ1
  have hp : 0 < 1/(γ*(1-γ)) := one_div_pos.mpr (mul_pos hγ hd)
  have hpow (p : ℝ) (hp : 0 < p) : ContinuousAt (fun x : ℝ => x^p) 0 :=
    Real.continuousAt_rpow_const 0 p (.inr hp.le)
  have hA : ContinuousAt (overlapA γ) 0 := by
    apply (continuousAt_const.sub (hpow _ (one_div_pos.mpr hγ))).div
      (continuousAt_const.sub (hpow _ hp))
    change 1 - (0 : ℝ) ^ (1/(γ*(1-γ))) ≠ 0
    rw [Real.zero_rpow hp.ne']
    norm_num
  have hB : ContinuousAt (overlapB γ) 0 := by
    apply (continuousAt_const.sub (hpow _ (one_div_pos.mpr hd))).div
      (continuousAt_const.sub (hpow _ hp))
    change 1 - (0 : ℝ) ^ (1/(γ*(1-γ))) ≠ 0
    rw [Real.zero_rpow hp.ne']
    norm_num
  have h : ContinuousAt (overlapG γ) 0 :=
    (((continuousAt_id.mul (hA.rpow_const (.inr hd.le))).mul
      (hB.rpow_const (.inr hγ.le))).div_const _)
  convert h.tendsto.mono_left nhdsWithin_le_nhds using 1
  simp [overlapG]

/-- Surjectivity, with the open endpoints handled by the actual endpoint limits. -/
theorem overlapG_surjOn {γ : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    SurjOn (overlapG γ) (Ioo (0 : ℝ) 1) (Ioo (0 : ℝ) 1) := by
  have ht0 := (overlapG_tendsto_zero hγ hγ1).mono_left
    (show 𝓝[Ioo (0 : ℝ) 1] 0 ≤ 𝓝[>] 0 from nhdsWithin_mono _ Ioo_subset_Ioi_self)
  have ht1 := (overlapG_tendsto_one hγ hγ1).mono_left
    (show 𝓝[Ioo (0 : ℝ) 1] 1 ≤ 𝓝[<] 1 from nhdsWithin_mono _ Ioo_subset_Iio_self)
  haveI : NeBot (𝓝[Ioo (0 : ℝ) 1] 0) := left_nhdsWithin_Ioo_neBot zero_lt_one
  haveI : NeBot (𝓝[Ioo (0 : ℝ) 1] 1) := right_nhdsWithin_Ioo_neBot zero_lt_one
  exact isPreconnected_Ioo.intermediate_value_Ioo
    (l₁ := 𝓝[Ioo (0 : ℝ) 1] 0) (l₂ := 𝓝[Ioo (0 : ℝ) 1] 1)
    inf_le_right inf_le_right (overlapG_continuousOn hγ hγ1) ht0 ht1

/-- A continuous, strictly increasing bijection from `(0,1)` onto `(0,1)`. -/
theorem overlapG_bijection {γ : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    ContinuousOn (overlapG γ) (Ioo (0 : ℝ) 1) ∧
    StrictMonoOn (overlapG γ) (Ioo (0 : ℝ) 1) ∧
    BijOn (overlapG γ) (Ioo (0 : ℝ) 1) (Ioo (0 : ℝ) 1) := by
  exact ⟨overlapG_continuousOn hγ hγ1, overlapG_strictMonoOn hγ hγ1,
    fun _ hz => overlapG_mem_Ioo hγ hγ1 hz.1 hz.2,
    (overlapG_strictMonoOn hγ hγ1).injOn, overlapG_surjOn hγ hγ1⟩

/-- The positive logarithmic target determines exactly one positive `t`. -/
theorem overlapF_existsUnique {γ E : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) (hE : 0 < E) :
    ∃! t : ℝ, 0 < t ∧ overlapF γ t = E := by
  have hd : 0 < 1-γ := sub_pos.mpr hγ1
  have hh : 0 < γ*(1-γ) := mul_pos hγ hd
  obtain ⟨z, hz, hG⟩ := overlapG_surjOn hγ hγ1
    ⟨Real.exp_pos (-E), Real.exp_lt_one_iff.mpr (neg_neg_of_pos hE)⟩
  let t := -Real.log z/(γ*(1-γ))
  have ht : 0 < t := div_pos (neg_pos.mpr (Real.log_neg hz.1 hz.2)) hh
  have he : Real.exp (-γ*(1-γ)*t) = z := by
    have : -γ*(1-γ)*t = Real.log z := by dsimp [t]; field_simp
    rw [this, Real.exp_log hz.1]
  have hF : overlapF γ t = E := by
    rw [overlapF_eq_log hγ hγ1 ht, he, hG, Real.log_exp, neg_neg]
  refine ⟨t, ⟨ht,hF⟩, ?_⟩
  intro s hs
  exact (overlapF_strictMonoOn hγ hγ1).injOn hs.1 ht (hs.2.trans hF.symm)

end Renyi
