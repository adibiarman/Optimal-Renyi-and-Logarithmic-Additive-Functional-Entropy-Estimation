import Renyi.CompletedConditionalCount
import Renyi.CoupledConditionalCountCertificate

/-! Source CC12 for every branch of the actual completed coupled polynomial. -/
set_option maxHeartbeats 1000000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

variable {ι Ω Ξ : Type*} [Fintype ι] [MeasurableSpace Ω] [MeasurableSpace Ξ]
variable {μ : Measure Ω} {ν : Measure Ξ}

section ActualCount
variable {ell Nk m d : ℕ} {gamma aCut b n cProfile fL f A B omega L Cscale Cd Ct cp Bpilot M : ℝ}
variable {CL cL D X R E0 u0 c E kappa u : ℝ}
variable (hell : 0 < ell) (hNk : 0 < Nk) (hmDegree : 1 ≤ m) (hdegree : 4 * (ell - 1) ≤ m)
variable (hgamma : 0 < gamma) (hgamma1 : gamma < 1) (halpha : 3 / 2 ≤ (m : ℝ) + gamma)
variable (haCut : 0 < aCut) (hab : aCut ≤ b) (hb : 0 < b)
variable (hcProfile : cProfile ∈ Set.Ioo (gamma / (1 + gamma)) 1)
variable (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
variable (hA : 0 ≤ A) (hA1 : A ≤ 1) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hw : 0 ≤ omega) (hw1 : omega < 1)
variable (hlocal : (ell : ℝ) ^ 2 * (aCut * (Nk : ℝ) ^ 2 / b) ≤ 1)
variable (hLactual : L = (upperDegree ((m : ℝ) + gamma) CL cL X : ℝ))
variable (hCL : 1 ≤ CL) (hcL : 0 < cL) (hellL : (ell : ℝ) ≤ L) (hNkL : (Nk : ℝ) ≤ L)
variable (hscale : 0 < Cscale) (hcountScale : (Nk : ℝ) ^ 2 / (n * b) ≤ Cscale * L)
variable (hH : 1 ≤ n * b) (hrd : m + 1 ≤ d) (hCd : 0 ≤ Cd) (hdegreeL : (d : ℝ) ≤ Cd * L)
variable (hCt : 2 * coupledCoefficientExponentialConstant + 4 * Cd ≤ Ct) (hCt2 : 2 ≤ Ct)
variable (hcp : 0 < cp) (hBpilot : 0 ≤ Bpilot) (hM : 0 ≤ M)
variable (hdegreeH : (d : ℝ) ≤ M * (n * b)) (hcpM : 4 * M ≤ cp)
variable (hD : 1 ≤ D) (hX : 1 ≤ X) (hE0 : 0 < E0) (hu0 : 0 < u0) (hc : 0 ≤ c)
variable (hsmall : cL * (coupledHighMediumConstant cp Bpilot M Cd + Ct + 1 / (CL + 1)) ≤ 1 / 2)
variable (hRtiny : Real.exp (3 * (Real.log (completedHighTinyConstant Cscale) + c)) ≤ R)
variable (hRmedium : Real.exp (3 * (Real.log (highMediumExponentialConstant CL
  (coupledHighMediumConstant cp Bpilot M Cd) Ct (n * b / L)) + c)) ≤ R)
variable (hE : E0 * (R / D) ^ ((m : ℝ) + gamma - 1) ≤ E)
variable (hkappa : Real.exp (-c * ((m : ℝ) + gamma)) ≤ kappa) (hu : u0 * X ^ (-((m : ℝ) + gamma)) ≤ u)
variable (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) (hk : (0 : ℝ) < Fintype.card ι)
variable (hnsize : n = D * ((m : ℝ) + gamma) * (Fintype.card ι : ℝ) ^ (1 - 1 / ((m : ℝ) + gamma)) * X)
variable (Counts : ι → Ω → ℕ) (lam : ι → ℝ≥0)
variable (hLaw : ∀ i, MeasurePreserving (Counts i) μ (poissonMeasure (lam i)))
variable (hpair : Pairwise (fun i j => IndepFun (Counts i) (Counts j) μ))
variable (Pilot : ι → Ξ → ℕ)
variable (hPilot : ∀ i, MeasurePreserving (Pilot i) ν
  (poissonMeasure ⟨cp * lam i, mul_nonneg hcp.le (lam i).coe_nonneg⟩))
variable (hlam : ∀ i, (lam i : ℝ) = n * p i)

include hell hNk hmDegree hcProfile hdegree hgamma hgamma1 halpha haCut hab hb hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1
include hlocal hLactual hCL hcL hellL hNkL hscale hcountScale hH hrd hCd hdegreeL hCt hCt2 hcp hBpilot hM hdegreeH hcpM
include hD hX hE0 hu0 hc hsmall hRtiny hRmedium hE hkappa hu hp hk hnsize hLaw hpair hPilot hlam

/-- The full actual conditional count certificate with D chosen after all fixed constants. -/
theorem completed_conditional_count_variance_actual {rho Eactual ustar eta : ℝ} (hrho : 0 < rho)
    (hRlow : Real.exp (3 * (Real.log (lowCountExponentialConstant rho (pilotConstant Bpilot cp)) + c)) ≤ R)
    (hcut : (Fintype.card ι : ℝ) * aCut ≤ rho / D) (hBpilotpos : 0 < Bpilot)
    (hEactual : 0 ≤ Eactual) (hustar : 0 < ustar) (heta : 0 < eta)
    (hbaseline : E ≤ Eactual + kappa * u / ustar)
    (hPP : (Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + gamma)) ≤ ∑ i, p i ^ ((m : ℝ) + gamma))
    (hDeta : conditionalCountRateConstant E0 u0 * (1 + 1 / ustar) ^ 2 / eta ≤ D) :
    pilotAveragedCountVariance Counts Pilot (cp * Bpilot * ((m : ℝ) + gamma)) d
      (completedCoupledPolynomial ell Nk m gamma aCut b cProfile fL f A B omega).coeff n μ ν ≤
      eta * (Eactual * (Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + gamma)) +
        kappa * u * (∑ i, p i ^ ((m : ℝ) + gamma)) +
        kappa * conditionalCountBonus p ((m : ℝ) + gamma) n L) ^ 2 := by
  have hreference := completed_conditional_count_variance_reference (p := p) (Counts := Counts) (lam := lam) (Pilot := Pilot)
    (hell := hell) (hNk := hNk) (hmDegree := hmDegree) (hcProfile := hcProfile) (hdegree := hdegree) (hgamma := hgamma) (hgamma1 := hgamma1) (halpha := halpha)
    (haCut := haCut) (hab := hab) (hb := hb) (hfL := hfL) (hfL1 := hfL1) (hf := hf) (hf1 := hf1)
    (hA := hA) (hA1 := hA1) (hB := hB) (hB1 := hB1) (hw := hw) (hw1 := hw1) (hlocal := hlocal)
    (hLactual := hLactual) (hCL := hCL) (hcL := hcL) (hellL := hellL) (hNkL := hNkL) (hscale := hscale)
    (hcountScale := hcountScale) (hH := hH) (hrd := hrd) (hCd := hCd) (hdegreeL := hdegreeL) (hCt := hCt) (hCt2 := hCt2)
    (hcp := hcp) (hBpilot := hBpilot) (hM := hM) (hdegreeH := hdegreeH) (hcpM := hcpM)
    (hD := hD) (hX := hX) (hE0 := hE0) (hu0 := hu0) (hc := hc) (hsmall := hsmall)
    (hRtiny := hRtiny) (hRmedium := hRmedium) (hE := hE) (hkappa := hkappa) (hu := hu)
    (hp := hp) (hk := hk) (hnsize := hnsize) (hLaw := hLaw) (hpair := hpair) (hPilot := hPilot) (hlam := hlam)
    hrho hRlow hcut hBpilotpos
  have hD0 : 0 < D := zero_lt_one.trans_le hD
  have hX0 : 0 < X := zero_lt_one.trans_le hX
  have hR0 : 0 < R := (Real.exp_pos _).trans_le hRtiny
  have hEpos : 0 < E := (by positivity : 0 < E0 * (R / D) ^ ((m : ℝ) + gamma - 1)).trans_le hE
  have hkappapos : 0 < kappa := (Real.exp_pos _).trans_le hkappa
  have hupos : 0 < u := (by positivity : 0 < u0 * X ^ (-((m : ℝ) + gamma))).trans_le hu
  have hn : 0 < n := by rw [hnsize]; positivity
  have ha : 1 < (m : ℝ) + gamma := by linarith
  have hLpos : 0 < L := by rw [hLactual]; exact_mod_cast upperDegree_pos ha hCL hcL hX
  have hPstar : 0 < (Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + gamma)) := Real.rpow_pos_of_pos hk _
  have hBonus := conditionalCountBonus_nonneg p hp hn.le hLpos.le (alpha := (m : ℝ) + gamma)
  have hK := conditionalCountRateConstant_pos hE0 hu0
  change _ ≤ conditionalCountRateConstant E0 u0 / D at hreference
  have htransfer := count_variance_source_margin_transfer hK.le hD0 hEpos hEactual hkappapos hupos hustar
    hPstar hPP hBonus hbaseline hreference
  exact count_variance_choose_sample_multiplier hD0 heta hDeta htransfer

end ActualCount
end Renyi
