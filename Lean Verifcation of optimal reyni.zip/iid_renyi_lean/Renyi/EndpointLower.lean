import Renyi.HiddenScale
import Renyi.HighOrder
import Renyi.IntegerIID

/-! Actual fixed-sample collision lower bound, uniformly in the real order. -/
noncomputable section
open scoped BigOperators
open MeasureTheory
namespace Renyi

def collisionAmplification (eps : ℝ) : ℝ := Real.exp (2 * eps + 2)
def collisionLowerConstant (eps : ℝ) : ℝ :=
  1 / (16384 * (collisionAmplification eps - 1) ^ 2)

theorem collisionAmplification_gt_one {eps : ℝ} (heps : 0 < eps) :
    1 < collisionAmplification eps := by
  unfold collisionAmplification
  exact Real.one_lt_exp_iff.mpr (by linarith)

theorem collisionLowerConstant_pos {eps : ℝ} (heps : 0 < eps) :
    0 < collisionLowerConstant eps := by
  unfold collisionLowerConstant
  have h := collisionAmplification_gt_one heps
  exact div_pos (by norm_num) (mul_pos (by norm_num) (sq_pos_of_pos (sub_pos.mpr h)))

private theorem collision_inverse_scale {k : ℕ} (hk : 0 < k) (ell : ℝ) :
    (k : ℝ) ^ (1 - 1 / ell) * collisionQ k ell = 1 := by
  have hkR : 0 < (k : ℝ) := by exact_mod_cast hk
  rw [collisionQ, ← Real.rpow_add hkR]
  convert Real.rpow_zero (k : ℝ) using 1
  ring

/-- The actual hidden-coordinate mixture has total variation at most one quarter
at the collision scale, including the common reservoir contribution. -/
theorem collision_mixture_tv {k n : ℕ} {ell eps : ℝ} (heps : 0 < eps)
    (hk : 2 ≤ k) (hell : 3 / 2 ≤ ell) (hellk : ell ≤ Real.log k)
    (hsmall : (k : ℝ) ^ (-(1 / 4) : ℝ) ≤ 1 / 4)
    (hBsmall : collisionAmplification eps * (k : ℝ) ^ (-(1 / 3) : ℝ) ≤ 1 / 4)
    (hlogsmall : (1 + Real.log k) * (k : ℝ) ^ (-(1 / 3) : ℝ) ≤ 1 / 2)
    (hn : (n : ℝ) ≤ collisionLowerConstant eps * ell * (k : ℝ) ^ (1 - 1 / ell)) :
    let B := collisionAmplification eps
    let m := collisionMultiplicity ell
    let q := collisionQ k ell
    ∃ (e : Fin m ↪ Fin k) (hmk : m < k) (hq : 0 < q)
      (hB : 1 ≤ B) (hmq : m * q < 1) (hv : m * q + (B - 1) * q ≤ 1),
      finiteTV (iidMass (hiddenNull e q hmk hq.le hmq.le) n)
        (iidUniformMixture (hiddenAlternative e q B hmk hq.le hB hv) n) ≤ 1 / 4 := by
  dsimp only
  let B := collisionAmplification eps
  let m := collisionMultiplicity ell
  let q := collisionQ k ell
  have hB : 1 < B := collisionAmplification_gt_one heps
  obtain ⟨hmk, hmq, hv, hres⟩ := collision_parameter_validity hk hell hellk hB.le
    hsmall hBsmall hlogsmall
  change m < k at hmk
  change (m : ℝ) * q < 1 at hmq
  change (m : ℝ) * q + (B - 1) * q ≤ 1 at hv
  change (1 + Real.log m) * q / (1 - m * q) ≤ 1 at hres
  have hq : 0 < q := Real.rpow_pos_of_pos (by exact_mod_cast (show 0 < k by omega)) _
  have hm : 0 < m := collisionMultiplicity_pos (by linarith)
  let e : Fin m ↪ Fin k := Fin.castLEEmb hmk.le
  refine ⟨e, hmk, hq, hB.le, hmq, hv, ?_⟩
  let u := (n : ℝ) * (B - 1) ^ 2 * q
  let v := (n : ℝ) * (B - 1) ^ 2 * q ^ 2 / (1 - m * q)
  have hden : 0 < 1 - (m : ℝ) * q := sub_pos.mpr hmq
  have hu : u ≤ (1 / 256 : ℝ) * (1 + Real.log m) := by
    have hmul := mul_le_mul_of_nonneg_right hn (mul_nonneg (sq_nonneg (B - 1)) hq.le)
    have hid := collision_inverse_scale (show 0 < k by omega) ell
    change (k : ℝ) ^ (1 - 1 / ell) * q = 1 at hid
    have hs : collisionLowerConstant eps * ell * (k : ℝ) ^ (1 - 1 / ell) *
        ((B - 1) ^ 2 * q) = ell / 16384 := by
      unfold collisionLowerConstant
      change (1 / (16384 * (B - 1) ^ 2)) * ell * (k : ℝ) ^ (1 - 1 / ell) *
        ((B - 1) ^ 2 * q) = ell / 16384
      calc
        _ = ((B - 1) ^ 2 / (16384 * (B - 1) ^ 2)) * ell *
            ((k : ℝ) ^ (1 - 1 / ell) * q) := by ring
        _ = ell / 16384 := by
          rw [hid]
          field_simp [ne_of_gt (sub_pos.mpr hB)]
    rw [hs] at hmul
    have hmLog := (collisionMultiplicity_log (by linarith : 0 ≤ ell)).1
    dsimp [u]
    nlinarith
  have hv0 : 0 ≤ v := by dsimp [v]; positivity
  have hv1 : v ≤ (1 / 256 : ℝ) := by
    have h1 := mul_le_mul_of_nonneg_right hu (div_nonneg hq.le hden.le)
    have hid : v = u * (q / (1 - (m : ℝ) * q)) := by dsimp [u, v]; ring
    rw [hid]
    calc
      _ ≤ (1 / 256 : ℝ) * (1 + Real.log m) * (q / (1 - m * q)) := h1
      _ = (1 / 256 : ℝ) * ((1 + Real.log m) * q / (1 - m * q)) := by ring
      _ ≤ (1 / 256 : ℝ) := by linarith [mul_le_mul_of_nonneg_left hres (by norm_num : (0 : ℝ) ≤ 1 / 256)]
  have hchi := (hidden_coordinate_chisq_bound e q B hm hmk hq hB.le hmq hv (n := n)).trans
    (hidden_mixture_scalar_bound hm (by norm_num : (0 : ℝ) ≤ 1 / 256)
      (by norm_num) hv0 hv1 hu)
  have hsqrt : Real.sqrt (iidMixtureChiSq (hiddenNull e q hmk hq.le hmq.le)
      (hiddenAlternative e q B hmk hq.le hB.le hv) n) ≤ 1 / 2 := by
    apply (Real.sqrt_le_iff).2
    exact ⟨by norm_num, by norm_num at hchi ⊢; linarith⟩
  exact (iidMixtureTV_le_sqrt_chisq _ _ (hiddenNull_pos e q hmk hq hmq)).trans (by linarith)

/-- Uniform fixed-size iid impossibility at the complete collision/saturation
scale for every finite order at least three halves. -/
theorem collision_iid_lower_uniform {eps : ℝ} (heps : 0 < eps) :
    ∃ c : ℝ, 0 < c ∧ ∃ K : ℕ, 2 ≤ K ∧ ∀ k : ℕ, K ≤ k →
      ∀ a : ℝ, 3 / 2 ≤ a → ∀ n : ℕ,
        (n : ℝ) ≤ c * min a (Real.log k) * (k : ℝ) ^ (1 - 1 / min a (Real.log k)) →
        ¬ Achievable k n a eps := by
  obtain ⟨K, hK, hlarge⟩ := collision_large_alphabet (collisionAmplification eps)
  refine ⟨collisionLowerConstant eps, collisionLowerConstant_pos heps, K, hK, ?_⟩
  intro k hk a ha n hn
  obtain ⟨hlog, hsmall, hBsmall, hlogsmall⟩ := hlarge k hk
  let ell := min a (Real.log k)
  have hell : 3 / 2 ≤ ell := le_min ha hlog
  have hellk : ell ≤ Real.log k := min_le_right _ _
  have hella : ell ≤ a := min_le_left _ _
  have hk2 : 2 ≤ k := hK.trans hk
  obtain ⟨e, hmk, hq, hB, hmq, hv, hTV⟩ := collision_mixture_tv heps hk2 hell hellk
    hsmall hBsmall hlogsmall hn
  apply iidUniformMixture_impossibility _ _ (collisionMultiplicity_pos (by linarith : 0 ≤ ell)) a eps _ hTV
  intro s
  have hr := collision_reservoir_power (show 1 ≤ k by omega) hmk hell hella hmq.le
  have hgap := hidden_coordinate_entropy_gap e (collisionQ k ell) (collisionAmplification eps) a
    hmk hq hB hmq hv (by linarith) hr s
  have hlogm := (collisionMultiplicity_log (by linarith : 0 ≤ ell)).2.2
  have hlogtwo := Real.log_le_sub_one_of_pos (show (0 : ℝ) < 2 by norm_num)
  have hlogB : Real.log (collisionAmplification eps) = 2 * eps + 2 := Real.log_exp _
  rw [hlogB] at hgap
  have hstrict : 2 * eps <
      (a * (2 * eps + 2) - Real.log ((collisionMultiplicity ell : ℝ) + 1)) / (a - 1) := by
    apply (lt_div_iff₀ (by linarith : 0 < a - 1)).2
    nlinarith
  exact hstrict.trans_le hgap

theorem functionalUniformMixture_impossibility {k m n : ℕ} (p : Simplex k)
    (q : Fin m → Simplex k) (hm : 0 < m) (F : Simplex k → ℝ) (eps : ℝ)
    (hgap : ∀ s, 2 * eps < F p - F (q s))
    (hTV : finiteTV (iidMass p n) (iidUniformMixture q n) ≤ 1 / 4) :
    ¬ (∃ est : Estimator k n, ∀ p : Simplex k,
      (∑ x, iidMass p n x * (est x {z : ℝ | eps < |z - F p|} : ℝ)) ≤ 1 / 3) := by
  rintro ⟨est, hest⟩
  let low : Set ℝ := Set.Iio (F p - eps)
  let t : Sample k n → ℝ := fun x => (est x low : ℝ)
  have ht0 : ∀ x, 0 ≤ t x := fun _ => NNReal.coe_nonneg _
  have ht1 : ∀ x, t x ≤ 1 := by
    intro x
    exact_mod_cast (est x).apply_le_one low
  have htest := finite_testing_lower_bound (iidMass p n) (iidUniformMixture q n) t
    (iidMass_sum p n) (iidUniformMixture_sum q n hm) ht0 ht1
  have hleft : ∑ x, iidMass p n x * t x ≤ (∑ x, iidMass p n x * (est x {z : ℝ | eps < |z - F p|} : ℝ)) := by
    apply Finset.sum_le_sum
    intro x _
    apply mul_le_mul_of_nonneg_left _ (iidMass_nonneg p x)
    apply NNReal.coe_le_coe.mpr
    apply (est x).apply_mono
    intro z hz
    change z < F p - eps at hz
    change eps < |z - F p|
    exact (by linarith : eps < -(z - F p)).trans_le (neg_le_abs _)
  have hright (s : Fin m) : ∑ x, iidMass (q s) n x * (1 - t x) ≤
      (∑ x, iidMass (q s) n x * (est x {z : ℝ | eps < |z - F (q s)|} : ℝ)) := by
    apply Finset.sum_le_sum
    intro x _
    apply mul_le_mul_of_nonneg_left _ (iidMass_nonneg (q s) x)
    have hcomp : (est x low : ℝ) + (est x lowᶜ : ℝ) = 1 := by
      simpa only [MeasureTheory.ProbabilityMeasure.measureReal_eq_coe_coeFn,
        MeasureTheory.ProbabilityMeasure.coeFn_univ, NNReal.coe_one] using
        (MeasureTheory.measureReal_add_measureReal_compl (μ := (est x : MeasureTheory.Measure ℝ))
          (show MeasurableSet low from measurableSet_Iio))
    have hb : (est x lowᶜ : ℝ) ≤ (est x {z | eps < |z - F (q s)|} : ℝ) := by
      apply NNReal.coe_le_coe.mpr
      apply (est x).apply_mono
      intro z hz
      have hz' : F p - eps ≤ z := le_of_not_gt hz
      exact (by linarith [hgap s] : eps < z - F (q s)).trans_le (le_abs_self _)
    dsimp [t]
    linarith
  have hmix : ∑ x, iidUniformMixture q n x * (1 - t x) ≤ 1 / 3 := by
    have hbound := Finset.sum_le_sum (s := Finset.univ)
      (fun s _ => (hright s).trans (hest (q s)))
    have hmpos : 0 < (m : ℝ) := by exact_mod_cast hm
    unfold iidUniformMixture
    simp_rw [div_mul_eq_mul_div, Finset.sum_mul]
    rw [← Finset.sum_div, Finset.sum_comm]
    apply (div_le_iff₀ hmpos).2
    simpa [mul_comm] using hbound
  rw [Finset.sum_add_distrib] at htest
  linarith [hleft.trans (hest p)]


/-- Min-entropy separation of the actual hidden-coordinate family. -/
theorem hidden_coordinate_minEntropy_gap {m k : ℕ} (e : Fin m ↪ Fin k) (q B : ℝ)
    (hm : 0 < m) (hmk : m < k) (hq : 0 < q) (hB : 1 ≤ B) (hmq : m * q < 1)
    (hvalid : m * q + (B - 1) * q ≤ 1) (hkq : 1 ≤ (k : ℝ) * q)
    (s : Fin m) :
    Real.log B ≤ minEntropy (hiddenNull e q hmk hq.le hmq.le) -
      minEntropy (hiddenAlternative e q B hmk hq.le hB hvalid s) := by
  let p₀ := hiddenNull e q hmk hq.le hmq.le
  let p₁ := hiddenAlternative e q B hmk hq.le hB hvalid s
  letI : Nonempty (Fin k) := ⟨e ⟨0, hm⟩⟩
  have hres : hiddenNullReservoir k m q ≤ q := by
    apply (div_le_iff₀ (sub_pos.mpr (by exact_mod_cast hmk) : (0 : ℝ) < (k : ℝ) - m)).2
    nlinarith
  have hnull : sSup (Set.range p₀.mass) = q := by
    apply le_antisymm
    · apply csSup_le (Set.range_nonempty p₀.mass)
      rintro z ⟨j, rfl⟩
      change labeledReservoirMass e (fun _ => q) (hiddenNullReservoir k m q) j ≤ q
      by_cases hj : ∃ i, e i = j
      · obtain ⟨i, rfl⟩ := hj
        simp
      · rw [labeledReservoirMass_off e _ _ hj]
        exact hres
    · have hval : p₀.mass (e s) = q := labeledReservoirMass_at e _ _ s
      exact hval ▸ le_csSup (Set.finite_range p₀.mass).bddAbove ⟨e s, rfl⟩
  have halt : B * q ≤ sSup (Set.range p₁.mass) := by
    have hval : p₁.mass (e s) = B * q := by
      change labeledReservoirMass e (hiddenDistinguished q B s) _ (e s) = _
      simp [hiddenDistinguished]
    exact hval ▸ le_csSup (Set.finite_range p₁.mass).bddAbove ⟨e s, rfl⟩
  have hBpos : 0 < B := lt_of_lt_of_le zero_lt_one hB
  have hlog := Real.log_le_log (mul_pos hBpos hq) halt
  rw [Real.log_mul hBpos.ne' hq.ne'] at hlog
  change Real.log B ≤ -Real.log (sSup (Set.range p₀.mass)) -
    -Real.log (sSup (Set.range p₁.mass))
  rw [hnull]
  linarith

/-- At saturation the collision scale is exactly `(k log k)/e`. -/
theorem collision_saturation_scale {k : ℕ} (hk : 1 < k) :
    Real.log k * (k : ℝ) ^ (1 - 1 / Real.log k) =
      ((k : ℝ) * Real.log k) / Real.exp 1 := by
  have hkR : 1 < (k : ℝ) := by exact_mod_cast hk
  have hkpos : 0 < (k : ℝ) := by linarith
  have hl : 0 < Real.log k := Real.log_pos hkR
  have hp : (k : ℝ) ^ (1 - 1 / Real.log k) = (k : ℝ) / Real.exp 1 := by
    rw [Real.rpow_def_of_pos hkpos]
    have hexp : Real.log k * (1 - 1 / Real.log k) = Real.log k - 1 := by
      field_simp
    rw [hexp, Real.exp_sub, Real.exp_log hkpos]
  rw [hp]
  ring

/-- The min-entropy endpoint has the actual uniform fixed-iid lower bound. -/
theorem min_entropy_iid_lower_uniform {eps : ℝ} (heps : 0 < eps) :
    ∃ c : ℝ, 0 < c ∧ ∃ K : ℕ, 2 ≤ K ∧ ∀ k : ℕ, K ≤ k →
      ∀ n : ℕ, (n : ℝ) ≤ c * ((k : ℝ) * Real.log k) →
        ¬ MinEntropyAchievable k n eps := by
  obtain ⟨K, hK, hlarge⟩ := collision_large_alphabet (collisionAmplification eps)
  refine ⟨collisionLowerConstant eps / Real.exp 1, div_pos (collisionLowerConstant_pos heps)
    (Real.exp_pos 1), K, hK, ?_⟩
  intro k hk n hn
  have hk2 := hK.trans hk
  obtain ⟨hlog, hsmall, hBsmall, hlogsmall⟩ := hlarge k hk
  have hn' : (n : ℝ) ≤ collisionLowerConstant eps * Real.log k *
      (k : ℝ) ^ (1 - 1 / Real.log k) := by
    rw [mul_assoc, collision_saturation_scale (show 1 < k by omega)]
    convert hn using 1
    ring
  obtain ⟨e, hmk, hq, hB, hmq, hv, hTV⟩ := collision_mixture_tv heps hk2 hlog le_rfl
    hsmall hBsmall hlogsmall hn'
  apply functionalUniformMixture_impossibility _ _
    (collisionMultiplicity_pos (by linarith : 0 ≤ Real.log k)) minEntropy eps _ hTV
  intro s
  have hqlo := (collisionQ_bounds (show 1 ≤ k by omega) hlog).1
  rw [Real.rpow_neg_one] at hqlo
  have hkq : 1 ≤ (k : ℝ) * collisionQ k (Real.log k) := by
    have h := mul_le_mul_of_nonneg_left hqlo (show (0 : ℝ) ≤ k by positivity)
    have hkR : (k : ℝ) ≠ 0 := by exact_mod_cast (show k ≠ 0 by omega)
    simpa [hkR] using h
  have hgap := hidden_coordinate_minEntropy_gap e (collisionQ k (Real.log k))
    (collisionAmplification eps) (collisionMultiplicity_pos (by linarith : 0 ≤ Real.log k))
    hmk hq hB hmq hv hkq s
  rw [show Real.log (collisionAmplification eps) = 2 * eps + 2 from Real.log_exp _] at hgap
  linarith

/-- A proof term for the full min-entropy minimax proposition in `Model`. -/
theorem min_entropy_minimax_verified : MinEntropyMinimaxClaim := by
  intro eps heps _hepshalf
  obtain ⟨c, hc, K, hK, hlower⟩ := min_entropy_iid_lower_uniform heps
  obtain ⟨C, hC, hupper⟩ := high_order_and_min_entropy_upper heps
  refine ⟨c, C, K, hc, hC, ?_⟩
  intro k hk _hlog
  constructor
  · obtain ⟨n, hn, _, hmin⟩ := hupper k (hK.trans hk)
    exact ⟨n, hn, hmin⟩
  · intro n hn
    exact (lt_of_not_ge (fun h => (hlower k hk n h) hn)).le

/-- Matching collision/saturation rates for all integer orders. The constants
are uniform over both the integer order and the alphabet size. -/
theorem integer_iid_minimax_uniform {eps : ℝ} (heps : 0 < eps) (hepshalf : eps ≤ 1 / 2) :
    ∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∃ K : ℕ, 2 ≤ K ∧
      ∀ k : ℕ, K ≤ k → ∀ r : ℕ, 2 ≤ r →
        (∃ n : ℕ, (n : ℝ) ≤ C * (min (r : ℝ) (Real.log k) *
          (k : ℝ) ^ (1 - 1 / min (r : ℝ) (Real.log k))) ∧ Achievable k n (r : ℝ) eps) ∧
        (∀ n : ℕ, Achievable k n (r : ℝ) eps →
          c * (min (r : ℝ) (Real.log k) *
            (k : ℝ) ^ (1 - 1 / min (r : ℝ) (Real.log k))) ≤ (n : ℝ)) := by
  obtain ⟨c, hc, K, hK, hlower⟩ := collision_iid_lower_uniform heps
  obtain ⟨C₁, hC₁, hupper₁⟩ := integer_iid_upper_uniform heps hepshalf
  obtain ⟨C₂, hC₂, hupper₂⟩ := high_order_and_min_entropy_upper heps
  let C := max C₁ (C₂ * Real.exp 1)
  refine ⟨c, C, hc, lt_of_lt_of_le hC₁ (le_max_left _ _), K, hK, ?_⟩
  intro k hk r hr
  have hk2 := hK.trans hk
  have hrR : (2 : ℝ) ≤ r := by exact_mod_cast hr
  constructor
  · by_cases hlow : (r : ℝ) ≤ Real.log k
    · obtain ⟨n, hn, ha⟩ := hupper₁ k r hk2 hr
      refine ⟨n, ?_, ha⟩
      rw [min_eq_left hlow]
      exact hn.trans (mul_le_mul_of_nonneg_right (le_max_left _ _)
        (by positivity : 0 ≤ (r : ℝ) * (k : ℝ) ^ (1 - 1 / (r : ℝ))))
    · obtain ⟨n, hn, ha, _⟩ := hupper₂ k hk2
      refine ⟨n, ?_, ha r hrR⟩
      rw [min_eq_right (le_of_not_ge hlow), collision_saturation_scale (by omega : 1 < k)]
      have hs : 0 ≤ (k : ℝ) * Real.log k := mul_nonneg (Nat.cast_nonneg _)
        (Real.log_nonneg (by exact_mod_cast (show 1 ≤ k by omega)))
      have hh := mul_le_mul_of_nonneg_right (le_max_right C₁ (C₂ * Real.exp 1))
        (div_nonneg hs (Real.exp_pos 1).le)
      have heq : (C₂ * Real.exp 1) * (((k : ℝ) * Real.log k) / Real.exp 1) =
          C₂ * ((k : ℝ) * Real.log k) := by field_simp
      rw [heq] at hh
      exact hn.trans hh
  · intro n hn
    have h := lt_of_not_ge (fun h => (hlower k hk r (by linarith) n (by simpa only [mul_assoc] using h)) hn)
    exact h.le

/-- Both minimax inequalities at the exact extended rate for every finite
order at or above `log k`. -/
theorem high_order_iid_minimax_uniform {eps : ℝ} (heps : 0 < eps) :
    ∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∃ K : ℕ, 2 ≤ K ∧
      ∀ k : ℕ, K ≤ k → 2 < Real.log k → ∀ a : ℝ, Real.log k ≤ a →
        (∃ n : ℕ, (n : ℝ) ≤ C * rate k a eps ∧ Achievable k n a eps) ∧
        (∀ n : ℕ, Achievable k n a eps → c * rate k a eps ≤ (n : ℝ)) := by
  obtain ⟨c, hc, K, hK, hlower⟩ := collision_iid_lower_uniform heps
  obtain ⟨C, hC, hupper⟩ := high_order_and_min_entropy_upper heps
  refine ⟨c / Real.exp 1, C, div_pos hc (Real.exp_pos 1), hC, K, hK, ?_⟩
  intro k hk hlog a ha
  have hk2 := hK.trans hk
  have hrate := rate_high_order (ε := eps) (show 0 < k by omega) (by linarith : 0 < a) ha
  rw [hrate]
  constructor
  · obtain ⟨n, hn, ha', _⟩ := hupper k hk2
    exact ⟨n, hn, ha' a (by linarith)⟩
  · intro n hn
    have hnecess : c * (min a (Real.log k) *
        (k : ℝ) ^ (1 - 1 / min a (Real.log k))) ≤ (n : ℝ) := by
      exact (lt_of_not_ge (fun h => (hlower k hk a (by linarith) n
        (by simpa only [mul_assoc] using h)) hn)).le
    rw [min_eq_right ha, collision_saturation_scale (by omega : 1 < k)] at hnecess
    convert hnecess using 1
    ring

def integerMultiplierBound (eps : ℝ) : ℝ := max 1 (1 / (4 * eps))

theorem integer_rootMultiplier_bound {eps : ℝ} (heps : 0 < eps) {r : ℕ} (hr : 2 ≤ r) :
    max 1 ((2 * eps * (r : ℝ)) ^ (-1 / (r : ℝ))) ≤ integerMultiplierBound eps := by
  have hrR : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hrpos : (0 : ℝ) < r := by linarith
  have hxpos : 0 < 2 * eps * (r : ℝ) := by positivity
  apply max_le (le_max_left _ _) _
  by_cases hx : 1 ≤ 2 * eps * (r : ℝ)
  · exact (Real.rpow_le_one_of_one_le_of_nonpos hx (div_nonpos_of_nonpos_of_nonneg (by norm_num) hrpos.le)).trans (le_max_left _ _)
  · have hx1 : 2 * eps * (r : ℝ) ≤ 1 := (lt_of_not_ge hx).le
    have he : -(1 : ℝ) ≤ -1 / (r : ℝ) := by
      have h := (div_le_one hrpos).2 (by linarith : (1 : ℝ) ≤ r)
      simpa only [neg_div] using neg_le_neg h
    have hp := Real.rpow_le_rpow_of_exponent_ge hxpos hx1 he
    rw [Real.rpow_neg_one] at hp
    have hi : (2 * eps * (r : ℝ))⁻¹ ≤ 1 / (4 * eps) := by
      rw [← one_div]
      exact one_div_le_one_div_of_le (by positivity) (by nlinarith)
    exact (hp.trans hi).trans (le_max_right _ _)

/-- Comparing the extended integer rate to the collision/saturation scale uses
only a fixed accuracy-dependent factor. -/
theorem integer_extended_rate_comparison {eps : ℝ} (heps : 0 < eps)
    {k r : ℕ} (hk : 2 ≤ k) (hr : 2 ≤ r) :
    let S := min (r : ℝ) (Real.log k) * (k : ℝ) ^ (1 - 1 / min (r : ℝ) (Real.log k))
    S ≤ rate k (r : ℝ) eps ∧ rate k (r : ℝ) eps ≤
      max (integerMultiplierBound eps) (Real.exp 1) * S := by
  dsimp only
  have hrR : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hrpos : (0 : ℝ) < r := by linarith
  by_cases hhigh : Real.log k ≤ (r : ℝ)
  · rw [min_eq_right hhigh, collision_saturation_scale (show 1 < k by omega),
      rate_high_order (show 0 < k by omega) hrpos hhigh]
    have hs : 0 ≤ (k : ℝ) * Real.log k := mul_nonneg (Nat.cast_nonneg _)
      (Real.log_nonneg (by exact_mod_cast (show 1 ≤ k by omega)))
    have he : 1 ≤ Real.exp (1 : ℝ) := Real.one_le_exp (by norm_num)
    constructor
    · exact div_le_self hs he
    · have h := mul_le_mul_of_nonneg_right
        (le_max_right (integerMultiplierBound eps) (Real.exp 1)) (div_nonneg hs (Real.exp_pos 1).le)
      have heq : Real.exp 1 * (((k : ℝ) * Real.log k) / Real.exp 1) =
          (k : ℝ) * Real.log k := by field_simp
      rw [heq] at h
      exact h
  · have hlow : (r : ℝ) < Real.log k := lt_of_not_ge hhigh
    rw [min_eq_left hlow.le]
    have hrepr : extendedMultiplier k (r : ℝ) eps =
        max 1 ((2 * eps * (r : ℝ)) ^ (-1 / (r : ℝ))) := by
      simp [extendedMultiplier, hhigh]
    unfold rate
    rw [hrepr]
    have hs : 0 ≤ (r : ℝ) * (k : ℝ) ^ (1 - 1 / (r : ℝ)) := by positivity
    constructor
    · exact le_mul_of_one_le_right hs (le_max_left _ _)
    · have h := mul_le_mul_of_nonneg_left
        ((integer_rootMultiplier_bound heps hr).trans
          (le_max_left (integerMultiplierBound eps) (Real.exp 1))) hs
      simpa only [mul_comm] using h

/-- Matching integer bounds in exactly the extended-rate notation of `Model`. -/
theorem integer_iid_minimax_extended_rate {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) :
    ∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∃ K : ℕ, 2 ≤ K ∧
      ∀ k : ℕ, K ≤ k → ∀ r : ℕ, 2 ≤ r →
        (∃ n : ℕ, (n : ℝ) ≤ C * rate k (r : ℝ) eps ∧ Achievable k n (r : ℝ) eps) ∧
        (∀ n : ℕ, Achievable k n (r : ℝ) eps → c * rate k (r : ℝ) eps ≤ (n : ℝ)) := by
  obtain ⟨c, C, hc, hC, K, hK, hmain⟩ := integer_iid_minimax_uniform heps hepshalf
  let M := max (integerMultiplierBound eps) (Real.exp 1)
  have hM : 0 < M := lt_of_lt_of_le (Real.exp_pos 1) (le_max_right _ _)
  refine ⟨c / M, C, div_pos hc hM, hC, K, hK, ?_⟩
  intro k hk r hr
  have hcmp := integer_extended_rate_comparison heps (hK.trans hk) hr
  obtain ⟨hupper, hlower⟩ := hmain k hk r hr
  constructor
  · obtain ⟨n, hn, ha⟩ := hupper
    exact ⟨n, hn.trans (mul_le_mul_of_nonneg_left hcmp.1 hC.le), ha⟩
  · intro n hn
    have hb := mul_le_mul_of_nonneg_left hcmp.2 (div_nonneg hc.le hM.le)
    have hid : (c / M) * (M * (min (r : ℝ) (Real.log k) *
        (k : ℝ) ^ (1 - 1 / min (r : ℝ) (Real.log k)))) =
        c * (min (r : ℝ) (Real.log k) *
          (k : ℝ) ^ (1 - 1 / min (r : ℝ) (Real.log k))) := by field_simp
    rw [hid] at hb
    exact hb.trans (hlower n hn)

/-- The verified finite-order part excludes only noninteger orders below `log k`.
This proposition is strictly weaker than `UniformMinimaxClaim`. -/
theorem endpoint_iid_minimax_verified {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) :
    ∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∃ K : ℕ, 2 ≤ K ∧
      ∀ k : ℕ, K ≤ k → 2 < Real.log k → ∀ a : ℝ, 1 < a →
        ((∃ r : ℕ, a = (r : ℝ)) ∨ Real.log k ≤ a) →
        (∃ n : ℕ, (n : ℝ) ≤ C * rate k a eps ∧ Achievable k n a eps) ∧
        (∀ n : ℕ, Achievable k n a eps → c * rate k a eps ≤ (n : ℝ)) := by
  obtain ⟨c₁, C₁, hc₁, hC₁, K₁, hK₁, h₁⟩ := integer_iid_minimax_extended_rate heps hepshalf
  obtain ⟨c₂, C₂, hc₂, hC₂, K₂, hK₂, h₂⟩ := high_order_iid_minimax_uniform heps
  refine ⟨min c₁ c₂, max C₁ C₂, lt_min hc₁ hc₂,
    lt_of_lt_of_le hC₁ (le_max_left _ _), max K₁ K₂,
    hK₁.trans (le_max_left _ _), ?_⟩
  intro k hk hlog a ha hcase
  have hmerge (c' C' : ℝ) (hC' : 0 < C')
      (hc' : min c₁ c₂ ≤ c') (hCmax : C' ≤ max C₁ C₂)
      (hresult : (∃ n : ℕ, (n : ℝ) ≤ C' * rate k a eps ∧ Achievable k n a eps) ∧
        (∀ n : ℕ, Achievable k n a eps → c' * rate k a eps ≤ (n : ℝ))) :
      (∃ n : ℕ, (n : ℝ) ≤ max C₁ C₂ * rate k a eps ∧ Achievable k n a eps) ∧
        (∀ n : ℕ, Achievable k n a eps → min c₁ c₂ * rate k a eps ≤ (n : ℝ)) := by
    obtain ⟨⟨n, hn, hach⟩, hlow⟩ := hresult
    have hrate0 : 0 ≤ rate k a eps := by nlinarith [show (0 : ℝ) ≤ n by positivity]
    exact ⟨⟨n, hn.trans (mul_le_mul_of_nonneg_right hCmax hrate0), hach⟩,
      fun m hm => (mul_le_mul_of_nonneg_right hc' hrate0).trans (hlow m hm)⟩
  rcases hcase with ⟨r, rfl⟩ | hhigh
  · have hr : 2 ≤ r := by
      have h : (1 : ℕ) < r := by exact_mod_cast ha
      omega
    exact hmerge c₁ C₁ hC₁ (min_le_left _ _) (le_max_left _ _)
      (h₁ k ((le_max_left _ _).trans hk) r hr)
  · exact hmerge c₂ C₂ hC₂ (min_le_right _ _) (le_max_right _ _)
      (h₂ k ((le_max_right _ _).trans hk) hlog a hhigh)

end Renyi
