import Renyi.NormalizationProbability
import Mathlib.Algebra.MvPolynomial.Basic
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Probability.ProbabilityMassFunction.Constructions

/-!
# Poisson splitting on a finite mark space

This module establishes distribution identities, rather than assuming a Poisson
marking certificate. The multinomial law is constructed explicitly and Poisson
mixing of that law is identified with a product of Poisson distributions.
-/

noncomputable section
open scoped BigOperators ENNReal NNReal
open MeasureTheory ProbabilityTheory

namespace Renyi

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The mass of a multinomial count vector, before the total-count restriction. -/
def multinomialMass (p : ι → ℝ≥0) (c : ι → ℕ) : ℝ≥0∞ :=
  (Nat.multinomial Finset.univ c : ℝ≥0∞) * ∏ i, (p i : ℝ≥0∞) ^ c i

/-- The finite multinomial theorem proves normalization, including total count zero. -/
theorem multinomialMass_sum (p : ι → ℝ≥0) (hp : ∑ i, p i = 1) (n : ℕ) :
    ∑ c ∈ Finset.piAntidiag Finset.univ n, multinomialMass p c = 1 := by
  have hsum : (∑ i, (p i : ℝ≥0∞)) = 1 := by
    exact_mod_cast hp
  simpa [multinomialMass, hsum] using
    (Finset.sum_pow_eq_sum_piAntidiag Finset.univ
      (fun i => (p i : ℝ≥0∞)) n).symm

/-- The count-vector distribution of a multinomial experiment. -/
def multinomialPMF (p : ι → ℝ≥0) (hp : ∑ i, p i = 1) (n : ℕ) : PMF (ι → ℕ) :=
  PMF.ofFinset
    (fun c => if ∑ i, c i = n then multinomialMass p c else 0)
    (Finset.piAntidiag Finset.univ n)
    (by
      rw [← multinomialMass_sum p hp n]
      apply Finset.sum_congr rfl
      intro c hc
      simp only [Finset.mem_piAntidiag, Finset.mem_univ, implies_true, and_true] at hc
      simp [hc])
    (by
      intro c hc
      have hne : ∑ i, c i ≠ n := by
        simpa only [Finset.mem_piAntidiag, Finset.mem_univ, implies_true, and_true] using hc
      simp [hne])

@[simp] theorem multinomialPMF_apply (p : ι → ℝ≥0) (hp : ∑ i, p i = 1)
    (n : ℕ) (c : ι → ℕ) :
    multinomialPMF p hp n c =
      if ∑ i, c i = n then multinomialMass p c else 0 := rfl

omit [DecidableEq ι] in
/-- Exact real-valued Poisson/multinomial factorization, valid also at zero rate
and at zero mark probabilities. -/
theorem poisson_multinomial_factorization_real (b : ℝ≥0) (p : ι → ℝ≥0)
    (hp : ∑ i, p i = 1) (c : ι → ℕ) :
    (∏ i, poissonPMFReal (b * p i) (c i)) =
      poissonPMFReal b (∑ i, c i) *
        ((Nat.multinomial Finset.univ c : ℝ) * ∏ i, (p i : ℝ) ^ c i) := by
  have hp' : ∑ i, (p i : ℝ) = 1 := by exact_mod_cast hp
  have hfac : (∏ i, ((c i).factorial : ℝ)) *
      (Nat.multinomial Finset.univ c : ℝ) = ((∑ i, c i).factorial : ℝ) := by
    exact_mod_cast Nat.multinomial_spec Finset.univ c
  have hden : (∏ i, ((c i).factorial : ℝ)) ≠ 0 := by positivity
  have htotal : ((∑ i, c i).factorial : ℝ) ≠ 0 := by positivity
  simp only [poissonPMFReal, NNReal.coe_mul, mul_pow,
    Finset.prod_div_distrib, Finset.prod_mul_distrib,
    Finset.prod_pow_eq_pow_sum, ← Real.exp_sum, Finset.sum_neg_distrib,
    ← Finset.mul_sum, hp', mul_one]
  field_simp
  rw [← hfac]
  ring

/-- The genuinely independent finite Poisson law. -/
def finitePoissonPMF (r : ι → ℝ≥0) : PMF (ι → ℕ) :=
  (Measure.pi (fun i => poissonMeasure (r i))).toPMF

omit [DecidableEq ι] in
@[simp] theorem finitePoissonPMF_apply (r : ι → ℝ≥0) (c : ι → ℕ) :
    finitePoissonPMF r c = ∏ i, poissonPMF (r i) (c i) := by
  rw [finitePoissonPMF, Measure.toPMF_apply]
  have hset : ({c} : Set (ι → ℕ)) = Set.univ.pi (fun i => {c i}) := by
    ext f
    simp only [Set.mem_singleton_iff, Set.mem_univ_pi, Set.mem_singleton_iff]
    exact funext_iff
  rw [hset, Measure.pi_pi]
  apply Finset.prod_congr rfl
  intro i _
  exact PMF.toMeasure_apply_singleton _ _ (MeasurableSet.singleton _)

/-- Poissonization turns the multinomial count distribution into independent
Poisson coordinates. This is an equality of probability mass functions. -/
theorem poisson_multinomial_split (b : ℝ≥0) (p : ι → ℝ≥0)
    (hp : ∑ i, p i = 1) :
    (poissonPMF b).bind (multinomialPMF p hp) =
      finitePoissonPMF (fun i => b * p i) := by
  ext c
  rw [PMF.bind_apply, finitePoissonPMF_apply]
  have hsum : (∑' n, poissonPMF b n * multinomialPMF p hp n c) =
      poissonPMF b (∑ i, c i) * multinomialMass p c := by
    rw [tsum_eq_single (∑ i, c i)]
    · simp
    · intro n hn
      simp [Ne.symm hn]
  rw [hsum]
  have heq := congrArg ENNReal.ofReal
    (poisson_multinomial_factorization_real b p hp c)
  simpa [multinomialMass, poissonPMF, ENNReal.ofReal_mul,
    ENNReal.ofReal_prod_of_nonneg, poissonPMFReal_nonneg,
    ENNReal.ofReal_pow, NNReal.coe_nonneg] using heq.symm

/-- A multinomial vector has exactly its prescribed total. -/
theorem multinomialPMF_map_total (p : ι → ℝ≥0) (hp : ∑ i, p i = 1) (n : ℕ) :
    (multinomialPMF p hp n).map (fun c => ∑ i, c i) = PMF.pure n := by
  classical
  ext k
  rw [PMF.map_apply, PMF.pure_apply]
  by_cases hk : k = n
  · subst k
    rw [if_pos rfl]
    calc
      _ = ∑' c, multinomialPMF p hp n c := by
        apply tsum_congr
        intro c
        by_cases hc : ∑ i, c i = n
        · simp [hc]
        · simp [hc, Ne.symm hc]
      _ = 1 := (multinomialPMF p hp n).tsum_coe
  · rw [if_neg hk]
    apply ENNReal.tsum_eq_zero.mpr
    intro c
    by_cases hc : ∑ i, c i = n
    · simp [hc, hk]
    · simp [hc]

/-- Independent Poisson coordinates with rates `b p_i` sum to `Poi(b)`. -/
theorem finitePoissonPMF_map_total (b : ℝ≥0) (p : ι → ℝ≥0)
    (hp : ∑ i, p i = 1) :
    (finitePoissonPMF (fun i => b * p i)).map (fun c => ∑ i, c i) =
      poissonPMF b := by
  rw [← poisson_multinomial_split b p hp, PMF.map_bind]
  simp only [multinomialPMF_map_total, PMF.bind_pure]

/-- The split coordinates are mutually independent, as random variables on the
Poissonized multinomial probability space. -/
theorem poisson_multinomial_independent (b : ℝ≥0) (p : ι → ℝ≥0)
    (hp : ∑ i, p i = 1) :
    iIndepFun (fun i (c : ι → ℕ) => c i)
      (((poissonPMF b).bind (multinomialPMF p hp)).toMeasure) := by
  rw [poisson_multinomial_split b p hp, finitePoissonPMF, Measure.toPMF_toMeasure]
  exact iIndepFun_pi (fun _ => measurable_id.aemeasurable)

/-- Each split coordinate has its required Poisson law. -/
theorem poisson_multinomial_coordinate_law (b : ℝ≥0) (p : ι → ℝ≥0)
    (hp : ∑ i, p i = 1) (i : ι) :
    (((poissonPMF b).bind (multinomialPMF p hp)).toMeasure).map
      (fun c => c i) = poissonMeasure (b * p i) := by
  rw [poisson_multinomial_split b p hp, finitePoissonPMF, Measure.toPMF_toMeasure]
  exact (measurePreserving_eval (fun i => poissonMeasure (b * p i)) i).map_eq

/-- Histogram of an ordered sample of `n` marks. -/
def markHistogram {n : ℕ} (x : Fin n → ι) : ι → ℕ :=
  fun i => ∑ k, if x k = i then 1 else 0

private def countExponent (c : ι → ℕ) : ι →₀ ℕ :=
  ∑ i, Finsupp.single i (c i)

@[simp] private theorem countExponent_apply (c : ι → ℕ) (i : ι) :
    countExponent c i = c i := by
  simp [countExponent, Finsupp.single_apply]

@[simp] private theorem countExponent_inj (c d : ι → ℕ) :
    countExponent c = countExponent d ↔ c = d := by
  constructor
  · intro h
    funext i
    have := congrArg (fun f : ι →₀ ℕ => f i) h
    simpa using this
  · exact congrArg countExponent

omit [Fintype ι] [DecidableEq ι] in
private theorem prod_monomial {κ : Type*} (s : Finset κ)
    (e : κ → ι →₀ ℕ) (a : κ → ℝ≥0∞) :
    (∏ k ∈ s, MvPolynomial.monomial (e k) (a k)) =
      (MvPolynomial.monomial (∑ k ∈ s, e k) (∏ k ∈ s, a k) :
        MvPolynomial ι ℝ≥0∞) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert k s hk ih =>
    simp only [Finset.prod_insert hk, Finset.sum_insert hk, ih,
      MvPolynomial.monomial_mul]

private theorem sample_product_monomial (p : ι → ℝ≥0∞) {n : ℕ} (x : Fin n → ι) :
    (∏ k, MvPolynomial.monomial (Finsupp.single (x k) 1) (p (x k))) =
      (MvPolynomial.monomial (countExponent (markHistogram x)) (∏ k, p (x k)) :
        MvPolynomial ι ℝ≥0∞) := by
  rw [prod_monomial]
  have h : (∑ k, Finsupp.single (x k) 1) = countExponent (markHistogram x) := by
    ext i
    simp [markHistogram, Finsupp.single_apply, eq_comm]
  rw [h]

private theorem count_product_monomial (p : ι → ℝ≥0∞) (c : ι → ℕ) :
    (∏ i, MvPolynomial.monomial (Finsupp.single i 1) (p i) ^ c i) =
      (MvPolynomial.monomial (countExponent c) (∏ i, p i ^ c i) :
        MvPolynomial ι ℝ≥0∞) := by
  simp only [MvPolynomial.monomial_pow]
  rw [prod_monomial]
  have h : (∑ i, c i • Finsupp.single i 1) = countExponent c := by
    ext i
    simp [Finsupp.single_apply]
  rw [h]

/-- The coefficient calculation that identifies the histogram of ordered iid
marks with the multinomial distribution. -/
theorem iid_histogram_mass (p : ι → ℝ≥0∞) (n : ℕ) (c : ι → ℕ) :
    (∑ x : Fin n → ι, if markHistogram x = c then ∏ k, p (x k) else 0) =
      if ∑ i, c i = n then
        (Nat.multinomial Finset.univ c : ℝ≥0∞) * ∏ i, p i ^ c i else 0 := by
  classical
  let z : ι → MvPolynomial ι ℝ≥0∞ :=
    fun i => MvPolynomial.monomial (Finsupp.single i 1) (p i)
  have heq := (Fintype.sum_pow z n).symm.trans
    (Finset.sum_pow_eq_sum_piAntidiag Finset.univ z n)
  have hc := congrArg (MvPolynomial.coeff (countExponent c)) heq
  simp only [z, sample_product_monomial, count_product_monomial,
    MvPolynomial.coeff_sum, MvPolynomial.coeff_monomial,
    countExponent_inj] at hc
  rw [hc]
  simp only [← map_natCast (MvPolynomial.C : ℝ≥0∞ →+* MvPolynomial ι ℝ≥0∞), MvPolynomial.coeff_C_mul,
    MvPolynomial.coeff_monomial, countExponent_inj, mul_ite, mul_zero]
  simp only [Finset.sum_ite_eq', Finset.mem_piAntidiag,
    Finset.mem_univ, implies_true, and_true]

/-- Product law of `n` ordered iid marks with probabilities `p`. -/
def iidMarkPMF (p : ι → ℝ≥0) (hp : ∑ i, p i = 1) (n : ℕ) :
    PMF (Fin n → ι) :=
  PMF.ofFintype (fun x => ∏ k, (p (x k) : ℝ≥0∞)) (by
    have hsum : ∑ i, (p i : ℝ≥0∞) = 1 := by exact_mod_cast hp
    simpa [hsum] using (Fintype.sum_pow (fun i => (p i : ℝ≥0∞)) n).symm)

omit [DecidableEq ι] in
@[simp] theorem iidMarkPMF_apply (p : ι → ℝ≥0) (hp : ∑ i, p i = 1)
    (n : ℕ) (x : Fin n → ι) : iidMarkPMF p hp n x = ∏ k, (p (x k) : ℝ≥0∞) := rfl

/-- The histogram of actual ordered iid marks has the multinomial law. -/
theorem iidMarkPMF_histogram (p : ι → ℝ≥0) (hp : ∑ i, p i = 1) (n : ℕ) :
    (iidMarkPMF p hp n).map markHistogram = multinomialPMF p hp n := by
  classical
  ext c
  rw [PMF.map_apply, tsum_fintype]
  simpa only [iidMarkPMF_apply, multinomialPMF_apply, multinomialMass, eq_comm]
    using iid_histogram_mass (fun i => (p i : ℝ≥0∞)) n c

/-- An outcome consists of a Poisson sample size and an ordered iid sample of that size. -/
abbrev PoissonMarkedSample (ι : Type*) := (n : ℕ) × (Fin n → ι)

instance {κ : Type*} [MeasurableSpace κ] [Countable κ]
    [MeasurableSingletonClass κ] : DiscreteMeasurableSpace (PoissonMarkedSample κ) where
  forall_measurableSet s := by
    change MeasurableSet[⨅ n, (inferInstance : MeasurableSpace (Fin n → κ)).map
      (Sigma.mk n)] s
    rw [MeasurableSpace.measurableSet_iInf]
    intro n
    change MeasurableSet ((Sigma.mk n) ⁻¹' s)
    exact (Set.to_countable _).measurableSet


/-- The original compound-Poisson random-marks experiment, including the order
of the iid marks. -/
def poissonMarkedSamplePMF (b : ℝ≥0) (p : ι → ℝ≥0) (hp : ∑ i, p i = 1) :
    PMF (PoissonMarkedSample ι) :=
  (poissonPMF b).bind (fun n => (iidMarkPMF p hp n).map (fun x => ⟨n, x⟩))

/-- The exact atom-multiplicity representation of the compound-Poisson experiment. -/
theorem poissonMarkedSample_histogram (b : ℝ≥0) (p : ι → ℝ≥0)
    (hp : ∑ i, p i = 1) :
    (poissonMarkedSamplePMF b p hp).map (fun x => markHistogram x.2) =
      finitePoissonPMF (fun i => b * p i) := by
  rw [poissonMarkedSamplePMF, PMF.map_bind]
  simp only [PMF.map_comp, Function.comp_def, iidMarkPMF_histogram]
  exact poisson_multinomial_split b p hp

/-- Histogram aggregation preserves every real-valued sum of marks. -/
theorem sum_histogram (z : ι → ℝ) {n : ℕ} (x : Fin n → ι) :
    (∑ i, z i * (markHistogram x i : ℝ)) = ∑ k, z (x k) := by
  classical
  simp only [markHistogram, Nat.cast_sum, Nat.cast_ite, Nat.cast_one, Nat.cast_zero,
    Finset.mul_sum, mul_ite, mul_one, mul_zero]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro k _
  simp

/-- The empirical sum divided by the Poisson mean, for a random-length ordered sample. -/
def compoundPoissonAverage (b : ℝ≥0) (z : ι → ℝ)
    (x : PoissonMarkedSample ι) : ℝ := (b : ℝ)⁻¹ * ∑ k, z (x.2 k)

/-- The source normalization bound for a Poisson number of ordered iid finite-support
marks. The multiplicity representation, independence, integrability, mean,
variance, and entropy event are all derived rather than assumed. -/
theorem compound_poisson_normalization_entropy_failure {L : ℕ}
    (b : ℝ≥0) (hb : 0 < (b : ℝ)) (p : Fin L → ℝ≥0)
    (hp : ∑ i, p i = 1) (z : Fin L → ℝ) (α A m : ℝ)
    (hα : 1 < α) (hm : 0 < m) (hm1 : m ≤ 1)
    (hmean : ∑ i, (p i : ℝ) * z i = 1)
    (hpower : ∑ i, (p i : ℝ) * z i ^ α = A) (hA : 0 < A) :
    (poissonMarkedSamplePMF b p hp).toMeasure.real
      {x | ¬ normalizationGood α b m A
        (compoundPoissonAverage b z x)
        (compoundPoissonAverage b (fun i => z i ^ α) x)} ≤
      (∑ i, (p i : ℝ) * z i ^ 2) /
        ((b : ℝ) * (min (1 / 4) (m / (16 * (α - 1)))) ^ 2) +
        (∑ i, (p i : ℝ) * (z i ^ α - A * z i) ^ 2) /
          ((b : ℝ) * A ^ 2 * (m / 16) ^ 2) := by
  let π := Measure.pi (fun i => poissonMeasure (b * p i))
  let μ := (poissonMarkedSamplePMF b p hp).toMeasure
  let C : Fin L → (Fin L → ℕ) → ℝ := fun i c => (c i : ℝ)
  have hC (i : Fin L) : IdentDistrib (fun n : ℕ => (n : ℝ)) (C i)
      (poissonMeasure (b * p i)) π := by
    have hid : IdentDistrib id (fun c : Fin L → ℕ => c i)
        (poissonMeasure (b * p i)) π :=
      ⟨measurable_id.aemeasurable, (measurable_pi_apply i).aemeasurable, by
        rw [Measure.map_id]
        exact (measurePreserving_eval (fun i => poissonMeasure (b * p i)) i).map_eq.symm⟩
    exact hid.comp (measurable_of_countable (fun n : ℕ => (n : ℝ)))
  have hi : iIndepFun C π := by
    exact (iIndepFun_pi (fun _ => measurable_id.aemeasurable)).comp
      (fun _ (n : ℕ) => (n : ℝ))
      (fun _ => measurable_of_countable (fun n : ℕ => (n : ℝ)))
  have hpair : Pairwise (fun i j => IndepFun (C i) (C j) π) :=
    fun _ _ hij => hi.indepFun hij
  have hbound := atomic_poisson_normalization_entropy_failure
    (μ := π) b hb p C z α A m hα hm hm1 hC hpair hmean hpower hA
  have hmap : μ.map (fun x : PoissonMarkedSample (Fin L) => markHistogram x.2) = π := by
    change (poissonMarkedSamplePMF b p hp).toMeasure.map _ = π
    rw [PMF.toMeasure_map _ _ (measurable_of_countable _),
      poissonMarkedSample_histogram, finitePoissonPMF, Measure.toPMF_toMeasure]
  let B := {c : Fin L → ℕ | ¬ normalizationGood α b m A
    (poissonAtomAverage b C z c) (poissonAtomAverage b C (fun i => z i ^ α) c)}
  have hevent : π B = μ {x | ¬ normalizationGood α b m A
      (compoundPoissonAverage b z x)
      (compoundPoissonAverage b (fun i => z i ^ α) x)} := by
    rw [← hmap, Measure.map_apply (measurable_of_countable _)
      (Set.to_countable B).measurableSet]
    congr 1
    ext x
    simp only [Set.mem_preimage, Set.mem_setOf_eq, B, C,
      poissonAtomAverage, compoundPoissonAverage, sum_histogram]
  change (μ _).toReal ≤ _
  rw [← hevent]
  exact hbound

omit [DecidableEq ι] in
/-- Taking the first `n` observations of an ordered iid sample preserves its iid law. -/
theorem iidMarkPMF_prefix (p : ι → ℝ≥0) (hp : ∑ i, p i = 1)
    {n m : ℕ} (h : n ≤ m) :
    (iidMarkPMF p hp m).map (fun x i => x (Fin.castLE h i)) = iidMarkPMF p hp n := by
  classical
  letI : MeasurableSpace ι := ⊤
  let q : PMF ι := PMF.ofFintype (fun i => (p i : ℝ≥0∞)) (by
    change (∑ i, (p i : ℝ≥0∞)) = 1
    exact_mod_cast hp)
  have hprod (N : ℕ) : (iidMarkPMF p hp N).toMeasure =
      Measure.pi (fun _ : Fin N => q.toMeasure) := by
    apply Measure.ext_of_singleton
    intro x
    rw [PMF.toMeasure_apply_singleton _ _ (MeasurableSet.singleton _), iidMarkPMF_apply]
    have hset : ({x} : Set (Fin N → ι)) = Set.univ.pi (fun k => {x k}) := by
      ext y
      simp only [Set.mem_singleton_iff, Set.mem_univ_pi, Set.mem_singleton_iff]
      exact funext_iff
    rw [hset, Measure.pi_pi]
    apply Finset.prod_congr rfl
    intro i _
    rw [PMF.toMeasure_apply_singleton _ _ (MeasurableSet.singleton _)]
    rfl
  apply PMF.toMeasure_injective
  rw [← PMF.toMeasure_map _ _ (measurable_of_countable _), hprod m, hprod n]
  have hi : iIndepFun (fun i : Fin n => fun x : Fin m → ι => x (Fin.castLE h i))
      (Measure.pi (fun _ : Fin m => q.toMeasure)) :=
    (iIndepFun_pi (fun _ => measurable_id.aemeasurable)).precomp
      (g := Fin.castLE h) (fun i j hij => Fin.ext (congrArg (fun k : Fin m => k.val) hij))
  have heval (i : Fin n) :
      (Measure.pi (fun _ : Fin m => q.toMeasure)).map
        (fun x => x (Fin.castLE h i)) = q.toMeasure :=
    (measurePreserving_eval (fun _ : Fin m => q.toMeasure) (Fin.castLE h i)).map_eq
  simpa only [heval] using
    (iIndepFun_iff_map_fun_eq_pi_map
      (fun i => (measurable_pi_apply (Fin.castLE h i)).aemeasurable)).mp hi

/-- Each atom count in the original random-length sample has its Poisson law. -/
theorem poissonMarkedSample_histogram_coordinate [MeasurableSpace ι]
    [MeasurableSingletonClass ι] (b : ℝ≥0) (p : ι → ℝ≥0)
    (hp : ∑ i, p i = 1) (i : ι) :
    MeasurePreserving (fun x : PoissonMarkedSample ι => markHistogram x.2 i)
      (poissonMarkedSamplePMF b p hp).toMeasure (poissonMeasure (b * p i)) := by
  refine ⟨measurable_of_countable _, ?_⟩
  have hmap : (poissonMarkedSamplePMF b p hp).toMeasure.map
      (fun x => markHistogram x.2) = Measure.pi (fun i => poissonMeasure (b * p i)) := by
    rw [PMF.toMeasure_map _ _ (measurable_of_countable _),
      poissonMarkedSample_histogram, finitePoissonPMF, Measure.toPMF_toMeasure]
  change (poissonMarkedSamplePMF b p hp).toMeasure.map
    ((fun c => c i) ∘ (fun x => markHistogram x.2)) = _
  rw [← Measure.map_map (measurable_pi_apply i) (measurable_of_countable _), hmap]
  exact (measurePreserving_eval (fun i => poissonMeasure (b * p i)) i).map_eq

/-- Atom multiplicities in the original ordered compound-Poisson sample are
jointly independent. -/
theorem poissonMarkedSample_histogram_independent [MeasurableSpace ι]
    [MeasurableSingletonClass ι] (b : ℝ≥0) (p : ι → ℝ≥0)
    (hp : ∑ i, p i = 1) :
    iIndepFun (fun i (x : PoissonMarkedSample ι) => markHistogram x.2 i)
      (poissonMarkedSamplePMF b p hp).toMeasure := by
  apply (iIndepFun_iff_map_fun_eq_pi_map
    (fun _ => (measurable_of_countable _).aemeasurable)).mpr
  simp_rw [(poissonMarkedSample_histogram_coordinate b p hp _).map_eq]
  rw [PMF.toMeasure_map _ _ (measurable_of_countable _),
    poissonMarkedSample_histogram, finitePoissonPMF, Measure.toPMF_toMeasure]

end Renyi






