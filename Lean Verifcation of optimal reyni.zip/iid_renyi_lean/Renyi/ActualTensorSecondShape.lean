import Renyi.ActiveMomentShape
import Renyi.TensorPriorSecondBounds

/-! Refined second moments attached to the actual calibrated interpolation
factors, with universal identities on the same tensor priors. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 1500000

/-- The complementary principal and all its interpolation nodes are positive. -/
theorem complementary_factor_geometry (n : ℕ) {xi z : ℝ}
    (hxi0 : 0<xi) (hxi1 : xi<1) (hz0 : 0<z) (hz1 : z≤1) :
    let b := xi/((n:ℝ)+1)^2
    let a := Real.exp (-5)*b*z^(1/xi)
    let u := interpolationNodes (chebyshevNode n b) a
    0<a ∧ ∀ i, a≤u i := by
  let b := xi/((n:ℝ)+1)^2
  let a := Real.exp (-5)*b*z^(1/xi)
  have hn0 : (0:ℝ)≤n := Nat.cast_nonneg n
  have hden : (1:ℝ)≤((n:ℝ)+1)^2 := by nlinarith
  have hb0 : 0<b := by dsimp [b]; positivity
  have hb1 : b<1 := by apply (div_lt_one (by positivity)).mpr; linarith
  have hzp : z^(1/xi)≤1 := Real.rpow_le_one hz0.le hz1 (by positivity)
  have he : Real.exp (-5)<1 := Real.exp_lt_one_iff.mpr (by norm_num)
  have hab : a≤b := by
    have hh := mul_le_mul_of_nonneg_left hzp (show 0≤Real.exp (-5)*b by positivity)
    have hh' := mul_le_mul_of_nonneg_right he.le hb0.le
    dsimp [a]
    nlinarith
  refine ⟨by positivity,?_⟩
  intro i
  cases i with
  | none => exact le_rfl
  | some i => exact hab.trans (chebyshevNode_bounds n b hb1.le i).1

/-- Positive-active orientation: the actual low and high interpolation bounds
give the quadratic target-mass cancellation for the same priors appearing
in the count experiment. -/
theorem positive_actual_tensor_second_shape {τ : Type*} [Fintype τ]
    (p₀ p₁ : FiniteAtomicPrior τ) (ns nc : ℕ) (zeta a rho s alpha kappa delta : ℝ)
    (hns : 0<ns) (hz0 : 0<zeta) (hz1 : zeta≤3/5)
    (ha : 0<a) (hrho : 0≤rho) (hrho1 : rho≤1)
    (hs : 0<s) (hs1 : s≤1/2) (hk : 0<kappa) (hk1 : kappa≤1)
    (hd : 0<delta) (hd1 : delta≤4) (halpha : s+2≤alpha)
    (haB : a≤((zeta/8)/((ns:ℝ)+1)^2)/2)
    (hpert : rho*a/((zeta/8)/((ns:ℝ)+1)^2)≤zeta)
    (hprincipal : 1/2≤normalizedInterpolation (chebyshevNode ns ((zeta/8)/((ns:ℝ)+1)^2)) a rho s none)
    (hmass : (∑ i, negativeCoeff (normalizedInterpolation (chebyshevNode ns ((zeta/8)/((ns:ℝ)+1)^2)) a rho s i))≤kappa)
    (hfloor : delta*kappa≤(a/((zeta/8)/((ns:ℝ)+1)^2))^s) :
    let bs := (zeta/8)/((ns:ℝ)+1)^2
    let us := chebyshevNode ns bs
    let bc := (1-s)/((nc:ℝ)+1)^2
    let ac := Real.exp (-5)*bc*(zeta*kappa)^(1/(1-s))
    let uc := chebyshevNode nc bc
    let l := normalizedInterpolation us a rho s
    let t := normalizedInterpolation uc ac 0 (1-s)
    let U := interpolationNodes us a
    let W := interpolationNodes uc ac
    let B := (a*ac)⁻¹
    let Z := tensorNormalizer l t U W a alpha
    (∑ i, l i*U i^(alpha-1)=0) →
    (∀ j:ℝ, 0<j → priorMoment p₀ j=B^(j-1)/Z*(∑ ij, tensorNegative l t ij*tensorAtom U W a ij^(j-alpha))) →
    (∀ j:ℝ, 0<j → priorMoment p₁ j=B^(j-1)/Z*(∑ ij, tensorPositive l t ij*tensorAtom U W a ij^(j-alpha))) →
    priorMoment p₀ (2*alpha)/(priorMoment p₀ alpha)^2≤
      (48*(1+Real.exp 2)/(delta/4)^2)*zeta^2*B^alpha ∧
    priorMoment p₁ (2*alpha)/(priorMoment p₁ alpha)^2≤
      (48*(1+Real.exp 2)/(delta/4)^2)*zeta^2*B^alpha := by
  let bs := (zeta/8)/((ns:ℝ)+1)^2
  let us := chebyshevNode ns bs
  let bc := (1-s)/((nc:ℝ)+1)^2
  let ac := Real.exp (-5)*bc*(zeta*kappa)^(1/(1-s))
  let uc := chebyshevNode nc bc
  let l := normalizedInterpolation us a rho s
  let t := normalizedInterpolation uc ac 0 (1-s)
  let U := interpolationNodes us a
  let W := interpolationNodes uc ac
  dsimp only
  intro hcancel hmom₀ hmom₁
  have halpha1 : 1<alpha := by linarith
  have hxi0 : 1/2≤1-s := by linarith
  have hxi1 : 1-s<1 := by linarith
  have hzK0 : 0<zeta*kappa := mul_pos hz0 hk
  have hzK1 : zeta*kappa≤1 := by nlinarith [mul_le_mul_of_nonneg_left hk1 hz0.le]
  have hgeom := complementary_factor_geometry nc (show 0<1-s by linarith) hxi1 hzK0 hzK1
  change 0<ac ∧ ∀ i, ac≤W i at hgeom
  have hac : 0<ac := hgeom.1
  have hbs0 : 0<bs := by dsimp [bs]; positivity
  have hn0 : (0:ℝ)≤ns := Nat.cast_nonneg ns
  have hden : (1:ℝ)≤((ns:ℝ)+1)^2 := by nlinarith
  have hbs1 : bs<1 := by apply (div_lt_one (by positivity)).mpr; linarith
  have hua (i) : a≤U i := by
    cases i with
    | none => exact le_rfl
    | some i =>
      have hab : a≤bs := by change a≤bs/2 at haB; linarith
      exact hab.trans (chebyshevNode_bounds ns bs hbs1.le i).1
  have hshape := active_factor_moment_shape ns zeta a rho s (alpha-1) kappa delta hns hz0 hz1 ha hrho hrho1 hs.le hk haB hpert (by linarith) hprincipal hmass hfloor
  have hJ := (active_jordan_bounds ns zeta a rho s (alpha-1) hns hz0 hz1 ha hrho hrho1 haB hpert (by linarith) hprincipal hcancel).2
  have hJordan : (∑ i, positiveCoeff (l i)*U i^(alpha-1))≤12*zeta*kappa := by
    have hh := mul_le_mul_of_nonneg_left hshape.2.1 (show 0≤3*zeta by positivity)
    linarith
  have hHigh := complementary_absolute_power_bound nc (1-s) (zeta*kappa) alpha hxi0 hxi1 hzK0 hzK1 (by linarith)
  change (∑ j, |t j| *W j^alpha)≤(1+Real.exp 2)*(zeta*kappa) at hHigh
  have hcomp := (chebyshev_nodes_weighted nc (1-s) (zeta*kappa) hxi0 hxi1 hzK0 hzK1).1
  have hcomp1 : (∑ j, negativeCoeff (t j))≤1 := by
    have he : Real.exp (-(1-s))≤1 := Real.exp_le_one_iff.mpr (by linarith)
    have hh := mul_le_mul_of_nonneg_right he hzK0.le
    linarith
  have hMass : (delta/4)*kappa≤(∑ i, negativeCoeff (l i))+(∑ j, negativeCoeff (t j)) := by
    have ht0 : 0≤∑ j, negativeCoeff (t j) := Finset.sum_nonneg (fun j _ => le_max_right _ _)
    linarith [hshape.1]
  have hh := tensor_priors_refined_second_bound l U t W p₀ p₁ ha hac halpha1 hua hgeom.2
    (normalizedInterpolation_positive_mass us ha hrho)
    (normalizedInterpolation_positive_mass uc hac (by norm_num)) rfl rfl (hmass.trans hk1) hcomp1
    hz0.le hk hk1 (by positivity : 0<delta/4) (by linarith : delta/4≤1)
    (by norm_num : (0:ℝ)≤12) (by positivity : 0≤1+Real.exp 2)
    hcancel hJordan (by nlinarith only [hHigh]) hMass hmom₀ hmom₁
  simpa only [show (4:ℝ)*12=48 by norm_num] using hh

/-- Negative-active orientation, using the same exact prior identities. -/
theorem negative_actual_tensor_second_shape {τ : Type*} [Fintype τ]
    (p₀ p₁ : FiniteAtomicPrior τ) (ns nc : ℕ) (zeta a rho s alpha kappa delta : ℝ)
    (hns : 0<ns) (hz0 : 0<zeta) (hz1 : zeta≤3/5)
    (ha : 0<a) (hrho : 0≤rho) (hrho1 : rho≤1)
    (hs : 0<s) (hs1 : s≤1/2) (hk : 0<kappa) (hk1 : kappa≤1)
    (hd : 0<delta) (hd1 : delta≤4) (halpha : 2-s≤alpha)
    (haB : a≤((zeta/8)/((ns:ℝ)+1)^2)/2)
    (hpert : rho*a/((zeta/8)/((ns:ℝ)+1)^2)≤zeta)
    (hprincipal : 1/2≤normalizedInterpolation (chebyshevNode ns ((zeta/8)/((ns:ℝ)+1)^2)) a rho s none)
    (hmass : (∑ i, negativeCoeff (normalizedInterpolation (chebyshevNode ns ((zeta/8)/((ns:ℝ)+1)^2)) a rho s i))≤kappa)
    (hfloor : delta*kappa≤(a/((zeta/8)/((ns:ℝ)+1)^2))^s) :
    let bs := (zeta/8)/((ns:ℝ)+1)^2
    let us := chebyshevNode ns bs
    let bc := (1-s)/((nc:ℝ)+1)^2
    let ac := Real.exp (-5)*bc*(zeta*kappa)^(1/(1-s))
    let uc := chebyshevNode nc bc
    let l := normalizedInterpolation us a rho s
    let t := normalizedInterpolation uc ac 0 (1-s)
    let U := interpolationNodes us a
    let W := interpolationNodes uc ac
    let B := (ac*a)⁻¹
    let Z := tensorNormalizer t l W U ac alpha
    (∑ i, t i*W i^(alpha-1)=0) →
    (∀ j:ℝ, 0<j → priorMoment p₀ j=B^(j-1)/Z*(∑ ij, tensorNegative t l ij*tensorAtom W U ac ij^(j-alpha))) →
    (∀ j:ℝ, 0<j → priorMoment p₁ j=B^(j-1)/Z*(∑ ij, tensorPositive t l ij*tensorAtom W U ac ij^(j-alpha))) →
    priorMoment p₀ (2*alpha)/(priorMoment p₀ alpha)^2≤
      (48*(1+Real.exp 2)/(delta/4)^2)*zeta^2*B^alpha ∧
    priorMoment p₁ (2*alpha)/(priorMoment p₁ alpha)^2≤
      (48*(1+Real.exp 2)/(delta/4)^2)*zeta^2*B^alpha := by
  let bs := (zeta/8)/((ns:ℝ)+1)^2
  let us := chebyshevNode ns bs
  let bc := (1-s)/((nc:ℝ)+1)^2
  let ac := Real.exp (-5)*bc*(zeta*kappa)^(1/(1-s))
  let uc := chebyshevNode nc bc
  let l := normalizedInterpolation us a rho s
  let t := normalizedInterpolation uc ac 0 (1-s)
  let U := interpolationNodes us a
  let W := interpolationNodes uc ac
  dsimp only
  intro hcancel hmom₀ hmom₁
  have halpha1 : 1<alpha := by linarith
  have hxi0 : 1/2≤1-s := by linarith
  have hxi1 : 1-s<1 := by linarith
  have hzK0 : 0<zeta*kappa := mul_pos hz0 hk
  have hzK1 : zeta*kappa≤1 := by nlinarith [mul_le_mul_of_nonneg_left hk1 hz0.le]
  have hgeom := complementary_factor_geometry nc (show 0<1-s by linarith) hxi1 hzK0 hzK1
  change 0<ac ∧ ∀ i, ac≤W i at hgeom
  have hac : 0<ac := hgeom.1
  have hbs0 : 0<bs := by dsimp [bs]; positivity
  have hn0 : (0:ℝ)≤ns := Nat.cast_nonneg ns
  have hden : (1:ℝ)≤((ns:ℝ)+1)^2 := by nlinarith
  have hbs1 : bs<1 := by apply (div_lt_one (by positivity)).mpr; linarith
  have hua (i) : a≤U i := by
    cases i with
    | none => exact le_rfl
    | some i =>
      have hab : a≤bs := by change a≤bs/2 at haB; linarith
      exact hab.trans (chebyshevNode_bounds ns bs hbs1.le i).1
  have hshape := active_factor_moment_shape ns zeta a rho s alpha kappa delta hns hz0 hz1 ha hrho hrho1 hs.le hk haB hpert (by linarith) hprincipal hmass hfloor
  have hJabs := complementary_absolute_power_bound nc (1-s) (zeta*kappa) (alpha-1) hxi0 hxi1 hzK0 hzK1 (by linarith)
  have htwo := absolute_power_moment_eq_twice t W (alpha-1) hcancel
  change (∑ i, |t i| *W i^(alpha-1))≤(1+Real.exp 2)*(zeta*kappa) at hJabs
  rw [htwo] at hJabs
  have hJ0 : 0≤∑ i, positiveCoeff (t i)*W i^(alpha-1) :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (le_max_right _ _) (Real.rpow_nonneg (hac.trans_le (hgeom.2 i)).le _))
  have hJordan : (∑ i, positiveCoeff (t i)*W i^(alpha-1))≤(1+Real.exp 2)*zeta*kappa := by
    nlinarith only [hJabs,hJ0]
  have hcomp := (chebyshev_nodes_weighted nc (1-s) (zeta*kappa) hxi0 hxi1 hzK0 hzK1).1
  have hcomp1 : (∑ j, negativeCoeff (t j))≤1 := by
    have he : Real.exp (-(1-s))≤1 := Real.exp_le_one_iff.mpr (by linarith)
    have hh := mul_le_mul_of_nonneg_right he hzK0.le
    linarith
  have hMass : (delta/4)*kappa≤(∑ j, negativeCoeff (t j))+(∑ i, negativeCoeff (l i)) := by
    have ht0 : 0≤∑ j, negativeCoeff (t j) := Finset.sum_nonneg (fun j _ => le_max_right _ _)
    linarith [hshape.1]
  have hh := tensor_priors_refined_second_bound t W l U p₀ p₁ hac ha halpha1 hgeom.2 hua
    (normalizedInterpolation_positive_mass uc hac (by norm_num))
    (normalizedInterpolation_positive_mass us ha hrho) rfl rfl hcomp1 (hmass.trans hk1)
    hz0.le hk hk1 (by positivity : 0<delta/4) (by linarith : delta/4≤1)
    (by positivity : 0≤1+Real.exp 2) (by norm_num : (0:ℝ)≤12)
    hcancel hJordan hshape.2.2 hMass hmom₀ hmom₁
  have hconst : 4*(1+Real.exp 2)*12=48*(1+Real.exp 2) := by ring
  simpa only [hconst] using hh

end Renyi
