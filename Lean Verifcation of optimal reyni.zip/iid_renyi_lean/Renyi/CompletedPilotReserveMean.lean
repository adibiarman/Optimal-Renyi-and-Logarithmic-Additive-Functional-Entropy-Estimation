import Renyi.CompletedPilotReserve

/-! Actual total boundary expectation at the complete reserved margin. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Polynomial
namespace Renyi
set_option maxHeartbeats 800000
variable {ι Ω : Type*} [Fintype ι] [MeasurableSpace Ω] {μ : Measure Ω}

theorem completed_polynomial_pilot_reserve_mean {ell N m : ℕ}
    (hell : 0<ell) (hN : 0<N) (hm : 1≤m) (hdegree : 4*(ell-1)≤m)
    {gamma a b fL f A B omega sigma n L cp Bpilot cb cstar eps C0 d D R eta u : ℝ}
    (hg : 0<gamma) (hg1 : gamma<1) (ha : 0<a) (hab : a≤b)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hA : 0≤A) (hA1 : A≤1) (hB : 0≤B) (hB1 : B≤1)
    (hw : 0≤omega) (hw1 : omega<1) (hs : 0≤sigma) (hs1 : sigma≤1)
    (hn : 0<n) (halpha : 3/2≤(m:ℝ)+gamma) (hL : 1≤L)
    (hellL : (ell:ℝ)≤L) (hNL : (N:ℝ)≤L) (hmL : (m:ℝ)+gamma≤L)
    (hcp0 : 1≤cp) (hBp : 16≤Bpilot) (hcs : 0≤cstar)
    (hnb : n*b=cb*L) (hcut : 2*Bpilot*((m:ℝ)+gamma)≤n*b) (hLn : 1≤L*(n*b))
    (hcp : 8*(coupledCoefficientExponentialConstant+20+cstar)≤cp*cb)
    (hcpGamma : 2*Bpilot+cstar+11≤cp)
    (p : ι→ℝ) (hp : ∀i,0≤p i) (Y Counts : ι→Ω→ℕ)
    (hCounts : ∀i,MeasurePreserving (Counts i) μ (poissonMeasure ⟨n*p i,mul_nonneg hn.le (hp i)⟩))
    (hind : ∀i,IndepFun (Y i) (Counts i) μ)
    (hY : ∀i,MeasurePreserving (Y i) μ
      (poissonMeasure ⟨cp*n*p i,mul_nonneg (mul_nonneg (by linarith only [hcp0]) hn.le) (hp i)⟩))
    (he : 0≤eps) (hC0 : 100≤C0) (hd : 0<d) (hD : 0<D) (hR : 0≤R)
    (heta : 0<eta) (heta1 : eta≤1) (hu : 0≤u)
    (hka : (Fintype.card ι:ℝ)*a≤R/D) (hDbudget : 400*R/(d*eta)≤D)
    (hExponent : 2*eps+Real.log (12/eta)≤cstar) :
    let alpha := (m:ℝ)+gamma
    let Q0 := completedCoupledPolynomial ell N m gamma a b
      (DegreeOneCompletion.coefficient gamma fL) fL f A B omega
    let Q : ι→ℝ := fun i => sigma*Q0.eval (p i)
    let chi := min (alpha-1) 1
    let kappa := Real.exp (-2*eps*(alpha-1))
    let M := chi*d*C0^m*a^(alpha-1)+kappa*u*(∑i,p i^alpha)+
      chi*kappa*conditionalCountBonus p alpha n L
    Integrable (pilotTotalBoundary p Q Y Counts n b alpha cp Bpilot (sigma*omega)) μ ∧
      (∫w,pilotTotalBoundary p Q Y Counts n b alpha cp Bpilot (sigma*omega) w ∂μ)≤eta*M := by
  let alpha := (m:ℝ)+gamma
  let Q0 := completedCoupledPolynomial ell N m gamma a b
    (DegreeOneCompletion.coefficient gamma fL) fL f A B omega
  let Q : ι→ℝ := fun i => sigma*Q0.eval (p i)
  let chi := min (alpha-1) 1
  let kappa := Real.exp (-2*eps*(alpha-1))
  let base := chi*d*C0^m*a^(alpha-1)
  let Bonus := conditionalCountBonus p alpha n L
  let P := ∑i,p i^alpha
  let M := base+kappa*u*P+chi*kappa*Bonus
  have hnoise := completed_polynomial_pilot_noise hell hN hm hdegree hg hg1 ha hab hfL hfL1 hf hf1
    hA hA1 hB hB1 hw hw1 hs hs1 hn halpha hL hellL hNL hmL hcp0 hBp hcs hnb hcut hLn hcp hcpGamma
    p hp Y Counts hCounts hind hY
  have hNoiseBound : (∫w,pilotTotalBoundary p Q Y Counts n b alpha cp Bpilot (sigma*omega) w ∂μ)≤
      (Fintype.card ι:ℝ)*((100:ℝ)^(m+1)*a^alpha)+
      (2*Real.exp (-cstar*L)+3*Real.exp (-cp*alpha)+Real.exp (-cstar*alpha))*Bonus := hnoise.2
  have hchi : (1/2:ℝ)≤chi := le_min (by dsimp [alpha];linarith only [halpha]) (by norm_num)
  have hchi0 : 0<chi := (by norm_num : (0:ℝ)<1/2).trans_le hchi
  have hCpos : 0<C0 := by linarith only [hC0]
  have hbase0 : 0<base := by dsimp [base];positivity
  have hBonus : 0≤Bonus := conditionalCountBonus_nonneg p hp hn.le (by linarith only [hL])
  have hP : 0≤P := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (hp i) _)
  have hkap : 0<kappa := Real.exp_pos _
  have hbelow := pilot_below_cutoff_baseline (K:=(Fintype.card ι:ℝ)) (C:=100) (C0:=C0)
    (alpha:=alpha) (m:=m) (chi:=chi) (Nat.cast_nonneg _) (by norm_num) hC0 ha hchi hd hD hR hka
  have hpref : 2*(100:ℝ)*R/(d*D)≤eta/2 := by
    apply (div_le_iff₀ (mul_pos hd hD)).mpr
    have hh := (div_le_iff₀ (mul_pos hd heta)).mp hDbudget
    nlinarith only [hh]
  have hbaseBound : (Fintype.card ι:ℝ)*((100:ℝ)^(m+1)*a^alpha)≤(eta/2)*base :=
    hbelow.trans (mul_le_mul_of_nonneg_right hpref hbase0.le)
  have hExp : 2*Real.exp (-cstar*L)+3*Real.exp (-cp*alpha)+Real.exp (-cstar*alpha)≤(eta/2)*kappa := by
    apply pilot_exponential_margin_budget he (by positivity) (by linarith only [heta1])
      (by linarith only [halpha]) hmL ?_ (by linarith only [hcpGamma,hBp])
    convert hExponent using 1
    congr 2
    field_simp
    norm_num
  have hExpBound := mul_le_mul_of_nonneg_right hExp hBonus
  have hchiBonus := mul_le_mul_of_nonneg_right hchi (mul_nonneg (mul_nonneg heta.le hkap.le) hBonus)
  have huP : 0≤kappa*u*P := by positivity
  have hbaseHalf : (eta/2)*base≤eta*base := mul_le_mul_of_nonneg_right (by linarith only [heta]) hbase0.le
  have hmean : (∫w,pilotTotalBoundary p Q Y Counts n b alpha cp Bpilot (sigma*omega) w ∂μ)≤eta*M := by
    dsimp [M]
    nlinarith only [hNoiseBound,hbaseBound,hExpBound,hchiBonus,hbaseHalf,mul_nonneg heta.le huP]
  exact ⟨hnoise.1,hmean⟩

end Renyi
