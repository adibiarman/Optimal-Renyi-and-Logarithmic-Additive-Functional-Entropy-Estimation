import Renyi.CountEndpointBonusBridge
import Renyi.ActualBiasModel
import Renyi.ActualAffineAnchor
import Renyi.PoissonPilotModel
import Renyi.HighOrderNorm

/-! One source count-noise budget and the actual rescaled estimator polynomial. -/
set_option maxHeartbeats 1000000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Polynomial
namespace Renyi

def actualCountBudget {k : ℕ} (p : Simplex k)
    (alpha eps Ch D cb lambda CL cL C0 db u0 : ℝ) : ℝ :=
  actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 db+
    upperKappa alpha eps*upperU k alpha eps u0*powerSum p alpha+
    min (alpha-1) 1*upperKappa alpha eps*conditionalCountBonus p.mass alpha (upperSample k alpha eps D)
      (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)

def actualSourcePolynomial (k : ℕ) (alpha eps Ch D cb lambda CL cL fL f M cu u0 : ℝ) : ℝ[X] :=
  C (upperRescaling k alpha eps cu u0)*actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M

/-- Both actual margins are positive, and the count bonus costs only max(1,cb)
relative to the endpoint bonus used by the deterministic mean bounds. -/
theorem actual_noise_budgets {k : ℕ} (p : Simplex k)
    {alpha eps Ch D cb lambda CL cL C0 db u0 : ℝ}
    (hk : 0<k) (ha : 3/2≤alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (heps : 0<eps) (hCh : 0≤Ch) (hD : 0<D) (hcb : 0<cb) (hlambda : 0<lambda) (hlambda4 : lambda≤4)
    (hCL : 1≤CL) (hcL : 0<cL) (hcbCL : 1≤cb*CL) (hC0 : 0≤C0) (hdb : 0≤db) (hu0 : 0<u0) :
    0<actualCountBudget p alpha eps Ch D cb lambda CL cL C0 db u0 ∧
    0<actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 db u0 ∧
    actualCountBudget p alpha eps Ch D cb lambda CL cL C0 db u0≤
      max 1 cb*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 db u0 := by
  have ha1 : 1<alpha := by linarith only [ha]
  have hk0 : (0:ℝ)<k := by exact_mod_cast hk
  have hn := upperSample_pos (ε:=eps) hk ha1 hg hg1 hD
  have hgeom := upper_actual_count_geometry hk ha hg hg1 heps hCh hD hcb hlambda hlambda4 hCL hcL hcbCL
  have haCut := hgeom.1
  have hb := hgeom.2.2.1
  have hnb := hgeom.2.2.2.2.2.2.2.2.2.1
  have hL : 0≤(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) := Nat.cast_nonneg _
  have hbase : 0≤actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 db := mul_nonneg
    (upperActualBaseline_nonneg ha1.le hC0 hdb haCut.le) (Real.rpow_nonneg hk0.le _)
  have hcore : 0<upperKappa alpha eps*upperU k alpha eps u0*powerSum p alpha :=
    mul_pos (mul_pos (Real.exp_pos _) (upperU_pos ha1 hg hg1 hu0)) (simplex_powerSum_pos p alpha)
  have hchi : 0≤min (alpha-1) 1 := le_min (by linarith only [ha]) (by norm_num)
  have hck : 0≤min (alpha-1) 1*upperKappa alpha eps := mul_nonneg hchi (Real.exp_pos _).le
  have hcbBonus := conditionalCountBonus_nonneg p.mass p.nonneg hn.le hL (alpha:=alpha)
  have hforward : 0≤actualForwardBonus p alpha eps D cb CL cL := Finset.sum_nonneg (fun i _ =>
    mul_nonneg (Real.rpow_nonneg (p.nonneg i) _) (le_min (mul_nonneg (sq_nonneg _) (div_nonneg (p.nonneg i) hb.le)) (by norm_num)))
  have hbonus := conditionalCountBonus_le_endpoint_bonus p.mass p.nonneg hb hnb (alpha:=alpha)
  change conditionalCountBonus p.mass alpha (upperSample k alpha eps D) (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤
    max 1 cb*actualForwardBonus p alpha eps D cb CL cL at hbonus
  have hbonus' := mul_le_mul_of_nonneg_left hbonus hck
  have hbaseCore : 0≤actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 db+
      upperKappa alpha eps*upperU k alpha eps u0*powerSum p alpha := by linarith only [hbase,hcore]
  have hscaled := mul_le_mul_of_nonneg_right (le_max_left (1:ℝ) cb) hbaseCore
  refine ⟨?_,?_,?_⟩
  · dsimp [actualCountBudget]
    linarith only [hbase,hcore,mul_nonneg hck hcbBonus]
  · dsimp [actualBiasBudget]
    linarith only [hbase,hcore,mul_nonneg hck hforward]
  · dsimp [actualCountBudget,actualBiasBudget]
    nlinarith only [hbonus',hscaled]

theorem actualCountBudget_le_actualBiasBudget_cb_one {k : ℕ} (p : Simplex k)
    {alpha eps Ch D lambda CL cL C0 db u0 : ℝ}
    (hk : 0<k) (ha : 3/2≤alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (heps : 0<eps) (hCh : 0≤Ch) (hD : 0<D) (hlambda : 0<lambda) (hlambda4 : lambda≤4)
    (hCL : 1≤CL) (hcL : 0<cL) (hC0 : 0≤C0) (hdb : 0≤db) (hu0 : 0<u0) :
    actualCountBudget p alpha eps Ch D 1 lambda CL cL C0 db u0≤
      actualBiasBudget p alpha eps Ch D 1 lambda CL cL C0 db u0 := by
  have hh := (actual_noise_budgets p hk ha hg hg1 heps hCh hD (by norm_num : (0:ℝ)<1)
    hlambda hlambda4 hCL hcL (by simpa only [one_mul] using hCL) hC0 hdb hu0).2.2
  simpa only [max_self,one_mul] using hh

@[simp] theorem actualSourcePolynomial_coeff (k j : ℕ)
    (alpha eps Ch D cb lambda CL cL fL f M cu u0 : ℝ) :
    (actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu u0).coeff j=
      upperRescaling k alpha eps cu u0*(actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).coeff j := by
  simp only [actualSourcePolynomial,coeff_C_mul]

@[simp] theorem actualSourcePolynomial_eval (k : ℕ)
    (alpha eps Ch D cb lambda CL cL fL f M cu u0 x : ℝ) :
    (actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu u0).eval x=
      upperRescaling k alpha eps cu u0*(actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).eval x := by
  simp only [actualSourcePolynomial,eval_mul,eval_C]

theorem actualSourcePolynomial_natDegree {k : ℕ}
    {alpha eps Ch D cb lambda CL cL fL f M cu u0 : ℝ} (ha : 1<alpha) :
    (actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu u0).natDegree≤
      upperCountDegree k alpha eps CL cL := by
  unfold actualSourcePolynomial
  apply natDegree_mul_le.trans
  simpa only [natDegree_C,zero_add] using (actualCoupledPolynomial_natDegree ha)

theorem actualSourcePolynomial_affine_coeff (k : ℕ)
    (alpha eps Ch D cb lambda CL cL fL f M cu u0 : ℝ) :
    (actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu u0).coeff 1=
      upperRescaling k alpha eps cu u0*
        (actualUpperPolynomial k alpha eps Ch D cb lambda CL cL fL f M (1/8)).coeff 1 := by
  rw [actualSourcePolynomial_coeff,actualUpperPolynomial_eq_actualCoupledPolynomial]

variable {iota Omega Xi : Type*} [Fintype iota] [MeasurableSpace Omega] [MeasurableSpace Xi]

theorem actualSourcePolynomial_count_variance_scaled {k : ℕ}
    (Counts : iota→Omega→ℕ) (Pilot : iota→Xi→ℕ) (T : ℝ) (d : ℕ)
    (alpha eps Ch D cb lambda CL cL fL f M cu u0 : ℝ) (mu : Measure Omega) (nu : Measure Xi) :
    pilotAveragedCountVariance Counts Pilot T d
      (actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu u0).coeff
      (upperSample k alpha eps D) mu nu=
      (upperRescaling k alpha eps cu u0)^2*pilotAveragedCountVariance Counts Pilot T d
        (actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).coeff
        (upperSample k alpha eps D) mu nu := by
  have hcoeff : (actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu u0).coeff=
      fun j => upperRescaling k alpha eps cu u0*(actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).coeff j := by
    funext j
    exact actualSourcePolynomial_coeff k j alpha eps Ch D cb lambda CL cL fL f M cu u0
  rw [hcoeff]
  exact pilotAveragedCountVariance_scaled Counts Pilot T d _ _ _ mu nu

theorem actualSourcePolynomial_count_variance_le {k : ℕ}
    (Counts : iota→Omega→ℕ) (Pilot : iota→Xi→ℕ) (T : ℝ) (d : ℕ)
    {alpha eps Ch D cb lambda CL cL fL f M cu u0 : ℝ}
    (ha : 1<alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1) (hcu : 0≤cu) (hu0 : 0<u0)
    (mu : Measure Omega) (nu : Measure Xi) :
    pilotAveragedCountVariance Counts Pilot T d
      (actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu u0).coeff
      (upperSample k alpha eps D) mu nu≤
      pilotAveragedCountVariance Counts Pilot T d
        (actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).coeff
        (upperSample k alpha eps D) mu nu := by
  have hs := upperRescaling_range (k:=k) (eps:=eps) ha hg hg1 hcu hu0
  have habs : |upperRescaling k alpha eps cu u0|≤1 := by rw [abs_of_nonneg hs.1.le]; exact hs.2
  have hcoeff : (actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu u0).coeff=
      fun j => upperRescaling k alpha eps cu u0*(actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).coeff j := by
    funext j
    exact actualSourcePolynomial_coeff k j alpha eps Ch D cb lambda CL cL fL f M cu u0
  rw [hcoeff]
  exact pilotAveragedCountVariance_scaled_le Counts Pilot T d _ habs _ mu nu

/-- The count certificate is unchanged after the actual common scalar rescaling. -/
theorem actual_source_conditional_count_variance_uniform_experiments
    {eps Ch cb lambda CL cp Bpilot M fL f cu u0 eta cLbound : ℝ}
    (heps : 0<eps) (hCh : 0≤Ch) (hcb : 0<cb) (hlambda : 0<lambda) (hlambda4 : lambda≤4)
    (hCL : 1≤CL) (hcbCL : 1≤cb*CL) (hcp : 0<cp) (hcpDegree : 80/cb≤cp) (hBpilot : 0<Bpilot)
    (hM : 0≤M) (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hcu : 0≤cu) (hu0 : 0<u0) (heta : 0<eta) (hcLbound : 0<cLbound) :
    ∃ cL C0 : ℝ, 0<cL ∧ cL≤cLbound ∧ 1≤C0 ∧ coupledLowCoefficientConstant≤C0 ∧
      ∀ db : ℝ, 0<db → db≤1 → ∃ D0 : ℝ, 1≤D0 ∧ ∀ (k : ℕ) (alpha D : ℝ),
      0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → D0≤D →
      ∀ {Omega Xi : Type*} [MeasurableSpace Omega] [MeasurableSpace Xi] (mu : Measure Omega) (nu : Measure Xi),
      ∀ (p : Simplex k) (Counts : Fin k→Omega→ℕ) (Pilot : Fin k→Xi→ℕ) (lam : Fin k→ℝ≥0),
      (∀i,MeasurePreserving (Counts i) mu (poissonMeasure (lam i))) →
      Pairwise (fun i j => IndepFun (Counts i) (Counts j) mu) →
      (∀i,MeasurePreserving (Pilot i) nu (poissonMeasure ⟨cp*lam i,mul_nonneg hcp.le (lam i).coe_nonneg⟩)) →
      (∀i,(lam i:ℝ)=upperSample k alpha eps D*p.mass i) →
      pilotAveragedCountVariance Counts Pilot (cp*Bpilot*alpha) (upperCountDegree k alpha eps CL cL)
        (actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu u0).coeff
        (upperSample k alpha eps D) mu nu≤
        eta*(actualCountBudget p alpha eps Ch D cb lambda CL cL C0 db u0)^2 := by
  obtain ⟨cL,C0,hcL,hcLmax,hC0,hC0low,hbound⟩ :=
    actual_coupled_conditional_count_variance_uniform_experiments heps hCh hcb hlambda hlambda4 hCL hcbCL
      hcp hcpDegree hBpilot hM hfL hfL1 hf hf1 hu0 heta hcLbound
  refine ⟨cL,C0,hcL,hcLmax,hC0,hC0low,?_⟩
  intro db hdb hdb1
  obtain ⟨D0,hD0,hDall⟩ := hbound db hdb hdb1
  refine ⟨D0,hD0,?_⟩
  intro k alpha D hk ha hg hg1 hD Omega Xi instOmega instXi mu nu p Counts Pilot lam hCounts hpair hPilot hlam
  have hcount := hDall k alpha D hk ha hg hg1 hD mu nu p Counts Pilot lam hCounts hpair hPilot hlam
  have hscaled := actualSourcePolynomial_count_variance_le (k:=k) (eps:=eps) Counts Pilot (cp*Bpilot*alpha)
    (upperCountDegree k alpha eps CL cL) (by linarith only [ha] : 1<alpha) hg hg1 hcu hu0 mu nu
    (Ch:=Ch) (D:=D) (cb:=cb) (lambda:=lambda) (CL:=CL) (cL:=cL) (fL:=fL) (f:=f) (M:=M)
  exact hscaled.trans (by simpa only [actualCountBudget,actualCutoffBudget] using hcount)

/-- The final affine-noise estimate is numerical: no variance conversion or
probability-space assumptions are needed when applying the stochastic band. -/
theorem actual_source_affine_noise_uniform
    {eps Ch cb lambda CL cL fL f M cu u0 C0 db eta : ℝ}
    (heps : 0<eps) (hCh : 0≤Ch) (hcb : 0<cb) (hlambda : 0<lambda) (hlambda4 : lambda≤4)
    (hCL : 1≤CL) (hcL : 0<cL) (hcbCL : 1≤cb*CL) (hfL : 0≤fL) (hfL1 : fL<1)
    (hM : 0≤M) (hcu : 0≤cu) (hu0 : 0<u0) (hC0 : coupledLowCoefficientConstant≤C0)
    (hdb : 0<db) (heta : 0<eta) :
    ∃ k0 : ℕ, ∀ k : ℕ, k0≤k → ∀ alpha D : ℝ,
      3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → 1≤D → ∀ p : Simplex k,
      (actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu u0).coeff 1^2/
        upperSample k alpha eps D≤eta*(actualCountBudget p alpha eps Ch D cb lambda CL cL C0 db u0)^2 := by
  obtain ⟨K,hK⟩ := actual_upper_affine_anchor_variance_uniform.{0} (f:=f)
    heps hCh hcb hlambda hlambda4 hCL hcL hcbCL hfL hfL1 hM (by norm_num : (0:ℝ)<1/8)
      hcu hu0 hC0 hdb heta
  refine ⟨max 1 K,?_⟩
  intro k hk alpha D ha hg hg1 hD p
  have hkpos : 0<k := (by norm_num : 0<1).trans_le ((le_max_left _ _).trans hk)
  have ha1 : 1<alpha := by linarith only [ha]
  have hn : 0<upperSample k alpha eps D := upperSample_pos hkpos ha1 hg hg1 (zero_lt_one.trans_le hD)
  let n := upperSample k alpha eps D
  let nNN : ℝ≥0 := ⟨n,hn.le⟩
  let mu := (pilotHistogramPMF nNN 1 p).toMeasure
  let lam : Fin k→ℝ≥0 := fun i => nNN*simplexNN p i
  let Counts : Fin k→PilotHistogram k→ℕ := fun i => pilotMainCount i
  let q := upperRescaling k alpha eps cu u0*
    (actualUpperPolynomial k alpha eps Ch D cb lambda CL cL fL f M (1/8)).coeff 1
  have hLaw (i : Fin k) : MeasurePreserving (Counts i) mu (poissonMeasure (lam i)) :=
    pilotMainCount_law nNN 1 p i
  have hpair : Pairwise (fun i j => IndepFun (Counts i) (Counts j) mu) := by
    intro i j hij
    exact (pilotHistogram_independent nNN 1 p).indepFun (by
      intro heq
      exact hij (congrArg Prod.fst heq))
  have hlam (i : Fin k) : (lam i:ℝ)=upperSample k alpha eps D*p.mass i := by
    simp only [lam,NNReal.coe_mul,simplexNN_coe,nNN,n]
    rfl
  have hsum : ∑i,(lam i:ℝ)=n := by
    dsimp [n]
    simp only [hlam,←Finset.mul_sum,p.normalized,mul_one]
  have hanchor := (hK k ((le_max_right _ _).trans hk) alpha D ha hg hg1 hD p mu Counts lam hLaw hpair hlam).2.2
  change variance (poissonAffineAnchor Counts n q) mu≤eta*(actualCountBudget p alpha eps Ch D cb lambda CL cL C0 db u0)^2 at hanchor
  have hmoment := common_affine_anchor_moments Counts lam hLaw hpair hn hsum q
  rw [hmoment.2.2] at hanchor
  have hcoeff : (actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu u0).coeff 1=q := by
    rw [actualSourcePolynomial_affine_coeff]
  rw [←hcoeff] at hanchor
  exact hanchor

end Renyi
