import Renyi.PoissonOverlap

/-! The exact rectangular summation kernel behind the Poisson Poincare inequality. -/
noncomputable section
open scoped BigOperators NNReal
open ProbabilityTheory
namespace Renyi

theorem poisson_first_moment_prefix (lam : ℝ≥0) (k : ℕ) :
    (∑ n ∈ Finset.range (k + 1), (n : ℝ) * poissonPMFReal lam n) =
      (lam : ℝ) * ∑ n ∈ Finset.range k, poissonPMFReal lam n := by
  rw [Finset.sum_range_succ']
  simp only [Nat.cast_zero, zero_mul, add_zero]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro n _
  simpa using poisson_factorial_shift lam n 1

theorem finite_prefix_hasSum (f : ℕ → ℝ) (k : ℕ) :
    HasSum (fun n => if n ≤ k then f n else 0) (∑ n ∈ Finset.range (k + 1), f n) := by
  have h := hasSum_sum_of_ne_finset_zero (s := Finset.range (k + 1)) (L := .unconditional ℕ)
    (f := fun n => if n ≤ k then f n else 0) (fun n hn => by
      have hnk : ¬ n ≤ k := by simpa only [Finset.mem_range, Nat.lt_succ_iff] using hn
      exact if_neg hnk)
  convert h using 1
  apply Finset.sum_congr rfl
  intro n hn
  simp only [if_pos (Nat.le_of_lt_succ (Finset.mem_range.mp hn))]

/-- Includes intensity zero and proves convergence, not just a formal series identity. -/
theorem poisson_poincare_kernel_hasSum (lam : ℝ≥0) (k : ℕ) :
    HasSum (fun mn : ℕ × ℕ => if mn.1 ≤ k ∧ k < mn.2 then
      poissonPMFReal lam mn.1 * poissonPMFReal lam mn.2 * ((mn.2 : ℝ) - mn.1) else 0)
      ((lam : ℝ) * poissonPMFReal lam k) := by
  let A := ∑ n ∈ Finset.range (k + 1), poissonPMFReal lam n
  let C := ∑ n ∈ Finset.range k, poissonPMFReal lam n
  have hleft : HasSum (fun n => if n ≤ k then poissonPMFReal lam n else 0) A :=
    finite_prefix_hasSum _ k
  have hleftN : HasSum (fun n => if n ≤ k then (n : ℝ) * poissonPMFReal lam n else 0)
      ((lam : ℝ) * C) := by
    simpa only [poisson_first_moment_prefix, C] using
      finite_prefix_hasSum (fun n => (n : ℝ) * poissonPMFReal lam n) k
  have hright : HasSum (fun n => if k < n then poissonPMFReal lam n else 0) (1 - A) := by
    convert (poissonPMFRealSum lam).sub hleft using 1
    funext n
    by_cases h : n ≤ k <;> simp [h, not_lt_of_ge, lt_of_not_ge]
  have hmean : HasSum (fun n : ℕ => (n : ℝ) * poissonPMFReal lam n) (lam : ℝ) := by
    simpa using poisson_factorial_hasSum lam 1
  have hrightN : HasSum (fun n => if k < n then (n : ℝ) * poissonPMFReal lam n else 0)
      ((lam : ℝ) - (lam : ℝ) * C) := by
    convert hmean.sub hleftN using 1
    funext n
    by_cases h : n ≤ k <;> simp [h, not_lt_of_ge, lt_of_not_ge]
  have h1 := hasSum_mul_nonneg_real hleft hrightN
    (fun _ => by split_ifs; exact poissonPMFReal_nonneg; exact le_rfl)
    (fun n => by split_ifs; exact mul_nonneg (Nat.cast_nonneg n) poissonPMFReal_nonneg; exact le_rfl)
  have h2 := hasSum_mul_nonneg_real hleftN hright
    (fun n => by split_ifs; exact mul_nonneg (Nat.cast_nonneg n) poissonPMFReal_nonneg; exact le_rfl)
    (fun _ => by split_ifs; exact poissonPMFReal_nonneg; exact le_rfl)
  have hac : A = C + poissonPMFReal lam k := Finset.sum_range_succ _ k
  convert h1.sub h2 using 1
  · funext mn
    by_cases hm : mn.1 ≤ k <;> by_cases hn : k < mn.2 <;> simp [hm, hn]
    ring
  · rw [hac]
    ring

end Renyi
