import Renyi.CoupledProfileBounds
import Renyi.EndpointExponent
import Renyi.UpperParameters

/-! Actual damping cancellation and quantitative cutoff loss. -/
noncomputable section
open Set
namespace Renyi

lemma damped_complement_cancellation {r δ E M : ℝ}
    (hr : 0 < r) (hr1 : r ≤ 1) (hδ : 0 < δ) (hδ1 : δ ≤ 1)
    (hE : 0 ≤ E) (hM : 1 ≤ M) (hrE : r ≤ Real.exp (-E/δ)) :
    r ≤ Real.exp (-E/8)*(1-(1-r)*Real.exp (-M*δ)) := by
  let t : ℝ := Real.exp (-M*δ)
  have ht : 0 < t := Real.exp_pos _
  have htlin : t ≤ 1-δ/2 := by
    have hh : t ≤ Real.exp (-δ) := Real.exp_le_exp.mpr (by nlinarith)
    exact hh.trans (exp_neg_le_linear_half hδ.le hδ1)
  have ht1 : t ≤ 1 := by linarith
  have hlog : Real.log r ≤ -E/δ := (Real.log_le_iff_le_exp hr).mpr hrE
  have hlog0 : Real.log r ≤ 0 := Real.log_nonpos hr.le hr1
  have hlogmul := (le_div_iff₀ hδ).mp hlog
  have hline := mul_le_mul_of_nonpos_right htlin hlog0
  have hexp : Real.exp (E/8)*r ≤ r^t := by
    rw [←Real.exp_log hr, ←Real.exp_add, Real.rpow_def_of_pos (Real.exp_pos _), Real.log_exp]
    apply Real.exp_le_exp.mpr
    nlinarith
  have ham := Real.geom_mean_le_arith_mean2_weighted ht.le (sub_nonneg.mpr ht1)
    hr.le (by norm_num : (0:ℝ)≤1) (by ring : t+(1-t)=1)
  simp only [Real.one_rpow,mul_one] at ham
  have hbound : Real.exp (E/8)*r ≤ 1-(1-r)*t := by nlinarith
  have hm := mul_le_mul_of_nonneg_left hbound (Real.exp_pos (-E/8)).le
  have heq : Real.exp (-E/8)*(Real.exp (E/8)*r)=r := by
    rw [←mul_assoc, ←Real.exp_add, neg_div, neg_add_cancel, Real.exp_zero, one_mul]
  rw [heq] at hm
  exact hm

lemma overlap_coefficients_unit {γ z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) :
    0 < overlapA γ z ∧ overlapA γ z < 1 ∧ 0 < overlapB γ z ∧ overlapB γ z < 1 := by
  have hc := overlap_coefficients hγ hγ1 hz hz1
  have he := overlap_endpoints hγ hγ1 hz hz1
  have hA : 0 < overlapA γ z := lt_trans (by linarith) hc.1
  have hB : 0 < overlapB γ z := hγ.trans hc.2
  have hAz := mul_pos hA (Real.rpow_pos_of_pos hz (1/(1-γ)))
  have hBz := mul_pos hB (Real.rpow_pos_of_pos hz (1/γ))
  exact ⟨hA, by linarith [he.2], hB, by linarith [he.1]⟩

lemma overlap_complement_bound {γ z E : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) (hzE : z ≤ Real.exp (-E)) :
    1-overlapB γ z ≤ Real.exp (-E/(1-γ)) := by
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have he := (overlap_endpoints hγ hγ1 hz hz1).1
  have hpow := Real.rpow_le_rpow hz.le hzE (one_div_pos.mpr (by linarith : 0<1-γ)).le
  rw [←Real.exp_mul] at hpow
  have hAp := mul_le_of_le_one_left (Real.rpow_nonneg hz.le (1/(1-γ))) hc.2.1.le
  have hexp : -E*(1/(1-γ))=-E/(1-γ) := by ring
  rw [hexp] at hpow
  linarith

/-- The cancellation for the actual scalar coefficients and actual omega=e^(-E/8). -/
theorem overlap_damped_complement_cancellation {γ z E M : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) (hE : 0 ≤ E) (hM : 1 ≤ M)
    (hzE : z ≤ Real.exp (-E)) :
    1-overlapB γ z ≤ Real.exp (-E/8)*(1-overlapB γ z*Real.exp (-M*(1-γ))) := by
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have h := damped_complement_cancellation (by linarith : 0<1-overlapB γ z)
    (by linarith : 1-overlapB γ z≤1) (by linarith : 0<1-γ) (by linarith : 1-γ≤1)
    hE hM (overlap_complement_bound hγ hγ1 hz hz1 hzE)
  simpa using h

/-- No external z-calibration assumption: the actual inverse envelope supplies it. -/
theorem upperOverlap_damped_complement_cancellation {γ E M : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (hE : 0 < E) (hM : 1 ≤ M) :
    1-overlapB γ (upperOverlapZ γ E) ≤
      Real.exp (-E/8)*(1-overlapB γ (upperOverlapZ γ E)*Real.exp (-M*(1-γ))) := by
  have hz := (upperOverlapZ_spec hγ hγ1 hE).1
  have hG := (upperOverlapZ_spec hγ hγ1 hE).2
  have hzE := overlapG_ge_parameter hγ hγ1 hz.1 hz.2
  rw [hG] at hzE
  exact overlap_damped_complement_cancellation hγ hγ1 hz.1 hz.2 hE.le hM hzE

lemma cutoff_replacement_lower {a b u v ω B H J : ℝ}
    (hH : 0 ≤ H) (hHJ : H ≤ J) (hB : B ≤ 1)
    (hc : 1-B ≤ ω*(1-b)) :
    a*u+b*v-max (a*u-1+B) 0*H ≤ a*u*(1-H)+b*v+ω*(1-b)*J := by
  have hc0 : 0 ≤ ω*(1-b) := (sub_nonneg.mpr hB).trans hc
  have h1 := mul_le_mul_of_nonneg_right hc hH
  have h2 := mul_le_mul_of_nonneg_left hHJ hc0
  have hm := mul_le_mul_of_nonneg_right (le_max_left (a*u-1+B) 0) hH
  nlinarith

/-- Cutoff cancellation for the actual profiles, not an assumed integral ordering. -/
theorem coupledProfiles_cutoff_lower {ℓ N : ℕ} (hN : 0 < N)
    {γ z E M fL f x y : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) (hE : 0 ≤ E) (hM : 1 ≤ M)
    (hzE : z ≤ Real.exp (-E)) (hy : 0 ≤ y) (hy1 : y ≤ 1) :
    let A := overlapA γ z*Real.exp (-M*γ)
    let B := overlapB γ z*Real.exp (-M*(1-γ))
    let ω := Real.exp (-E/8)
    A*lowProfile ℓ γ fL x + B*highProfile N (1-γ) f ω y -
      max (A*lowProfile ℓ γ fL x-1+overlapB γ z) 0 * endpointProfile N 6 1 y ≤
    A*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y) +
      B*highProfile N (1-γ) f ω y + ω*(1-B)*endpointProfile N 6 (1-γ) y := by
  dsimp only
  apply cutoff_replacement_lower
    (endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1).1
    (endpointProfile_exponent_antitone hN (by norm_num) (by linarith) (by linarith) hy hy1)
    (overlap_coefficients_unit hγ hγ1 hz hz1).2.2.2.le
    (overlap_damped_complement_cancellation hγ hγ1 hz hz1 hE hM hzE)

lemma cutoff_power_loss {γ r C Y H w : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hr : 0 ≤ r) (hC : 0 ≤ C) (hY : 0 < Y) (hH : 0 ≤ H) (hHY : H ≤ C*Y)
    (hw : w ≤ r*((1-γ)/Y)^γ) :
    max (w-r) 0*H ≤ C*r*(γ*(1-γ)) := by
  have hd : 0 < 1-γ := by linarith
  by_cases hYd : 1-γ ≤ Y
  · have hquot : (1-γ)/Y ≤ 1 := (div_le_one hY).mpr hYd
    have hq := Real.rpow_le_one (div_nonneg hd.le hY.le) hquot hγ.le
    have hwr : w ≤ r := hw.trans (mul_le_of_le_one_right hr hq)
    rw [max_eq_right (by linarith : w-r≤0), zero_mul]
    positivity
  · have hquot : 1 ≤ (1-γ)/Y := (le_div_iff₀ hY).mpr (by linarith)
    have hq := Real.one_le_rpow hquot hγ.le
    have hdiff : 0 ≤ r*(((1-γ)/Y)^γ-1) := mul_nonneg hr (sub_nonneg.mpr hq)
    have hmax : max (w-r) 0 ≤ r*(((1-γ)/Y)^γ-1) := max_le (by nlinarith) hdiff
    have hprod := mul_le_mul hmax hHY hH hdiff
    let t : ℝ := Y/(1-γ)
    have ht : 0 < t := div_pos hY hd
    have hrepr : (1-γ)*t=Y := by dsimp [t]; field_simp
    have hinv : (1-γ)/Y=t⁻¹ := by dsimp [t]; field_simp
    have hpower : ((1-γ)/Y)^γ*Y=(1-γ)*t^(1-γ) := by
      rw [hinv, ←Real.rpow_neg_eq_inv_rpow]
      calc
        _ = (1-γ)*(t^(-γ)*t) := by rw [←hrepr]; ring
        _ = _ := by rw [←Real.rpow_add_one ht.ne']; congr 2; ring
    have ham := Real.geom_mean_le_arith_mean2_weighted hd.le hγ.le ht.le
      (by norm_num : (0:ℝ)≤1) (by ring : (1-γ)+γ=1)
    simp only [Real.one_rpow,mul_one] at ham
    have hdiffpow : t^(1-γ)-t ≤ γ := by nlinarith [mul_nonneg hγ.le ht.le]
    have hloss : ((1-γ)/Y)^γ*Y-Y ≤ γ*(1-γ) := by
      have hm := mul_le_mul_of_nonneg_left hdiffpow hd.le
      rw [hpower, ←hrepr]
      nlinarith
    have hlast := mul_le_mul_of_nonneg_left hloss (mul_nonneg hC hr)
    nlinarith

lemma reverse_capacity_power {γ Z Y z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hZ : 0 ≤ Z) (hY : 0 < Y) (hz : 0 < z)
    (hcap : Z*Y ≤ Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    Real.exp (coupledProfileConstant*γ)*(Z/γ)^γ ≤ z^(1/(1-γ))*((1-γ)/Y)^γ := by
  have hd : 0 < 1-γ := by linarith
  have hC : 0 ≤ coupledProfileConstant := by
    unfold coupledProfileConstant
    have := Real.log_nonneg (by norm_num : (1:ℝ)≤24)
    linarith
  have hzpow := Real.rpow_pos_of_pos hz (1/(γ*(1-γ)))
  have hq : Z/γ ≤ Real.exp (-2*coupledProfileConstant)*((1-γ)/Y)*z^(1/(γ*(1-γ))) := by
    have hzcap := (le_div_iff₀ hY).mpr hcap
    calc
      _ ≤ (Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))/Y)/γ :=
        div_le_div_of_nonneg_right hzcap hγ.le
      _ = _ := by field_simp
  have hp := Real.rpow_le_rpow (div_nonneg hZ hγ.le) hq hγ.le
  have hm := mul_le_mul_of_nonneg_left hp (Real.exp_pos (coupledProfileConstant*γ)).le
  have heq : Real.exp (coupledProfileConstant*γ)*
      (Real.exp (-2*coupledProfileConstant)*((1-γ)/Y)*z^(1/(γ*(1-γ))))^γ =
      Real.exp (-coupledProfileConstant*γ)*(z^(1/(1-γ))*((1-γ)/Y)^γ) := by
    rw [Real.mul_rpow (mul_nonneg (Real.exp_pos _).le (div_nonneg hd.le hY.le)) hzpow.le,
      Real.mul_rpow (Real.exp_pos _).le (div_nonneg hd.le hY.le), ←Real.exp_mul,
      ←Real.rpow_mul hz.le]
    have hid : (1/(γ*(1-γ)))*γ=1/(1-γ) := by field_simp
    rw [hid]
    calc
      _ = (Real.exp (coupledProfileConstant*γ)*Real.exp ((-2*coupledProfileConstant)*γ))*
          (z^(1/(1-γ))*((1-γ)/Y)^γ) := by ring
      _ = _ := by rw [←Real.exp_add]; congr 2; ring
  rw [heq] at hm
  exact hm.trans (mul_le_of_le_one_left
    (mul_nonneg (Real.rpow_nonneg hz.le _) (Real.rpow_nonneg (div_nonneg hd.le hY.le) γ))
    (Real.exp_le_one_iff.mpr (by nlinarith)))

/-- The actual reverse arm obeys the precise bound used in the cutoff cancellation. -/
theorem lowProfile_reverse_capacity {ℓ : ℕ} (hℓ : 0 < ℓ)
    {γ z M f x Y : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) (hM : 0 ≤ M) (hf : 0 ≤ f) (hf1 : f < 1)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) (hY : 0 < Y)
    (hcap : ((ℓ:ℝ)^2*x)*Y ≤ Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ f x ≤
      (1-overlapB γ z)*((1-γ)/Y)^γ := by
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := (lowProfile_upper_power hℓ hγ hγ1.le hf hf1 hx hx1).trans
    (reverse_capacity_power hγ hγ1 (by positivity) hY hz hcap)
  have hu0 := (lowProfile_range hℓ hγ hf hf1 hx hx1).1
  have hA := mul_le_of_le_one_right hc.1.le (Real.exp_le_one_iff.mpr (by nlinarith : -M*γ≤0))
  have hmul := mul_le_mul hA hu hu0 hc.1.le
  have he := (overlap_endpoints hγ hγ1 hz hz1).1
  calc
    _ ≤ overlapA γ z*(z^(1/(1-γ))*((1-γ)/Y)^γ) := hmul
    _ = (overlapA γ z*z^(1/(1-γ)))*((1-γ)/Y)^γ := by ring
    _ = _ := by rw [show overlapA γ z*z^(1/(1-γ))=1-overlapB γ z by linarith only [he]]

lemma overlap_complement_le_parameter {γ z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) : 1-overlapB γ z ≤ z := by
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have he := (overlap_endpoints hγ hγ1 hz hz1).1
  have hd : 0 < 1-γ := by linarith
  have hpow : z^(1/(1-γ)) ≤ z := by
    have hh := Real.rpow_le_rpow_of_exponent_ge hz hz1.le
      ((le_div_iff₀ hd).mpr (by linarith : (1:ℝ)*(1-γ)≤1))
    simpa using hh
  have ha := mul_le_of_le_one_left (Real.rpow_nonneg hz.le (1/(1-γ))) hc.2.1.le
  linarith

/-- Step 3's O(kappa h) cutoff loss for the actual profiles and scalar coefficients. -/
theorem coupledProfiles_cutoff_loss {ℓ N : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    {γ z E M f x y : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) (hzE : z ≤ Real.exp (-E))
    (hM : 0 ≤ M) (hf : 0 ≤ f) (hf1 : f < 1)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) (hy : 0 < y) (hy1 : y ≤ 1)
    (hcap : ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    max ((overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ f x-1+overlapB γ z) 0 *
      endpointProfile N 6 1 y ≤ Real.exp (Real.log 12+1)*Real.exp (-E)*(γ*(1-γ)) := by
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hr : 0 ≤ 1-overlapB γ z := sub_nonneg.mpr hc.2.2.2.le
  have hY : 0 < (N:ℝ)^2*y := by positivity
  have hu := lowProfile_reverse_capacity hℓ hγ hγ1 hz hz1 hM hf hf1 hx hx1 hY hcap
  have hH := endpointProfile_upper_power hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy.le hy1
  simp only [Real.rpow_one, mul_one] at hH
  have hloss := cutoff_power_loss hγ hγ1 hr (Real.exp_pos (Real.log 12+1)).le hY
    (endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy.le hy1).1 hH hu
  have hrex := (overlap_complement_le_parameter hγ hγ1 hz hz1).trans hzE
  have hupper := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left hrex (Real.exp_pos (Real.log 12+1)).le)
    (mul_nonneg hγ.le (by linarith : 0≤1-γ))
  have heq : (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ f x-(1-overlapB γ z) =
      (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ f x-1+overlapB γ z := by ring
  rw [heq] at hloss
  exact hloss.trans hupper

end Renyi
