import Renyi.TensorSecondMoment

/-! Bounds on the actual tensor power moments, keeping the normalizer and
Jordan mass factors explicit. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- Each tensor parity is bounded by the product of the absolute factors. -/
theorem tensor_parities_le_absolute {ι κ : Type*} (l : ι → ℝ) (r : κ → ℝ) (ij : ι × κ) :
    tensorPositive l r ij ≤ |l ij.1| * |r ij.2| ∧
      tensorNegative l r ij ≤ |l ij.1| * |r ij.2| := by
  have heq : tensorPositive l r ij + tensorNegative l r ij = |l ij.1| * |r ij.2| := by
    rw [← positive_add_negative (l ij.1), ← positive_add_negative (r ij.2)]
    unfold tensorPositive tensorNegative
    ring
  constructor <;> nlinarith only [heq,tensorPositive_nonneg l r ij,tensorNegative_nonneg l r ij]

/-- The tensor atom is below its high coordinate because its low coordinate
is at least the principal scale. -/
theorem tensorAtom_le_high {ι κ : Type*} (u : ι → ℝ) (w : κ → ℝ) {a : ℝ}
    (ha : 0<a) (hua : ∀ i, a≤u i) (hw : ∀ j, 0≤w j) (ij : ι×κ) :
    tensorAtom u w a ij ≤ w ij.2 := by
  unfold tensorAtom
  apply (div_le_iff₀ (ha.trans_le (hua _))).mpr
  simpa only [mul_comm] using mul_le_mul_of_nonneg_right (hua ij.1) (hw ij.2)

/-- Both actual tensor parity power moments are at most the absolute high
power moment times the low absolute mass. -/
theorem tensor_parity_power_bound {ι κ : Type*} [Fintype ι] [Fintype κ]
    (l u : ι → ℝ) (r w : κ → ℝ) {a alpha C H : ℝ}
    (ha : 0<a) (hua : ∀ i, a≤u i) (hw : ∀ j, 0<w j) (halpha : 0≤alpha)
    (hC : (∑ i, |l i|)≤C) (hH : (∑ j, |r j| *w j^alpha)≤H) :
    (∑ ij, tensorPositive l r ij*tensorAtom u w a ij^alpha)≤C*H ∧
      (∑ ij, tensorNegative l r ij*tensorAtom u w a ij^alpha)≤C*H := by
  have hu (i) : 0<u i := ha.trans_le (hua i)
  have hH0 : 0≤H := (Finset.sum_nonneg (fun j _ => mul_nonneg (abs_nonneg _) (Real.rpow_nonneg (hw _).le _))).trans hH
  have hpower (ij : ι×κ) : tensorAtom u w a ij^alpha ≤ w ij.2^alpha :=
    Real.rpow_le_rpow (tensorAtom_pos u w ha hu hw ij).le
      (tensorAtom_le_high u w ha hua (fun j => (hw j).le) ij) halpha
  have hbound : (∑ ij : ι×κ, (|l ij.1| * |r ij.2|)*w ij.2^alpha)≤C*H := by
    calc
      _ = (∑ i, |l i|)*(∑ j, |r j| *w j^alpha) := by
        convert finite_tensor_factor (fun i => |l i|) (fun j => |r j| *w j^alpha) using 1
        apply Finset.sum_congr rfl
        intro ij _
        ring
      _ ≤ C*H := mul_le_mul hC hH
        (Finset.sum_nonneg (fun j _ => mul_nonneg (abs_nonneg _) (Real.rpow_nonneg (hw _).le _)))
        ((Finset.sum_nonneg (fun i _ => abs_nonneg _)).trans hC)
  constructor
  · apply le_trans (Finset.sum_le_sum (fun ij _ => ?_)) hbound
    exact mul_le_mul (tensor_parities_le_absolute l r ij).1 (hpower ij)
      (Real.rpow_nonneg (tensorAtom_pos u w ha hu hw ij).le _) (mul_nonneg (abs_nonneg _) (abs_nonneg _))
  · apply le_trans (Finset.sum_le_sum (fun ij _ => ?_)) hbound
    exact mul_le_mul (tensor_parities_le_absolute l r ij).2 (hpower ij)
      (Real.rpow_nonneg (tensorAtom_pos u w ha hu hw ij).le _) (mul_nonneg (abs_nonneg _) (abs_nonneg _))

/-- A finite prior with the actual reweighting moment formula has the exact
second-power ratio used by the normalization transfer. -/
theorem prior_second_ratio_of_moments {ι τ : Type*} [Fintype ι] [Fintype τ]
    (p : FiniteAtomicPrior τ) (mu z : ι→ℝ) {B Z alpha : ℝ}
    (hB : 0<B) (hZ : 0<Z) (halpha : 0<alpha)
    (hmom : ∀ j:ℝ, 0<j → priorMoment p j=B^(j-1)/Z*(∑ i, mu i*z i^(j-alpha)))
    (hM : 0<∑ i, mu i) :
    priorMoment p (2*alpha)/(priorMoment p alpha)^2 =
      B*Z*(∑ i, mu i*z i^alpha)/(∑ i,mu i)^2 := by
  rw [hmom (2*alpha) (by positivity),hmom alpha halpha]
  simp only [sub_self,Real.rpow_zero,mul_one,show 2*alpha-alpha=alpha by ring]
  have hpow : B*(B^(alpha-1))^2=B^(2*alpha-1) := by
    calc
      _ = B^(1:ℝ)*B^((alpha-1)*(2:ℝ)) := by rw [Real.rpow_one,Real.rpow_mul hB.le,Real.rpow_two]
      _ = B^(1+(alpha-1)*2) := (Real.rpow_add hB _ _).symm
      _ = _ := by congr 1; ring
  rw [← hpow]
  have hBp : B^(alpha-1)≠0 := (Real.rpow_pos_of_pos hB _).ne'
  field_simp

/-- A bound on the scaled normalizer and the parity moment preserves the
quadratic target-mass cancellation in the actual normalized second moment. -/
theorem refined_second_ratio_bound {B Z alpha H M zeta kappa CJ CH c : ℝ}
    (hB : 0<B) (_hZ : 0≤Z) (hH : 0≤H) (hz : 0≤zeta) (hk : 0<kappa)
    (hc : 0<c) (hCJ : 0≤CJ) (hCH : 0≤CH)
    (hscaled : Z/B^(alpha-1)≤CJ*zeta*kappa)
    (hhigh : H≤CH*zeta*kappa) (hmass : c*kappa≤M) :
    B*Z*H/M^2 ≤ (CJ*CH/c^2)*zeta^2*B^alpha := by
  have hM : 0<M := (mul_pos hc hk).trans_le hmass
  have hBp : 0<B^(alpha-1) := Real.rpow_pos_of_pos hB _
  have hscaled' : Z≤CJ*zeta*kappa*B^(alpha-1) := (div_le_iff₀ hBp).mp hscaled
  have hn : Z*H≤(CJ*zeta*kappa*B^(alpha-1))*(CH*zeta*kappa) :=
    mul_le_mul hscaled' hhigh hH (by positivity)
  have hd : (c*kappa)^2≤M^2 := sq_le_sq₀ (mul_pos hc hk).le hM.le |>.mpr hmass
  have hrat : Z*H/M^2≤((CJ*zeta*kappa*B^(alpha-1))*(CH*zeta*kappa))/(c*kappa)^2 := by
    calc
      _ ≤ ((CJ*zeta*kappa*B^(alpha-1))*(CH*zeta*kappa))/M^2 :=
        div_le_div_of_nonneg_right hn (sq_nonneg _)
      _ ≤ _ := div_le_div_of_nonneg_left (by positivity) (sq_pos_of_pos (mul_pos hc hk)) hd
  have hh := mul_le_mul_of_nonneg_left hrat hB.le
  have hpower : B*B^(alpha-1)=B^alpha := by
    calc
      _ = B^(1:ℝ)*B^(alpha-1) := by rw [Real.rpow_one]
      _ = B^(1+(alpha-1)) := (Real.rpow_add hB _ _).symm
      _ = _ := by congr 1; ring
  convert hh using 1
  · ring
  · field_simp
    rw [← hpower]
    ring

end Renyi
