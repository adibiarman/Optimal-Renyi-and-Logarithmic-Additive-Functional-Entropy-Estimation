import Renyi.CoupledProfileDeficit

/-! Strict deficits for the actual high profile uniformly below an omega ceiling. -/
noncomputable section
open Set
namespace Renyi

theorem kernel_mixture_local_deficit {N d : ℕ} (hN : 2≤N) (hd : 1≤d) {s f x T : ℝ}
    (hs : 0<s) (_hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1)
    (hy : lowDeficitLocalScale f*s≤(N:ℝ)^2*x) (hy1 : (N:ℝ)^2*x≤1/24)
    (hcmp : T≤Real.exp ((Real.log 24+1)*s)*((N:ℝ)^2*x/s)^s*endpointKernel N d x+
      f*(1-endpointKernel N d x)) :
    ((1-f)/128)*((N:ℝ)^2*x)≤1-T := by
  let y : ℝ := (N:ℝ)^2*x
  let v : ℝ := y/s
  let δ : ℝ := (1-f)/256
  let B : ℝ := Real.log 24+1
  let E : ℝ := s*(B+Real.log v)
  have hρ : 0<1-f := by linarith
  have hρ1 : 1-f≤1 := by linarith
  have hδ : 0<δ := by dsimp [δ];positivity
  have hB : 0<B := by have hl := Real.log_nonneg (by norm_num : (1:ℝ)≤24);dsimp [B];linarith
  have hv1 : 1≤v := by
    apply (le_div_iff₀ hs).mpr
    have hscale : 1≤lowDeficitLocalScale f := le_max_left _ _
    have hm := mul_le_mul_of_nonneg_right hscale hs.le
    exact hm.trans hy
  have hv : 0<v := zero_lt_one.trans_le hv1
  have hlog := log_add_two_le_linear hv hδ (show 16/δ^2≤v by
    apply (le_div_iff₀ hs).mpr
    have hscale : 16/δ^2≤lowDeficitLocalScale f :=
      (le_max_left _ _).trans (le_max_right _ _)
    exact (mul_le_mul_of_nonneg_right hscale hs.le).trans hy)
  have hBscale : 2*B/δ≤v := by
    apply (le_div_iff₀ hs).mpr
    have hscale : 2*B/δ≤lowDeficitLocalScale f := (le_max_right _ _).trans (le_max_right _ _)
    exact (mul_le_mul_of_nonneg_right hscale hs.le).trans hy
  have hBv : B≤δ*v/2 := by
    have hm := (div_le_iff₀ hδ).mp hBscale
    nlinarith only [hm]
  have hbudget : E≤δ*y := by
    have hm := mul_le_mul_of_nonneg_left (show B+Real.log v≤δ*v by linarith only [hlog,hBv]) hs.le
    have hid : s*v=y := by dsimp [v];field_simp
    change s*(B+Real.log v)≤δ*y
    calc
      _ ≤ s*(δ*v) := hm
      _ = δ*(s*v) := by ring
      _ = _ := by rw [hid]
  have hE0 : 0≤E := mul_nonneg hs.le (add_nonneg hB.le (Real.log_nonneg hv1))
  have hy0 : 0≤y := by dsimp [y];positivity
  have hρy : (1-f)*y≤y := by nlinarith only [mul_le_mul_of_nonneg_right hρ1 hy0]
  have hEhalf : E≤1/2 := by dsimp [δ] at hbudget; nlinarith only [hbudget,hρy,hy1]
  have hexp := exp_le_one_add_twice hE0 hEhalf
  have hK0 := endpointKernel_nonneg N d x
  have hK1 := endpointKernel_le_one (by omega : 0<N) d hx hx1
  have hKexp := endpointKernel_local_exp_upper hN hd hx hx1 (by linarith only [hy1])
  have hKlin : y/64≤1-endpointKernel N d x := by
    have he := endpoint_exp_neg_le_half (show 0≤y/32 by positivity) (show y/32≤1 by linarith only [hy1])
    change endpointKernel N d x≤Real.exp (-y/32) at hKexp
    have heq : Real.exp (-(y/32))=Real.exp (-y/32) := by congr 1;ring
    rw [heq] at he
    nlinarith only [hKexp,he]
  have hidexp : Real.exp ((Real.log 24+1)*s)*((N:ℝ)^2*x/s)^s=Real.exp E := by
    rw [Real.rpow_def_of_pos hv,←Real.exp_add]
    congr 1
    dsimp [E,B,v,y]
    ring
  rw [hidexp] at hcmp
  have hexpK := mul_le_mul_of_nonneg_right hexp hK0
  have hEK : 2*E*endpointKernel N d x≤2*E := mul_le_of_le_one_right (by positivity) hK1
  have hgap := mul_le_mul_of_nonneg_left hKlin hρ.le
  dsimp [δ] at hbudget
  nlinarith only [hcmp,hexpK,hEK,hgap,hbudget]

theorem kernel_mixture_outer_deficit {N d : ℕ} (hN : 2≤N) (hd : 1≤d) {s f x T : ℝ}
    (hs : 0<s) (_hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1)
    (hsmall : s≤lowDeficitOrder f) (hy : (1/24:ℝ)≤(N:ℝ)^2*x)
    (hcmp : T≤Real.exp (lowDeficitRate f*s)*(endpointKernel N d x)^(1-lowDeficitTilt f)+
      f*(1-endpointKernel N d x)) : lowDeficitOuterConstant f≤1-T := by
  let a : ℝ := lowDeficitTilt f
  let K : ℝ := endpointKernel N d x
  let E : ℝ := lowDeficitRate f*s
  let S : ℝ := (1-a)*K+a
  have ha : 0<a := by dsimp [a,lowDeficitTilt];linarith
  have ha1 : a≤1 := by dsimp [a,lowDeficitTilt];linarith
  have hrate := lowDeficitRate_pos hf hf1
  have hE0 : 0≤E := mul_nonneg hrate.le hs.le
  have hrate1 : s≤1/(2*lowDeficitRate f) :=
    hsmall.trans ((min_le_right _ _).trans (min_le_left _ _))
  have hrate2 : s≤(1-f)*lowDeficitKernelGap/(8*lowDeficitRate f) :=
    hsmall.trans ((min_le_right _ _).trans (min_le_right _ _))
  have hEhalf : E≤1/2 := by
    have hm := (le_div_iff₀ (mul_pos (by norm_num : (0:ℝ)<2) hrate)).mp hrate1
    dsimp [E]
    nlinarith only [hm]
  have hEbudget : 2*E≤(1-f)*lowDeficitKernelGap/4 := by
    have hm := (le_div_iff₀ (mul_pos (by norm_num : (0:ℝ)<8) hrate)).mp hrate2
    dsimp [E]
    nlinarith only [hm]
  have hxpos : 0<x := by
    by_contra hn
    have hm := mul_nonpos_of_nonneg_of_nonpos (sq_nonneg (N:ℝ)) (le_of_not_gt hn)
    nlinarith only [hm,hy]
  have hK0 : 0≤K := endpointKernel_nonneg N d x
  have hK1 : K≤1 := endpointKernel_le_one (by omega : 0<N) d hx hx1
  have hKg : lowDeficitKernelGap≤1-K := by
    have hk := endpointKernel_uniform_gap_scale (d:=d) hN hd hxpos hx1
      (by norm_num : (0:ℝ)<1/24) (by norm_num : (1/24:ℝ)≤1) hy
    have heq : -(1/24:ℝ)/32=-(1:ℝ)/768 := by norm_num
    rw [heq] at hk
    unfold lowDeficitKernelGap
    dsimp [K]
    linarith only [hk]
  have hAM := Real.geom_mean_le_arith_mean2_weighted (sub_nonneg.mpr ha1) ha.le hK0
    (by norm_num : (0:ℝ)≤1) (show (1-a)+a=1 by ring)
  simp only [Real.one_rpow,mul_one] at hAM
  have hS0 : 0≤S := (Real.rpow_nonneg hK0 (1-a)).trans hAM
  have hS1 : S≤1 := by dsimp [S];nlinarith only [mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hK1)]
  change T≤Real.exp E*K^(1-a)+f*(1-K) at hcmp
  have hAMexp := mul_le_mul_of_nonneg_left hAM (Real.exp_pos E).le
  have hexpS := mul_le_mul_of_nonneg_right (exp_le_one_add_twice hE0 hEhalf) hS0
  have hES : 2*E*S≤2*E := mul_le_of_le_one_right (by positivity) hS1
  have hρa : 1-f-a=3*(1-f)/4 := by dsimp [a,lowDeficitTilt];ring
  have hρapos : 0≤1-f-a := by linarith only [hρa,hf1]
  have hgap := mul_le_mul_of_nonneg_left hKg hρapos
  have hρag := congrArg (fun z:ℝ => z*lowDeficitKernelGap) hρa
  unfold lowDeficitOuterConstant
  dsimp [S] at hexpS hES
  nlinarith only [hcmp,hAMexp,hexpS,hES,hEbudget,hgap,hρag]

lemma highProfile_bump_comparison_ceiling {N : ℕ} (hN : 0<N) {s f ω w x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωw : ω≤w) (hw1 : w<1) (hx : 0≤x) (hx1 : x≤1) :
    highProfile N s f ω x≤
      Real.exp ((Real.log 24+1)*s)*((N:ℝ)^2*x/s)^s*endpointKernel N 6 x+
        w*(1-endpointKernel N 6 x) := by
  have hbump := coupled_bump_upper_kernel (d:=6) hN (by norm_num) hs hs1 hw1
    (fun _y hy => ⟨(highShoulder_range hN hs hf hf1 hω hy.1 hy.2).1,
      (highShoulder_range hN hs hf hf1 hω hy.1 hy.2).2.trans hωw⟩) hx hx1
  have hshoulder := (highShoulder_kernel_bound hN hs hf hf1 hω hx hx1).trans
    (mul_le_mul_of_nonneg_right hωw (sub_nonneg.mpr (endpointKernel_le_one hN 6 hx hx1)))
  unfold highProfile coupledProfile
  exact add_le_add hbump hshoulder

lemma highProfile_interpolated_upper_ceiling {N : ℕ} (hN : 2≤N) {s a f ω w x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (ha : 0<a) (hsa : s≤a)
    (hf : 0≤f) (hf1 : f≤1) (hω : 0≤ω) (hωw : ω≤w) (hw1 : w<1)
    (hx : 0≤x) (hx1 : x≤1) :
    highProfile N s f ω x≤
      Real.exp ((Real.log 24+1+Real.log (32/a))*s)*(endpointKernel N 6 x)^(1-a)+
        w*(1-endpointKernel N 6 x) := by
  have hcmp := highProfile_bump_comparison_ceiling (by omega : 0<N) hs hs1 hf hf1 hω hωw hw1 hx hx1
  have hratio := endpointKernel_interpolated_ratio hN (by norm_num : 2≤6) hs ha hsa hx hx1
  have hm := mul_le_mul_of_nonneg_left hratio (Real.exp_pos ((Real.log 24+1)*s)).le
  have hid : Real.exp ((Real.log 24+1)*s)*(32/a)^s=
      Real.exp ((Real.log 24+1+Real.log (32/a))*s) := by
    rw [Real.rpow_def_of_pos (by positivity : 0<32/a),←Real.exp_add]
    congr 1
    ring
  rw [←mul_assoc (Real.exp ((Real.log 24+1)*s)) ((32/a)^s) ((endpointKernel N 6 x)^(1-a)),hid] at hm
  nlinarith only [hcmp,hm]

/-- The actual high profile has a linear endpoint deficit uniformly below a fixed omega ceiling. -/
theorem highProfile_local_deficit {N : ℕ} (hN : 2≤N) {s f ω w x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωw : ω≤w) (hw1 : w<1) (hx : 0≤x) (hx1 : x≤1)
    (hy : lowDeficitLocalScale w*s≤(N:ℝ)^2*x) (hy1 : (N:ℝ)^2*x≤1/24) :
    ((1-w)/128)*((N:ℝ)^2*x)≤1-highProfile N s f ω x := by
  exact kernel_mixture_local_deficit hN (by norm_num : 1≤6) hs hs1 (hω.trans hωw) hw1 hx hx1 hy hy1
    (highProfile_bump_comparison_ceiling (by omega : 0<N) hs hs1 hf hf1 hω hωw hw1 hx hx1)

/-- The actual high profile has a fixed deficit outside the endpoint neighborhood. -/
theorem highProfile_outer_deficit {N : ℕ} (hN : 2≤N) {s f ω w x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωw : ω≤w) (hw1 : w<1) (hx : 0≤x) (hx1 : x≤1)
    (hsmall : s≤lowDeficitOrder w) (hy : (1/24:ℝ)≤(N:ℝ)^2*x) :
    lowDeficitOuterConstant w≤1-highProfile N s f ω x := by
  apply kernel_mixture_outer_deficit hN (by norm_num : 1≤6) hs hs1 (hω.trans hωw) hw1 hx hx1 hsmall hy
  have ha : 0<lowDeficitTilt w := by unfold lowDeficitTilt;linarith only [hw1]
  exact highProfile_interpolated_upper_ceiling hN hs hs1 ha (hsmall.trans (min_le_left _ _))
    hf hf1 hω hωw hw1 hx hx1

/-- Complete actual high-profile deficit with constants depending only on the omega ceiling. -/
theorem highProfile_deficit {N : ℕ} (hN : 2≤N) {s f ω w x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωw : ω≤w) (hw1 : w<1) (hx : 0≤x) (hx1 : x≤1)
    (hsmall : s≤lowDeficitOrder w) (hy : lowDeficitLocalScale w*s≤(N:ℝ)^2*x) :
    lowDeficitConstant w*min ((N:ℝ)^2*x) 1≤1-highProfile N s f ω x := by
  by_cases hlocal : (N:ℝ)^2*x≤1/24
  · have hgap := highProfile_local_deficit hN hs hs1 hf hf1 hω hωw hw1 hx hx1 hy hlocal
    have hy1 : (N:ℝ)^2*x≤1 := by linarith only [hlocal]
    rw [min_eq_left hy1]
    exact (mul_le_mul_of_nonneg_right (min_le_left _ _) (show 0≤(N:ℝ)^2*x by positivity)).trans hgap
  · have hgap := highProfile_outer_deficit hN hs hs1 hf hf1 hω hωw hw1 hx hx1 hsmall
      (le_of_lt (lt_of_not_ge hlocal))
    have hscale : lowDeficitConstant w*min ((N:ℝ)^2*x) 1≤lowDeficitConstant w :=
      mul_le_of_le_one_right (lowDeficitConstant_pos hw1).le (min_le_right _ _)
    exact (hscale.trans (min_le_right _ _)).trans hgap

/-- Uniform source form of the high-profile deficit, valid for every floor and omega below the ceiling. -/
theorem highProfile_deficit_uniform {w : ℝ} (hw : 0≤w) (hw1 : w<1) :
    ∃ s0 C c : ℝ, 0<s0 ∧ 0<C ∧ 0<c ∧
      ∀ (N:ℕ) (s f ω x:ℝ), 2≤N → 0<s → s≤1 → s≤s0 → 0≤f → f≤1 →
        0≤ω → ω≤w → 0≤x → x≤1 →
        C*s≤(N:ℝ)^2*x → c*min ((N:ℝ)^2*x) 1≤1-highProfile N s f ω x := by
  refine ⟨lowDeficitOrder w,lowDeficitLocalScale w,lowDeficitConstant w,
    lowDeficitOrder_pos hw hw1,?_,lowDeficitConstant_pos hw1,?_⟩
  · exact zero_lt_one.trans_le (le_max_left _ _)
  · intro N s f ω x hN hs hs1 hsmall hf hf1 hω hωw hx hx1 hy
    exact highProfile_deficit hN hs hs1 hf hf1 hω hωw hw1 hx hx1 hsmall hy

end Renyi
