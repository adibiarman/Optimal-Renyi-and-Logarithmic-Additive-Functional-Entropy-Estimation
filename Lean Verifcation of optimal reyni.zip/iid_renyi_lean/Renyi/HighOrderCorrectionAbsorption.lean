import Renyi.NearTwoHybridMargin

/-! Actual endpoint reserves absorb the baseline and below-cutoff losses above order two. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- The small cutoff defeats every integer-order coefficient uniformly. -/
theorem high_order_cutoff_geometric {m:ℕ} {alpha C r:ℝ}
    (hm:2≤m) (hma:(m:ℝ)≤alpha) (ham:alpha≤(m:ℝ)+1)
    (hC:1≤C) (hr:0<r) (hsmall:r≤1/(4*C)) :
    C^m*r^(alpha-1)≤8*C^2*(2:ℝ)^(1-alpha)*r := by
  have hC0:0<C:=zero_lt_one.trans_le hC
  have hr1:r≤1:=hsmall.trans ((div_le_one (by positivity : 0<4*C)).mpr (by linarith only [hC]))
  have hm2:(2:ℝ)≤m:=by exact_mod_cast hm
  have hreal:(m-2:ℕ)=(m:ℝ)-2:=by rw [Nat.cast_sub hm];norm_num
  have hmono:r^(alpha-2)≤r^(m-2:ℕ):=by
    rw [←Real.rpow_natCast,hreal]
    exact Real.rpow_le_rpow_of_exponent_ge hr hr1 (by linarith only [hma])
  have hCr:0≤C*r:=by positivity
  have hCr4:C*r≤1/4:=by
    have hh: r*(4*C)≤1:=(le_div_iff₀ (by positivity : 0<4*C)).mp hsmall
    nlinarith only [hh]
  have hnat:=pow_le_pow_left₀ hCr hCr4 (m-2)
  have hgeom:(1/4:ℝ)^(m-2)≤8*(2:ℝ)^(1-alpha):=by
    have hbase:(1/4:ℝ)=(2:ℝ)^(-2:ℝ):=by norm_num
    rw [←Real.rpow_natCast,hbase,←Real.rpow_mul (by norm_num : (0:ℝ)≤2),hreal]
    have hexp:-2*((m:ℝ)-2)≤3+(1-alpha):=by linarith only [ham,hm2]
    have hh:=Real.rpow_le_rpow_of_exponent_le (by norm_num : (1:ℝ)≤2) hexp
    rw [Real.rpow_add (by norm_num : (0:ℝ)<2)] at hh
    norm_num at hh
    simpa only [neg_mul] using hh
  have hpoly:C^m*r^(m-2)=C^2*(C*r)^(m-2):=by
    rw [mul_pow,←mul_assoc,←pow_add]
    have heq:2+(m-2)=m:=by omega
    rw [heq]
  have hstep:C^m*r^(alpha-2)≤C^2*(8*(2:ℝ)^(1-alpha)):=by
    calc
      C^m*r^(alpha-2)≤C^m*r^(m-2:ℕ):=mul_le_mul_of_nonneg_left hmono (by positivity)
      _ = C^2*(C*r)^(m-2):=hpoly
      _ ≤ C^2*((1/4:ℝ)^(m-2)):=mul_le_mul_of_nonneg_left hnat (sq_nonneg C)
      _ ≤ _:=mul_le_mul_of_nonneg_left hgeom (sq_nonneg C)
  have hrpow:r^(alpha-1)=r^(alpha-2)*r:=by
    have hh:=Real.rpow_add hr (alpha-2) 1
    rw [Real.rpow_one,show alpha-2+1=alpha-1 by ring] at hh
    exact hh
  rw [hrpow]
  have hh:=mul_le_mul_of_nonneg_right hstep hr.le
  nlinarith only [hh]

/-- A normalized cutoff has a genuine positive reserve in the actual simplex. -/
theorem simplex_high_order_endpoint_reserve {k:ℕ} (hk:0<k) (p:Simplex k)
    {alpha a:ℝ} (ha:0<a) (halpha:2≤alpha) (hcut:(k:ℝ)*a≤1/2) :
    (2:ℝ)^(1-alpha)*((k:ℝ)*a)*(k:ℝ)^(1-alpha)≤
      ∑i,if a≤p.mass i then p.mass i^alpha*min (a/p.mass i) 1 else 0 := by
  have hkR:(0:ℝ)<k:=by exact_mod_cast hk
  let t:ℝ:=1/(2*k)
  have ht:0<t:=by dsimp [t];positivity
  have hat:a≤t:=by
    dsimp [t]
    apply (le_div_iff₀ (by positivity : (0:ℝ)<2*k)).mpr
    nlinarith only [hcut]
  have hm:=simplex_truncated_endpoint_margin hk p halpha ha.le hat
  have hfirst:a*t^(alpha-2)≤t^(alpha-1):=by
    have hh:=mul_le_mul_of_nonneg_right hat (Real.rpow_nonneg ht.le (alpha-2))
    have heq:t*t^(alpha-2)=t^(alpha-1):=by
      have hh:=Real.rpow_add ht 1 (alpha-2)
      rw [Real.rpow_one,show 1+(alpha-2)=alpha-1 by ring] at hh
      exact hh.symm
    rwa [heq] at hh
  change (1/2:ℝ)*min (a*t^(alpha-2)) (t^(alpha-1))≤_ at hm
  rw [min_eq_left hfirst] at hm
  have hid:(1/2:ℝ)*(a*t^(alpha-2))=(2:ℝ)^(1-alpha)*((k:ℝ)*a)*(k:ℝ)^(1-alpha):=by
    have htPow:t^(alpha-2)=(2:ℝ)^(2-alpha)*(k:ℝ)^(2-alpha):=by
      dsimp [t]
      rw [one_div,Real.inv_rpow (by positivity : (0:ℝ)≤2*k),Real.mul_rpow (by norm_num : (0:ℝ)≤2) hkR.le,
        mul_inv,←Real.rpow_neg (by norm_num : (0:ℝ)≤2),←Real.rpow_neg hkR.le]
      simp only [neg_sub]
    have htwo:(2:ℝ)^(2-alpha)=2*(2:ℝ)^(1-alpha):=by
      rw [show 2-alpha=1+(1-alpha) by ring,Real.rpow_add (by norm_num : (0:ℝ)<2),Real.rpow_one]
    have hkpow:(k:ℝ)^(2-alpha)=(k:ℝ)*(k:ℝ)^(1-alpha):=by
      rw [show 2-alpha=1+(1-alpha) by ring,Real.rpow_add hkR,Real.rpow_one]
    rw [htPow,htwo,hkpow]
    ring
  rwa [←hid]


/-- The actual baseline is controlled by the summed endpoint reserve. -/
theorem high_order_baseline_le_endpoint_reserve {k m:ℕ} (hk:0<k) (p:Simplex k)
    {alpha a C d:ℝ} (hm:2≤m) (hma:(m:ℝ)≤alpha) (ham:alpha≤(m:ℝ)+1)
    (ha:0<a) (hC:1≤C) (hd:0≤d) (hcut:(k:ℝ)*a≤1/(4*C)) :
    d*C^m*((k:ℝ)*a)^(alpha-1)*(k:ℝ)^(1-alpha)≤
      (8*d*C^2)*(∑i,if a≤p.mass i then p.mass i^alpha*min (a/p.mass i) 1 else 0) := by
  have hkR:(0:ℝ)<k:=by exact_mod_cast hk
  have hr:0<(k:ℝ)*a:=mul_pos hkR ha
  have hm2:(2:ℝ)≤m:=by exact_mod_cast hm
  have hhalf:(k:ℝ)*a≤1/2:=hcut.trans ((div_le_iff₀ (by positivity : 0<4*C)).mpr (by linarith only [hC]))
  have hgeo:=high_order_cutoff_geometric hm hma ham hC hr hcut
  have hscaled:=mul_le_mul_of_nonneg_right hgeo (mul_nonneg hd (Real.rpow_nonneg hkR.le (1-alpha)))
  have hraw:=simplex_high_order_endpoint_reserve (alpha:=alpha) hk p ha (by linarith only [hm2,hma]) hhalf
  have hlast:=mul_le_mul_of_nonneg_left hraw (by positivity : 0≤8*d*C^2)
  nlinarith only [hscaled,hlast]

/-- The exponential below-cutoff loss has one additional small factor ka. -/
theorem high_order_below_le_endpoint_reserve {k m:ℕ} (hk:0<k) (p:Simplex k)
    {alpha a:ℝ} (hm:2≤m) (hma:(m:ℝ)≤alpha) (ham:alpha≤(m:ℝ)+1)
    (ha:0<a) (hcut:(k:ℝ)*a≤1/(4*100)) :
    (k:ℝ)*(100:ℝ)^(m+1)*a^alpha≤
      (8*(100:ℝ)^3*((k:ℝ)*a))*(∑i,if a≤p.mass i then p.mass i^alpha*min (a/p.mass i) 1 else 0) := by
  have hkR:(0:ℝ)<k:=by exact_mod_cast hk
  have hr:0<(k:ℝ)*a:=mul_pos hkR ha
  have hm2:(2:ℝ)≤m:=by exact_mod_cast hm
  have hgeo:=high_order_cutoff_geometric hm hma ham (by norm_num : (1:ℝ)≤100) hr hcut
  have hhalf:(k:ℝ)*a≤1/2:=hcut.trans (by norm_num)
  have hraw:=simplex_high_order_endpoint_reserve (alpha:=alpha) hk p ha (by linarith only [hm2,hma]) hhalf
  have hscaled:=mul_le_mul_of_nonneg_right hgeo
    (show 0≤100*((k:ℝ)*a)*(k:ℝ)^(1-alpha) by positivity)
  have hlast:=mul_le_mul_of_nonneg_left hraw (show 0≤8*(100:ℝ)^3*((k:ℝ)*a) by positivity)
  have hid:(k:ℝ)*(100:ℝ)^(m+1)*a^alpha=
      100*((k:ℝ)*a)*((100:ℝ)^m*((k:ℝ)*a)^(alpha-1)*(k:ℝ)^(1-alpha)) := by
    have heq:((k:ℝ)*a)^alpha*(k:ℝ)^(1-alpha)=(k:ℝ)*a^alpha:=by
      rw [Real.mul_rpow hkR.le ha.le]
      calc
        _=((k:ℝ)^alpha*(k:ℝ)^(1-alpha))*a^alpha:=by ring
        _=_:=by rw [←Real.rpow_add hkR,show alpha+(1-alpha)=1 by ring,Real.rpow_one]
    have hrpow:((k:ℝ)*a)^alpha=((k:ℝ)*a)*((k:ℝ)*a)^(alpha-1):=by
      have hh:=Real.rpow_add hr 1 (alpha-1)
      rw [Real.rpow_one,show 1+(alpha-1)=alpha by ring] at hh
      exact hh
    rw [pow_succ]
    calc
      _=(100*(100:ℝ)^m)*(((k:ℝ)*a)^alpha*(k:ℝ)^(1-alpha)):=by rw [heq];ring
      _=_:=by rw [hrpow];ring
  rw [hid]
  nlinarith only [hscaled,hlast]

/-- Any assignment to polynomial and heavy arms retains the scalar endpoint reserve. -/
theorem hybrid_endpoint_margin_dominates_endpoint {k:ℕ} (p:Simplex k)
    (light:Fin k→Bool) {alpha a theta h ell c w:ℝ}
    (ha:0≤a) (htheta:0≤theta) (hh:0≤h) (hell:1≤ell) (hc:0≤c) (hw:0≤w) :
    min c w*(∑i,if a≤p.mass i then p.mass i^alpha*min (a/p.mass i) 1 else 0)≤
      c*(∑i,if light i then if a≤p.mass i then p.mass i^alpha*
        min (h+theta*p.mass i+min (ell^2*(a/p.mass i)) 1) 1 else 0 else 0)+
      w*(∑i,if light i then 0 else p.mass i^alpha) := by
  have hsum:(∑i,if a≤p.mass i then p.mass i^alpha*min (a/p.mass i) 1 else 0)≤
      ∑i,if a≤p.mass i then p.mass i^alpha*min (a/p.mass i+theta*p.mass i) 1 else 0:=by
    apply Finset.sum_le_sum
    intro i _
    split_ifs
    · exact mul_le_mul_of_nonneg_left (min_le_min
        (le_add_of_nonneg_right (mul_nonneg htheta (p.nonneg i))) (le_refl 1))
        (Real.rpow_nonneg (p.nonneg i) alpha)
    · exact le_refl 0
  exact (mul_le_mul_of_nonneg_left hsum (le_min hc hw)).trans
    (hybrid_endpoint_margin_dominates_two_arm p light ha htheta hh hell hc hw)


/-- The actual heavy arm has a fixed epsilon-dependent gap above order two. -/
theorem upperOmega_high_order_gap {k:ℕ} {alpha eps Ch cw:ℝ}
    (ha:2≤alpha) (hg:0<fractionalPart alpha) (hg1:fractionalPart alpha<1)
    (heps:0<eps) (hCh:0≤Ch) (hcw:0≤cw) :
    1-Real.exp (-cw*eps)≤1-upperOmega k alpha eps Ch cw := by
  have ha1:1<alpha:=by linarith only [ha]
  have hE:eps≤upperE0 k alpha eps Ch:=by
    have hh:eps*(alpha-1)≤upperE0 k alpha eps Ch:=
      (upper_reserved_interval (k:=k) ha1 hg hg1 heps hCh).1
    nlinarith only [hh,mul_nonneg heps.le (show 0≤alpha-2 by linarith only [ha])]
  have hmul:=mul_le_mul_of_nonneg_left hE hcw
  have hexp:=Real.exp_le_exp.mpr (show -cw*upperE0 k alpha eps Ch≤-cw*eps by nlinarith only [hmul])
  exact sub_le_sub_left hexp 1

/-- One fixed small d and one final exposure multiplier absorb all deterministic
corrections into half the actual mixed strict upper reserve, uniformly for alpha≥2. -/
theorem upper_actual_high_order_correction_absorbed {eps Ch cb lambda CL cL C0 c cw:ℝ}
    (heps:0<eps) (hCh:0≤Ch) (hcb:0<cb) (hlambda:0<lambda)
    (hCL:1≤CL) (hcL:0<cL) (hC0:100≤C0) (hc:0<c) (hcw:0<cw) :
    ∃d0 D0:ℝ,0<d0 ∧ d0≤1 ∧ 1≤D0 ∧
      ∀(k:ℕ) (alpha D d ell:ℝ),0<k → 2≤alpha →
        0<fractionalPart alpha → fractionalPart alpha<1 →
        D0≤D → 0≤d → d≤d0 → 1≤ell → ∀(p:Simplex k) (light:Fin k→Bool),
      let a:=upperA k alpha eps Ch D cb lambda CL cL
      let b:=upperB k alpha eps D cb CL cL
      let N:=upperDegree alpha CL cL (rootMultiplier k alpha eps)
      let omega:=upperOmega k alpha eps Ch cw
      4*(upperActualBaseline k alpha C0 d a*(k:ℝ)^(1-alpha))+
        (k:ℝ)*(100:ℝ)^(upperOrderFloor alpha+1)*a^alpha≤
      (1/2:ℝ)*(c*(∑i,if light i then if a≤p.mass i then p.mass i^alpha*
        min (fractionalPart alpha*(1-fractionalPart alpha)+((N:ℝ)^2/b)*p.mass i+
          min (ell^2*(a/p.mass i)) 1) 1 else 0 else 0)+
        (1-omega)*(∑i,if light i then 0 else p.mass i^alpha)) := by
  let K:=min c (1-Real.exp (-cw*eps))
  have hgap:0<1-Real.exp (-cw*eps):=by
    apply sub_pos.mpr
    exact Real.exp_lt_one_iff.mpr (by nlinarith only [mul_pos hcw heps])
  have hK:0<K:=lt_min hc hgap
  have hCpos:0<C0:=by linarith only [hC0]
  let d0:=min 1 (K/(128*C0^2))
  let ca:=min (1/(4*C0)) (K/(32*(100:ℝ)^3))
  have hca:0<ca:=lt_min (by positivity) (by positivity)
  obtain ⟨D0,hD0,hcut⟩:=upper_cutoff_eventually_small heps hCh hcb hlambda hCL hcL hca
  obtain ⟨rm,rp,hrm,_hrp,hcutBoth⟩:=upper_actual_cutoff heps hCh hcb hlambda hCL hcL
  refine ⟨d0,D0,by dsimp [d0];positivity,min_le_left _ _,hD0,?_⟩
  intro k alpha D d ell hk ha hg hg1 hD0D hd hd0 hell p light
  dsimp only
  have ha1:1<alpha:=by linarith only [ha]
  have hD:0<D:=zero_lt_one.trans_le (hD0.trans hD0D)
  have hkR:(0:ℝ)<k:=by exact_mod_cast hk
  let a:=upperA k alpha eps Ch D cb lambda CL cL
  let b:=upperB k alpha eps D cb CL cL
  let N:=upperDegree alpha CL cL (rootMultiplier k alpha eps)
  let S:=∑i,if a≤p.mass i then p.mass i^alpha*min (a/p.mass i) 1 else 0
  have hden:0<(alpha-1)/(alpha*k):=div_pos (sub_pos.mpr ha1) (mul_pos (by linarith only [ha]) hkR)
  have haPos:0<a:=by
    have hh:rm/D*Real.exp (-upperW k alpha eps)≤a/((alpha-1)/(alpha*k)):=
      (hcutBoth k alpha D hk ha1 hg hg1 hD).1
    exact (mul_pos (mul_pos (div_pos hrm hD) (Real.exp_pos _)) hden).trans_le
      ((le_div_iff₀ hden).mp hh)
  have hb:0<b:=upperB_pos hk ha1 hg hg1 hD hcb hCL hcL
  have hka:(k:ℝ)*a≤ca:=by
    have hh:=mul_le_mul_of_nonneg_left (hcut k alpha D hk ha1 hg hg1 hD0D) hkR.le
    have hid:(k:ℝ)*(ca*((alpha-1)/(alpha*k)))=ca*((alpha-1)/alpha):=by field_simp
    rw [hid] at hh
    have hratio:(alpha-1)/alpha≤1:=(div_le_one (by linarith only [ha] : 0<alpha)).mpr (by linarith)
    exact hh.trans (mul_le_of_le_one_right hca.le hratio)
  have hsmall:(k:ℝ)*a≤1/(4*C0):=hka.trans (min_le_left _ _)
  have hsmall100:(k:ℝ)*a≤1/(4*100):=by
    have hh:((k:ℝ)*a)*(4*C0)≤1:=(le_div_iff₀ (by positivity : 0<4*C0)).mp hsmall
    have hh':400*((k:ℝ)*a)≤4*C0*((k:ℝ)*a):=by
      have hm:=mul_le_mul_of_nonneg_right hC0 (mul_pos hkR haPos).le
      nlinarith only [hm]
    norm_num only at ⊢
    nlinarith only [hh,hh']
  have hm:2≤upperOrderFloor alpha:=by
    exact (Nat.le_floor_iff (by linarith only [ha] : 0≤alpha)).mpr (by norm_num; exact ha)
  have hma:(upperOrderFloor alpha:ℝ)≤alpha:=upperOrderFloor_le ha1
  have ham:alpha≤(upperOrderFloor alpha:ℝ)+1:=(Nat.lt_floor_add_one alpha).le
  have hbase:=high_order_baseline_le_endpoint_reserve hk p hm hma ham haPos
    (by linarith only [hC0] : 1≤C0) hd hsmall
  have hbelow:=high_order_below_le_endpoint_reserve hk p hm hma ham haPos hsmall100
  have hS:0≤S:=Finset.sum_nonneg (fun i _=>by
    split_ifs
    · exact mul_nonneg (Real.rpow_nonneg (p.nonneg i) alpha)
        (le_min (div_nonneg haPos.le (p.nonneg i)) zero_le_one)
    · exact le_refl 0)
  have hdK:32*d*C0^2≤K/4:=by
    have hh:=hd0.trans (min_le_right 1 (K/(128*C0^2)))
    have hh':d*(128*C0^2)≤K:=(le_div_iff₀ (by positivity : 0<128*C0^2)).mp hh
    nlinarith only [hh']
  have hrK:8*(100:ℝ)^3*((k:ℝ)*a)≤K/4:=by
    have hh:=hka.trans (min_le_right (1/(4*C0)) (K/(32*(100:ℝ)^3)))
    have hh':((k:ℝ)*a)*(32*(100:ℝ)^3)≤K:=(le_div_iff₀ (by norm_num : 0<32*(100:ℝ)^3)).mp hh
    nlinarith only [hh']
  have hOmega:=upperOmega_high_order_gap (k:=k) ha hg hg1 heps hCh hcw.le
  have hW:0≤1-upperOmega k alpha eps Ch cw:=hgap.le.trans hOmega
  have htheta:0≤(N:ℝ)^2/b:=div_nonneg (sq_nonneg _) hb.le
  have hgamma:0≤fractionalPart alpha*(1-fractionalPart alpha):=mul_nonneg hg.le (by linarith only [hg1])
  have hmix:=hybrid_endpoint_margin_dominates_endpoint (alpha:=alpha) p light haPos.le htheta hgamma hell hc.le hW
  have hmin:K≤min c (1-upperOmega k alpha eps Ch cw):=min_le_min (le_refl c) hOmega
  have hreserve:K*S≤c*(∑i,if light i then if a≤p.mass i then p.mass i^alpha*
      min (fractionalPart alpha*(1-fractionalPart alpha)+((N:ℝ)^2/b)*p.mass i+
        min (ell^2*(a/p.mass i)) 1) 1 else 0 else 0)+
      (1-upperOmega k alpha eps Ch cw)*(∑i,if light i then 0 else p.mass i^alpha):=
    (mul_le_mul_of_nonneg_right hmin hS).trans hmix
  have hbaseId:upperActualBaseline k alpha C0 d a*(k:ℝ)^(1-alpha)=
      d*C0^upperOrderFloor alpha*((k:ℝ)*a)^(alpha-1)*(k:ℝ)^(1-alpha):=by
    unfold upperActualBaseline
    rw [min_eq_right (by linarith only [ha] : 1≤alpha-1)]
    ring
  rw [hbaseId]
  have hdS:=mul_le_mul_of_nonneg_right hdK hS
  have hrS:=mul_le_mul_of_nonneg_right hrK hS
  change _≤(8*d*C0^2)*S at hbase
  change _≤(8*(100:ℝ)^3*((k:ℝ)*a))*S at hbelow
  nlinarith only [hbase,hbelow,hdS,hrS,hreserve]

end Renyi
