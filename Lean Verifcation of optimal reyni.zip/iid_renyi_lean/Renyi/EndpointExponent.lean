import Renyi.EndpointIntegral
import Renyi.DegreeOneProfile

/-! Uniform endpoint-profile comparison as the exponent approaches one. -/
noncomputable section
open scoped BigOperators
open MeasureTheory Set
namespace Renyi

def endpointScaledWeight (N d : ℕ) (s y : ℝ) : ℝ :=
  y ^ (s - 1) * endpointKernel N d (y / (N : ℝ)^2)

def endpointScaledPrimitive (N d : ℕ) (s z : ℝ) : ℝ :=
  ∫ y in (0 : ℝ)..z, endpointScaledWeight N d s y

theorem endpointScaledWeight_integrable (N d : ℕ) {s : ℝ} (hs : 0 < s) (a b : ℝ) :
    IntervalIntegrable (endpointScaledWeight N d s) volume a b := by
  apply (intervalIntegral.intervalIntegrable_rpow' (by linarith : -1 < s - 1)).mul_continuousOn
  exact ((endpointKernel_continuous N d).comp (continuous_id.div_const _)).continuousOn

theorem endpointScaledPrimitive_rescale {N d : ℕ} (hN : 0 < N) (s : ℝ)
    {z : ℝ} (hz : 0 ≤ z) :
    endpointScaledPrimitive N d s z =
      ((N : ℝ)^2) ^ s * endpointPrimitive N d s (z / (N : ℝ)^2) := by
  have hR : 0 < (N : ℝ)^2 := by positivity
  have hid (y : ℝ) (hy : 0 ≤ y) : endpointScaledWeight N d s y =
      ((N : ℝ)^2)^(s-1) * ((y/(N : ℝ)^2)^(s-1) * endpointKernel N d (y/(N : ℝ)^2)) := by
    unfold endpointScaledWeight
    rw [← mul_assoc, ← Real.mul_rpow hR.le (div_nonneg hy hR.le), mul_div_cancel₀ _ hR.ne']
  unfold endpointScaledPrimitive
  have he : (∫ y in (0 : ℝ)..z, endpointScaledWeight N d s y) =
      ∫ y in (0 : ℝ)..z, ((N : ℝ)^2)^(s-1) *
        ((y/(N : ℝ)^2)^(s-1) * endpointKernel N d (y/(N : ℝ)^2)) := by
    apply intervalIntegral.integral_congr
    intro y hy
    rw [Set.uIcc_of_le hz] at hy
    exact hid y hy.1
  rw [he, intervalIntegral.integral_const_mul,
    intervalIntegral.integral_comp_div (fun y => y^(s-1)*endpointKernel N d y) hR.ne']
  simp only [zero_div, smul_eq_mul]
  rw [← mul_assoc]
  have hp : ((N : ℝ)^2)^(s-1) * (N : ℝ)^2 = ((N : ℝ)^2)^s := by
    rw [← Real.rpow_add_one hR.ne', sub_add_cancel]
  rw [hp]
  rfl

theorem endpointScaledPrimitive_ratio {N d : ℕ} (hN : 0 < N)
    {s x : ℝ} (hx : 0 ≤ x) :
    endpointScaledPrimitive N d s ((N : ℝ)^2*x) /
      endpointScaledPrimitive N d s ((N : ℝ)^2) = endpointProfile N d s x := by
  have hR : 0 < (N : ℝ)^2 := by positivity
  rw [endpointScaledPrimitive_rescale hN s (mul_nonneg hR.le hx),
    endpointScaledPrimitive_rescale hN s hR.le, mul_div_cancel_left₀ _ hR.ne', div_self hR.ne',
    mul_div_mul_left _ _ (Real.rpow_pos_of_pos hR s).ne']
  rfl

theorem endpointScaledPrimitive_total_lower {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) :
    Real.exp (-(Real.log 12 + 1)) ≤ endpointScaledPrimitive N d s ((N : ℝ)^2) := by
  have hR : 0 < (N : ℝ)^2 := by positivity
  rw [endpointScaledPrimitive_rescale hN s hR.le, div_self hR.ne']
  change Real.exp (-(Real.log 12 + 1)) ≤ ((N : ℝ)^2)^s * endpointIntegral N d s
  have hp : ((N : ℝ)^2)^s = (N : ℝ)^(2*s) := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul (by positivity : 0 ≤ (N : ℝ))]
    norm_num
  rw [hp]
  have h := endpointIntegral_normalized_lower hN hd hs
  have hlog : 0 ≤ Real.log 12 + 1 := by have := Real.log_nonneg (by norm_num : (1:ℝ) ≤ 12); linarith
  have he : Real.exp (-(Real.log 12+1)) ≤ Real.exp (-(Real.log 12+1)*s) :=
    Real.exp_le_exp.mpr (by nlinarith)
  have hnonneg : 0 ≤ (N : ℝ)^(2*s)*endpointIntegral N d s :=
    mul_nonneg (Real.rpow_nonneg (by positivity) _) (endpointIntegral_pos hN hd hs).le
  nlinarith

theorem endpoint_low_log_bound {y : ℝ} (hy : 0 < y) (hy1 : y ≤ 1) :
    |Real.log y| ≤ 4 * y ^ (-(1/4 : ℝ)) := by
  have hp : 0 < y ^ (-(1/4 : ℝ)) := Real.rpow_pos_of_pos hy _
  have h := Real.log_le_sub_one_of_pos hp
  rw [Real.log_rpow hy] at h
  rw [abs_of_nonpos (Real.log_nonpos hy.le hy1)]
  nlinarith

theorem endpoint_high_log_bound {y : ℝ} (hy : 1 ≤ y) :
    Real.log y ≤ 2 * y ^ (1/2 : ℝ) := by
  have hy0 : 0 < y := zero_lt_one.trans_le hy
  have h := Real.log_le_sub_one_of_pos (Real.rpow_pos_of_pos hy0 (1/2 : ℝ))
  rw [Real.log_rpow hy0] at h
  linarith

theorem endpoint_power_difference_low {s y : ℝ} (hs : 1/2 ≤ s) (hs1 : s ≤ 1)
    (hy : 0 < y) (hy1 : y ≤ 1) :
    |y^(s-1) - 1| ≤ 4 * (1-s) * y ^ (-(3/4 : ℝ)) := by
  have hp : 1 ≤ y^(s-1) := Real.one_le_rpow_of_pos_of_le_one_of_nonpos hy hy1 (by linarith)
  rw [abs_of_nonneg (by linarith : 0 ≤ y^(s-1)-1)]
  have h := Real.add_one_le_exp ((1-s)*Real.log y)
  have hmul := mul_le_mul_of_nonneg_left h (Real.rpow_pos_of_pos hy (s-1)).le
  have hid : y^(s-1)*Real.exp ((1-s)*Real.log y) = 1 := by
    rw [Real.rpow_def_of_pos hy, ← Real.exp_add]
    convert Real.exp_zero using 1
    ring
  rw [hid] at hmul
  have hlo := endpoint_low_log_bound hy hy1
  have hlog : Real.log y ≤ 0 := Real.log_nonpos hy.le hy1
  rw [abs_of_nonpos hlog] at hlo
  have hpower : y^(s-1) ≤ y^(-(1/2:ℝ)) :=
    Real.rpow_le_rpow_of_exponent_ge hy hy1 (by linarith)
  have hm := mul_le_mul hpower hlo (by linarith : 0 ≤ -Real.log y)
    (Real.rpow_nonneg hy.le _)
  have heq : y^(-(1/2:ℝ)) * (4*y^(-(1/4:ℝ))) = 4*y^(-(3/4:ℝ)) := by
    rw [mul_left_comm, ← Real.rpow_add hy]
    norm_num
  rw [heq] at hm
  have hmm := mul_le_mul_of_nonneg_left hm (by linarith : 0 ≤ 1-s)
  nlinarith only [hmul, hmm]

theorem endpoint_power_difference_high {s y : ℝ} (hs1 : s ≤ 1) (hy : 1 ≤ y) :
    |y^(s-1) - 1| ≤ 2 * (1-s) * y^(1/2:ℝ) := by
  have hy0 : 0 < y := zero_lt_one.trans_le hy
  have hp : y^(s-1) ≤ 1 := by
    have h := Real.rpow_le_rpow_of_exponent_le hy (show s-1 ≤ 0 by linarith)
    simpa only [Real.rpow_zero] using h
  rw [abs_of_nonpos (by linarith : y^(s-1)-1 ≤ 0)]
  have h := Real.add_one_le_exp ((s-1)*Real.log y)
  rw [mul_comm (s-1), ← Real.rpow_def_of_pos hy0] at h
  have hh := mul_le_mul_of_nonneg_left (endpoint_high_log_bound hy) (by linarith : 0 ≤ 1-s)
  nlinarith

theorem endpointScaledWeight_difference_low {N d : ℕ} (hN : 0 < N)
    {s y : ℝ} (hs : 1/2 ≤ s) (hs1 : s ≤ 1) (hy : 0 < y) (hy1 : y ≤ 1) :
    |endpointScaledWeight N d s y - endpointScaledWeight N d 1 y| ≤
      4 * (1-s) * y^(-(3/4:ℝ)) := by
  have hR : 0 < (N : ℝ)^2 := by positivity
  have hR1 : 1 ≤ (N : ℝ)^2 := by
    have hn : (1:ℝ) ≤ N := by exact_mod_cast hN
    nlinarith
  have hx1 : y/(N:ℝ)^2 ≤ 1 := (div_le_one hR).2 (hy1.trans hR1)
  have hK0 := endpointKernel_nonneg N d (y/(N:ℝ)^2)
  have hK1 := endpointKernel_le_one hN d (div_nonneg hy.le hR.le) hx1
  simp only [endpointScaledWeight, sub_self, Real.rpow_zero, one_mul]
  rw [← sub_one_mul, abs_mul, abs_of_nonneg hK0]
  exact (mul_le_of_le_one_right (abs_nonneg _) hK1).trans
    (endpoint_power_difference_low hs hs1 hy hy1)

theorem endpointScaledWeight_difference_high {N d : ℕ} (hN : 0 < N) (hd : 2 ≤ d)
    {s y : ℝ} (hs1 : s ≤ 1) (hy : 1 ≤ y) (hyR : y ≤ (N : ℝ)^2) :
    |endpointScaledWeight N d s y - endpointScaledWeight N d 1 y| ≤
      2 * (1-s) * y^(-(3/2:ℝ)) := by
  have hR : 0 < (N : ℝ)^2 := by positivity
  have hy0 : 0 < y := zero_lt_one.trans_le hy
  have hx1 : y/(N:ℝ)^2 ≤ 1 := (div_le_one hR).2 hyR
  have hK0 := endpointKernel_nonneg N d (y/(N:ℝ)^2)
  have hK1 := endpointKernel_le_inverse_power hN d (div_pos hy0 hR) hx1
  rw [mul_div_cancel₀ _ hR.ne'] at hK1
  have hInv0 : 0 ≤ y⁻¹ := inv_nonneg.mpr hy0.le
  have hInv1 : y⁻¹ ≤ 1 := inv_le_one_of_one_le₀ hy
  have hpow := pow_le_pow_of_le_one hInv0 hInv1 hd
  have hK2 : endpointKernel N d (y/(N:ℝ)^2) ≤ y^(-(2:ℝ)) := by
    rw [Real.rpow_neg hy0.le, Real.rpow_two, ← inv_pow]
    exact hK1.trans hpow
  simp only [endpointScaledWeight, sub_self, Real.rpow_zero, one_mul]
  rw [← sub_one_mul, abs_mul, abs_of_nonneg hK0]
  have h := mul_le_mul (endpoint_power_difference_high hs1 hy) hK2 hK0
    (mul_nonneg (by linarith : 0 ≤ 2*(1-s)) (Real.rpow_nonneg hy0.le _))
  have hid : (2*(1-s)*y^(1/2:ℝ))*y^(-(2:ℝ)) = 2*(1-s)*y^(-(3/2:ℝ)) := by
    rw [mul_assoc, ← Real.rpow_add hy0]
    norm_num
  exact h.trans_eq hid

theorem endpointScaledPrimitive_difference_low {N d : ℕ} (hN : 0 < N)
    {s z : ℝ} (hs : 1/2 ≤ s) (hs1 : s ≤ 1) (hz : 0 ≤ z) (hz1 : z ≤ 1) :
    |endpointScaledPrimitive N d s z - endpointScaledPrimitive N d 1 z| ≤ 16*(1-s) := by
  have hi := (intervalIntegral.intervalIntegrable_rpow' (a := 0) (b := z)
    (by norm_num : (-1:ℝ) < -(3/4:ℝ))).const_mul (4*(1-s))
  have h := intervalIntegral.norm_integral_le_of_norm_le (μ := volume)
    (f := fun y : ℝ => endpointScaledWeight N d s y - endpointScaledWeight N d 1 y) hz
    (Filter.Eventually.of_forall (fun y hy => ?_)) hi
  · have heval : (∫ y in (0:ℝ)..z, 4*(1-s)*y^(-(3/4:ℝ))) = 16*(1-s)*z^(1/4:ℝ) := by
      rw [intervalIntegral.integral_const_mul, integral_rpow (Or.inl (by norm_num))]
      norm_num
      ring
    rw [heval] at h
    have hpow : z^(1/4:ℝ) ≤ 1 := Real.rpow_le_one hz hz1 (by norm_num)
    have hb := mul_le_mul_of_nonneg_left hpow (by linarith : 0 ≤ 16*(1-s))
    simp only [mul_one] at hb
    apply le_trans _ (h.trans hb)
    rw [endpointScaledPrimitive, endpointScaledPrimitive,
      ← intervalIntegral.integral_sub (endpointScaledWeight_integrable N d (by linarith) 0 z)
        (endpointScaledWeight_integrable N d (by norm_num) 0 z), Real.norm_eq_abs]
  · simpa only [Real.norm_eq_abs] using endpointScaledWeight_difference_low hN hs hs1 hy.1 (hy.2.trans hz1)

theorem endpointScaledPrimitive_difference {N d : ℕ} (hN : 0 < N) (hd : 2 ≤ d)
    {s z : ℝ} (hs : 1/2 ≤ s) (hs1 : s ≤ 1) (hz : 0 ≤ z) (hzR : z ≤ (N:ℝ)^2) :
    |endpointScaledPrimitive N d s z - endpointScaledPrimitive N d 1 z| ≤ 20*(1-s) := by
  by_cases hz1 : z ≤ 1
  · exact (endpointScaledPrimitive_difference_low hN hs hs1 hz hz1).trans (by linarith)
  have h1z : 1 ≤ z := (lt_of_not_ge hz1).le
  have hi : IntervalIntegrable (fun y : ℝ => 2*(1-s)*y^(-(3/2:ℝ))) volume 1 z := by
    apply IntervalIntegrable.const_mul
    apply intervalIntegral.intervalIntegrable_rpow (Or.inr ?_)
    rw [Set.uIcc_of_le h1z]
    norm_num
  have h := intervalIntegral.norm_integral_le_of_norm_le (μ := volume)
    (f := fun y : ℝ => endpointScaledWeight N d s y - endpointScaledWeight N d 1 y) h1z
    (Filter.Eventually.of_forall (fun y hy => ?_)) hi
  · have heval : (∫ y in (1:ℝ)..z, 2*(1-s)*y^(-(3/2:ℝ))) =
        4*(1-s)*(1-z^(-(1/2:ℝ))) := by
      rw [intervalIntegral.integral_const_mul, integral_rpow (Or.inr ⟨by norm_num, ?_⟩)]
      · norm_num
        ring
      · rw [Set.uIcc_of_le h1z]
        norm_num
    rw [heval, Real.norm_eq_abs] at h
    have htail : |(∫ y in (1:ℝ)..z, endpointScaledWeight N d s y - endpointScaledWeight N d 1 y)| ≤
        4*(1-s) := h.trans (by nlinarith [Real.rpow_nonneg hz (-(1/2:ℝ))])
    have hlo := endpointScaledPrimitive_difference_low (d := d) hN hs hs1 (z := 1) (by norm_num) le_rfl
    have hsplit (q : ℝ) (hq : 0 < q) : endpointScaledPrimitive N d q z =
        endpointScaledPrimitive N d q 1 + ∫ y in (1:ℝ)..z, endpointScaledWeight N d q y := by
      exact (intervalIntegral.integral_add_adjacent_intervals
        (endpointScaledWeight_integrable N d hq 0 1)
        (endpointScaledWeight_integrable N d hq 1 z)).symm
    rw [hsplit s (by linarith), hsplit 1 (by norm_num)]
    have hid : endpointScaledPrimitive N d s 1 + (∫ y in (1:ℝ)..z, endpointScaledWeight N d s y) -
        (endpointScaledPrimitive N d 1 1 + ∫ y in (1:ℝ)..z, endpointScaledWeight N d 1 y) =
        (endpointScaledPrimitive N d s 1 - endpointScaledPrimitive N d 1 1) +
        ∫ y in (1:ℝ)..z, endpointScaledWeight N d s y - endpointScaledWeight N d 1 y := by
      rw [intervalIntegral.integral_sub (endpointScaledWeight_integrable N d (by linarith) 1 z)
        (endpointScaledWeight_integrable N d (by norm_num) 1 z)]
      ring
    rw [hid]
    exact (abs_add_le _ _).trans (by linarith)
  · simpa only [Real.norm_eq_abs] using endpointScaledWeight_difference_high hN hd hs1 hy.1.le (hy.2.trans hzR)

theorem endpointScaledPrimitive_range {N d : ℕ} (hN : 0 < N) {s z : ℝ}
    (hs : 0 < s) (hz : 0 ≤ z) (hzR : z ≤ (N:ℝ)^2) :
    0 ≤ endpointScaledPrimitive N d s z ∧
      endpointScaledPrimitive N d s z ≤ endpointScaledPrimitive N d s ((N:ℝ)^2) := by
  have hR : 0 < (N:ℝ)^2 := by positivity
  rw [endpointScaledPrimitive_rescale hN s hz, endpointScaledPrimitive_rescale hN s hR.le,
    div_self hR.ne']
  exact ⟨mul_nonneg (Real.rpow_nonneg hR.le _) (endpointPrimitive_nonneg N d (div_nonneg hz hR.le)),
    mul_le_mul_of_nonneg_left (endpointPrimitive_le_integral N d hs (div_nonneg hz hR.le)
      ((div_le_one hR).2 hzR)) (Real.rpow_nonneg hR.le _)⟩

theorem normalized_difference_bound {u v m n D : ℝ}
    (hm : 0 < m) (hn : 0 < n) (hv : 0 ≤ v) (hvn : v ≤ n) (_hD : 0 ≤ D)
    (huv : |u-v| ≤ D) (hmn : |m-n| ≤ D) :
    |u/m-v/n| ≤ 2*D/m := by
  have hvn0 : 0 ≤ v/n := div_nonneg hv hn.le
  have hvn1 : v/n ≤ 1 := (div_le_one hn).2 hvn
  have hid : u/m-v/n = ((u-v)+(v/n)*(n-m))/m := by field_simp; ring
  rw [hid, abs_div, abs_of_pos hm]
  apply div_le_div_of_nonneg_right _ hm.le
  have hh := abs_add_le (u-v) ((v/n)*(n-m))
  rw [abs_mul, abs_of_nonneg hvn0, abs_sub_comm n m] at hh
  have hprod := mul_le_mul hvn1 hmn (abs_nonneg _) (by norm_num : (0:ℝ) ≤ 1)
  nlinarith

/-- Uniform exponent comparison for the actual normalized kernel integral. -/
theorem endpointProfile_exponent_difference_abs {N d : ℕ} (hN : 0 < N)
    (hd0 : 2 ≤ d) (hd1 : d ≤ 6) {s x : ℝ}
    (hs : 1/2 ≤ s) (hs1 : s ≤ 1) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    |endpointProfile N d s x - endpointProfile N d 1 x| ≤
      (40 * Real.exp (Real.log 12 + 1)) * (1-s) := by
  have hR : 0 < (N:ℝ)^2 := by positivity
  have hz : 0 ≤ (N:ℝ)^2*x := mul_nonneg hR.le hx
  have hzR : (N:ℝ)^2*x ≤ (N:ℝ)^2 := by nlinarith
  have hlow := endpointScaledPrimitive_total_lower hN hd1 (by linarith : 0 < s) hs1
  have hlow1 := endpointScaledPrimitive_total_lower (d := d) hN hd1 (s := 1) (by norm_num) le_rfl
  have hm : 0 < endpointScaledPrimitive N d s ((N:ℝ)^2) := (Real.exp_pos _).trans_le hlow
  have hn : 0 < endpointScaledPrimitive N d 1 ((N:ℝ)^2) := (Real.exp_pos _).trans_le hlow1
  have hv := endpointScaledPrimitive_range (d := d) hN (s := 1) (by norm_num) hz hzR
  have hdif := endpointScaledPrimitive_difference (d := d) hN hd0 hs hs1 hz hzR
  have htot := endpointScaledPrimitive_difference (d := d) hN hd0 hs hs1 hR.le le_rfl
  have h := normalized_difference_bound hm hn hv.1 hv.2 (by linarith : 0 ≤ 20*(1-s)) hdif htot
  rw [endpointScaledPrimitive_ratio hN hx, endpointScaledPrimitive_ratio hN hx] at h
  apply h.trans
  calc
    2*(20*(1-s))/endpointScaledPrimitive N d s ((N:ℝ)^2) ≤
        2*(20*(1-s))/Real.exp (-(Real.log 12+1)) :=
      div_le_div_of_nonneg_left (by linarith) (Real.exp_pos _) hlow
    _ = _ := by rw [Real.exp_neg]; field_simp; ring

theorem endpointProfile_exponent_antitone {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    endpointProfile N d 1 x ≤ endpointProfile N d s x := by
  rcases eq_or_lt_of_le hx with rfl | hx
  · simp only [endpointProfile_zero, le_refl]
  have hsint := endpointKernel_weight_integrable N d hs
  have h1int := endpointKernel_weight_integrable N d (by norm_num : (0:ℝ)<1)
  have hprefix : x^(s-1)*endpointPrimitive N d 1 x ≤ endpointPrimitive N d s x := by
    unfold endpointPrimitive
    rw [← intervalIntegral.integral_const_mul]
    apply intervalIntegral.integral_mono_on_of_le_Ioo hx.le ((h1int 0 x).const_mul _) (hsint 0 x)
    intro y hy
    simp only [sub_self, Real.rpow_zero, one_mul]
    exact mul_le_mul_of_nonneg_right
      (Real.rpow_le_rpow_of_nonpos hy.1 hy.2.le (by linarith)) (endpointKernel_nonneg N d y)
  have htail : endpointTailIntegral N d s x ≤ x^(s-1)*endpointTailIntegral N d 1 x := by
    unfold endpointTailIntegral
    rw [← intervalIntegral.integral_const_mul]
    apply intervalIntegral.integral_mono_on hx1 (hsint x 1) ((h1int x 1).const_mul _)
    intro y hy
    simp only [sub_self, Real.rpow_zero, one_mul]
    exact mul_le_mul_of_nonneg_right
      (Real.rpow_le_rpow_of_nonpos hx hy.1 (by linarith)) (endpointKernel_nonneg N d y)
  have hsplit (q : ℝ) (hq : 0 < q) : endpointIntegral N d q =
      endpointPrimitive N d q x + endpointTailIntegral N d q x :=
    (intervalIntegral.integral_add_adjacent_intervals
      (endpointKernel_weight_integrable N d hq 0 x)
      (endpointKernel_weight_integrable N d hq x 1)).symm
  have hps0 := endpointPrimitive_nonneg N d (s := s) hx.le
  have hp10 := endpointPrimitive_nonneg N d (s := 1) hx.le
  have ht10 : 0 ≤ endpointTailIntegral N d 1 x := by
    apply intervalIntegral.integral_nonneg hx1
    intro y hy
    exact mul_nonneg (Real.rpow_nonneg (hx.le.trans hy.1) _) (endpointKernel_nonneg N d y)
  have hA := mul_le_mul_of_nonneg_right hprefix ht10
  have hB := mul_le_mul_of_nonneg_left htail hp10
  unfold endpointProfile
  apply (div_le_div_iff₀ (endpointIntegral_pos hN hd (by norm_num : (0:ℝ)<1))
    (endpointIntegral_pos hN hd hs)).2
  rw [hsplit 1 (by norm_num), hsplit s hs]
  nlinarith only [hA, hB]

/-- The signed and uniform source comparison needed at order one. -/
theorem endpointProfile_order_one_comparison {N d : ℕ} (hN : 0 < N)
    (hd0 : 2 ≤ d) (hd1 : d ≤ 6) {s x : ℝ}
    (hs : 1/2 ≤ s) (hs1 : s ≤ 1) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    0 ≤ endpointProfile N d s x - endpointProfile N d 1 x ∧
    endpointProfile N d s x - endpointProfile N d 1 x ≤
      (40 * Real.exp (Real.log 12 + 1)) * (1-s) := by
  exact ⟨sub_nonneg.mpr (endpointProfile_exponent_antitone hN hd1 (by linarith) hs1 hx hx1),
    (le_abs_self _).trans (endpointProfile_exponent_difference_abs hN hd0 hd1 hs hs1 hx hx1)⟩

end Renyi
