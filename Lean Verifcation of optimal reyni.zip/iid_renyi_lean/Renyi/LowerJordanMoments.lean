import Renyi.InterpolationMomentBounds

/-! Lower and upper Jordan power moments of the actual interpolation factors. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- A normalized principal mass of at least one half bounds its normalizer. -/
theorem principal_normalizer_upper {n : ℕ} (u : Fin (n+1) → ℝ)
    {a rho e : ℝ} (ha : 0 < a) (hrho : 0 ≤ rho)
    (hprincipal : 1/2 ≤ normalizedInterpolation u a rho e none) :
    interpolationNormalizer u a rho e * a^e ≤ 2*(1+rho) := by
  have hP := interpolationNormalizer_pos u (e := e) ha hrho
  change (1/2 : ℝ) ≤ ((1+rho)*a^(-e))/interpolationNormalizer u a rho e at hprincipal
  have hp := (le_div_iff₀ hP).mp hprincipal
  have hh := mul_le_mul_of_nonneg_right hp (Real.rpow_pos_of_pos ha e).le
  have hcancel : a^(-e)*a^e = 1 := by rw [← Real.rpow_add ha]; simp
  have heq : ((1+rho)*a^(-e))*a^e = 1+rho := by rw [mul_assoc,hcancel,mul_one]
  rw [heq] at hh
  nlinarith

/-- The endpoint node gives an actual lower bound on the canceled Jordan power
moment, including the normalizing principal factor. -/
theorem interpolation_jordan_endpoint_lower {n : ℕ} (u : Fin (n+1) → ℝ)
    {a rho e beta b : ℝ} (ha : 0 < a) (hrho : 0 ≤ rho) (hb : 0 ≤ b)
    (hu : ∀ i, 0 < u i) (j : Fin (n+1)) (huj : u j = 1)
    (hweight : b/2 ≤ |lagrangeWeight u a j|)
    (hprincipal : 1/2 ≤ normalizedInterpolation u a rho e none)
    (hcancel : ∑ i, normalizedInterpolation u a rho e i * interpolationNodes u a i^beta = 0) :
    b*a^e/(8*(1+rho)) ≤
      ∑ i, positiveCoeff (normalizedInterpolation u a rho e i) * interpolationNodes u a i^beta := by
  let P := interpolationNormalizer u a rho e
  let J := ∑ i, positiveCoeff (normalizedInterpolation u a rho e i)*interpolationNodes u a i^beta
  have hP : 0 < P := interpolationNormalizer_pos u (e := e) ha hrho
  have hpower0 (i : Option (Fin (n+1))) : 0 < interpolationNodes u a i := by
    cases i with
    | none => exact ha
    | some i => exact hu i
  have htwo := absolute_power_moment_eq_twice (normalizedInterpolation u a rho e)
    (interpolationNodes u a) beta hcancel
  have hsingle := Finset.single_le_sum
    (s := (Finset.univ : Finset (Option (Fin (n+1)))))
    (f := fun i => |normalizedInterpolation u a rho e i| * interpolationNodes u a i^beta)
    (fun i _ => mul_nonneg (abs_nonneg _) (Real.rpow_pos_of_pos (hpower0 i) beta).le)
    (Finset.mem_univ (some j))
  change |normalizedInterpolation u a rho e (some j)| * (u j)^beta ≤ _ at hsingle
  rw [huj,Real.one_rpow,mul_one,htwo] at hsingle
  have hatom : |normalizedInterpolation u a rho e (some j)| =
      |lagrangeWeight u a j| * (1+rho*a)/P := by
    have hfac : 0 ≤ 1+rho*a := by positivity
    simp only [normalizedInterpolation,weightedInterpolation,interpolationWeights,
      interpolationNodes,Option.elim_some,huj,Real.one_rpow,mul_one,div_one,
      abs_div,abs_neg,abs_mul,abs_of_nonneg hfac]
    change |lagrangeWeight u a j| * (1+rho*a)/|P| = _
    rw [abs_of_pos hP]
  have hmass : b/(2*P) ≤ 2*J := by
    rw [hatom] at hsingle
    have hh : b/2 ≤ |lagrangeWeight u a j| * (1+rho*a) := by
      have hp := mul_nonneg (abs_nonneg (lagrangeWeight u a j)) (mul_nonneg hrho ha.le)
      nlinarith
    have hd := div_le_div_of_nonneg_right hh hP.le
    have heq : (b/2)/P=b/(2*P) := by ring
    rw [heq] at hd
    exact hd.trans hsingle
  have hPupper := principal_normalizer_upper u ha hrho hprincipal
  have hJlower : b/(4*P) ≤ J := by
    have heq : b/(4*P)=(b/(2*P))/2 := by ring
    rw [heq]
    apply (div_le_iff₀ (by norm_num : (0:ℝ)<2)).mpr
    linarith
  have hfirst : b*a^e/(8*(1+rho)) ≤ b/(4*P) := by
    apply (div_le_div_iff₀ (by positivity : 0 < 8*(1+rho)) (by positivity : 0 < 4*P)).mpr
    change b*a^e*(4*P) ≤ b*(8*(1+rho))
    have hh := mul_le_mul_of_nonneg_left hPupper hb
    dsimp [P]
    nlinarith
  exact hfirst.trans hJlower

/-- The complementary low factor has an explicit polynomial lower bound on J.
The endpoint argument includes degree zero. -/
theorem complementary_jordan_lower (n : ℕ) (xi z beta : ℝ)
    (hxi0 : 1/2 ≤ xi) (hxi1 : xi < 1) (hz0 : 0 < z) (hz1 : z ≤ 1)
    (hcancel :
      let b := xi/((n : ℝ)+1)^2
      let a := Real.exp (-5)*b*z^(1/xi)
      let u := chebyshevNode n b
      ∑ i, normalizedInterpolation u a 0 xi i*interpolationNodes u a i^beta = 0) :
    let b := xi/((n : ℝ)+1)^2
    let a := Real.exp (-5)*b*z^(1/xi)
    let u := chebyshevNode n b
    Real.exp (-5)*z/(32*((n : ℝ)+1)^4) ≤
      ∑ i, positiveCoeff (normalizedInterpolation u a 0 xi i)*interpolationNodes u a i^beta := by
  let b := xi/((n : ℝ)+1)^2
  let a := Real.exp (-5)*b*z^(1/xi)
  let u := chebyshevNode n b
  have hxi : 0 < xi := by linarith
  have hnp : (1 : ℝ) ≤ ((n : ℝ)+1)^2 := by
    have hn0 : (0 : ℝ) ≤ n := Nat.cast_nonneg n
    nlinarith
  have hb0 : 0 < b := by dsimp [b]; positivity
  have hb1 : b < 1 := by apply (div_lt_one (by positivity)).mpr; linarith
  have ha0 : 0 < a := by dsimp [a]; positivity
  have haB : a ≤ b/2 := by
    have hzp : z^(1/xi) ≤ 1 := Real.rpow_le_one hz0.le hz1 (by positivity)
    have he : Real.exp (-5) ≤ 1/2 := by
      rw [Real.exp_neg]
      apply (inv_le_iff_one_le_mul₀ (Real.exp_pos 5)).mpr
      have hh := Real.add_one_le_exp (5 : ℝ)
      nlinarith
    have hh := mul_le_mul_of_nonneg_left hzp (show 0 ≤ Real.exp (-5)*b by positivity)
    dsimp [a]
    nlinarith [mul_le_mul_of_nonneg_right he hb0.le]
  have hu0 (i) : 0 < u i := hb0.trans_le (chebyshevNode_bounds n b hb1.le i).1
  have hweight : b/2 ≤ |lagrangeWeight u a (Fin.last n)| := by
    by_cases hn : n=0
    · subst n
      have huniv : (Finset.univ : Finset (Fin (0+1))) = {Fin.last 0} := by decide
      simp only [lagrangeWeight,Lagrange.basis,huniv,Finset.erase_singleton,Finset.prod_empty,Polynomial.eval_one,abs_one]
      linarith
    · exact chebyshev_last_weight_lower n b a (Nat.pos_of_ne_zero hn) hb0.le hb1 haB
  have hprincipal := (chebyshev_nodes_weighted n xi z hxi0 hxi1 hz0 hz1).2
  have hlow := interpolation_jordan_endpoint_lower u (rho := 0) (e := xi) ha0 (by norm_num)
    hb0.le hu0 (Fin.last n) (chebyshevNode_last n b) hweight hprincipal hcancel
  have haPower : a^xi = Real.exp (-5*xi)*b^xi*z := by
    dsimp [a]
    rw [Real.mul_rpow (by positivity : 0 ≤ Real.exp (-5)*b) (Real.rpow_pos_of_pos hz0 _).le,
      Real.mul_rpow (Real.exp_pos _).le hb0.le, ← Real.exp_mul,
      ← Real.rpow_mul hz0.le, one_div_mul_cancel hxi.ne',Real.rpow_one]
  have hpow : b ≤ b^xi := by
    simpa only [Real.rpow_one] using Real.rpow_le_rpow_of_exponent_ge hb0 hb1.le hxi1.le
  have he : Real.exp (-5) ≤ Real.exp (-5*xi) := Real.exp_le_exp.mpr (by linarith)
  have hblow : (1 : ℝ)/(2*((n : ℝ)+1)^2) ≤ b := by
    dsimp [b]
    apply (div_le_div_iff₀ (by positivity : 0 < 2*((n : ℝ)+1)^2) (by positivity)).mpr
    nlinarith
  have hpoly : Real.exp (-5)*z/(32*((n : ℝ)+1)^4) ≤ b*a^xi/8 := by
    rw [haPower]
    have hprod := mul_le_mul he hpow hb0.le (Real.exp_pos _).le
    have hb2 : (1 : ℝ)/(4*((n : ℝ)+1)^4) ≤ b^2 := by
      have hid : (1 : ℝ)/(4*((n : ℝ)+1)^4)=(1/(2*((n : ℝ)+1)^2))^2 := by
        field_simp
        ring
      rw [hid]
      exact (sq_le_sq₀ (by positivity) hb0.le).mpr hblow
    have hh := mul_le_mul_of_nonneg_left hb2 (mul_nonneg (Real.exp_pos (-5)).le hz0.le)
    have hh' := mul_le_mul_of_nonneg_right hprod (mul_nonneg hb0.le hz0.le)
    calc
      Real.exp (-5)*z/(32*((n : ℝ)+1)^4) =
          (Real.exp (-5)*z * (1/(4*((n : ℝ)+1)^4)))/8 := by field_simp; ring
      _ ≤ (Real.exp (-5)*z*b^2)/8 := div_le_div_of_nonneg_right hh (by norm_num)
      _ = (Real.exp (-5)*b*(b*z))/8 := by ring
      _ ≤ (Real.exp (-5*xi)*b^xi*(b*z))/8 := div_le_div_of_nonneg_right hh' (by norm_num)
      _ = b*(Real.exp (-5*xi)*b^xi*z)/8 := by ring
  dsimp only
  simp only [add_zero,mul_one] at hlow
  exact hpoly.trans hlow

/-- The active low factor has two explicit Jordan power bounds. -/
theorem active_jordan_bounds (n : ℕ) (zeta a rho s beta : ℝ)
    (hn : 0<n) (hz0 : 0<zeta) (hz1 : zeta≤3/5)
    (ha : 0<a) (hrho : 0≤rho) (hrho1 : rho≤1)
    (haB : a≤((zeta/8)/((n:ℝ)+1)^2)/2)
    (hpert : rho*a/((zeta/8)/((n:ℝ)+1)^2)≤zeta)
    (hbeta : s+1≤beta)
    (hprincipal : 1/2≤normalizedInterpolation (chebyshevNode n ((zeta/8)/((n:ℝ)+1)^2)) a rho s none)
    (hcancel : ∑ i, normalizedInterpolation (chebyshevNode n ((zeta/8)/((n:ℝ)+1)^2)) a rho s i *
      interpolationNodes (chebyshevNode n ((zeta/8)/((n:ℝ)+1)^2)) a i^beta=0) :
    let b := (zeta/8)/((n:ℝ)+1)^2
    let u := chebyshevNode n b
    zeta*a^s/(128*((n:ℝ)+1)^2)≤
      (∑ i, positiveCoeff (normalizedInterpolation u a rho s i)*interpolationNodes u a i^beta) ∧
    (∑ i, positiveCoeff (normalizedInterpolation u a rho s i)*interpolationNodes u a i^beta)≤3*zeta*a^s := by
  let b := (zeta/8)/((n:ℝ)+1)^2
  let u := chebyshevNode n b
  have hb0 : 0<b := by dsimp [b]; positivity
  have hn0 : (0:ℝ)≤n := Nat.cast_nonneg n
  have hden : (1:ℝ)≤((n:ℝ)+1)^2 := by nlinarith
  have hb1 : b<1 := by
    apply (div_lt_one (by positivity : (0:ℝ)<((n:ℝ)+1)^2)).mpr
    linarith
  have hu (i) : 0<u i := hb0.trans_le (chebyshevNode_bounds n b hb1.le i).1
  have hweight := chebyshev_last_weight_lower n b a hn hb0.le hb1 haB
  have hlower := interpolation_jordan_endpoint_lower u ha hrho hb0.le hu (Fin.last n)
    (chebyshevNode_last n b) hweight hprincipal hcancel
  have habs := active_absolute_power_bound n zeta a rho s beta hn hz0 hz1 ha hrho haB hpert hbeta
  have htwo := absolute_power_moment_eq_twice (normalizedInterpolation u a rho s)
    (interpolationNodes u a) beta hcancel
  have hJ0 : 0≤∑ i, positiveCoeff (normalizedInterpolation u a rho s i)*interpolationNodes u a i^beta := by
    apply Finset.sum_nonneg
    intro i _
    exact mul_nonneg (le_max_right _ _) (Real.rpow_nonneg (by cases i with | none => exact ha.le | some i => exact (hu i).le) _)
  constructor
  · have heq : zeta*a^s/(128*((n:ℝ)+1)^2)=b*a^s/16 := by dsimp [b]; field_simp; ring
    rw [heq]
    apply le_trans ?_ hlower
    apply div_le_div_of_nonneg_left (by positivity) (by positivity : (0:ℝ)<8*(1+rho))
    linarith
  · dsimp only at habs
    rw [htwo] at habs
    linarith

end Renyi
