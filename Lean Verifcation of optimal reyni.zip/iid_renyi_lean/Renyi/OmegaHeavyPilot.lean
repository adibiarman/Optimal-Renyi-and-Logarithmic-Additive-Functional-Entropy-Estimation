import Renyi.OmegaHeavyRandomSubset
import Renyi.PoissonPilotProduct

/-! Actual random-pilot omega-heavy concentration under the concrete count experiment. -/
noncomputable section
open scoped BigOperators NNReal
open Set MeasureTheory ProbabilityTheory
namespace Renyi

/-- The source omega-heavy event after arbitrary selection by the actual pilot histogram.
The scale and margin are explicit and independent of k, n, cp and the distribution. -/
theorem omega_heavy_pilot_subset_concentration {eps c0 rho : ℝ}
    (heps : 0<eps) (hc0 : 0<c0) (hc01 : c0<1) (hrho : 0<rho) (hrho1 : rho<1)
    {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) {a E0 : ℝ} (ha : 3/2≤a)
    (hElow : eps*(a-1)≤E0) (hEhigh : E0≤2*eps*(a-1))
    (S : (Fin k→ℕ)→Finset (Fin k)) (G : Set (Fin k→ℕ))
    (hmean : ∀y∈G,∀i∈S y,omegaHeavyScale eps c0 rho*a≤(n:ℝ)*p.mass i) :
    1-rho≤(pilotHistogramPMF n cp p).toMeasure.real {h |
      (fun i => pilotSelectionCount i h)∈G →
      h∈omegaHeavySubsetEvent (fun i => pilotMainCount i) (fun i => n*simplexNN p i)
        a E0 eps c0 (omegaHeavyMargin eps c0) (S (fun i => pilotSelectionCount i h))} := by
  let μ := (finitePoissonPMF (fun i => n*simplexNN p i)).toMeasure
  let ν := (finitePoissonPMF (fun i => cp*(n*simplexNN p i))).toMeasure
  have hlaw (i : Fin k) : MeasurePreserving (fun x:Fin k→ℕ => x i) μ (poissonMeasure (n*simplexNN p i)) := by
    dsimp [μ]
    rw [finitePoissonPMF,Measure.toPMF_toMeasure]
    exact measurePreserving_eval (fun i => poissonMeasure (n*simplexNN p i)) i
  have hh := (omega_heavy_random_subset_concentration_explicit (μ:=μ) (ν:=ν)
    heps hc0 hc01 hrho hrho1).2.2 k a E0 ha hElow hEhigh
      (fun i x => x i) (fun i => n*simplexNN p i) hlaw S G (by
        intro y hy i hi
        simpa only [NNReal.coe_mul,simplexNN_coe] using hmean y hy i hi)
  let E : Set ((Fin k→ℕ)×(Fin k→ℕ)) := {xy | xy.2∈G →
    xy.1∈omegaHeavySubsetEvent (fun i (x:Fin k→ℕ) => x i) (fun i => n*simplexNN p i)
      a E0 eps c0 (omegaHeavyMargin eps c0) (S xy.2)}
  change 1-rho≤(μ.prod ν).real E at hh
  have htransfer := (pilotHistogram_split_law n cp p).measureReal_preimage
    (s:=E) (Set.to_countable E).measurableSet.nullMeasurableSet
  change (pilotHistogramPMF n cp p).toMeasure.real (splitPilotHistogram⁻¹' E)=(μ.prod ν).real E at htransfer
  rw [←htransfer] at hh
  exact hh

/-- Joint good-pilot and heavy enclosure probability, with only rho additional loss. -/
theorem omega_heavy_pilot_joint_concentration {eps c0 rho : ℝ}
    (heps : 0<eps) (hc0 : 0<c0) (hc01 : c0<1) (hrho : 0<rho) (hrho1 : rho<1)
    {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) {a E0 : ℝ} (ha : 3/2≤a)
    (hElow : eps*(a-1)≤E0) (hEhigh : E0≤2*eps*(a-1))
    (S : (Fin k→ℕ)→Finset (Fin k)) (G : Set (Fin k→ℕ))
    (hmean : ∀y∈G,∀i∈S y,omegaHeavyScale eps c0 rho*a≤(n:ℝ)*p.mass i) :
    (finitePoissonPMF (fun i => cp*(n*simplexNN p i))).toMeasure.real G-rho≤
      (pilotHistogramPMF n cp p).toMeasure.real {h |
        (fun i => pilotSelectionCount i h)∈G ∧
        h∈omegaHeavySubsetEvent (fun i => pilotMainCount i) (fun i => n*simplexNN p i)
          a E0 eps c0 (omegaHeavyMargin eps c0) (S (fun i => pilotSelectionCount i h))} := by
  let F : Set (PilotHistogram k) := {h | (fun i => pilotSelectionCount i h)∈G}
  let E : Set (PilotHistogram k) := {h | (fun i => pilotSelectionCount i h)∈G →
    h∈omegaHeavySubsetEvent (fun i => pilotMainCount i) (fun i => n*simplexNN p i)
      a E0 eps c0 (omegaHeavyMargin eps c0) (S (fun i => pilotSelectionCount i h))}
  have hh := omega_heavy_pilot_subset_concentration heps hc0 hc01 hrho hrho1 n cp p ha hElow hEhigh S G hmean
  have hjoint := probability_inter_lower (μ:=(pilotHistogramPMF n cp p).toMeasure)
    (E:=E) (Set.to_countable F).measurableSet hh
  have hF : (pilotHistogramPMF n cp p).toMeasure.real F=
      (finitePoissonPMF (fun i => cp*(n*simplexNN p i))).toMeasure.real G := by
    have hm := (pilotHistogram_split_law n cp p).measureReal_preimage
      (s:=(univ:Set (Fin k→ℕ))×ˢG) (Set.to_countable ((univ:Set (Fin k→ℕ))×ˢG)).measurableSet.nullMeasurableSet
    have hpre : splitPilotHistogram⁻¹' ((univ:Set (Fin k→ℕ))×ˢG)=F := by
      ext h
      simp only [mem_preimage,mem_prod,mem_univ,true_and,F,mem_setOf_eq,splitPilotHistogram]
    rw [hpre] at hm
    apply hm.trans
    simp only [Measure.real,Measure.prod_prod,measure_univ,one_mul]
  rw [hF] at hjoint
  apply hjoint.trans_eq
  congr 1
  ext h
  simp only [mem_inter_iff,E,F,mem_setOf_eq]
  tauto

end Renyi
