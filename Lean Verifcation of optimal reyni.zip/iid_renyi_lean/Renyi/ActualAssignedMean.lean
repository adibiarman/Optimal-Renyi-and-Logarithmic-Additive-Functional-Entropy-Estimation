import Renyi.ActualPowerSumUpper

/-! The deterministic mean with an arbitrary realized heavy aggregate. -/
noncomputable section
open scoped BigOperators
namespace Renyi

def assignedLightPower {k : ℕ} (p : Simplex k) (light : Fin k→Bool) (alpha : ℝ) : ℝ :=
  ∑ i, if light i then (p.mass i)^alpha else 0

def assignedHeavyPower {k : ℕ} (p : Simplex k) (light : Fin k→Bool) (alpha : ℝ) : ℝ :=
  ∑ i, if light i then 0 else (p.mass i)^alpha

def actualLightPolynomialMean {k : ℕ} (p : Simplex k) (light : Fin k→Bool)
    (alpha eps Ch D cb lambda CL cL fL f M : ℝ) : ℝ :=
  ∑ i, if light i then
    (actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).eval (p.mass i) else 0

/-- The realized heavy statistic enters only through its aggregate value. -/
def actualAssignedOracleMean {k : ℕ} (p : Simplex k) (light : Fin k→Bool) (heavy : ℝ)
    (alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d : ℝ) : ℝ :=
  upperRescaling k alpha eps cu u0*
    (actualLightPolynomialMean p light alpha eps Ch D cb lambda CL cL fL f M+heavy)+
      2*actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d

lemma assigned_power_partition {k : ℕ} (p : Simplex k) (light : Fin k→Bool) (alpha : ℝ) :
    powerSum p alpha=assignedLightPower p light alpha+assignedHeavyPower p light alpha := by
  simp only [powerSum,assignedLightPower,assignedHeavyPower,←Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  split_ifs <;> simp

lemma actual_hybrid_mean_partition {k : ℕ} (p : Simplex k) (light : Fin k→Bool)
    (alpha eps Ch D cb lambda CL cL fL f M : ℝ) :
    actualCoupledHybridMean p light alpha eps Ch D cb lambda CL cL fL f M=
      actualLightPolynomialMean p light alpha eps Ch D cb lambda CL cL fL f M+
        Real.exp (-upperE0 k alpha eps Ch/8)*assignedHeavyPower p light alpha := by
  simp only [actualCoupledHybridMean,actualLightPolynomialMean,assignedHeavyPower,
    Finset.mul_sum,←Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  split_ifs <;> simp

/-- The actual light polynomial sum retains the damped lower certificate; no
assumption on a nominal or realized heavy statistic enters this statement. -/
theorem actualCoupledPolynomial_light_sum_lower {eps fL f qL qH M lambda : ℝ}
    (heps : 0<eps) (hfL : 0<fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hM : 1≤M) (hlambda : 0<lambda) (hlambdaC : lambda≤Real.exp (-2*coupledProfileConstant))
    (hqL : Real.exp (-(eps/2))<qL) (hqLf : qL<fL)
    (hqH : Real.exp (-7*(eps/2)/8)<qH) (hqHf : qH<f) :
    ∃ C c : ℝ, 0≤C ∧ 0<c ∧ ∀ (k : ℕ) (alpha Ch D cb CL cL : ℝ),
      0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 →
      0≤Ch → 0<D → 0<cb → 1≤CL → 0<cL → 1≤cb*CL →
      ∀ (p : Simplex k) (light : Fin k→Bool),
        (∀ i, light i=true → p.mass i≤upperB k alpha eps D cb CL cL) →
      Real.exp (-upperE0 k alpha eps Ch)*Real.exp (-C*(fractionalPart alpha*(1-fractionalPart alpha)))*assignedLightPower p light alpha+
        c*Real.exp (-upperE0 k alpha eps Ch)*(∑ i, if light i then if upperA k alpha eps Ch D cb lambda CL cL≤p.mass i then
          (p.mass i)^alpha*min
            ((upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2*(p.mass i/upperB k alpha eps D cb CL cL)) 1 else 0 else 0)≤
        actualLightPolynomialMean p light alpha eps Ch D cb lambda CL cL fL f M+
          (k:ℝ)*100^(upperOrderFloor alpha+1)*(upperA k alpha eps Ch D cb lambda CL cL)^alpha := by
  obtain ⟨C,c,hC,hc,hlower⟩ := actualCoupledPolynomial_global_lower
    heps hfL hfL1 hf hf1 hM hlambda hlambdaC hqL hqLf hqH hqHf
  refine ⟨C,c,hC,hc,?_⟩
  intro k alpha Ch D cb CL cL hk ha hg hg1 hCh hD hcb hCL hcL hcbCL p light hlight
  let a := upperA k alpha eps Ch D cb lambda CL cL
  let b := upperB k alpha eps D cb CL cL
  let N := upperDegree alpha CL cL (rootMultiplier k alpha eps)
  let Q := actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M
  let base := Real.exp (-upperE0 k alpha eps Ch)*Real.exp (-C*(fractionalPart alpha*(1-fractionalPart alpha)))
  let err := 100^(upperOrderFloor alpha+1)*a^alpha
  have ha0 : 0≤a := (upper_actual_count_geometry hk ha hg hg1 heps hCh hD hcb hlambda
    (by linarith only [coupled_capacity_lambda_le_one hlambdaC] : lambda≤4) hCL hcL hcbCL).1.le
  have herr : 0≤err := by dsimp [err]; positivity
  have hbase1 : base≤1 := by
    have h1 : Real.exp (-upperE0 k alpha eps Ch)≤1 := Real.exp_le_one_iff.mpr (by
      have hh := (upper_reserved_interval (k:=k) (by linarith only [ha] : 1<alpha) hg hg1 heps hCh).1
      nlinarith only [hh,heps,ha])
    have h2 : Real.exp (-C*(fractionalPart alpha*(1-fractionalPart alpha)))≤1 :=
      Real.exp_le_one_iff.mpr (by
        have hh := mul_nonneg hC (mul_nonneg hg.le (sub_nonneg.mpr hg1.le))
        nlinarith only [hh])
    exact (mul_le_of_le_one_left (Real.exp_pos _).le h1).trans h2
  have hpoint (i : Fin k) :
      base*(if light i then (p.mass i)^alpha else 0)+
        c*Real.exp (-upperE0 k alpha eps Ch)*(if light i then if a≤p.mass i then
          (p.mass i)^alpha*min ((N:ℝ)^2*(p.mass i/b)) 1 else 0 else 0)≤
        (if light i then Q.eval (p.mass i) else 0)+err := by
    by_cases hl : light i=true
    · by_cases hpa : a≤p.mass i
      · have hi := hlower k alpha Ch D cb CL cL (p.mass i) hk ha hg hg1 hCh hD hcb hCL hcL hcbCL hpa (hlight i hl)
        change (p.mass i)^alpha*(base+c*Real.exp (-upperE0 k alpha eps Ch)*min ((N:ℝ)^2*(p.mass i/b)) 1)≤Q.eval (p.mass i) at hi
        simp only [hl,hpa,ite_true]
        nlinarith only [hi,herr]
      · have hi := actualCoupledPolynomial_below_cutoff_exponential hk ha hg hg1 heps hCh hD hcb hlambda hlambdaC hCL hcL hcbCL
          hfL hfL1 hf.le hf1.le (by linarith only [hM] : 0≤M) (p.nonneg i) (le_of_lt (lt_of_not_ge hpa))
        change |Q.eval (p.mass i)|+(p.mass i)^alpha≤err at hi
        have habs := neg_abs_le (Q.eval (p.mass i))
        have hbp := mul_le_of_le_one_left (Real.rpow_nonneg (p.nonneg i) alpha) hbase1
        simp only [hl,hpa,ite_true,ite_false,mul_zero,add_zero]
        linarith only [hi,habs,hbp]
    · have hl' : light i=false := Bool.eq_false_iff.mpr hl
      simpa only [hl',Bool.false_eq_true,ite_false,mul_zero,zero_add] using herr
  have hsum := Finset.sum_le_sum (fun (i:Fin k) (_hi:i∈Finset.univ) => hpoint i)
  simpa only [assignedLightPower,actualLightPolynomialMean,Finset.sum_add_distrib,
    Finset.mul_sum,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,
    Q,err,a,b,N,base,mul_assoc] using hsum

/-- The light spatial margin before multiplication by its fixed strict-gap constant. -/
def actualLightSpatialMargin {k : ℕ} (p : Simplex k) (light : Fin k→Bool)
    (alpha eps Ch D cb lambda CL cL : ℝ) : ℝ :=
  ∑ i, if light i then if upperA k alpha eps Ch D cb lambda CL cL≤p.mass i then
    (p.mass i)^alpha*min (fractionalPart alpha*(1-fractionalPart alpha)+
      (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2*(p.mass i/upperB k alpha eps D cb CL cL)+
        min ((upperLowResolution alpha:ℝ)^2*(upperA k alpha eps Ch D cb lambda CL cL/p.mass i)) 1) 1 else 0 else 0

lemma actualUpperReserve_partition {k : ℕ} (p : Simplex k) (light : Fin k→Bool)
    (alpha eps Ch D cb lambda CL cL c : ℝ) :
    actualUpperReserve p light alpha eps Ch D cb lambda CL cL c=
      c*actualLightSpatialMargin p light alpha eps Ch D cb lambda CL cL+
        (1-Real.exp (-upperE0 k alpha eps Ch/8))*assignedHeavyPower p light alpha := rfl

/-- A realized heavy aggregate with a fixed upper gap preserves the actual upper
certificate, with that same heavy gap replacing the nominal omega gap. -/
theorem actualAssignedPolynomial_power_sum_upper {eps fL f : ℝ}
    (heps : 0<eps) (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) :
    ∃ M0 c : ℝ, 1≤M0 ∧ 0<c ∧ ∀ (M : ℝ), M0≤M →
      ∀ (k : ℕ) (alpha Ch D cb lambda CL cL heavy cH : ℝ),
        0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 →
        0≤Ch → 0<D → 0<cb → 0<lambda → lambda≤Real.exp (-2*coupledProfileConstant) →
        1≤CL → 0<cL → 1≤cb*CL →
        ∀ (p : Simplex k) (light : Fin k→Bool),
          (∀ i, light i=true → p.mass i≤upperB k alpha eps D cb CL cL) →
          heavy≤(1-cH)*assignedHeavyPower p light alpha →
        actualLightPolynomialMean p light alpha eps Ch D cb lambda CL cL fL f M+heavy+
          c*actualLightSpatialMargin p light alpha eps Ch D cb lambda CL cL+
            cH*assignedHeavyPower p light alpha≤powerSum p alpha+
              (k:ℝ)*100^(upperOrderFloor alpha+1)*(upperA k alpha eps Ch D cb lambda CL cL)^alpha := by
  obtain ⟨M0,c,hM0,hc,hupper⟩ := actualCoupledPolynomial_power_sum_upper heps hfL hfL1 hf hf1
  refine ⟨M0,c,hM0,hc,?_⟩
  intro M hM k alpha Ch D cb lambda CL cL heavy cH hk ha hg hg1 hCh hD hcb hlambda hlambdaC hCL hcL hcbCL p light hlight hheavy
  have hh := hupper M hM k alpha Ch D cb lambda CL cL hk ha hg hg1 hCh hD hcb hlambda hlambdaC hCL hcL hcbCL p light hlight
  rw [actual_hybrid_mean_partition,actualUpperReserve_partition] at hh
  nlinarith only [hh,hheavy]

/-- Only light coordinates below a are lost when the complete forward bonus is
replaced by the light above-cutoff bonus and the heavy power sum. -/
theorem assigned_forward_bonus_cutoff_loss {k N : ℕ} {a b alpha : ℝ}
    (ha : 0≤a) (halpha : 0≤alpha) (p : Simplex k) (light : Fin k→Bool) :
    (∑ i, (p.mass i)^alpha*min ((N:ℝ)^2*(p.mass i/b)) 1)≤
      (∑ i, if light i then if a≤p.mass i then (p.mass i)^alpha*min ((N:ℝ)^2*(p.mass i/b)) 1 else 0 else 0)+
        assignedHeavyPower p light alpha+(k:ℝ)*a^alpha := by
  have hpoint (i : Fin k) : (p.mass i)^alpha*min ((N:ℝ)^2*(p.mass i/b)) 1≤
      (if light i then if a≤p.mass i then (p.mass i)^alpha*min ((N:ℝ)^2*(p.mass i/b)) 1 else 0 else 0)+
        (if light i then 0 else (p.mass i)^alpha)+a^alpha := by
    have haPow := Real.rpow_nonneg ha alpha
    by_cases hl : light i=true
    · by_cases hpa : a≤p.mass i
      · simp only [hl,hpa,ite_true,add_zero]
        exact le_add_of_nonneg_right haPow
      · simp only [hl,hpa,ite_true,ite_false,zero_add]
        exact (mul_le_of_le_one_right (Real.rpow_nonneg (p.nonneg i) _) (min_le_right _ _)).trans
          (Real.rpow_le_rpow (p.nonneg i) (le_of_lt (lt_of_not_ge hpa)) halpha)
    · have hl' : light i=false := Bool.eq_false_iff.mpr hl
      simp only [hl',Bool.false_eq_true,ite_false,zero_add]
      exact (mul_le_of_le_one_right (Real.rpow_nonneg (p.nonneg i) _) (min_le_right _ _)).trans
        (le_add_of_nonneg_right haPow)
  have hsum := Finset.sum_le_sum (fun (i:Fin k) (_hi:i∈Finset.univ) => hpoint i)
  simpa only [assignedHeavyPower,Finset.sum_add_distrib,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] using hsum

end Renyi
