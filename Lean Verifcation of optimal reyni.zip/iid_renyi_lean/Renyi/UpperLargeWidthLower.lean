import Renyi.ActualBiasModel
import Renyi.CorrectedLowerTransfer
import Renyi.UpperDampedReserve
import Renyi.UpperPilotBaseline

/-! The actual corrected mean has the full lower margin outside the compact-width range. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 700000

/-- The final choice of D pays the entire proved cutoff loss with the actual correction. -/
theorem upper_actual_cutoff_error_paid {eps Ch cb lambda CL cL C0 d : ℝ}
    (heps : 0<eps) (hCh : 0≤Ch) (hcb : 0<cb) (hlambda : 0<lambda)
    (hCL : 1≤CL) (hcL : 0<cL) (hC0 : 100≤C0) (hd : 0<d) :
    ∃ D0 : ℝ, 1≤D0 ∧ ∀ (k : ℕ) (alpha D : ℝ),
      0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → D0≤D →
      (k:ℝ)*100^(upperOrderFloor alpha+1)*(upperA k alpha eps Ch D cb lambda CL cL)^alpha≤
        actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d := by
  obtain ⟨D0,hD0,hcut⟩ := upper_cutoff_eventually_small heps hCh hcb hlambda hCL hcL
    (show 0<d/200 by positivity)
  refine ⟨D0,hD0,?_⟩
  intro k alpha D hk ha hg hg1 hD
  have ha1 : 1<alpha := by linarith only [ha]
  have hDpos : 0<D := zero_lt_one.trans_le (hD0.trans hD)
  have hb := upperB_pos hk ha1 hg hg1 hDpos hcb hCL hcL (ε:=eps)
  have hac : 0<upperA k alpha eps Ch D cb lambda CL cL := by
    unfold upperA upperOverlapZ
    have hh : 0<fractionalPart alpha*(1-fractionalPart alpha) := mul_pos hg (sub_pos.mpr hg1)
    have hm : (0:ℝ)<upperOrderFloor alpha := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one (upperOrderFloor_one_le ha1))
    have hN : (0:ℝ)<upperDegree alpha CL cL (rootMultiplier k alpha eps) := by
      exact_mod_cast upperDegree_pos ha1 hCL hcL (one_le_rootMultiplier ha1 hg hg1)
    positivity
  have hkR : (0:ℝ)<k := by exact_mod_cast hk
  have hka : (k:ℝ)*upperA k alpha eps Ch D cb lambda CL cL≤d/200 := by
    have hc := mul_le_mul_of_nonneg_left (hcut k alpha D hk ha1 hg hg1 hD) hkR.le
    have hid : (k:ℝ)*(d/200*((alpha-1)/(alpha*k)))=d/200*((alpha-1)/alpha) := by field_simp
    rw [hid] at hc
    exact hc.trans (mul_le_of_le_one_right (by positivity : 0≤d/200)
      ((div_le_one (by linarith only [ha1] : 0<alpha)).mpr (by linarith)))
  have hh := pilot_below_cutoff_actual_baseline (C:=100) (D:=1) (R:=d/200) (eta:=1)
    hk (by norm_num) hC0 hac ha hd (by norm_num) (by positivity) (by norm_num)
    (by simpa only [div_one] using hka) (by field_simp; norm_num)
  simpa only [actualCutoffBudget,one_mul,mul_assoc] using hh

/-- Full actual lower bias transfer in the large-width case. The root, geometry,
cutoff loss, common scalar rescaling and arbitrary pilot assignment are all discharged. -/
theorem upper_actual_large_width_bias_lower {eps fL f qL qH M lambda : ℝ}
    (heps : 0<eps) (hfL : 0<fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hM : 1≤M) (hlambda : 0<lambda) (hlambdaC : lambda≤Real.exp (-2*coupledProfileConstant))
    (hqL : Real.exp (-(eps/2))<qL) (hqLf : qL<fL)
    (hqH : Real.exp (-7*(eps/2)/8)<qH) (hqHf : qH<f) :
    ∃ C : ℝ, 0≤C ∧ ∀ (Ch cu u0 C0 d cb CL cL : ℝ),
      2*C+2≤Ch → 0≤cu → 0<u0 → cu≤min 1 (eps/4)/2 →
      100≤C0 → 0<d → 0<cb → 1≤CL → 0<cL → 1≤cb*CL →
      ∃ c D0 : ℝ, 0<c ∧ 1≤D0 ∧ ∀ (k : ℕ) (alpha D : ℝ),
        0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → D0≤D →
        4*C*(fractionalPart alpha*(1-fractionalPart alpha))≤2*eps*(alpha-1) →
        ∀ (p : Simplex k) (light : Fin k→Bool),
          (∀ i, light i=true → p.mass i≤upperB k alpha eps D cb CL cL) →
        upperKappa alpha eps*powerSum p alpha+
          c*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d u0≤
        actualCorrectedOracleMean p light alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d := by
  obtain ⟨C,cg,hC,hcg,hmean⟩ := actualCoupledPolynomial_power_sum_lower
    heps hfL hfL1 hf hf1 hM hlambda hlambdaC hqL hqLf hqH hqHf
  refine ⟨C,hC,?_⟩
  intro Ch cu u0 C0 d cb CL cL hCh hcu hu0 hcua hC0 hd hcb hCL hcL hcbCL
  have hCh0 : 0≤Ch := by linarith only [hCh,hC]
  obtain ⟨cbas,hcbas,hbase⟩ := upper_rescaling_damped_baseline heps hC hCh hcu hu0 hcua
  obtain ⟨D0,hD0,hpaid⟩ := upper_actual_cutoff_error_paid heps hCh0 hcb hlambda hCL hcL hC0 hd
  let r0 := (1+cu*u0)⁻¹
  have hr0 : 0<r0 := inv_pos.mpr (by positivity)
  let c := min (1/2:ℝ) (min cbas (r0*cg))
  have hc : 0<c := lt_min (by norm_num) (lt_min hcbas (mul_pos hr0 hcg))
  refine ⟨c,D0,hc,hD0,?_⟩
  intro k alpha D hk ha hg hg1 hD hlarge p light hlight
  have ha1 : 1<alpha := by linarith only [ha]
  have hDpos : 0<D := zero_lt_one.trans_le (hD0.trans hD)
  let a := upperA k alpha eps Ch D cb lambda CL cL
  let b := upperB k alpha eps D cb CL cL
  let N := upperDegree alpha CL cL (rootMultiplier k alpha eps)
  let Bt := ∑ i, if a≤p.mass i then (p.mass i)^alpha*min ((N:ℝ)^2*(p.mass i/b)) 1 else 0
  let err := (k:ℝ)*100^(upperOrderFloor alpha+1)*a^alpha
  have hb : 0<b := upperB_pos hk ha1 hg hg1 hDpos hcb hCL hcL (ε:=eps)
  have ha0 : 0≤a := (upper_actual_count_geometry hk ha hg hg1 heps hCh0 hDpos hcb hlambda
    (by linarith only [coupled_capacity_lambda_le_one hlambdaC] : lambda≤4) hCL hcL hcbCL).1.le
  have herr : 0≤err := by dsimp [err]; positivity
  have hP : 0≤powerSum p alpha := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (p.nonneg i) _)
  have hBt : 0≤Bt := by
    apply Finset.sum_nonneg
    intro i _
    split_ifs
    · exact mul_nonneg (Real.rpow_nonneg (p.nonneg i) _)
        (le_min (mul_nonneg (sq_nonneg _) (div_nonneg (p.nonneg i) hb.le)) (by norm_num))
    · exact le_refl _
  have hbonus := forward_bonus_cutoff_loss (N:=N) ha0 hb (by linarith only [ha] : 0≤alpha) p.mass p.nonneg
  have hpow : (1:ℝ)≤100^(upperOrderFloor alpha+1) := one_le_pow₀ (by norm_num : (1:ℝ)≤100)
  have hlowerr : (k:ℝ)*a^alpha≤err := by
    have hh := mul_le_mul_of_nonneg_right hpow (mul_nonneg (Nat.cast_nonneg k) (Real.rpow_nonneg ha0 alpha))
    dsimp only [err]
    nlinarith only [hh]
  have hB : actualForwardBonus p alpha eps D cb CL cL≤Bt+err := by
    change (∑ i,(p.mass i)^alpha*min ((N:ℝ)^2*(p.mass i/b)) 1)≤Bt+err
    exact hbonus.trans (add_le_add_left hlowerr Bt)
  have hκ : 0≤upperKappa alpha eps := (Real.exp_pos _).le
  have hκ1 : upperKappa alpha eps≤1 := Real.exp_le_one_iff.mpr (by
    nlinarith only [heps,ha1])
  have hk0 : upperKappa alpha eps≤Real.exp (-upperE0 k alpha eps Ch) := by
    have hh := (upper_reserved_interval (k:=k) ha1 hg hg1 heps hCh0).2
    apply Real.exp_le_exp.mpr
    linarith only [hh]
  have hu := (upperU_pos (k:=k) (eps:=eps) ha1 hg hg1 hu0).le
  have hrange := upperRescaling_range (k:=k) (eps:=eps) ha1 hg hg1 hcu hu0
  have hden : 0<1+cu*upperU k alpha eps u0 := by positivity
  have hr : r0≤upperRescaling k alpha eps cu u0 := by
    have hh := add_le_add_left (mul_le_mul_of_nonneg_left
      (show upperU k alpha eps u0≤u0 from min_le_right _ _) hcu) 1
    simpa only [r0,upperRescaling,one_div] using one_div_le_one_div_of_le hden hh
  have hchi : 0≤min (alpha-1) 1 := le_min (by linarith only [ha1]) (by norm_num)
  have hbm := hbase k alpha ha1 hg hg1 hlarge
  have hmean' := hmean k alpha Ch D cb CL cL hk ha hg hg1 hCh0 hDpos hcb hCL hcL hcbCL p light hlight
  change Real.exp (-upperE0 k alpha eps Ch)*Real.exp (-C*(fractionalPart alpha*(1-fractionalPart alpha)))*powerSum p alpha+
    cg*Real.exp (-upperE0 k alpha eps Ch)*Bt≤actualCoupledHybridMean p light alpha eps Ch D cb lambda CL cL fL f M+err at hmean'
  have hpaid' := hpaid k alpha D hk ha hg hg1 hD
  change err≤actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d at hpaid'
  have hh := corrected_lower_margin_transfer hP hBt herr hpaid' hκ hκ1 hk0 hu hr0 hr hrange.2 hcbas hcg
    hchi (min_le_right _ _) (by simpa only [mul_assoc] using hbm) hmean' hB
  simpa only [actualBiasBudget,actualCorrectedOracleMean,c,r0] using hh

end Renyi
