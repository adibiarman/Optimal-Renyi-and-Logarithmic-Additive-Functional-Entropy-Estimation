import Renyi.FingerprintDistance
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-! Real expectations of bounded tests under actual PMF kernels. -/
noncomputable section
open MeasureTheory
namespace Renyi

def pmfExpectation {Ω : Type*} (p : PMF Ω) (t : Ω → ℝ) : ℝ :=
  ∑' x, (p x).toReal * t x

theorem pmfExpectation_nonneg {Ω : Type*} (p : PMF Ω) (t : Ω → ℝ)
    (ht : ∀ x, 0 ≤ t x) : 0 ≤ pmfExpectation p t :=
  tsum_nonneg (fun x => mul_nonneg ENNReal.toReal_nonneg (ht x))

theorem pmfExpectation_le_one {Ω : Type*} (p : PMF Ω) (t : Ω → ℝ)
    (ht0 : ∀ x, 0 ≤ t x) (ht1 : ∀ x, t x ≤ 1) : pmfExpectation p t ≤ 1 := by
  have hp := pmfReal_hasSum p
  have ht := summable_bounded_test _ t hp.summable ht0 ht1
  calc
    _ ≤ ∑' x, (p x).toReal := ht.tsum_le_tsum
      (fun x => mul_le_of_le_one_right ENNReal.toReal_nonneg (ht1 x)) hp.summable
    _ = 1 := hp.tsum_eq

theorem pmf_bind_toReal {Ω Y : Type*} (p : PMF Ω) (K : Ω → PMF Y) (y : Y) :
    ((p.bind K) y).toReal = ∑' x, (p x).toReal * (K x y).toReal := by
  rw [PMF.bind_apply, ENNReal.tsum_toReal_eq]
  · simp_rw [ENNReal.toReal_mul]
  · intro x
    exact ENNReal.mul_ne_top (p.apply_ne_top x) ((K x).apply_ne_top y)

theorem pmf_joint_real_summable {Ω Y : Type*} (p : PMF Ω) (K : Ω → PMF Y) :
    Summable (fun xy : Ω × Y => (p xy.1).toReal * (K xy.1 xy.2).toReal) := by
  apply (summable_prod_of_nonneg (fun _ => mul_nonneg ENNReal.toReal_nonneg ENNReal.toReal_nonneg)).2
  constructor
  · intro x
    exact ((pmfReal_hasSum (K x)).mul_left (p x).toReal).summable
  · simp_rw [tsum_mul_left, (pmfReal_hasSum _).tsum_eq, mul_one]
    exact (pmfReal_hasSum p).summable

/-- The law of total expectation for a bounded randomized test. -/
theorem pmfExpectation_bind {Ω Y : Type*} (p : PMF Ω) (K : Ω → PMF Y)
    (t : Y → ℝ) (ht0 : ∀ y, 0 ≤ t y) (ht1 : ∀ y, t y ≤ 1) :
    pmfExpectation (p.bind K) t = pmfExpectation p (fun x => pmfExpectation (K x) t) := by
  have hj := summable_bounded_test _ (fun xy : Ω × Y => t xy.2)
    (pmf_joint_real_summable p K) (fun xy => ht0 xy.2) (fun xy => ht1 xy.2)
  have hswap : (∑' x, ∑' y, (p x).toReal * (K x y).toReal * t y) =
      ∑' y, ∑' x, (p x).toReal * (K x y).toReal * t y := hj.tsum_comm.symm
  calc
    _ = ∑' y, ∑' x, (p x).toReal * (K x y).toReal * t y := by
      apply tsum_congr
      intro y
      rw [pmf_bind_toReal, tsum_mul_right]
    _ = ∑' x, ∑' y, (p x).toReal * (K x y).toReal * t y := hswap.symm
    _ = _ := by
      apply tsum_congr
      intro x
      simp_rw [mul_assoc]
      exact tsum_mul_left

/-- A bad latent event costs at most its probability for any test valued in [0,1]. -/
theorem pmfExpectation_le_of_good {Ω : Type*} [MeasurableSpace Ω]
    [MeasurableSingletonClass Ω] (p : PMF Ω) (t : Ω → ℝ) (bad : Set Ω)
    {c : ℝ} (hc : 0 ≤ c) (ht0 : ∀ x, 0 ≤ t x) (ht1 : ∀ x, t x ≤ 1)
    (hgood : ∀ x, x ∉ bad → t x ≤ c) :
    pmfExpectation p t ≤ c + p.toMeasure.real bad := by
  classical
  have hpoint (x : Ω) : t x ≤ c + bad.indicator (fun _ => (1 : ℝ)) x := by
    by_cases hx : x ∈ bad
    · simp only [Set.indicator_of_mem hx]
      linarith [ht1 x]
    · simpa only [Set.indicator_of_notMem hx, add_zero] using hgood x hx
  have hsum := ((pmfReal_hasSum p).mul_right c).add (pmf_event_real_hasSum p bad)
  simp only [one_mul] at hsum
  calc
    _ ≤ ∑' x, ((p x).toReal * c + (p x).toReal * bad.indicator (fun _ => (1 : ℝ)) x) :=
      (summable_bounded_test _ t (pmfReal_hasSum p).summable ht0 ht1).tsum_le_tsum
        (fun x => by simpa only [mul_add] using mul_le_mul_of_nonneg_left (hpoint x) ENNReal.toReal_nonneg)
        hsum.summable
    _ = _ := hsum.tsum_eq

end Renyi
