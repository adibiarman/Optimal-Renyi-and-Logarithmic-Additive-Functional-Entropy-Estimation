import Renyi.LowerActualNegativeSecond
import Renyi.LowerDefectScale
import Renyi.LowerMeanExponential
import Renyi.LowerCountBudget

/-! Actual negative-orientation mean and count calibration. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 500000

theorem lower_actual_negative_count_envelopes {τ : Type*} [Fintype τ]
    (p₀ p₁ : FiniteAtomicPrior τ) {k m : ℕ} {s ε : ℝ}
    (hk : 0<k) (hm : 1≤m) (hs : 0<s) (hs1 : s≤1/2) (hε : 0<ε) (hε1 : ε≤1/2)
    (hx : lowerPriorRootCutoff ε≤rootMultiplier k ((m:ℝ)+(1-s)) ε) :
    let α := (m:ℝ)+(1-s)
    let x := rootMultiplier k α ε
    let L := Nat.ceil (10*α*(1+Real.log x))
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let ds : ℝ := ((L-m:ℕ):ℝ)+1
    let dc : ℝ := ((m-1:ℕ):ℝ)+1
    let bs := (ζ/8)/ds^2
    let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
    let a := θ/((1/100)*(L:ℝ)*ac)
    let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
    let us := chebyshevNode (L-m) bs
    let uc := chebyshevNode (m-1) ((1-s)/dc^2)
    let l := normalizedInterpolation uc ac 0 (1-s)
    let t := normalizedInterpolation us a ρ s
    let U := interpolationNodes uc ac
    let V := interpolationNodes us a
    let B := (ac*a)⁻¹
    let Z := tensorNormalizer l t U V ac α
    let Rc := ∑ i,negativeCoeff (l i)
    let Rs := ∑ j,negativeCoeff (t j)
    let D := B^(((m+1:ℕ):ℝ)-1)/Z*(ac^(s-1)/(interpolationNormalizer uc ac 0 (1-s)*interpolationNormalizer us a ρ s))
    0<Z →
    priorMoment p₀ α=B^(α-1)/Z*(Rc+Rs) →
    priorMoment p₁ α=B^(α-1)/Z*(1+Rc*Rs) →
    D≤Real.exp ((20+2/c)*(m+1))/ζ ∧
    priorMoment p₀ α≤(lowerPriorIntensityConstant ε)^(-1/2:ℝ)*Real.exp ((20+2/c)*(m+1))/ζ ∧
    priorMoment p₁ α≤(lowerPriorIntensityConstant ε)^(-1/2:ℝ)*Real.exp ((20+2/c)*(m+1))/ζ := by
  let α := (m : ℝ)+(1-s)
  let x := rootMultiplier k α ε
  let L := Nat.ceil (10*α*(1+Real.log x))
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ds : ℝ := ((L-m : ℕ) : ℝ)+1
  let dc : ℝ := ((m-1 : ℕ) : ℝ)+1
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*(L : ℝ)*ac)
  have hmR : (1 : ℝ) ≤ m := by exact_mod_cast hm
  have hα : 3/2 ≤ α := by dsimp [α]; linarith
  have hα1 : 1 < α := by linarith
  have hα0 : 0 < α := by linarith
  have hγ : fractionalPart α = 1-s :=
    fractionalPart_nat_add_small m (by linarith) (by linarith)
  have hγ₀ : 0 < fractionalPart α := by rw [hγ]; linarith
  have hγ₁ : fractionalPart α < 1 := by rw [hγ]; linarith
  have hnear : s = 1-fractionalPart α := by rw [hγ]; ring
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hx0 : 0 < x := by linarith
  have hlog : 0 ≤ Real.log x := Real.log_nonneg (by linarith)
  have hLlo : 10*α*(1+Real.log x) ≤ (L : ℝ) := Nat.le_ceil _
  have hLm : m+1 ≤ L := by
    have : (m : ℝ)+1 ≤ L := by dsimp [α] at *; nlinarith
    exact_mod_cast this
  have hds : 0 < ds := by dsimp [ds]; positivity
  have hdc : 0 < dc := by dsimp [dc]; positivity
  have hdc_eq : dc = (m : ℝ) := by
    dsimp [dc]
    rw [Nat.cast_sub hm]
    push_cast
    ring
  have hdshi : ds ≤ (L : ℝ)+1 := by
    dsimp [ds]
    exact add_le_add_right (by exact_mod_cast (Nat.sub_le L m)) 1
  have hdim : ds*dc ≤ α*((L : ℝ)+1) := by
    have h1 := mul_le_mul_of_nonneg_right hdshi (by positivity : 0 ≤ dc)
    rw [hdc_eq] at h1
    have h2 := mul_le_mul_of_nonneg_left (show (m : ℝ) ≤ α by dsimp [α]; linarith)
      (show 0 ≤ (L : ℝ)+1 by positivity)
    rw [hdc_eq]
    exact h1.trans (by nlinarith only [h2])
  have hc := lowerPriorCoefficient_bounds hε
  have hc0 : 0<c := hc.1
  have hβ0 : 0 < α-1 := sub_pos.mpr hα1
  have hE : 0 < E := by dsimp [E]; positivity
  have hv : 0 ≤ v := by dsimp [v]; positivity
  have hw : 0 < w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv
  have hcon := lower_actual_principal_constraints_with_perturbation hk hα hε hs hs1 hγ₀ hγ₁
    (Or.inr hnear) hx hds hdc hdim
  dsimp only at hcon
  let bs := (ζ/8)/ds^2
  let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
  change 0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 ∧ ρ ≤ 1 at hcon
  have hmul : 4*ζ*((ds-1)/ds) = 4*ζ*((L-m : ℕ) : ℝ)/(((L-m : ℕ) : ℝ)+1) := by
    dsimp [ds]
    ring
  have hpert : max (((a/bs)^s/κ)*
      Real.exp (4*ζ*((L-m : ℕ) : ℝ)/(((L-m : ℕ) : ℝ)+1))-1) 0 * a / bs ≤ ζ := by
    rw [← hmul]
    exact hcon.2.2.2.1
  let us := chebyshevNode (L-m) bs
  let uc := chebyshevNode (m-1) ((1-s)/dc^2)
  let l := normalizedInterpolation uc ac 0 (1-s)
  let t := normalizedInterpolation us a ρ s
  let U := interpolationNodes uc ac
  let V := interpolationNodes us a
  dsimp only
  intro hZ hA₀ hA₁
  change 0<tensorNormalizer l t U V ac α at hZ
  change priorMoment p₀ α=((ac*a)⁻¹)^(α-1)/tensorNormalizer l t U V ac α*((∑i,negativeCoeff (l i))+(∑i,negativeCoeff (t i))) at hA₀
  change priorMoment p₁ α=((ac*a)⁻¹)^(α-1)/tensorNormalizer l t U V ac α*(1+(∑i,negativeCoeff (l i))*(∑i,negativeCoeff (t i))) at hA₁
  have hns : 0<L-m := by omega
  have hκ0 : 0<κ := Real.exp_pos _
  have hκ1 : κ≤1 := Real.exp_le_one_iff.mpr (by linarith only [hE,hw])
  have hζ0 : 0<ζ := hcon.2.2.2.2.1
  have hζsmall : ζ≤3/5 := by linarith only [hcon.2.2.2.2.2.1]
  have hbs0 : 0<bs := by dsimp [bs]; positivity
  have hactive := active_interpolation_mass_bound (L-m) ζ a s κ hns hζ0 hζsmall hcon.1 hcon.2.1 hs.le hκ0 hκ1 hpert
  dsimp only at hactive
  rw [←hmul] at hactive
  change (∑ i, negativeCoeff (t i))≤κ ∧ 1/2≤t none at hactive
  let bc := (1-s)/dc^2
  have hξ : 0<1-s := by linarith only [hs1]
  have hbc0 : 0<bc := by dsimp [bc]; positivity
  have hdc1 : 1≤dc := by dsimp [dc]; exact le_add_of_nonneg_left (Nat.cast_nonneg _)
  have hbc1 : bc<1 := by dsimp [bc]; apply (div_lt_one (by positivity)).mpr; nlinarith only [hdc1,hs]
  have hzK0 : 0<ζ*κ := mul_pos hζ0 hκ0
  have hzK1 : ζ*κ≤1 := by nlinarith only [mul_le_mul_of_nonneg_left hκ1 hζ0.le,hcon.2.2.2.2.2.1]
  have hac : 0<ac := by dsimp [ac]; positivity
  have hab : ac<bc := by
    have hp := Real.rpow_le_one hzK0.le hzK1 (by positivity : 0≤1/(1-s))
    have he : Real.exp (-5)<1 := Real.exp_lt_one_iff.mpr (by norm_num)
    have hh := mul_le_mul_of_nonneg_left hp (show 0≤Real.exp (-5)*bc by positivity)
    have hh' := mul_lt_mul_of_pos_right he hbc0
    change Real.exp (-5)*bc*(ζ*κ)^(1/(1-s))<bc
    exact (show Real.exp (-5)*bc*(ζ*κ)^(1/(1-s))≤Real.exp (-5)*bc by simpa only [mul_one] using hh).trans_lt (by simpa only [one_mul] using hh')
  have hau (i) : ac<uc i := hab.trans_le (chebyshevNode_bounds (m-1) bc hbc1.le i).1
  have hcancel := low_integer_factor_zero uc (chebyshevNode_injective (m-1) bc hbc1)
    (ρ:=0) (γ:=1-s) hac hau 1 (by norm_num) (by omega) (Or.inr rfl)
  simp only [Nat.cast_one] at hcancel
  have hr : (2:ℝ)≤(m:ℝ)+1 := by linarith only [hmR]
  have hαeq : (m:ℝ)+1-s=α := by dsimp [α]; ring
  have hEupper : E≤(m:ℝ)+1 := by
    have hh := mul_le_mul_of_nonneg_right hε1 (show 0≤2*(α-1) by positivity)
    dsimp only [E]
    dsimp [α] at hh
    nlinarith only [hh,hs]
  have hvupper : v≤1/4 := by
    have hfrac : (α-1)/α≤1 := (div_le_one hα0).mpr (by linarith only)
    have hh := mul_le_mul_of_nonneg_right hfrac (Real.rpow_nonneg hx0.le (-α))
    have hp : x^(-α)≤x^(-1:ℝ) := Real.rpow_le_rpow_of_exponent_le (by linarith only [hx4] : 1≤x) (by linarith only [hα1])
    rw [Real.rpow_neg_one] at hp
    have hi : x⁻¹≤1/4 := by simpa only [one_div] using one_div_le_one_div_of_le (by norm_num : (0:ℝ)<4) hx4
    have hh' : v≤x^(-α) := by simpa only [one_mul] using hh
    exact hh'.trans (hp.trans hi)
  have hwupper : w≤1/2 := by dsimp [w]; nlinarith only [hvupper,sq_nonneg (s-1/2)]
  have hζfloor : c*s/2≤ζ := by
    have hh := lower_target_fractional_floor hc.1 hs hs1 hE hv
    convert hh using 1
    ring
  have hbs1 : bs<1 := by
    apply (div_lt_one (by positivity : (0:ℝ)<ds^2)).mpr
    have hds1 : 1≤ds := by dsimp [ds]; exact le_add_of_nonneg_left (Nat.cast_nonneg _)
    nlinarith only [hcon.2.2.2.2.2.1,hds1]
  have haus (i) : a<us i :=
    (show a<bs by linarith only [hcon.1,hcon.2.1]).trans_le (chebyshevNode_bounds (L-m) bs hbs1.le i).1
  have husp (i) : 0<us i := hcon.1.trans (haus i)
  have hVp (i) : 0<V i := by
    cases i with
    | none => exact hcon.1
    | some i => exact husp i
  have hVlo (i) : a≤V i := by
    cases i with
    | none => exact le_rfl
    | some i => exact (haus i).le
  have hcancel' : (∑ i,l i*U i^((m:ℝ)+1-s-1))=0 := by
    rw [hαeq]
    convert hcancel using 1
  have hZ' : 0<tensorNormalizer l t U V ac ((m:ℝ)+1-s) := by rw [hαeq]; exact hZ
  have hD := complementary_chebyshev_defect_bound (n:=m-1) us hcon.1 hcon.2.2.1 husp hc.1 hs hs1 hζfloor
    (show ζ≤1 by linarith only [hcon.2.2.2.2.2.1]) hE.le hEupper hw.le hwupper hr
    (show ((m-1:ℕ):ℝ)+1≤(m:ℝ)+1 by change dc≤(m:ℝ)+1; rw [hdc_eq]; linarith only) hcancel' hZ'
  dsimp only at hD
  rw [hαeq] at hD
  have hDfinal : _≤Real.exp ((20+2/c)*((m:ℝ)+1))/ζ := hD
  have hcn0 : 0<lowerPriorIntensityConstant ε := Real.exp_pos _
  have hcn1 : lowerPriorIntensityConstant ε≤1 := by
    apply (Real.log_le_log_iff hcn0 zero_lt_one).mp
    rw [Real.log_one]
    have hh := lower_actual_log_sample_bound hε
    have hnonneg : 0≤26/lowerPriorCoefficient ε := by positivity
    exact hh.trans (by linarith only [hnonneg])
  have hcnpow : 1≤(lowerPriorIntensityConstant ε)^(-1/2:ℝ) :=
    Real.one_le_rpow_of_pos_of_le_one_of_nonpos hcn0 hcn1 (by norm_num)
  have hcom := chebyshev_nodes_weighted (m-1) (1-s) (ζ*κ) (by linarith only [hs1]) (by linarith only [hs]) hzK0 hzK1
  change (∑i,negativeCoeff (l i))≤Real.exp (-(1-s))*(ζ*κ) ∧ 1/2≤l none at hcom
  have hRc1 : (∑i,negativeCoeff (l i))≤1 := by
    have he : Real.exp (-(1-s))≤1 := Real.exp_le_one_iff.mpr (by linarith only [hs1])
    exact hcom.1.trans ((mul_le_mul_of_nonneg_right he hzK0.le).trans (by simpa only [one_mul] using hzK1))
  have hRs1 := hactive.1.trans hκ1
  have hmean (p : FiniteAtomicPrior τ) (M : ℝ) (hM : 0≤M) (hM2 : M≤2)
      (hA : priorMoment p α=((ac*a)⁻¹)^(α-1)/tensorNormalizer l t U V ac α*M) :
      priorMoment p α≤(lowerPriorIntensityConstant ε)^(-1/2:ℝ)*Real.exp ((20+2/c)*((m:ℝ)+1))/ζ := by
    have hh := tensor_prior_complementary_mean_shape p t V (m-1) (1-s) (ζ*κ) α a M
      (by linarith only [hs1]) (by linarith only [hs]) hzK0 hzK1 hα1.le hcon.1 hVp hVlo
      (normalizedInterpolation_positive_mass us hcon.1 hcon.2.2.1) hRs1 none rfl
      (hactive.2.trans (le_abs_self _)) hM hM2 hcancel hA
    have hexp := lower_complementary_mean_exponential_envelope hr hc.1 (show c≤1 by linarith only [hc.2]) hEupper hwupper
    have hpow : dc^4≤((m:ℝ)+1)^4 := pow_le_pow_left₀ hdc.le (by rw [hdc_eq]; linarith only) 4
    have hcoef : 128*Real.exp 5*dc^4/κ≤Real.exp ((20+2/c)*((m:ℝ)+1)) :=
      (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hpow (by positivity)) hκ0.le).trans hexp
    calc
      _≤128*Real.exp 5*dc^4/(ζ*κ) := hh
      _=(128*Real.exp 5*dc^4/κ)/ζ := by ring
      _≤Real.exp ((20+2/c)*((m:ℝ)+1))/ζ := div_le_div_of_nonneg_right hcoef hζ0.le
      _≤_ := by
        apply div_le_div_of_nonneg_right _ hζ0.le
        simpa only [one_mul] using mul_le_mul_of_nonneg_right hcnpow (Real.exp_pos _).le
  have hRc0 : 0≤∑i,negativeCoeff (l i) := Finset.sum_nonneg (fun _ _ => le_max_right _ _)
  have hRs0 : 0≤∑i,negativeCoeff (t i) := Finset.sum_nonneg (fun _ _ => le_max_right _ _)
  refine ⟨?_,hmean p₀ _ (add_nonneg hRc0 hRs0) (by linarith only [hRc1,hRs1]) hA₀,
    hmean p₁ _ (by positivity) (by nlinarith only [mul_le_mul hRc1 hRs1 hRs0 zero_le_one]) hA₁⟩
  simpa only [Nat.cast_add,Nat.cast_one] using hDfinal

def lowerNegativeSmallCountConclusion (k m L : ℕ) (s E w c a θ : ℝ) : Prop :=
    let ζ := c * w / (1 - Real.exp (-E))
    let κ := Real.exp (-E - 4 * w)
    let ξ := 1 - s
    let ns := L - m
    let nc := m - 1
    let bs := (ζ / 8) / ((ns : ℝ) + 1) ^ 2
    let bc := ξ / ((nc : ℝ) + 1) ^ 2
    let ac := Real.exp (-5) * bc * (ζ * κ) ^ (1 / ξ)
    let ρ := max (((a / bs) ^ s / κ) *
      Real.exp (4 * ζ * (ns : ℝ) / ((ns : ℝ) + 1)) - 1) 0
    let us := chebyshevNode ns bs
    let uc := chebyshevNode nc bc
    let α := (m:ℝ)+(1-s)
    let l := normalizedInterpolation uc ac 0 (1-s)
    let t := normalizedInterpolation us a ρ s
    let U := interpolationNodes uc ac
    let V := interpolationNodes us a
    let Rc := ∑ i, negativeCoeff (l i)
    let Rs := ∑ j, negativeCoeff (t j)
    let B := (ac*a)⁻¹
    let Z := tensorNormalizer l t U V ac α
    let D := B^(((m+1:ℕ):ℝ)-1)/Z*(ac^(s-1)/(interpolationNormalizer uc ac 0 (1-s)*interpolationNormalizer us a ρ s))
    0<Z ∧ 0<D ∧ ∃ p₀ p₁ : FiniteAtomicPrior
      (Option ((Option (Fin ((m-1)+1))) × (Option (Fin ((L-m)+1))))),
      (∀ i, p₀.value i=0 ∨ (1≤p₀.value i ∧ p₀.value i≤B)) ∧
      (∀ i, p₁.value i=0 ∨ (1≤p₁.value i ∧ p₁.value i≤B)) ∧
      priorMoment p₀ 1=1 ∧ priorMoment p₁ 1=1 ∧
      (∀ j : ℕ, 1≤j → j≤L+1 → j≠m+1 → priorMoment p₁ (j:ℝ)=priorMoment p₀ (j:ℝ)) ∧
      priorMoment p₁ α=B^(α-1)/Z*(1+Rc*Rs) ∧
      priorMoment p₀ α=B^(α-1)/Z*(Rc+Rs) ∧
      Real.log (priorMoment p₁ α/priorMoment p₀ α)=Real.log ((1+Rc*Rs)/(Rc+Rs)) ∧
      (∀ j : ℝ, 0<j → priorMoment p₀ j=B^(j-1)/Z*(∑ ij, tensorNegative l t ij*tensorAtom U V ac ij^(j-α))) ∧
      (∀ j : ℝ, 0<j → priorMoment p₁ j=B^(j-1)/Z*(∑ ij, tensorPositive l t ij*tensorAtom U V ac ij^(j-α))) ∧
      |priorMoment p₁ ((m+1:ℕ):ℝ)-priorMoment p₀ ((m+1:ℕ):ℝ)|≤ρ*D ∧
      (∀ j : ℕ, j≤m+1 → Real.exp (-1)*θ^(m+1)*D/(j.factorial:ℝ)≤poissonMixture p₀.mass p₀.value θ j) ∧
      (∀ j : ℕ, j≤m+1 → Real.exp (-1)*θ^(m+1)*D/(j.factorial:ℝ)≤poissonMixture p₁.mass p₁.value θ j) ∧
      E+w≤Real.log (priorMoment p₁ α/priorMoment p₀ α) ∧ Rs≤κ ∧ Rc≤ζ*κ ∧
      (k:ℝ)*countDistance (poissonMixture p₀.mass p₀.value θ) (poissonMixture p₁.mass p₁.value θ)≤1/32

theorem lower_actual_negative_small_count_priors {k m : ℕ} {s ε : ℝ}
    (hk : 0<k) (hm : 1≤m) (hs : 0<s) (hs1 : s≤1/2) (hε : 0<ε) (hε1 : ε≤1/2)
    (hx : lowerPriorRootCutoff ε≤rootMultiplier k ((m:ℝ)+(1-s)) ε) :
    let α := (m:ℝ)+(1-s)
    let x := rootMultiplier k α ε
    let L := Nat.ceil (10*α*(1+Real.log x))
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let ac := Real.exp (-5)*((1-s)/(((m-1:ℕ):ℝ)+1)^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
    let a := θ/((1/100)*(L:ℝ)*ac)
    lowerNegativeSmallCountConclusion k m L s E w c a θ := by
  let α := (m : ℝ)+(1-s)
  let x := rootMultiplier k α ε
  let L := Nat.ceil (10*α*(1+Real.log x))
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ds : ℝ := ((L-m : ℕ) : ℝ)+1
  let dc : ℝ := ((m-1 : ℕ) : ℝ)+1
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*(L : ℝ)*ac)
  have hmR : (1 : ℝ) ≤ m := by exact_mod_cast hm
  have hα : 3/2 ≤ α := by dsimp [α]; linarith
  have hα1 : 1 < α := by linarith
  have hα0 : 0 < α := by linarith
  have hγ : fractionalPart α = 1-s :=
    fractionalPart_nat_add_small m (by linarith) (by linarith)
  have hγ₀ : 0 < fractionalPart α := by rw [hγ]; linarith
  have hγ₁ : fractionalPart α < 1 := by rw [hγ]; linarith
  have hnear : s = 1-fractionalPart α := by rw [hγ]; ring
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hx0 : 0 < x := by linarith
  have hlog : 0 ≤ Real.log x := Real.log_nonneg (by linarith)
  have hLlo : 10*α*(1+Real.log x) ≤ (L : ℝ) := Nat.le_ceil _
  have hLm : m+1 ≤ L := by
    have : (m : ℝ)+1 ≤ L := by dsimp [α] at *; nlinarith
    exact_mod_cast this
  have hds : 0 < ds := by dsimp [ds]; positivity
  have hdc : 0 < dc := by dsimp [dc]; positivity
  have hdc_eq : dc = (m : ℝ) := by
    dsimp [dc]
    rw [Nat.cast_sub hm]
    push_cast
    ring
  have hdshi : ds ≤ (L : ℝ)+1 := by
    dsimp [ds]
    exact add_le_add_right (by exact_mod_cast (Nat.sub_le L m)) 1
  have hdim : ds*dc ≤ α*((L : ℝ)+1) := by
    have h1 := mul_le_mul_of_nonneg_right hdshi (by positivity : 0 ≤ dc)
    rw [hdc_eq] at h1
    have h2 := mul_le_mul_of_nonneg_left (show (m : ℝ) ≤ α by dsimp [α]; linarith)
      (show 0 ≤ (L : ℝ)+1 by positivity)
    rw [hdc_eq]
    exact h1.trans (by nlinarith only [h2])
  have _hc := lowerPriorCoefficient_bounds hε
  have hβ0 : 0 < α-1 := sub_pos.mpr hα1
  have hE : 0 < E := by dsimp [E]; positivity
  have hv : 0 ≤ v := by dsimp [v]; positivity
  have hw : 0 < w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv
  have hcon := lower_actual_principal_constraints_with_perturbation hk hα hε hs hs1 hγ₀ hγ₁
    (Or.inr hnear) hx hds hdc hdim
  dsimp only at hcon
  let bs := (ζ/8)/ds^2
  let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
  change 0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 ∧ ρ ≤ 1 at hcon
  have hmul : 4*ζ*((ds-1)/ds) = 4*ζ*((L-m : ℕ) : ℝ)/(((L-m : ℕ) : ℝ)+1) := by
    dsimp [ds]
    ring
  have hpert : max (((a/bs)^s/κ)*
      Real.exp (4*ζ*((L-m : ℕ) : ℝ)/(((L-m : ℕ) : ℝ)+1))-1) 0 * a / bs ≤ ζ := by
    rw [← hmul]
    exact hcon.2.2.2.1
  have hθ : 0<θ := by dsimp [θ,lowerPriorIntensityConstant]; positivity
  have hLpos : (0:ℝ)<L := (show 0<10*α*(1+Real.log x) by positivity).trans_le hLlo
  have hζ0 : 0<ζ := hcon.2.2.2.2.1
  have hξ0 : 0<1-s := by linarith
  have hac : 0<ac := by dsimp [ac,κ]; positivity
  have hact := lower_actual_principal_constraints_with_activation hk hα hε hs hs1 hγ₀ hγ₁
    (Or.inr hnear) hx hds hdc hdim
  dsimp only at hact
  have hdata := lower_actual_negative_count_priors hk hm hs hs1 hε hx
  dsimp only [lowerNegativeCountConclusion] at hdata
  rw [←hmul] at hdata
  obtain ⟨hZ,hD,p₀,p₁,hp₀,hp₁,hm₀,hm₁,hmatch,hA₁,hA₀,hlogA,hmom₀,hmom₁,hdef,hq₀,hq₁,hgap,hRs,hRc⟩ := hdata
  have henvelopes := lower_actual_negative_count_envelopes p₀ p₁ hk hm hs hs1 hε hε1 hx hZ hA₀ hA₁
  let B := (ac*a)⁻¹
  have hBdef : B=(1/100)*(L:ℝ)/θ := by dsimp [B,a]; field_simp
  have hv₀ (i) : 0≤p₀.value i := (hp₀ i).elim (fun h => h ▸ le_rfl) (fun h => le_trans zero_le_one h.1)
  have hv₁ (i) : 0≤p₁.value i := (hp₁ i).elim (fun h => h ▸ le_rfl) (fun h => le_trans zero_le_one h.1)
  have hb₀ (i) : p₀.value i≤B := (hp₀ i).elim (fun h => h ▸ le_of_lt (by dsimp [B]; positivity)) (fun h => h.2)
  have hb₁ (i) : p₁.value i≤B := (hp₁ i).elim (fun h => h ▸ le_of_lt (by dsimp [B]; positivity)) (fun h => h.2)
  have hcount := lower_actual_small_count_budget p₀ p₁ hk (show 2≤m+1 by omega) hα hε hε1 hs hs1 hγ₀ hγ₁
    (Or.inr hnear) (Or.inr (show α-((m+1:ℕ):ℝ)= -s by dsimp [α]; push_cast; ring))
    (show 1<rootMultiplier k α ε by change 1<x; linarith only [hx4]) hLlo rfl hBdef rfl
    hcon.2.2.1 hD hact.2.2.2.2.2.2.2.1 hact.2.2.2.2.2.2.2.2
    (by simpa only [Nat.cast_add,Nat.cast_one] using henvelopes.1)
    (by simpa only [Nat.cast_add,Nat.cast_one] using henvelopes.2.1)
    (by simpa only [Nat.cast_add,Nat.cast_one] using henvelopes.2.2)
    hv₀ hv₁ hb₀ hb₁ hmatch hdef
    (fun j _ hj => hq₀ j hj) (fun j _ hj => hq₁ j hj)
  dsimp only [lowerNegativeSmallCountConclusion]
  rw [←hmul]
  exact ⟨hZ,hD,p₀,p₁,hp₀,hp₁,hm₀,hm₁,hmatch,hA₁,hA₀,hlogA,hmom₀,hmom₁,hdef,hq₀,hq₁,hgap,hRs,hRc,hcount⟩

end Renyi
