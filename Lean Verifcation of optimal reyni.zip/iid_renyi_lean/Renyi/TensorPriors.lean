import Renyi.InterpolationComplete
import Renyi.FinitePriors
import Mathlib.Probability.ProbabilityMassFunction.Integrals

/-!
# Positive tensor priors on finite supports

All parity masses and reweighted probabilities are explicitly constructed.
Finite laws may have coinciding scalar atom values; the probability law is
their pushforward, so no cancellation of overlapping images is required.
-/

noncomputable section
open scoped BigOperators
namespace Renyi

def positiveCoeff (x : ℝ) : ℝ := max x 0
def negativeCoeff (x : ℝ) : ℝ := max (-x) 0

theorem positive_sub_negative (x : ℝ) : positiveCoeff x - negativeCoeff x = x := by
  by_cases hx : 0 ≤ x
  · simp [positiveCoeff, negativeCoeff, max_eq_left hx, max_eq_right (neg_nonpos.mpr hx)]
  · have hx' : x ≤ 0 := le_of_not_ge hx
    simp [positiveCoeff, negativeCoeff, max_eq_right hx', max_eq_left (neg_nonneg.mpr hx')]

def tensorPositive {ι κ : Type*} (l : ι → ℝ) (r : κ → ℝ) (ij : ι × κ) : ℝ :=
  positiveCoeff (l ij.1) * positiveCoeff (r ij.2) +
    negativeCoeff (l ij.1) * negativeCoeff (r ij.2)

def tensorNegative {ι κ : Type*} (l : ι → ℝ) (r : κ → ℝ) (ij : ι × κ) : ℝ :=
  positiveCoeff (l ij.1) * negativeCoeff (r ij.2) +
    negativeCoeff (l ij.1) * positiveCoeff (r ij.2)

theorem tensorPositive_nonneg {ι κ : Type*} (l : ι → ℝ) (r : κ → ℝ) (ij : ι × κ) :
    0 ≤ tensorPositive l r ij := by
  unfold tensorPositive positiveCoeff negativeCoeff
  positivity

theorem tensorNegative_nonneg {ι κ : Type*} (l : ι → ℝ) (r : κ → ℝ) (ij : ι × κ) :
    0 ≤ tensorNegative l r ij := by
  unfold tensorNegative positiveCoeff negativeCoeff
  positivity

theorem tensor_parity_difference {ι κ : Type*} (l : ι → ℝ) (r : κ → ℝ) (ij : ι × κ) :
    tensorPositive l r ij - tensorNegative l r ij = l ij.1 * r ij.2 := by
  unfold tensorPositive tensorNegative
  calc
    _ = (positiveCoeff (l ij.1) - negativeCoeff (l ij.1)) *
        (positiveCoeff (r ij.2) - negativeCoeff (r ij.2)) := by ring
    _ = _ := by rw [positive_sub_negative, positive_sub_negative]

theorem finite_tensor_factor {ι κ : Type*} [Fintype ι] [Fintype κ]
    (f : ι → ℝ) (g : κ → ℝ) :
    (∑ ij : ι × κ, f ij.1 * g ij.2) = (∑ i, f i) * (∑ j, g j) := by
  simp only [Fintype.sum_prod_type, ← Finset.mul_sum, ← Finset.sum_mul]

theorem tensorPositive_mass {ι κ : Type*} [Fintype ι] [Fintype κ]
    (l : ι → ℝ) (r : κ → ℝ) {Rl Rr : ℝ}
    (hl : ∑ i, positiveCoeff (l i) = 1) (hr : ∑ j, positiveCoeff (r j) = 1)
    (hnl : ∑ i, negativeCoeff (l i) = Rl) (hnr : ∑ j, negativeCoeff (r j) = Rr) :
    ∑ ij, tensorPositive l r ij = 1 + Rl * Rr := by
  unfold tensorPositive
  rw [Finset.sum_add_distrib,
    finite_tensor_factor (fun i => positiveCoeff (l i)) (fun j => positiveCoeff (r j)),
    finite_tensor_factor (fun i => negativeCoeff (l i)) (fun j => negativeCoeff (r j)),
    hl, hr, hnl, hnr]
  ring

theorem tensorNegative_mass {ι κ : Type*} [Fintype ι] [Fintype κ]
    (l : ι → ℝ) (r : κ → ℝ) {Rl Rr : ℝ}
    (hl : ∑ i, positiveCoeff (l i) = 1) (hr : ∑ j, positiveCoeff (r j) = 1)
    (hnl : ∑ i, negativeCoeff (l i) = Rl) (hnr : ∑ j, negativeCoeff (r j) = Rr) :
    ∑ ij, tensorNegative l r ij = Rl + Rr := by
  unfold tensorNegative
  rw [Finset.sum_add_distrib,
    finite_tensor_factor (fun i => positiveCoeff (l i)) (fun j => negativeCoeff (r j)),
    finite_tensor_factor (fun i => negativeCoeff (l i)) (fun j => positiveCoeff (r j)),
    hl, hr, hnl, hnr]
  ring

def tensorAtom {ι κ : Type*} (u : ι → ℝ) (w : κ → ℝ) (a : ℝ) (ij : ι × κ) : ℝ :=
  a * w ij.2 / u ij.1

theorem tensorAtom_pos {ι κ : Type*} (u : ι → ℝ) (w : κ → ℝ) {a : ℝ}
    (ha : 0 < a) (hu : ∀ i, 0 < u i) (hw : ∀ j, 0 < w j) (ij : ι × κ) :
    0 < tensorAtom u w a ij := div_pos (mul_pos ha (hw _)) (hu _)

theorem tensorAtom_power {ι κ : Type*} (u : ι → ℝ) (w : κ → ℝ) {a : ℝ}
    (ha : 0 < a) (hu : ∀ i, 0 < u i) (hw : ∀ j, 0 < w j) (t : ℝ) (ij : ι × κ) :
    tensorAtom u w a ij ^ t = (u ij.1 / a) ^ (-t) * w ij.2 ^ t := by
  have hz : tensorAtom u w a ij = (u ij.1 / a)⁻¹ * w ij.2 := by
    unfold tensorAtom
    field_simp
  rw [hz, Real.mul_rpow (inv_pos.mpr (div_pos (hu _) ha)).le (hw _).le,
    ← Real.rpow_neg_eq_inv_rpow]

/-- The parity difference factors into the two signed power moments. -/
theorem tensor_power_difference {ι κ : Type*} [Fintype ι] [Fintype κ]
    (l : ι → ℝ) (r : κ → ℝ) (u : ι → ℝ) (w : κ → ℝ) {a : ℝ}
    (ha : 0 < a) (hu : ∀ i, 0 < u i) (hw : ∀ j, 0 < w j) (t : ℝ) :
    (∑ ij, tensorPositive l r ij * tensorAtom u w a ij ^ t) -
      (∑ ij, tensorNegative l r ij * tensorAtom u w a ij ^ t) =
      (∑ i, l i * (u i / a) ^ (-t)) * (∑ j, r j * w j ^ t) := by
  rw [← Finset.sum_sub_distrib]
  calc
    (∑ ij, (tensorPositive l r ij * tensorAtom u w a ij ^ t -
        tensorNegative l r ij * tensorAtom u w a ij ^ t)) =
        ∑ ij : ι × κ, (l ij.1 * (u ij.1 / a) ^ (-t)) * (r ij.2 * w ij.2 ^ t) := by
          apply Finset.sum_congr rfl
          intro ij _
          rw [← sub_mul, tensor_parity_difference, tensorAtom_power u w ha hu hw]
          ring
    _ = _ := finite_tensor_factor (fun i => l i * (u i / a) ^ (-t)) (fun j => r j * w j ^ t)

/-- The paper's mean-annihilation condition gives the same normalizer on both sides. -/
theorem tensor_common_normalizer {ι κ : Type*} [Fintype ι] [Fintype κ]
    (l : ι → ℝ) (r : κ → ℝ) (u : ι → ℝ) (w : κ → ℝ) {a α : ℝ}
    (ha : 0 < a) (hu : ∀ i, 0 < u i) (hw : ∀ j, 0 < w j)
    (hmean : (∑ i, l i * u i ^ (α - 1)) * (∑ j, r j * w j ^ (1 - α)) = 0) :
    (∑ ij, tensorPositive l r ij * tensorAtom u w a ij ^ (1 - α)) =
      (∑ ij, tensorNegative l r ij * tensorAtom u w a ij ^ (1 - α)) := by
  have h := tensor_power_difference l r u w ha hu hw (1 - α)
  have he : -(1 - α) = α - 1 := by ring
  rw [he] at h
  have hfactor : (∑ i, l i * (u i / a) ^ (α - 1)) =
      (∑ i, l i * u i ^ (α - 1)) / a ^ (α - 1) := by
    rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro i _
    rw [Real.div_rpow (hu _).le ha.le]
    ring
  rw [hfactor] at h
  have hzero : ((∑ i, l i * u i ^ (α - 1)) / a ^ (α - 1)) *
      (∑ j, r j * w j ^ (1 - α)) = 0 := by
    rw [div_mul_eq_mul_div, hmean, zero_div]
  rw [hzero] at h
  exact sub_eq_zero.mp h

/-- A finite probability law with a real-valued random variable at each atom. -/
structure FiniteAtomicPrior (ι : Type*) [Fintype ι] where
  mass : ι → ℝ
  value : ι → ℝ
  mass_nonneg : ∀ i, 0 ≤ mass i
  mass_sum : ∑ i, mass i = 1

def priorMoment {ι : Type*} [Fintype ι] (p : FiniteAtomicPrior ι) (j : ℝ) : ℝ :=
  ∑ i, p.mass i * p.value i ^ j

/-- The constructed coefficients define a Mathlib probability mass function. -/
def FiniteAtomicPrior.toPMF {ι : Type*} [Fintype ι] (p : FiniteAtomicPrior ι) : PMF ι :=
  PMF.ofFintype (fun i => ENNReal.ofReal (p.mass i)) (by
    rw [← ENNReal.ofReal_sum_of_nonneg (fun i _ => p.mass_nonneg i), p.mass_sum]
    norm_num)

/-- The finite moment notation equals expectation on the actual probability space. -/
theorem priorMoment_eq_integral {ι : Type*} [Fintype ι] [MeasurableSpace ι]
    [MeasurableSingletonClass ι] (p : FiniteAtomicPrior ι) (j : ℝ) :
    priorMoment p j = ∫ i, p.value i ^ j ∂p.toPMF.toMeasure := by
  rw [PMF.integral_eq_sum]
  unfold priorMoment
  apply Finset.sum_congr rfl
  intro i _
  simp [FiniteAtomicPrior.toPMF, ENNReal.toReal_ofReal (p.mass_nonneg i)]

/-- Completion at zero on a general finite index type. -/
def completeFinitePrior {ι : Type*} [Fintype ι] (w v : ι → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hv : ∀ i, 1 ≤ v i)
    (hmean : ∑ i, w i * v i = 1) : FiniteAtomicPrior (Option ι) where
  mass := fun i => i.elim (1 - ∑ j, w j) w
  value := fun i => i.elim 0 v
  mass_nonneg := by
    intro i
    cases i with
    | none =>
      have h := mass_le_first_moment w v hw hv
      change 0 ≤ 1 - ∑ j, w j
      linarith
    | some i => exact hw i
  mass_sum := by simp [Fintype.sum_option]

theorem completeFinitePrior_moment {ι : Type*} [Fintype ι] (w v : ι → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hv : ∀ i, 1 ≤ v i)
    (hmean : ∑ i, w i * v i = 1) {j : ℝ} (hj : 0 < j) :
    priorMoment (completeFinitePrior w v hw hv hmean) j = ∑ i, w i * v i ^ j := by
  simp [priorMoment, completeFinitePrior, Fintype.sum_option,
    Real.zero_rpow (ne_of_gt hj)]

/-- The general power moment of the reweighted positive measure. -/
theorem reweighted_power_moment {ι : Type*} [Fintype ι] (μ z : ι → ℝ)
    {B Z α j : ℝ} (hB : 0 < B) (hZ : 0 < Z) (hz : ∀ i, 0 < z i) :
    (∑ i, reweightedMass μ z B Z α i * (B * z i) ^ j) =
      B ^ (j - 1) / Z * (∑ i, μ i * z i ^ (j - α)) := by
  have hterm (i : ι) : reweightedMass μ z B Z α i * (B * z i) ^ j =
      (B ^ (j - 1) / Z) * (μ i * z i ^ (j - α)) := by
    have hpz : z i ^ (-α) * z i ^ j = z i ^ (j - α) := by
      rw [← Real.rpow_add (hz i)]
      congr 1
      ring
    have hpB : B ^ (j - 1) = B ^ j / B := Real.rpow_sub_one (ne_of_gt hB) j
    unfold reweightedMass
    calc
      μ i / (B * Z) * z i ^ (-α) * (B * z i) ^ j =
          (B ^ j / B) / Z * (μ i * (z i ^ (-α) * z i ^ j)) := by
            rw [Real.mul_rpow hB.le (hz i).le]
            field_simp
      _ = _ := by rw [← hpB, hpz]
  simp_rw [hterm]
  rw [← Finset.mul_sum]

def reweightedPrior {ι : Type*} [Fintype ι] (μ z : ι → ℝ) (B Z α : ℝ)
    (hμ : ∀ i, 0 ≤ μ i) (hB : 0 < B) (hZ : 0 < Z) (hz : ∀ i, 0 < z i)
    (hv : ∀ i, 1 ≤ B * z i) (hZdef : Z = ∑ i, μ i * z i ^ (1 - α)) :
    FiniteAtomicPrior (Option ι) :=
  completeFinitePrior (reweightedMass μ z B Z α) (fun i => B * z i)
    (reweighted_nonneg μ z B Z α hμ hB hZ hz) hv
    (reweighted_mean μ z B Z α hB hZ hz hZdef)

theorem reweightedPrior_mean {ι : Type*} [Fintype ι] (μ z : ι → ℝ) (B Z α : ℝ)
    (hμ : ∀ i, 0 ≤ μ i) (hB : 0 < B) (hZ : 0 < Z) (hz : ∀ i, 0 < z i)
    (hv : ∀ i, 1 ≤ B * z i) (hZdef : Z = ∑ i, μ i * z i ^ (1 - α)) :
    priorMoment (reweightedPrior μ z B Z α hμ hB hZ hz hv hZdef) 1 = 1 := by
  unfold reweightedPrior
  rw [completeFinitePrior_moment _ _ _ _ _ (by norm_num)]
  simpa only [Real.rpow_one] using reweighted_mean μ z B Z α hB hZ hz hZdef

theorem reweightedPrior_power_moment {ι : Type*} [Fintype ι] (μ z : ι → ℝ)
    (B Z α : ℝ) (hμ : ∀ i, 0 ≤ μ i) (hB : 0 < B) (hZ : 0 < Z)
    (hz : ∀ i, 0 < z i) (hv : ∀ i, 1 ≤ B * z i)
    (hZdef : Z = ∑ i, μ i * z i ^ (1 - α)) {j : ℝ} (hj : 0 < j) :
    priorMoment (reweightedPrior μ z B Z α hμ hB hZ hz hv hZdef) j =
      B ^ (j - 1) / Z * (∑ i, μ i * z i ^ (j - α)) := by
  unfold reweightedPrior
  rw [completeFinitePrior_moment _ _ _ _ _ hj]
  exact reweighted_power_moment μ z hB hZ hz

theorem reweightedPrior_support {ι : Type*} [Fintype ι] (μ z : ι → ℝ) (B Z α : ℝ)
    (hμ : ∀ i, 0 ≤ μ i) (hB : 0 < B) (hZ : 0 < Z) (hz : ∀ i, 0 < z i)
    (hv : ∀ i, 1 ≤ B * z i) (hZdef : Z = ∑ i, μ i * z i ^ (1 - α))
    (hz1 : ∀ i, z i ≤ 1) :
    ∀ i, (reweightedPrior μ z B Z α hμ hB hZ hz hv hZdef).value i = 0 ∨
      (1 ≤ (reweightedPrior μ z B Z α hμ hB hZ hz hv hZdef).value i ∧
       (reweightedPrior μ z B Z α hμ hB hZ hz hv hZdef).value i ≤ B) := by
  intro i
  cases i with
  | none => exact Or.inl rfl
  | some i =>
    apply Or.inr
    refine ⟨hv i, ?_⟩
    change B * z i ≤ B
    simpa only [mul_one] using mul_le_mul_of_nonneg_left (hz1 i) hB.le

theorem tensorAtom_support {ι κ : Type*} (u : ι → ℝ) (w : κ → ℝ) {a b : ℝ}
    (ha : 0 < a) (hb : 0 < b) (hua : ∀ i, a ≤ u i) (hu1 : ∀ i, u i ≤ 1)
    (hwb : ∀ j, b ≤ w j) (hw1 : ∀ j, w j ≤ 1) (ij : ι × κ) :
    0 < tensorAtom u w a ij ∧ tensorAtom u w a ij ≤ 1 ∧
      1 ≤ (a * b)⁻¹ * tensorAtom u w a ij := by
  have hu : ∀ i, 0 < u i := fun i => ha.trans_le (hua i)
  have hw : ∀ j, 0 < w j := fun j => hb.trans_le (hwb j)
  refine ⟨tensorAtom_pos u w ha hu hw ij, ?_, ?_⟩
  · change a * w ij.2 / u ij.1 ≤ 1
    apply (div_le_iff₀ (hu _)).2
    nlinarith [hua ij.1, mul_le_mul_of_nonneg_left (hw1 ij.2) ha.le]
  · have heq : (a * b)⁻¹ * tensorAtom u w a ij = w ij.2 / (b * u ij.1) := by
      unfold tensorAtom
      field_simp
    rw [heq]
    apply (le_div_iff₀ (mul_pos hb (hu _))).2
    nlinarith [hwb ij.2, mul_le_mul_of_nonneg_left (hu1 ij.1) hb.le]

theorem positive_weighted_sum {ι : Type*} [Fintype ι] (μ f : ι → ℝ)
    (hμ : ∀ i, 0 ≤ μ i) (hf : ∀ i, 0 < f i) (hμsum : 0 < ∑ i, μ i) :
    0 < ∑ i, μ i * f i := by
  rcases (Finset.sum_pos_iff_of_nonneg (fun i _ => hμ i)).mp hμsum with ⟨i, hi, hpos⟩
  apply (Finset.sum_pos_iff_of_nonneg (fun i _ => mul_nonneg (hμ i) (hf i).le)).2
  exact ⟨i, hi, mul_pos hpos (hf i)⟩

def tensorNormalizer {ι κ : Type*} [Fintype ι] [Fintype κ]
    (l : ι → ℝ) (r : κ → ℝ) (u : ι → ℝ) (w : κ → ℝ) (a α : ℝ) : ℝ :=
  ∑ ij, tensorNegative l r ij * tensorAtom u w a ij ^ (1 - α)

theorem tensorNormalizer_pos {ι κ : Type*} [Fintype ι] [Fintype κ]
    (l : ι → ℝ) (r : κ → ℝ) (u : ι → ℝ) (w : κ → ℝ) {a α Rl Rr : ℝ}
    (ha : 0 < a) (hu : ∀ i, 0 < u i) (hw : ∀ j, 0 < w j)
    (hl : ∑ i, positiveCoeff (l i) = 1) (hr : ∑ j, positiveCoeff (r j) = 1)
    (hnl : ∑ i, negativeCoeff (l i) = Rl) (hnr : ∑ j, negativeCoeff (r j) = Rr)
    (hR : 0 < Rl + Rr) : 0 < tensorNormalizer l r u w a α := by
  apply positive_weighted_sum (tensorNegative l r) (fun ij => tensorAtom u w a ij ^ (1 - α))
    (tensorNegative_nonneg l r) (fun ij => Real.rpow_pos_of_pos (tensorAtom_pos u w ha hu hw ij) _)
  rw [tensorNegative_mass l r hl hr hnl hnr]
  exact hR

/-- The full positive-prior construction on finite supports.

Both probability laws are explicitly constructed from the parity tensors.
No resulting moment identity, probability normalization, or positivity is
assumed. The only signed-moment condition is the source lemma's stated
mean-annihilation condition.
-/
theorem tensor_priors {ι κ : Type*} [Fintype ι] [Fintype κ]
    (l : ι → ℝ) (r : κ → ℝ) (u : ι → ℝ) (w : κ → ℝ) {a b α Rl Rr : ℝ}
    (hα : 1 < α) (ha : 0 < a) (hb : 0 < b)
    (hua : ∀ i, a ≤ u i) (hu1 : ∀ i, u i ≤ 1)
    (hwb : ∀ j, b ≤ w j) (hw1 : ∀ j, w j ≤ 1)
    (hl : ∑ i, positiveCoeff (l i) = 1) (hr : ∑ j, positiveCoeff (r j) = 1)
    (hnl : ∑ i, negativeCoeff (l i) = Rl) (hnr : ∑ j, negativeCoeff (r j) = Rr)
    (hR : 0 < Rl + Rr)
    (hmean : (∑ i, l i * u i ^ (α - 1)) * (∑ j, r j * w j ^ (1 - α)) = 0) :
    let B := (a * b)⁻¹
    let Z := tensorNormalizer l r u w a α
    0 < Z ∧ ∃ p₀ p₁ : FiniteAtomicPrior (Option (ι × κ)),
      (∀ i, p₀.value i = 0 ∨ (1 ≤ p₀.value i ∧ p₀.value i ≤ B)) ∧
      (∀ i, p₁.value i = 0 ∨ (1 ≤ p₁.value i ∧ p₁.value i ≤ B)) ∧
      priorMoment p₀ 1 = 1 ∧ priorMoment p₁ 1 = 1 ∧
      (∀ j : ℝ, 0 < j →
        priorMoment p₁ j - priorMoment p₀ j =
          B ^ (j - 1) / Z *
            ((∑ i, l i * (u i / a) ^ (α - j)) * (∑ t, r t * w t ^ (j - α)))) ∧
      priorMoment p₁ α = B ^ (α - 1) / Z * (1 + Rl * Rr) ∧
      priorMoment p₀ α = B ^ (α - 1) / Z * (Rl + Rr) ∧
      Real.log (priorMoment p₁ α / priorMoment p₀ α) =
        Real.log ((1 + Rl * Rr) / (Rl + Rr)) := by
  let B := (a * b)⁻¹
  let Z := tensorNormalizer l r u w a α
  let z := tensorAtom u w a
  have hB : 0 < B := inv_pos.mpr (mul_pos ha hb)
  have hu : ∀ i, 0 < u i := fun i => ha.trans_le (hua i)
  have hw : ∀ j, 0 < w j := fun j => hb.trans_le (hwb j)
  have hs := tensorAtom_support u w ha hb hua hu1 hwb hw1
  have hz : ∀ ij, 0 < z ij := fun ij => (hs ij).1
  have hz1 : ∀ ij, z ij ≤ 1 := fun ij => (hs ij).2.1
  have hv : ∀ ij, 1 ≤ B * z ij := fun ij => (hs ij).2.2
  have hZ : 0 < Z := tensorNormalizer_pos l r u w ha hu hw hl hr hnl hnr hR
  have hZ0 : Z = ∑ ij, tensorNegative l r ij * z ij ^ (1 - α) := rfl
  have hZ1 : Z = ∑ ij, tensorPositive l r ij * z ij ^ (1 - α) :=
    (tensor_common_normalizer l r u w ha hu hw hmean).symm
  let p₀ := reweightedPrior (tensorNegative l r) z B Z α
    (tensorNegative_nonneg l r) hB hZ hz hv hZ0
  let p₁ := reweightedPrior (tensorPositive l r) z B Z α
    (tensorPositive_nonneg l r) hB hZ hz hv hZ1
  have hm0 (j : ℝ) (hj : 0 < j) : priorMoment p₀ j =
      B ^ (j - 1) / Z * (∑ ij, tensorNegative l r ij * z ij ^ (j - α)) :=
    reweightedPrior_power_moment _ _ _ _ _ _ _ _ _ _ _ hj
  have hm1 (j : ℝ) (hj : 0 < j) : priorMoment p₁ j =
      B ^ (j - 1) / Z * (∑ ij, tensorPositive l r ij * z ij ^ (j - α)) :=
    reweightedPrior_power_moment _ _ _ _ _ _ _ _ _ _ _ hj
  have hαpos : 0 < α := by linarith
  have hA0 : priorMoment p₀ α = B ^ (α - 1) / Z * (Rl + Rr) := by
    rw [hm0 α hαpos]
    simp only [sub_self, Real.rpow_zero, mul_one]
    rw [tensorNegative_mass l r hl hr hnl hnr]
  have hA1 : priorMoment p₁ α = B ^ (α - 1) / Z * (1 + Rl * Rr) := by
    rw [hm1 α hαpos]
    simp only [sub_self, Real.rpow_zero, mul_one]
    rw [tensorPositive_mass l r hl hr hnl hnr]
  refine ⟨hZ, p₀, p₁,
    reweightedPrior_support _ _ _ _ _ _ _ _ _ _ _ hz1,
    reweightedPrior_support _ _ _ _ _ _ _ _ _ _ _ hz1,
    reweightedPrior_mean _ _ _ _ _ _ _ _ _ _ _,
    reweightedPrior_mean _ _ _ _ _ _ _ _ _ _ _, ?_, hA1, hA0, ?_⟩
  · intro j hj
    rw [hm1 j hj, hm0 j hj, ← mul_sub]
    have hdiff := tensor_power_difference l r u w ha hu hw (j - α)
    have he : -(j - α) = α - j := by ring
    rw [he] at hdiff
    rw [hdiff]
  · rw [hA1, hA0, parity_ratio hB (ne_of_gt hZ) (ne_of_gt hR)]

/-- A zero shifted degree is canceled exactly when its perturbation is zero. -/
theorem interpolation_shift_moment_zero {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) {a ρ e : ℝ} (ha : 0 < a) (hau : ∀ i, a < u i)
    (j : ℕ) (hjn : j ≤ n) (hjzero : j = 0 → ρ = 0) :
    (∑ i, normalizedInterpolation u a ρ e i *
      interpolationNodes u a i ^ (e + (j : ℝ))) = 0 := by
  by_cases hj : j = 0
  · subst j
    have hρ := hjzero rfl
    simp only [Nat.cast_zero, add_zero]
    rw [normalizedInterpolation_lowest_moment u hu ha hau, hρ, zero_mul, zero_div]
  · exact normalizedInterpolation_moment_cancellation u hu ha hau j (by omega) hjn

/-- The low interpolation factor handles degrees below or at the integer part. -/
theorem low_integer_factor_zero {m : ℕ} (u : Fin ((m - 1) + 1) → ℝ)
    (hu : Function.Injective u) {a ρ γ : ℝ} (ha : 0 < a) (hau : ∀ i, a < u i)
    (j : ℕ) (hj1 : 1 ≤ j) (hjm : j ≤ m) (hdefect : j ≠ m ∨ ρ = 0) :
    (∑ i, normalizedInterpolation u a ρ γ i *
      interpolationNodes u a i ^ ((m : ℝ) + γ - (j : ℝ))) = 0 := by
  have he : (m : ℝ) + γ - (j : ℝ) = γ + ((m - j : ℕ) : ℝ) := by
    rw [Nat.cast_sub hjm]
    ring
  rw [he]
  apply interpolation_shift_moment_zero u hu ha hau (m - j) (by omega)
  intro hjzero
  rcases hdefect with hne | hrho
  · exact False.elim (hne (by omega))
  · exact hrho

/-- The high interpolation factor handles degrees above the integer part. -/
theorem high_integer_factor_zero {m L : ℕ} (w : Fin ((L - m) + 1) → ℝ)
    (hw : Function.Injective w) {b ρ γ : ℝ} (hb : 0 < b) (hbw : ∀ i, b < w i)
    (j : ℕ) (hjm : m + 1 ≤ j) (hjL : j ≤ L + 1)
    (hdefect : j ≠ m + 1 ∨ ρ = 0) :
    (∑ i, normalizedInterpolation w b ρ (1 - γ) i *
      interpolationNodes w b i ^ ((j : ℝ) - ((m : ℝ) + γ))) = 0 := by
  have he : (j : ℝ) - ((m : ℝ) + γ) = (1 - γ) + ((j - (m + 1) : ℕ) : ℝ) := by
    rw [Nat.cast_sub hjm, Nat.cast_add, Nat.cast_one]
    ring
  rw [he]
  apply interpolation_shift_moment_zero w hw hb hbw (j - (m + 1)) (by omega)
  intro hjzero
  rcases hdefect with hne | hrho
  · exact False.elim (hne (by omega))
  · exact hrho

theorem scaled_signed_power_sum {ι : Type*} [Fintype ι] (l v : ι → ℝ)
    {a : ℝ} (ha : 0 < a) (hv : ∀ i, 0 < v i) (t : ℝ) :
    (∑ i, l i * (v i / a) ^ t) = (∑ i, l i * v i ^ t) / a ^ t := by
  rw [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i _
  rw [Real.div_rpow (hv i).le ha.le]
  ring

/-- Every integer degree in the stated range has a vanishing tensor factor,
apart from the two explicitly permitted adjacent defects. -/
theorem noninteger_tensor_factor_cancellation {m L : ℕ}
    (u : Fin ((m - 1) + 1) → ℝ) (w : Fin ((L - m) + 1) → ℝ)
    (hu : Function.Injective u) (hw : Function.Injective w) {a b ρl ρr γ : ℝ}
    (ha : 0 < a) (hb : 0 < b) (hau : ∀ i, a < u i) (hbw : ∀ i, b < w i)
    (j : ℕ) (hj1 : 1 ≤ j) (hjL : j ≤ L + 1)
    (hlow : j ≠ m ∨ ρl = 0) (hhigh : j ≠ m + 1 ∨ ρr = 0) :
    (∑ i, normalizedInterpolation u a ρl γ i *
      (interpolationNodes u a i / a) ^ ((m : ℝ) + γ - (j : ℝ))) *
    (∑ t, normalizedInterpolation w b ρr (1 - γ) t *
      interpolationNodes w b t ^ ((j : ℝ) - ((m : ℝ) + γ))) = 0 := by
  by_cases hjm : j ≤ m
  · rw [scaled_signed_power_sum _ _ ha (interpolationNodes_pos u ha hau),
      low_integer_factor_zero u hu ha hau j hj1 hjm hlow, zero_div, zero_mul]
  · rw [high_integer_factor_zero w hw hb hbw j (by omega) hjL hhigh, mul_zero]

/-- Exact noninteger moment cancellations for the explicitly constructed priors.

The only extra scalar condition is the same positive-total-negative-mass
condition required by the source tensor-prior lemma. The mean-annihilation
condition is proved here from the interpolation construction, including m=1.
-/
theorem noninteger_matched_priors {m L : ℕ} (hm : 1 ≤ m) (_hLm : m ≤ L)
    (u : Fin ((m - 1) + 1) → ℝ) (w : Fin ((L - m) + 1) → ℝ)
    (hu : Function.Injective u) (hw : Function.Injective w) {a b ρl ρr γ : ℝ}
    (ha : 0 < a) (ha1 : a < 1) (hb : 0 < b) (hb1 : b < 1)
    (hau : ∀ i, a < u i) (hu1 : ∀ i, u i ≤ 1)
    (hbw : ∀ i, b < w i) (hw1 : ∀ i, w i ≤ 1)
    (hρl : 0 ≤ ρl) (hρr : 0 ≤ ρr) (hγ : 0 < γ) (_hγ1 : γ < 1)
    (hone : m = 1 → ρl = 0)
    (hR : 0 <
      (∑ i, negativeCoeff (normalizedInterpolation u a ρl γ i)) +
      (∑ j, negativeCoeff (normalizedInterpolation w b ρr (1 - γ) j))) :
    ∃ p₀ p₁ : FiniteAtomicPrior
        (Option ((Option (Fin ((m - 1) + 1))) × (Option (Fin ((L - m) + 1))))),
      (∀ i, p₀.value i = 0 ∨ (1 ≤ p₀.value i ∧ p₀.value i ≤ (a * b)⁻¹)) ∧
      (∀ i, p₁.value i = 0 ∨ (1 ≤ p₁.value i ∧ p₁.value i ≤ (a * b)⁻¹)) ∧
      priorMoment p₀ 1 = 1 ∧ priorMoment p₁ 1 = 1 ∧
      (∀ j : ℕ, 1 ≤ j → j ≤ L + 1 →
        (j ≠ m ∨ ρl = 0) → (j ≠ m + 1 ∨ ρr = 0) →
          priorMoment p₁ (j : ℝ) = priorMoment p₀ (j : ℝ)) := by
  let l := normalizedInterpolation u a ρl γ
  let r := normalizedInterpolation w b ρr (1 - γ)
  let U := interpolationNodes u a
  let W := interpolationNodes w b
  have hα : 1 < (m : ℝ) + γ := by
    have hmR : (1 : ℝ) ≤ m := by exact_mod_cast hm
    linarith
  have hl : ∑ i, positiveCoeff (l i) = 1 :=
    normalizedInterpolation_positive_mass u ha hρl
  have hr : ∑ j, positiveCoeff (r j) = 1 :=
    normalizedInterpolation_positive_mass w hb hρr
  have hUa : ∀ i, a ≤ U i := by
    intro i
    cases i with
    | none => exact le_rfl
    | some i => exact (hau i).le
  have hU1 : ∀ i, U i ≤ 1 := by
    intro i
    cases i with
    | none => exact ha1.le
    | some i => exact hu1 i
  have hWb : ∀ i, b ≤ W i := by
    intro i
    cases i with
    | none => exact le_rfl
    | some i => exact (hbw i).le
  have hW1 : ∀ i, W i ≤ 1 := by
    intro i
    cases i with
    | none => exact hb1.le
    | some i => exact hw1 i
  have hlow1 : 1 ≠ m ∨ ρl = 0 := by
    by_cases hm1 : m = 1
    · exact Or.inr (hone hm1)
    · exact Or.inl (Ne.symm hm1)
  have hmean : (∑ i, l i * U i ^ ((m : ℝ) + γ - 1)) *
      (∑ j, r j * W j ^ (1 - ((m : ℝ) + γ))) = 0 := by
    have hzero := low_integer_factor_zero u hu (γ := γ) ha hau 1 (by omega) hm hlow1
    simpa only [Nat.cast_one, hzero, zero_mul] using
      congrArg (fun x : ℝ => x * (∑ j, r j * W j ^ (1 - ((m : ℝ) + γ)))) hzero
  obtain ⟨_, p₀, p₁, hs₀, hs₁, hm₀, hm₁, hdiff, _, _, _⟩ :=
    tensor_priors l r U W hα ha hb hUa hU1 hWb hW1 hl hr rfl rfl hR hmean
  refine ⟨p₀, p₁, hs₀, hs₁, hm₀, hm₁, ?_⟩
  intro j hj1 hjL hlow hhigh
  have hj : (0 : ℝ) < j := by exact_mod_cast (show 0 < j by omega)
  have h := hdiff (j : ℝ) hj
  have hz := noninteger_tensor_factor_cancellation u w hu hw (γ := γ) ha hb hau hbw j hj1 hjL hlow hhigh
  change (∑ i, l i * (U i / a) ^ ((m : ℝ) + γ - (j : ℝ))) *
    (∑ t, r t * W t ^ ((j : ℝ) - ((m : ℝ) + γ))) = 0 at hz
  rw [hz, mul_zero] at h
  exact sub_eq_zero.mp h

end Renyi
