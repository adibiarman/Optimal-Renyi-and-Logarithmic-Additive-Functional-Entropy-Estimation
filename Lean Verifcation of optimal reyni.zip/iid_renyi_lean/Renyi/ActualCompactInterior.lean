import Renyi.ActualCompactLocalization
import Renyi.CompactOmegaGap
import Renyi.ActualBiasBudgetBounds

/-! Complete compact-width deterministic interior for the one source oracle,
including every sufficiently accurate heavy aggregate. -/
noncomputable section
namespace Renyi
set_option maxHeartbeats 900000

def compactInteriorCoefficient (eps W u0 : ℝ) : ℝ :=
  compactOmegaGap eps W/(12*(u0+2))

lemma compactInteriorCoefficient_pos {eps W u0 : ℝ} (heps : 0<eps) (hu0 : 0<u0) :
    0<compactInteriorCoefficient eps W u0 :=
  div_pos (compactOmegaGap_pos heps) (by positivity)

/-- A single D-last cutoff establishes the full source margin. Any heavy
aggregate perturbing the oracle by at most the displayed fixed fraction of P
is allowed, so this theorem applies directly after the heavy concentration event. -/
theorem actual_compact_ideal_interior {eps W Ch cb lambda CL cL fL f M cu u0 C0 d : ℝ}
    (heps : 0<eps) (hW : 0<W) (hCh : 0≤Ch) (hcb : 0<cb)
    (hlambda : 0<lambda) (hlambda4 : lambda≤4) (hCL : 1≤CL) (hcL : 0<cL) (hcbCL : 1≤cb*CL)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1) (hM : 0≤M)
    (hcu : 0≤cu) (hu0 : 0<u0) (hC0 : 1≤C0) (hd : 0≤d) (hd1 : d≤1)
    (hsmall : cu*u0≤compactOmegaLowerGap eps W/2) :
    ∃ D0 : ℝ, 0<D0 ∧ ∀ (k : ℕ) (alpha D : ℝ),
      0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → D0≤D →
      2*eps*(alpha-1)/(fractionalPart alpha*(1-fractionalPart alpha))≤W →
      ∀ (p : Simplex k) (light : Fin k→Bool),
        (∀i,light i=true→p.mass i≤upperB k alpha eps D cb CL cL) →
        ∀ V : ℝ, |V-actualCorrectedOracleMean p light alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d|≤
          (compactOmegaGap eps W/4)*powerSum p alpha →
        upperKappa alpha eps*powerSum p alpha+
            3*compactInteriorCoefficient eps W u0*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d u0≤V ∧
          V+3*compactInteriorCoefficient eps W u0*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d u0≤powerSum p alpha := by
  let g := compactOmegaGap eps W
  have hg0 : 0<g := compactOmegaGap_pos heps
  have hg4 : 0<g/4 := by positivity
  let c := g/(12*(u0+2))
  have hc : 0<c := div_pos hg0 (by positivity)
  obtain ⟨D1,hD1,hbias⟩ := actual_corrected_oracle_compact_bias heps hW hCh hcb hlambda hlambda4 hCL hcL hcbCL
    hfL hfL1 hf hf1 hM hcu hu0 hC0 hd hg4
  obtain ⟨D2,hD2,hbase⟩ := actualCutoffBudget_uniform_le_powerSum heps hCh hcb hlambda hCL hcL hC0 hd hd1
  refine ⟨max D1 D2,hD1.trans_le (le_max_left _ _),?_⟩
  intro k alpha D hk ha hg hg1 hDD hwidth p light hlight V hV
  have hD1' : D1≤D := (le_max_left _ _).trans hDD
  have hD2' : D2≤D := (le_max_right _ _).trans hDD
  have hmean := abs_le.mp (hbias k alpha D hk ha hg hg1 hD1' hwidth p light hlight)
  have hpert := abs_le.mp hV
  have hgap := actual_compact_omega_gaps (k:=k) ha heps hg hg1 hCh hcu hu0 hsmall hwidth
  have hP : 0<powerSum p alpha := simplex_powerSum_pos p alpha
  have hlow := mul_le_mul_of_nonneg_right hgap.1 hP.le
  have hhigh := mul_le_mul_of_nonneg_right hgap.2 hP.le
  have hbudget := actualBiasBudget_le_powerSum p (by linarith only [ha]) heps.le hg hg1 hu0
    (hbase k alpha D hk ha hg hg1 hD2' p)
  have hreserve : 3*c*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d u0≤(g/4)*powerSum p alpha := by
    have hh := mul_le_mul_of_nonneg_left hbudget (mul_nonneg (by norm_num : (0:ℝ)≤3) hc.le)
    convert hh using 1
    dsimp [c]
    field_simp
    ring
  change |V-actualCorrectedOracleMean p light alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d|≤(g/4)*powerSum p alpha at hV
  change (upperKappa alpha eps+g)*powerSum p alpha≤_ at hlow
  change (_+g)*powerSum p alpha≤_ at hhigh
  have hnonneg : 0≤g*powerSum p alpha := mul_nonneg hg0.le hP.le
  change 3*compactInteriorCoefficient eps W u0*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d u0≤(g/4)*powerSum p alpha at hreserve
  dsimp only [g] at hmean hlow hhigh hreserve hnonneg
  constructor <;> nlinarith only [hmean.1,hmean.2,hpert.1,hpert.2,hlow,hhigh,hreserve,hnonneg]

end Renyi
