import Renyi.HiddenCoordinate
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

/-! Uniform elementary estimates for the hidden-coordinate mixture. -/
noncomputable section
open Filter
open scoped Topology
namespace Renyi

theorem exp_sub_one_le_mul_exp (t : ℝ) : Real.exp t - 1 ≤ t * Real.exp t := by
  have h := mul_le_mul_of_nonneg_right (Real.add_one_le_exp (-t)) (Real.exp_pos t).le
  rw [← Real.exp_add] at h
  simp only [neg_add_cancel, Real.exp_zero] at h
  nlinarith

theorem exp_le_two_of_le_half {t : ℝ} (ht0 : 0 ≤ t) (ht1 : t ≤ 1 / 2) : Real.exp t ≤ 2 := by
  have h := Real.exp_bound_div_one_sub_of_interval ht0 (by linarith : t < 1)
  exact h.trans ((div_le_iff₀ (by linarith : 0 < 1 - t)).2 (by linarith))

theorem hidden_exponential_ratio {kap y : ℝ} (hk0 : 0 ≤ kap) (hk1 : kap ≤ 1 / 2)
    (hy : 0 ≤ y) :
    (Real.exp (kap * (1 + y)) - 1) / Real.exp y ≤ 4 * kap := by
  have hkap := exp_le_two_of_le_half hk0 hk1
  have hyexp : 1 + y ≤ 2 * Real.exp (y / 2) := by
    have h := Real.add_one_le_exp (y / 2)
    linarith
  have hky : Real.exp (kap * y) ≤ Real.exp (y / 2) := by
    apply Real.exp_le_exp.mpr
    nlinarith
  have hprod : (1 + y) * Real.exp (kap * (1 + y)) ≤ 4 * Real.exp y := by
    rw [show kap * (1 + y) = kap + kap * y by ring, Real.exp_add]
    calc
      _ ≤ (2 * Real.exp (y / 2)) * (2 * Real.exp (y / 2)) := by
        exact mul_le_mul hyexp (mul_le_mul hkap hky (Real.exp_pos _).le (by norm_num))
          (mul_nonneg (Real.exp_pos _).le (Real.exp_pos _).le) (by positivity)
      _ = _ := by rw [mul_mul_mul_comm, ← Real.exp_add]; congr 2 <;> ring
  have h := mul_le_mul_of_nonneg_left hprod hk0
  have hmean := exp_sub_one_le_mul_exp (kap * (1 + y))
  apply (div_le_iff₀ (Real.exp_pos y)).2
  nlinarith

theorem hidden_mixture_scalar_bound {m : ℕ} (hm : 0 < m) {u v kap : ℝ}
    (hk0 : 0 ≤ kap) (hk1 : kap ≤ 1 / 2) (hv0 : 0 ≤ v) (hv1 : v ≤ kap)
    (hu : u ≤ kap * (1 + Real.log m)) :
    Real.exp v * (Real.exp u - 1) / m + Real.exp v - 1 ≤ 10 * kap := by
  have hmR : 0 < (m : ℝ) := by exact_mod_cast hm
  have hy : 0 ≤ Real.log (m : ℝ) := Real.log_nonneg (by exact_mod_cast hm)
  have hratio := hidden_exponential_ratio hk0 hk1 hy
  rw [Real.exp_log hmR] at hratio
  have hrat : (Real.exp u - 1) / (m : ℝ) ≤ 4 * kap :=
    (div_le_div_of_nonneg_right (sub_le_sub_right (Real.exp_le_exp.mpr hu) 1) hmR.le).trans hratio
  have hev := exp_le_two_of_le_half hv0 (hv1.trans hk1)
  have hvdiff : Real.exp v - 1 ≤ 2 * kap := by
    have h := Real.abs_exp_sub_one_le (show |v| ≤ 1 by rw [abs_of_nonneg hv0]; linarith)
    rw [abs_of_nonneg hv0] at h
    exact (le_abs_self _).trans (h.trans (by linarith))
  have hmul := mul_le_mul_of_nonneg_left hrat (Real.exp_pos v).le
  have hmul' := mul_le_mul_of_nonneg_right hev (by positivity : 0 ≤ 4 * kap)
  rw [← mul_div_assoc] at hmul
  linarith

def collisionQ (k : ℕ) (ell : ℝ) : ℝ := (k : ℝ) ^ (-1 + 1 / ell)
def collisionMultiplicity (ell : ℝ) : ℕ := ⌊Real.exp (ell / 64)⌋₊

theorem collisionMultiplicity_pos {ell : ℝ} (hell : 0 ≤ ell) :
    0 < collisionMultiplicity ell := by
  apply Nat.floor_pos.mpr
  exact Real.one_le_exp (by positivity)

theorem collisionMultiplicity_log {ell : ℝ} (hell : 0 ≤ ell) :
    ell / 64 ≤ 1 + Real.log (collisionMultiplicity ell) ∧
      Real.log (collisionMultiplicity ell) ≤ ell / 64 ∧
      Real.log ((collisionMultiplicity ell : ℝ) + 1) ≤ Real.log 2 + ell / 64 := by
  have hm : 0 < collisionMultiplicity ell := collisionMultiplicity_pos hell
  have hmR : 0 < (collisionMultiplicity ell : ℝ) := by exact_mod_cast hm
  have hm1 : 1 ≤ (collisionMultiplicity ell : ℝ) := by exact_mod_cast hm
  have hexp : 0 < Real.exp (ell / 64) := Real.exp_pos _
  have hfloor := Nat.floor_le hexp.le
  change (collisionMultiplicity ell : ℝ) ≤ Real.exp (ell / 64) at hfloor
  have hceil := Nat.lt_floor_add_one (Real.exp (ell / 64))
  change Real.exp (ell / 64) < (collisionMultiplicity ell : ℝ) + 1 at hceil
  have hhalf : Real.exp (ell / 64) / 2 ≤ (collisionMultiplicity ell : ℝ) := by linarith
  have hlo := Real.log_le_log (div_pos hexp (by norm_num)) hhalf
  rw [Real.log_div hexp.ne' (by norm_num), Real.log_exp] at hlo
  have hlogtwo := Real.log_le_sub_one_of_pos (show (0 : ℝ) < 2 by norm_num)
  have hhi := Real.log_le_log hmR hfloor
  rw [Real.log_exp] at hhi
  have hplus : (collisionMultiplicity ell : ℝ) + 1 ≤ 2 * Real.exp (ell / 64) := by linarith
  have hpluslog := Real.log_le_log (by positivity : 0 < (collisionMultiplicity ell : ℝ) + 1) hplus
  rw [Real.log_mul (by norm_num) hexp.ne', Real.log_exp] at hpluslog
  exact ⟨by linarith, hhi, hpluslog⟩

theorem collisionQ_bounds {k : ℕ} {ell : ℝ} (hk : 1 ≤ k) (hell : 3 / 2 ≤ ell) :
    (k : ℝ) ^ (-1 : ℝ) ≤ collisionQ k ell ∧
      collisionQ k ell ≤ (k : ℝ) ^ (-(1 / 3) : ℝ) := by
  have hkR : 1 ≤ (k : ℝ) := by exact_mod_cast hk
  have hellpos : 0 < ell := by linarith
  constructor
  · apply Real.rpow_le_rpow_of_exponent_le hkR
    have := one_div_pos.mpr hellpos
    linarith
  · apply Real.rpow_le_rpow_of_exponent_le hkR
    have hinv : 1 / ell ≤ 2 / 3 := (div_le_iff₀ hellpos).2 (by linarith)
    linarith

theorem collision_mq_bound {k : ℕ} {ell : ℝ} (hk : 1 ≤ k)
    (hell : 3 / 2 ≤ ell) (hellk : ell ≤ Real.log k) :
    (collisionMultiplicity ell : ℝ) * collisionQ k ell ≤ (k : ℝ) ^ (-(1 / 4) : ℝ) := by
  have hkR : 1 ≤ (k : ℝ) := by exact_mod_cast hk
  have hkpos : 0 < (k : ℝ) := by linarith
  have hm : (collisionMultiplicity ell : ℝ) ≤ (k : ℝ) ^ (1 / 64 : ℝ) := by
    calc
      _ ≤ Real.exp (ell / 64) := Nat.floor_le (Real.exp_pos _).le
      _ ≤ Real.exp (Real.log k / 64) := Real.exp_le_exp.mpr (by linarith)
      _ = _ := by rw [Real.rpow_def_of_pos hkpos]; congr 1; ring
  have hq := (collisionQ_bounds hk hell).2
  calc
    _ ≤ (k : ℝ) ^ (1 / 64 : ℝ) * (k : ℝ) ^ (-(1 / 3) : ℝ) :=
      mul_le_mul hm hq (Real.rpow_pos_of_pos hkpos _).le (Real.rpow_pos_of_pos hkpos _).le
    _ = (k : ℝ) ^ ((1 / 64 : ℝ) - 1 / 3) := by rw [← Real.rpow_add hkpos]; congr 1
    _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hkR (by norm_num)

theorem collision_reservoir_power {k m : ℕ} {ell a : ℝ} (hk : 1 ≤ k)
    (hmk : m < k) (hell : 3 / 2 ≤ ell) (hella : ell ≤ a)
    (hmq : (m : ℝ) * collisionQ k ell ≤ 1) :
    ((k : ℝ) - m) * hiddenNullReservoir k m (collisionQ k ell) ^ a ≤ collisionQ k ell ^ a := by
  have hkpos : 0 < (k : ℝ) := by exact_mod_cast lt_of_lt_of_le Nat.zero_lt_one hk
  have hkR : 1 ≤ (k : ℝ) := by exact_mod_cast hk
  have hkm : 0 < (k : ℝ) - m := sub_pos.mpr (by exact_mod_cast hmk)
  have ha : 0 ≤ a := by linarith
  have hellpos : 0 < ell := by linarith
  have hqlo : 1 / (k : ℝ) ≤ collisionQ k ell := by
    simpa only [Real.rpow_neg_one, one_div] using (collisionQ_bounds hk hell).1
  have hr0 : 0 ≤ hiddenNullReservoir k m (collisionQ k ell) := div_nonneg (sub_nonneg.mpr hmq) hkm.le
  have hr1 : hiddenNullReservoir k m (collisionQ k ell) ≤ 1 / (k : ℝ) := by
    apply (div_le_iff₀ hkm).2
    have hmul := mul_le_mul_of_nonneg_left hqlo (Nat.cast_nonneg m)
    field_simp
    field_simp at hmul
    nlinarith
  calc
    _ ≤ (k : ℝ) * (1 / (k : ℝ)) ^ a :=
      mul_le_mul (by linarith) (Real.rpow_le_rpow hr0 hr1 ha)
        (Real.rpow_nonneg hr0 _) (Nat.cast_nonneg _)
    _ = (k : ℝ) ^ (1 - a) := by
      rw [one_div, Real.inv_rpow hkpos.le, ← Real.rpow_neg hkpos.le]
      calc
        _ = (k : ℝ) ^ (1 : ℝ) * (k : ℝ) ^ (-a) := by rw [Real.rpow_one]
        _ = _ := by rw [← Real.rpow_add hkpos]; congr 1
    _ ≤ (k : ℝ) ^ ((-1 + 1 / ell) * a) := by
      apply Real.rpow_le_rpow_of_exponent_le hkR
      have h : (1 : ℝ) ≤ a / ell := (le_div_iff₀ hellpos).2 (by simpa using hella)
      rw [show (-1 + 1 / ell) * a = -a + a / ell by ring]
      linarith
    _ = _ := by rw [collisionQ, Real.rpow_mul hkpos.le]

theorem collision_large_alphabet (B : ℝ) :
    ∃ K : ℕ, 2 ≤ K ∧ ∀ k : ℕ, K ≤ k →
      3 / 2 ≤ Real.log k ∧ (k : ℝ) ^ (-(1 / 4) : ℝ) ≤ 1 / 4 ∧
        B * (k : ℝ) ^ (-(1 / 3) : ℝ) ≤ 1 / 4 ∧
        (1 + Real.log k) * (k : ℝ) ^ (-(1 / 3) : ℝ) ≤ 1 / 2 := by
  have hcast : Tendsto (fun k : ℕ => (k : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hp₄ := (tendsto_rpow_neg_atTop (show (0 : ℝ) < 1 / 4 by norm_num)).comp hcast
  have hp₃ := tendsto_rpow_neg_atTop (show (0 : ℝ) < 1 / 3 by norm_num)
  have hB : Tendsto (fun k : ℕ => B * (k : ℝ) ^ (-(1 / 3) : ℝ)) atTop (𝓝 0) := by
    simpa only [mul_zero] using tendsto_const_nhds.mul (hp₃.comp hcast)
  have hlogdiv := (isLittleO_log_rpow_atTop (show (0 : ℝ) < 1 / 3 by norm_num)).tendsto_div_nhds_zero
  have hlogpow : Tendsto (fun x : ℝ => Real.log x * x ^ (-(1 / 3) : ℝ)) atTop (𝓝 0) := by
    apply hlogdiv.congr'
    filter_upwards [eventually_gt_atTop (0 : ℝ)] with x hx
    rw [Real.rpow_neg hx.le, div_eq_mul_inv]
  have hcombined : Tendsto (fun k : ℕ => (1 + Real.log k) * (k : ℝ) ^ (-(1 / 3) : ℝ))
      atTop (𝓝 0) := by
    have h := (hp₃.add hlogpow).comp hcast
    simpa only [zero_add, add_mul, one_mul] using h
  have hl := (Real.tendsto_log_atTop.comp hcast).eventually (eventually_ge_atTop (3 / 2 : ℝ))
  have he : ∀ᶠ k : ℕ in atTop,
      3 / 2 ≤ Real.log k ∧ (k : ℝ) ^ (-(1 / 4) : ℝ) ≤ 1 / 4 ∧
        B * (k : ℝ) ^ (-(1 / 3) : ℝ) ≤ 1 / 4 ∧
        (1 + Real.log k) * (k : ℝ) ^ (-(1 / 3) : ℝ) ≤ 1 / 2 := by
    filter_upwards [hl, hp₄.eventually_le_const (by norm_num : (0 : ℝ) < 1 / 4),
      hB.eventually_le_const (by norm_num : (0 : ℝ) < 1 / 4),
      hcombined.eventually_le_const (by norm_num : (0 : ℝ) < 1 / 2)] with k h₁ h₂ h₃ h₄
    exact ⟨h₁, h₂, h₃, h₄⟩
  obtain ⟨K, hK⟩ := eventually_atTop.mp he
  refine ⟨max 2 K, le_max_left _ _, fun k hk => hK k ((le_max_right _ _).trans hk)⟩

theorem collision_parameter_validity {k : ℕ} {ell B : ℝ}
    (hk : 2 ≤ k) (hell : 3 / 2 ≤ ell) (hellk : ell ≤ Real.log k) (hB : 1 ≤ B)
    (hsmall : (k : ℝ) ^ (-(1 / 4) : ℝ) ≤ 1 / 4)
    (hBsmall : B * (k : ℝ) ^ (-(1 / 3) : ℝ) ≤ 1 / 4)
    (hlogsmall : (1 + Real.log k) * (k : ℝ) ^ (-(1 / 3) : ℝ) ≤ 1 / 2) :
    collisionMultiplicity ell < k ∧
      (collisionMultiplicity ell : ℝ) * collisionQ k ell < 1 ∧
      (collisionMultiplicity ell : ℝ) * collisionQ k ell + (B - 1) * collisionQ k ell ≤ 1 ∧
      (1 + Real.log (collisionMultiplicity ell)) * collisionQ k ell /
        (1 - (collisionMultiplicity ell : ℝ) * collisionQ k ell) ≤ 1 := by
  have hk1 : 1 ≤ k := by omega
  have hkpos : 0 < (k : ℝ) := by exact_mod_cast lt_of_lt_of_le Nat.zero_lt_one hk1
  have hqpos : 0 < collisionQ k ell := Real.rpow_pos_of_pos hkpos _
  have hq := collisionQ_bounds hk1 hell
  have hmq := (collision_mq_bound hk1 hell hellk).trans hsmall
  have hqlo : 1 / (k : ℝ) ≤ collisionQ k ell := by
    simpa only [Real.rpow_neg_one, one_div] using hq.1
  have hkq : 1 ≤ (k : ℝ) * collisionQ k ell := by
    have h := mul_le_mul_of_nonneg_left hqlo hkpos.le
    simpa [hkpos.ne'] using h
  have hmk : collisionMultiplicity ell < k := by
    by_contra h
    have hmkR : (k : ℝ) ≤ collisionMultiplicity ell := by exact_mod_cast le_of_not_gt h
    have h := mul_le_mul_of_nonneg_right hmkR hqpos.le
    linarith
  refine ⟨hmk, by linarith, ?_, ?_⟩
  · have hBq := (mul_le_mul_of_nonneg_left hq.2 (by linarith : 0 ≤ B)).trans hBsmall
    nlinarith
  · apply (div_le_iff₀ (by linarith : 0 < 1 - (collisionMultiplicity ell : ℝ) * collisionQ k ell)).2
    have hlogm := (collisionMultiplicity_log (by linarith : 0 ≤ ell)).2.1
    have hlogk : Real.log (collisionMultiplicity ell) ≤ Real.log k := by linarith
    have hleft : (1 + Real.log (collisionMultiplicity ell)) * collisionQ k ell ≤ 1 / 2 := by
      calc
        _ ≤ (1 + Real.log k) * (k : ℝ) ^ (-(1 / 3) : ℝ) :=
          mul_le_mul (by linarith) hq.2 hqpos.le (by linarith)
        _ ≤ _ := hlogsmall
    linarith

end Renyi
