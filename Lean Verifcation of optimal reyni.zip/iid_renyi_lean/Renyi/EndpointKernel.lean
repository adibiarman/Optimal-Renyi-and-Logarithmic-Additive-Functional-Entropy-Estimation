import Mathlib.Analysis.SpecialFunctions.Trigonometric.Chebyshev
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Inverse
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic
import Renyi.PolynomialCoefficientMass

/-!
# The actual Chebyshev endpoint kernel

This module starts the elementary endpoint-kernel construction with its exact
Chebyshev formula, sine representation, and global bounds. All estimates concern
the constructed function; no kernel estimates are assumed as certificates.
-/

noncomputable section
open scoped BigOperators
open Polynomial Polynomial.Chebyshev
namespace Renyi

def endpointKernel (N d : ℕ) (x : ℝ) : ℝ :=
  ((U ℝ ((N : ℤ) - 1)).eval (Real.sqrt (1 - x)) / N) ^ (2 * d)

def endpointAngle (x : ℝ) : ℝ := Real.arcsin (Real.sqrt x)

theorem endpointAngle_sin {x : ℝ} (_hx : 0 ≤ x) (hx1 : x ≤ 1) :
    Real.sin (endpointAngle x) = Real.sqrt x := by
  exact Real.sin_arcsin (by linarith [Real.sqrt_nonneg x]) (Real.sqrt_le_one.mpr hx1)

theorem endpointAngle_cos {x : ℝ} (hx : 0 ≤ x) :
    Real.cos (endpointAngle x) = Real.sqrt (1 - x) := by
  rw [endpointAngle, Real.cos_arcsin, Real.sq_sqrt hx]

theorem endpointAngle_nonneg {x : ℝ} : 0 ≤ endpointAngle x :=
  Real.arcsin_nonneg.mpr (Real.sqrt_nonneg x)

theorem abs_sin_nat_mul_le (N : ℕ) (θ : ℝ) :
    |Real.sin (N * θ)| ≤ N * |Real.sin θ| := by
  induction N with
  | zero => simp
  | succ N ih =>
    rw [Nat.cast_add, Nat.cast_one, add_mul, one_mul, Real.sin_add]
    calc
      _ ≤ |Real.sin (N * θ) * Real.cos θ| +
          |Real.cos (N * θ) * Real.sin θ| := abs_add_le _ _
      _ ≤ |Real.sin (N * θ)| + |Real.sin θ| := by
        simp only [abs_mul]
        gcongr
        · exact mul_le_of_le_one_right (abs_nonneg _) (Real.abs_cos_le_one _)
        · exact mul_le_of_le_one_left (abs_nonneg _) (Real.abs_cos_le_one _)
      _ ≤ (N + 1) * |Real.sin θ| := by nlinarith

theorem endpoint_chebyshev_sine {x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1)
    (N : ℕ) :
    (U ℝ ((N : ℤ) - 1)).eval (Real.sqrt (1 - x)) * Real.sqrt x =
      Real.sin (N * endpointAngle x) := by
  have h := U_real_cos (endpointAngle x) ((N : ℤ) - 1)
  simpa [endpointAngle_cos hx, endpointAngle_sin hx hx1] using h

theorem endpointKernel_zero {N : ℕ} (hN : 0 < N) (d : ℕ) :
    endpointKernel N d 0 = 1 := by
  have hNr : (N : ℝ) ≠ 0 := by exact_mod_cast hN.ne'
  simp [endpointKernel, U_eval_one, hNr]

theorem endpointKernel_nonneg (N d : ℕ) (x : ℝ) :
    0 ≤ endpointKernel N d x := by
  unfold endpointKernel
  rw [pow_mul]
  exact pow_nonneg (sq_nonneg _) _

theorem endpointKernel_continuous (N d : ℕ) : Continuous (endpointKernel N d) := by
  unfold endpointKernel
  fun_prop

theorem endpoint_chebyshev_abs_le {N : ℕ} (hN : 0 < N)
    {x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    |(U ℝ ((N : ℤ) - 1)).eval (Real.sqrt (1 - x)) / N| ≤ 1 := by
  rcases hx.eq_or_lt with rfl | hx
  · have hNr : (N : ℝ) ≠ 0 := by exact_mod_cast hN.ne'
    simp [U_eval_one, hNr]
  have hs := endpoint_chebyshev_sine hx.le hx1 N
  have hsin := abs_sin_nat_mul_le N (endpointAngle x)
  rw [endpointAngle_sin hx.le hx1, abs_of_nonneg (Real.sqrt_nonneg x),
    ← hs, abs_mul, abs_of_nonneg (Real.sqrt_nonneg x)] at hsin
  have hu := (mul_le_mul_iff_left₀ (Real.sqrt_pos.mpr hx)).mp hsin
  rw [abs_div, abs_of_nonneg (show 0 ≤ (N : ℝ) from Nat.cast_nonneg _)]
  exact (div_le_one (by exact_mod_cast hN)).mpr hu

theorem endpointKernel_le_one {N : ℕ} (hN : 0 < N) (d : ℕ)
    {x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1) : endpointKernel N d x ≤ 1 := by
  calc
    endpointKernel N d x ≤ |endpointKernel N d x| := le_abs_self _
    _ ≤ 1 := by
      rw [endpointKernel, abs_pow]
      exact pow_le_one₀ (abs_nonneg _) (endpoint_chebyshev_abs_le hN hx hx1)

theorem endpointKernel_sine {N : ℕ} (hN : 0 < N) (d : ℕ)
    {x : ℝ} (hx : 0 < x) (hx1 : x ≤ 1) :
    endpointKernel N d x =
      (Real.sin (N * endpointAngle x) / (N * Real.sqrt x)) ^ (2*d) := by
  have hs := endpoint_chebyshev_sine hx.le hx1 N
  have hNr : (N : ℝ) ≠ 0 := by exact_mod_cast hN.ne'
  unfold endpointKernel
  congr 1
  field_simp
  nlinarith

theorem endpointKernel_le_inverse_power {N : ℕ} (hN : 0 < N) (d : ℕ)
    {x : ℝ} (hx : 0 < x) (hx1 : x ≤ 1) :
    endpointKernel N d x ≤ ((N : ℝ)^2 * x)⁻¹ ^ d := by
  rw [endpointKernel_sine hN d hx hx1, pow_mul, div_pow]
  have hn : 0 < (N : ℝ) := by exact_mod_cast hN
  have hs : Real.sin (N * endpointAngle x) ^ 2 ≤ 1 :=
    (sq_le_one_iff_abs_le_one _).mpr (Real.abs_sin_le_one _)
  have hden : ((N : ℝ) * Real.sqrt x)^2 = (N : ℝ)^2 * x := by
    rw [mul_pow, Real.sq_sqrt hx.le]
  rw [hden]
  apply pow_le_pow_left₀ (by positivity)
  simpa [one_div] using (div_le_div_of_nonneg_right hs (by positivity :
    0 ≤ (N : ℝ)^2 * x))

theorem endpointKernel_global_bounds {N : ℕ} (hN : 0 < N) (d : ℕ)
    {x : ℝ} (hx : 0 < x) (hx1 : x ≤ 1) :
    0 ≤ endpointKernel N d x ∧
      endpointKernel N d x ≤ min 1 (((N : ℝ)^2 * x)⁻¹ ^ d) :=
  ⟨endpointKernel_nonneg N d x,
    le_min (endpointKernel_le_one hN d hx.le hx1)
      (endpointKernel_le_inverse_power hN d hx hx1)⟩

/-- The square of the second-kind Chebyshev polynomial, with its even variable
already replaced by `1-X`. This recurrence constructs an ordinary polynomial. -/
def endpointSquarePolynomial : ℕ → ℝ[X]
  | 0 => 1
  | 1 => 4 * (1-X)
  | n+2 => (2-4*X) * endpointSquarePolynomial (n+1) - endpointSquarePolynomial n + 2

theorem chebyshev_U_cassini (n : ℕ) :
    U ℝ ((n : ℤ)+1)^2 - 2*X*U ℝ ((n : ℤ)+1)*U ℝ (n : ℤ) +
      U ℝ (n : ℤ)^2 = 1 := by
  induction n with
  | zero => simp [U_one]; ring
  | succ n ih =>
    push_cast
    rw [show (n : ℤ)+1+1 = n+2 by ring, U_add_two]
    linear_combination ih

theorem endpointSquarePolynomial_comp (n : ℕ) :
    (endpointSquarePolynomial n).comp (1-X^2) = U ℝ (n : ℤ)^2 := by
  induction n using Nat.twoStepInduction with
  | zero => simp [endpointSquarePolynomial]
  | one => simp [endpointSquarePolynomial, U_one]; ring
  | more n h0 h1 =>
    rw [endpointSquarePolynomial]
    simp only [add_comp, sub_comp, mul_comp, ofNat_comp, X_comp, h0, h1]
    push_cast
    rw [U_add_two]
    linear_combination -2 * (chebyshev_U_cassini n)

theorem endpointSquarePolynomial_eval (n : ℕ) {x : ℝ} (hx1 : x ≤ 1) :
    (endpointSquarePolynomial n).eval x =
      (U ℝ (n : ℤ)).eval (Real.sqrt (1-x)) ^ 2 := by
  have h := congrArg (Polynomial.eval (Real.sqrt (1-x))) (endpointSquarePolynomial_comp n)
  simpa [eval_comp, Real.sq_sqrt (sub_nonneg.mpr hx1)] using h

def endpointKernelPolynomial (N d : ℕ) : ℝ[X] :=
  (C (((N : ℝ)^2)⁻¹) * endpointSquarePolynomial (N-1))^d

theorem endpointKernelPolynomial_eval {N : ℕ} (hN : 0 < N) (d : ℕ)
    {x : ℝ} (hx1 : x ≤ 1) :
    (endpointKernelPolynomial N d).eval x = endpointKernel N d x := by
  have hn : ((N-1 : ℕ) : ℤ) = (N : ℤ)-1 := by omega
  simp only [endpointKernelPolynomial, eval_pow, eval_mul, eval_C,
    endpointSquarePolynomial_eval _ hx1, hn, endpointKernel, pow_mul, div_pow]
  ring

theorem endpointSquarePolynomial_coefficientMass (n : ℕ) :
    coefficientMass (endpointSquarePolynomial n) ≤ (9 : ℝ)^n := by
  have h4 : coefficientMass (4 : ℝ[X]) = 4 := by
    change coefficientMass (C 4) = 4
    rw [coefficientMass_C]
    norm_num
  have h2 : coefficientMass (2 : ℝ[X]) = 2 := by
    change coefficientMass (C 2) = 2
    rw [coefficientMass_C]
    norm_num
  have ha : coefficientMass (2-4*X : ℝ[X]) ≤ 6 := by
    calc
      _ ≤ coefficientMass (2 : ℝ[X]) + coefficientMass (4*X : ℝ[X]) :=
        coefficientMass_sub_le _ _
      _ ≤ 2 + coefficientMass (4 : ℝ[X]) * coefficientMass X := by
        rw [h2]
        exact add_le_add_left (coefficientMass_mul_le _ _) _
      _ = 6 := by rw [h4, coefficientMass_X]; norm_num
  induction n using Nat.twoStepInduction with
  | zero => simp [endpointSquarePolynomial]
  | one =>
    simp only [endpointSquarePolynomial, pow_one]
    have h := coefficientMass_sub_le (1 : ℝ[X]) X
    have hm := coefficientMass_mul_le (4 : ℝ[X]) (1-X)
    simp only [coefficientMass_one, coefficientMass_X] at h
    rw [h4] at hm
    linarith
  | more n h0 h1 =>
    rw [endpointSquarePolynomial]
    have h := coefficientMass_add_le
      ((2-4*X)*endpointSquarePolynomial (n+1)-endpointSquarePolynomial n) 2
    have hs := coefficientMass_sub_le
      ((2-4*X)*endpointSquarePolynomial (n+1)) (endpointSquarePolynomial n)
    have hm := (coefficientMass_mul_le (2-4*X) (endpointSquarePolynomial (n+1))).trans
      (mul_le_mul ha h1 (coefficientMass_nonneg _) (by norm_num))
    have hp : 1 ≤ (9 : ℝ)^n := one_le_pow₀ (by norm_num)
    rw [h2] at h
    rw [pow_succ] at h1 hm
    rw [pow_succ, pow_succ]
    nlinarith

theorem endpointKernelPolynomial_coefficientMass {N : ℕ} (hN : 0 < N) (d : ℕ) :
    coefficientMass (endpointKernelPolynomial N d) ≤ (9 : ℝ)^((N-1)*d) := by
  have hn : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hinv : 0 ≤ ((N : ℝ)^2)⁻¹ := by positivity
  have hinv1 : ((N : ℝ)^2)⁻¹ ≤ 1 := by
    apply inv_le_one_of_one_le₀
    nlinarith
  have hmass : coefficientMass (C (((N : ℝ)^2)⁻¹) * endpointSquarePolynomial (N-1)) ≤
      (9 : ℝ)^(N-1) := by
    rw [coefficientMass_C_mul, abs_of_nonneg hinv]
    exact (mul_le_of_le_one_left (coefficientMass_nonneg _) hinv1).trans
      (endpointSquarePolynomial_coefficientMass _)
  unfold endpointKernelPolynomial
  exact (coefficientMass_pow_le _ d).trans
    ((pow_le_pow_left₀ (coefficientMass_nonneg _) hmass d).trans_eq (pow_mul _ _ _).symm)

theorem endpointKernelPolynomial_uniform_coefficients {N d : ℕ}
    (hN : 0 < N) (hd : d ≤ 6) :
    coefficientMass (endpointKernelPolynomial N d) ≤ ((9 : ℝ)^6)^(N+1) := by
  rw [← pow_mul]
  exact (endpointKernelPolynomial_coefficientMass hN d).trans
    (pow_le_pow_right₀ (by norm_num) (by
      calc (N-1)*d ≤ (N+1)*6 := Nat.mul_le_mul (by omega) hd
           _ = 6*(N+1) := Nat.mul_comm _ _))

end Renyi
