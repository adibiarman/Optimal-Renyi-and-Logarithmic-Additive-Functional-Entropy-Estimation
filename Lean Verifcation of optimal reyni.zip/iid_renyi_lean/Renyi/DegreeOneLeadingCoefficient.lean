import Renyi.DegreeOnePolynomialCoefficients
import Renyi.CoupledLeadingCoefficient

/-! The sharp first high coefficient of the actual degree-one completed branch. -/
noncomputable section
open scoped BigOperators
open Polynomial
namespace Renyi

/-- Concrete leading coefficient bound for the actual degree-one completed polynomial. -/
theorem degreeOneCoupledPolynomial_leading_bound {N m : ℕ} (hm : 1 ≤ m) (hN : 0 < N)
    {γ c a b f A B ω : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 < a) (hb : 0 < b)
    (hc : c ∈ Set.Ioo (γ / (1 + γ)) 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1)
    (hZ : (N : ℝ) ^ 2 * (a / b) ≤ 1) :
    |(degreeOneCoupledPolynomial N m γ (c * a * (1 + γ) / γ) b f ω A B).coeff (m + 1)| ≤
      A * a ^ γ * ((24 * Real.exp 12) * (N : ℝ) ^ 2 / b *
        (8 : ℝ)) +
      B / b ^ (1 - γ) * (coupledLocalizationConstant * (N : ℝ) ^ (2 * (1 - γ))) +
      (ω * (1 - B) / b ^ (1 - γ)) *
        (Real.exp (Real.log 12 + 1) * (N : ℝ) ^ (2 * (1 - γ))) := by
  have hc0 : 0 < c := (div_pos hγ (by positivity)).trans hc.1
  let P := degreeOneLowPolynomial γ c
  let R := reverseScaledPolynomial P m a
  let J := X * endpointProfilePolynomial N 6 1
  let z := C b⁻¹ * X
  have hpdeg : P.natDegree ≤ m := (degreeOneLowPolynomial_natDegree γ c).trans hm
  have hRzero : R.coeff (m + 1) = 0 :=
    coeff_eq_zero_of_natDegree_lt ((reverseScaledPolynomial_natDegree P m a).trans_lt (Nat.lt_succ_self m))
  have hcross := reverseScaledPolynomial_leading_cross_bound P J hpdeg ha.le hb
    (sq_nonneg (N : ℝ)) (by positivity : 0 ≤ 24 * Real.exp 12)
    (endpointCutoffPolynomial_geometric_coeff hN)
  have hlocal : coefficientMass (P.comp (C (a * (N : ℝ) ^ 2 / b) * X)) ≤ 8 := by
    have h := degreeOneLowPolynomial_local_mass hγ hγ1.le hc (by positivity : 0 ≤ a * (N : ℝ) ^ 2 / b)
    have hz : a * (N : ℝ) ^ 2 / b ≤ 1 := by
      convert hZ using 1
      ring
    exact h.trans (by linarith)
  have hcross' : |(R * J.comp z).coeff (m + 1)| ≤
      (24 * Real.exp 12) * (N : ℝ) ^ 2 / b *
        (8 : ℝ) :=
    hcross.trans (mul_le_mul_of_nonneg_left hlocal (by positivity))
  have hlow : (C (A * a ^ γ) * R * (1 - J.comp z)).coeff (m + 1) =
      -(A * a ^ γ) * (R * J.comp z).coeff (m + 1) := by
    rw [mul_assoc, coeff_C_mul, mul_sub, mul_one, coeff_sub, hRzero]
    ring
  have hlowabs : |(C (A * a ^ γ) * R * (1 - J.comp z)).coeff (m + 1)| ≤
      A * a ^ γ * ((24 * Real.exp 12) * (N : ℝ) ^ 2 / b *
        (8 : ℝ)) := by
    rw [hlow, abs_mul, abs_neg, abs_of_nonneg (mul_nonneg hA (Real.rpow_nonneg ha.le γ))]
    exact mul_le_mul_of_nonneg_left hcross' (by positivity)
  have hhigh := highProfilePolynomial_leading_bound hN (by linarith : 0 < 1 - γ)
    (by linarith : 1 - γ ≤ 1) hf hf1 hω hω1
  have hintegral : |(endpointProfilePolynomial N 6 (1 - γ)).coeff 0| ≤
      Real.exp (Real.log 12 + 1) * (N : ℝ) ^ (2 * (1 - γ)) := by
    rw [endpointProfilePolynomial_coeff_zero hN,
      abs_of_pos (inv_pos.mpr (mul_pos (by linarith) (endpointIntegral_pos hN (by norm_num) (by linarith))))]
    exact endpointIntegral_inverse_weight_sharp hN (by norm_num) (by linarith) (by linarith)
  have hhighabs : |(C (B / b ^ (1 - γ)) * X ^ (m + 1) *
      (highProfilePolynomial N (1 - γ) f ω).comp z).coeff (m + 1)| ≤
        B / b ^ (1 - γ) * (coupledLocalizationConstant * (N : ℝ) ^ (2 * (1 - γ))) := by
    rw [shiftedPolynomial_leading_coeff, abs_mul,
      abs_of_nonneg (div_nonneg hB (Real.rpow_nonneg hb.le _))]
    exact mul_le_mul_of_nonneg_left hhigh (by positivity)
  have hrestabs : |(C (ω * (1 - B) / b ^ (1 - γ)) * X ^ (m + 1) *
      (endpointProfilePolynomial N 6 (1 - γ)).comp z).coeff (m + 1)| ≤
        (ω * (1 - B) / b ^ (1 - γ)) *
          (Real.exp (Real.log 12 + 1) * (N : ℝ) ^ (2 * (1 - γ))) := by
    rw [shiftedPolynomial_leading_coeff, abs_mul,
      abs_of_nonneg (div_nonneg (mul_nonneg hω (sub_nonneg.mpr hB1)) (Real.rpow_nonneg hb.le _))]
    exact mul_le_mul_of_nonneg_left hintegral
      (div_nonneg (mul_nonneg hω (sub_nonneg.mpr hB1)) (Real.rpow_nonneg hb.le _))
  rw [degreeOneCoupledPolynomial_reverse hm hγ hc0 ha.le]
  change |((C (A * a ^ γ) * R * (1 - J.comp z) +
    C (B / b ^ (1 - γ)) * X ^ (m + 1) * (highProfilePolynomial N (1 - γ) f ω).comp z) +
    C (ω * (1 - B) / b ^ (1 - γ)) * X ^ (m + 1) * (endpointProfilePolynomial N 6 (1 - γ)).comp z).coeff (m + 1)| ≤ _
  rw [coeff_add, coeff_add]
  exact ((abs_add_le _ _).trans (add_le_add_right (abs_add_le _ _) _)).trans
    (add_le_add (add_le_add hlowabs hhighabs) hrestabs)

def degreeOneLeadingCoefficientConstant : ℝ :=
  8 * (24 * Real.exp 12) + coupledLocalizationConstant + Real.exp (Real.log 12 + 1)

lemma degreeOneLeadingCoefficientConstant_pos : 0 < degreeOneLeadingCoefficientConstant := by
  have hC : 0 < coupledLocalizationConstant := Real.exp_pos _
  unfold degreeOneLeadingCoefficientConstant
  positivity

/-- Uniform leading coefficient in count units for the actual degree-one completed branch. -/
theorem degreeOneCoupledPolynomial_leading_count_bound {N m : ℕ} (hm : 1 ≤ m) (hN : 0 < N)
    {γ c a b n f A B ω : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 < a) (hb : 0 < b) (hn : 0 < n)
    (hc : c ∈ Set.Ioo (γ / (1 + γ)) 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1)
    (hZ : (N : ℝ) ^ 2 * (a / b) ≤ 1) :
    |n ^ (-(1 - γ)) * (degreeOneCoupledPolynomial N m γ (c * a * (1 + γ) / γ) b f ω A B).coeff (m + 1)| ≤
      degreeOneLeadingCoefficientConstant * ((N : ℝ) ^ 2 / (n * b)) ^ (1 - γ) := by
  let F := ((N : ℝ) ^ 2 / (n * b)) ^ (1 - γ)
  let T := a * (N : ℝ) ^ 2 / b
  have hN0 : 0 < (N : ℝ) := by exact_mod_cast hN
  have hT : 0 < T := by dsimp [T]; positivity
  have hT1 : T ≤ 1 := by
    convert hZ using 1
    dsimp [T]
    ring
  have hTpow : T ^ γ ≤ 1 := Real.rpow_le_one hT.le hT1 hγ.le
  have hF : 0 ≤ F := by dsimp [F]; positivity
  have hnPow : 0 < n ^ (-(1 - γ)) := Real.rpow_pos_of_pos hn _
  have hbase := degreeOneCoupledPolynomial_leading_bound hm hN hγ hγ1 ha hb hc hf hf1 hA hB hB1 hω hω1 hZ
  have hcross : n ^ (-(1 - γ)) * (A * a ^ γ * ((24 * Real.exp 12) * (N : ℝ) ^ 2 / b * 8)) =
      (8 * (24 * Real.exp 12) * A) * F * T ^ γ := by
    have h := fractional_endpoint_leading_identity (by norm_num : (0 : ℝ) < 1) (sq_pos_of_pos hN0) ha hb hn (γ := γ)
    simp only [Real.one_rpow, mul_one, one_mul] at h
    have hT' : (N : ℝ) ^ 2 * a / b = T := by dsimp [T]; ring
    rw [hT'] at h
    convert congrArg (fun v : ℝ => (8 * (24 * Real.exp 12) * A) * v) h using 1 <;> ring
  have hhigh : n ^ (-(1 - γ)) *
      (B / b ^ (1 - γ) * (coupledLocalizationConstant * (N : ℝ) ^ (2 * (1 - γ)))) = B * coupledLocalizationConstant * F := by
    have h := endpoint_leading_count_factor hN hb hn (δ := 1 - γ)
    convert congrArg (fun v : ℝ => (B * coupledLocalizationConstant) * v) h using 1
    ring
  have hrest : n ^ (-(1 - γ)) * ((ω * (1 - B) / b ^ (1 - γ)) *
      (Real.exp (Real.log 12 + 1) * (N : ℝ) ^ (2 * (1 - γ)))) =
        (ω * (1 - B) * Real.exp (Real.log 12 + 1)) * F := by
    have h := endpoint_leading_count_factor hN hb hn (δ := 1 - γ)
    convert congrArg (fun v : ℝ => (ω * (1 - B) * Real.exp (Real.log 12 + 1)) * v) h using 1
    ring
  rw [abs_mul, abs_of_pos hnPow]
  apply (mul_le_mul_of_nonneg_left hbase hnPow.le).trans
  rw [mul_add, mul_add, hcross, hhigh, hrest]
  have hproduct : A * T ^ γ ≤ 1 := (mul_le_of_le_one_right hA hTpow).trans hA1
  have hleft := mul_le_mul_of_nonneg_left hproduct (by positivity : 0 ≤ 8 * (24 * Real.exp 12) * F)
  have hmiddle := mul_le_mul_of_nonneg_right hB1 (show 0 ≤ coupledLocalizationConstant * F from
    mul_nonneg (Real.exp_pos _).le hF)
  have hwproduct : ω * (1 - B) ≤ 1 :=
    (mul_le_of_le_one_right hω (by linarith : 1 - B ≤ 1)).trans hω1.le
  have hlast := mul_le_mul_of_nonneg_right hwproduct (mul_nonneg (Real.exp_pos (Real.log 12 + 1)).le hF)
  unfold degreeOneLeadingCoefficientConstant
  nlinarith

/-- Source CC7 on the completed degree-one arm. -/
theorem degreeOneCoupledPolynomial_leading_count_uniform {N m : ℕ} (hm : 1 ≤ m) (hN : 0 < N)
    {γ c a b n f A B ω L Cscale : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 < a) (hb : 0 < b) (hn : 0 < n)
    (hc : c ∈ Set.Ioo (γ / (1 + γ)) 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1)
    (hZ : (N : ℝ) ^ 2 * (a / b) ≤ 1)
    (hL : 0 < L) (hC : 0 < Cscale) (hscale : (N : ℝ) ^ 2 / (n * b) ≤ Cscale * L) :
    |n ^ (-(1 - γ)) * (degreeOneCoupledPolynomial N m γ (c * a * (1 + γ) / γ) b f ω A B).coeff (m + 1)| ≤
      (degreeOneLeadingCoefficientConstant * max 1 Cscale) * (L / (1 - γ)) ^ (1 - γ) := by
  have hδ : 0 < 1 - γ := by linarith
  have hδ1 : 1 - γ ≤ 1 := by linarith
  have hbase := degreeOneCoupledPolynomial_leading_count_bound hm hN hγ hγ1 ha hb hn hc hf hf1
    hA hA1 hB hB1 hω hω1 hZ
  have hcpow : Cscale ^ (1 - γ) ≤ max 1 Cscale := by
    by_cases hC1 : Cscale ≤ 1
    · exact (Real.rpow_le_one hC.le hC1 hδ.le).trans (le_max_left _ _)
    · have h := Real.rpow_le_rpow_of_exponent_le (by linarith : 1 ≤ Cscale) hδ1
      rw [Real.rpow_one] at h
      exact h.trans (le_max_right _ _)
  have hLdiv : L ≤ L / (1 - γ) := by apply (le_div_iff₀ hδ).mpr; nlinarith
  have hpower : ((N : ℝ) ^ 2 / (n * b)) ^ (1 - γ) ≤ max 1 Cscale * (L / (1 - γ)) ^ (1 - γ) := by
    apply (Real.rpow_le_rpow (by positivity) hscale hδ.le).trans
    rw [Real.mul_rpow hC.le hL.le]
    exact mul_le_mul hcpow (Real.rpow_le_rpow hL.le hLdiv hδ.le) (by positivity) (by positivity)
  apply hbase.trans
  apply (mul_le_mul_of_nonneg_left hpower degreeOneLeadingCoefficientConstant_pos.le).trans_eq
  ring

end Renyi
