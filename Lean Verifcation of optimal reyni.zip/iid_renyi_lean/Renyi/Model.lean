import Renyi.Normalization
import Mathlib.MeasureTheory.Measure.ProbabilityMeasure

/-!
# The statistical model and the uniform minimax statements

`UniformMinimaxClaim` below states the finite-order minimax result.
`FullIIDVerification.iid_renyi_full_verified` proves it together with the
min-entropy endpoint. This model module defines the statements separately
from their proofs.

The estimator may randomize and may output any real number. No finite-output
or deterministic-estimator restriction is imposed.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory

namespace Renyi

/-- A probability vector on the fixed labeled alphabet `Fin k`. -/
structure Simplex (k : ℕ) where
  mass : Fin k → ℝ
  nonneg : ∀ i, 0 ≤ mass i
  normalized : ∑ i, mass i = 1

/-- The ordered sample space of exactly `n` observations. -/
abbrev Sample (k n : ℕ) := Fin n → Fin k

/-- Independence and identical distribution are specified by the product mass. -/
def iidMass {k : ℕ} (p : Simplex k) (n : ℕ) (x : Sample k n) : ℝ :=
  ∏ j, p.mass (x j)

theorem iidMass_nonneg {k n : ℕ} (p : Simplex k) (x : Sample k n) :
    0 ≤ iidMass p n x :=
  Finset.prod_nonneg (fun j _ => p.nonneg (x j))

/-- The i.i.d. observation law really has total mass one. -/
theorem iidMass_sum {k : ℕ} (p : Simplex k) (n : ℕ) :
    ∑ x : Sample k n, iidMass p n x = 1 := by
  have h := Finset.prod_univ_sum (ι := Fin n)
    (fun _ => (Finset.univ : Finset (Fin k))) (fun _ i => p.mass i)
  simpa [iidMass, p.normalized] using h.symm

def powerSum {k : ℕ} (p : Simplex k) (α : ℝ) : ℝ :=
  ∑ i, p.mass i ^ α

def entropy {k : ℕ} (p : Simplex k) (α : ℝ) : ℝ :=
  entropyFromPower (α - 1) (powerSum p α)

/-- A probability distribution over real outputs for each possible sample. -/
abbrev Estimator (k n : ℕ) := Sample k n → ProbabilityMeasure ℝ

/-- Probability of absolute error strictly greater than epsilon. -/
def errorProbability {k n : ℕ} (p : Simplex k) (α ε : ℝ)
    (est : Estimator k n) : ℝ :=
  ∑ x, iidMass p n x *
    (est x {z : ℝ | ε < |z - entropy p α|} : ℝ)

theorem errorProbability_nonneg {k n : ℕ} (p : Simplex k) (α ε : ℝ)
    (est : Estimator k n) : 0 ≤ errorProbability p α ε est := by
  apply Finset.sum_nonneg
  intro x _
  exact mul_nonneg (iidMass_nonneg p x) (NNReal.coe_nonneg _)

theorem errorProbability_le_one {k n : ℕ} (p : Simplex k) (α ε : ℝ)
    (est : Estimator k n) : errorProbability p α ε est ≤ 1 := by
  calc
    errorProbability p α ε est ≤ ∑ x : Sample k n, iidMass p n x * 1 := by
      apply Finset.sum_le_sum
      intro x _
      apply mul_le_mul_of_nonneg_left _ (iidMass_nonneg p x)
      exact_mod_cast (est x).apply_le_one {z : ℝ | ε < |z - entropy p α|}
    _ = 1 := by simpa only [mul_one] using iidMass_sum p n

/-- Achievability with failure probability at most one third, uniformly in p. -/
def Achievable (k n : ℕ) (α ε : ℝ) : Prop :=
  ∃ est : Estimator k n, ∀ p : Simplex k, errorProbability p α ε est ≤ 1 / 3

def fractionalPart (α : ℝ) : ℝ := α - (⌊α⌋ : ℤ)

def rootQSquared (k : ℕ) (α ε : ℝ) : ℝ :=
  let β := α - 1
  let γ := fractionalPart α
  let δ := 1 - γ
  let h := γ * δ
  let Ψ := γ ^ (1 + 1 / δ) * δ ^ (1 + 1 / γ)
  Ψ / (α ^ (2 : ℕ) * β ^ (2 : ℕ)) *
    Real.exp (Real.log k / α - (2 * ε * β) / h)

/-- The root formula is intended for noninteger `1 < alpha < log k`.
Nonemptiness is proved in `Renyi.Root`; attainment and unique crossing
are proved in `Renyi.RootCharacterization`. -/
def rootMultiplier (k : ℕ) (α ε : ℝ) : ℝ :=
  let γ := fractionalPart α
  let h := γ * (1 - γ)
  sInf {x : ℝ | 1 ≤ x ∧ 1 ≤
    (α * h / (α - 1)) * x ^ α *
      max (1 + Real.log (x * (1 + Real.log x) / rootQSquared k α ε)) 0}

/-- The requested extended multiplier, with the high-order branch first. -/
def extendedMultiplier (k : ℕ) (α ε : ℝ) : ℝ := by
  classical
  exact if Real.log k ≤ α then
    (Real.log k / α) * (k : ℝ) ^ (1 / α)
  else if ∃ r : ℕ, α = (r : ℝ) then
    max 1 ((2 * ε * α) ^ (-1 / α))
  else rootMultiplier k α ε

def rate (k : ℕ) (α ε : ℝ) : ℝ :=
  α * (k : ℝ) ^ (1 - 1 / α) * extendedMultiplier k α ε

/-- The high-order branch gives exactly k log k. This is algebra only. -/
theorem rate_high_order {k : ℕ} {α ε : ℝ} (hk : 0 < k)
    (hα : 0 < α) (hhigh : Real.log k ≤ α) :
    rate k α ε = (k : ℝ) * Real.log k := by
  have hkR : 0 < (k : ℝ) := by exact_mod_cast hk
  have hpow : (k : ℝ) ^ (1 - 1 / α) * (k : ℝ) ^ (1 / α) = k := by
    rw [← Real.rpow_add hkR]
    ring_nf
    exact Real.rpow_one _
  unfold rate extendedMultiplier
  rw [if_pos hhigh]
  calc
    α * (k : ℝ) ^ (1 - 1 / α) *
        (Real.log k / α * (k : ℝ) ^ (1 / α)) =
        Real.log k * ((k : ℝ) ^ (1 - 1 / α) * (k : ℝ) ^ (1 / α)) := by
          field_simp
    _ = (k : ℝ) * Real.log k := by rw [hpow]; ring

/-- The entire finite-order minimax statement.

For each fixed accuracy, the constants and alphabet cutoff are uniform over
all real orders greater than one. Both existence of a good estimator and
impossibility below a constant multiple of the rate are demanded.

The proof is `iid_renyi_uniform_minimax_verified` in `FullIIDVerification`.
-/
def UniformMinimaxClaim : Prop :=
  ∀ ε : ℝ, 0 < ε → ε < 1 / 2 →
    ∃ c C : ℝ, ∃ k₀ : ℕ,
      0 < c ∧ 0 < C ∧
      ∀ k : ℕ, k₀ ≤ k → 2 < Real.log k →
        ∀ α : ℝ, 1 < α →
          (∃ n : ℕ, (n : ℝ) ≤ C * rate k α ε ∧ Achievable k n α ε) ∧
          (∀ n : ℕ, Achievable k n α ε → c * rate k α ε ≤ (n : ℝ))

/-- Min-entropy uses the largest probability mass. -/
def minEntropy {k : ℕ} (p : Simplex k) : ℝ :=
  -Real.log (sSup (Set.range p.mass))

def MinEntropyAchievable (k n : ℕ) (ε : ℝ) : Prop :=
  ∃ est : Estimator k n, ∀ p : Simplex k,
    (∑ x, iidMass p n x *
      (est x {z : ℝ | ε < |z - minEntropy p|} : ℝ)) ≤ 1 / 3

/-- Min-entropy endpoint, proved by `Renyi.min_entropy_minimax_verified`. -/
def MinEntropyMinimaxClaim : Prop :=
  ∀ ε : ℝ, 0 < ε → ε < 1 / 2 →
    ∃ c C : ℝ, ∃ k₀ : ℕ,
      0 < c ∧ 0 < C ∧
      ∀ k : ℕ, k₀ ≤ k → 2 < Real.log k →
        (∃ n : ℕ, (n : ℝ) ≤ C * ((k : ℝ) * Real.log k) ∧
          MinEntropyAchievable k n ε) ∧
        (∀ n : ℕ, MinEntropyAchievable k n ε →
          c * ((k : ℝ) * Real.log k) ≤ (n : ℝ))

/-- Both finite orders and min-entropy, proved by `iid_renyi_full_verified`. -/
def FullManuscriptClaim : Prop := UniformMinimaxClaim ∧ MinEntropyMinimaxClaim

end Renyi
