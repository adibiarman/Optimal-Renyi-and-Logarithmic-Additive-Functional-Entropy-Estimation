import Renyi.DegreeOnePolynomialCoefficients

/-! Low-degree coefficients of the completed polynomial. -/
noncomputable section
open Polynomial
namespace Renyi

lemma degreeOneCoupledPolynomial_low_coeff {N m j : ℕ} (hm : 1≤m) (hj : j≤m)
    {γ a b c f A B ω : ℝ} (hγ : 0<γ) (hc : 0<c) (ha : 0≤a) :
    (degreeOneCoupledPolynomial N m γ (c*a*(1+γ)/γ) b f ω A B).coeff j=
      (C (A*a^γ)*reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a*
        (1-(X*endpointProfilePolynomial N 6 1).comp (C b⁻¹*X))).coeff j := by
  have hj' : ¬m+1≤j := by omega
  rw [degreeOneCoupledPolynomial_reverse hm hγ hc ha]
  simp only [coeff_add,mul_assoc,coeff_C_mul,coeff_X_pow_mul',if_neg hj',mul_zero,add_zero]

theorem degreeOneCoupledPolynomial_low_coefficient_bound {N m j : ℕ}
    (hN : 0 < N) (hm : 1≤m) (hj : j ≤ m)
    {γ a b c f A B ω Z : ℝ} (hγ : 0 < γ) (hγ1 : γ ≤ 1)
    (ha : 0 < a) (hb : 0 < b) (hc : c∈Set.Ioo (γ/(1+γ)) 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hZ : (N:ℝ)^2*(a/b) ≤ Z) :
    |(degreeOneCoupledPolynomial N m γ (c*a*(1+γ)/γ) b f ω A B).coeff j| * a^j ≤
      a^((m:ℝ)+γ)*(8)*
        (1+24*Z*Real.exp (12*Real.sqrt Z)) := by
  let P := C (A*a^γ)*reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a *
    (1-(X*endpointProfilePolynomial N 6 1).comp (C b⁻¹*X))
  have hcoeff := abs_coeff_le_coefficientMass (P.comp (C a*X)) j
  rw [comp_C_mul_X_coeff, abs_mul, abs_of_nonneg (pow_nonneg ha.le j)] at hcoeff
  have hrev := reverseScaledPolynomial_comp_coefficientMass (degreeOneLowPolynomial γ c)
    ((degreeOneLowPolynomial_natDegree γ c).trans hm) ha.le (le_refl a)
  have hcut := endpointCutoffPolynomial_local_mass_uniform hN (by norm_num : 6≤6)
    (div_nonneg ha.le hb.le) hZ
  norm_num only [Nat.cast_ofNat, show (2:ℝ)*6=12 by norm_num] at hcut
  have hcut' : coefficientMass (1-(X*endpointProfilePolynomial N 6 1).comp (C (a/b)*X)) ≤
      1+24*Z*Real.exp (12*Real.sqrt Z) := by
    exact (coefficientMass_sub_le _ _).trans (by simpa using add_le_add_left hcut 1)
  have hlow := degreeOneLowPolynomial_coefficientMass hγ hγ1 hc
  have hfirst : coefficientMass ((C (A*a^γ)*reverseScaledPolynomial
      (degreeOneLowPolynomial γ c) m a).comp (C a*X)) ≤
      a^((m:ℝ)+γ)*(8) := by
    rw [mul_comp, C_comp, coefficientMass_C_mul,
      abs_of_nonneg (mul_nonneg hA (Real.rpow_nonneg ha.le γ))]
    have hm := mul_le_mul_of_nonneg_left hrev (mul_nonneg hA (Real.rpow_nonneg ha.le γ))
    have hm2 := mul_le_mul_of_nonneg_left hlow (show 0 ≤ a^γ*a^m by positivity)
    have hA' := mul_le_of_le_one_left
      (show 0 ≤ a^γ*(coefficientMass (degreeOneLowPolynomial γ c)*a^m) by
        exact mul_nonneg (Real.rpow_nonneg ha.le γ) (mul_nonneg (coefficientMass_nonneg _) (pow_nonneg ha.le m))) hA1
    have hid : a^γ*a^m=a^((m:ℝ)+γ) := by
      rw [←Real.rpow_natCast, ←Real.rpow_add ha]
      congr 1
      ring
    apply hm.trans
    calc
      _ = A*(a^γ*(coefficientMass (degreeOneLowPolynomial γ c)*a^m)) := by ring
      _ ≤ a^γ*(coefficientMass (degreeOneLowPolynomial γ c)*a^m) := hA'
      _ = (a^γ*a^m)*coefficientMass (degreeOneLowPolynomial γ c) := by ring
      _ ≤ _ := by simpa only [hid] using hm2
  have hmass : coefficientMass (P.comp (C a*X)) ≤
      a^((m:ℝ)+γ)*(8)*
        (1+24*Z*Real.exp (12*Real.sqrt Z)) := by
    dsimp only [P]
    rw [mul_comp, sub_comp, one_comp, comp_assoc, scale_comp_scale]
    exact (coefficientMass_mul_le _ _).trans
      (mul_le_mul hfirst hcut' (coefficientMass_nonneg _) (by positivity))
  rw [degreeOneCoupledPolynomial_low_coeff hm hj hγ ((div_pos hγ (by positivity)).trans hc.1) ha.le]
  exact hcoeff.trans hmass


/-- The same fixed exponential low-count budget holds for the completed degree-one arm. -/
theorem degreeOneCoupledPolynomial_low_coefficient_exponential {N m j : ℕ}
    (hN : 0<N) (hm : 1≤m) (hj : j≤m) {γ a b c f A B ω : ℝ}
    (hγ : 0<γ) (hγ1 : γ≤1) (ha : 0<a) (hb : 0<b)
    (hc : c∈Set.Ioo (γ/(1+γ)) 1) (hA : 0≤A) (hA1 : A≤1)
    (hZ : (N:ℝ)^2*(a/b)≤1) :
    |(degreeOneCoupledPolynomial N m γ (c*a*(1+γ)/γ) b f ω A B).coeff j|≤
      coupledLowCoefficientConstant^(m+1)*a^((m:ℝ)+γ-(j:ℝ)) := by
  have hh := degreeOneCoupledPolynomial_low_coefficient_bound (f:=f) (B:=B) (ω:=ω)
    hN hm hj hγ hγ1 ha hb hc hA hA1 hZ
  simp only [Real.sqrt_one,mul_one] at hh
  have hsmall : (8:ℝ)≤100^(m+1) := (by norm_num : (8:ℝ)≤100).trans
    (le_self_pow₀ (by norm_num : (1:ℝ)≤100) (by omega : m+1≠0))
  have hC : 1≤1+24*Real.exp 12 := by linarith only [Real.exp_pos (12:ℝ)]
  have hpow := le_self_pow₀ hC (by omega : m+1≠0)
  have hbudget := mul_le_mul hsmall hpow (by positivity : 0≤1+24*Real.exp 12)
    (by positivity : 0≤(100:ℝ)^(m+1))
  rw [←mul_pow] at hbudget
  have hfinal : |(degreeOneCoupledPolynomial N m γ (c*a*(1+γ)/γ) b f ω A B).coeff j| *a^j≤
      a^((m:ℝ)+γ)*coupledLowCoefficientConstant^(m+1) := by
    apply hh.trans
    have hmul := mul_le_mul_of_nonneg_left hbudget (Real.rpow_nonneg ha.le ((m:ℝ)+γ))
    change _≤a^((m:ℝ)+γ)*(100*(1+24*Real.exp 12))^(m+1)
    nlinarith only [hmul]
  have hd := (le_div_iff₀ (pow_pos ha j)).mpr hfinal
  apply hd.trans_eq
  rw [Real.rpow_sub ha,Real.rpow_natCast]
  ring

/-- Complete source low-degree bound, with no omitted ℓ=1 branch. -/
theorem completedCoupledPolynomial_low_coefficient_exponential {ℓ N m j : ℕ}
    (hℓ : 0<ℓ) (hN : 0<N) (hm : 1≤m) (hdegree : 4*(ℓ-1)≤m) (hj : j≤m)
    {γ a b c fL f A B ω : ℝ} (hγ : 0<γ) (hγ1 : γ≤1) (ha : 0<a) (hb : 0<b)
    (hc : c∈Set.Ioo (γ/(1+γ)) 1) (hfL : 0≤fL) (hfL1 : fL<1)
    (hA : 0≤A) (hA1 : A≤1) (hZ : (N:ℝ)^2*(a/b)≤1) :
    |(completedCoupledPolynomial ℓ N m γ a b c fL f A B ω).coeff j|≤
      coupledLowCoefficientConstant^(m+1)*a^((m:ℝ)+γ-(j:ℝ)) := by
  unfold completedCoupledPolynomial
  split
  · exact degreeOneCoupledPolynomial_low_coefficient_exponential hN hm hj hγ hγ1 ha hb hc hA hA1 hZ
  · exact coupledQPolynomial_low_coefficient_exponential hℓ hN hdegree hj hγ hγ1 ha hb hfL hfL1 hA hA1 hZ

end Renyi
