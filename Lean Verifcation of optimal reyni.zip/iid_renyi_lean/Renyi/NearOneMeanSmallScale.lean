import Renyi.NearOneMeanCalibration

/-! The final D-last mean calibration at the actual root scale. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 500000

theorem simplex_small_scale_power {k : ℕ} (hk : 0<k) (p : Simplex k)
    {alpha t r : ℝ} (ha : 1≤alpha) (ht : 0≤t) (hr : 0≤r) (hr1 : r≤1)
    (hkt : (k:ℝ)*t≤r) :
    (k:ℝ)*t^alpha≤r*(∑i,p.mass i^alpha) := by
  have hk0 : (0:ℝ)<k := by exact_mod_cast hk
  have hpow := (Real.rpow_le_rpow (mul_nonneg hk0.le ht) hkt (by linarith : 0≤alpha)).trans
    (Real.rpow_le_self_of_le_one hr hr1 ha)
  have hJ := simplex_powerSum_uniform_lower hk p ha
  have hid : ((k:ℝ)*t)^alpha*(k:ℝ)^(1-alpha)=(k:ℝ)*t^alpha := by
    rw [Real.mul_rpow hk0.le ht]
    calc
      _=((k:ℝ)^alpha*(k:ℝ)^(1-alpha))*t^alpha := by ring
      _=_ := by rw [←Real.rpow_add hk0,show alpha+(1-alpha)=1 by ring,Real.rpow_one]
  rw [←hid]
  exact mul_le_mul hpow hJ (Real.rpow_nonneg hk0.le _) hr

/-- All mean errors of the actual near-one construction fit into a fixed
beta*P budget after the sample multiplier is chosen last. -/
theorem actual_near_one_expected_mean_calibrated
    {eps cb lambda CL cmin q Q M cw f cu u0 B eta : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hf : 0≤f) (hf1 : f≤1)
    (hcu : 0≤cu) (hu0 : 0<u0) (hB : 16≤B) (hCLB : 2*B≤cb*CL)
    (heta : 0<eta) (hlarge : Real.exp (-B/2)≤eta) :
    ∃ cp0 : ℝ, 1≤cp0 ∧ ∀ cp : ℝ, cp0≤cp → ∀ cL : ℝ, 0<cL →
      ∃ D0 : ℝ, 1≤D0 ∧ ∀ (k N : ℕ) (alpha Ch D c : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → D0≤D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) → ∀ p : Simplex k,
      |actualNearOneExpectedMean N alpha eps Ch D cb lambda CL cL c M cw f cu u0 cp B 0 p-
        upperOmega k alpha eps Ch cw*(∑i,p.mass i^alpha)|≤
          (2*cu+4*eta)*(alpha-1)*(∑i,p.mass i^alpha) := by
  obtain ⟨K,cp0,hK,hcp0,hmean⟩ := actual_near_one_expected_mean_uniform heps hcb hlambda hCL hcmin hq hQ hM hcw hcw1 hf hf1 hcu hu0 hB hCLB heta hlarge
  refine ⟨cp0,hcp0,?_⟩
  intro cp hcp cL hcL
  obtain ⟨Ct,ct,Ct',hCt,_hct,_hCt',hscale⟩ := near_one_scales_uniform
    (c:=1) heps hcb hlambda hCL hcL (by norm_num) hq hQ
  let r := min 1 (eta/K)
  have hr : 0<r := lt_min (by norm_num) (div_pos heta hK)
  have hr1 : r≤1 := min_le_left _ _
  have hrEta : r≤eta/K := min_le_right _ _
  let D0 := max 1 (Ct/r)
  refine ⟨D0,le_max_left _ _,?_⟩
  intro k N alpha Ch D c hk ha ha1 hCh hD0 hc hc1 hNlo hNhi p
  have hD1 : 1≤D := (le_max_left _ _).trans hD0
  have hD : 0<D := zero_lt_one.trans_le hD1
  have hDr : Ct/r≤D := (le_max_right _ _).trans hD0
  have hCtD : Ct/D≤r := (div_le_iff₀ hD).mpr (by
    have hh := (div_le_iff₀ hr).mp hDr
    nlinarith only [hh])
  have hβ : 0<alpha-1 := sub_pos.mpr ha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order ha ha1).2];exact hβ
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order ha ha1).2];linarith only [ha1]
  have hb := upperB_pos (ε:=eps) hk ha hg hg1 hD hcb hCL hcL
  have hL := upperDegree_pos ha hCL hcL (one_le_rootMultiplier (k:=k) (ε:=eps) ha hg hg1)
  have hNr : 0<(N:ℝ) := (mul_pos hq hL).trans_le hNlo
  let t := upperB k alpha eps D cb CL cL/(N:ℝ)^2
  have ht : 0<t := div_pos hb (sq_pos_of_pos hNr)
  have hsc := (hscale k alpha Ch D N hk ha ha1 hCh hD hNlo hNhi).2.1
  have hbase := simplex_small_scale_power hk p ha.le ht.le hr.le hr1 (hsc.trans hCtD)
  have hKr : K*r≤eta := by
    have hh := (le_div_iff₀ hK).mp hrEta
    nlinarith only [hh]
  have hP : 0≤∑i,p.mass i^alpha := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (p.nonneg i) _)
  have hsmall : (k:ℝ)*K*(alpha-1)*t^alpha≤eta*(alpha-1)*(∑i,p.mass i^alpha) := by
    have hh := mul_le_mul_of_nonneg_left hbase (show 0≤K*(alpha-1) by positivity)
    have hh' := mul_le_mul_of_nonneg_right hKr (mul_nonneg hβ.le hP)
    nlinarith only [hh,hh']
  have hh := hmean cp hcp cL hcL k N alpha Ch D c 0 hk ha ha1 hCh hD hc hc1 hNlo hNhi p
  simp only [abs_zero,zero_add] at hh
  exact hh.trans (by nlinarith only [hsmall])

end Renyi
