import Renyi.PoissonThinningLaw
import Renyi.FingerprintTransfer
import Renyi.GenericMixtureTesting

/-! Actual observation kernels and exceptional-event bounds for the lower experiment. -/
noncomputable section
open scoped BigOperators ENNReal NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- Bounded tests that agree outside a bad event differ by at most its probability. -/
theorem pmfExpectation_le_of_agreement {Ω : Type*} [MeasurableSpace Ω]
    [MeasurableSingletonClass Ω] (p : PMF Ω) (f g : Ω → ℝ) (bad : Set Ω)
    (hf0 : ∀ x, 0 ≤ f x) (hf1 : ∀ x, f x ≤ 1)
    (hg0 : ∀ x, 0 ≤ g x) (hg1 : ∀ x, g x ≤ 1)
    (heq : ∀ x, x ∉ bad → f x = g x) :
    pmfExpectation p f ≤ pmfExpectation p g + p.toMeasure.real bad := by
  classical
  have hs := (summable_bounded_test _ g (pmfReal_hasSum p).summable hg0 hg1).hasSum.add
    (pmf_event_real_hasSum p bad)
  apply le_trans _ hs.tsum_eq.le
  apply (summable_bounded_test _ f (pmfReal_hasSum p).summable hf0 hf1).tsum_le_tsum _ hs.summable
  intro x
  by_cases hx : x ∈ bad
  · have hb : f x ≤ g x + 1 := by linarith [hf1 x, hg0 x]
    simpa only [Set.indicator_of_mem hx, mul_one, mul_add] using
      mul_le_mul_of_nonneg_left hb (show 0 ≤ (p x).toReal from ENNReal.toReal_nonneg)
  · simp only [heq x hx, Set.indicator_of_notMem hx, mul_zero, add_zero, le_refl]

/-- The original Poisson record retains its stated Poisson length law. -/
theorem poissonCountableSamplePMF_length {κ : Type*} [Countable κ]
    [MeasurableSpace κ] [MeasurableSingletonClass κ]
    (b : ℝ≥0) (q : PMF κ) :
    (poissonCountableSamplePMF b q).map Sigma.fst = poissonPMF b := by
  rw [poissonCountableSamplePMF, PMF.map_bind]
  simp only [PMF.map_comp, Function.comp_def]
  change (poissonPMF b).bind (fun n => (iidCountablePMF q n).map (fun _ => n)) = _
  change (poissonPMF b).bind (fun n => (iidCountablePMF q n).map (Function.const _ n)) = _
  simp only [PMF.map_const, PMF.bind_pure]

/-- Alphabet overflow has exactly the original Poisson-length tail probability. -/
theorem poisson_record_overflow {κ : Type*} [Countable κ]
    [MeasurableSpace κ] [MeasurableSingletonClass κ]
    (b : ℝ≥0) (q : PMF κ) (k : ℕ) :
    (poissonCountableSamplePMF b q).toMeasure.real {x | k < x.1} =
      (poissonPMF b).toMeasure.real {n | k < n} := by
  have h := congrArg (fun p : PMF ℕ => p.toMeasure.real {n | k < n})
    (poissonCountableSamplePMF_length b q)
  dsimp only at h
  rw [← PMF.toMeasure_map _ _ (measurable_of_countable _)] at h
  simpa only [Measure.real, Measure.map_apply (measurable_of_countable _)
    (Set.to_countable {n : ℕ | k < n}).measurableSet] using h

/-- Below alphabet overflow, removing every unobserved coordinate preserves
exactly the common randomized labeling, ordering, and prefix kernel. -/
theorem thin_full_sample_kernel_eq {k : ℕ} (n : ℕ) (fallback : Sample k n)
    (x : PoissonMarkedSample ℕ) (hxk : x.1 ≤ k) :
    fullSampleKernel n fallback x = observedSampleKernel n fallback (thinPositiveRecord x) := by
  apply observed_full_sample_kernel_eq n fallback x (thinPositiveRecord x)
    (retainedEmbedding x.2) _ _ hxk
  · intro i
    exact (thinPositiveRecord_entry x i).symm
  · intro j hj
    exact (retainedEmbedding_covers x.2 j).mpr hj

/-- The observable positive-count experiment and the full latent-coordinate
experiment have the same test risk up to the single support-overflow event. -/
theorem visible_full_sample_test_le {k : ℕ} (b : ℝ≥0) (q : PMF ℕ)
    (n : ℕ) (fallback : Sample k n) (t : Sample k n → ℝ)
    (ht0 : ∀ x, 0 ≤ t x) (ht1 : ∀ x, t x ≤ 1) :
    pmfExpectation
      ((poissonCountableSamplePMF (b * positiveMarkMass q) (visibleMarkPMF q)).bind
        (observedSampleKernel n fallback)) t ≤
      pmfExpectation ((poissonCountableSamplePMF b q).bind
        (fullSampleKernel n fallback)) t +
      (poissonPMF b).toMeasure.real {Q | k < Q} := by
  rw [← poisson_thin_positive_law b q, PMF.bind_map]
  rw [pmfExpectation_bind _ _ t ht0 ht1, pmfExpectation_bind _ _ t ht0 ht1]
  rw [← poisson_record_overflow b q k]
  apply pmfExpectation_le_of_agreement
  · intro x; exact pmfExpectation_nonneg _ t ht0
  · intro x; exact pmfExpectation_le_one _ t ht0 ht1
  · intro x; exact pmfExpectation_nonneg _ t ht0
  · intro x; exact pmfExpectation_le_one _ t ht0 ht1
  · intro x hx
    have hxk : x.1 ≤ k := Nat.le_of_not_gt hx
    simp only [Function.comp_apply, ← thin_full_sample_kernel_eq n fallback x hxk]

/-- The actual mixed-count law: draw a weight atom, then its Poisson count. -/
def mixedPoissonMarkPMF {κ : Type*} (r : PMF κ) (z : κ → ℝ≥0)
    (theta : ℝ≥0) : PMF ℕ := r.bind (fun a => poissonPMF (theta * z a))

/-- For a fixed number of atoms, mixing all counts independently is equivalent
to drawing the iid atom array first and then its independent Poisson counts. -/
theorem iid_mixed_poisson_law {κ : Type*} [Countable κ]
    [MeasurableSpace κ] [MeasurableSingletonClass κ]
    (r : PMF κ) (z : κ → ℝ≥0) (theta : ℝ≥0) (n : ℕ) :
    iidCountablePMF (mixedPoissonMarkPMF r z theta) n =
      (iidCountablePMF r n).bind (fun atoms =>
        finitePoissonPMF (fun i => theta * z (atoms i))) := by
  exact coordinateCountablePMF_bind (fun _ : Fin n => r)
    (fun _ a => poissonPMF (theta * z a))

/-- The conditional independent-count experiment for a finite random atom record. -/
def countsGivenAtoms {κ : Type*} (z : κ → ℝ≥0) (theta : ℝ≥0)
    (x : PoissonMarkedSample κ) : PMF (PoissonMarkedSample ℕ) :=
  (finitePoissonPMF (fun i => theta * z (x.2 i))).map (fun c => ⟨x.1, c⟩)

/-- Exact identity between the original two-stage prior/count experiment and
the Poisson experiment with iid mixed-count marks. -/
theorem poisson_mixed_counts_law {κ : Type*} [Countable κ]
    [MeasurableSpace κ] [MeasurableSingletonClass κ]
    (b : ℝ≥0) (r : PMF κ) (z : κ → ℝ≥0) (theta : ℝ≥0) :
    poissonCountableSamplePMF b (mixedPoissonMarkPMF r z theta) =
      (poissonCountableSamplePMF b r).bind (countsGivenAtoms z theta) := by
  rw [poissonCountableSamplePMF, poissonCountableSamplePMF, PMF.bind_bind]
  congr 1
  funext n
  rw [iid_mixed_poisson_law, PMF.map_bind, PMF.bind_map]
  rfl

/-- The stronger original normalization deviation event, retaining the mass
lower bound needed for sample availability, has the same two-moment budget. -/
theorem compound_poisson_deviation_failure {L : ℕ}
    (b : ℝ≥0) (hb : 0 < (b : ℝ)) (p : Fin L → ℝ≥0)
    (hp : ∑ i, p i = 1) (z : Fin L → ℝ) (alpha A t u : ℝ)
    (hmean : ∑ i, (p i : ℝ) * z i = 1)
    (hpower : ∑ i, (p i : ℝ) * z i ^ alpha = A)
    (hA : 0 < A) (ht : 0 < t) (hu : 0 < u) :
    (poissonMarkedSamplePMF b p hp).toMeasure.real
      {x | t < |compoundPoissonAverage b z x - 1| ∨
        A * u < |compoundPoissonAverage b (fun i => z i ^ alpha) x -
          A * compoundPoissonAverage b z x|} ≤
      (∑ i, (p i : ℝ) * z i ^ 2) / ((b : ℝ) * t ^ 2) +
        (∑ i, (p i : ℝ) * (z i ^ alpha - A * z i) ^ 2) /
          ((b : ℝ) * A ^ 2 * u ^ 2) := by
  let π := Measure.pi (fun i => poissonMeasure (b * p i))
  let μ := (poissonMarkedSamplePMF b p hp).toMeasure
  let C : Fin L → (Fin L → ℕ) → ℝ := fun i c => (c i : ℝ)
  have hC (i : Fin L) : IdentDistrib (fun n : ℕ => (n : ℝ)) (C i)
      (poissonMeasure (b * p i)) π := by
    have hid : IdentDistrib id (fun c : Fin L → ℕ => c i)
        (poissonMeasure (b * p i)) π :=
      ⟨measurable_id.aemeasurable, (measurable_pi_apply i).aemeasurable, by
        rw [Measure.map_id]
        exact (measurePreserving_eval (fun i => poissonMeasure (b * p i)) i).map_eq.symm⟩
    exact hid.comp (measurable_of_countable (fun n : ℕ => (n : ℝ)))
  have hi : iIndepFun C π := by
    exact (iIndepFun_pi (fun _ => measurable_id.aemeasurable)).comp
      (fun _ (n : ℕ) => (n : ℝ))
      (fun _ => measurable_of_countable (fun n : ℕ => (n : ℝ)))
  have hpair : Pairwise (fun i j => IndepFun (C i) (C j) π) :=
    fun _ _ hij => hi.indepFun hij
  have hbound := atomic_poisson_normalization_probability
    (μ := π) b hb p C z alpha A t u hC hpair hmean hpower hA ht hu
  have hmap : μ.map (fun x : PoissonMarkedSample (Fin L) => markHistogram x.2) = π := by
    change (poissonMarkedSamplePMF b p hp).toMeasure.map _ = π
    rw [PMF.toMeasure_map _ _ (measurable_of_countable _),
      poissonMarkedSample_histogram, finitePoissonPMF, Measure.toPMF_toMeasure]
  let B := {c : Fin L → ℕ | t < |poissonAtomAverage b C z c - 1| ∨
    A * u < |poissonAtomAverage b C (fun i => z i ^ alpha) c - A * poissonAtomAverage b C z c|}
  have hevent : π B = μ {x | t < |compoundPoissonAverage b z x - 1| ∨
      A * u < |compoundPoissonAverage b (fun i => z i ^ alpha) x - A * compoundPoissonAverage b z x|} := by
    rw [← hmap, Measure.map_apply (measurable_of_countable _)
      (Set.to_countable B).measurableSet]
    congr 1
    ext x
    simp only [Set.mem_preimage, Set.mem_setOf_eq, B, C,
      poissonAtomAverage, compoundPoissonAverage, sum_histogram]
  change (μ _).toReal ≤ _
  rw [← hevent]
  exact hbound

/-- Conditional counts and uniform random labels may be drawn in either order. -/
theorem conditional_full_sample_law {κ : Type*} {k : ℕ}
    (z : κ → ℝ≥0) (theta : ℝ≥0) (x : PoissonMarkedSample κ)
    (n : ℕ) (fallback : Sample k n) (hxk : x.1 ≤ k) :
    (countsGivenAtoms z theta x).bind (fullSampleKernel n fallback) =
      (uniformInjection x.1 k hxk).bind (fun e =>
        (finitePoissonPMF (fun i => theta * z (x.2 i))).bind
          (fun c => orderedCountPrefix n fallback (pushCounts e c))) := by
  rw [countsGivenAtoms, PMF.bind_map]
  change (finitePoissonPMF (fun i => theta * z (x.2 i))).bind
    (fun c => fullSampleKernel n fallback ⟨x.1, c⟩) = _
  simp only [fullSampleKernel, dif_pos hxk]
  exact PMF.bind_comm (finitePoissonPMF (fun i => theta * z (x.2 i)))
    (uniformInjection x.1 k hxk)
    (fun c e => orderedCountPrefix n fallback (pushCounts e c))

/-- The conditional law of the observable reconstruction agrees with the full
weight-conditional law when the number of latent atoms fits the alphabet. -/
theorem conditional_observed_sample_law {κ : Type*} {k : ℕ}
    (z : κ → ℝ≥0) (theta : ℝ≥0) (x : PoissonMarkedSample κ)
    (n : ℕ) (fallback : Sample k n) (hxk : x.1 ≤ k) :
    (countsGivenAtoms z theta x).bind
        (fun c => observedSampleKernel n fallback (thinPositiveRecord c)) =
      (countsGivenAtoms z theta x).bind (fullSampleKernel n fallback) := by
  rw [countsGivenAtoms, PMF.bind_map, PMF.bind_map]
  congr 1
  funext c
  exact (thin_full_sample_kernel_eq n fallback ⟨x.1, c⟩ hxk).symm

/-- A conditional test-risk bound for the actual common observation kernel.
The iid test bound is evaluated on every explicit padded normalized weight
vector; the only extra term is the actual unavailable-prefix probability. -/
theorem conditional_observed_test_le {κ : Type*} {k : ℕ}
    (z : κ → ℝ≥0) (theta : ℝ≥0) (x : PoissonMarkedSample κ)
    (n : ℕ) (fallback : Sample k n) (hxk : x.1 ≤ k)
    (hw : 0 < ∑ i, z (x.2 i)) (t : Sample k n → ℝ)
    (ht0 : ∀ y, 0 ≤ t y) (ht1 : ∀ y, t y ≤ 1) {c : ℝ} (hc : 0 ≤ c)
    (hiid : ∀ e : Fin x.1 ↪ Fin k,
      pmfExpectation (iidMarkPMF
        (simplexNN (paddedSimplex e (fun i => (z (x.2 i) : ℝ))
          (fun i => (z (x.2 i)).coe_nonneg)
          (by
            have h : (0 : ℝ) < ((∑ i, z (x.2 i) : ℝ≥0) : ℝ) := by exact_mod_cast hw
            simpa only [NNReal.coe_sum] using h))) (simplexNN_sum _) n) t ≤ c) :
    pmfExpectation ((countsGivenAtoms z theta x).bind
        (fun c => observedSampleKernel n fallback (thinPositiveRecord c))) t ≤
      c + (poissonPMF (theta * ∑ i, z (x.2 i))).toMeasure.real {q | q < n} := by
  rw [conditional_observed_sample_law z theta x n fallback hxk,
    conditional_full_sample_law z theta x n fallback hxk,
    pmfExpectation_bind _ _ t ht0 ht1]
  have hbound (e : Fin x.1 ↪ Fin k) :=
    (labeled_weighted_counts_test_le e theta (fun i => z (x.2 i)) hw n fallback t ht0 ht1).trans
      (add_le_add_right (hiid e) _)
  letI : MeasurableSpace (Fin x.1 ↪ Fin k) := ⊤
  have h := pmfExpectation_le_of_good (uniformInjection x.1 k hxk) _ ∅
    (show 0 ≤ c + (poissonPMF (theta * ∑ i, z (x.2 i))).toMeasure.real {q | q < n} by
      exact add_nonneg hc ENNReal.toReal_nonneg)
    (fun _ => pmfExpectation_nonneg _ t ht0)
    (fun _ => pmfExpectation_le_one _ t ht0 ht1)
    (fun e _ => hbound e)
  simpa using h

/-- The actual iid law of a positively normalized atom record after a fixed injection. -/
def atomRecordIIDPMF {κ : Type*} {k : ℕ} (z : κ → ℝ≥0)
    (x : PoissonMarkedSample κ) (n : ℕ) (e : Fin x.1 ↪ Fin k)
    (hw : 0 < ∑ i, z (x.2 i)) : PMF (Sample k n) :=
  iidMarkPMF (simplexNN (paddedSimplex e (fun i => (z (x.2 i) : ℝ))
    (fun i => (z (x.2 i)).coe_nonneg) (by
      have h : (0 : ℝ) < ((∑ i, z (x.2 i) : ℝ≥0) : ℝ) := by exact_mod_cast hw
      simpa only [NNReal.coe_sum] using h))) (simplexNN_sum _) n

/-- On the retained normalization event, the unavailable-prefix cost is the
single exponential budget from the manuscript. -/
theorem atom_record_availability {κ : Type*} (b theta : ℝ≥0)
    (z : κ → ℝ≥0) (x : PoissonMarkedSample κ) (n : ℕ)
    (hS : (3 : ℝ) / 4 * b ≤ ∑ i, (z (x.2 i) : ℝ))
    (hn : (n : ℝ) ≤ (theta : ℝ) * b / 4) :
    (poissonPMF (theta * ∑ i, z (x.2 i))).toMeasure.real {q | q < n} ≤
      Real.exp (-(theta : ℝ) * b / 16) := by
  have hm := mul_le_mul_of_nonneg_left hS theta.coe_nonneg
  apply (poisson_prefix_shortfall (theta * ∑ i, z (x.2 i)) n (by
    simp only [NNReal.coe_mul, NNReal.coe_sum]
    nlinarith)).trans
  apply Real.exp_le_exp.mpr
  simp only [NNReal.coe_mul, NNReal.coe_sum]
  nlinarith

/-- Observation transfer with the two exceptional events paid exactly once.
The hypotheses refer to the explicit normalized iid laws on good weight
records. Both the count-law identity and all labeling/thinning kernels are
proved above; no observation-distance or testing certificate is assumed. -/
theorem observed_poisson_prior_test_le {κ : Type*} [Countable κ]
    [MeasurableSpace κ] [MeasurableSingletonClass κ] {k : ℕ}
    (b theta : ℝ≥0) (hb : 0 < (b : ℝ)) (r : PMF κ) (z : κ → ℝ≥0)
    (n : ℕ) (fallback : Sample k n) (t : Sample k n → ℝ)
    (ht0 : ∀ y, 0 ≤ t y) (ht1 : ∀ y, t y ≤ 1)
    (bad : Set (PoissonMarkedSample κ)) {c : ℝ} (hc : 0 ≤ c)
    (hn : (n : ℝ) ≤ (theta : ℝ) * b / 4)
    (hmass : ∀ x, x ∉ bad → (3 : ℝ) / 4 * b ≤ ∑ i, (z (x.2 i) : ℝ))
    (hiid : ∀ x, x ∉ bad → ∀ e : Fin x.1 ↪ Fin k,
      ∀ hw : 0 < ∑ i, z (x.2 i), pmfExpectation (atomRecordIIDPMF z x n e hw) t ≤ c) :
    let q := mixedPoissonMarkPMF r z theta
    pmfExpectation
      ((poissonCountableSamplePMF (b * positiveMarkMass q) (visibleMarkPMF q)).bind
        (observedSampleKernel n fallback)) t ≤
      c + (poissonCountableSamplePMF b r).toMeasure.real bad +
        (poissonPMF b).toMeasure.real {Q | k < Q} + Real.exp (-(theta : ℝ) * b / 16) := by
  dsimp only
  rw [← poisson_thin_positive_law b (mixedPoissonMarkPMF r z theta), PMF.bind_map,
    poisson_mixed_counts_law, PMF.bind_bind, pmfExpectation_bind _ _ t ht0 ht1]
  let μ := poissonCountableSamplePMF b r
  let f := fun x => pmfExpectation ((countsGivenAtoms z theta x).bind
    (fun c => observedSampleKernel n fallback (thinPositiveRecord c))) t
  have hgood (x : PoissonMarkedSample κ) (hx : x ∉ bad ∪ {x | k < x.1}) :
      f x ≤ c + Real.exp (-(theta : ℝ) * b / 16) := by
    have hx' : x ∉ bad := fun h => hx (Or.inl h)
    have hxk : x.1 ≤ k := Nat.le_of_not_gt (fun h => hx (Or.inr h))
    have hsumR : (0 : ℝ) < ∑ i, (z (x.2 i) : ℝ) :=
      lt_of_lt_of_le (mul_pos (by norm_num : (0 : ℝ) < 3/4) hb) (hmass x hx')
    have hw : 0 < ∑ i, z (x.2 i) := by exact_mod_cast hsumR
    have h := conditional_observed_test_le z theta x n fallback hxk hw t ht0 ht1 hc
      (fun e => hiid x hx' e hw)
    exact h.trans (add_le_add_left (atom_record_availability b theta z x n (hmass x hx') hn) c)
  have h := pmfExpectation_le_of_good μ f (bad ∪ {x | k < x.1})
    (add_nonneg hc (Real.exp_pos _).le)
    (fun _ => pmfExpectation_nonneg _ t ht0)
    (fun _ => pmfExpectation_le_one _ t ht0 ht1) hgood
  have hbnd := measureReal_union_le (μ := μ.toMeasure) bad {x | k < x.1}
  rw [show μ.toMeasure.real {x | k < x.1} =
    (poissonPMF b).toMeasure.real {Q | k < Q} from poisson_record_overflow b r k] at hbnd
  change pmfExpectation μ f ≤ _
  linarith

/-- The actual two-deviation normalization event, before counts are observed. -/
def atomNormalizationBad {κ : Type*} (b : ℝ≥0) (z : κ → ℝ≥0)
    (alpha A m : ℝ) : Set (PoissonMarkedSample κ) :=
  {x | min (1 / 4) (m / (16 * (alpha - 1))) <
      |compoundPoissonAverage b (fun i => (z i : ℝ)) x - 1| ∨
    A * (m / 16) < |compoundPoissonAverage b (fun i => (z i : ℝ) ^ alpha) x -
      A * compoundPoissonAverage b (fun i => (z i : ℝ)) x|}

/-- The good normalization event preserves at least three quarters of the
nominal total weight, exactly as needed for the Poisson availability bound. -/
theorem atomNormalizationBad_mass_lower {κ : Type*} (b : ℝ≥0) (hb : 0 < (b : ℝ))
    (z : κ → ℝ≥0) (alpha A m : ℝ) (x : PoissonMarkedSample κ)
    (hx : x ∉ atomNormalizationBad b z alpha A m) :
    (3 : ℝ) / 4 * b ≤ ∑ i, (z (x.2 i) : ℝ) := by
  have hs : |compoundPoissonAverage b (fun i => (z i : ℝ)) x - 1| ≤ 1 / 4 :=
    (le_of_not_gt (fun h => hx (Or.inl h))).trans (min_le_left _ _)
  have hlo := (abs_le.mp hs).1
  unfold compoundPoissonAverage at hlo
  have h := mul_le_mul_of_nonneg_left hlo hb.le
  field_simp at h
  nlinarith

/-- Exact cancellation of the nominal Poisson mean in the normalized power sum. -/
theorem normalized_compound_power_identity {b W : ℝ} (hb : 0 < b) (hW : 0 < W)
    (P alpha : ℝ) :
    b ^ (1 - alpha) * (b⁻¹ * P) / (b⁻¹ * W) ^ alpha = P / W ^ alpha := by
  rw [Real.rpow_sub hb, Real.rpow_one,
    show b⁻¹ * W = W / b by ring, Real.div_rpow hW.le hb.le]
  have hbpow : b ^ alpha ≠ 0 := (Real.rpow_pos_of_pos hb alpha).ne'
  have hWpow : W ^ alpha ≠ 0 := (Real.rpow_pos_of_pos hW alpha).ne'
  field_simp

/-- Every fixed injection of a good weight record has entropy within the
normalization reserve of its deterministic center. -/
theorem atomNormalizationBad_entropy_close {κ : Type*} {k : ℕ}
    (b : ℝ≥0) (hb : 0 < (b : ℝ)) (z : κ → ℝ≥0) {alpha A m : ℝ}
    (ha : 1 < alpha) (hA : 0 < A) (hm : 0 < m) (hm1 : m ≤ 1)
    (x : PoissonMarkedSample κ) (hx : x ∉ atomNormalizationBad b z alpha A m)
    (e : Fin x.1 ↪ Fin k) (hw : 0 < ∑ i, z (x.2 i)) :
    |entropy (paddedSimplex e (fun i => (z (x.2 i) : ℝ))
        (fun i => (z (x.2 i)).coe_nonneg) (by
          have h : (0 : ℝ) < ((∑ i, z (x.2 i) : ℝ≥0) : ℝ) := by exact_mod_cast hw
          simpa only [NNReal.coe_sum] using h)) alpha -
      (Real.log b - Real.log A / (alpha - 1))| ≤ m / (4 * (alpha - 1)) := by
  have hnorm : normalizationGood alpha b m A
      (compoundPoissonAverage b (fun i => (z i : ℝ)) x)
      (compoundPoissonAverage b (fun i => (z i : ℝ) ^ alpha) x) := by
    by_contra h
    exact hx (normalization_bad_subset _ _ ha hb hm hm1 hA h)
  rw [paddedSimplex_entropy e _ _ _ (by linarith : alpha ≠ 0)]
  have hW : (0 : ℝ) < ∑ i, (z (x.2 i) : ℝ) := by exact_mod_cast hw
  have heq := normalized_compound_power_identity hb hW
    (∑ i, (z (x.2 i) : ℝ) ^ alpha) alpha
  have h := hnorm.2.2.le
  unfold compoundPoissonAverage at h
  rw [heq] at h
  exact h

/-- A finite prior with the original nonnegative masses. -/
def finiteWeightPMF {L : ℕ} (p : Fin L → ℝ≥0) (hp : ∑ i, p i = 1) : PMF (Fin L) :=
  PMF.ofFintype (fun i => (p i : ℝ≥0∞)) (by
    simpa only [ENNReal.coe_finset_sum, ENNReal.coe_one] using
      congrArg (fun r : ℝ≥0 => (r : ℝ≥0∞)) hp)

@[simp] theorem finiteWeightPMF_apply {L : ℕ} (p : Fin L → ℝ≥0)
    (hp : ∑ i, p i = 1) (i : Fin L) : finiteWeightPMF p hp i = p i := rfl

/-- The finite atomic prior uses precisely the original ordered iid experiment. -/
theorem finiteWeightPMF_poisson_law {L : ℕ} (p : Fin L → ℝ≥0)
    (hp : ∑ i, p i = 1) (b : ℝ≥0) :
    poissonCountableSamplePMF b (finiteWeightPMF p hp) = poissonMarkedSamplePMF b p hp := by
  unfold poissonCountableSamplePMF poissonMarkedSamplePMF
  congr 1
  funext n
  congr 1
  ext x
  simp only [iidCountablePMF_apply, finiteWeightPMF_apply, iidMarkPMF_apply]

/-- The explicit two-moment normalization-failure expression from the manuscript. -/
def normalizationMomentBudget {L : ℕ} (b : ℝ≥0) (p z : Fin L → ℝ≥0)
    (alpha A m : ℝ) : ℝ :=
  (∑ i, (p i : ℝ) * (z i : ℝ) ^ (2 : ℕ)) /
    ((b : ℝ) * (min (1 / 4) (m / (16 * (alpha - 1)))) ^ (2 : ℕ)) +
  (∑ i, (p i : ℝ) * ((z i : ℝ) ^ alpha - A * z i) ^ (2 : ℕ)) /
    ((b : ℝ) * A ^ (2 : ℕ) * (m / 16) ^ (2 : ℕ))

/-- Explicit finite-prior first/power moments imply the exact good-event budget
used by the observation transfer; the mass-availability event is retained. -/
theorem finite_prior_normalization_bad_le {L : ℕ} (b : ℝ≥0) (hb : 0 < (b : ℝ))
    (p z : Fin L → ℝ≥0) (hp : ∑ i, p i = 1) {alpha A m : ℝ}
    (ha : 1 < alpha) (hA : 0 < A) (hm : 0 < m)
    (hmean : ∑ i, (p i : ℝ) * z i = 1)
    (hpower : ∑ i, (p i : ℝ) * (z i : ℝ) ^ alpha = A) :
    (poissonCountableSamplePMF b (finiteWeightPMF p hp)).toMeasure.real
        (atomNormalizationBad b z alpha A m) ≤ normalizationMomentBudget b p z alpha A m := by
  rw [finiteWeightPMF_poisson_law]
  have hbeta : 0 < alpha - 1 := sub_pos.mpr ha
  exact compound_poisson_deviation_failure b hb p hp (fun i => (z i : ℝ)) alpha A
    (min (1 / 4) (m / (16 * (alpha - 1)))) (m / 16) hmean hpower hA
    (lt_min (by norm_num) (by positivity)) (by positivity)

/-- Complementing a bounded test complements its actual expectation. -/
theorem pmfExpectation_one_sub {Ω : Type*} (p : PMF Ω) (t : Ω → ℝ)
    (ht0 : ∀ x, 0 ≤ t x) (ht1 : ∀ x, t x ≤ 1) :
    pmfExpectation p (fun x => 1 - t x) = 1 - pmfExpectation p t := by
  have h := (pmfReal_hasSum p).sub
    (summable_bounded_test _ t (pmfReal_hasSum p).summable ht0 ht1).hasSum
  calc
    _ = ∑' x, ((p x).toReal - (p x).toReal * t x) := by
      apply tsum_congr
      intro x
      ring
    _ = _ := h.tsum_eq

/-- The full one-hypothesis observation-transfer risk bound from the actual
finite prior moments. The normalized-center iid risk is the only statistical
input; an assumed uniformly accurate estimator supplies it directly. -/
theorem finite_prior_center_test_le {L k : ℕ} (b theta : ℝ≥0)
    (hb : 0 < (b : ℝ)) (p z : Fin L → ℝ≥0) (hp : ∑ i, p i = 1)
    {alpha A m : ℝ} (ha : 1 < alpha) (hA : 0 < A) (hm : 0 < m) (hm1 : m ≤ 1)
    (hmean : ∑ i, (p i : ℝ) * z i = 1)
    (hpower : ∑ i, (p i : ℝ) * (z i : ℝ) ^ alpha = A)
    (n : ℕ) (fallback : Sample k n) (hn : (n : ℝ) ≤ (theta : ℝ) * b / 4)
    (t : Sample k n → ℝ) (ht0 : ∀ y, 0 ≤ t y) (ht1 : ∀ y, t y ≤ 1)
    {c : ℝ} (hc : 0 ≤ c)
    (htest : ∀ P : Simplex k,
      |entropy P alpha - (Real.log b - Real.log A / (alpha - 1))| ≤ m / (4 * (alpha - 1)) →
      pmfExpectation (iidMarkPMF (simplexNN P) (simplexNN_sum P) n) t ≤ c) :
    let q := mixedPoissonMarkPMF (finiteWeightPMF p hp) z theta
    pmfExpectation
      ((poissonCountableSamplePMF (b * positiveMarkMass q) (visibleMarkPMF q)).bind
        (observedSampleKernel n fallback)) t ≤
      c + normalizationMomentBudget b p z alpha A m +
        (poissonPMF b).toMeasure.real {Q | k < Q} + Real.exp (-(theta : ℝ) * b / 16) := by
  have h := observed_poisson_prior_test_le b theta hb (finiteWeightPMF p hp) z
    n fallback t ht0 ht1 (atomNormalizationBad b z alpha A m) hc hn
    (fun x hx => atomNormalizationBad_mass_lower b hb z alpha A m x hx)
    (fun x hx e hw => htest _ (atomNormalizationBad_entropy_close b hb z ha hA hm hm1 x hx e hw))
  have hbad := finite_prior_normalization_bad_le b hb p z hp ha hA hm hmean hpower
  dsimp only at h ⊢
  linarith

/-- Full finite-atomic fingerprint-to-iid lower transfer. Its hypotheses are
exact first/power moments and the explicit scalar gap, moment, count-distance,
support, and availability inequalities from the manuscript. Every observation
law and reduction in the conclusion is constructed in this project. -/
theorem fingerprint_transfer_impossibility {L0 L1 k n : ℕ}
    (b theta : ℝ≥0) (hb : 0 < (b : ℝ)) (hk : 2 * (b : ℝ) ≤ k)
    (p0 z0 : Fin L0 → ℝ≥0) (p1 z1 : Fin L1 → ℝ≥0)
    (hp0 : ∑ i, p0 i = 1) (hp1 : ∑ i, p1 i = 1)
    {alpha eps A0 A1 m : ℝ} (ha : 1 < alpha)
    (hA0 : 0 < A0) (hA1 : 0 < A1) (hm : 0 < m) (hm1 : m ≤ 1)
    (hmean0 : ∑ i, (p0 i : ℝ) * z0 i = 1)
    (hmean1 : ∑ i, (p1 i : ℝ) * z1 i = 1)
    (hpower0 : ∑ i, (p0 i : ℝ) * (z0 i : ℝ) ^ alpha = A0)
    (hpower1 : ∑ i, (p1 i : ℝ) * (z1 i : ℝ) ^ alpha = A1)
    (hgap : 2 * eps * (alpha - 1) + m ≤ Real.log (A1 / A0))
    (hD : (b : ℝ) * countDistance
      (fun j => (mixedPoissonMarkPMF (finiteWeightPMF p0 hp0) z0 theta j).toReal)
      (fun j => (mixedPoissonMarkPMF (finiteWeightPMF p1 hp1) z1 theta j).toReal) ≤ 1 / 16)
    (hzeta0 : normalizationMomentBudget b p0 z0 alpha A0 m ≤ 1 / 64)
    (hzeta1 : normalizationMomentBudget b p1 z1 alpha A1 m ≤ 1 / 64)
    (hsupport : (Real.exp 1 / 4) ^ (b : ℝ) ≤ 1 / 128)
    (havailable : Real.exp (-(theta : ℝ) * b / 16) ≤ 1 / 128)
    (hn : (n : ℝ) ≤ (theta : ℝ) * b / 4) : ¬ Achievable k n alpha eps := by
  intro hach
  obtain ⟨est, hest⟩ := hach
  have hbeta : 0 < alpha - 1 := sub_pos.mpr ha
  have hkR : (0 : ℝ) < k := lt_of_lt_of_le (mul_pos (by norm_num) hb) hk
  have hkN : 0 < k := by exact_mod_cast hkR
  let fallback : Sample k n := fun _ => ⟨0, hkN⟩
  let cLow := Real.log b - Real.log A1 / (alpha - 1)
  let cHigh := Real.log b - Real.log A0 / (alpha - 1)
  let tau := m / (4 * (alpha - 1))
  have hlog : Real.log (A1 / A0) = Real.log A1 - Real.log A0 :=
    Real.log_div hA1.ne' hA0.ne'
  have hsep : 2 * (eps + tau) < cHigh - cLow := by
    have hh := (div_le_div_iff_of_pos_right hbeta).mpr hgap
    rw [hlog] at hh
    have hleft : (2 * eps * (alpha - 1) + m) / (alpha - 1) =
        2 * eps + m / (alpha - 1) := by field_simp
    rw [hleft] at hh
    have hright : (Real.log A1 - Real.log A0) / (alpha - 1) = cHigh - cLow := by
      dsimp [cHigh, cLow]
      ring
    rw [hright] at hh
    have hmargin : 0 < m / (alpha - 1) := div_pos hm hbeta
    have htau : tau = (m / (alpha - 1)) / 4 := by dsimp [tau]; field_simp
    rw [htau]
    linarith
  let t : Sample k n → ℝ := fun x => (est x (Set.Ioi ((cLow + cHigh) / 2)) : ℝ)
  have ht0 : ∀ x, 0 ≤ t x := fun _ => NNReal.coe_nonneg _
  have ht1 : ∀ x, t x ≤ 1 := by
    intro x
    exact_mod_cast (est x).apply_le_one (Set.Ioi ((cLow + cHigh) / 2))
  let q0 := mixedPoissonMarkPMF (finiteWeightPMF p0 hp0) z0 theta
  let q1 := mixedPoissonMarkPMF (finiteWeightPMF p1 hp1) z1 theta
  let P0 := poissonCountableSamplePMF (b * positiveMarkMass q0) (visibleMarkPMF q0)
  let P1 := poissonCountableSamplePMF (b * positiveMarkMass q1) (visibleMarkPMF q1)
  let K := observedSampleKernel n fallback
  have htail : (poissonPMF b).toMeasure.real {Q | k < Q} ≤ 1 / 128 :=
    (poisson_support_overflow b k hk).trans hsupport
  have hrisk1 : pmfExpectation (P1.bind K) t ≤ 35 / 96 := by
    have h := finite_prior_center_test_le b theta hb p1 z1 hp1 ha hA1 hm hm1 hmean1 hpower1
      n fallback hn t ht0 ht1 (by norm_num : (0 : ℝ) ≤ 1/3)
      (fun P hP => (iid_center_test_left P est alpha eps tau cLow cHigh hsep hP).trans (hest P))
    change pmfExpectation (P1.bind K) t ≤ _ at h
    linarith
  have hrisk0 : pmfExpectation (P0.bind K) (fun x => 1 - t x) ≤ 35 / 96 := by
    have h := finite_prior_center_test_le b theta hb p0 z0 hp0 ha hA0 hm hm1 hmean0 hpower0
      n fallback hn (fun x => 1 - t x) (fun x => sub_nonneg.mpr (ht1 x))
      (fun x => by linarith [ht0 x]) (by norm_num : (0 : ℝ) ≤ 1/3)
      (fun P hP => (iid_center_test_right P est alpha eps tau cLow cHigh hsep hP).trans (hest P))
    change pmfExpectation (P0.bind K) (fun x => 1 - t x) ≤ _ at h
    linarith
  have hroot : Real.sqrt ((b : ℝ) * countDistance (fun j => (q0 j).toReal)
      (fun j => (q1 j).toReal)) ≤ 1 / 4 := by
    apply (Real.sqrt_le_iff).mpr
    constructor
    · norm_num
    · change (b : ℝ) * countDistance _ _ ≤ (1 / 4 : ℝ) ^ 2
      norm_num
      exact hD
  have htest : |pmfExpectation (P0.bind K) t - pmfExpectation (P1.bind K) t| ≤ 1 / 4 := by
    rw [pmfExpectation_bind _ _ t ht0 ht1, pmfExpectation_bind _ _ t ht0 ht1]
    exact ((discrete_bounded_test_contraction (fun x => (P0 x).toReal)
      (fun x => (P1 x).toReal) (fun x => pmfExpectation (K x) t)
      (pmfReal_hasSum P0) (pmfReal_hasSum P1)
      (fun _ => pmfExpectation_nonneg _ t ht0)
      (fun _ => pmfExpectation_le_one _ t ht0 ht1)).trans
      (visible_poisson_sample_tv_le_countDistance b q0 q1)).trans hroot
  have hcomp := pmfExpectation_one_sub (P0.bind K) t ht0 ht1
  have hbound := (abs_le.mp htest).2
  linarith

/-- The mixed-count probabilities used in the transfer are exactly the explicit
Poisson-mixture series used by the scalar lower calibration. -/
theorem finite_mixed_count_toReal {L : ℕ} (p z : Fin L → ℝ≥0)
    (hp : ∑ i, p i = 1) (theta : ℝ≥0) (j : ℕ) :
    (mixedPoissonMarkPMF (finiteWeightPMF p hp) z theta j).toReal =
      poissonMixture (fun i => (p i : ℝ)) (fun i => (z i : ℝ)) theta j := by
  rw [mixedPoissonMarkPMF, PMF.bind_apply, tsum_fintype, ENNReal.toReal_sum]
  · simp only [finiteWeightPMF_apply, ENNReal.toReal_mul, ENNReal.coe_toReal]
    change (∑ i, (p i : ℝ) * (ENNReal.ofReal (poissonPMFReal (theta * z i) j)).toReal) = _
    simp_rw [ENNReal.toReal_ofReal poissonPMFReal_nonneg]
    rfl
  · intro i _
    exact ENNReal.mul_ne_top (ENNReal.coe_ne_top) ((poissonPMF (theta * z i)).apply_ne_top j)

end Renyi
