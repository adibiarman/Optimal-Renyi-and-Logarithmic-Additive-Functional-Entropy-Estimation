import Renyi.CompletedHighVariance
import Renyi.CompletedLowCountCalibration
import Renyi.CoupledConditionalCount

/-! Conditional count calibration for the full completed source polynomial. -/
set_option maxHeartbeats 1000000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

variable {ι Ω Ξ : Type*} [Fintype ι] [MeasurableSpace Ω] [MeasurableSpace Ξ]
variable {μ : Measure Ω} {ν : Measure Ξ}

def completedHighTinyConstant (Cscale : ℝ) : ℝ :=
  highTinyExponentialConstant (completedLeadingCoefficientConstant * max 1 Cscale)

section ActualCount
variable {ell Nk m d : ℕ} {gamma aCut b n cProfile fL f A B omega L Cscale Cd Ct cp Bpilot M : ℝ}
variable {CL cL D X R E0 u0 c E kappa u : ℝ}
variable (hell : 0 < ell) (hNk : 0 < Nk) (hmDegree : 1 ≤ m) (hdegree : 4 * (ell - 1) ≤ m)
variable (hgamma : 0 < gamma) (hgamma1 : gamma < 1) (halpha : 3 / 2 ≤ (m : ℝ) + gamma)
variable (haCut : 0 < aCut) (hab : aCut ≤ b) (hb : 0 < b)
variable (hcProfile : cProfile ∈ Set.Ioo (gamma / (1 + gamma)) 1)
variable (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
variable (hA : 0 ≤ A) (hA1 : A ≤ 1) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hw : 0 ≤ omega) (hw1 : omega < 1)
variable (hlocal : (ell : ℝ) ^ 2 * (aCut * (Nk : ℝ) ^ 2 / b) ≤ 1)
variable (hLactual : L = (upperDegree ((m : ℝ) + gamma) CL cL X : ℝ))
variable (hCL : 1 ≤ CL) (hcL : 0 < cL) (hellL : (ell : ℝ) ≤ L) (hNkL : (Nk : ℝ) ≤ L)
variable (hscale : 0 < Cscale) (hcountScale : (Nk : ℝ) ^ 2 / (n * b) ≤ Cscale * L)
variable (hH : 1 ≤ n * b) (hrd : m + 1 ≤ d) (hCd : 0 ≤ Cd) (hdegreeL : (d : ℝ) ≤ Cd * L)
variable (hCt : 2 * coupledCoefficientExponentialConstant + 4 * Cd ≤ Ct) (hCt2 : 2 ≤ Ct)
variable (hcp : 0 < cp) (hBpilot : 0 ≤ Bpilot) (hM : 0 ≤ M)
variable (hdegreeH : (d : ℝ) ≤ M * (n * b)) (hcpM : 4 * M ≤ cp)
variable (hD : 1 ≤ D) (hX : 1 ≤ X) (hE0 : 0 < E0) (hu0 : 0 < u0) (hc : 0 ≤ c)
variable (hsmall : cL * (coupledHighMediumConstant cp Bpilot M Cd + Ct + 1 / (CL + 1)) ≤ 1 / 2)
variable (hRtiny : Real.exp (3 * (Real.log (completedHighTinyConstant Cscale) + c)) ≤ R)
variable (hRmedium : Real.exp (3 * (Real.log (highMediumExponentialConstant CL
  (coupledHighMediumConstant cp Bpilot M Cd) Ct (n * b / L)) + c)) ≤ R)
variable (hE : E0 * (R / D) ^ ((m : ℝ) + gamma - 1) ≤ E)
variable (hkappa : Real.exp (-c * ((m : ℝ) + gamma)) ≤ kappa) (hu : u0 * X ^ (-((m : ℝ) + gamma)) ≤ u)
variable (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) (hk : (0 : ℝ) < Fintype.card ι)
variable (hnsize : n = D * ((m : ℝ) + gamma) * (Fintype.card ι : ℝ) ^ (1 - 1 / ((m : ℝ) + gamma)) * X)
variable (Counts : ι → Ω → ℕ) (lam : ι → ℝ≥0)
variable (hLaw : ∀ i, MeasurePreserving (Counts i) μ (poissonMeasure (lam i)))
variable (hpair : Pairwise (fun i j => IndepFun (Counts i) (Counts j) μ))
variable (Pilot : ι → Ξ → ℕ)
variable (hPilot : ∀ i, MeasurePreserving (Pilot i) ν
  (poissonMeasure ⟨cp * lam i, mul_nonneg hcp.le (lam i).coe_nonneg⟩))
variable (hlam : ∀ i, (lam i : ℝ) = n * p i)

include hell hNk hmDegree hcProfile hdegree hgamma hgamma1 halpha haCut hab hb hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1
include hlocal hLactual hCL hcL hellL hNkL hscale hcountScale hH hrd hCd hdegreeL hCt hCt2 hcp hBpilot hM hdegreeH hcpM
include hD hX hE0 hu0 hc hsmall hRtiny hRmedium hE hkappa hu hp hk hnsize hLaw hpair hPilot hlam

/-- The actual coupled high block, including the pilot, satisfies the calibrated full-margin rate. -/
theorem completed_high_count_variance_calibrated :
    pilotAveragedCountVariance Counts Pilot (cp * Bpilot * ((m : ℝ) + gamma)) d
      (highCountCoefficients (m + 1) (completedCoupledPolynomial ell Nk m gamma aCut b cProfile fL f A B omega).coeff) n μ ν /
      (E * (Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + gamma)) + kappa * u * (∑ i, p i ^ ((m : ℝ) + gamma)) +
        kappa * conditionalCountBonus p ((m : ℝ) + gamma) n L) ^ 2 ≤
      (1 / (E0 * u0) + 1 / E0) / D := by
  let alpha := (m : ℝ) + gamma
  let r := m + 1
  let Q := completedCoupledPolynomial ell Nk m gamma aCut b cProfile fL f A B omega
  let K := completedLeadingCoefficientConstant * max 1 Cscale
  let tiny := 2 * K ^ 2 * Real.exp 2 * (2 * (r : ℝ)) ^ r + 2 * ((r + 1 : ℕ) : ℝ) ^ (r + 1)
  let budget := coupledCoefficientBudget ell Nk gamma aCut b A B omega
  let medium := ((d : ℝ) + 1) ^ 2 * budget ^ 2 * Real.exp (cp * Bpilot * alpha + M * d)
  let Cmed := coupledHighMediumConstant cp Bpilot M Cd
  have ha : 1 < alpha := by dsimp [alpha]; linarith
  have hD0 : 0 < D := zero_lt_one.trans_le hD
  have hX0 : 0 < X := zero_lt_one.trans_le hX
  have hn : 0 < n := by rw [hnsize]; positivity
  have hLpos : 0 < L := by rw [hLactual]; exact_mod_cast upperDegree_pos ha hCL hcL hX
  have hL : 1 ≤ L := by rw [hLactual]; exact_mod_cast upperDegree_pos ha hCL hcL hX
  have hCmed : 0 ≤ Cmed := by
    have hCb := coupledCoefficientExponentialConstant_pos.le
    dsimp [Cmed, coupledHighMediumConstant]
    positivity
  have hCt0 : 0 ≤ Ct := by linarith
  have hraw := completed_high_averaged_count_variance hell hNk hmDegree hdegree hgamma hgamma1 haCut hab hb hn hcProfile hfL hfL1 hf hf1
    hA hA1 hB hB1 hw hw1 hlocal hL hellL hNkL hscale hcountScale hH hrd hCd hdegreeL hCt hCt2
      hcp hBpilot hM hdegreeH hcpM Counts lam hLaw hpair Pilot hPilot
  change pilotAveragedCountVariance Counts Pilot (cp * Bpilot * alpha) d (highCountCoefficients r Q.coeff) n μ ν ≤
    n ^ (-2 * alpha) * (tiny * (∑ i, (lam i : ℝ) ^ alpha) + medium * (n * b) ^ alpha *
      ∑ i, if Real.exp (-Ct * L) < (lam i : ℝ) then (lam i : ℝ) ^ alpha else 0) at hraw
  rw [high_count_probability_units p hp lam hn hb hlam] at hraw
  have hbudget0 : 0 ≤ budget := by
    have h1B : 0 ≤ 1 - B := sub_nonneg.mpr hB1
    dsimp [budget, coupledCoefficientBudget]
    positivity
  have hbudget := coupledCoefficientBudget_exponential hgamma.le haCut.le hab hb hA hA1 hB hB1 hw hw1.le hL hellL hNkL
  have haL : alpha ≤ L := by
    have horder : alpha ≤ (upperDegree alpha CL cL X : ℝ) := by
      have h := (upperDegree_bounds ha hCL hcL hX).1
      nlinarith
    rwa [← hLactual] at horder
  have hmedium := high_medium_budget_exponential hbudget0 hbudget hdegreeL haL (mul_nonneg hcp.le hBpilot) hM
  have htiny := high_tiny_prefactor_exponential halpha
    (by dsimp [r, alpha]; push_cast; linarith : (r : ℝ) ≤ alpha + 1)
    (by dsimp [r, alpha]; push_cast; linarith : alpha ≤ (r : ℝ)) (K := K)
  have hcb : 0 < n * b / L := div_pos (mul_pos hn hb) hLpos
  have hnb : n * b = (n * b / L) * L := by field_simp
  exact high_count_two_component_calibrated p hp hk halpha hLactual hCL hcL hCmed hCt0 hcb
    (highTinyExponentialConstant_ge_one K) (by positivity) (by positivity)
    htiny hmedium hD hX hE0 hu0 hc hsmall hRtiny hRmedium hE hkappa hu hnsize hnb hraw

/-- Complete actual conditional count variance against the source reference margin. -/
theorem completed_conditional_count_variance_reference {rho : ℝ} (hrho : 0 < rho)
    (hRlow : Real.exp (3 * (Real.log (lowCountExponentialConstant rho (pilotConstant Bpilot cp)) + c)) ≤ R)
    (hcut : (Fintype.card ι : ℝ) * aCut ≤ rho / D) (hBpilotpos : 0 < Bpilot) :
    pilotAveragedCountVariance Counts Pilot (cp * Bpilot * ((m : ℝ) + gamma)) d
      (completedCoupledPolynomial ell Nk m gamma aCut b cProfile fL f A B omega).coeff n μ ν /
      (E * (Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + gamma)) + kappa * u * (∑ i, p i ^ ((m : ℝ) + gamma)) +
        kappa * conditionalCountBonus p ((m : ℝ) + gamma) n L) ^ 2 ≤
      2 * (max (E0 ^ (-2 : ℝ)) (E0 ^ (-1 : ℝ)) * max 1 (u0 ^ (-1 : ℝ)) +
        (1 / (E0 * u0) + 1 / E0)) / D := by
  let alpha := (m : ℝ) + gamma
  let Q := completedCoupledPolynomial ell Nk m gamma aCut b cProfile fL f A B omega
  let Pstar := (Fintype.card ι : ℝ) ^ (1 - alpha)
  let P := ∑ i, p i ^ alpha
  let Mlow := Pstar * (E + (kappa * u) * (P / Pstar))
  let Mfull := E * Pstar + kappa * u * P + kappa * conditionalCountBonus p alpha n L
  let Vlow := pilotAveragedCountVariance Counts Pilot (cp * Bpilot * alpha) m Q.coeff n μ ν
  let Vhigh := pilotAveragedCountVariance Counts Pilot (cp * Bpilot * alpha) d (highCountCoefficients (m + 1) Q.coeff) n μ ν
  have ha : 1 < alpha := by dsimp [alpha]; linarith
  have hD0 : 0 < D := zero_lt_one.trans_le hD
  have hX0 : 0 < X := zero_lt_one.trans_le hX
  have hR0 : 0 < R := (Real.exp_pos _).trans_le hRtiny
  have hn : 0 < n := by rw [hnsize]; positivity
  have hLpos : 0 < L := by rw [hLactual]; exact_mod_cast upperDegree_pos ha hCL hcL hX
  have hEpos : 0 < E := (by positivity : 0 < E0 * (R / D) ^ ((m : ℝ) + gamma - 1)).trans_le hE
  have hkappapos : 0 < kappa := (Real.exp_pos _).trans_le hkappa
  have hupos : 0 < u := (by positivity : 0 < u0 * X ^ (-((m : ℝ) + gamma))).trans_le hu
  have hm : 0 < m := by
    by_contra h
    have hm0 : m = 0 := by omega
    subst m
    norm_num at halpha
    linarith
  have hZ : (Nk : ℝ) ^ 2 * (aCut / b) ≤ 1 := by
    have hell1 : 1 ≤ (ell : ℝ) := by exact_mod_cast hell
    have hell2 : 1 ≤ (ell : ℝ) ^ 2 := by nlinarith
    have hx : 0 ≤ (Nk : ℝ) ^ 2 * (aCut / b) := by positivity
    have h := mul_le_mul_of_nonneg_right hell2 hx
    have hl : (ell : ℝ) ^ 2 * ((Nk : ℝ) ^ 2 * (aCut / b)) ≤ 1 := by
      convert hlocal using 1
      ring
    nlinarith
  have hvref : u0 * Real.exp (-c * ((m : ℝ) + gamma)) * X ^ (-((m : ℝ) + gamma)) ≤ kappa * u := by
    have h := mul_le_mul hkappa hu (by positivity) hkappapos.le
    convert h using 1
    ring
  have hlow := completed_low_count_variance_calibrated (f := f) (B := B) (ω := omega)
    Bpilot cp hBpilotpos hcp Counts lam hLaw hpair Pilot hPilot p hp hk hm hell hNk hdegree hmDegree
    hgamma hgamma1.le halpha haCut hb hcProfile hfL hfL1 hA hA1 hZ hrho hD hX hE0 hu0 hc hRlow hcut hE hvref hnsize hlam
  have hhigh := completed_high_count_variance_calibrated (p := p) (Counts := Counts) (lam := lam) (Pilot := Pilot)
    (hell := hell) (hNk := hNk) (hmDegree := hmDegree) (hcProfile := hcProfile) (hdegree := hdegree) (hgamma := hgamma) (hgamma1 := hgamma1) (halpha := halpha)
    (haCut := haCut) (hab := hab) (hb := hb) (hfL := hfL) (hfL1 := hfL1) (hf := hf) (hf1 := hf1)
    (hA := hA) (hA1 := hA1) (hB := hB) (hB1 := hB1) (hw := hw) (hw1 := hw1) (hlocal := hlocal)
    (hLactual := hLactual) (hCL := hCL) (hcL := hcL) (hellL := hellL) (hNkL := hNkL) (hscale := hscale)
    (hcountScale := hcountScale) (hH := hH) (hrd := hrd) (hCd := hCd) (hdegreeL := hdegreeL) (hCt := hCt) (hCt2 := hCt2)
    (hcp := hcp) (hBpilot := hBpilot) (hM := hM) (hdegreeH := hdegreeH) (hcpM := hcpM)
    (hD := hD) (hX := hX) (hE0 := hE0) (hu0 := hu0) (hc := hc) (hsmall := hsmall)
    (hRtiny := hRtiny) (hRmedium := hRmedium) (hE := hE) (hkappa := hkappa) (hu := hu)
    (hp := hp) (hk := hk) (hnsize := hnsize) (hLaw := hLaw) (hpair := hpair) (hPilot := hPilot) (hlam := hlam)
  change Vlow / Mlow ^ 2 ≤ _ at hlow
  change Vhigh / Mfull ^ 2 ≤ _ at hhigh
  have hPstar : 0 < Pstar := Real.rpow_pos_of_pos hk _
  have hP : 0 ≤ P := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (hp i) _)
  have hbonus := conditionalCountBonus_nonneg p hp hn.le hLpos.le (alpha := alpha)
  have hMlowid : Mlow = E * Pstar + kappa * u * P := by dsimp [Mlow]; field_simp
  have hMlowpos : 0 < Mlow := by rw [hMlowid]; positivity
  have hMcompare : Mlow ≤ Mfull := by dsimp [Mfull]; rw [hMlowid]; nlinarith [mul_nonneg hkappapos.le hbonus]
  have hMfullpos : 0 < Mfull := hMlowpos.trans_le hMcompare
  have hVlow : 0 ≤ Vlow := integral_nonneg (fun _ => variance_nonneg _ _)
  have hlowfull := (div_le_div_of_nonneg_left hVlow (sq_pos_of_pos hMlowpos)
    ((sq_le_sq₀ hMlowpos.le hMfullpos.le).mpr hMcompare)).trans hlow
  have hsplit := pilot_averaged_count_variance_low_high Counts lam hLaw hpair Pilot
    (fun i => (⟨cp * lam i, mul_nonneg hcp.le (lam i).coe_nonneg⟩ : ℝ≥0)) hPilot
      (cp * Bpilot * alpha) (by omega : m ≤ d) Q.coeff n
  have h := div_le_div_of_nonneg_right hsplit (sq_nonneg Mfull)
  apply h.trans
  have hbound := add_le_add (mul_le_mul_of_nonneg_left hlowfull (by norm_num : (0 : ℝ) ≤ 2))
    (mul_le_mul_of_nonneg_left hhigh (by norm_num : (0 : ℝ) ≤ 2))
  convert hbound using 1 <;> dsimp [Vlow, Vhigh, Q, Mfull, Pstar, P, alpha] <;> ring

end ActualCount
end Renyi
