import Renyi.CoupledCountVariance
import Renyi.CoupledHighMoments

/-! Actual light-count variance in the near-one range. The coefficient
assumptions are the explicit hypotheses of source lemma CC17. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

private theorem near_one_coefficient_scaling {n b a : ℝ} (hn : 0 < n) (hb : 0 < b) (j : ℕ) :
    (b ^ (a - (j : ℝ)) / n ^ j) ^ (2 : ℕ) =
      n ^ (-2 * a) * (n * b) ^ (2 * a - 2 * j) := by
  apply Real.log_injOn_pos (Set.mem_Ioi.mpr (by positivity)) (Set.mem_Ioi.mpr (by positivity))
  rw [Real.log_pow, Real.log_div (Real.rpow_pos_of_pos hb _).ne' (pow_pos hn _).ne',
    Real.log_rpow hb, Real.log_pow,
    Real.log_mul (Real.rpow_pos_of_pos hn _).ne' (Real.rpow_pos_of_pos (mul_pos hn hb) _).ne',
    Real.log_rpow hn, Real.log_rpow (mul_pos hn hb), Real.log_mul hn.ne' hb.ne']
  push_cast
  ring

/-- One actual pilot-selected high-degree term, with a coefficient of order beta. -/
theorem near_one_high_term_bound {n b a beta A cp B M : ℝ} (hn : 0 < n) (hb : 0 < b)
    (ha : 0 < a) (hbeta : 0 ≤ beta) (hA : 0 ≤ A) (hcp0 : 0 < cp) (hB : 0 ≤ B)
    (hM : 0 ≤ M) (hcp : 4 * M ≤ cp) (lam : ℝ≥0) {j : ℕ} {c : ℝ}
    (hj : a ≤ (j : ℝ)) (hjM : (j : ℝ) ≤ M * (n * b))
    (hcoef : |c| ≤ beta * A * b ^ (a - j)) :
    (c / n ^ j) ^ (2 : ℕ) *
      poissonPilotSecond lam ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp * B * a) j ≤
      (beta * A) ^ (2 : ℕ) * n ^ (-2 * a) * Real.exp (cp * B * a + M * j) *
        (n * b) ^ a * (lam : ℝ) ^ a := by
  have hbound : 0 ≤ beta * A * b ^ (a - j) := by positivity
  have hs := mul_le_mul hcoef hcoef (abs_nonneg c) hbound
  simp only [← pow_two, sq_abs] at hs
  have hcoeff : (c / n ^ j) ^ (2 : ℕ) ≤
      (beta * A) ^ (2 : ℕ) * (n ^ (-2 * a) * (n * b) ^ (2 * a - 2 * j)) := by
    have h := div_le_div_of_nonneg_right hs (sq_nonneg (n ^ j))
    rw [← div_pow] at h
    have heq : (beta * A * b ^ (a - j)) ^ (2 : ℕ) / (n ^ j) ^ (2 : ℕ) =
        (beta * A) ^ (2 : ℕ) * (b ^ (a - j) / n ^ j) ^ (2 : ℕ) := by
      rw [div_pow, mul_pow]
      ring
    rw [heq, near_one_coefficient_scaling hn hb j] at h
    simpa only [mul_assoc] using h
  have hm := poisson_high_moment_all lam (mul_pos hn hb) ha hj hB hcp0 hM hjM hcp
  have hm0 : 0 ≤ poissonPilotSecond lam ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp * B * a) j := by
    rw [poissonPilotSecond_factor]
    exact mul_nonneg (poissonLowerMass_nonneg _ _) (poissonFactorialSecond_nonneg _ _)
  have hfirst := mul_le_mul_of_nonneg_right hcoeff hm0
  have hsecond := mul_le_mul_of_nonneg_left hm (mul_nonneg (sq_nonneg (beta * A)) (Real.rpow_nonneg hn.le (-2 * a)))
  nlinarith only [hfirst, hsecond]

variable {ι Ω Ξ : Type*} [Fintype ι] [MeasurableSpace Ω] [MeasurableSpace Ξ]
variable {μ : Measure Ω} {ν : Measure Ξ}

/-- The actual pilot-averaged light-residual variance retains its beta-squared
factor uniformly as the real order approaches one. -/
theorem near_one_light_count_variance
    {a beta A n b cp B M : ℝ} (hn : 0 < n) (hb : 0 < b)
    (ha : 0 < a) (ha2 : a ≤ 2) (hbeta : 0 ≤ beta) (hA : 0 ≤ A)
    (hcp0 : 0 < cp) (hB : 0 ≤ B) (hM : 0 ≤ M) (hcp : 4 * M ≤ cp)
    (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (Y : ι → Ξ → ℕ)
    (hY : ∀ i, MeasurePreserving (Y i) ν
      (poissonMeasure ⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩))
    (d : ℕ) (hd : (d : ℝ) ≤ M * (n * b)) (c : ℕ → ℝ)
    (hc1 : c 1 = 0) (hcoef : ∀ j : ℕ, 2 ≤ j → j ≤ d → |c j| ≤ beta * A * b ^ (a - j)) :
    pilotAveragedCountVariance N Y (cp * B * a) d c n μ ν ≤
      (d : ℝ) ^ (2 : ℕ) * (beta * A) ^ (2 : ℕ) * n ^ (-2 * a) *
        Real.exp (cp * B * a + M * d) * (n * b) ^ a * (∑ i, (lam i : ℝ) ^ a) := by
  have hstart := pilot_averaged_count_variance_le N lam hLaw hpair Y
    (fun i => (⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩ : ℝ≥0)) hY
    (cp * B * a) d c n
  have hterm (i : ι) (r : ℕ) (hr : r ∈ Finset.range d) :
      (c (r + 1) / n ^ (r + 1)) ^ (2 : ℕ) *
        poissonPilotSecond (lam i) ⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩
          (cp * B * a) (r + 1) ≤
      (beta * A) ^ (2 : ℕ) * n ^ (-2 * a) * Real.exp (cp * B * a + M * d) *
        (n * b) ^ a * (lam i : ℝ) ^ a := by
    have hrD : r + 1 ≤ d := by have := Finset.mem_range.mp hr; omega
    by_cases hr0 : r = 0
    · subst r
      simp only [Nat.zero_add, hc1, zero_div, zero_pow (by norm_num : 2 ≠ 0), zero_mul]
      positivity
    · have hr2 : 2 ≤ r + 1 := by omega
      have hra : a ≤ ((r + 1 : ℕ) : ℝ) := ha2.trans (by exact_mod_cast hr2)
      have hrM : ((r + 1 : ℕ) : ℝ) ≤ M * (n * b) :=
        (by exact_mod_cast hrD : ((r + 1 : ℕ) : ℝ) ≤ d).trans hd
      have h := near_one_high_term_bound hn hb ha hbeta hA hcp0 hB hM hcp (lam i) hra hrM
        (hcoef (r + 1) hr2 hrD)
      have he : Real.exp (cp * B * a + M * ((r + 1 : ℕ) : ℝ)) ≤
          Real.exp (cp * B * a + M * (d : ℝ)) := Real.exp_le_exp.mpr
        (add_le_add_left (mul_le_mul_of_nonneg_left
          (by exact_mod_cast hrD : ((r + 1 : ℕ) : ℝ) ≤ d) hM) _)
      have hm := mul_le_mul_of_nonneg_left he (by positivity : 0 ≤ (beta * A) ^ (2 : ℕ) * n ^ (-2 * a))
      have hm' := mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right hm (Real.rpow_nonneg (mul_pos hn hb).le a))
        (Real.rpow_nonneg (lam i).coe_nonneg a)
      exact h.trans hm'
  apply hstart.trans
  calc
    _ ≤ (d : ℝ) * ∑ i, ∑ _r ∈ Finset.range d,
      (beta * A) ^ (2 : ℕ) * n ^ (-2 * a) * Real.exp (cp * B * a + M * d) *
        (n * b) ^ a * (lam i : ℝ) ^ a := by
      apply mul_le_mul_of_nonneg_left _ (Nat.cast_nonneg d)
      apply Finset.sum_le_sum
      intro i _
      exact Finset.sum_le_sum (fun r hr => hterm i r hr)
    _ = _ := by
      simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro i _
      ring

private theorem near_one_full_scaling {n b a : ℝ} (hn : 0 < n) (hb : 0 < b) (j : ℕ) :
    (b ^ (a - (j : ℝ)) / n ^ j) ^ (2 : ℕ) * (n * b) ^ (2 * j) = b ^ (2 * a) := by
  apply Real.log_injOn_pos (Set.mem_Ioi.mpr (by positivity)) (Set.mem_Ioi.mpr (by positivity))
  rw [Real.log_mul (by positivity) (by positivity), Real.log_pow,
    Real.log_div (Real.rpow_pos_of_pos hb _).ne' (pow_pos hn _).ne', Real.log_rpow hb,
    Real.log_pow, Real.log_pow, Real.log_mul hn.ne' hb.ne', Real.log_rpow hb]
  push_cast
  ring

/-- A coefficient of order beta gives a selected second moment of order
beta squared, at every degree including the constant and linear terms. -/
theorem near_one_selected_degree_second {n b a beta A cp T M : ℝ}
    (hn : 0 < n) (hb : 0 < b) (hbeta : 0 ≤ beta) (hA : 0 ≤ A)
    (hcp0 : 0 < cp) (hT : 0 ≤ T) (hM : 0 ≤ M) (hcp : 4 * M ≤ cp)
    (lam : ℝ≥0) {j d : ℕ} {c : ℝ} (hjd : j ≤ d) (hd : (d : ℝ) ≤ M * (n * b))
    (hcoef : |c| ≤ beta * A * b ^ (a - j)) :
    (c / n ^ j) ^ (2 : ℕ) *
      poissonPilotSecond lam ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ T j ≤
      (beta * A) ^ (2 : ℕ) * Real.exp (T + M * d) * b ^ (2 * a) := by
  have hs := mul_le_mul hcoef hcoef (abs_nonneg c) (by positivity : 0 ≤ beta * A * b ^ (a - j))
  simp only [← pow_two, sq_abs] at hs
  have hscaled : (c / n ^ j) ^ (2 : ℕ) * (n * b) ^ (2 * j) ≤
      (beta * A) ^ (2 : ℕ) * b ^ (2 * a) := by
    have hdiv := div_le_div_of_nonneg_right hs (sq_nonneg (n ^ j))
    rw [← div_pow] at hdiv
    have hm := mul_le_mul_of_nonneg_right hdiv (pow_nonneg (mul_pos hn hb).le (2 * j))
    have hid : (beta * A * b ^ (a - j)) ^ (2 : ℕ) / (n ^ j) ^ (2 : ℕ) *
        (n * b) ^ (2 * j) = (beta * A) ^ (2 : ℕ) * b ^ (2 * a) := by
      calc
        _ = (beta * A) ^ (2 : ℕ) * ((b ^ (a - j) / n ^ j) ^ (2 : ℕ) * (n * b) ^ (2 * j)) := by
          rw [div_pow, mul_pow]
          ring
        _ = _ := by rw [near_one_full_scaling hn hb j]
    rw [hid] at hm
    exact hm
  have hjM : (j : ℝ) ≤ M * (n * b) := (by exact_mod_cast hjd : (j : ℝ) ≤ d).trans hd
  have hm := poissonPilotSecond_normalized_bound lam (mul_pos hn hb) hcp0 hT hM hjM hcp
  have he : Real.exp (T + M * (j : ℝ)) ≤ Real.exp (T + M * (d : ℝ)) :=
    Real.exp_le_exp.mpr (add_le_add_left (mul_le_mul_of_nonneg_left (by exact_mod_cast hjd : (j : ℝ) ≤ d) hM) T)
  have hfirst := mul_le_mul_of_nonneg_left hm (sq_nonneg (c / n ^ j))
  have hsecond := mul_le_mul_of_nonneg_left he (pow_nonneg (mul_pos hn hb).le (2 * j))
  have hsecond' := mul_le_mul_of_nonneg_left hsecond (sq_nonneg (c / n ^ j))
  have hthird := mul_le_mul_of_nonneg_right hscaled (Real.exp_pos (T + M * d)).le
  nlinarith only [hfirst, hsecond', hthird]

/-- Direct second moment of the entire light residual under the independent
pilot/main product law. This includes all randomness of the selector. -/
theorem near_one_light_joint_second {n b a beta A cp T M : ℝ}
    (hn : 0 < n) (hb : 0 < b) (hbeta : 0 ≤ beta) (hA : 0 ≤ A)
    (hcp0 : 0 < cp) (hT : 0 ≤ T) (hM : 0 ≤ M) (hcp : 4 * M ≤ cp)
    (lam : ℝ≥0) (d : ℕ) (hd : (d : ℝ) ≤ M * (n * b)) (c : ℕ → ℝ)
    (hcoef : ∀ j : ℕ, j ≤ d → |c j| ≤ beta * A * b ^ (a - j)) :
    Summable (fun z : ℕ × ℕ =>
      (if (z.1 : ℝ) ≤ T then factorialStatistic d (fun j => c j / n ^ j) z.2 ^ 2 else 0) *
      (poissonPMFReal lam z.2 * poissonPMFReal ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ z.1)) ∧
    (∑' z : ℕ × ℕ,
      (if (z.1 : ℝ) ≤ T then factorialStatistic d (fun j => c j / n ^ j) z.2 ^ 2 else 0) *
      (poissonPMFReal lam z.2 * poissonPMFReal ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ z.1)) ≤
      ((d : ℝ) + 1) ^ (2 : ℕ) * (beta * A) ^ (2 : ℕ) * Real.exp (T + M * d) * b ^ (2 * a) := by
  let mu : ℝ≥0 := ⟨cp * lam, by positivity⟩
  let f : ℕ × ℕ → ℝ := fun z =>
    (if (z.1 : ℝ) ≤ T then factorialStatistic d (fun j => c j / n ^ j) z.2 ^ 2 else 0) *
      (poissonPMFReal lam z.2 * poissonPMFReal mu z.1)
  let g : ℕ × ℕ → ℝ := fun z => ((d : ℝ) + 1) * ∑ j ∈ Finset.range (d + 1),
    (c j / n ^ j) ^ (2 : ℕ) *
      ((if (z.1 : ℝ) ≤ T then (z.2.descFactorial j : ℝ) ^ 2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1))
  have hg : HasSum g (((d : ℝ) + 1) * ∑ j ∈ Finset.range (d + 1),
      (c j / n ^ j) ^ (2 : ℕ) * poissonPilotSecond lam mu T j) := by
    have h := hasSum_sum (s := Finset.range (d + 1)) (fun j _ =>
      (poissonPilotSecond_joint_hasSum lam mu T j).mul_left ((c j / n ^ j) ^ (2 : ℕ)))
    simpa only [Finset.sum_apply] using h.mul_left ((d : ℝ) + 1)
  have hf0 (z : ℕ × ℕ) : 0 ≤ f z := by
    dsimp [f]
    split_ifs <;> exact mul_nonneg (by positivity) (mul_nonneg poissonPMFReal_nonneg poissonPMFReal_nonneg)
  have hfg (z : ℕ × ℕ) : f z ≤ g z := by
    have hsq := Finset.sum_mul_sq_le_sq_mul_sq (Finset.range (d + 1)) (fun _ : ℕ => (1 : ℝ))
      (fun j => (c j / n ^ j) * (z.2.descFactorial j : ℝ))
    simp only [one_mul, one_pow, Finset.sum_const, Finset.card_range, nsmul_eq_mul, mul_one,
      Nat.cast_add, Nat.cast_one, mul_pow] at hsq
    have hm := mul_le_mul_of_nonneg_right hsq
      (mul_nonneg (poissonPMFReal_nonneg (r := lam) (n := z.2))
        (poissonPMFReal_nonneg (r := mu) (n := z.1)))
    dsimp [f, g]
    by_cases hz : (z.1 : ℝ) ≤ T
    · simp only [if_pos hz]
      convert hm using 1
      simp only [Finset.mul_sum, Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro j _
      ring
    · simp [hz]
  have hs : Summable f := Summable.of_nonneg_of_le hf0 hfg hg.summable
  refine ⟨hs, ?_⟩
  have h := hs.tsum_le_tsum hfg hg.summable
  rw [hg.tsum_eq] at h
  apply h.trans
  have hterm (j : ℕ) (hj : j ∈ Finset.range (d + 1)) := near_one_selected_degree_second
    hn hb hbeta hA hcp0 hT hM hcp lam (show j ≤ d by have := Finset.mem_range.mp hj; omega)
      hd (hcoef j (by have := Finset.mem_range.mp hj; omega))
  have hsum := Finset.sum_le_sum (s := Finset.range (d + 1)) hterm
  have hmul := mul_le_mul_of_nonneg_left hsum (by positivity : 0 ≤ (d : ℝ) + 1)
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul, Nat.cast_add, Nat.cast_one] at hmul
  nlinarith only [hmul]

end Renyi
