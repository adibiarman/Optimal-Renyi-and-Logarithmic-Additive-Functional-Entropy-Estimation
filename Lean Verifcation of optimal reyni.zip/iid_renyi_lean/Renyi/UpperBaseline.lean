import Renyi.UpperParameters
import Renyi.UpperDegree
import Mathlib.Analysis.MeanInequalitiesPow

/-!
# Baseline transfer and reserved width

The baseline estimates use the actual regularized-root widths. The cutoff
comparison is kept explicit until it is supplied by the preceding parameter
calibration theorem.
-/

noncomputable section
open scoped BigOperators
namespace Renyi

def upperKappa (alpha eps : ℝ) : ℝ := Real.exp (-2 * eps * (alpha - 1))

def upperUStar (eps u0 : ℝ) : ℝ := min (min (eps / 2) (1 / 3)) u0

def upperNominalBaseline (alpha C0 d rho D : ℝ) : ℝ :=
  min (alpha - 1) 1 * d * C0 ^ upperOrderFloor alpha * (rho / D) ^ (alpha - 1)

def upperActualBaseline (k : ℕ) (alpha C0 d a : ℝ) : ℝ :=
  min (alpha - 1) 1 * d * C0 ^ upperOrderFloor alpha * ((k : ℝ) * a) ^ (alpha - 1)

theorem upperUStar_pos {eps u0 : ℝ} (heps : 0 < eps) (hu0 : 0 < u0) :
    0 < upperUStar eps u0 := lt_min (lt_min (by positivity) (by norm_num)) hu0

theorem upperOrderFloor_le_twice_gap {alpha : ℝ} (halpha : 3 / 2 ≤ alpha) :
    (upperOrderFloor alpha : ℝ) ≤ 2 * (alpha - 1) := by
  by_cases h2 : 2 ≤ alpha
  · have hm := upperOrderFloor_le (by linarith : 1 < alpha)
    linarith
  · have hm1 : upperOrderFloor alpha = 1 := by
      apply le_antisymm
      · have hm : upperOrderFloor alpha < 2 :=
          (Nat.floor_lt (by linarith : 0 ≤ alpha)).mpr (by exact_mod_cast lt_of_not_ge h2)
        omega
      · exact upperOrderFloor_one_le (by linarith)
    rw [hm1]
    norm_num
    linarith

theorem upper_gap_ratio_ge_third {alpha : ℝ} (halpha : 3 / 2 ≤ alpha) :
    (1 : ℝ) / 3 ≤ (alpha - 1) / alpha := by
  apply (le_div_iff₀ (by linarith : 0 < alpha)).mpr
  linarith

/-- The last choice of D forces the nominal baseline below the target power ratio. -/
theorem upperNominalBaseline_le_kappa {alpha eps C0 d rho D : ℝ}
    (halpha : 3 / 2 ≤ alpha) (hC0 : 1 ≤ C0) (hd : 0 ≤ d) (hd1 : d ≤ 1)
    (hrho : 0 < rho) (hD : rho * C0 ^ 2 * Real.exp (2 * eps) ≤ D) :
    upperNominalBaseline alpha C0 d rho D ≤ upperKappa alpha eps := by
  have hbeta : 0 < alpha - 1 := by linarith
  have hC : 0 < C0 := by linarith
  have hDpos : 0 < D := lt_of_lt_of_le (by positivity) hD
  have hm := upperOrderFloor_le_twice_gap halpha
  have hcpow : C0 ^ upperOrderFloor alpha ≤ (C0 ^ (2 : ℕ)) ^ (alpha - 1) := by
    rw [← Real.rpow_natCast, ← Real.rpow_natCast C0 2, ← Real.rpow_mul hC.le]
    exact Real.rpow_le_rpow_of_exponent_le hC0 hm
  have hbase : C0 ^ 2 * (rho / D) ≤ Real.exp (-2 * eps) := by
    have hdiv : (C0 ^ 2 * rho) / D ≤ 1 / Real.exp (2 * eps) := by
      apply (div_le_div_iff₀ hDpos (Real.exp_pos _)).mpr
      nlinarith
    have heq : Real.exp (-2 * eps) = 1 / Real.exp (2 * eps) := by
      rw [show -2 * eps = -(2 * eps) by ring, Real.exp_neg, one_div]
    rw [heq]
    convert hdiv using 1
    ring
  have hpow := Real.rpow_le_rpow (by positivity : 0 ≤ C0 ^ 2 * (rho / D)) hbase hbeta.le
  rw [Real.mul_rpow (sq_nonneg C0) (div_nonneg hrho.le hDpos.le), ← Real.exp_mul] at hpow
  have hcore : C0 ^ upperOrderFloor alpha * (rho / D) ^ (alpha - 1) ≤
      upperKappa alpha eps := by
    apply (mul_le_mul_of_nonneg_right hcpow (Real.rpow_nonneg (div_nonneg hrho.le hDpos.le) _)).trans
    simpa only [upperKappa] using hpow
  have hpref : min (alpha - 1) 1 * d ≤ 1 := by
    have h := mul_le_mul (min_le_right (alpha - 1) 1) hd1 hd (by norm_num : (0 : ℝ) ≤ 1)
    simpa using h
  have hcore0 : 0 ≤ C0 ^ upperOrderFloor alpha * (rho / D) ^ (alpha - 1) := by positivity
  unfold upperNominalBaseline
  calc
    _ = (min (alpha - 1) 1 * d) *
        (C0 ^ upperOrderFloor alpha * (rho / D) ^ (alpha - 1)) := by ring
    _ ≤ 1 * upperKappa alpha eps := mul_le_mul hpref hcore hcore0 (by norm_num)
    _ = upperKappa alpha eps := one_mul _

theorem upperActualBaseline_nonneg {k : ℕ} {alpha C0 d a : ℝ}
    (halpha : 1 ≤ alpha) (hC0 : 0 ≤ C0) (hd : 0 ≤ d) (ha : 0 ≤ a) :
    0 ≤ upperActualBaseline k alpha C0 d a := by
  have hbeta : 0 ≤ alpha - 1 := sub_nonneg.mpr halpha
  unfold upperActualBaseline
  positivity

/-- The baseline is monotone in its physical cutoff. -/
theorem upperNominalBaseline_le_actual {k : ℕ} {alpha C0 d rho D a : ℝ}
    (halpha : 1 ≤ alpha) (hC0 : 0 ≤ C0) (hd : 0 ≤ d)
    (hrhoD : 0 ≤ rho / D) (hcut : rho / D ≤ (k : ℝ) * a) :
    upperNominalBaseline alpha C0 d rho D ≤ upperActualBaseline k alpha C0 d a := by
  apply mul_le_mul_of_nonneg_left
    (Real.rpow_le_rpow hrhoD hcut (sub_nonneg.mpr halpha))
  exact mul_nonneg (mul_nonneg (le_min (sub_nonneg.mpr halpha) (by norm_num)) hd)
    (pow_nonneg hC0 _)

theorem upperW_nonneg {k : ℕ} {alpha eps : ℝ} (halpha : 1 < alpha)
    (hgamma : 0 < fractionalPart alpha) (hgamma1 : fractionalPart alpha < 1) :
    0 ≤ upperW k alpha eps := by
  have hs := (upper_root_slack (k := k) (ε := eps) halpha hgamma hgamma1).1
  have hh : 0 < fractionalPart alpha * (1 - fractionalPart alpha) :=
    mul_pos hgamma (sub_pos.mpr hgamma1)
  unfold upperW
  exact add_nonneg hs (div_nonneg (le_max_right _ _) hh.le)

theorem upperV_pos {k : ℕ} {alpha eps : ℝ} (halpha : 1 < alpha)
    (hgamma : 0 < fractionalPart alpha) (hgamma1 : fractionalPart alpha < 1) :
    0 < upperV k alpha eps := by
  have hx : 0 < rootMultiplier k alpha eps :=
    zero_lt_one.trans_le (one_le_rootMultiplier halpha hgamma hgamma1)
  unfold upperV
  exact mul_pos (div_pos (sub_pos.mpr halpha) (by linarith)) (Real.rpow_pos_of_pos hx _)

theorem upperU_pos {k : ℕ} {alpha eps u0 : ℝ} (halpha : 1 < alpha)
    (hgamma : 0 < fractionalPart alpha) (hgamma1 : fractionalPart alpha < 1)
    (hu0 : 0 < u0) : 0 < upperU k alpha eps u0 := by
  have hv := upperV_pos (k := k) (eps := eps) halpha hgamma hgamma1
  have hh := mul_pos hgamma (sub_pos.mpr hgamma1)
  exact lt_min (add_pos hv hh) hu0

/-- A positive slack can only occur when the regularization margin is uniformly large. -/
theorem upperUStar_le_upperU_of_w_pos {k : ℕ} {alpha eps u0 : ℝ}
    (halpha : 3 / 2 ≤ alpha) (hgamma : 0 < fractionalPart alpha)
    (hgamma1 : fractionalPart alpha < 1) (heps : 0 < eps)
    (hw : 0 < upperW k alpha eps) :
    upperUStar eps u0 ≤ upperU k alpha eps u0 := by
  have ha : 1 < alpha := by linarith
  have hh : 0 < fractionalPart alpha * (1 - fractionalPart alpha) :=
    mul_pos hgamma (sub_pos.mpr hgamma1)
  have hx := one_le_rootMultiplier (k := k) (ε := eps) ha hgamma hgamma1
  have hs := upper_root_slack (k := k) (ε := eps) ha hgamma hgamma1
  have hu0 : upperUStar eps u0 ≤ u0 := min_le_right _ _
  have hue : upperUStar eps u0 ≤ eps / 2 :=
    (min_le_left _ _).trans (min_le_left _ _)
  have hut : upperUStar eps u0 ≤ (1 : ℝ) / 3 :=
    (min_le_left _ _).trans (min_le_right _ _)
  apply le_min _ hu0
  by_cases hx1 : rootMultiplier k alpha eps = 1
  · have hv : (1 : ℝ) / 3 ≤ upperV k alpha eps := by
      simpa only [upperV, hx1, Real.one_rpow, mul_one] using upper_gap_ratio_ge_third halpha
    linarith
  · have hxgt : 1 < rootMultiplier k alpha eps := lt_of_le_of_ne hx (Ne.symm hx1)
    have hs0 := hs.2.1 hxgt
    have hv : eps * (alpha - 1) < upperV k alpha eps := by
      by_contra hv
      have hv' : upperV k alpha eps - eps * (alpha - 1) ≤ 0 := by linarith
      simp only [upperW, hs0, max_eq_right hv', zero_div, add_zero] at hw
      exact lt_irrefl 0 hw
    have hbe : eps / 2 ≤ eps * (alpha - 1) := by nlinarith
    linarith

def upperReserveConstant (eps Ch u0 : ℝ) : ℝ := min (min 1 Ch) (eps / (2 * u0))

/-- An explicit positive fraction of u is reserved in the logarithmic width. -/
theorem upper_reserved_delta {k : ℕ} {alpha eps Ch u0 : ℝ}
    (halpha : 3 / 2 ≤ alpha) (hgamma : 0 < fractionalPart alpha)
    (hgamma1 : fractionalPart alpha < 1) (heps : 0 < eps)
    (hCh : 0 < Ch) (hu0 : 0 < u0) :
    0 < upperReserveConstant eps Ch u0 ∧
      upperReserveConstant eps Ch u0 * upperU k alpha eps u0 ≤ upperDelta k alpha eps Ch := by
  have ha : 1 < alpha := by linarith
  have hv := (upperV_pos (k := k) (eps := eps) ha hgamma hgamma1).le
  have hh := (mul_pos hgamma (sub_pos.mpr hgamma1)).le
  have hu := (upperU_pos (k := k) (eps := eps) ha hgamma hgamma1 hu0).le
  have hc : 0 < upperReserveConstant eps Ch u0 :=
    lt_min (lt_min zero_lt_one hCh) (div_pos heps (by positivity))
  have hc1 : upperReserveConstant eps Ch u0 ≤ 1 :=
    (min_le_left _ _).trans (min_le_left _ _)
  have hcCh : upperReserveConstant eps Ch u0 ≤ Ch :=
    (min_le_left _ _).trans (min_le_right _ _)
  have hce : upperReserveConstant eps Ch u0 ≤ eps / (2 * u0) := min_le_right _ _
  have huv : upperU k alpha eps u0 ≤
      upperV k alpha eps + fractionalPart alpha * (1 - fractionalPart alpha) := min_le_left _ _
  have huu : upperU k alpha eps u0 ≤ u0 := min_le_right _ _
  refine ⟨hc, le_min ?_ ?_⟩
  · have h1 := mul_le_mul_of_nonneg_left huv hc.le
    have h2 := mul_le_mul_of_nonneg_right hc1 hv
    have h3 := mul_le_mul_of_nonneg_right hcCh hh
    nlinarith
  · have h1 := mul_le_mul hce huu hu (by positivity : 0 ≤ eps / (2 * u0))
    have hid : eps / (2 * u0) * u0 = eps / 2 := by field_simp
    rw [hid] at h1
    nlinarith

/-- The reserved logarithmic width yields the required multiplicative margin. -/
theorem upper_reserved_power_gap {k : ℕ} {alpha eps Ch u0 : ℝ}
    (halpha : 3 / 2 ≤ alpha) (hgamma : 0 < fractionalPart alpha)
    (hgamma1 : fractionalPart alpha < 1) (heps : 0 < eps)
    (hCh : 0 < Ch) (hu0 : 0 < u0) :
    upperReserveConstant eps Ch u0 * upperKappa alpha eps * upperU k alpha eps u0 ≤
      Real.exp (-upperE0 k alpha eps Ch) - upperKappa alpha eps := by
  have hd := (upper_reserved_delta (k := k) halpha hgamma hgamma1 heps hCh hu0).2
  have he := Real.add_one_le_exp (upperDelta k alpha eps Ch)
  have hκ : 0 ≤ upperKappa alpha eps := (Real.exp_pos _).le
  have h1 := mul_le_mul_of_nonneg_left hd hκ
  have h2 := mul_le_mul_of_nonneg_left (by linarith :
    upperDelta k alpha eps Ch ≤ Real.exp (upperDelta k alpha eps Ch) - 1) hκ
  have hid : Real.exp (-upperE0 k alpha eps Ch) - upperKappa alpha eps =
      upperKappa alpha eps * (Real.exp (upperDelta k alpha eps Ch) - 1) := by
    unfold upperE0 upperKappa
    rw [show -(2 * eps * (alpha - 1) - upperDelta k alpha eps Ch) =
      -2 * eps * (alpha - 1) + upperDelta k alpha eps Ch by ring, Real.exp_add]
    ring
  rw [hid]
  nlinarith

/-- Baseline transfer after the preceding parameter lemma supplies the zero-slack cutoff. -/
theorem upper_baseline_transfer_of_cutoff {k : ℕ} {alpha eps C0 d rho D a u0 : ℝ}
    (halpha : 3 / 2 ≤ alpha) (hgamma : 0 < fractionalPart alpha)
    (hgamma1 : fractionalPart alpha < 1) (heps : 0 < eps) (hu0 : 0 < u0)
    (hC0 : 1 ≤ C0) (hd : 0 ≤ d) (hd1 : d ≤ 1) (hrho : 0 < rho)
    (ha : 0 ≤ a) (hD : rho * C0 ^ 2 * Real.exp (2 * eps) ≤ D)
    (hcut : upperW k alpha eps = 0 → rho / D ≤ (k : ℝ) * a) :
    upperNominalBaseline alpha C0 d rho D ≤ upperActualBaseline k alpha C0 d a +
      upperKappa alpha eps * upperU k alpha eps u0 / upperUStar eps u0 := by
  have hal : 1 < alpha := by linarith
  have hC : 0 < C0 := by linarith
  have hDpos : 0 < D := lt_of_lt_of_le (by positivity) hD
  have hs := upperUStar_pos heps hu0
  have hu := upperU_pos (k := k) (eps := eps) hal hgamma hgamma1 hu0
  have hkappa : 0 < upperKappa alpha eps := Real.exp_pos _
  have hactual := upperActualBaseline_nonneg (k := k) hal.le hC.le hd ha
  by_cases hw : upperW k alpha eps = 0
  · apply (upperNominalBaseline_le_actual hal.le hC.le hd
      (div_nonneg hrho.le hDpos.le) (hcut hw)).trans
    exact le_add_of_nonneg_right (by positivity)
  · have hwpos : 0 < upperW k alpha eps :=
      lt_of_le_of_ne (upperW_nonneg hal hgamma hgamma1) (Ne.symm hw)
    have hlarge := upperUStar_le_upperU_of_w_pos (u0 := u0) halpha hgamma hgamma1 heps hwpos
    have hk : upperKappa alpha eps ≤
        upperKappa alpha eps * upperU k alpha eps u0 / upperUStar eps u0 := by
      apply (le_div_iff₀ hs).mpr
      exact mul_le_mul_of_nonneg_left hlarge hkappa.le
    exact (upperNominalBaseline_le_kappa halpha hC0 hd hd1 hrho hD).trans
      (hk.trans (le_add_of_nonneg_left hactual))

/-- The original two-sided cutoff calibration supplies the required zero-slack inequality. -/
theorem upper_cutoff_zero_slack {k : ℕ} {alpha eps rminus D a : ℝ}
    (hk : 0 < k) (halpha : 3 / 2 ≤ alpha) (hrminus : 0 < rminus) (hD : 0 < D)
    (hcut : rminus / D * Real.exp (-upperW k alpha eps) ≤ a / ((alpha - 1) / (alpha * k)))
    (hw : upperW k alpha eps = 0) : (rminus / 3) / D ≤ (k : ℝ) * a := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have ha : 0 < alpha := by linarith
  have hb : 0 < alpha - 1 := by linarith
  rw [hw, neg_zero, Real.exp_zero, mul_one] at hcut
  have hh := (le_div_iff₀ (div_pos hb (mul_pos ha hkR))).mp hcut
  have h1 := mul_le_mul_of_nonneg_right hh hkR.le
  have hid : (rminus / D * ((alpha - 1) / (alpha * k))) * k =
      (rminus / D) * ((alpha - 1) / alpha) := by field_simp
  rw [hid] at h1
  have h2 := mul_le_mul_of_nonneg_left (upper_gap_ratio_ge_third halpha)
    (div_nonneg hrminus.le hD.le)
  rw [show (rminus / 3) / D = (rminus / D) * (1 / 3) by ring]
  exact h2.trans (by simpa only [mul_comm a] using h1)

/-- Algebraic transfer of the complete baseline-plus-margin budget. -/
theorem baseline_margin_transfer {Ebase Eactual kappa u ustar Pstar P B : ℝ}
    (hactual : 0 ≤ Eactual) (hkappa : 0 ≤ kappa) (hu : 0 ≤ u) (hustar : 0 < ustar)
    (hPstar : 0 ≤ Pstar) (hPP : Pstar ≤ P) (hB : 0 ≤ B)
    (hbase : Ebase ≤ Eactual + kappa * u / ustar) :
    Ebase * Pstar + kappa * u * P + kappa * B ≤
      (1 + 1 / ustar) * (Eactual * Pstar + kappa * u * P + kappa * B) := by
  have h1 := mul_le_mul_of_nonneg_right hbase hPstar
  have h2 := mul_le_mul_of_nonneg_left hPP (div_nonneg (mul_nonneg hkappa hu) hustar.le)
  have h3 : kappa * u * P ≤ Eactual * Pstar + kappa * u * P + kappa * B := by
    nlinarith [mul_nonneg hactual hPstar, mul_nonneg hkappa hB]
  have h4 := (div_le_div_iff_of_pos_right hustar).mpr h3
  have hid : (kappa * u / ustar) * P = kappa * u * P / ustar := by ring
  rw [hid] at h2
  have hid2 : (1 + 1 / ustar) * (Eactual * Pstar + kappa * u * P + kappa * B) =
      Eactual * Pstar + kappa * u * P + kappa * B +
        (Eactual * Pstar + kappa * u * P + kappa * B) / ustar := by ring
  rw [hid2]
  nlinarith

/-- Jensen's lower bound for the power sum of an actual simplex point. -/
theorem simplex_powerSum_uniform_lower {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {alpha : ℝ} (halpha : 1 ≤ alpha) :
    (k : ℝ) ^ (1 - alpha) ≤ powerSum p alpha := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hJ := Real.rpow_sum_le_const_mul_sum_rpow_of_nonneg
    (s := Finset.univ) (f := p.mass) (p := alpha) halpha (fun i _ => p.nonneg i)
  simp only [p.normalized, Real.one_rpow, Finset.card_univ, Fintype.card_fin] at hJ
  have h := mul_le_mul_of_nonneg_left hJ (Real.rpow_nonneg hkR.le (1 - alpha))
  have hid : (k : ℝ) ^ (1 - alpha) * (k : ℝ) ^ (alpha - 1) = 1 := by
    rw [← Real.rpow_add hkR]
    simp
  rw [mul_one, ← mul_assoc, hid, one_mul] at h
  exact h

theorem upper_cutoff_scaled_upper {k : ℕ} {alpha eps rplus D a : ℝ}
    (hk : 0 < k) (halpha : 1 < alpha) (hgamma : 0 < fractionalPart alpha)
    (hgamma1 : fractionalPart alpha < 1) (hrplus : 0 < rplus) (hD : 0 < D)
    (hcut : a / ((alpha - 1) / (alpha * k)) ≤ rplus / D * Real.exp (-upperW k alpha eps)) :
    (k : ℝ) * a ≤ rplus / D := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have ha : 0 < alpha := by linarith
  have hb : 0 < alpha - 1 := sub_pos.mpr halpha
  have hw := upperW_nonneg (k := k) (eps := eps) halpha hgamma hgamma1
  have he : Real.exp (-upperW k alpha eps) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
  have hh := hcut.trans (by simpa only [mul_one] using
    mul_le_mul_of_nonneg_left he (div_nonneg hrplus.le hD.le))
  have hdiv := (div_le_iff₀ (div_pos hb (mul_pos ha hkR))).mp hh
  have h1 := mul_le_mul_of_nonneg_right hdiv hkR.le
  have hid : (rplus / D * ((alpha - 1) / (alpha * k))) * k =
      (rplus / D) * ((alpha - 1) / alpha) := by field_simp
  rw [hid] at h1
  have hratio : (alpha - 1) / alpha ≤ 1 := (div_le_one ha).mpr (by linarith)
  have h2 := mul_le_mul_of_nonneg_left hratio (div_nonneg hrplus.le hD.le)
  simpa only [mul_one, mul_comm a] using h1.trans h2

/-- Full source baseline lemma for the actual regularized-root parameter construction.
The cutoff constants are obtained from the proved parameter theorem; no cutoff,
slack, root, or reserved-width certificate is assumed in this statement. -/
theorem upper_baseline_uniform {eps Ch cb lambda CL cL u0 C0 d : ℝ}
    (heps : 0 < eps) (hCh : 0 < Ch) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hu0 : 0 < u0) (hC0 : 1 ≤ C0)
    (hd : 0 < d) (hd1 : d ≤ 1) :
    ∃ rhoMinus rhoPlus c : ℝ, 0 < rhoMinus ∧ 0 < rhoPlus ∧ 0 < c ∧
      ∀ (k : ℕ) (alpha D : ℝ), 0 < k → 3 / 2 ≤ alpha →
        0 < fractionalPart alpha → fractionalPart alpha < 1 →
        rhoMinus * C0 ^ 2 * Real.exp (2 * eps) ≤ D →
        (k : ℝ) * upperA k alpha eps Ch D cb lambda CL cL ≤ rhoPlus / D ∧
        upperNominalBaseline alpha C0 d rhoMinus D ≤
          upperActualBaseline k alpha C0 d (upperA k alpha eps Ch D cb lambda CL cL) +
            upperKappa alpha eps * upperU k alpha eps u0 / upperUStar eps u0 ∧
        (∀ (p : Simplex k) (B : ℝ), 0 ≤ B →
          upperNominalBaseline alpha C0 d rhoMinus D * (k : ℝ) ^ (1 - alpha) +
            upperKappa alpha eps * upperU k alpha eps u0 * powerSum p alpha +
            upperKappa alpha eps * B ≤
          (1 + 1 / upperUStar eps u0) *
            (upperActualBaseline k alpha C0 d (upperA k alpha eps Ch D cb lambda CL cL) *
                (k : ℝ) ^ (1 - alpha) +
              upperKappa alpha eps * upperU k alpha eps u0 * powerSum p alpha +
              upperKappa alpha eps * B)) ∧
        c * upperU k alpha eps u0 ≤ upperDelta k alpha eps Ch ∧
        c * upperKappa alpha eps * upperU k alpha eps u0 ≤
          Real.exp (-upperE0 k alpha eps Ch) - upperKappa alpha eps := by
  obtain ⟨rminus, rplus, hrminus, hrplus, hcut⟩ :=
    upper_actual_cutoff heps hCh.le hcb hlambda hCL hcL
  have hrho : 0 < rminus / 3 := by positivity
  have hc : 0 < upperReserveConstant eps Ch u0 :=
    lt_min (lt_min zero_lt_one hCh) (div_pos heps (by positivity))
  refine ⟨rminus / 3, rplus, upperReserveConstant eps Ch u0, hrho, hrplus, hc, ?_⟩
  intro k alpha D hk halpha hgamma hgamma1 hD
  have hal : 1 < alpha := by linarith
  have hC : 0 < C0 := by linarith
  have hDpos : 0 < D := lt_of_lt_of_le (by positivity) hD
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hscale : 0 < (alpha - 1) / (alpha * k) := by
    exact div_pos (sub_pos.mpr hal) (mul_pos (by linarith) hkR)
  have hcuts := hcut k alpha D hk hal hgamma hgamma1 hDpos
  have hratio : 0 < upperA k alpha eps Ch D cb lambda CL cL / ((alpha - 1) / (alpha * k)) :=
    lt_of_lt_of_le (mul_pos (div_pos hrminus hDpos) (Real.exp_pos _)) hcuts.1
  have ha : 0 < upperA k alpha eps Ch D cb lambda CL cL := by
    have h := (lt_div_iff₀ hscale).mp hratio
    simpa using h
  have htransfer := upper_baseline_transfer_of_cutoff halpha hgamma hgamma1 heps hu0
    hC0 hd.le hd1 hrho ha.le hD
    (fun hw => upper_cutoff_zero_slack hk halpha hrminus hDpos hcuts.1 hw)
  have hu := upperU_pos (k := k) (eps := eps) hal hgamma hgamma1 hu0
  have hdelta := (upper_reserved_delta (k := k) halpha hgamma hgamma1 heps hCh hu0).2
  have hgap := upper_reserved_power_gap (k := k) halpha hgamma hgamma1 heps hCh hu0
  refine ⟨upper_cutoff_scaled_upper hk hal hgamma hgamma1 hrplus hDpos hcuts.2,
    htransfer, ?_, hdelta, hgap⟩
  intro p B hB
  exact baseline_margin_transfer
    (upperActualBaseline_nonneg hal.le hC.le hd.le ha.le)
    (Real.exp_pos _).le hu.le (upperUStar_pos heps hu0)
    (Real.rpow_nonneg hkR.le _) (simplex_powerSum_uniform_lower hk p hal.le) hB htransfer

end Renyi
