import Renyi.CoupledSaturationLower

/-! Quantitative endpoint stability for the bounded-energy clipped overlap argument. -/
noncomputable section
namespace Renyi

def dampedFloorThreshold (q r E M : ℝ) : ℝ :=
  min (1/2) (min (E*(q-r)/(4*q)) ((q-r)/(4*q*(M+1))))

theorem dampedFloorThreshold_pos {q r E M : ℝ} (hr : 0≤r) (hrq : r<q) (hE : 0<E) (hM : 0≤M) :
    0<dampedFloorThreshold q r E M := by
  have hq : 0<q := hr.trans_lt hrq
  have hqr : 0<q-r := sub_pos.mpr hrq
  unfold dampedFloorThreshold
  positivity

/-- A fixed floor dominates a prescribed baseline at every sufficiently small endpoint order. -/
theorem damped_floor_threshold_lower {s q r E M A : ℝ} (hs : 0<s)
    (hr : 0≤r) (hrq : r<q) (_hE : 0<E) (hM : 0≤M)
    (hsmall : s≤dampedFloorThreshold q r E M) (hA : 1-Real.exp (-E/s)≤A) :
    r≤(A*Real.exp (-M*s))*q := by
  let c := (q-r)/(4*q)
  have hq : 0<q := hr.trans_lt hrq
  have hc : 0<c := div_pos (sub_pos.mpr hrq) (by positivity)
  have hc1 : c≤1/4 := by
    apply (div_le_iff₀ (show 0<4*q by positivity)).mpr
    nlinarith only [hr]
  have hscale1 : s≤E*c := by
    have hh := hsmall.trans ((min_le_right _ _).trans (min_le_left _ _))
    convert hh using 1
    dsimp [c]
    ring
  have hscale2 : s≤c/(M+1) := by
    have hh := hsmall.trans ((min_le_right _ _).trans (min_le_right _ _))
    convert hh using 1
    dsimp [c]
    have hM1 : 0<M+1 := by positivity
    field_simp [hq.ne',hM1.ne']
  have hexp : Real.exp (-E/s)≤c := by
    have hbudget : 1/c≤E/s := by
      apply (le_div_iff₀ hs).mpr
      have hsdiv : s/c≤E := (div_le_iff₀ hc).mpr hscale1
      simpa only [div_eq_mul_inv,mul_comm,one_mul] using hsdiv
    have hh := exp_neg_le_of_large hc hbudget
    simpa only [neg_div] using hh
  have hA' : 1-c≤A := by linarith only [hA,hexp]
  have hMd : M*s≤c := by
    have hh := (le_div_iff₀ (show 0<M+1 by positivity)).mp hscale2
    nlinarith only [hh,hs]
  have he := Real.add_one_le_exp (-M*s)
  have he' : 1-c≤Real.exp (-M*s) := by linarith only [he,hMd]
  have hprod := mul_le_mul hA' he' (show 0≤1-c by linarith only [hc1])
    (show 0≤A by linarith only [hA',hc1])
  have hmul := mul_le_mul_of_nonneg_right hprod hq.le
  have hid : 4*q*c=q-r := by dsimp [c];field_simp
  nlinarith only [hmul,hid,hr,hrq,mul_nonneg hq.le (sq_nonneg c)]

lemma overlapA_exponential_complement {γ z E : ℝ} (hγ : 0<γ) (hγ1 : γ<1)
    (hz : 0<z) (hz1 : z<1) (hzE : z≤Real.exp (-E)) :
    1-Real.exp (-E/γ)≤overlapA γ z := by
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have he := (overlap_endpoints hγ hγ1 hz hz1).2
  have hp := Real.rpow_le_rpow hz.le hzE (one_div_pos.mpr hγ).le
  rw [←Real.exp_mul,show -E*(1/γ)=-E/γ by ring] at hp
  have hm := mul_le_of_le_one_left (Real.rpow_nonneg hz.le (1/γ)) hc.2.2.2.le
  linarith only [he,hp,hm]

/-- The actual low scalar coefficient reaches every fixed floor above the maximal baseline. -/
theorem overlapA_damped_floor_lower {γ z q r E M : ℝ} (hγ : 0<γ) (hγ1 : γ<1)
    (hz : 0<z) (hz1 : z<1) (hzE : z≤Real.exp (-E))
    (hr : 0≤r) (hrq : r<q) (hE : 0<E) (hM : 0≤M)
    (hsmall : γ≤dampedFloorThreshold q r E M) :
    r≤(overlapA γ z*Real.exp (-M*γ))*q :=
  damped_floor_threshold_lower hγ hr hrq hE hM hsmall (overlapA_exponential_complement hγ hγ1 hz hz1 hzE)

/-- The same endpoint stability holds for the reserved actual high scalar coefficient. -/
theorem overlapB_damped_floor_lower {γ z q r E M : ℝ} (hγ : 0<γ) (hγ1 : γ<1)
    (hz : 0<z) (hz1 : z<1) (hzE : z≤Real.exp (-E))
    (hr : 0≤r) (hrq : r<q) (hE : 0<E) (hM : 0≤M)
    (hsmall : 1-γ≤dampedFloorThreshold q r E M) :
    r≤(overlapB γ z*Real.exp (-M*(1-γ)))*q := by
  have hh := overlap_complement_bound hγ hγ1 hz hz1 hzE
  exact damped_floor_threshold_lower (by linarith only [hγ1]) hr hrq hE hM hsmall (by linarith only [hh])

lemma fractional_power_uniform_upper {s Z R : ℝ} (hs : 0<s) (hs1 : s≤1)
    (hZ : 0≤Z) (hZR : Z≤R) : (Z/s)^s≤Real.exp 1*max R 1 := by
  have hself := endpoint_self_power_lower hs
  have hpower : Z^s≤max R 1 := by
    by_cases hZ1 : Z≤1
    · exact (Real.rpow_le_one hZ hZ1 hs.le).trans (le_max_right _ _)
    · have hh := Real.rpow_le_rpow_of_exponent_le (le_of_not_ge hZ1) hs1
      rw [Real.rpow_one] at hh
      exact hh.trans (hZR.trans (le_max_left _ _))
  rw [Real.div_rpow hZ hs.le]
  apply (div_le_iff₀ (Real.rpow_pos_of_pos hs s)).mpr
  have hexp := mul_le_mul_of_nonneg_left hself (Real.exp_pos 1).le
  have hid : Real.exp 1*Real.exp (-1)=1 := by rw [←Real.exp_add];norm_num
  rw [hid] at hexp
  have hm := mul_le_mul_of_nonneg_right hexp (show 0≤max R 1 by exact zero_le_one.trans (le_max_right _ _))
  nlinarith only [hm,hpower]

/-- Clipping a bounded ideal profile incurs only an O(s) exponential loss once s is bounded below. -/
lemma clipped_profile_exponential_lower {s s0 q R U u : ℝ}
    (hs : 0≤s) (hs0 : 0<s0) (hq : 0<q) (hR : 0<R)
    (hU : 0≤U) (hUR : U≤R) (hu : min q U≤u) (haway : q<U → s0≤s) :
    Real.exp (-(-Real.log (min 1 (q/R))/s0)*s)*U≤u := by
  let a := min 1 (q/R)
  have ha : 0<a := lt_min (by norm_num) (div_pos hq hR)
  have ha1 : a≤1 := min_le_left _ _
  have hloga : Real.log a≤0 := Real.log_nonpos ha.le ha1
  by_cases hUq : U≤q
  · have hcoef : Real.exp (-(-Real.log a/s0)*s)≤1 := Real.exp_le_one_iff.mpr (by
      have hpos : 0≤(-Real.log a/s0)*s := mul_nonneg (div_nonneg (neg_nonneg.mpr hloga) hs0.le) hs
      nlinarith only [hpos])
    have hmul := mul_le_of_le_one_left hU hcoef
    exact hmul.trans ((min_eq_right hUq).symm ▸ hu)
  · have hss := haway (lt_of_not_ge hUq)
    have hcoef : Real.exp (-(-Real.log a/s0)*s)≤a := by
      calc
        _ ≤ Real.exp (Real.log a) := by
          apply Real.exp_le_exp.mpr
          have hm := mul_le_mul_of_nonpos_left hss hloga
          rw [show -(-Real.log a/s0)*s=(Real.log a*s)/s0 by ring]
          exact (div_le_iff₀ hs0).mpr hm
        _ = a := Real.exp_log ha
    have hscale : a*U≤q := by
      have hm := mul_le_mul_of_nonneg_right (min_le_right (1:ℝ) (q/R)) hU
      have hm' := mul_le_mul_of_nonneg_left hUR (div_nonneg hq.le hR.le)
      have hid : (q/R)*R=q := by field_simp
      rw [hid] at hm'
      exact hm.trans hm'
    exact (mul_le_mul_of_nonneg_right hcoef hU).trans (hscale.trans ((min_eq_left (le_of_lt (lt_of_not_ge hUq))).symm ▸ hu))

lemma clipped_profile_exponential_fixed_lower {s s0 qmin q R U u : ℝ}
    (hs : 0≤s) (hs0 : 0<s0) (hq : 0<qmin) (hqq : qmin≤q) (hR : 0<R)
    (hU : 0≤U) (hUR : U≤R) (hu : min q U≤u) (haway : q<U → s0≤s) :
    Real.exp (-(-Real.log (min 1 (qmin/R))/s0)*s)*U≤u := by
  let a := min 1 (qmin/R)
  have ha : 0<a := lt_min (by norm_num) (div_pos hq hR)
  have ha1 : a≤1 := min_le_left _ _
  have hloga : Real.log a≤0 := Real.log_nonpos ha.le ha1
  by_cases hUq : U≤q
  · have hcoef : Real.exp (-(-Real.log a/s0)*s)≤1 := Real.exp_le_one_iff.mpr (by
      have hpos : 0≤(-Real.log a/s0)*s := mul_nonneg (div_nonneg (neg_nonneg.mpr hloga) hs0.le) hs
      nlinarith only [hpos])
    have hmul := mul_le_of_le_one_left hU hcoef
    exact hmul.trans ((min_eq_right hUq).symm ▸ hu)
  · have hss := haway (lt_of_not_ge hUq)
    have hcoef : Real.exp (-(-Real.log a/s0)*s)≤a := by
      calc
        _ ≤ Real.exp (Real.log a) := by
          apply Real.exp_le_exp.mpr
          have hm := mul_le_mul_of_nonpos_left hss hloga
          rw [show -(-Real.log a/s0)*s=(Real.log a*s)/s0 by ring]
          exact (div_le_iff₀ hs0).mpr hm
        _ = a := Real.exp_log ha
    have hscale : a*U≤qmin := by
      have hm := mul_le_mul_of_nonneg_right (min_le_right (1:ℝ) (qmin/R)) hU
      have hm' := mul_le_mul_of_nonneg_left hUR (div_nonneg hq.le hR.le)
      have hid : (qmin/R)*R=qmin := by field_simp
      rw [hid] at hm'
      exact hm.trans hm'
    exact (mul_le_mul_of_nonneg_right hcoef hU).trans ((hscale.trans hqq).trans ((min_eq_left (le_of_lt (lt_of_not_ge hUq))).symm ▸ hu))

lemma overlapG_coarse_parameter_lower {γ z : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1) :
    overlapG γ z*Real.exp (-2)≤z := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hG := (overlapG_mem_Ioo hγ hγ1 hz hz1).1
  have hden0 : 0<(1-γ)^(1-γ)*γ^γ := mul_pos (Real.rpow_pos_of_pos hd _) (Real.rpow_pos_of_pos hγ _)
  have hden := mul_le_mul (endpoint_self_power_lower hd) (endpoint_self_power_lower hγ)
    (Real.exp_pos (-1)).le (Real.rpow_pos_of_pos hd (1-γ)).le
  have hexp : Real.exp (-1)*Real.exp (-1)=Real.exp (-2) := by rw [←Real.exp_add];norm_num
  rw [hexp] at hden
  have hA := Real.rpow_le_one hc.1.le hc.2.1.le hd.le
  have hB := Real.rpow_le_one hc.2.2.1.le hc.2.2.2.le hγ.le
  have hnum := mul_le_mul hA hB (Real.rpow_nonneg hc.2.2.1.le γ) (by norm_num : (0:ℝ)≤1)
  simp only [one_mul] at hnum
  have hnum' := mul_le_mul_of_nonneg_left hnum hz.le
  have hid : overlapG γ z*((1-γ)^(1-γ)*γ^γ)=z*(overlapA γ z^(1-γ)*overlapB γ z^γ) := by
    unfold overlapG
    field_simp [hden0.ne']
  have hm := mul_le_mul_of_nonneg_left hden hG.le
  rw [hid] at hm
  nlinarith only [hm,hnum']

lemma sharp_power_pair_product_lower {γ z lam0 C D Z Y u v : ℝ}
    (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hlam : 0<lam0) (hZ : 0≤Z) (hY : 0≤Y)
    (hu : Real.exp (-C*γ)*(Z/γ)^γ≤u)
    (hv : Real.exp (-D*(1-γ))*(Y/(1-γ))^(1-γ)≤v)
    (hcap : lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤Z*Y) :
    z*Real.exp (-(C+D-Real.log lam0)*(γ*(1-γ)))≤u^(1-γ)*v^γ := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hh : 0<γ*(1-γ) := mul_pos hγ hd
  have hu0 : 0≤u := (mul_nonneg (Real.exp_pos _).le (Real.rpow_nonneg (div_nonneg hZ hγ.le) γ)).trans hu
  have hp := mul_le_mul (Real.rpow_le_rpow (by positivity) hu hd.le)
    (Real.rpow_le_rpow (by positivity) hv hγ.le) (by positivity) (Real.rpow_nonneg hu0 (1-γ))
  rw [coupled_lower_power_identity hγ hγ1 hZ hY] at hp
  have hq : lam0*z^(1/(γ*(1-γ)))≤Z*Y/(γ*(1-γ)) := by
    apply (le_div_iff₀ hh).mpr
    nlinarith only [hcap]
  have hraise := Real.rpow_le_rpow (by positivity) hq hh.le
  have hid : (lam0*z^(1/(γ*(1-γ))))^(γ*(1-γ))=Real.exp (Real.log lam0*(γ*(1-γ)))*z := by
    rw [Real.mul_rpow hlam.le (Real.rpow_nonneg hz.le _),←Real.rpow_mul hz.le,
      one_div_mul_cancel hh.ne',Real.rpow_one,Real.rpow_def_of_pos hlam]
  rw [hid] at hraise
  have hm := mul_le_mul_of_nonneg_left hraise (Real.exp_pos (-(C+D)*(γ*(1-γ)))).le
  have heq : Real.exp (-(C+D)*(γ*(1-γ)))*(Real.exp (Real.log lam0*(γ*(1-γ)))*z)=
      z*Real.exp (-(C+D-Real.log lam0)*(γ*(1-γ))) := by
    rw [←mul_assoc,←Real.exp_add,mul_comm]
    congr 2
    ring
  rw [heq] at hm
  exact hm.trans hp

end Renyi
