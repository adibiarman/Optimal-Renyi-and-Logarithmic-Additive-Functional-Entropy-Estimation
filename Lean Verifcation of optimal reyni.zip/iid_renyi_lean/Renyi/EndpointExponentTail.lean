import Renyi.EndpointExponent

/-! Localized exponent cancellation for the actual high endpoint kernel. -/
noncomputable section
open MeasureTheory Set
namespace Renyi

def endpointScaledTail (N d : ℕ) (s z : ℝ) : ℝ :=
  ∫ y in z..((N:ℝ)^2), endpointScaledWeight N d s y

theorem endpointScaledTail_ratio {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s z : ℝ} (hs : 0 < s) (hz : 0 ≤ z) :
    endpointScaledTail N d s z / endpointScaledPrimitive N d s ((N:ℝ)^2) =
      1-endpointProfile N d s (z/(N:ℝ)^2) := by
  have hR : 0 < (N:ℝ)^2 := by positivity
  have hM : 0 < endpointScaledPrimitive N d s ((N:ℝ)^2) := by
    rw [endpointScaledPrimitive_rescale hN s hR.le, div_self hR.ne']
    exact mul_pos (Real.rpow_pos_of_pos hR s) (endpointIntegral_pos hN hd hs)
  have hsum : endpointScaledPrimitive N d s z + endpointScaledTail N d s z =
      endpointScaledPrimitive N d s ((N:ℝ)^2) :=
    intervalIntegral.integral_add_adjacent_intervals
      (endpointScaledWeight_integrable N d hs 0 z)
      (endpointScaledWeight_integrable N d hs z ((N:ℝ)^2))
  have hr := endpointScaledPrimitive_ratio (d := d) hN (s := s) (div_nonneg hz hR.le)
  rw [mul_div_cancel₀ _ hR.ne'] at hr
  rw [← hr]
  field_simp
  linarith

theorem endpointScaledWeight_difference_six {N : ℕ} (hN : 0 < N)
    {s y : ℝ} (hs1 : s ≤ 1) (hy : 1 ≤ y) (hyR : y ≤ (N:ℝ)^2) :
    |endpointScaledWeight N 6 s y - endpointScaledWeight N 6 1 y| ≤
      2*(1-s)*y^(-(11/2:ℝ)) := by
  have hR : 0 < (N:ℝ)^2 := by positivity
  have hy0 : 0 < y := zero_lt_one.trans_le hy
  have hK0 := endpointKernel_nonneg N 6 (y/(N:ℝ)^2)
  have hK := endpointKernel_le_inverse_power hN 6 (div_pos hy0 hR) ((div_le_one hR).2 hyR)
  rw [mul_div_cancel₀ _ hR.ne'] at hK
  have hKr : endpointKernel N 6 (y/(N:ℝ)^2) ≤ y^(-(6:ℝ)) := by
    rw [Real.rpow_neg hy0.le]
    norm_cast
    simpa only [inv_pow, Nat.cast_pow] using hK
  simp only [endpointScaledWeight, sub_self, Real.rpow_zero, one_mul]
  rw [← sub_one_mul, abs_mul, abs_of_nonneg hK0]
  have h := mul_le_mul (endpoint_power_difference_high hs1 hy) hKr hK0
    (mul_nonneg (by linarith : 0 ≤ 2*(1-s)) (Real.rpow_nonneg hy0.le _))
  have hid : (2*(1-s)*y^(1/2:ℝ))*y^(-(6:ℝ)) = 2*(1-s)*y^(-(11/2:ℝ)) := by
    rw [mul_assoc, ← Real.rpow_add hy0]
    norm_num
  exact h.trans_eq hid

theorem endpointScaledTail_difference {N : ℕ} (hN : 0 < N)
    {s z : ℝ} (hs : 1/2 ≤ s) (hs1 : s ≤ 1) (hz : 1 ≤ z) (hzR : z ≤ (N:ℝ)^2) :
    |endpointScaledTail N 6 s z - endpointScaledTail N 6 1 z| ≤
      (1-s)*z^(-(9/2:ℝ)) := by
  have hz0 : 0 < z := zero_lt_one.trans_le hz
  have hR : 0 < (N:ℝ)^2 := by positivity
  have hzero : (0:ℝ) ∉ Set.uIcc z ((N:ℝ)^2) := by
    rw [Set.uIcc_of_le hzR]
    simp only [Set.mem_Icc, not_and_or, not_le]
    exact Or.inl hz0
  have hi := (intervalIntegral.intervalIntegrable_rpow (μ := volume) (a := z) (b := (N:ℝ)^2)
    (r := -(11/2:ℝ)) (Or.inr hzero)).const_mul (2*(1-s))
  have h := intervalIntegral.norm_integral_le_of_norm_le (μ := volume)
    (f := fun y : ℝ => endpointScaledWeight N 6 s y - endpointScaledWeight N 6 1 y) hzR
    (Filter.Eventually.of_forall (fun y hy => by
      simpa only [Real.norm_eq_abs] using endpointScaledWeight_difference_six hN hs1
        (hz.trans hy.1.le) hy.2)) hi
  have heval : (∫ y in z..((N:ℝ)^2), 2*(1-s)*y^(-(11/2:ℝ))) =
      (4/9:ℝ)*(1-s)*(z^(-(9/2:ℝ))-((N:ℝ)^2)^(-(9/2:ℝ))) := by
    rw [intervalIntegral.integral_const_mul, integral_rpow (Or.inr ⟨by norm_num,hzero⟩)]
    norm_num
    ring
  rw [heval, Real.norm_eq_abs] at h
  unfold endpointScaledTail
  rw [← intervalIntegral.integral_sub (endpointScaledWeight_integrable N 6 (by linarith) z ((N:ℝ)^2))
    (endpointScaledWeight_integrable N 6 (by norm_num) z ((N:ℝ)^2))]
  apply h.trans
  nlinarith [Real.rpow_nonneg hz0.le (-(9/2:ℝ)), Real.rpow_nonneg hR.le (-(9/2:ℝ))]

theorem normalized_difference_refined {u v m n D E : ℝ}
    (hm : 0 < m) (hn : 0 < n) (hv : 0 ≤ v)
    (huv : |u-v| ≤ D) (hmn : |m-n| ≤ E) :
    |u/m-v/n| ≤ (D+(v/n)*E)/m := by
  have hvn0 : 0 ≤ v/n := div_nonneg hv hn.le
  have hid : u/m-v/n = ((u-v)+(v/n)*(n-m))/m := by field_simp; ring
  rw [hid, abs_div, abs_of_pos hm]
  apply div_le_div_of_nonneg_right _ hm.le
  have hh := abs_add_le (u-v) ((v/n)*(n-m))
  rw [abs_mul, abs_of_nonneg hvn0, abs_sub_comm n m] at hh
  have hprod := mul_le_mul_of_nonneg_left hmn hvn0
  linarith

/-- A polynomially decaying exponent comparison suffices for all near-one bias terms. -/
theorem endpointProfile_exponent_tail {N : ℕ} (hN : 0 < N) {s x : ℝ}
    (hs : 1/2 ≤ s) (hs1 : s ≤ 1) (hx : 0 < x) (hx1 : x ≤ 1)
    (hy : 1 ≤ (N:ℝ)^2*x) :
    |endpointProfile N 6 s x - endpointProfile N 6 1 x| ≤
      ((1+20*Real.exp (Real.log 12+1))*Real.exp (Real.log 12+1)) *
        (1-s)*((N:ℝ)^2*x)^(-(9/2:ℝ)) := by
  let y := (N:ℝ)^2*x
  let C := Real.exp (Real.log 12+1)
  have hC : 0 < C := Real.exp_pos _
  have hR : 0 < (N:ℝ)^2 := by positivity
  have hy0 : 0 < y := by dsimp [y]; positivity
  have hyR : y ≤ (N:ℝ)^2 := by dsimp [y]; nlinarith
  have hlow := endpointScaledPrimitive_total_lower (d := 6) hN (by norm_num) (by linarith : 0<s) hs1
  have hlow1 := endpointScaledPrimitive_total_lower (d := 6) hN (by norm_num) (s := 1) (by norm_num) le_rfl
  have hm : 0 < endpointScaledPrimitive N 6 s ((N:ℝ)^2) := (Real.exp_pos _).trans_le hlow
  have hn : 0 < endpointScaledPrimitive N 6 1 ((N:ℝ)^2) := (Real.exp_pos _).trans_le hlow1
  have hv : 0 ≤ endpointScaledTail N 6 1 y := by
    apply intervalIntegral.integral_nonneg hyR
    intro z hz
    exact mul_nonneg (Real.rpow_nonneg (hy0.le.trans hz.1) _) (endpointKernel_nonneg _ _ _)
  have hdif := endpointScaledTail_difference hN hs hs1 hy hyR
  have htot := endpointScaledPrimitive_difference (d := 6) hN (by norm_num) hs hs1 hR.le le_rfl
  have h := normalized_difference_refined hm hn hv hdif htot
  have hr1 := endpointScaledTail_ratio (d := 6) hN (by norm_num) (s := 1) (by norm_num) hy0.le
  have hrs := endpointScaledTail_ratio (d := 6) hN (by norm_num) (s := s) (by linarith) hy0.le
  have hydiv : y/(N:ℝ)^2=x := by dsimp [y]; field_simp
  rw [hydiv] at hr1 hrs
  rw [hr1, hrs, show (1-endpointProfile N 6 s x)-(1-endpointProfile N 6 1 x) =
    -(endpointProfile N 6 s x-endpointProfile N 6 1 x) by ring, abs_neg] at h
  have htail := endpointProfile_tail (d := 6) hN (by norm_num) (by norm_num)
    (s := 1) (by norm_num) le_rfl hx hx1
  have htail0 : 1-endpointProfile N 6 1 x ≤ C*y^(-(5:ℝ)) := by
    convert htail using 1
    norm_num [C, y]
  have hpower : y^(-(5:ℝ)) ≤ y^(-(9/2:ℝ)) :=
    Real.rpow_le_rpow_of_exponent_le hy (by norm_num)
  have htail' : 1-endpointProfile N 6 1 x ≤ C*y^(-(9/2:ℝ)) := by
    apply htail0.trans
    exact mul_le_mul_of_nonneg_left hpower hC.le
  have hnum : (1-s)*y^(-(9/2:ℝ))+(1-endpointProfile N 6 1 x)*(20*(1-s)) ≤
      (1+20*C)*(1-s)*y^(-(9/2:ℝ)) := by
    have hh := mul_le_mul_of_nonneg_right htail' (by linarith : 0 ≤ 20*(1-s))
    nlinarith only [hh]
  apply h.trans
  apply le_trans (div_le_div_of_nonneg_right hnum hm.le)
  have hnnum : 0 ≤ (1+20*C)*(1-s)*y^(-(9/2:ℝ)) := by
    exact mul_nonneg (mul_nonneg (by positivity) (by linarith)) (Real.rpow_nonneg hy0.le _)
  have hdiv := div_le_div_of_nonneg_left hnnum (Real.exp_pos _) hlow
  apply hdiv.trans_eq
  dsimp [C, y]
  rw [Real.exp_neg]
  field_simp

end Renyi
