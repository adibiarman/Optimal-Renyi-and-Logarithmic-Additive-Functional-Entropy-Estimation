import Renyi.CoupledDeterministicUpper

/-! Direct absolute envelopes for the actual polynomial on its approximation interval. -/
noncomputable section
namespace Renyi

/-- Every actual coupled polynomial with unit scalar weights has range [0,3 p^alpha]. -/
theorem coupledQPolynomial_range {ℓ N m : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    (hdegree : 4*(ℓ-1)≤m) {γ a b p fL f A B ω : ℝ}
    (hγ : 0<γ) (hγ1 : γ<1) (ha : 0<a) (hap : a≤p) (hpb : p≤b)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hA : 0≤A) (hA1 : A≤1) (hB : 0≤B) (hB1 : B≤1) (hω : 0≤ω) (hω1 : ω<1) :
    0≤(coupledQPolynomial ℓ N m γ a b fL f A B ω).eval p ∧
      (coupledQPolynomial ℓ N m γ a b fL f A B ω).eval p≤3*p^((m:ℝ)+γ) := by
  have hp := ha.trans_le hap
  have hb := hp.trans_le hpb
  have hx : 0≤a/p := div_nonneg ha.le hp.le
  have hx1 : a/p≤1 := (div_le_one hp).mpr hap
  have hy : 0≤p/b := div_nonneg hp.le hb.le
  have hy1 : p/b≤1 := (div_le_one hb).mpr hpb
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hy hy1
  have hl0 := mul_nonneg (mul_nonneg hA hu.1) (sub_nonneg.mpr hH.2)
  have hh0 := mul_nonneg hB hv.1
  have hj0 := mul_nonneg (mul_nonneg hω (sub_nonneg.mpr hB1)) hJ.1
  have hlu := mul_le_of_le_one_right hA hu.2
  have hlcut := mul_le_of_le_one_right (mul_nonneg hA hu.1) (by linarith only [hH.1] : 1-endpointProfile N 6 1 (p/b)≤1)
  have hhu := mul_le_of_le_one_right hB hv.2
  have hju := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hB1)) hJ.2
  have hjw := mul_le_of_le_one_right hω (by linarith only [hB] : 1-B≤1)
  rw [coupledQPolynomial_eval hℓ hN hdegree hγ hγ1 ha hap hpb]
  unfold coupledQExpression
  constructor
  · exact mul_nonneg (Real.rpow_nonneg hp.le _) (by linarith only [hl0,hh0,hj0])
  · have hsum : A*lowProfile ℓ γ fL (a/p)*(1-endpointProfile N 6 1 (p/b))+
        B*highProfile N (1-γ) f ω (p/b)+ω*(1-B)*endpointProfile N 6 (1-γ) (p/b)≤3 := by
      linarith only [hlu,hlcut,hhu,hju,hjw,hA1,hB1,hω1]
    have hm := mul_le_mul_of_nonneg_left hsum (Real.rpow_nonneg hp.le ((m:ℝ)+γ))
    nlinarith only [hm]

/-- Absolute envelope used for actual false-heavy pilot error control. -/
theorem coupledQPolynomial_absolute_envelope {ℓ N m : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    (hdegree : 4*(ℓ-1)≤m) {γ a b p fL f A B ω : ℝ}
    (hγ : 0<γ) (hγ1 : γ<1) (ha : 0<a) (hap : a≤p) (hpb : p≤b)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hA : 0≤A) (hA1 : A≤1) (hB : 0≤B) (hB1 : B≤1) (hω : 0≤ω) (hω1 : ω<1) :
    |(coupledQPolynomial ℓ N m γ a b fL f A B ω).eval p|≤3*p^((m:ℝ)+γ) := by
  have h := coupledQPolynomial_range hℓ hN hdegree hγ hγ1 ha hap hpb hfL hfL1 hf hf1 hA hA1 hB hB1 hω hω1
  rw [abs_of_nonneg h.1]
  exact h.2

end Renyi
