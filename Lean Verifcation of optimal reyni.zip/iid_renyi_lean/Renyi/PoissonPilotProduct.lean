import Renyi.PoissonPilotModel

/-! Exact separation of the main and pilot histogram vectors. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def splitPilotHistogram {k:ℕ} (h:PilotHistogram k) : (Fin k→ℕ)×(Fin k→ℕ) :=
  (fun i => pilotMainCount i h,fun i => pilotSelectionCount i h)

def joinPilotHistogram {k:ℕ} (x:(Fin k→ℕ)×(Fin k→ℕ)) : PilotHistogram k :=
  fun ib => if ib.2 then x.2 ib.1 else x.1 ib.1

@[simp] theorem split_joinPilotHistogram {k:ℕ} (x:(Fin k→ℕ)×(Fin k→ℕ)) :
    splitPilotHistogram (joinPilotHistogram x)=x := by
  rcases x with ⟨x,y⟩
  rfl

@[simp] theorem join_splitPilotHistogram {k:ℕ} (h:PilotHistogram k) :
    joinPilotHistogram (splitPilotHistogram h)=h := by
  funext ib
  rcases ib with ⟨i,b⟩
  cases b <;> rfl

theorem pilotHistogram_split_atom {k:ℕ} (n cp:ℝ≥0) (p:Simplex k)
    (x:(Fin k→ℕ)×(Fin k→ℕ)) :
    (pilotHistogramPMF n cp p).map splitPilotHistogram x=
      finitePoissonPMF (fun i => n*simplexNN p i) x.1 *
        finitePoissonPMF (fun i => cp*(n*simplexNN p i)) x.2 := by
  rw [PMF.map_apply,tsum_eq_single (joinPilotHistogram x)]
  · simp only [split_joinPilotHistogram,if_true,pilotHistogramPMF,finitePoissonPMF_apply,
      Fintype.prod_prod_type,Fintype.prod_bool,pilotHistogramRate,joinPilotHistogram,
      Bool.false_eq_true,if_false,if_true]
    rw [Finset.prod_mul_distrib,mul_comm]
  · intro h hh
    have hne:x≠splitPilotHistogram h := by
      intro heq
      have heq' := congrArg joinPilotHistogram heq
      exact hh (by simpa only [join_splitPilotHistogram] using heq'.symm)
    simp only [hne,if_false]

/-- The two entire histograms have the actual product law. -/
theorem pilotHistogram_split_law {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) :
    MeasurePreserving (splitPilotHistogram (k:=k)) (pilotHistogramPMF n cp p).toMeasure
      ((finitePoissonPMF (fun i => n*simplexNN p i)).toMeasure.prod
        (finitePoissonPMF (fun i => cp*(n*simplexNN p i))).toMeasure) := by
  refine ⟨measurable_of_countable _,?_⟩
  rw [PMF.toMeasure_map _ _ (measurable_of_countable _)]
  apply Measure.ext_of_singleton
  intro x
  rw [PMF.toMeasure_apply_singleton _ _ (MeasurableSet.singleton _)]
  rw [pilotHistogram_split_atom]
  have hs:({x}:Set ((Fin k→ℕ)×(Fin k→ℕ)))={x.1}×ˢ{x.2} := by
    ext y
    simp only [Set.mem_singleton_iff,Set.mem_prod]
    exact Prod.ext_iff
  rw [hs,Measure.prod_prod]
  rw [PMF.toMeasure_apply_singleton _ _ (MeasurableSet.singleton _),
    PMF.toMeasure_apply_singleton _ _ (MeasurableSet.singleton _)]

end Renyi
