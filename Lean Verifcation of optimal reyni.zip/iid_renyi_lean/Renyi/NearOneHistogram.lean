import Renyi.NearOneActualVariance
import Renyi.NearOneMeanCalibration
import Renyi.PoissonPilotLaws
import Renyi.NonintegerIID

/-! The actual calibrated near-one statistic on independent pilot histograms. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Polynomial
namespace Renyi

def nearOneHistogramStatistic (k N:ℕ)
    (alpha eps Ch D cb lambda CL cL c M cw f cu u0:ℝ) (cp:ℝ≥0) (B repair:ℝ) : PilotHistogram k→ℝ :=
  actualNearOneCountStatistic pilotMainCount pilotSelectionCount N
    alpha eps Ch D cb lambda CL cL c M cw f cu u0 cp B repair

/-- The finite-histogram statistic has its genuine polynomial/Gamma mixture
mean; every Poisson marginal and independence hypothesis is proved. -/
theorem nearOneHistogramStatistic_mean {k N:ℕ}
    {alpha eps Ch D cb lambda CL cL c M cw f cu u0 B repair:ℝ}
    (hk:0<k) (ha:1<alpha) (ha1:alpha≤3/2) (hD:0<D)
    (hcb:0<cb) (hCL:1≤CL) (hcL:0<cL) (hN:0<N)
    (cp:ℝ≥0) (p:Simplex k) :
    (∫h,nearOneHistogramStatistic k N alpha eps Ch D cb lambda CL cL c M cw f cu u0 cp B repair h
      ∂(pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure)=
      actualNearOneExpectedMean N alpha eps Ch D cb lambda CL cL c M cw f cu u0 cp B repair p := by
  let n:=upperSample k alpha eps D
  let b:=upperB k alpha eps D cb CL cL
  let t:=b/(N:ℝ)^2
  let P:=actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
    (upperRescaling k alpha eps cu u0)
  let lam:Fin k→ℝ≥0:=fun i=>Real.toNNReal (n*p.mass i)
  let pilotLam:Fin k→ℝ≥0:=fun i=>Real.toNNReal ((cp:ℝ)*n*p.mass i)
  have hg:0<fractionalPart alpha := by rw [(near_one_order ha ha1).2]; linarith only [ha]
  have hg1:fractionalPart alpha<1 := by rw [(near_one_order ha ha1).2]; linarith only [ha1]
  have hn:0<n:=upperSample_pos hk ha hg hg1 hD
  have hncoe:(nonintegerPoissonMean k alpha eps D:ℝ)=n:=nonintegerPoissonMean_coe hk ha hg hg1 hD
  have hb:0<b:=upperB_pos hk ha hg hg1 hD hcb hCL hcL
  have hNr:(0:ℝ)<N:=by exact_mod_cast hN
  have ht:0<t:=div_pos hb (sq_pos_of_pos hNr)
  have hmain (i):MeasurePreserving (pilotMainCount i)
      (pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure (poissonMeasure (lam i)) := by
    have hh:=pilotMainCount_law_real (nonintegerPoissonMean k alpha eps D) cp p i
    rw [hncoe] at hh
    exact hh
  have hpilot (i):MeasurePreserving (pilotSelectionCount i)
      (pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure (poissonMeasure (pilotLam i)) := by
    have hh:=pilotSelectionCount_law_real (nonintegerPoissonMean k alpha eps D) cp p i
    rw [hncoe] at hh
    exact hh
  have hlam (i):(lam i:ℝ)=n*p.mass i:=Real.coe_toNNReal _ (mul_nonneg hn.le (p.nonneg i))
  have hd:P.natDegree≤20*N:=actualNearOnePolynomial_natDegree_le hN alpha eps Ch D cb lambda CL cL c M cw f (upperRescaling k alpha eps cu u0)
  have hh:=near_one_hybrid_polynomial_mean pilotSelectionCount pilotMainCount pilotLam lam hpilot hmain
    (pilotSelectionCount_independent_main (nonintegerPoissonMean k alpha eps D) cp p)
    (pilotMainCount_independent (nonintegerPoissonMean k alpha eps D) cp p) hn ht
    p.mass p.normalized hlam P (20*N) hd (by omega)
    (beta:=alpha-1) (omega:=upperOmega k alpha eps Ch cw) (T:=(cp:ℝ)*B*alpha)
    (q:=P.coeff 1) (repair:=repair)
  simpa only [nearOneHistogramStatistic,actualNearOneCountStatistic,polynomialNearOneCountStatistic,
    actualNearOneExpectedMean,show 1+(alpha-1)=alpha by ring,n,b,t,P,lam,pilotLam] using hh.2


/-- A coefficient constant chosen before the logarithmic degree slope, for
an explicit fixed choice of every auxiliary near-one parameter. -/
theorem nearOneHistogramStatistic_variance_uniform
    {eps cu CL B:ℝ} (heps:0<eps) (hcu:0≤cu) (hCL:1≤CL) (hB:0≤B)
    (cp:ℝ≥0) (hcp:80≤(cp:ℝ)) (hcpExp:2*Real.exp 1≤(cp:ℝ)) :
    ∃K:ℝ,0<K ∧ ∀cL:ℝ,0<cL → ∀(k:ℕ) (alpha D:ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0<D → ∀p:Simplex k,
      let N:=upperDegree alpha CL cL (rootMultiplier k alpha eps)
      let n:=upperSample k alpha eps D
      let b:=upperB k alpha eps D 1 CL cL
      let t:=b/(N:ℝ)^2
      let mu:=(pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure
      let F:=nearOneHistogramStatistic k N alpha eps 0 D 1 1 CL cL 1 0 (1/2) (1/2) cu 1 cp B 0
      MemLp F 2 mu ∧ variance F mu≤
        nearOneHybridVarianceBudget (simplexPoissonMeans n p) n t b (alpha-1)
          (K*Real.exp (K*(N:ℝ))) eps K ((cp:ℝ)*B*alpha) 20 (20*N) := by
  obtain ⟨K,hK,hvariance⟩:=actual_near_one_variance_degree_uniform_experiments
    (eps:=eps) (cb:=1) (lambda:=1) (CL:=CL) (cmin:=1) (q:=1) (Q:=1)
    (M:=0) (cw:=1/2) (f:=1/2) (cu:=cu) (u0:=1) (cp:=(cp:ℝ)) (Bpilot:=B)
    heps (by norm_num : (0:ℝ)<1) (by norm_num : (0:ℝ)<1) hCL (by simpa only [one_pow,one_mul] using hCL)
    (by norm_num : (0:ℝ)<1) (by norm_num : (0:ℝ)<1) (by norm_num : (0:ℝ)<1)
    (by norm_num : (0:ℝ)≤0) (by norm_num : (0:ℝ)<1/2) (by norm_num : (1/2:ℝ)<1)
    (by norm_num : (0:ℝ)≤1/2) (by norm_num : (1/2:ℝ)≤1) hcu (by norm_num : (0:ℝ)<1)
    (show 0<(cp:ℝ) by linarith only [hcp]) (by norm_num at *; exact hcp) hcpExp hB
  refine ⟨K,hK,?_⟩
  intro cL hcL k alpha D hk ha ha1 hD p
  dsimp only
  let N:=upperDegree alpha CL cL (rootMultiplier k alpha eps)
  have hg:0<fractionalPart alpha := by rw [(near_one_order ha ha1).2]; linarith only [ha]
  have hg1:fractionalPart alpha<1 := by rw [(near_one_order ha ha1).2]; linarith only [ha1]
  have hncoe:=nonintegerPoissonMean_coe (eps:=eps) hk ha hg hg1 hD
  have hh:=hvariance (pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure cL hcL k N alpha 0 D 1 0 hk ha ha1 (by norm_num) hD
    (by norm_num) (by norm_num) (by simp only [N,one_mul,le_refl])
    (by simp only [N,one_mul,le_refl]) p pilotMainCount pilotSelectionCount
  dsimp only at hh
  have hCounts (i):MeasurePreserving (pilotMainCount i)
      (pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure
      (poissonMeasure (simplexPoissonMeans (upperSample k alpha eps D) p i)) := by
    have hh:=pilotMainCount_law_real (nonintegerPoissonMean k alpha eps D) cp p i
    rw [hncoe] at hh
    exact hh
  have hPilot (i):MeasurePreserving (pilotSelectionCount i)
      (pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure
      (poissonMeasure ⟨(cp:ℝ)*(simplexPoissonMeans (upperSample k alpha eps D) p i:ℝ),
        mul_nonneg (show 0≤(cp:ℝ) from cp.coe_nonneg) (simplexPoissonMeans _ p i).coe_nonneg⟩) := by
    have hh:=pilotSelectionCount_law_amplified (nonintegerPoissonMean k alpha eps D) cp p i
    rw [hncoe] at hh
    exact hh
  have hfinal:=hh hCounts hPilot
    (pilotSelectionCount_independent_main (nonintegerPoissonMean k alpha eps D) cp p)
    (pilotHistogram_pairs_independent (nonintegerPoissonMean k alpha eps D) cp p)
  simpa only [nearOneHistogramStatistic,show 2*(1/2:ℝ)*eps=eps by ring,
    show (20:ℝ)*1/1=20 by norm_num] using hfinal

end Renyi
