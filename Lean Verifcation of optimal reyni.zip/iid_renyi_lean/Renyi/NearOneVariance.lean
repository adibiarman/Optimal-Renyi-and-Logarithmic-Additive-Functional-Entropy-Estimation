import Renyi.NearOneEstimator
import Renyi.CommonAnchor
import Renyi.PoissonPairMoments
import Renyi.OrderOneNoise

/-! Variance of the actual near-one hybrid, including its random pilot and
the common affine replacement. -/
set_option maxHeartbeats 600000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def nearOneGammaCountResidual (beta xi omega : ℝ) (j : ℕ) : ℝ :=
  omega * analyticCount (1 + beta) j - xi ^ beta * (j : ℝ)

theorem nearOneGammaCountResidual_memLp (lam : ℝ≥0) (beta xi omega : ℝ) :
    MemLp (nearOneGammaCountResidual beta xi omega) 2 (poissonMeasure lam) :=
  ((analyticCount_memLp lam (1 + beta)).const_mul omega).sub
    ((poisson_nat_memLp lam).const_mul (xi ^ beta))

/-- The actual high-intensity Gamma residual has a beta-squared variance,
including the damping error in omega. -/
theorem near_one_gamma_count_variance_high {beta xi omega Cw : ℝ}
    (hbeta : 0 < beta) (hbeta1 : beta ≤ 1 / 2) (hxi : 0 < xi)
    (hw0 : 0 ≤ omega) (hw1 : omega ≤ 1) (hCw : 0 ≤ Cw)
    (hwdiff : |omega - 1| ≤ Cw * beta) (lam : ℝ≥0) (hlam : 1 ≤ (lam : ℝ)) :
    variance (nearOneGammaCountResidual beta xi omega) (poissonMeasure lam) ≤
      beta ^ 2 * (2 * orderOneNoiseConstant * (lam : ℝ) *
        ((lam : ℝ) ^ (2 * beta) + xi ^ (2 * beta)) *
        (1 + (Real.log ((lam : ℝ) / xi)) ^ 2) +
        2 * Cw ^ 2 * xi ^ (2 * beta) * (lam : ℝ)) := by
  let V : ℕ → ℝ := fun j => (analyticCount (1 + beta) j - xi ^ beta * (j : ℝ)) / beta
  have hV : MemLp V 2 (poissonMeasure lam) := by
    have hnum := (analyticCount_memLp lam (1 + beta)).sub ((poisson_nat_memLp lam).const_mul (xi ^ beta))
    simpa only [V, div_eq_mul_inv] using hnum.mul_const beta⁻¹
  have hdecomp : nearOneGammaCountResidual beta xi omega = fun j =>
      (omega * beta) * V j + ((omega - 1) * xi ^ beta) * (j : ℝ) := by
    funext j
    dsimp [nearOneGammaCountResidual, V]
    field_simp
    ring
  have htri := variance_fun_add_le_two (hV.const_mul (omega * beta))
    ((poisson_nat_memLp lam).const_mul ((omega - 1) * xi ^ beta))
  rw [variance_mul, variance_mul, poisson_nat_variance] at htri
  have hnoise := order_one_divided_variance hbeta hbeta1 hxi lam hlam
  change variance V (poissonMeasure lam) ≤ _ at hnoise
  have hwSq : omega ^ 2 ≤ 1 := by nlinarith
  have hleft := mul_le_mul_of_nonneg_right hwSq (sq_nonneg beta)
  have hleft' := mul_le_mul_of_nonneg_right hleft (variance_nonneg V (poissonMeasure lam))
  have hnoise' := mul_le_mul_of_nonneg_left hnoise (sq_nonneg beta)
  have hdiff := mul_le_mul hwdiff hwdiff (abs_nonneg _) (mul_nonneg hCw hbeta.le)
  simp only [← pow_two, sq_abs, mul_pow] at hdiff
  have hxpow : (xi ^ beta) ^ (2 : ℕ) = xi ^ (2 * beta) := by
    rw [mul_comm (2 : ℝ), Real.rpow_mul hxi.le, Real.rpow_two]
  have hright := mul_le_mul_of_nonneg_right hdiff
    (mul_nonneg (sq_nonneg (xi ^ beta)) lam.coe_nonneg)
  rw [hdecomp]
  rw [hxpow] at hright
  simp only [mul_pow, hxpow] at htri
  nlinarith only [htri, hleft', hnoise', hright]

/-- The bounded-intensity Gamma residual also retains beta squared, including
the actual signed value at zero. -/
theorem near_one_gamma_count_variance_low {beta xi omega Cw : ℝ}
    (hbeta : 0 < beta) (hbeta1 : beta ≤ 1 / 2) (hxi : 0 < xi) (hxi1 : xi ≤ 1)
    (hw0 : 0 ≤ omega) (hw1 : omega ≤ 1) (hCw : 0 ≤ Cw)
    (hwdiff : |omega - 1| ≤ Cw * beta) (lam : ℝ≥0) (hlam : (lam : ℝ) ≤ 1) :
    variance (nearOneGammaCountResidual beta xi omega) (poissonMeasure lam) ≤
      beta ^ 2 * ((6 : ℝ) ^ (6 : ℕ) * Real.exp (Real.exp 1 - 1) *
        gammaResidualPilotConstant Cw ^ 2 * (1 + |Real.log xi|) ^ 2) := by
  let K := gammaResidualPilotConstant Cw ^ 2 * beta ^ 2 * (1 + |Real.log xi|) ^ 2
  have hK : 0 ≤ K := by dsimp [K]; positivity
  have hR := nearOneGammaCountResidual_memLp lam beta xi omega
  have hpoint (j : ℕ) : nearOneGammaCountResidual beta xi omega j ^ 2 ≤
      K * ((j : ℝ) + 1) ^ (6 : ℕ) := by
    have h := gamma_residual_pilot_pointwise hbeta hbeta1 hxi hxi1 hw0 hw1 hCw hwdiff j
    have hD : 0 ≤ gammaResidualPilotConstant Cw := by
      dsimp [gammaResidualPilotConstant]
      linarith [smallOrderRatioConstant_nonneg]
    have hs := mul_le_mul h h (abs_nonneg _)
      (by positivity : 0 ≤ gammaResidualPilotConstant Cw * beta * (1 + |Real.log xi|) * ((j : ℝ) + 1) ^ (3 : ℕ))
    simp only [← pow_two, sq_abs] at hs
    dsimp [K, nearOneGammaCountResidual]
    nlinarith only [hs]
  have hmono := integral_mono hR.integrable_sq
    (((poisson_count_power_memLp lam 6).integrable one_le_two).const_mul K) hpoint
  rw [integral_const_mul] at hmono
  have hm := mul_le_mul_of_nonneg_left (poisson_shifted_sixth_moment_bound lam) hK
  have he : Real.exp ((lam : ℝ) * (Real.exp 1 - 1)) ≤ Real.exp (Real.exp 1 - 1) := by
    apply Real.exp_le_exp.mpr
    have he0 : 0 ≤ Real.exp 1 - 1 := by linarith [Real.add_one_le_exp (1 : ℝ)]
    exact mul_le_of_le_one_left he0 hlam
  have he' := mul_le_mul_of_nonneg_left he (by positivity : 0 ≤ K * (6 : ℝ) ^ (6 : ℕ))
  have hv := variance_le_expectation_sq hR.aestronglyMeasurable
  change variance (nearOneGammaCountResidual beta xi omega) (poissonMeasure lam) ≤
    ∫ j, nearOneGammaCountResidual beta xi omega j ^ 2 ∂poissonMeasure lam at hv
  dsimp [K] at *
  nlinarith only [hv, hmono, hm, he']

def nearOneGammaVarianceEnvelope (beta xi Cw : ℝ) (lam : ℝ≥0) : ℝ :=
  if 1 ≤ (lam : ℝ) then
    2 * orderOneNoiseConstant * (lam : ℝ) *
      ((lam : ℝ) ^ (2 * beta) + xi ^ (2 * beta)) *
      (1 + (Real.log ((lam : ℝ) / xi)) ^ 2) +
      2 * Cw ^ 2 * xi ^ (2 * beta) * (lam : ℝ)
  else (6 : ℝ) ^ (6 : ℕ) * Real.exp (Real.exp 1 - 1) *
    gammaResidualPilotConstant Cw ^ 2 * (1 + |Real.log xi|) ^ 2

theorem near_one_gamma_count_variance {beta xi omega Cw : ℝ}
    (hbeta : 0 < beta) (hbeta1 : beta ≤ 1 / 2) (hxi : 0 < xi) (hxi1 : xi ≤ 1)
    (hw0 : 0 ≤ omega) (hw1 : omega ≤ 1) (hCw : 0 ≤ Cw)
    (hwdiff : |omega - 1| ≤ Cw * beta) (lam : ℝ≥0) :
    variance (nearOneGammaCountResidual beta xi omega) (poissonMeasure lam) ≤
      beta ^ 2 * nearOneGammaVarianceEnvelope beta xi Cw lam := by
  by_cases h : 1 ≤ (lam : ℝ)
  · simpa only [nearOneGammaVarianceEnvelope, if_pos h] using
      near_one_gamma_count_variance_high hbeta hbeta1 hxi hw0 hw1 hCw hwdiff lam h
  · simpa only [nearOneGammaVarianceEnvelope, if_neg h] using
      near_one_gamma_count_variance_low hbeta hbeta1 hxi hxi1 hw0 hw1 hCw hwdiff lam (le_of_not_ge h)

def nearOneGammaResidual (n t beta omega : ℝ) (j : ℕ) : ℝ :=
  nearOneGammaCountResidual beta (n * t) omega j / n ^ (1 + beta)

theorem nearOneGammaResidual_memLp (lam : ℝ≥0) (n t beta omega : ℝ) :
    MemLp (nearOneGammaResidual n t beta omega) 2 (poissonMeasure lam) := by
  simpa only [nearOneGammaResidual, div_eq_mul_inv] using
    (nearOneGammaCountResidual_memLp lam beta (n * t) omega).mul_const ((n ^ (1 + beta))⁻¹)

theorem nearOneGammaResidual_probability_identity {n t beta omega : ℝ}
    (hn : 0 < n) (ht : 0 < t) (j : ℕ) :
    nearOneGammaResidual n t beta omega j =
      omega * analyticCount (1 + beta) j / n ^ (1 + beta) -
        t ^ beta * (j : ℝ) / n :=
  (gamma_residual_probability_identity hn ht j).symm

theorem near_one_gamma_residual_variance {n t beta omega Cw : ℝ}
    (hn : 0 < n) (ht : 0 < t) (hnt : n * t ≤ 1)
    (hbeta : 0 < beta) (hbeta1 : beta ≤ 1 / 2)
    (hw0 : 0 ≤ omega) (hw1 : omega ≤ 1) (hCw : 0 ≤ Cw)
    (hwdiff : |omega - 1| ≤ Cw * beta) (lam : ℝ≥0) :
    variance (nearOneGammaResidual n t beta omega) (poissonMeasure lam) ≤
      beta ^ 2 / n ^ (2 * (1 + beta)) * nearOneGammaVarianceEnvelope beta (n * t) Cw lam := by
  have heq : nearOneGammaResidual n t beta omega = fun j =>
      (1 / n ^ (1 + beta)) * nearOneGammaCountResidual beta (n * t) omega j := by
    funext j
    dsimp [nearOneGammaResidual]
    ring
  rw [heq, variance_mul]
  have h := mul_le_mul_of_nonneg_left
    (near_one_gamma_count_variance hbeta hbeta1 (mul_pos hn ht) hnt hw0 hw1 hCw hwdiff lam)
    (sq_nonneg (1 / n ^ (1 + beta)))
  have hp : n ^ (2 * (1 + beta)) = (n ^ (1 + beta)) ^ (2 : ℕ) := by
    rw [mul_comm (2 : ℝ), Real.rpow_mul hn.le, Real.rpow_two]
  rw [hp]
  convert h using 1
  ring

def nearOneSelectedLightResidual (n : ℝ) (d : ℕ) (c : ℕ → ℝ) (T : ℝ)
    (z : ℕ × ℕ) : ℝ :=
  if (z.1 : ℝ) ≤ T then factorialStatistic d (fun j => c j / n ^ j) z.2 else 0

def nearOneSelectedGammaResidual (n t beta omega T : ℝ) (z : ℕ × ℕ) : ℝ :=
  if (z.1 : ℝ) ≤ T then nearOneGammaResidual n t beta omega z.2 else 0

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

theorem near_one_selected_light_variance {n b a beta A cp T M : ℝ}
    (hn : 0 < n) (hb : 0 < b) (hbeta : 0 ≤ beta) (hA : 0 ≤ A)
    (hcp0 : 0 < cp) (hT : 0 ≤ T) (hM : 0 ≤ M) (hcp : 4 * M ≤ cp)
    (Y N : Ω → ℕ) (lam : ℝ≥0)
    (hN : MeasurePreserving N μ (poissonMeasure lam))
    (hY : MeasurePreserving Y μ
      (poissonMeasure ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩))
    (hind : IndepFun Y N μ) (d : ℕ) (hd : (d : ℝ) ≤ M * (n * b)) (c : ℕ → ℝ)
    (hcoef : ∀ j : ℕ, j ≤ d → |c j| ≤ beta * A * b ^ (a - j)) :
    MemLp (fun w => nearOneSelectedLightResidual n d c T (Y w, N w)) 2 μ ∧
      variance (fun w => nearOneSelectedLightResidual n d c T (Y w, N w)) μ ≤
        ((d : ℝ) + 1) ^ (2 : ℕ) * (beta * A) ^ (2 : ℕ) * Real.exp (T + M * d) * b ^ (2 * a) := by
  let mu : ℝ≥0 := ⟨cp * lam, by positivity⟩
  have h := near_one_light_joint_second hn hb hbeta hA hcp0 hT hM hcp lam d hd c hcoef
  have hfun (z : ℕ × ℕ) : nearOneSelectedLightResidual n d c T z ^ 2 *
      (poissonPMFReal lam z.2 * poissonPMFReal mu z.1) =
      (if (z.1 : ℝ) ≤ T then factorialStatistic d (fun j => c j / n ^ j) z.2 ^ 2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1) := by
    dsimp [nearOneSelectedLightResidual]
    split_ifs <;> simp
  have hs : Summable (fun z => nearOneSelectedLightResidual n d c T z ^ 2 *
      (poissonPMFReal lam z.2 * poissonPMFReal mu z.1)) := h.1.congr (fun z => (hfun z).symm)
  have htrans := poisson_pair_variance_of_second_sum (fun w => (Y w, N w)) mu lam
    (poisson_pair_measurePreserving Y N mu lam hY hN hind) (nearOneSelectedLightResidual n d c T) hs
  refine ⟨htrans.1, htrans.2.trans ?_⟩
  simpa only [hfun] using h.2

theorem near_one_selected_gamma_variance {n t beta omega Cw cp T : ℝ}
    (hn : 0 < n) (ht : 0 < t) (hnt : n * t ≤ 1)
    (hbeta : 0 < beta) (hbeta1 : beta ≤ 1 / 2)
    (hw0 : 0 ≤ omega) (hw1 : omega ≤ 1) (hCw : 0 ≤ Cw)
    (hwdiff : |omega - 1| ≤ Cw * beta)
    (hcp0 : 0 < cp) (hcp : 2 * Real.exp 1 ≤ cp)
    (Y N : Ω → ℕ) (lam : ℝ≥0)
    (hN : MeasurePreserving N μ (poissonMeasure lam))
    (hY : MeasurePreserving Y μ
      (poissonMeasure ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩))
    (hind : IndepFun Y N μ) :
    MemLp (fun w => nearOneSelectedGammaResidual n t beta omega T (Y w, N w)) 2 μ ∧
      variance (fun w => nearOneSelectedGammaResidual n t beta omega T (Y w, N w)) μ ≤
        (6 : ℝ) ^ (6 : ℕ) * Real.exp T * gammaResidualPilotConstant Cw ^ 2 * beta ^ 2 /
          n ^ (2 * (1 + beta)) * (1 + |Real.log (n * t)|) ^ 2 := by
  let mu : ℝ≥0 := ⟨cp * lam, by positivity⟩
  have h := gamma_residual_light_probability_second hn ht hnt hbeta hbeta1 hw0 hw1 hCw
    hwdiff hcp0 hcp lam (T := T)
  dsimp only at h
  have hfun (z : ℕ × ℕ) : nearOneSelectedGammaResidual n t beta omega T z ^ 2 *
      (poissonPMFReal lam z.2 * poissonPMFReal mu z.1) =
      (if (z.1 : ℝ) ≤ T then
        (omega * analyticCount (1 + beta) z.2 / n ^ (1 + beta) -
          t ^ beta * (z.2 : ℝ) / n) ^ 2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1) := by
    dsimp [nearOneSelectedGammaResidual]
    split_ifs
    · rw [nearOneGammaResidual_probability_identity hn ht]
    · simp
  have hs : Summable (fun z => nearOneSelectedGammaResidual n t beta omega T z ^ 2 *
      (poissonPMFReal lam z.2 * poissonPMFReal mu z.1)) := h.1.congr (fun z => (hfun z).symm)
  have htrans := poisson_pair_variance_of_second_sum (fun w => (Y w, N w)) mu lam
    (poisson_pair_measurePreserving Y N mu lam hY hN hind) (nearOneSelectedGammaResidual n t beta omega T) hs
  refine ⟨htrans.1, htrans.2.trans ?_⟩
  simpa only [hfun] using h.2

def nearOneHybridResidual (n t beta omega T : ℝ) (d : ℕ) (c : ℕ → ℝ)
    (z : ℕ × ℕ) : ℝ :=
  nearOneGammaResidual n t beta omega z.2 +
    (nearOneSelectedLightResidual n d c T z - nearOneSelectedGammaResidual n t beta omega T z)

theorem nearOneHybridResidual_branch (n t beta omega T : ℝ) (d : ℕ) (c : ℕ → ℝ)
    (z : ℕ × ℕ) :
    nearOneHybridResidual n t beta omega T d c z =
      if (z.1 : ℝ) ≤ T then factorialStatistic d (fun j => c j / n ^ j) z.2
      else nearOneGammaResidual n t beta omega z.2 := by
  dsimp [nearOneHybridResidual, nearOneSelectedLightResidual, nearOneSelectedGammaResidual]
  split_ifs <;> ring

def nearOneHybridStatistic {ι : Type*} [Fintype ι]
    (N Y : ι → Ω → ℕ) (n t beta omega T q repair : ℝ) (d : ℕ) (c : ℕ → ℝ) : Ω → ℝ :=
  fun w => repair + t ^ beta +
    (∑ i, nearOneHybridResidual n t beta omega T d c (Y i w, N i w)) +
      poissonAffineAnchor N n (q - t ^ beta) w

/-- Complete variance assembly for the actual hybrid: the independent main
counts, the random pilot selectors, the signed Gamma branch, and the affine
replacement are all included. The only coefficient inputs are the displayed
deterministic bounds on the actual light residual. -/
theorem near_one_hybrid_variance {ι : Type*} [Fintype ι]
    {n t b beta A omega Cw Cq cp T M q repair : ℝ}
    (hn : 0 < n) (ht : 0 < t) (hb : 0 < b) (hnt : n * t ≤ 1)
    (hbeta : 0 < beta) (hbeta1 : beta ≤ 1 / 2)
    (hA : 0 ≤ A) (hw0 : 0 ≤ omega) (hw1 : omega ≤ 1) (hCw : 0 ≤ Cw)
    (hwdiff : |omega - 1| ≤ Cw * beta) (hCq : 0 ≤ Cq)
    (hq : |q - t ^ beta| ≤ Cq * beta * t ^ beta)
    (hcp0 : 0 < cp) (hT : 0 ≤ T) (hM : 0 ≤ M) (hcp : 4 * M ≤ cp)
    (hcpExp : 2 * Real.exp 1 ≤ cp)
    (N Y : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hN : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hY : ∀ i, MeasurePreserving (Y i) μ
      (poissonMeasure ⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩))
    (hind : ∀ i, IndepFun (Y i) (N i) μ)
    (hpair : Pairwise (fun i j => IndepFun (fun w => (Y i w, N i w))
      (fun w => (Y j w, N j w)) μ))
    (hsum : ∑ i, (lam i : ℝ) = n)
    (d : ℕ) (hd : (d : ℝ) ≤ M * (n * b)) (c : ℕ → ℝ)
    (hcoef : ∀ j : ℕ, j ≤ d → |c j| ≤ beta * A * b ^ (1 + beta - j)) :
    MemLp (nearOneHybridStatistic N Y n t beta omega T q repair d c) 2 μ ∧
      variance (nearOneHybridStatistic N Y n t beta omega T q repair d c) μ ≤
        4 * beta ^ 2 / n ^ (2 * (1 + beta)) *
          (∑ i, nearOneGammaVarianceEnvelope beta (n * t) Cw (lam i)) +
        8 * (Fintype.card ι : ℝ) * (((d : ℝ) + 1) ^ 2 * (beta * A) ^ 2 *
          Real.exp (T + M * d) * b ^ (2 * (1 + beta))) +
        8 * (Fintype.card ι : ℝ) * ((6 : ℝ) ^ (6 : ℕ) * Real.exp T *
          gammaResidualPilotConstant Cw ^ 2 * beta ^ 2 / n ^ (2 * (1 + beta)) *
            (1 + |Real.log (n * t)|) ^ 2) +
        2 * Cq ^ 2 * beta ^ 2 * t ^ (2 * beta) / n := by
  let H : ι → Ω → ℝ := fun i w => nearOneHybridResidual n t beta omega T d c (Y i w, N i w)
  let G : ι → Ω → ℝ := fun i w => nearOneGammaResidual n t beta omega (N i w)
  let Q : ι → Ω → ℝ := fun i w => nearOneSelectedLightResidual n d c T (Y i w, N i w)
  let S : ι → Ω → ℝ := fun i w => nearOneSelectedGammaResidual n t beta omega T (Y i w, N i w)
  let KQ := ((d : ℝ) + 1) ^ 2 * (beta * A) ^ 2 * Real.exp (T + M * d) * b ^ (2 * (1 + beta))
  let KS := (6 : ℝ) ^ (6 : ℕ) * Real.exp T * gammaResidualPilotConstant Cw ^ 2 * beta ^ 2 /
    n ^ (2 * (1 + beta)) * (1 + |Real.log (n * t)|) ^ 2
  let scale := beta ^ 2 / n ^ (2 * (1 + beta))
  have hG (i : ι) : MemLp (G i) 2 μ :=
    (nearOneGammaResidual_memLp (lam i) n t beta omega).comp_measurePreserving (hN i)
  have hGvar (i : ι) : variance (G i) μ ≤
      scale * nearOneGammaVarianceEnvelope beta (n * t) Cw (lam i) := by
    have h := (hN i).variance_fun_comp (measurable_of_countable (nearOneGammaResidual n t beta omega)).aemeasurable
    exact h.trans_le (near_one_gamma_residual_variance hn ht hnt hbeta hbeta1 hw0 hw1 hCw hwdiff (lam i))
  have hQ (i : ι) : MemLp (Q i) 2 μ ∧ variance (Q i) μ ≤ KQ :=
    near_one_selected_light_variance hn hb hbeta.le hA hcp0 hT hM hcp (Y i) (N i) (lam i)
      (hN i) (hY i) (hind i) d hd c hcoef
  have hS (i : ι) : MemLp (S i) 2 μ ∧ variance (S i) μ ≤ KS :=
    near_one_selected_gamma_variance hn ht hnt hbeta hbeta1 hw0 hw1 hCw hwdiff hcp0 hcpExp
      (Y i) (N i) (lam i) (hN i) (hY i) (hind i)
  have hH (i : ι) : MemLp (H i) 2 μ := (hG i).add ((hQ i).1.sub (hS i).1)
  have hHvar (i : ι) : variance (H i) μ ≤
      2 * scale * nearOneGammaVarianceEnvelope beta (n * t) Cw (lam i) + 4 * KQ + 4 * KS := by
    have ht1 := variance_fun_add_le_two (hG i) ((hQ i).1.sub (hS i).1)
    have ht2 := variance_fun_sub_le_two (hQ i).1 (hS i).1
    change variance (H i) μ ≤ _ at ht1
    change variance (Q i - S i) μ ≤ _ at ht2
    nlinarith only [ht1, ht2, hGvar i, (hQ i).2, (hS i).2]
  have hpairH : Pairwise (fun i j => IndepFun (H i) (H j) μ) := by
    intro i j hij
    exact (hpair hij).comp (measurable_of_countable (nearOneHybridResidual n t beta omega T d c))
      (measurable_of_countable (nearOneHybridResidual n t beta omega T d c))
  have hpairN : Pairwise (fun i j => IndepFun (N i) (N j) μ) := by
    intro i j hij
    exact (hpair hij).comp measurable_snd measurable_snd
  have hsumH : MemLp (fun w => ∑ i, H i w) 2 μ :=
    memLp_finset_sum (s := Finset.univ) (fun i _ => hH i)
  have hvarsum : variance (fun w => ∑ i, H i w) μ = ∑ i, variance (H i) μ := by
    convert (IndepFun.variance_sum (s := Finset.univ) (X := H)
      (fun i _ => hH i) (fun i _ j _ hij => hpairH hij)) using 1
    congr 1
    funext w
    simp only [Finset.sum_apply]
  have hsumBound : variance (fun w => ∑ i, H i w) μ ≤
      2 * scale * (∑ i, nearOneGammaVarianceEnvelope beta (n * t) Cw (lam i)) +
        4 * (Fintype.card ι : ℝ) * KQ + 4 * (Fintype.card ι : ℝ) * KS := by
    rw [hvarsum]
    have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ => hHvar i)
    convert h using 1
    simp only [Finset.sum_add_distrib, Finset.sum_const, Finset.card_univ,
      nsmul_eq_mul, ← Finset.mul_sum]
    ring
  have hanchor := common_affine_anchor_moments N lam hN hpairN hn hsum (q - t ^ beta)
  have hanchorBound := near_one_affine_anchor_variance N lam hN hpairN hn hsum ht hbeta.le hCq hq
  have htri := variance_fun_add_le_two hsumH hanchor.1
  have heq : nearOneHybridStatistic N Y n t beta omega T q repair d c = fun w =>
      (repair + t ^ beta) + ((∑ i, H i w) + poissonAffineAnchor N n (q - t ^ beta) w) := by
    funext w
    dsimp [nearOneHybridStatistic, H]
    ring
  rw [heq]
  refine ⟨(memLp_const (repair + t ^ beta)).add (hsumH.add hanchor.1), ?_⟩
  have hc := variance_const_add (hsumH.add hanchor.1).aestronglyMeasurable (repair + t ^ beta)
  change variance (fun w => (repair + t ^ beta) +
      ((∑ i, H i w) + poissonAffineAnchor N n (q - t ^ beta) w)) μ =
    variance (fun w => (∑ i, H i w) + poissonAffineAnchor N n (q - t ^ beta) w) μ at hc
  rw [hc]
  dsimp [KQ, KS, scale] at hsumBound
  have hfinal := htri.trans (add_le_add
    (mul_le_mul_of_nonneg_left hsumBound (by norm_num : (0 : ℝ) ≤ 2))
    (mul_le_mul_of_nonneg_left hanchorBound (by norm_num : (0 : ℝ) ≤ 2)))
  convert hfinal using 1
  ring

end Renyi
