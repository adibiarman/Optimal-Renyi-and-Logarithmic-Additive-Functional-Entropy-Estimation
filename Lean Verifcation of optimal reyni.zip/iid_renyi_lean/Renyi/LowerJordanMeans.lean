import Renyi.LowerJordanMoments
import Renyi.LowerActiveMass
import Renyi.TensorPriorSecondBounds

/-! Power-mean bounds from the actual tensor Jordan normalizer. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- A positive power approaching zero keeps a uniform floor when its base
is bounded below by a fixed multiple of that power. -/
theorem small_power_uniform_floor {s z c : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hc : 0<c) (hc1 : c≤1) (hz : c*s≤z) :
    c*Real.exp (-1)≤z^s := by
  have hsLog : -1≤s*Real.log s := by
    have hh := mul_le_mul_of_nonneg_left (Real.one_sub_inv_le_log_of_pos hs) hs.le
    have hid : s*(1-s⁻¹)=s-1 := by field_simp
    rw [hid] at hh
    linarith
  have hself : Real.exp (-1)≤s^s := by
    rw [Real.rpow_def_of_pos hs]
    exact Real.exp_le_exp.mpr (by nlinarith only [hsLog])
  have hcPower : c≤c^s := by
    simpa only [Real.rpow_one] using Real.rpow_le_rpow_of_exponent_ge hc hc1 hs1
  have hz0 : 0<z := (mul_pos hc hs).trans_le hz
  calc
    _ ≤ c^s*s^s := mul_le_mul hcPower hself (Real.exp_pos _).le (Real.rpow_nonneg hc.le _)
    _ = (c*s)^s := (Real.mul_rpow hc.le hs.le).symm
    _ ≤ z^s := Real.rpow_le_rpow (mul_pos hc hs).le hz hs.le

/-- Dividing the active principal target by the square of the dimension
preserves a fixed small-power floor with an explicit polynomial loss. -/
theorem active_node_power_floor {s z c d : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hc : 0<c) (hc1 : c≤1) (hz : c*s≤z)
    (hd : 1≤d) :
    c*Real.exp (-1)/(8*d^2)≤((z/8)/d^2)^s := by
  have hz0 : 0<z := (mul_pos hc hs).trans_le hz
  have hd0 : 0<d := zero_lt_one.trans_le hd
  have hden : (1:ℝ)≤8*d^2 := by nlinarith
  have hdenpow : (8*d^2)^s≤8*d^2 := by
    simpa only [Real.rpow_one] using Real.rpow_le_rpow_of_exponent_le hden hs1
  have hfloor := small_power_uniform_floor hs hs1 hc hc1 hz
  have heq : (z/8)/d^2=z/(8*d^2) := by ring
  rw [heq,Real.div_rpow hz0.le (by positivity : (0:ℝ)≤8*d^2)]
  exact div_le_div₀ (by positivity) hfloor (Real.rpow_pos_of_pos (by positivity) _) hdenpow

/-- The exact tensor normalizer turns a low Jordan lower bound into a
power-mean upper bound for either of the same constructed priors. -/
theorem tensor_prior_mean_upper {ι κ τ : Type*}
    [Fintype ι] [Fintype κ] [Fintype τ]
    (l u : ι→ℝ) (r w : κ→ℝ) (p : FiniteAtomicPrior τ)
    {a b alpha M J₀ : ℝ}
    (ha : 0<a) (hb : 0<b) (halpha : 1≤alpha)
    (hu : ∀ i, 0<u i) (hw : ∀ j, 0<w j) (hwb : ∀ j, b≤w j)
    (hr : ∑ j, positiveCoeff (r j)=1)
    (hnr : (∑ j, negativeCoeff (r j))≤1)
    (j₀ : κ) (hw₀ : w j₀=b) (hprincipal : 1/2≤|r j₀|)
    (hcancel : ∑ i, l i*u i^(alpha-1)=0)
    (hJ₀ : 0<J₀) (hJordan : J₀≤∑ i, positiveCoeff (l i)*u i^(alpha-1))
    (_hM : 0≤M) (hM2 : M≤2)
    (hA : priorMoment p alpha=((a*b)⁻¹)^(alpha-1)/tensorNormalizer l r u w a alpha*M) :
    priorMoment p alpha≤4/J₀ := by
  let B := (a*b)⁻¹
  let Z := tensorNormalizer l r u w a alpha
  have hBp : 0<B^(alpha-1) := Real.rpow_pos_of_pos (inv_pos.mpr (mul_pos ha hb)) _
  have hi := (high_inverse_moment_bounds r w hb (sub_nonneg.mpr halpha) hwb hr rfl hnr j₀ hw₀ hprincipal).1
  have hscaled : J₀/2≤Z/B^(alpha-1) := by
    rw [tensorNormalizer_scaled_jordan l u r w ha hb hu hw hcancel]
    have hh := mul_le_mul hJordan hi (by norm_num : (0:ℝ)≤1/2)
      ((Finset.sum_nonneg (fun i _ => mul_nonneg (le_max_right _ _) (Real.rpow_nonneg (hu _).le _))))
    nlinarith only [hh]
  have hscaled0 : 0<Z/B^(alpha-1) := (half_pos hJ₀).trans_le hscaled
  have hZ : 0<Z := (div_pos_iff_of_pos_right hBp).mp hscaled0
  have hAe : priorMoment p alpha=M/(Z/B^(alpha-1)) := by
    rw [hA]
    dsimp [B,Z]
    field_simp
  rw [hAe]
  calc
    _ ≤ 2/(Z/B^(alpha-1)) := div_le_div_of_nonneg_right hM2 hscaled0.le
    _ ≤ 2/(J₀/2) := div_le_div_of_nonneg_left (by norm_num) (half_pos hJ₀) hscaled
    _ = 4/J₀ := by ring

end Renyi
