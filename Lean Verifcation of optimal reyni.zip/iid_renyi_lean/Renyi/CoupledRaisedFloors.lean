import Renyi.CoupledProfileLower

/-! Raised-floor bounds for the actual low and high endpoint profiles. -/
noncomputable section
open Set
namespace Renyi

lemma normalizer_le_power_at_large_scale {N d : ℕ} (hN : 0<N)
    {s x C : ℝ} {H : ℝ → ℝ} (hs : 0<s) (hC : 0<C) (hx : 0≤x)
    (hy : C*s≤(N:ℝ)^2*x)
    (hupper : (N:ℝ)^(2*s)*coupledNormalizer s (endpointKernel N d) H≤(C*s)^s) :
    coupledNormalizer s (endpointKernel N d) H≤x^s := by
  have hNp : 0<(N:ℝ)^(2*s) := Real.rpow_pos_of_pos (by exact_mod_cast hN) _
  have hpow := Real.rpow_le_rpow (mul_pos hC hs).le hy hs.le
  rw [←endpoint_scale_power hN hx] at hpow
  exact (mul_le_mul_iff_right₀ hNp).mp (hupper.trans hpow)

lemma raised_floor_mix_lower {K J f : ℝ} (hK0 : 0≤K) (hK1 : K≤1)
    (_hJ0 : 0≤J) (hJ1 : J≤1) (_hf : 0≤f) (hf1 : f≤1) :
    f-(1-J)*(1-K)≤K+f*J*(1-K) := by
  have hprod : 0≤(1-J)*(1-K) := mul_nonneg (sub_nonneg.mpr hJ1) (sub_nonneg.mpr hK1)
  have hmix1 := mul_le_mul_of_nonneg_right hf1 hK0
  have hmix2 := mul_le_mul_of_nonneg_right hf1 hprod
  nlinarith only [hmix1,hmix2]

/-- Exact low-profile floor reduction, before any scalar s calibration. -/
theorem lowProfile_floor_reduction {N : ℕ} (hN : 2≤N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : endpointReserveConstant f*s≤(N:ℝ)^2*x) :
    f-(1-endpointProfile N 2 s x)*(1-endpointKernel N 2 x)≤lowProfile N s f x := by
  have hN0 : 0<N := by omega
  have hK0 := endpointKernel_nonneg N 2 x
  have hK1 := endpointKernel_le_one hN0 2 hx hx1
  have hJ := endpointProfile_range hN0 (by norm_num : 2≤6) hs hx hx1
  have ha := lowNormalizer_pos hN0 hs hf hf1
  have hpow := normalizer_le_power_at_large_scale (d:=2) hN0 hs (endpointReserveConstant_pos hf1) hx hy
    (lowNormalizer_sharp_upper hN hs hs1 hf hf1)
  have hbump : endpointKernel N 2 x≤x^s*endpointKernel N 2 x/lowNormalizer N s f := by
    apply (le_div_iff₀ ha).mpr
    have hm := mul_le_mul_of_nonneg_right hpow hK0
    change endpointKernel N 2 x*coupledNormalizer s (endpointKernel N 2) (lowShoulder N s f)≤_
    nlinarith only [hm]
  have hmix := raised_floor_mix_lower hK0 hK1 hJ.1 hJ.2 hf hf1.le
  unfold lowProfile coupledProfile lowShoulder
  change f-(1-endpointProfile N 2 s x)*(1-endpointKernel N 2 x)≤
    x^s*endpointKernel N 2 x/lowNormalizer N s f+f*endpointProfile N 2 s x*(1-endpointKernel N 2 x)
  linarith only [hbump,hmix]

/-- The corresponding high-profile reduction is uniform in omega. -/
theorem highProfile_floor_reduction {N : ℕ} (hN : 2≤N) {s f ω x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : endpointReserveConstant f*s≤(N:ℝ)^2*x) :
    ω*(f-(1-endpointProfile N 6 s x)*(1-endpointKernel N 6 x))≤highProfile N s f ω x := by
  have hN0 : 0<N := by omega
  have hK0 := endpointKernel_nonneg N 6 x
  have hK1 := endpointKernel_le_one hN0 6 hx hx1
  have hJ := endpointProfile_range hN0 (by norm_num : 6≤6) hs hx hx1
  have ha := highNormalizer_pos hN0 hs hf hf1.le hω hω1
  have hpow := normalizer_le_power_at_large_scale (d:=6) hN0 hs (endpointReserveConstant_pos hf1) hx hy
    (highNormalizer_sharp_upper hN hs hs1 hf hf1 hω hω1)
  have hbump : ω*endpointKernel N 6 x≤x^s*endpointKernel N 6 x/highNormalizer N s f ω := by
    apply (le_div_iff₀ ha).mpr
    change highNormalizer N s f ω≤x^s at hpow
    have hm := mul_le_mul_of_nonneg_right hpow hK0
    have hmω := mul_le_mul_of_nonneg_right hω1.le (mul_nonneg ha.le hK0)
    nlinarith only [hm,hmω]
  have hWf : f≤highShoulderWeight N f x := by
    unfold highShoulderWeight
    nlinarith only [mul_nonneg (sub_nonneg.mpr hf1.le) (sq_nonneg (1-endpointKernel N 3 x))]
  have hshoulder := mul_le_mul_of_nonneg_left hWf
    (mul_nonneg (mul_nonneg hω hJ.1) (sub_nonneg.mpr hK1))
  have hmix := mul_le_mul_of_nonneg_left (raised_floor_mix_lower hK0 hK1 hJ.1 hJ.2 hf hf1.le) hω
  unfold highProfile coupledProfile highShoulder
  change ω*(f-(1-endpointProfile N 6 s x)*(1-endpointKernel N 6 x))≤
    x^s*endpointKernel N 6 x/highNormalizer N s f ω+
      ω*endpointProfile N 6 s x*(1-endpointKernel N 6 x)*highShoulderWeight N f x
  nlinarith only [hbump,hshoulder,hmix]

def endpointTailDefectConstant : ℝ := Real.exp (Real.log 12+1)+1

lemma endpointTailDefectConstant_pos : 0<endpointTailDefectConstant := by
  unfold endpointTailDefectConstant
  positivity

lemma endpoint_sum_tail_defect {N d : ℕ} (hN : 0<N) (hd0 : 2≤d) (hd1 : d≤6)
    {s x : ℝ} (hs : 0<s) (hs1 : s≤1) (hx : 0<x) (hx1 : x≤1) (hy : 1≤(N:ℝ)^2*x) :
    (1-endpointProfile N d s x)+endpointKernel N d x≤endpointTailDefectConstant/((N:ℝ)^2*x) := by
  have hy0 : 0<(N:ℝ)^2*x := by positivity
  have hinv0 : 0≤((N:ℝ)^2*x)⁻¹ := by positivity
  have hinv1 : ((N:ℝ)^2*x)⁻¹≤1 := inv_le_one_of_one_le₀ hy
  have htail := endpointKernel_le_inverse_power hN d hx hx1
  have hpow := pow_le_pow_of_le_one hinv0 hinv1 (show 1≤d by omega)
  have hK : endpointKernel N d x≤((N:ℝ)^2*x)⁻¹ :=
    htail.trans (by simpa only [pow_one] using hpow)
  have hJ := endpointProfile_tail hN hd0 hd1 hs hs1 hx hx1
  have hdR : (2:ℝ)≤d := by exact_mod_cast hd0
  have hrpow := Real.rpow_le_rpow_of_exponent_le hy (show s-(d:ℝ)≤-1 by linarith only [hs1,hdR])
  rw [Real.rpow_neg_one] at hrpow
  have hm := mul_le_mul_of_nonneg_left hrpow (show 0≤Real.exp (Real.log 12+1)*s by positivity)
  have hsMul := mul_le_mul_of_nonneg_left hs1
    (mul_nonneg (Real.exp_pos (Real.log 12+1)).le hinv0)
  unfold endpointTailDefectConstant
  rw [div_eq_mul_inv]
  nlinarith only [hK,hJ,hm,hsMul]

lemma shoulder_tail_mix_lower {K J f : ℝ} (hK0 : 0≤K) (_hK1 : K≤1)
    (_hJ0 : 0≤J) (hJ1 : J≤1) (hf : 0≤f) (hf1 : f≤1) :
    f-((1-J)+K)≤f*J*(1-K) := by
  have herr : 0≤(1-J)+K := by linarith only [hJ1,hK0]
  have hKJ := mul_nonneg hK0 (sub_nonneg.mpr hJ1)
  have hmul := mul_le_mul_of_nonneg_left (show 1-((1-J)+K)≤J*(1-K) by nlinarith only [hKJ]) hf
  have hferr := mul_le_mul_of_nonneg_right hf1 herr
  nlinarith only [hmul,hferr]

/-- The actual low shoulder supplies a uniform scaled-tail approximation to f. -/
theorem lowProfile_tail_lower {N : ℕ} (hN : 0<N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1)
    (hx : 0<x) (hx1 : x≤1) (hy : 1≤(N:ℝ)^2*x) :
    f-endpointTailDefectConstant/((N:ℝ)^2*x)≤lowProfile N s f x := by
  have hK := endpointKernel_nonneg N 2 x
  have hK1 := endpointKernel_le_one hN 2 hx.le hx1
  have hJ := endpointProfile_range hN (by norm_num : 2≤6) hs hx.le hx1
  have hmix := shoulder_tail_mix_lower hK hK1 hJ.1 hJ.2 hf hf1.le
  have htail := endpoint_sum_tail_defect hN (by norm_num : 2≤2) (by norm_num : 2≤6) hs hs1 hx hx1 hy
  have hfirst : 0≤x^s*endpointKernel N 2 x/lowNormalizer N s f := by
    exact div_nonneg (mul_nonneg (Real.rpow_nonneg hx.le s) hK) (lowNormalizer_pos hN hs hf hf1).le
  unfold lowProfile coupledProfile lowShoulder
  change f-endpointTailDefectConstant/((N:ℝ)^2*x)≤
    x^s*endpointKernel N 2 x/lowNormalizer N s f+f*endpointProfile N 2 s x*(1-endpointKernel N 2 x)
  linarith only [hmix,htail,hfirst]

/-- The actual high shoulder supplies a tail approximation uniform in omega. -/
theorem highProfile_tail_lower {N : ℕ} (hN : 0<N) {s f ω x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0<x) (hx1 : x≤1) (hy : 1≤(N:ℝ)^2*x) :
    ω*(f-endpointTailDefectConstant/((N:ℝ)^2*x))≤highProfile N s f ω x := by
  have hK := endpointKernel_nonneg N 6 x
  have hK1 := endpointKernel_le_one hN 6 hx.le hx1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hs hx.le hx1
  have hmix := shoulder_tail_mix_lower hK hK1 hJ.1 hJ.2 hf hf1.le
  have htail := endpoint_sum_tail_defect hN (by norm_num : 2≤6) (by norm_num : 6≤6) hs hs1 hx hx1 hy
  have hWf : f≤highShoulderWeight N f x := by
    unfold highShoulderWeight
    nlinarith only [mul_nonneg (sub_nonneg.mpr hf1.le) (sq_nonneg (1-endpointKernel N 3 x))]
  have hshoulder := mul_le_mul_of_nonneg_left hWf
    (mul_nonneg (mul_nonneg hω hJ.1) (sub_nonneg.mpr hK1))
  have hfirst : 0≤x^s*endpointKernel N 6 x/highNormalizer N s f ω :=
    div_nonneg (mul_nonneg (Real.rpow_nonneg hx.le s) hK) (highNormalizer_pos hN hs hf hf1.le hω hω1).le
  have hωmix := mul_le_mul_of_nonneg_left hmix hω
  have hωtail := mul_le_mul_of_nonneg_left htail hω
  unfold highProfile coupledProfile highShoulder
  change ω*(f-endpointTailDefectConstant/((N:ℝ)^2*x))≤
    x^s*endpointKernel N 6 x/highNormalizer N s f ω+
      ω*endpointProfile N 6 s x*(1-endpointKernel N 6 x)*highShoulderWeight N f x
  nlinarith only [hωmix,hωtail,hshoulder,hfirst]

end Renyi
