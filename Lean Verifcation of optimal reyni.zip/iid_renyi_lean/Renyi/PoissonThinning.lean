import Renyi.FingerprintDistance
import Mathlib.Data.Finset.Sort

/-! Actual deletion of zero marks from a Poisson number of iid records. -/
noncomputable section
open scoped BigOperators ENNReal NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- Retained positions of a finite record. -/
def retainedPositions {n : ℕ} (x : Fin n → ℕ) : Finset (Fin n) :=
  Finset.univ.filter (fun i => x i ≠ 0)

/-- The retained positions, in their original order. -/
def retainedEmbedding {n : ℕ} (x : Fin n → ℕ) :
    Fin (retainedPositions x).card ↪ Fin n :=
  ((retainedPositions x).orderEmbOfFin rfl).toEmbedding

theorem retainedEmbedding_nonzero {n : ℕ} (x : Fin n → ℕ)
    (i : Fin (retainedPositions x).card) : x (retainedEmbedding x i) ≠ 0 := by
  have h := (retainedPositions x).orderEmbOfFin_mem rfl i
  exact (Finset.mem_filter.mp h).2

theorem retainedEmbedding_covers {n : ℕ} (x : Fin n → ℕ) (i : Fin n) :
    i ∈ Set.range (retainedEmbedding x) ↔ x i ≠ 0 := by
  simp [retainedEmbedding, Finset.range_orderEmbOfFin, retainedPositions]

/-- Delete zero marks and reindex each retained positive mark `j+1` as `j`. -/
def thinPositiveRecord (x : PoissonMarkedSample ℕ) : PoissonMarkedSample ℕ :=
  ⟨(retainedPositions x.2).card, fun i => x.2 (retainedEmbedding x.2 i)-1⟩

theorem thinPositiveRecord_entry (x : PoissonMarkedSample ℕ)
    (i : Fin (thinPositiveRecord x).1) :
    (thinPositiveRecord x).2 i + 1 = x.2 (retainedEmbedding x.2 i) := by
  exact Nat.sub_add_cancel (Nat.one_le_iff_ne_zero.mpr (retainedEmbedding_nonzero x.2 i))

/-- Restricting an iid array to distinct fixed coordinates preserves its iid law. -/
theorem iidCountablePMF_restrict {κ : Type*} [Countable κ]
    [MeasurableSpace κ] [MeasurableSingletonClass κ]
    (q : PMF κ) {r n : ℕ} (s : Fin r ↪ Fin n) :
    (iidCountablePMF q n).map (fun x i => x (s i)) = iidCountablePMF q r := by
  apply PMF.toMeasure_injective
  rw [← PMF.toMeasure_map _ _ (measurable_of_countable _)]
  simp only [iidCountablePMF, Measure.toPMF_toMeasure]
  have hi := (iIndepFun_pi (μ := fun _ : Fin n => q.toMeasure)
    (X := fun _ => id) (fun _ => measurable_id.aemeasurable)).precomp s.injective
  have heq := (iIndepFun_iff_map_fun_eq_pi_map
    (fun i => (measurable_pi_apply (s i)).aemeasurable)).mp hi
  simpa only [id_eq, (measurePreserving_eval (fun _ : Fin n => q.toMeasure) _).map_eq]
    using heq

/-- Finite products commute with summation over all coordinate choices. -/
theorem ennreal_tsum_fin_product {κ : Type*} (n : ℕ) (f : Fin n → κ → ℝ≥0∞) :
    (∑' x : Fin n → κ, ∏ i, f i (x i)) = ∏ i, ∑' a, f i a := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [← (Fin.consEquiv (fun _ : Fin (n+1) => κ)).tsum_eq]
    simp only [Fin.prod_univ_succ, Fin.consEquiv_apply, Fin.cons_zero, Fin.cons_succ]
    rw [ENNReal.tsum_prod']
    simp_rw [ENNReal.tsum_mul_left, ih]
    rw [ENNReal.tsum_mul_right]

/-- Independent coordinates, allowing a different marginal in each position. -/
def coordinateCountablePMF {κ : Type*} [Countable κ]
    [MeasurableSpace κ] [MeasurableSingletonClass κ] {n : ℕ}
    (q : Fin n → PMF κ) : PMF (Fin n → κ) :=
  (Measure.pi (fun i => (q i).toMeasure)).toPMF

@[simp] theorem coordinateCountablePMF_apply {κ : Type*} [Countable κ]
    [MeasurableSpace κ] [MeasurableSingletonClass κ] {n : ℕ}
    (q : Fin n → PMF κ) (x : Fin n → κ) :
    coordinateCountablePMF q x = ∏ i, q i (x i) := by
  rw [coordinateCountablePMF, Measure.toPMF_apply]
  have hset : ({x} : Set (Fin n → κ)) = Set.univ.pi (fun i => {x i}) := by
    ext y
    simp only [Set.mem_singleton_iff, Set.mem_univ_pi, Set.mem_singleton_iff]
    exact funext_iff
  rw [hset, Measure.pi_pi]
  exact Finset.prod_congr rfl (fun i _ =>
    PMF.toMeasure_apply_singleton _ _ (MeasurableSet.singleton _))

/-- Independent mixtures may be sampled by first drawing all their latent flags. -/
theorem coordinateCountablePMF_bind {κ η : Type*} [Countable κ] [Countable η]
    [MeasurableSpace κ] [MeasurableSingletonClass κ]
    [MeasurableSpace η] [MeasurableSingletonClass η] {n : ℕ}
    (p : Fin n → PMF κ) (q : Fin n → κ → PMF η) :
    coordinateCountablePMF (fun i => (p i).bind (q i)) =
      (coordinateCountablePMF p).bind
        (fun x => coordinateCountablePMF (fun i => q i (x i))) := by
  ext y
  simp only [coordinateCountablePMF_apply, PMF.bind_apply, ← Finset.prod_mul_distrib]
  exact (ennreal_tsum_fin_product n (fun i a => p i a * q i a (y i))).symm

/-- Coordinatewise maps of iid draws have the corresponding independent marginals. -/
theorem iidCountablePMF_coordinate_map {κ η : Type*} [Countable κ] [Countable η]
    [MeasurableSpace κ] [MeasurableSingletonClass κ]
    [MeasurableSpace η] [MeasurableSingletonClass η]
    (q : PMF κ) (n : ℕ) (f : Fin n → κ → η) :
    (iidCountablePMF q n).map (fun x i => f i (x i)) =
      coordinateCountablePMF (fun i => q.map (f i)) := by
  apply PMF.toMeasure_injective
  rw [← PMF.toMeasure_map _ _ (measurable_of_countable _)]
  simp only [iidCountablePMF, coordinateCountablePMF, Measure.toPMF_toMeasure]
  rw [Measure.pi_map_pi (fun i => (measurable_of_countable (f i)).aemeasurable)]
  simp_rw [PMF.toMeasure_map _ _ (measurable_of_countable _)]

/-- A flag indicates exactly whether the original mark is positive. -/
def retentionFlagPMF (q : PMF ℕ) : PMF Bool := q.map (fun j => decide (j ≠ 0))

theorem positiveMarkMass_coe_eq (q : PMF ℕ) :
    (positiveMarkMass q : ℝ≥0∞) = ∑' j, q (j+1) := by
  have hle := ENNReal.tsum_comp_le_tsum_of_injective
    Nat.succ_injective q
  rw [q.tsum_coe] at hle
  apply (ENNReal.toReal_eq_toReal ENNReal.coe_ne_top (ne_top_of_le_ne_top ENNReal.one_ne_top hle)).mp
  rw [ENNReal.tsum_toReal_eq (fun j => q.apply_ne_top (j+1))]
  rfl

@[simp] theorem retentionFlagPMF_true (q : PMF ℕ) :
    retentionFlagPMF q true = (positiveMarkMass q : ℝ≥0∞) := by
  rw [retentionFlagPMF, PMF.map_apply, tsum_eq_zero_add' ENNReal.summable]
  simp [positiveMarkMass_coe_eq]

@[simp] theorem retentionFlagPMF_false (q : PMF ℕ) : retentionFlagPMF q false = q 0 := by
  rw [retentionFlagPMF, PMF.map_apply, tsum_eq_zero_add' ENNReal.summable]
  simp

/-- A positive mark can be sampled independently of its retention flag. -/
theorem mark_retention_decomposition (q : PMF ℕ) :
    q = (retentionFlagPMF q).bind (fun b =>
      (visibleMarkPMF q).map (fun j => if b then j+1 else 0)) := by
  ext j
  cases j with
  | zero => simp [PMF.bind_apply, tsum_fintype, PMF.map_apply]
  | succ j =>
    have h := congrArg (fun x : ℝ≥0 => (x : ℝ≥0∞)) (visibleMarkPMF_intensity 1 q j)
    simp only [one_mul, ENNReal.coe_mul, ENNReal.coe_toNNReal (PMF.apply_ne_top _ _)] at h
    simp only [PMF.bind_apply, tsum_fintype, Fintype.sum_bool,
      retentionFlagPMF_true, retentionFlagPMF_false, Bool.false_eq_true, if_false, if_true,
      PMF.map_apply]
    simp only [Nat.add_left_inj, Nat.add_eq_zero_iff,
      Nat.one_ne_zero, and_false, if_false, tsum_zero, mul_zero, add_zero]
    rw [tsum_eq_single j]
    · simpa using h.symm
    · intro a ha
      simp [Ne.symm ha]

/-- Apply a retention mask to independently sampled positive marks. -/
def maskedMarks {n : ℕ} (b : Fin n → Bool) (x : Fin n → ℕ) : Fin n → ℕ :=
  fun i => if b i then x i+1 else 0

/-- The iid mark array admits independent flag and positive-mark arrays. -/
theorem iid_retention_decomposition (q : PMF ℕ) (n : ℕ) :
    iidCountablePMF q n = (iidCountablePMF (retentionFlagPMF q) n).bind
      (fun b => (iidCountablePMF (visibleMarkPMF q) n).map (maskedMarks b)) := by
  have h := coordinateCountablePMF_bind (fun _ : Fin n => retentionFlagPMF q)
    (fun _ b => (visibleMarkPMF q).map (fun j => if b then j+1 else 0))
  simp_rw [← mark_retention_decomposition q, ← iidCountablePMF_coordinate_map] at h
  exact h

/-- Positions selected by a Boolean mask. -/
def flagPositions {n : ℕ} (b : Fin n → Bool) : Finset (Fin n) :=
  Finset.univ.filter (fun i => b i = true)

def flagEmbedding {n : ℕ} (b : Fin n → Bool) : Fin (flagPositions b).card ↪ Fin n :=
  ((flagPositions b).orderEmbOfFin rfl).toEmbedding

theorem flagEmbedding_true {n : ℕ} (b : Fin n → Bool) (i : Fin (flagPositions b).card) :
    b (flagEmbedding b i) = true :=
  (Finset.mem_filter.mp ((flagPositions b).orderEmbOfFin_mem rfl i)).2

/-- Deleting zeros from a masked record extracts precisely the selected coordinates. -/
theorem thinPositiveRecord_masked {n : ℕ} (b : Fin n → Bool) (x : Fin n → ℕ) :
    thinPositiveRecord ⟨n, maskedMarks b x⟩ =
      ⟨(flagPositions b).card, fun i => x (flagEmbedding b i)⟩ := by
  have hpos : retainedPositions (maskedMarks b x) = flagPositions b := by
    ext i
    cases hb : b i <;> simp [retainedPositions, flagPositions, maskedMarks, hb]
  calc
    thinPositiveRecord ⟨n, maskedMarks b x⟩ =
        ⟨(flagPositions b).card, fun i => maskedMarks b x (flagEmbedding b i)-1⟩ := by
      exact congrArg (fun S : Finset (Fin n) =>
        (⟨S.card, fun i => maskedMarks b x ((S.orderEmbOfFin rfl).toEmbedding i)-1⟩ :
          PoissonMarkedSample ℕ)) hpos
    _ = ⟨(flagPositions b).card, fun i => x (flagEmbedding b i)⟩ := by
      apply congrArg (fun f : Fin (flagPositions b).card → ℕ =>
        (⟨(flagPositions b).card, f⟩ : PoissonMarkedSample ℕ))
      funext i
      change (if b (flagEmbedding b i) then x (flagEmbedding b i)+1 else 0)-1 = _
      rw [flagEmbedding_true b i]
      simp

end Renyi
