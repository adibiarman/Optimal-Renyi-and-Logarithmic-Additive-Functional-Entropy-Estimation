import Renyi.UpperParameters

/-! Explicit linear margins for the overlap target near order one. -/
noncomputable section
namespace Renyi

/-- The tangent inequality for the exponential, expressed as a difference. -/
theorem exp_difference_tangent (a b : ℝ) :
    Real.exp a * (b-a) ≤ Real.exp b - Real.exp a := by
  have h := mul_le_mul_of_nonneg_left (Real.add_one_le_exp (b-a)) (Real.exp_pos a).le
  have heq : Real.exp a * Real.exp (b-a) = Real.exp b := by
    rw [← Real.exp_add]
    congr 1
    ring
  rw [heq] at h
  nlinarith

/-- An explicit positive constant controlling both sides of the overlap target. -/
def nearOneMarginConstant (ε cω : ℝ) : ℝ :=
  min (cω*ε*Real.exp (-ε)) (2*ε*(1-cω)*Real.exp (-ε))

theorem nearOneMarginConstant_pos {ε cω : ℝ} (hε : 0 < ε)
    (hcω : 0 < cω) (hcω1 : cω < 1) : 0 < nearOneMarginConstant ε cω := by
  have hc : 0 < 1-cω := sub_pos.mpr hcω1
  unfold nearOneMarginConstant
  exact lt_min (by positivity) (by positivity)

/-- The reserved accuracy interval gives margins of order `β` on both sides. -/
theorem near_one_exponential_margins {ε cω β E0 : ℝ}
    (hε : 0 < ε) (hcω : 0 < cω) (hcω1 : cω < 1)
    (hβ : 0 < β) (hβhalf : β ≤ 1/2)
    (hElo : ε*β ≤ E0) (hEhi : E0 ≤ 2*ε*β) :
    nearOneMarginConstant ε cω * β ≤
      min (1-Real.exp (-cω*E0)) (Real.exp (-cω*E0)-Real.exp (-2*ε*β)) ∧
    1-Real.exp (-cω*E0) ≤ 2*cω*ε*β := by
  have hc : 0 < 1-cω := sub_pos.mpr hcω1
  have hE : 0 < E0 := (mul_pos hε hβ).trans_le hElo
  have hEb : 2*ε*β ≤ ε := by nlinarith
  have hcE : cω*E0 ≤ ε := by nlinarith
  have he₁ : Real.exp (-ε) ≤ Real.exp (-cω*E0) := Real.exp_le_exp.mpr (by linarith)
  have he₂ : Real.exp (-ε) ≤ Real.exp (-2*ε*β) := Real.exp_le_exp.mpr (by linarith)
  have h₁ := exp_difference_tangent (-cω*E0) 0
  simp only [Real.exp_zero, zero_sub] at h₁
  have h₂ := exp_difference_tangent (-2*ε*β) (-cω*E0)
  have hlo₁ : cω*ε*Real.exp (-ε)*β ≤ 1-Real.exp (-cω*E0) := by
    have hprod := mul_le_mul he₁ (mul_le_mul_of_nonneg_left hElo hcω.le)
      (by positivity : 0 ≤ cω*(ε*β)) (Real.exp_pos _).le
    nlinarith
  have hgap : 2*ε*(1-cω)*β ≤ -cω*E0-(-2*ε*β) := by
    nlinarith [mul_le_mul_of_nonneg_left hEhi hcω.le]
  have hlo₂ : 2*ε*(1-cω)*Real.exp (-ε)*β ≤
      Real.exp (-cω*E0)-Real.exp (-2*ε*β) := by
    have hprod := mul_le_mul he₂ hgap (by positivity : 0 ≤ 2*ε*(1-cω)*β)
      (Real.exp_pos _).le
    nlinarith
  refine ⟨le_min ?_ ?_, ?_⟩
  · exact (mul_le_mul_of_nonneg_right (min_le_left _ _) hβ.le).trans hlo₁
  · exact (mul_le_mul_of_nonneg_right (min_le_right _ _) hβ.le).trans hlo₂
  · have h := Real.add_one_le_exp (-cω*E0)
    nlinarith [mul_le_mul_of_nonneg_left hEhi hcω.le]

/-- The actual calibrated overlap target has the same explicit linear margins. -/
theorem upperOmega_near_one_margins {k : ℕ} {α ε Ch cω : ℝ}
    (hα : 1 < α) (hαhalf : α ≤ 3/2)
    (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1)
    (hε : 0 < ε) (hCh : 0 ≤ Ch) (hcω : 0 < cω) (hcω1 : cω < 1) :
    nearOneMarginConstant ε cω * (α-1) ≤
      min (1-upperOmega k α ε Ch cω)
        (upperOmega k α ε Ch cω-Real.exp (-2*ε*(α-1))) ∧
    1-upperOmega k α ε Ch cω ≤ 2*cω*ε*(α-1) := by
  have hE := upper_reserved_interval (k := k) hα hγ hγ1 hε hCh
  exact near_one_exponential_margins hε hcω hcω1 (by linarith) (by linarith) hE.1 hE.2

end Renyi
