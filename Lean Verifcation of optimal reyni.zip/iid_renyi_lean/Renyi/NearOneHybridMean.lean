import Renyi.NearOneMeanAssembly

/-! Actual hybrid means and uniform beta-preserving aggregation. -/
noncomputable section
open scoped BigOperators NNReal
open Polynomial MeasureTheory ProbabilityTheory
namespace Renyi
set_option maxHeartbeats 600000

/-- The selected Gamma mean error in probability units, including p=0. -/
theorem near_one_gamma_coordinate_mean_error {n p beta omega cp B eta : ℝ}
    (hn : 0<n) (hp : 0≤p) (hb : 0<beta) (hb1 : beta≤1/2)
    (hw : 0≤omega) (hw1 : omega≤1) (hcp : 1≤cp) (hB : 16≤B)
    (heta : 0≤eta) (hlarge : Real.exp (-B/2)≤eta) (hsmall : Real.exp (-cp)≤eta) :
    (1-poissonLowerMass (Real.toNNReal (cp*n*p)) (cp*B*(1+beta)))*
      |omega*analyticMean (Real.toNNReal (n*p)) (1+beta)/n^(1+beta)-omega*p^(1+beta)|≤
        2*eta*beta*p^(1+beta) := by
  let lam := Real.toNNReal (n*p)
  have hl : (lam:ℝ)=n*p := Real.coe_toNNReal _ (mul_nonneg hn.le hp)
  have hcp0 : 0<cp := by linarith only [hcp]
  let pilot : ℝ≥0 := ⟨cp*lam,mul_nonneg hcp0.le lam.coe_nonneg⟩
  have hpilot : pilot=Real.toNNReal (cp*n*p) := by
    ext
    rw [Real.toNNReal_of_nonneg (by positivity : 0≤cp*n*p)]
    change cp*(lam:ℝ)=cp*n*p
    rw [hl]
    ring
  have hm := analyticMean_near_one_bias_all hb hb1 lam
  have hf := near_one_heavy_pilot_bias_factor hcp hB (by linarith only [hb] : 1≤1+beta) heta hlarge hsmall lam
  have hmass0 : 0≤poissonUpperMass pilot (cp*B*(1+beta)) := poissonUpperMass_nonneg _ _
  have hfirst := mul_le_mul_of_nonneg_left hm hmass0
  have hsecond := mul_le_mul_of_nonneg_left hf (show 0≤2*beta by positivity)
  have hsel : poissonUpperMass pilot (cp*B*(1+beta))*
      |analyticMean lam (1+beta)-(lam:ℝ)^(1+beta)|≤2*eta*beta*(lam:ℝ)^(1+beta) := by
    nlinarith only [hfirst,hsecond]
  rw [hpilot,poissonUpperMass_eq_one_sub] at hsel
  have hnPow : 0<n^(1+beta) := Real.rpow_pos_of_pos hn _
  have hpow : (lam:ℝ)^(1+beta)=n^(1+beta)*p^(1+beta) := by rw [hl,Real.mul_rpow hn.le hp]
  have hid : omega*analyticMean lam (1+beta)/n^(1+beta)-omega*p^(1+beta)=
      (omega/n^(1+beta))*(analyticMean lam (1+beta)-(lam:ℝ)^(1+beta)) := by
    rw [hpow]
    field_simp
  rw [hid,abs_mul,abs_of_nonneg (div_nonneg hw hnPow.le)]
  have hscaled := mul_le_mul_of_nonneg_left hsel (div_nonneg hw hnPow.le)
  have hmain : (1-poissonLowerMass (Real.toNNReal (cp*n*p)) (cp*B*(1+beta)))*
      ((omega/n^(1+beta))*|analyticMean lam (1+beta)-(lam:ℝ)^(1+beta)|)≤omega*(2*eta*beta*p^(1+beta)) := by
    convert hscaled using 1
    · ring
    · rw [hpow]
      field_simp
  have hfinal := mul_le_of_le_one_left (show 0≤2*eta*beta*p^(1+beta) by positivity) hw1
  exact hmain.trans hfinal

/-- The full mean is the genuine polynomial/Gamma mixture, with a common
sample-total anchor of exactly zero expectation. -/
theorem near_one_hybrid_polynomial_mean {Ω ι : Type*} [MeasurableSpace Ω] [Fintype ι]
    {μ : Measure Ω} [IsProbabilityMeasure μ]
    (Y N : ι→Ω→ℕ) (pilotLam lam : ι→ℝ≥0)
    (hY : ∀i,MeasurePreserving (Y i) μ (poissonMeasure (pilotLam i)))
    (hN : ∀i,MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hind : ∀i,IndepFun (Y i) (N i) μ)
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    {n t beta omega T q repair : ℝ} (hn : 0<n) (ht : 0<t)
    (p : ι→ℝ) (hp : ∑i,p i=1) (hlam : ∀i,(lam i:ℝ)=n*p i)
    (P : ℝ[X]) (d : ℕ) (hd : P.natDegree≤d) (hd1 : 1≤d) :
    Integrable (nearOneHybridStatistic N Y n t beta omega T q repair d ((P-C (t^beta)*X).coeff)) μ ∧
      (∫w,nearOneHybridStatistic N Y n t beta omega T q repair d ((P-C (t^beta)*X).coeff) w ∂μ)=
        repair+∑i,(poissonLowerMass (pilotLam i) T*P.eval (p i)+
          (1-poissonLowerMass (pilotLam i) T)*omega*analyticMean (lam i) (1+beta)/n^(1+beta)) := by
  have hlin : (C (t^beta)*X : ℝ[X]).natDegree≤d :=
    (show (C (t^beta)*X : ℝ[X]).natDegree≤1 by compute_degree).trans hd1
  have hres : (P-C (t^beta)*X).natDegree≤d :=
    (Polynomial.natDegree_sub_le _ _).trans (max_le hd hlin)
  have hh := near_one_hybrid_mean Y N pilotLam lam hY hN hind hpair hn ht p hp hlam d ((P-C (t^beta)*X).coeff)
    (beta:=beta) (omega:=omega) (T:=T) (q:=q) (repair:=repair)
  rw [polynomialOfCoefficients_eq_of_natDegree _ hres] at hh
  refine ⟨hh.1,hh.2.trans ?_⟩
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  simp only [Polynomial.eval_sub,Polynomial.eval_mul,Polynomial.eval_C,Polynomial.eval_X]
  ring

/-- Finite aggregation preserves the same selected local/tail and Gamma
mean errors without a dimension-dependent multiplicative loss. -/
theorem hybrid_mixture_mean_error {ι : Type*} [Fintype ι]
    (s Q G target weight : ι→ℝ) {repair A B C : ℝ}
    (hs0 : ∀i,0≤s i) (hs1 : ∀i,s i≤1)
    (hQ : ∀i,s i*|Q i-target i|≤A+B*weight i)
    (hG : ∀i,(1-s i)*|G i-target i|≤C*weight i) :
    |repair+∑i,(s i*Q i+(1-s i)*G i)-∑i,target i|≤
      |repair|+(Fintype.card ι:ℝ)*A+(B+C)*(∑i,weight i) := by
  have hcoord (i) : |s i*Q i+(1-s i)*G i-target i|≤A+(B+C)*weight i := by
    rw [show s i*Q i+(1-s i)*G i-target i=s i*(Q i-target i)+(1-s i)*(G i-target i) by ring]
    apply (abs_add_le _ _).trans
    rw [abs_mul,abs_mul,abs_of_nonneg (hs0 i),abs_of_nonneg (sub_nonneg.mpr (hs1 i))]
    nlinarith only [hQ i,hG i]
  have hid : repair+∑i,(s i*Q i+(1-s i)*G i)-∑i,target i=
      repair+∑i,(s i*Q i+(1-s i)*G i-target i) := by rw [Finset.sum_sub_distrib];ring
  rw [hid]
  apply (abs_add_le _ _).trans
  have hh := (Finset.abs_sum_le_sum_abs (s:=Finset.univ) (fun i => s i*Q i+(1-s i)*G i-target i)).trans
    (Finset.sum_le_sum (fun i _ => hcoord i))
  have he : (∑i,(A+(B+C)*weight i))=(Fintype.card ι:ℝ)*A+(B+C)*(∑i,weight i) := by
    rw [Finset.sum_add_distrib,←Finset.mul_sum]
    simp only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul]
  rw [he] at hh
  linarith only [hh]

end Renyi
