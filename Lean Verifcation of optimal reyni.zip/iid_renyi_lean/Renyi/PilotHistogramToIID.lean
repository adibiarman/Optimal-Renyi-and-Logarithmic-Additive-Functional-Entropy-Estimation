import Renyi.PoissonKernelToIID
import Renyi.PoissonPilotFlagging
import Renyi.HighOrderNorm

/-! Concrete pilot-Poisson procedures implemented by randomized fixed iid samples. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- Random flagging and the histogram statistic are internal randomization;
the procedure never uses the unknown probability vector. -/
def pilotHistogramOutputKernel {k:ℕ} (cp:ℝ≥0) (G:PilotHistogram k→ℝ)
    (x:PoissonMarkedSample (Fin k)) : PMF ℝ :=
  (pilotFlagRecordKernel cp x).map (fun z => G (markHistogram z.2))

/-- The implemented output has exactly the concrete independent-histogram law. -/
theorem pilotHistogramOutputKernel_law {k:ℕ} (n cp:ℝ≥0) (p:Simplex k)
    (G:PilotHistogram k→ℝ) :
    (poissonMarkedSamplePMF ((1+cp)*n) (simplexNN p) (simplexNN_sum p)).bind
      (pilotHistogramOutputKernel cp G)=(pilotHistogramPMF n cp p).map G := by
  change (poissonMarkedSamplePMF ((1+cp)*n) (simplexNN p) (simplexNN_sum p)).bind
    (fun x => (pilotFlagRecordKernel cp x).map (fun z => G (markHistogram z.2)))=_
  rw [←PMF.map_bind]
  have hh := congrArg (fun q:PMF (PilotHistogram k) => q.map G)
    (poisson_pilot_histogram_law n cp p)
  simpa only [PMF.map_comp,Function.comp_def] using hh

/-- A risk statement on the actual independent histograms gives an iid estimator. -/
theorem achievable_of_pilotHistogram_error {k:ℕ} (n cp:ℝ≥0)
    (alpha eps delta:ℝ) (G:PilotHistogram k→ℝ)
    (herror:∀p:Simplex k,(pilotHistogramPMF n cp p).toMeasure.real
      {h | eps < |G h-entropy p alpha|}≤delta)
    (hbudget:delta+Real.exp (-(((1+cp)*n:ℝ≥0):ℝ)/3)≤1/3) :
    Achievable k ⌈2*(((1+cp)*n:ℝ≥0):ℝ)⌉₊ alpha eps := by
  apply achievable_of_poisson_kernel_error_ceil_twice ((1+cp)*n) alpha eps delta
    (pilotHistogramOutputKernel cp G) _ hbudget
  intro p
  rw [pilotHistogramOutputKernel_law]
  have hB:MeasurableSet {z:ℝ | eps < |z-entropy p alpha|} :=
    measurableSet_lt measurable_const (by fun_prop)
  have hm := PMF.toMeasure_map_apply G (pilotHistogramPMF n cp p) _
    (measurable_of_countable G) hB
  simpa only [Measure.real,hm,Set.preimage_setOf_eq] using herror p

/-- Exact logarithmic conversion of the asymmetric power-sum band. -/
theorem pilotHistogram_entropy_error_subset {k:ℕ} {alpha:ℝ} (halpha:1<alpha)
    (eps:ℝ) (p:Simplex k) (F:PilotHistogram k→ℝ) :
    {h | eps < |(entropyFromPower (alpha-1) (F h)-eps)-entropy p alpha|} ⊆
      {h | F h<Real.exp (-2*eps*(alpha-1))*powerSum p alpha ∨ powerSum p alpha<F h} := by
  intro h hh
  by_contra hbad
  have hlo:Real.exp (-2*eps*(alpha-1))*powerSum p alpha≤F h :=
    le_of_not_gt (fun hz => hbad (Or.inl hz))
  have hhi:F h≤powerSum p alpha := le_of_not_gt (fun hz => hbad (Or.inr hz))
  have hgood := entropy_of_power_band (sub_pos.mpr halpha) (simplex_powerSum_pos p alpha) hlo hhi
  exact (not_lt_of_ge hgood) hh

/-- Concrete iid achievability from a proved power-sum band for an explicit
statistic of the independent Poisson main and pilot histograms. -/
theorem achievable_of_pilotHistogram_band {k:ℕ} (n cp:ℝ≥0)
    {alpha:ℝ} (halpha:1<alpha) (eps delta:ℝ) (F:PilotHistogram k→ℝ)
    (hband:∀p:Simplex k,(pilotHistogramPMF n cp p).toMeasure.real
      {h | F h<Real.exp (-2*eps*(alpha-1))*powerSum p alpha ∨ powerSum p alpha<F h}≤delta)
    (hbudget:delta+Real.exp (-(((1+cp)*n:ℝ≥0):ℝ)/3)≤1/3) :
    Achievable k ⌈2*(((1+cp)*n:ℝ≥0):ℝ)⌉₊ alpha eps := by
  apply achievable_of_pilotHistogram_error n cp alpha eps delta
    (fun h => entropyFromPower (alpha-1) (F h)-eps) _ hbudget
  intro p
  exact (measureReal_mono (μ:=(pilotHistogramPMF n cp p).toMeasure)
    (pilotHistogram_entropy_error_subset halpha eps p F)).trans (hband p)

/-- A quarter failure budget and a constant total mean suffice for the iid risk. -/
theorem pilotHistogram_quarter_budget {b:ℝ} (hb:3*Real.log 12≤b) :
    (1:ℝ)/4+Real.exp (-b/3)≤1/3 := by
  have hexp:Real.exp (-b/3)≤1/12 := by
    calc
      Real.exp (-b/3)≤Real.exp (-Real.log 12) := Real.exp_le_exp.mpr (by linarith)
      _ = 1/12 := by rw [Real.exp_neg,Real.exp_log (by norm_num : (0:ℝ)<12)]; norm_num
  linarith

/-- The exact fixed-sample implementation and its linear Poisson budget. -/
theorem iid_upper_of_pilotHistogram_band {k:ℕ} (n cp:ℝ≥0)
    {alpha:ℝ} (halpha:1<alpha) (eps:ℝ) (F:PilotHistogram k→ℝ)
    (hband:∀p:Simplex k,(pilotHistogramPMF n cp p).toMeasure.real
      {h | F h<Real.exp (-2*eps*(alpha-1))*powerSum p alpha ∨ powerSum p alpha<F h}≤1/4)
    (hmean:3*Real.log 12≤(((1+cp)*n:ℝ≥0):ℝ))
    (hone:1≤(((1+cp)*n:ℝ≥0):ℝ)) :
    ∃m:ℕ,(m:ℝ)≤3*(1+(cp:ℝ))*(n:ℝ) ∧ Achievable k m alpha eps := by
  refine ⟨_,?_,achievable_of_pilotHistogram_band n cp halpha eps (1/4) F hband
    (pilotHistogram_quarter_budget hmean)⟩
  simpa only [NNReal.coe_mul,NNReal.coe_add,NNReal.coe_one,mul_assoc] using
    poisson_fixed_sample_size_le ((1+cp)*n) hone

end Renyi
