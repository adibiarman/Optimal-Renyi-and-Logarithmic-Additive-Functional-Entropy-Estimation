import Renyi.SimplexEndpointMarginNearTwo

/-! Actual capacity calibration of the summed two-arm margin below order two. -/
noncomputable section
open scoped BigOperators
namespace Renyi

def nearTwoEndpointConstant (eps lambda : ℝ) : ℝ :=
  min lambda 1 * Real.exp (-(2 * eps + 3)) / 2

lemma nearTwoEndpointConstant_pos {eps lambda : ℝ} (hlambda : 0 < lambda) :
    0 < nearTwoEndpointConstant eps lambda := by
  unfold nearTwoEndpointConstant
  positivity

lemma nearTwoEndpointConstant_le_one {eps lambda : ℝ} (heps : 0 ≤ eps) :
    nearTwoEndpointConstant eps lambda ≤ 1 := by
  have he := Real.exp_le_one_iff.mpr (show -(2 * eps + 3) ≤ 0 by linarith)
  have hm := mul_le_mul_of_nonneg_right (min_le_right lambda 1) (Real.exp_pos (-(2 * eps + 3))).le
  unfold nearTwoEndpointConstant
  nlinarith only [he, hm]

lemma near_two_capacity_geometric_lower {beta a theta eps lambda z : ℝ}
    (hbeta : (1 : ℝ) / 2 ≤ beta) (hbeta1 : beta < 1) (ha : 0 < a)
    (htheta : 0 < theta) (hlambda : 0 < lambda) (hz : 0 < z) (hz1 : z ≤ 1)
    (hzlo : Real.exp (-(2 * eps + 2)) ≤ z)
    (hcap : lambda * (beta * (1 - beta)) * z ^ (1 / (beta * (1 - beta))) ≤ a * theta) :
    nearTwoEndpointConstant eps lambda * a ^ beta ≤
      a ^ ((beta + 1) / 2) * theta ^ ((1 - beta) / 2) := by
  have hb : 0 < beta := by linarith
  have hd : 0 < 1 - beta := sub_pos.mpr hbeta1
  have hh : 0 < beta * (1 - beta) := mul_pos hb hd
  have hq : 0 ≤ (1 - beta) / 2 := by linarith
  have hq1 : (1 - beta) / 2 ≤ 1 := by linarith
  have hlambdaPow : min lambda 1 ≤ lambda ^ ((1 - beta) / 2) := by
    by_cases hl : lambda ≤ 1
    · exact (min_le_left lambda 1).trans (Real.self_le_rpow_of_le_one hlambda.le hl hq1)
    · exact (min_le_right lambda 1).trans
        (Real.one_le_rpow (le_of_not_ge hl) hq)
  have hbetaPow : (1 : ℝ) / 2 ≤ beta ^ ((1 - beta) / 2) :=
    hbeta.trans (Real.self_le_rpow_of_le_one hb.le hbeta1.le hq1)
  have hdeltaPow : Real.exp (-1 : ℝ) ≤ (1 - beta) ^ ((1 - beta) / 2) := by
    exact (endpoint_self_power_lower hd).trans
      (Real.rpow_le_rpow_of_exponent_ge hd (by linarith : 1 - beta ≤ 1)
        (by linarith : (1 - beta) / 2 ≤ 1 - beta))
  have hzexponent : 1 / (2 * beta) ≤ 1 := (div_le_one (by positivity : 0 < 2 * beta)).mpr (by linarith)
  have hzPow : Real.exp (-(2 * eps + 2)) ≤ z ^ (1 / (2 * beta)) :=
    hzlo.trans (Real.self_le_rpow_of_le_one hz.le hz1 hzexponent)
  have hid : (lambda * (beta * (1 - beta)) * z ^ (1 / (beta * (1 - beta)))) ^ ((1 - beta) / 2) =
      lambda ^ ((1 - beta) / 2) * beta ^ ((1 - beta) / 2) *
        (1 - beta) ^ ((1 - beta) / 2) * z ^ (1 / (2 * beta)) := by
    apply Real.log_injOn_pos (by apply Set.mem_Ioi.mpr; positivity)
      (by apply Set.mem_Ioi.mpr; positivity)
    simp (disch := positivity) only [Real.log_rpow, Real.log_mul]
    field_simp
    ring
  have hprod := mul_le_mul
    (mul_le_mul (mul_le_mul hlambdaPow hbetaPow (by norm_num : (0 : ℝ) ≤ 1 / 2)
      (Real.rpow_nonneg hlambda.le _)) hdeltaPow (Real.exp_pos (-1)).le (by positivity))
    hzPow (Real.exp_pos (-(2 * eps + 2))).le (by positivity)
  have heq : (min lambda 1 * (1 / 2) * Real.exp (-1)) * Real.exp (-(2 * eps + 2)) =
      nearTwoEndpointConstant eps lambda := by
    unfold nearTwoEndpointConstant
    calc
      _ = min lambda 1 * (Real.exp (-1) * Real.exp (-(2 * eps + 2))) / 2 := by ring
      _ = _ := by rw [← Real.exp_add]; congr 2; ring
  rw [heq, ← hid] at hprod
  have hcapPow := Real.rpow_le_rpow (by positivity) hcap hq
  have hgeom : a ^ beta * (a * theta) ^ ((1 - beta) / 2) =
      a ^ ((beta + 1) / 2) * theta ^ ((1 - beta) / 2) := by
    apply Real.log_injOn_pos (by apply Set.mem_Ioi.mpr; positivity)
      (by apply Set.mem_Ioi.mpr; positivity)
    simp (disch := positivity) only [Real.log_rpow, Real.log_mul]
    ring
  have hm := mul_le_mul_of_nonneg_left (hprod.trans hcapPow) (Real.rpow_nonneg ha.le beta)
  rw [hgeom] at hm
  simpa only [mul_comm (a ^ beta)] using hm

/-- The actual capacity, together with the simplex constraint, pays a fixed multiple of a^beta. -/
theorem simplex_truncated_endpoint_margin_near_two {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {beta a theta eps lambda z : ℝ} (hbeta : (1 : ℝ) / 2 ≤ beta) (hbeta1 : beta < 1)
    (heps : 0 ≤ eps) (ha : 0 < a) (htheta : 0 < theta) (hlambda : 0 < lambda)
    (hz : 0 < z) (hz1 : z ≤ 1) (hzlo : Real.exp (-(2 * eps + 2)) ≤ z)
    (hcap : lambda * (beta * (1 - beta)) * z ^ (1 / (beta * (1 - beta))) ≤ a * theta)
    (hcut : a ≤ (1 : ℝ) / (2 * k)) :
    nearTwoEndpointConstant eps lambda / 2 * a ^ beta ≤
      ∑ i, if a ≤ p.mass i then
        p.mass i ^ (1 + beta) * min (a / p.mass i + theta * p.mass i) 1 else 0 := by
  have hgeom := near_two_capacity_geometric_lower hbeta hbeta1 ha htheta hlambda hz hz1 hzlo hcap
  have hc := (nearTwoEndpointConstant_pos (eps := eps) hlambda).le
  have hc1 := nearTwoEndpointConstant_le_one (lambda := lambda) heps
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hp := Real.rpow_le_rpow ha.le hcut (show 0 ≤ beta by linarith)
  have ht : nearTwoEndpointConstant eps lambda * a ^ beta ≤ ((1 : ℝ) / (2 * k)) ^ beta :=
    (mul_le_of_le_one_left (Real.rpow_nonneg ha.le beta) hc1).trans hp
  have hmin := le_min hgeom ht
  have hsum := simplex_two_arm_endpoint_margin hk p (by linarith : 0 ≤ beta) hbeta1.le ha htheta hcut
  nlinarith only [hmin, hsum]

end Renyi
