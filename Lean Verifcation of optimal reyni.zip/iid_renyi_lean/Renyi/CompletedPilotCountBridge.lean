import Renyi.CompletedPilotComparison
import Renyi.PilotCenteredCounts

/-! Actual factorial polynomial, frozen-pilot expectation, and exact joint count-noise bridge. -/
noncomputable section
open scoped BigOperators NNReal
open Polynomial MeasureTheory ProbabilityTheory
namespace Renyi
set_option maxHeartbeats 800000
variable {ι Ω : Type*} [Fintype ι] [MeasurableSpace Ω] {μ : Measure Ω}

def polynomialCountCoordinate (Q : ℝ[X]) (d : ℕ) (n : ℝ) (Counts : ι→Ω→ℕ) : ι→Ω→ℝ :=
  fun i w => factorialStatistic d (fun r => Q.coeff r/n^r) (Counts i w)

omit [Fintype ι] in
lemma polynomial_count_coordinate_mean (Q : ℝ[X]) {d : ℕ} (hd : Q.natDegree≤d)
    (n : ℝ) (hn : n≠0) (p : ι→ℝ) (Counts : ι→Ω→ℕ) (lam : ι→ℝ≥0)
    (hCounts : ∀i,MeasurePreserving (Counts i) μ (poissonMeasure (lam i)))
    (hlam : ∀i,(lam i:ℝ)=n*p i) (i : ι) :
    (∫w,polynomialCountCoordinate Q d n Counts i w ∂μ)=Q.eval (p i) := by
  have hcomp := (hCounts i).hasLaw.integral_comp
    (measurable_of_countable (factorialStatistic d (fun r => Q.coeff r/n^r))).aestronglyMeasurable
  change (∫w,polynomialCountCoordinate Q d n Counts i w ∂μ)=_ at hcomp
  rw [hcomp,poisson_scaled_polynomial_integral (lam i) d Q.coeff n (p i) hn (hlam i)]
  rw [show polynomialOfCoefficients d Q.coeff=Q from
    (Q.as_sum_range_C_mul_X_pow' (lt_of_le_of_lt hd (Nat.lt_succ_self d))).symm]

/-- Freezing any pilot vector gives exactly the selected polynomial values. -/
theorem pilot_selected_actual_polynomial_mean [IsFiniteMeasure μ] (Q : ℝ[X]) {d : ℕ} (hd : Q.natDegree≤d)
    (n : ℝ) (hn : n≠0) (p : ι→ℝ) (Counts : ι→Ω→ℕ) (lam : ι→ℝ≥0)
    (hCounts : ∀i,MeasurePreserving (Counts i) μ (poissonMeasure (lam i)))
    (hlam : ∀i,(lam i:ℝ)=n*p i) (y : ι→ℕ) (T : ℝ) :
    (∫w,pilotSelectedCountEstimator Counts y T d Q.coeff n w ∂μ)=
      ∑i,if (y i:ℝ)≤T then Q.eval (p i) else 0 := by
  have hF (i:ι) : Integrable (fun w => if (y i:ℝ)≤T then
      polynomialCountCoordinate Q d n Counts i w else 0) μ := by
    split_ifs
    · exact (countPolynomial_coordinate_memLp Counts lam hCounts d Q.coeff n i).integrable one_le_two
    · exact integrable_zero _ _ _
  change (∫w,∑i,if (y i:ℝ)≤T then polynomialCountCoordinate Q d n Counts i w else 0 ∂μ)=_
  rw [integral_finset_sum Finset.univ (fun i _ => hF i)]
  apply Finset.sum_congr rfl
  intro i _
  split_ifs
  · exact polynomial_count_coordinate_mean Q hd n hn p Counts lam hCounts hlam i
  · exact integral_zero _ _

/-- The source's averaged conditional variance is the variance of the same
centered polynomial term appearing in the actual hybrid comparison. -/
theorem pilot_centered_polynomial_moments_actual [IsProbabilityMeasure μ]
    (Q : ℝ[X]) {d : ℕ} (hd : Q.natDegree≤d) (n : ℝ) (hn : n≠0) (p : ι→ℝ)
    (Y Counts : ι→Ω→ℕ) (pilotLam lam : ι→ℝ≥0)
    (hY : ∀i,MeasurePreserving (Y i) μ (poissonMeasure (pilotLam i)))
    (hCounts : ∀i,MeasurePreserving (Counts i) μ (poissonMeasure (lam i)))
    (hind : ∀i,IndepFun (Y i) (Counts i) μ)
    (hpair : Pairwise (fun i j => IndepFun (fun w => (Y i w,Counts i w)) (fun w => (Y j w,Counts j w)) μ))
    (hlam : ∀i,(lam i:ℝ)=n*p i) (alpha cp B : ℝ) :
    let Z := pilotCenteredPolynomial (fun i => Q.eval (p i))
      (polynomialCountCoordinate Q d n Counts) Y alpha cp B
    MemLp Z 2 μ ∧ (∫w,Z w ∂μ)=0 ∧
      variance Z μ=pilotAveragedCountVariance Counts Y (cp*B*alpha) d Q.coeff n μ μ := by
  let f : ℕ→ℝ := factorialStatistic d (fun r => Q.coeff r/n^r)
  have hpoly : polynomialOfCoefficients d Q.coeff=Q :=
    (Q.as_sum_range_C_mul_X_pow' (lt_of_le_of_lt hd (Nat.lt_succ_self d))).symm
  have hmean (i:ι) : (∫j,f j ∂poissonMeasure (lam i))=Q.eval (p i) := by
    dsimp [f]
    rw [poisson_scaled_polynomial_integral (lam i) d Q.coeff n (p i) hn (hlam i),hpoly]
  have hm := pilot_centered_sum_moments Y Counts pilotLam lam hY hCounts hind hpair
    (cp*B*alpha) (fun _ => f) (fun i => poisson_polynomial_memLp (lam i) d _)
  have hid : (fun w => ∑i,pilotCenteredCoordinate (Y i) (Counts i) (cp*B*alpha) f (lam i) w)=
      pilotCenteredPolynomial (fun i => Q.eval (p i)) (polynomialCountCoordinate Q d n Counts) Y alpha cp B := by
    funext w
    unfold pilotCenteredCoordinate pilotCenteredPolynomial polynomialCountCoordinate
    simp_rw [hmean]
    rfl
  change MemLp (fun w => ∑i,pilotCenteredCoordinate (Y i) (Counts i) (cp*B*alpha) f (lam i) w) 2 μ ∧ _ at hm
  rw [hid] at hm
  refine ⟨hm.1,hm.2.1,hm.2.2.trans ?_⟩
  have hpairCounts : Pairwise (fun i j => IndepFun (Counts i) (Counts j) μ) := by
    intro i j hij
    exact (hpair hij).comp measurable_snd measurable_snd
  exact (pilot_averaged_count_variance Counts lam hCounts hpairCounts Y pilotLam hY
    (cp*B*alpha) d Q.coeff n).symm

/-- Pointwise frozen-pilot centering agrees with the joint centered term. -/
theorem pilot_centered_polynomial_sub_mean [IsFiniteMeasure μ] (Q : ℝ[X]) {d : ℕ} (hd : Q.natDegree≤d)
    (n : ℝ) (hn : n≠0) (p : ι→ℝ) (Y Counts : ι→Ω→ℕ) (lam : ι→ℝ≥0)
    (hCounts : ∀i,MeasurePreserving (Counts i) μ (poissonMeasure (lam i)))
    (hlam : ∀i,(lam i:ℝ)=n*p i) (alpha cp B : ℝ) (w : Ω) :
    pilotCenteredPolynomial (fun i => Q.eval (p i)) (polynomialCountCoordinate Q d n Counts) Y alpha cp B w=
      pilotSelectedCountEstimator Counts (fun i => Y i w) (cp*B*alpha) d Q.coeff n w-
        (∫v,pilotSelectedCountEstimator Counts (fun i => Y i w) (cp*B*alpha) d Q.coeff n v ∂μ) := by
  rw [pilot_selected_actual_polynomial_mean Q hd n hn p Counts lam hCounts hlam]
  unfold pilotCenteredPolynomial pilotSelectedCountEstimator polynomialCountCoordinate
  rw [←Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro i _
  split_ifs <;> simp

end Renyi
