import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Algebra.Polynomial.Basic
import Mathlib.Tactic

/-! # Absolute coefficient sums of actual polynomials -/

noncomputable section
open scoped BigOperators
open Polynomial
namespace Renyi

def coefficientMass (p : ℝ[X]) : ℝ := p.sum (fun _ a => |a|)

theorem coefficientMass_nonneg (p : ℝ[X]) : 0 ≤ coefficientMass p :=
  Finset.sum_nonneg (fun _ _ => abs_nonneg _)

@[simp] theorem coefficientMass_zero : coefficientMass (0 : ℝ[X]) = 0 := by
  simp [coefficientMass]

@[simp] theorem coefficientMass_monomial (n : ℕ) (a : ℝ) :
    coefficientMass (monomial n a) = |a| := by
  simp [coefficientMass]

@[simp] theorem coefficientMass_C (a : ℝ) : coefficientMass (C a) = |a| := by
  simp [coefficientMass]

@[simp] theorem coefficientMass_one : coefficientMass (1 : ℝ[X]) = 1 := by
  simpa using coefficientMass_C 1

@[simp] theorem coefficientMass_X : coefficientMass (X : ℝ[X]) = 1 := by
  simp [coefficientMass]

theorem coefficientMass_add_le (p q : ℝ[X]) :
    coefficientMass (p+q) ≤ coefficientMass p + coefficientMass q := by
  unfold coefficientMass
  rw [sum_eq_of_subset _ (by simp) (support_add : (p+q).support ⊆ _),
    sum_eq_of_subset _ (by simp) (Finset.subset_union_left : p.support ⊆ p.support ∪ q.support),
    sum_eq_of_subset _ (by simp) (Finset.subset_union_right : q.support ⊆ p.support ∪ q.support),
    ← Finset.sum_add_distrib]
  exact Finset.sum_le_sum (fun _ _ => by simpa using abs_add_le _ _)

@[simp] theorem coefficientMass_neg (p : ℝ[X]) : coefficientMass (-p) = coefficientMass p := by
  simp [coefficientMass, Polynomial.sum_def]

theorem coefficientMass_sub_le (p q : ℝ[X]) :
    coefficientMass (p-q) ≤ coefficientMass p + coefficientMass q := by
  simpa [sub_eq_add_neg] using coefficientMass_add_le p (-q)

theorem coefficientMass_sum_le {ι : Type*} (s : Finset ι) (p : ι → ℝ[X]) :
    coefficientMass (∑ i ∈ s, p i) ≤ ∑ i ∈ s, coefficientMass (p i) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
    simp only [Finset.sum_insert hi]
    exact (coefficientMass_add_le _ _).trans (add_le_add_left ih _)

theorem coefficientMass_mul_le (p q : ℝ[X]) :
    coefficientMass (p*q) ≤ coefficientMass p * coefficientMass q := by
  calc
    _ = coefficientMass (∑ i ∈ p.support, ∑ j ∈ q.support,
        monomial (i+j) (p.coeff i * q.coeff j)) := by
      exact congrArg coefficientMass (Polynomial.mul_eq_sum_sum (p := p) (q := q))
    _ ≤ ∑ i ∈ p.support, coefficientMass (∑ j ∈ q.support,
        monomial (i+j) (p.coeff i * q.coeff j)) := coefficientMass_sum_le _ _
    _ ≤ ∑ i ∈ p.support, ∑ j ∈ q.support,
        coefficientMass (monomial (i+j) (p.coeff i * q.coeff j)) :=
      Finset.sum_le_sum (fun _ _ => coefficientMass_sum_le _ _)
    _ = coefficientMass p * coefficientMass q := by
      simp only [coefficientMass_monomial, abs_mul]
      simp only [coefficientMass, Polynomial.sum_def, Finset.sum_mul, Finset.mul_sum]
      exact Finset.sum_comm

theorem coefficientMass_pow_le (p : ℝ[X]) (n : ℕ) :
    coefficientMass (p^n) ≤ coefficientMass p ^ n := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [pow_succ, pow_succ]
    exact (coefficientMass_mul_le _ _).trans
      (mul_le_mul_of_nonneg_right ih (coefficientMass_nonneg p))

theorem coefficientMass_C_mul (a : ℝ) (p : ℝ[X]) :
    coefficientMass (C a * p) = |a| * coefficientMass p := by
  rw [← smul_eq_C_mul]
  change (a • p).sum (fun _ a => |a|) = _
  rw [Polynomial.sum_smul_index' _ _ _ (by simp)]
  simp [abs_mul, Polynomial.sum_def, coefficientMass, Finset.mul_sum]

theorem abs_coeff_le_coefficientMass (p : ℝ[X]) (j : ℕ) :
    |p.coeff j| ≤ coefficientMass p := by
  by_cases hj : j ∈ p.support
  · change |p.coeff j| ≤ ∑ n ∈ p.support, |p.coeff n|
    exact Finset.single_le_sum (fun (i : ℕ) (_hi : i ∈ p.support) => abs_nonneg (p.coeff i)) hj
  · simp only [notMem_support_iff.mp hj, abs_zero]
    exact coefficientMass_nonneg p

end Renyi
