import Renyi.CompletedPowerSumLower

/-! Cutoff bookkeeping for the complete corrected lower bias transfer. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- Omitting the below-cutoff coordinates loses at most k*a^alpha from the
actual forward bonus. -/
theorem forward_bonus_cutoff_loss {k N : ℕ} {a b alpha : ℝ}
    (ha : 0≤a) (_hb : 0<b) (halpha : 0≤alpha) (p : Fin k→ℝ) (hp : ∀ i,0≤p i) :
    (∑ i, (p i)^alpha*min ((N:ℝ)^2*(p i/b)) 1)≤
      (∑ i, if a≤p i then (p i)^alpha*min ((N:ℝ)^2*(p i/b)) 1 else 0)+(k:ℝ)*a^alpha := by
  have hpoint (i : Fin k) : (p i)^alpha*min ((N:ℝ)^2*(p i/b)) 1≤
      (if a≤p i then (p i)^alpha*min ((N:ℝ)^2*(p i/b)) 1 else 0)+a^alpha := by
    by_cases hpa : a≤p i
    · simp only [hpa,ite_true]
      exact le_add_of_nonneg_right (Real.rpow_nonneg ha _)
    · simp only [hpa,ite_false,zero_add]
      exact (mul_le_of_le_one_right (Real.rpow_nonneg (hp i) _) (min_le_right _ _)).trans
        (Real.rpow_le_rpow (hp i) (le_of_lt (lt_of_not_ge hpa)) halpha)
  have hsum := Finset.sum_le_sum (fun (i:Fin k) (_hi:i∈Finset.univ) => hpoint i)
  simpa only [Finset.sum_add_distrib,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] using hsum

/-- A corrected mean retains all three source lower margins once the actual
cutoff loss, damped baseline, and spatial sum have been proved. -/
lemma corrected_lower_margin_transfer {P B Bt F err e kappa u r base kappa0
    cb cg r0 chi : ℝ}
    (hP : 0≤P) (hBt : 0≤Bt) (herr : 0≤err) (he : err≤e)
    (hkappa : 0≤kappa) (hkappa1 : kappa≤1) (hk0 : kappa≤kappa0)
    (hu : 0≤u) (hr0 : 0<r0) (hr : r0≤r) (hr1 : r≤1)
    (hcb : 0<cb) (hcg : 0<cg) (hchi : 0≤chi) (hchi1 : chi≤1)
    (hbase : kappa+cb*kappa*u≤r*base)
    (hmean : base*P+cg*kappa0*Bt≤F+err)
    (hB : B≤Bt+err) :
    let c := min (1/2:ℝ) (min cb (r0*cg))
    kappa*P+c*(e+kappa*u*P+chi*kappa*B)≤r*F+2*e := by
  dsimp only
  let c := min (1/2:ℝ) (min cb (r0*cg))
  have hc : 0≤c := (lt_min (by norm_num) (lt_min hcb (mul_pos hr0 hcg))).le
  have hc2 : c≤1/2 := min_le_left _ _
  have hccb : c≤cb := (min_le_right _ _).trans (min_le_left _ _)
  have hccg : c≤r0*cg := (min_le_right _ _).trans (min_le_right _ _)
  have hrpos : 0≤r := hr0.le.trans hr
  have he0 : 0≤e := herr.trans he
  have hκχ : 0≤chi*kappa := mul_nonneg hchi hkappa
  have hκχ1 : chi*kappa≤1 := by simpa only [one_mul] using (mul_le_mul hchi1 hkappa1 hkappa (by norm_num : (0:ℝ)≤1))
  have hmain := mul_le_mul_of_nonneg_left hmean hrpos
  have hb := mul_le_mul_of_nonneg_right hbase hP
  have hg0 : r0*cg*kappa≤r*cg*kappa0 := by
    have h1 := mul_le_mul_of_nonneg_right hr hcg.le
    exact mul_le_mul h1 hk0 hkappa (mul_nonneg hrpos hcg.le)
  have hg := mul_le_mul_of_nonneg_right hg0 hBt
  have heR := mul_le_of_le_one_left herr hr1
  have hreg := mul_le_mul_of_nonneg_right hccb (mul_nonneg (mul_nonneg hkappa hu) hP)
  have hbonus := mul_le_mul_of_nonneg_right hccg (mul_nonneg hkappa hBt)
  have hbonusχ := mul_le_of_le_one_left (mul_nonneg (mul_nonneg hc hkappa) hBt) hchi1
  have hB' := mul_le_mul_of_nonneg_left hB (mul_nonneg hc hκχ)
  have heC := mul_le_mul_of_nonneg_right hc2 he0
  have heκ := mul_le_mul_of_nonneg_left (mul_le_of_le_one_left herr hκχ1) hc
  have heCerr := (mul_le_mul_of_nonneg_left he hc).trans heC
  change kappa*P+c*(e+kappa*u*P+chi*kappa*B)≤_
  nlinarith only [hmain,hb,hg,heR,hreg,hbonus,hbonusχ,hB',heC,heκ,heCerr,he]

end Renyi
