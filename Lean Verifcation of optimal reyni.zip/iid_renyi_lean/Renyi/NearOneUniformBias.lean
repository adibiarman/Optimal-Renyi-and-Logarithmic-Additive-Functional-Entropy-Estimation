import Renyi.NearOneUniformDegree

/-! Actual localized bias with constants independent of the degree calibration. -/
noncomputable section
namespace Renyi

theorem actual_near_one_bias_degree_uniform {eps cb lambda CL cmin q Q M cw f : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hf : 0≤f) (hf1 : f≤1) :
    ∃ K : ℝ, 0<K ∧ ∀ (cL : ℝ), 0<cL → ∀ (k N : ℕ) (alpha Ch D c s0 p : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) →
      0≤s0 → s0≤1 → 0≤p → p≤upperB k alpha eps D cb CL cL →
      |actualNearOneExpression k N alpha eps Ch D cb lambda CL cL c M cw f s0 p-
        s0*upperOmega k alpha eps Ch cw*p^alpha|≤
          K*(alpha-1)*(upperB k alpha eps D cb CL cL/(N:ℝ)^2)^alpha := by
  obtain ⟨Ca,hCa,ha⟩ := near_one_attenuated_amplitudes_uniform heps hM hcw hcw1
  obtain ⟨lo,hi,hlo,hhi,hratio⟩ := near_one_variable_tangent_compact_degree_uniform heps hcb hlambda
    hCL hcmin hq hQ
  let ML := |Real.log lo|+|Real.log hi|
  let K := nearOneTangentConstant+tangentReplacementConstant ML+
    Ca*(tangentCutoffConstant ML+coupledLocalizationConstant)
  have hML : 0≤ML := add_nonneg (abs_nonneg _) (abs_nonneg _)
  have hK : 0<K := by
    dsimp [K,nearOneTangentConstant,tangentReplacementConstant,tangentCutoffConstant,
      coupledLocalizationConstant]
    positivity
  refine ⟨K,hK,?_⟩
  intro cL hcL k N alpha Ch D c s0 p hk halpha halpha1 hCh hD hc hc1 hNlo hNhi hs0 hs1 hp hpb
  have hbeta : 0<alpha-1 := sub_pos.mpr halpha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order halpha halpha1).2]; exact hbeta
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order halpha halpha1).2]; linarith
  have hL := upperDegree_pos halpha hCL hcL (one_le_rootMultiplier (k:=k) (ε:=eps) halpha hg hg1)
  have hNr : 0<(N:ℝ) := (mul_pos hq hL).trans_le hNlo
  have hN : 0<N := by exact_mod_cast hNr
  have hb := upperB_pos (ε:=eps) hk halpha hg hg1 hD hcb hCL hcL
  have ht : 0<upperB k alpha eps D cb CL cL/(N:ℝ)^2 := div_pos hb (sq_pos_of_pos hNr)
  have hr := hratio cL hcL k alpha Ch D N c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
  have htau : 0<c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1) := by
    have hh := (lt_div_iff₀ ht).mp (hlo.trans_le hr.1)
    simpa only [zero_mul] using hh
  have hlog := log_abs_of_compact hlo hr.1 hr.2
  have hamp := ha k alpha Ch halpha halpha1 hCh
  have hE := upper_reserved_interval (k:=k) halpha hg hg1 heps hCh
  have hEpos : 0<upperE0 k alpha eps Ch := (mul_pos heps hbeta).trans_le hE.1
  have hw : 0≤upperOmega k alpha eps Ch cw := (Real.exp_pos _).le
  have hw1 : upperOmega k alpha eps Ch cw<1 := Real.exp_lt_one_iff.mpr (by nlinarith)
  have h := near_one_expression_bias hN htau hb hbeta.le (by linarith) hlog hf hf1 hw hw1
    hs0 hs1 hCa.le hamp.1 hamp.2 hp hpb
  change |nearOneExpression N _ (alpha-1) f _ _ _ s0 _ p-
    s0*upperOmega k alpha eps Ch cw*p^alpha|≤K*(alpha-1)*_ at ⊢
  simpa only [show 1+(alpha-1)=alpha by ring] using h


end Renyi
