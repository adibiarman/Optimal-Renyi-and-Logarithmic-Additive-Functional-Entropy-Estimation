import Renyi.LowerMassRatio
import Renyi.LowerCalibrationFinal
import Renyi.LowerActiveMass

/-! A uniform positive mass floor from the actual root calibration. -/
noncomputable section
namespace Renyi

/-- The actual root and both geometric dimension bounds imply a uniform
active-principal ratio floor, independently of proximity to an integer. -/
theorem lower_actual_active_ratio_floor {k : ℕ} {α ε s ds dc : ℝ}
    (hk : 0<k) (hα : 3/2≤α) (hε : 0<ε)
    (hs : 0<s) (hs1 : s≤1/2)
    (hγ₀ : 0<fractionalPart α) (hγ₁ : fractionalPart α<1)
    (hnearest : s=fractionalPart α ∨ s=1-fractionalPart α)
    (hx : lowerPriorRootCutoff ε≤rootMultiplier k α ε)
    (hds : 0<ds) (hdc : 0<dc)
    (hdimhi : ds*dc≤α*((Nat.ceil (10*α*(1+Real.log (rootMultiplier k α ε))):ℝ)+1))
    (hdimlo : α*(Nat.ceil (10*α*(1+Real.log (rootMultiplier k α ε))):ℝ)/4≤ds*dc) :
    let x := rootMultiplier k α ε
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
    let bs := (ζ/8)/ds^2
    let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
    let a := θ/((1/100)*L*ac)
    Real.exp (lowerLogSampleConstant ε c/2-4)≤(a/bs)^s/κ := by
  let x := rootMultiplier k α ε
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
  let bs := (ζ/8)/ds^2
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
  let a := θ/((1/100)*L*ac)
  let G := 4-Real.log ((1/100:ℝ)/8)+Real.log ((ds*dc)^2/(L*α^3*(1+Real.log x)))
  have hα1 : 1<α := by linarith
  have hα0 : 0<α := by linarith
  have hslt : s<1 := by linarith
  have hx4 : 4≤x := (le_max_left _ _).trans hx
  have hx1 : 1<x := by linarith
  have hv0 : 0≤v := by
    dsimp [v]
    exact mul_nonneg (div_nonneg (by linarith) hα0.le) (Real.rpow_nonneg (by linarith) _)
  have hc := (lowerPriorCoefficient_bounds hε).1
  have hcon := lower_actual_principal_constraints_with_perturbation hk hα hε hs hs1 hγ₀ hγ₁ hnearest hx hds hdc hdimhi
  change 0<a ∧ a≤bs/2 ∧ 0≤_ ∧ _≤ζ ∧ 0<ζ ∧ ζ≤1/8 ∧ _≤1 at hcon
  have hζ0 : 0<ζ := hcon.2.2.2.2.1
  have hζ1 : ζ≤1 := by linarith [hcon.2.2.2.2.2.1]
  have hbs : 0<bs := by dsimp [bs]; positivity
  have hL : 0<L := (show 0<10*α*(1+Real.log x) by
    have hlog0 := Real.log_pos hx1
    positivity).trans_le (Nat.le_ceil _)
  have hG : 0≤G := lower_ceiling_log_geometry_lower hα1.le hx1.le hds hdc hdimlo
  have hden : 0<1-Real.exp (-ε) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  have hcn : lowerLogSampleConstant ε c≤0 := by
    have hV : 0<lowerVelocityConstant ε c := by unfold lowerVelocityConstant; positivity
    have hMargin : 0<lowerPrincipalMargin ε c := by unfold lowerPrincipalMargin; positivity
    unfold lowerLogSampleConstant
    have hsum : 0≤1020+6/c+lowerPrincipalMargin ε c+4*c/(1-Real.exp (-ε)) := by positivity
    linarith
  have hlog := root_principal_ratio_log hk hα1 hγ₀ hγ₁ hx1 hs hslt hnearest hζ0
    (Real.exp_pos (lowerLogSampleConstant ε c)) (by norm_num : (0:ℝ)<1/100) hL hds hdc
  change Real.log (a/bs)=lowerPrincipalLog s E v ζ (α-1)
    (Real.log (Real.exp (lowerLogSampleConstant ε c))) G at hlog
  rw [Real.log_exp] at hlog
  have heq : Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G)=a/bs := by
    rw [←hlog,Real.exp_log (div_pos hcon.1 hbs)]
  have hh := lower_active_ratio_uniform (E:=E) hs hs1 hv0 hζ0 hζ1 (show 0<α-1 by linarith) hG hcn
  rw [heq] at hh
  exact hh

/-- The actual target parameter dominates a fixed multiple of the distance
to the nearest integer. -/
theorem lower_target_fractional_floor {c s E v : ℝ}
    (hc : 0<c) (hs : 0<s) (hs1 : s≤1/2) (hE : 0<E) (hv : 0≤v) :
    (c/2)*s≤c*(s*(1-s)+v)/(1-Real.exp (-E)) := by
  have hd : 0<1-Real.exp (-E) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  have hd1 : 1-Real.exp (-E)≤1 := by linarith [Real.exp_pos (-E)]
  have hw0 : 0≤s*(1-s)+v := add_nonneg (mul_nonneg hs.le (by linarith)) hv
  have hw : s/2≤s*(1-s)+v := by nlinarith
  have hh := mul_le_mul_of_nonneg_left hw hc.le
  have hdiv : c*(s*(1-s)+v)≤c*(s*(1-s)+v)/(1-Real.exp (-E)) := by
    have hh' := div_le_div_of_nonneg_left (mul_nonneg hc.le hw0) hd hd1
    simpa only [div_one] using hh'
  nlinarith

end Renyi
