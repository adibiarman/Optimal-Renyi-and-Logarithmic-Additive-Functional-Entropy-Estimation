import Renyi.UpperBaseline

/-! Bounded-width calibration of the actual regularized-root parameters. -/

noncomputable section
namespace Renyi

theorem upper_root_Q_bound {k : ℕ} {alpha eps : ℝ} (ha : 1 < alpha)
    (hg : 0 < fractionalPart alpha) (hg1 : fractionalPart alpha < 1) :
    rootQSquared k alpha eps ≤ Real.exp 1 * rootMultiplier k alpha eps *
      (1 + Real.log (rootMultiplier k alpha eps)) := by
  have hx1 := one_le_rootMultiplier (k := k) (ε := eps) ha hg hg1
  have hx : 0 < rootMultiplier k alpha eps := zero_lt_one.trans_le hx1
  have hh := mul_pos hg (sub_pos.mpr hg1)
  have hv := upperV_pos (k := k) (eps := eps) ha hg hg1
  have hs := upper_root_slack (k := k) (ε := eps) ha hg hg1
  have he : Real.exp (1 - upperV k alpha eps /
      (fractionalPart alpha * (1 - fractionalPart alpha)) - upperSigma k alpha eps) ≤
      Real.exp 1 := Real.exp_le_exp.mpr (by
        have := div_nonneg hv.le hh.le
        linarith [hs.1])
  have hl : 0 ≤ 1 + Real.log (rootMultiplier k alpha eps) := by
    have := Real.log_nonneg hx1
    linarith
  have h := mul_le_mul_of_nonneg_left he hl
  rw [← hs.2.2] at h
  have h' := (div_le_iff₀ hx).mp h
  nlinarith [h']

theorem upper_degree_log_lower {alpha CL cL X : ℝ} (ha : 0 ≤ alpha) (hX : 1 ≤ X) :
    alpha * min CL cL * (1 + Real.log X) ≤ (upperDegree alpha CL cL X : ℝ) := by
  have ht := Real.log_nonneg hX
  have h := mul_le_mul_of_nonneg_right (min_le_right CL cL) ht
  have hb : min CL cL * (1 + Real.log X) ≤ CL + cL * Real.log X := by
    nlinarith [min_le_left CL cL]
  have hh := mul_le_mul_of_nonneg_left hb ha
  exact le_trans (by nlinarith [hh]) (upperDegree_ge_exact alpha CL cL X)

/-- A lower bound on the actual Q factor controls the effective count scale. -/
theorem upper_count_scale_of_Q_lower {k : ℕ} {alpha eps D CL cL cq : ℝ}
    (hk : 0 < k) (ha : 1 < alpha) (hg : 0 < fractionalPart alpha)
    (hg1 : fractionalPart alpha < 1) (hD : 0 < D) (hCL : 1 ≤ CL)
    (hcL : 0 < cL) (hcq : 0 < cq)
    (hq : cq * (k : ℝ) ^ (1 / alpha) ≤ rootQSquared k alpha eps) :
    (k : ℝ) / (upperSample k alpha eps D *
      (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)) ≤
      (Real.exp 1 / (cq * min CL cL)) / D := by
  have ha0 : 0 < alpha := by linarith
  have hk0 : 0 < (k : ℝ) := by exact_mod_cast hk
  have hx1 := one_le_rootMultiplier (k := k) (ε := eps) ha hg hg1
  have hx : 0 < rootMultiplier k alpha eps := zero_lt_one.trans_le hx1
  have hL := upperDegree_pos ha hCL hcL hx1
  have hl := upper_degree_log_lower ha0.le hx1 (CL := CL) (cL := cL)
  have hmin : 0 < min CL cL := lt_min (by linarith) hcL
  have hQ := hq.trans (upper_root_Q_bound ha hg hg1)
  have hlog : 0 ≤ 1 + Real.log (rootMultiplier k alpha eps) := by
    have := Real.log_nonneg hx1
    linarith
  have hL' : min CL cL * (1 + Real.log (rootMultiplier k alpha eps)) ≤
      (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) := by
    have hmul := mul_le_mul_of_nonneg_right ha.le (mul_nonneg hmin.le hlog)
    nlinarith
  have hscale : cq * min CL cL * (k : ℝ) ^ (1 / alpha) ≤
      Real.exp 1 * rootMultiplier k alpha eps *
        (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) := by
    have h1 := mul_le_mul_of_nonneg_left hQ hmin.le
    have h2 := mul_le_mul_of_nonneg_left hL' (mul_pos (Real.exp_pos 1) hx).le
    nlinarith
  have hp : 0 < (k : ℝ) ^ (1 - 1 / alpha) := Real.rpow_pos_of_pos hk0 _
  have hpow : (k : ℝ) ^ (1 - 1 / alpha) * (k : ℝ) ^ (1 / alpha) = k := by
    rw [← Real.rpow_add hk0]
    simp
  have hscaled := mul_le_mul_of_nonneg_left hscale hp.le
  have hα := mul_le_mul_of_nonneg_left ha.le
    (show 0 ≤ Real.exp 1 * (k : ℝ) ^ (1 - 1 / alpha) *
      rootMultiplier k alpha eps * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)
      by positivity)
  have hn := upperSample_pos hk ha hg hg1 hD (ε := eps)
  apply (div_le_div_iff₀ (mul_pos hn hL) hD).mpr
  have hid : (k : ℝ) * D * (cq * min CL cL) ≤
      Real.exp 1 * (upperSample k alpha eps D *
        (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)) := by
    have hs' : (k : ℝ) * (cq * min CL cL) ≤
        Real.exp 1 * alpha * (k : ℝ) ^ (1 - 1 / alpha) *
          rootMultiplier k alpha eps * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) := by
      calc
        _ = (k : ℝ) ^ (1 - 1 / alpha) * (cq * min CL cL * (k : ℝ) ^ (1 / alpha)) := by
          calc
            _ = ((k : ℝ) ^ (1 - 1 / alpha) * (k : ℝ) ^ (1 / alpha)) *
                (cq * min CL cL) := congrArg (fun z : ℝ => z * (cq * min CL cL)) hpow.symm
            _ = _ := by ring
        _ ≤ _ := by nlinarith [hscaled, hα]
    have hm := mul_le_mul_of_nonneg_right hs' hD.le
    unfold upperSample
    nlinarith [hm]
  convert (le_div_iff₀ (mul_pos hcq hmin)).mpr hid using 1
  ring

theorem upper_tangent_count_scale {k : ℕ} {alpha eps D cb CL cL N q C : ℝ}
    (hk : 0 < k) (ha : 1 < alpha) (hg : 0 < fractionalPart alpha)
    (hg1 : fractionalPart alpha < 1) (hD : 0 < D) (hcb : 0 ≤ cb)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hq : 0 < q)
    (hN : q * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ≤ N)
    (hcount : (k : ℝ) / (upperSample k alpha eps D *
      (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)) ≤ C / D) :
    (k : ℝ) * (upperB k alpha eps D cb CL cL / N ^ 2) ≤ (cb / q ^ 2 * C) / D := by
  have hn := upperSample_pos hk ha hg hg1 hD (ε := eps)
  have hL := upperDegree_pos ha hCL hcL (one_le_rootMultiplier (k := k) (ε := eps) ha hg hg1)
  have hN0 : 0 < N := lt_of_lt_of_le (mul_pos hq hL) hN
  have hsq : q ^ 2 * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ^ 2 ≤ N ^ 2 := by
    have hh := mul_le_mul hN hN (mul_pos hq hL).le hN0.le
    nlinarith [hh]
  have hfrac : (k : ℝ) * (upperB k alpha eps D cb CL cL / N ^ 2) ≤
      cb / q ^ 2 * ((k : ℝ) / (upperSample k alpha eps D *
        (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ))) := by
    have hden := mul_le_mul_of_nonneg_left hsq hn.le
    have hb := div_le_div_of_nonneg_left
      (by positivity : 0 ≤ (k : ℝ) * cb * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ))
      (by positivity : 0 < upperSample k alpha eps D *
        (q ^ 2 * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ^ 2)) hden
    unfold upperB
    convert hb using 1 <;> field_simp
  have hh := mul_le_mul_of_nonneg_left hcount (div_nonneg hcb (sq_nonneg q))
  exact hfrac.trans (by convert hh using 1; ring)

theorem bounded_width_geometry {alpha eps M : ℝ} (ha : 3 / 2 ≤ alpha)
    (heps : 0 < eps) (hM : 0 < M) (hg : 0 < fractionalPart alpha)
    (hg1 : fractionalPart alpha < 1)
    (hwidth : 2 * eps * (alpha - 1) /
      (fractionalPart alpha * (1 - fractionalPart alpha)) ≤ M) :
    eps / M ≤ fractionalPart alpha * (1 - fractionalPart alpha) ∧
      eps / M ≤ fractionalPart alpha ∧ eps / M ≤ 1 - fractionalPart alpha ∧
      alpha - 1 ≤ M / (8 * eps) := by
  have hd : 0 < 1 - fractionalPart alpha := sub_pos.mpr hg1
  have hh : 0 < fractionalPart alpha * (1 - fractionalPart alpha) := mul_pos hg hd
  have hw := (div_le_iff₀ hh).mp hwidth
  have hquarter : fractionalPart alpha * (1 - fractionalPart alpha) ≤ 1 / 4 := by
    nlinarith [sq_nonneg (fractionalPart alpha - 1 / 2)]
  have he : eps ≤ M * (fractionalPart alpha * (1 - fractionalPart alpha)) := by
    nlinarith
  have hhlo : eps / M ≤ fractionalPart alpha * (1 - fractionalPart alpha) :=
    (div_le_iff₀ hM).mpr (by nlinarith [he])
  refine ⟨hhlo, hhlo.trans ?_, hhlo.trans ?_, ?_⟩
  · nlinarith [sq_nonneg (fractionalPart alpha)]
  · nlinarith [sq_nonneg (1 - fractionalPart alpha)]
  · apply (le_div_iff₀ (by positivity : 0 < 8 * eps)).mpr
    have := mul_le_mul_of_nonneg_left hquarter hM.le
    nlinarith

theorem overlapPsi_bounded_width {gamma s : ℝ} (hs : 0 < s)
    (hg : 0 < gamma) (hg1 : gamma < 1) (hsg : s ≤ gamma) (hsd : s ≤ 1 - gamma) :
    (s ^ (1 + 1 / s)) ^ (2 : ℕ) ≤ overlapPsi gamma ∧ overlapPsi gamma ≤ 1 := by
  have hd : 0 < 1 - gamma := sub_pos.mpr hg1
  have hs1 : s ≤ 1 := hsg.trans hg1.le
  have hpow : 0 ≤ s ^ (1 + 1 / s) := (Real.rpow_pos_of_pos hs _).le
  have hrecg : 1 / gamma ≤ 1 / s := one_div_le_one_div_of_le hs hsg
  have hrecd : 1 / (1 - gamma) ≤ 1 / s := one_div_le_one_div_of_le hs hsd
  have hgexp : 0 ≤ 1 + 1 / gamma := by positivity
  have hdexp : 0 ≤ 1 + 1 / (1 - gamma) := by positivity
  have hlo1 : s ^ (1 + 1 / s) ≤ gamma ^ (1 + 1 / (1 - gamma)) := by
    exact (Real.rpow_le_rpow_of_exponent_ge hs hs1 (by linarith)).trans
      (Real.rpow_le_rpow hs.le hsg hdexp)
  have hlo2 : s ^ (1 + 1 / s) ≤ (1 - gamma) ^ (1 + 1 / gamma) := by
    exact (Real.rpow_le_rpow_of_exponent_ge hs hs1 (by linarith)).trans
      (Real.rpow_le_rpow hs.le hsd hgexp)
  have hhi1 : gamma ^ (1 + 1 / (1 - gamma)) ≤ 1 :=
    Real.rpow_le_one hg.le hg1.le hdexp
  have hhi2 : (1 - gamma) ^ (1 + 1 / gamma) ≤ 1 :=
    Real.rpow_le_one hd.le (by linarith) hgexp
  constructor
  · simpa only [overlapPsi, pow_two] using
      mul_le_mul hlo1 hlo2 hpow (Real.rpow_nonneg hg.le _)
  · simpa only [overlapPsi, one_mul] using
      mul_le_mul hhi1 hhi2 (Real.rpow_nonneg hd.le _) (by norm_num : (0 : ℝ) ≤ 1)

def upperCompactQConstant (eps M : ℝ) : ℝ :=
  ((eps / M) ^ (1 + 1 / (eps / M))) ^ (2 : ℕ) * Real.exp (-M) /
    ((1 + M / (8 * eps)) ^ (2 : ℕ) * (M / (8 * eps)) ^ (2 : ℕ))

theorem upperCompactQConstant_pos {eps M : ℝ} (heps : 0 < eps) (hM : 0 < M) :
    0 < upperCompactQConstant eps M := by
  unfold upperCompactQConstant
  positivity

theorem rootQSquared_factorization {k : ℕ} {alpha eps : ℝ} (hk : 0 < k) :
    rootQSquared k alpha eps =
      (overlapPsi (fractionalPart alpha) /
        (alpha ^ (2 : ℕ) * (alpha - 1) ^ (2 : ℕ)) *
        Real.exp (-(2 * eps * (alpha - 1)) /
          (fractionalPart alpha * (1 - fractionalPart alpha)))) * (k : ℝ) ^ (1 / alpha) := by
  have hk0 : 0 < (k : ℝ) := by exact_mod_cast hk
  unfold rootQSquared
  change overlapPsi (fractionalPart alpha) / (alpha ^ (2 : ℕ) * (alpha - 1) ^ (2 : ℕ)) *
    Real.exp (Real.log k / alpha - (2 * eps * (alpha - 1)) /
      (fractionalPart alpha * (1 - fractionalPart alpha))) = _
  rw [Real.rpow_def_of_pos hk0]
  simp only [mul_assoc, ← Real.exp_add]
  congr 2
  ring

theorem upper_bounded_width_Q {k : ℕ} {alpha eps M : ℝ}
    (hk : 0 < k) (ha : 3 / 2 ≤ alpha) (heps : 0 < eps) (hM : 0 < M)
    (hg : 0 < fractionalPart alpha) (hg1 : fractionalPart alpha < 1)
    (hwidth : 2 * eps * (alpha - 1) /
      (fractionalPart alpha * (1 - fractionalPart alpha)) ≤ M) :
    upperCompactQConstant eps M * (k : ℝ) ^ (1 / alpha) ≤ rootQSquared k alpha eps ∧
      rootQSquared k alpha eps ≤ 4 * (k : ℝ) ^ (1 / alpha) := by
  have ha0 : 0 < alpha := by linarith
  have hb : 0 < alpha - 1 := by linarith
  have hh := mul_pos hg (sub_pos.mpr hg1)
  have hs := div_pos heps hM
  have hR : 0 < M / (8 * eps) := by positivity
  obtain ⟨_, hsg, hsd, hbhi⟩ := bounded_width_geometry ha heps hM hg hg1 hwidth
  have hpsi := overlapPsi_bounded_width hs hg hg1 hsg hsd
  have hden : 0 < alpha ^ (2 : ℕ) * (alpha - 1) ^ (2 : ℕ) := by positivity
  have hdenlo : 1 / 4 ≤ alpha ^ (2 : ℕ) * (alpha - 1) ^ (2 : ℕ) := by
    have ha2 : (1 : ℝ) ≤ alpha ^ (2 : ℕ) := by nlinarith
    have hb2 : (1 : ℝ) / 4 ≤ (alpha - 1) ^ (2 : ℕ) := by nlinarith
    nlinarith
  have hdenhi : alpha ^ (2 : ℕ) * (alpha - 1) ^ (2 : ℕ) ≤
      (1 + M / (8 * eps)) ^ (2 : ℕ) * (M / (8 * eps)) ^ (2 : ℕ) := by
    apply mul_le_mul
    · nlinarith
    · nlinarith
    · positivity
    · positivity
  have hexplo : Real.exp (-M) ≤ Real.exp (-(2 * eps * (alpha - 1)) /
      (fractionalPart alpha * (1 - fractionalPart alpha))) := by
    apply Real.exp_le_exp.mpr
    simpa only [neg_div] using neg_le_neg hwidth
  have hexphi : Real.exp (-(2 * eps * (alpha - 1)) /
      (fractionalPart alpha * (1 - fractionalPart alpha))) ≤ 1 := by
    apply Real.exp_le_one_iff.mpr
    exact div_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr (by positivity)) hh.le
  have hp := overlapPsi_pos hg hg1
  have hp0 : 0 ≤ ((eps / M) ^ (1 + 1 / (eps / M))) ^ (2 : ℕ) := sq_nonneg _
  have hfactorlo : upperCompactQConstant eps M ≤
      overlapPsi (fractionalPart alpha) / (alpha ^ (2 : ℕ) * (alpha - 1) ^ (2 : ℕ)) *
      Real.exp (-(2 * eps * (alpha - 1)) /
        (fractionalPart alpha * (1 - fractionalPart alpha))) := by
    have h1 := mul_le_mul hpsi.1 hexplo (Real.exp_pos (-M)).le hp.le
    have h2 := div_le_div_of_nonneg_left (mul_nonneg hp0 (Real.exp_pos (-M)).le) hden hdenhi
    apply h2.trans
    unfold upperCompactQConstant at *
    convert (div_le_div_iff_of_pos_right hden).mpr h1 using 1
    ring
  have hfactorhi : overlapPsi (fractionalPart alpha) /
      (alpha ^ (2 : ℕ) * (alpha - 1) ^ (2 : ℕ)) *
      Real.exp (-(2 * eps * (alpha - 1)) /
        (fractionalPart alpha * (1 - fractionalPart alpha))) ≤ 4 := by
    have h := mul_le_mul hpsi.2 hexphi (Real.exp_pos _).le (by norm_num : (0 : ℝ) ≤ 1)
    have hnum : overlapPsi (fractionalPart alpha) *
        Real.exp (-(2 * eps * (alpha - 1)) /
          (fractionalPart alpha * (1 - fractionalPart alpha))) ≤
        4 * (alpha ^ (2 : ℕ) * (alpha - 1) ^ (2 : ℕ)) := by nlinarith
    convert (div_le_iff₀ hden).mpr hnum using 1
    ring
  rw [rootQSquared_factorization hk]
  have hk0 : 0 ≤ (k : ℝ) ^ (1 / alpha) := Real.rpow_nonneg (Nat.cast_nonneg _) _
  exact ⟨mul_le_mul_of_nonneg_right hfactorlo hk0, mul_le_mul_of_nonneg_right hfactorhi hk0⟩

/-- Complete bounded-width calibration; all constants are uniform in k, alpha, D, and N. -/
theorem upper_bounded_width_uniform {eps M cb CL cL u0 q : ℝ}
    (heps : 0 < eps) (hM : 0 < M) (hcb : 0 ≤ cb) (hCL : 1 ≤ CL)
    (hcL : 0 < cL) (hu0 : 0 < u0) (hq : 0 < q) :
    ∃ cQ C cu : ℝ, 0 < cQ ∧ 0 < C ∧ 0 < cu ∧
      ∀ (k : ℕ) (alpha D N : ℝ), 0 < k → 3 / 2 ≤ alpha →
      0 < fractionalPart alpha → fractionalPart alpha < 1 → 0 < D →
      2 * eps * (alpha - 1) / (fractionalPart alpha * (1 - fractionalPart alpha)) ≤ M →
      q * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ≤ N →
      cQ * (k : ℝ) ^ (1 / alpha) ≤ rootQSquared k alpha eps ∧
      rootQSquared k alpha eps ≤ 4 * (k : ℝ) ^ (1 / alpha) ∧
      (k : ℝ) / (upperSample k alpha eps D *
        (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)) ≤ C / D ∧
      (k : ℝ) * (upperB k alpha eps D cb CL cL / N ^ 2) ≤ C / D ∧
      cu ≤ upperU k alpha eps u0 := by
  let cq := upperCompactQConstant eps M
  let C0 := Real.exp 1 / (cq * min CL cL)
  let C := (1 + cb / q ^ 2) * C0
  have hcq : 0 < cq := upperCompactQConstant_pos heps hM
  have hC0 : 0 < C0 := div_pos (Real.exp_pos _) (mul_pos hcq (lt_min (by linarith) hcL))
  have hcbr : 0 ≤ cb / q ^ 2 := div_nonneg hcb (sq_nonneg q)
  have hC : 0 < C := mul_pos (by linarith) hC0
  refine ⟨cq, C, min (eps / M) u0, hcq, hC, lt_min (div_pos heps hM) hu0, ?_⟩
  intro k alpha D N hk ha hg hg1 hD hwidth hN
  have ha1 : 1 < alpha := by linarith
  have hQ := upper_bounded_width_Q hk ha heps hM hg hg1 hwidth
  have hcount := upper_count_scale_of_Q_lower hk ha1 hg hg1 hD hCL hcL hcq hQ.1
  have ht := upper_tangent_count_scale hk ha1 hg hg1 hD hcb hCL hcL hq hN hcount
  have hC0C : C0 ≤ C := by dsimp [C]; nlinarith
  have hCbC : cb / q ^ 2 * C0 ≤ C := by dsimp [C]; nlinarith
  have hgeo := bounded_width_geometry ha heps hM hg hg1 hwidth
  have hv := upperV_pos (k := k) (eps := eps) ha1 hg hg1
  refine ⟨hQ.1, hQ.2,
    hcount.trans ((div_le_div_iff_of_pos_right hD).mpr hC0C),
    ht.trans ((div_le_div_iff_of_pos_right hD).mpr hCbC), ?_⟩
  unfold upperU
  exact min_le_min (by linarith [hgeo.1]) le_rfl

end Renyi
