import Renyi.NearOne
import Renyi.UpperBaseline

/-! The actual scalar rescaling used by the common estimator. -/
noncomputable section
namespace Renyi

def upperRescaling (k : ℕ) (alpha eps cu u0 : ℝ) : ℝ :=
  (1+cu*upperU k alpha eps u0)⁻¹

theorem upperRescaling_range {k : ℕ} {alpha eps cu u0 : ℝ}
    (halpha : 1<alpha) (hγ : 0<fractionalPart alpha) (hγ1 : fractionalPart alpha<1)
    (hcu : 0≤cu) (hu0 : 0<u0) :
    0<upperRescaling k alpha eps cu u0 ∧ upperRescaling k alpha eps cu u0≤1 := by
  have hu := upperU_pos (k:=k) (eps:=eps) halpha hγ hγ1 hu0
  have hnon := mul_nonneg hcu hu.le
  constructor
  · exact inv_pos.mpr (by linarith only [hnon])
  · exact inv_le_one_of_one_le₀ (by linarith only [hnon])

theorem upperU_near_one_bound {k : ℕ} {alpha eps u0 : ℝ}
    (halpha : 1<alpha) (halpha1 : alpha≤3/2) : upperU k alpha eps u0≤2*(alpha-1) := by
  have hb : 0<alpha-1 := sub_pos.mpr halpha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order halpha halpha1).2];exact hb
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order halpha halpha1).2];linarith only [halpha1]
  have hx := one_le_rootMultiplier (k:=k) (ε:=eps) halpha hg hg1
  have hp : rootMultiplier k alpha eps^(-alpha)≤1 := Real.rpow_le_one_of_one_le_of_nonpos hx (by linarith only [halpha])
  have hdiv : (alpha-1)/alpha≤alpha-1 := by
    apply (div_le_iff₀ (by linarith only [halpha] : 0<alpha)).mpr
    nlinarith only [sq_nonneg (alpha-1)]
  have hv : upperV k alpha eps≤alpha-1 :=
    (mul_le_of_le_one_right (div_nonneg hb.le (by linarith only [halpha] : 0≤alpha)) hp).trans hdiv
  have h := min_le_left (upperV k alpha eps+fractionalPart alpha*(1-fractionalPart alpha)) u0
  change upperU k alpha eps u0≤_ at h
  rw [(near_one_order halpha halpha1).2] at h
  nlinarith only [h,hv,sq_nonneg (alpha-1)]

/-- The exact rescaling is within O(beta) of one at near-one orders. -/
theorem upperRescaling_near_one {k : ℕ} {alpha eps cu u0 : ℝ}
    (halpha : 1<alpha) (halpha1 : alpha≤3/2) (hcu : 0≤cu) (hu0 : 0<u0) :
    0<upperRescaling k alpha eps cu u0 ∧ upperRescaling k alpha eps cu u0≤1 ∧
      |upperRescaling k alpha eps cu u0-1|≤2*cu*(alpha-1) := by
  have hb : 0<alpha-1 := sub_pos.mpr halpha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order halpha halpha1).2];exact hb
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order halpha halpha1).2];linarith only [halpha1]
  have hr := upperRescaling_range (k:=k) (eps:=eps) halpha hg hg1 hcu hu0
  refine ⟨hr.1,hr.2,?_⟩
  rw [abs_of_nonpos (sub_nonpos.mpr hr.2)]
  have hu := upperU_pos (k:=k) (eps:=eps) halpha hg hg1 hu0
  have hnon := mul_nonneg hcu hu.le
  have hden : 0<1+cu*upperU k alpha eps u0 := by linarith only [hnon]
  have hid : 1-upperRescaling k alpha eps cu u0=
      cu*upperU k alpha eps u0/(1+cu*upperU k alpha eps u0) := by
    unfold upperRescaling
    field_simp
    ring
  have hquot : cu*upperU k alpha eps u0/(1+cu*upperU k alpha eps u0)≤cu*upperU k alpha eps u0 := by
    apply (div_le_iff₀ hden).mpr
    nlinarith only [sq_nonneg (cu*upperU k alpha eps u0)]
  have hbnd := mul_le_mul_of_nonneg_left (upperU_near_one_bound (k:=k) (eps:=eps) (u0:=u0) halpha halpha1) hcu
  linarith only [hid,hquot,hbnd]

end Renyi
