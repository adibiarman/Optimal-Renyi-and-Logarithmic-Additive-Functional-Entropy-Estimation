import Renyi.DegreeOneCentralLower
import Renyi.ClippedOverlapLower

/-! Actual canonical degree-one lower certificate. -/
noncomputable section
namespace Renyi.DegreeOneCompletion

def degreeOneMinEnvelopeConstant (f _q : ℝ) : ℝ := -Real.log (1-f)

/-- Actual clipped profiles retain the overlap baseline uniformly on bounded energy and resolution ranges. -/
theorem coupledProfiles_bounded_energy_base_lower {fL f qL qH Emin Emax R D M lam0 : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hEmin : 0<Emin) (_hEmax : Emin≤Emax) (hR : 1≤R) (_hD : 1≤D) (hM : 0≤M)
    (hlam0 : 0<lam0) (hlam1 : lam0≤1)
    (hqL : Real.exp (-Emin)<qL) (hqLf : qL<fL)
    (hqH : Real.exp (-7*Emin/8)<qH) (hqHf : qH<f) :
    ∃ K : ℝ, 0≤K ∧ ∀ (ℓ N : ℕ) (γ z E x y : ℝ), 2≤ℓ → 2≤N → (ℓ:ℝ)≤R →
      0<γ → γ<1 → 0<z → z<1 → Emin≤E → E≤Emax → overlapG γ z=Real.exp (-E) →
      0≤x → x≤1 → 0≤y → y≤1 → (N:ℝ)^2*y≤D*(1-γ) →
      lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤(x)*((N:ℝ)^2*y) →
      Real.exp (-E)*Real.exp (-K*(γ*(1-γ)))≤
        coupledReservedBase ℓ N γ z M fL f (Real.exp (-E/8)) x y := by
  let Ω := Real.exp (-Emax/8)
  let CL := max 0 (degreeOneMinEnvelopeConstant fL qL)
  let CH := max 0 (coupledHighMinEnvelopeConstant f qH Ω)
  let RL := Real.exp 1*max (R^2) 1
  let RH := max D 1
  let sL := dampedFloorThreshold qL (Real.exp (-Emin)) Emin M
  let sH := dampedFloorThreshold qH (Real.exp (-7*Emin/8)) Emin (M+1)
  let aL := min 1 (qL/RL)
  let aH := min 1 (qH*Ω/RH)
  let KL := -Real.log aL/sL
  let KH := -Real.log aH/sH
  let K := (M+CL+KL)+(M+1+CH+KH)-Real.log lam0
  have hqL0 : 0<qL := (Real.exp_pos _).trans hqL
  have hqH0 : 0<qH := (Real.exp_pos _).trans hqH
  have hΩ : 0<Ω := Real.exp_pos _
  have hRL : 0<RL := mul_pos (Real.exp_pos _) (zero_lt_one.trans_le (le_max_right _ _))
  have hRH : 0<RH := zero_lt_one.trans_le (le_max_right _ _)
  have hsL : 0<sL := dampedFloorThreshold_pos (Real.exp_pos _).le hqL hEmin hM
  have hsH : 0<sH := dampedFloorThreshold_pos (Real.exp_pos _).le hqH hEmin (by positivity)
  have haL : 0<aL := lt_min (by norm_num) (div_pos hqL0 hRL)
  have haH : 0<aH := lt_min (by norm_num) (div_pos (mul_pos hqH0 hΩ) hRH)
  have hKL : 0≤KL := div_nonneg (neg_nonneg.mpr (Real.log_nonpos haL.le (min_le_left _ _))) hsL.le
  have hKH : 0≤KH := div_nonneg (neg_nonneg.mpr (Real.log_nonpos haH.le (min_le_left _ _))) hsH.le
  have hCL : 0≤CL := le_max_left _ _
  have hCH : 0≤CH := le_max_left _ _
  have hK : 0≤K := by
    have hlog := Real.log_nonpos hlam0.le hlam1
    dsimp [K]
    linarith only [hM,hCL,hCH,hKL,hKH,hlog]
  refine ⟨K,hK,?_⟩
  intro ℓ N γ z E x y hℓ hN _hℓR hγ hγ1 hz hz1 hEE hEEmax hG hx hx1 hy hy1 hY hcap
  let ω := Real.exp (-E/8)
  let Z := x
  let Y := (N:ℝ)^2*y
  let U := Real.exp (-CL*γ)*(Z/γ)^γ
  let V := Real.exp (-CH*(1-γ))*(Y/(1-γ))^(1-γ)
  let AL := overlapA γ z*Real.exp (-M*γ)
  let BH := overlapB γ z*Real.exp (-(M+1)*(1-γ))
  let S := coupledReservedBase ℓ N γ z M fL f ω x y
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hE : 0<E := hEmin.trans_le hEE
  have hω : 0<ω := Real.exp_pos _
  have hω1 : ω<1 := Real.exp_lt_one_iff.mpr (by linarith only [hE])
  have hΩω : Ω≤ω := Real.exp_le_exp.mpr (by linarith only [hEEmax])
  have hzE : z≤Real.exp (-Emin) := by
    have hh := overlapG_ge_parameter hγ hγ1 hz hz1
    rw [hG] at hh
    exact hh.trans (Real.exp_le_exp.mpr (by linarith only [hEE]))
  have hκL : Real.exp (-E)≤Real.exp (-Emin) := Real.exp_le_exp.mpr (by linarith only [hEE])
  have hκH : Real.exp (-E)≤Real.exp (-7*Emin/8)*ω := by
    rw [←Real.exp_add]
    apply Real.exp_le_exp.mpr
    linarith only [hEE]
  have hweights := overlap_coefficients_unit hγ hγ1 hz hz1
  have hAL : 0≤AL := mul_nonneg hweights.1.le (Real.exp_pos _).le
  have hBH : 0≤BH := mul_nonneg hweights.2.2.1.le (Real.exp_pos _).le
  have hu0 := (lowProfile_range (by omega : 0<ℓ) hγ hfL.le hfL1 hx hx1).1
  have hv0 := (highProfile_range (by omega : 0<N) hd hf.le hf1.le hω.le hω1 hy hy1).1
  have hU : 0≤U := mul_nonneg (Real.exp_pos _).le (Real.rpow_nonneg (by positivity) γ)
  have hV : 0≤V := mul_nonneg (Real.exp_pos _).le (Real.rpow_nonneg (by positivity) (1-γ))
  have hUR : U≤RL := by
    have hZ : Z≤R^2 := by
      have hh : (1:ℝ)≤R^2 := one_le_pow₀ hR
      exact hx1.trans hh
    have hp := fractional_power_uniform_upper hγ hγ1.le (show 0≤Z by dsimp [Z];positivity) hZ
    exact (mul_le_of_le_one_left (Real.rpow_nonneg (by positivity) γ)
      (Real.exp_le_one_iff.mpr (by nlinarith only [mul_nonneg hCL hγ.le]))).trans hp
  have hVR : V≤RH := by
    have hq : Y/(1-γ)≤D := (div_le_iff₀ hd).mpr (by nlinarith only [hY])
    have hp : (Y/(1-γ))^(1-γ)≤max D 1 := by
      by_cases hq1 : Y/(1-γ)≤1
      · exact (Real.rpow_le_one (by positivity) hq1 hd.le).trans (le_max_right _ _)
      · have hbase : 1≤Y/(1-γ) := le_of_not_ge hq1
        have hh := Real.rpow_le_rpow_of_exponent_le hbase hd1
        rw [Real.rpow_one] at hh
        exact hh.trans (hq.trans (le_max_left _ _))
    exact (mul_le_of_le_one_left (Real.rpow_nonneg (by positivity) (1-γ))
      (Real.exp_le_one_iff.mpr (by nlinarith only [mul_nonneg hCH hd.le]))).trans hp
  have hu : min qL U≤lowProfile ℓ γ fL x := by
    have hh := lowProfile_global_min_lower (N:=ℓ) hγ hγ1.le hfL hfL1 hqLf.le hx hx1
    have hh : min qL (Real.exp (-degreeOneMinEnvelopeConstant fL qL*γ)*(x/γ)^γ)≤lowProfile ℓ γ fL x := by
      simpa only [degreeOneMinEnvelopeConstant,neg_neg] using hh
    have he : Real.exp (-CL*γ)≤Real.exp (-degreeOneMinEnvelopeConstant fL qL*γ) :=
      Real.exp_le_exp.mpr (by have hm := mul_le_mul_of_nonneg_right (le_max_right (0:ℝ) (degreeOneMinEnvelopeConstant fL qL)) hγ.le;nlinarith only [hm])
    exact (min_le_min (le_refl qL) (mul_le_mul_of_nonneg_right he (Real.rpow_nonneg (by positivity) γ))).trans hh
  have hv : min (qH*ω) V≤highProfile N (1-γ) f ω y := by
    have hh := highProfile_global_min_lower hN hd hd1 hf hf1 hqHf hΩ hΩω hω1 hy hy1
    have he : Real.exp (-CH*(1-γ))≤Real.exp (-coupledHighMinEnvelopeConstant f qH Ω*(1-γ)) :=
      Real.exp_le_exp.mpr (by have hm := mul_le_mul_of_nonneg_right (le_max_right (0:ℝ) (coupledHighMinEnvelopeConstant f qH Ω)) hd.le;nlinarith only [hm])
    exact (min_le_min (le_refl (qH*ω)) (mul_le_mul_of_nonneg_right he (Real.rpow_nonneg (by positivity) (1-γ)))).trans hh
  by_cases hS : Real.exp (-E)≤S
  · exact (mul_le_of_le_one_right (Real.exp_pos (-E)).le (Real.exp_le_one_iff.mpr
      (by nlinarith only [mul_nonneg hK (mul_nonneg hγ.le hd.le)]))).trans hS
  have hawayL : qL<U → sL≤γ := by
    intro hclip
    have huq : qL≤lowProfile ℓ γ fL x := by rwa [min_eq_left hclip.le] at hu
    have hobj : AL*qL≤S := by
      have hm := mul_le_mul_of_nonneg_left huq hAL
      have hh := mul_nonneg hBH hv0
      dsimp [S,coupledReservedBase,AL,BH] at *
      nlinarith only [hm,hh]
    by_contra hn
    have hsmall : γ≤sL := (lt_of_not_ge hn).le
    have hh := overlapA_damped_floor_lower hγ hγ1 hz hz1 hzE (Real.exp_pos _).le hqL hEmin hM hsmall
    exact (not_le_of_gt (lt_of_not_ge hS)) (hκL.trans (hh.trans hobj))
  have hawayH : qH*ω<V → sH≤1-γ := by
    intro hclip
    have hvq : qH*ω≤highProfile N (1-γ) f ω y := by rwa [min_eq_left hclip.le] at hv
    have hobj : BH*(qH*ω)≤S := by
      have hm := mul_le_mul_of_nonneg_left hvq hBH
      have hh := mul_nonneg hAL hu0
      dsimp [S,coupledReservedBase,AL,BH] at *
      nlinarith only [hm,hh]
    by_contra hn
    have hsmall : 1-γ≤sH := (lt_of_not_ge hn).le
    have hh := overlapB_damped_floor_lower hγ hγ1 hz hz1 hzE (Real.exp_pos _).le hqH hEmin (show 0≤M+1 by positivity) hsmall
    have hhw := mul_le_mul_of_nonneg_right hh hω.le
    exact (not_le_of_gt (lt_of_not_ge hS)) (hκH.trans (by dsimp [BH] at hobj;nlinarith only [hhw,hobj]))
  have hlow := clipped_profile_exponential_lower hγ.le hsL hqL0 hRL hU hUR hu hawayL
  have hhigh := clipped_profile_exponential_fixed_lower hd.le hsH (mul_pos hqH0 hΩ)
    (mul_le_mul_of_nonneg_left hΩω hqH0.le) hRH hV hVR hv hawayH
  change Real.exp (-KL*γ)*U≤lowProfile ℓ γ fL x at hlow
  change Real.exp (-KH*(1-γ))*V≤highProfile N (1-γ) f ω y at hhigh
  have hlow' := mul_le_mul_of_nonneg_left hlow (Real.exp_pos (-M*γ)).le
  have hhigh' := mul_le_mul_of_nonneg_left hhigh (Real.exp_pos (-(M+1)*(1-γ))).le
  have hidL : Real.exp (-M*γ)*(Real.exp (-KL*γ)*U)=Real.exp (-(M+CL+KL)*γ)*(Z/γ)^γ := by
    dsimp [U]
    rw [←mul_assoc,←mul_assoc,←Real.exp_add,←Real.exp_add]
    congr 2
    ring
  have hidH : Real.exp (-(M+1)*(1-γ))*(Real.exp (-KH*(1-γ))*V)=
      Real.exp (-(M+1+CH+KH)*(1-γ))*(Y/(1-γ))^(1-γ) := by
    dsimp [V]
    rw [←mul_assoc,←mul_assoc,←Real.exp_add,←Real.exp_add]
    congr 2
    ring
  rw [hidL] at hlow'
  rw [hidH] at hhigh'
  have hprod := sharp_power_pair_product_lower hγ hγ1 hz hlam0 (show 0≤Z by dsimp [Z];positivity)
    (show 0≤Y by dsimp [Y];positivity) hlow' hhigh' hcap
  have hbound := overlap_approximate_lower_bound (D:=K*(γ*(1-γ))) hγ hγ1 hz hz1
    (mul_nonneg (Real.exp_pos (-M*γ)).le hu0)
    (mul_nonneg (Real.exp_pos (-(M+1)*(1-γ))).le hv0)
    (by simpa only [K,neg_mul] using hprod)
  rw [hG] at hbound
  dsimp [S,coupledReservedBase]
  simpa only [neg_mul,mul_assoc] using hbound


end Renyi.DegreeOneCompletion
