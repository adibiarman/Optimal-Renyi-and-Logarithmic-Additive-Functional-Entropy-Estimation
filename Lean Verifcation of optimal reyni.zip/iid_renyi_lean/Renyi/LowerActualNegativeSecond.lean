import Renyi.LowerActualSecondMoments

/-! Actual-root refined second moments in the negative-active orientation. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 1800000

theorem lower_actual_negative_second_moments {τ : Type*} [Fintype τ]
    (p₀ p₁ : FiniteAtomicPrior τ) {k m : ℕ} {s ε : ℝ}
    (hk : 0<k) (hm : 1≤m) (hs : 0<s) (hs1 : s≤1/2) (hε : 0<ε)
    (hx : lowerPriorRootCutoff ε≤rootMultiplier k ((m:ℝ)+(1-s)) ε) :
    let α := (m:ℝ)+(1-s)
    let x := rootMultiplier k α ε
    let L := Nat.ceil (10*α*(1+Real.log x))
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let ds : ℝ := ((L-m:ℕ):ℝ)+1
    let dc : ℝ := ((m-1:ℕ):ℝ)+1
    let bs := (ζ/8)/ds^2
    let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
    let a := θ/((1/100)*(L:ℝ)*ac)
    let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
    let us := chebyshevNode (L-m) bs
    let uc := chebyshevNode (m-1) ((1-s)/dc^2)
    let l := normalizedInterpolation uc ac 0 (1-s)
    let t := normalizedInterpolation us a ρ s
    let U := interpolationNodes uc ac
    let V := interpolationNodes us a
    let B := (ac*a)⁻¹
    let Z := tensorNormalizer l t U V ac α
    (∀ j:ℝ, 0<j → priorMoment p₀ j=B^(j-1)/Z*(∑ ij, tensorNegative l t ij*tensorAtom U V ac ij^(j-α))) →
    (∀ j:ℝ, 0<j → priorMoment p₁ j=B^(j-1)/Z*(∑ ij, tensorPositive l t ij*tensorAtom U V ac ij^(j-α))) →
    priorMoment p₀ (2*α)/(priorMoment p₀ α)^2≤lowerPriorSecondConstant ε*ζ^2*B^α ∧
    priorMoment p₁ (2*α)/(priorMoment p₁ α)^2≤lowerPriorSecondConstant ε*ζ^2*B^α := by
  let α := (m : ℝ)+(1-s)
  let x := rootMultiplier k α ε
  let L := Nat.ceil (10*α*(1+Real.log x))
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ds : ℝ := ((L-m : ℕ) : ℝ)+1
  let dc : ℝ := ((m-1 : ℕ) : ℝ)+1
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*(L : ℝ)*ac)
  have hmR : (1 : ℝ) ≤ m := by exact_mod_cast hm
  have hα : 3/2 ≤ α := by dsimp [α]; linarith
  have hα1 : 1 < α := by linarith
  have hα0 : 0 < α := by linarith
  have hγ : fractionalPart α = 1-s :=
    fractionalPart_nat_add_small m (by linarith) (by linarith)
  have hγ₀ : 0 < fractionalPart α := by rw [hγ]; linarith
  have hγ₁ : fractionalPart α < 1 := by rw [hγ]; linarith
  have hnear : s = 1-fractionalPart α := by rw [hγ]; ring
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hx0 : 0 < x := by linarith
  have hlog : 0 ≤ Real.log x := Real.log_nonneg (by linarith)
  have hLlo : 10*α*(1+Real.log x) ≤ (L : ℝ) := Nat.le_ceil _
  have hLm : m+1 ≤ L := by
    have : (m : ℝ)+1 ≤ L := by dsimp [α] at *; nlinarith
    exact_mod_cast this
  have hds : 0 < ds := by dsimp [ds]; positivity
  have hdc : 0 < dc := by dsimp [dc]; positivity
  have hdc_eq : dc = (m : ℝ) := by
    dsimp [dc]
    rw [Nat.cast_sub hm]
    push_cast
    ring
  have hdshi : ds ≤ (L : ℝ)+1 := by
    dsimp [ds]
    exact add_le_add_right (by exact_mod_cast (Nat.sub_le L m)) 1
  have hdim : ds*dc ≤ α*((L : ℝ)+1) := by
    have h1 := mul_le_mul_of_nonneg_right hdshi (by positivity : 0 ≤ dc)
    rw [hdc_eq] at h1
    have h2 := mul_le_mul_of_nonneg_left (show (m : ℝ) ≤ α by dsimp [α]; linarith)
      (show 0 ≤ (L : ℝ)+1 by positivity)
    rw [hdc_eq]
    exact h1.trans (by nlinarith only [h2])
  have _hc := lowerPriorCoefficient_bounds hε
  have hβ0 : 0 < α-1 := sub_pos.mpr hα1
  have hE : 0 < E := by dsimp [E]; positivity
  have hv : 0 ≤ v := by dsimp [v]; positivity
  have hw : 0 < w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv
  have hcon := lower_actual_principal_constraints_with_perturbation hk hα hε hs hs1 hγ₀ hγ₁
    (Or.inr hnear) hx hds hdc hdim
  dsimp only at hcon
  let bs := (ζ/8)/ds^2
  let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
  change 0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 ∧ ρ ≤ 1 at hcon
  have hmul : 4*ζ*((ds-1)/ds) = 4*ζ*((L-m : ℕ) : ℝ)/(((L-m : ℕ) : ℝ)+1) := by
    dsimp [ds]
    ring
  have hpert : max (((a/bs)^s/κ)*
      Real.exp (4*ζ*((L-m : ℕ) : ℝ)/(((L-m : ℕ) : ℝ)+1))-1) 0 * a / bs ≤ ζ := by
    rw [← hmul]
    exact hcon.2.2.2.1
  let us := chebyshevNode (L-m) bs
  let uc := chebyshevNode (m-1) ((1-s)/dc^2)
  let l := normalizedInterpolation uc ac 0 (1-s)
  let t := normalizedInterpolation us a ρ s
  let U := interpolationNodes uc ac
  let V := interpolationNodes us a
  dsimp only
  intro hmom₀ hmom₁
  have hns : 0<L-m := by omega
  have hκ0 : 0<κ := Real.exp_pos _
  have hκ1 : κ≤1 := Real.exp_le_one_iff.mpr (by linarith)
  have hζ0 : 0<ζ := hcon.2.2.2.2.1
  have hζsmall : ζ≤3/5 := by linarith [hcon.2.2.2.2.2.1]
  have hbs0 : 0<bs := by dsimp [bs]; positivity
  have hactive := active_interpolation_mass_bound (L-m) ζ a s κ hns hζ0 hζsmall hcon.1 hcon.2.1 hs.le hκ0 hκ1 hpert
  dsimp only at hactive
  rw [←hmul] at hactive
  change (∑ i, negativeCoeff (t i))≤κ ∧ 1/2≤t none at hactive
  have hLα : 10*α≤L := by nlinarith
  have hdimlo : α*(L:ℝ)/4≤ds*dc := by
    have hh := lower_nat_dimension_product_lower hm
      (show (m:ℝ)≤α by dsimp [α]; linarith)
      (show α≤(m:ℝ)+1 by dsimp [α]; linarith) hLα
    rw [hdc_eq]
    nlinarith only [hh]
  let δ := Real.exp (lowerLogSampleConstant ε c/2-4)
  have hδ0 : 0<δ := Real.exp_pos _
  have hratio := lower_actual_active_ratio_floor hk hα hε hs hs1 hγ₀ hγ₁ (Or.inr hnear) hx hds hdc hdim hdimlo
  change δ≤(a/bs)^s/κ at hratio
  have hfloor : δ*κ≤(a/bs)^s := (le_div_iff₀ hκ0).mp hratio
  have hshape := active_factor_moment_shape (L-m) ζ a ρ s α κ δ hns hζ0 hζsmall hcon.1 hcon.2.2.1 hcon.2.2.2.2.2.2 hs.le hκ0 hcon.2.1 hcon.2.2.2.1
    (by dsimp [α]; linarith) hactive.2 hactive.1 hfloor
  have hδ1 : δ≤4 := by
    have hh := hshape.1.trans hactive.1
    nlinarith
  let bc := (1-s)/dc^2
  have hξ : 0<1-s := by linarith
  have hbc0 : 0<bc := by dsimp [bc]; positivity
  have hdc1 : 1≤dc := by dsimp [dc]; exact le_add_of_nonneg_left (Nat.cast_nonneg _)
  have hbc1 : bc<1 := by dsimp [bc]; apply (div_lt_one (by positivity)).mpr; nlinarith
  have hzK0 : 0<ζ*κ := mul_pos hζ0 hκ0
  have hzK1 : ζ*κ≤1 := by nlinarith [mul_le_mul_of_nonneg_left hκ1 hζ0.le,hcon.2.2.2.2.2.1]
  have hac : 0<ac := by dsimp [ac]; positivity
  have hab : ac<bc := by
    have hp := Real.rpow_le_one hzK0.le hzK1 (by positivity : 0≤1/(1-s))
    have he : Real.exp (-5)<1 := Real.exp_lt_one_iff.mpr (by norm_num)
    have hh := mul_le_mul_of_nonneg_left hp (show 0≤Real.exp (-5)*bc by positivity)
    have hh' := mul_lt_mul_of_pos_right he hbc0
    dsimp [ac,bc] at *
    nlinarith
  have hau (i) : ac<uc i := hab.trans_le (chebyshevNode_bounds (m-1) bc hbc1.le i).1
  have hcancel := low_integer_factor_zero uc (chebyshevNode_injective (m-1) bc hbc1)
    (ρ:=0) (γ:=1-s) hac hau 1 (by norm_num) (by omega) (Or.inr rfl)
  simp only [Nat.cast_one] at hcancel
  have hh := negative_actual_tensor_second_shape p₀ p₁ (L-m) (m-1) ζ a ρ s α κ δ hns hζ0 hζsmall hcon.1 hcon.2.2.1 hcon.2.2.2.2.2.2 hs hs1 hκ0 hκ1 hδ0 hδ1
    (by dsimp [α]; linarith) hcon.2.1 hcon.2.2.2.1 hactive.2 hactive.1 hfloor hcancel hmom₀ hmom₁
  exact hh

end Renyi
