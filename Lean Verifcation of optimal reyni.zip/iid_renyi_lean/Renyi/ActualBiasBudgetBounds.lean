import Renyi.ActualBiasModel
import Renyi.UpperPilotBaseline
import Renyi.HighOrderNorm

/-! Uniform upper control of the canonical deterministic margin by the power sum. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 700000

lemma actualBaseline_le_one_of_small_cutoff {k : ℕ} {alpha C0 d a : ℝ}
    (hk : 0<k) (ha : 3/2≤alpha) (hC0 : 1≤C0) (hd : 0≤d) (hd1 : d≤1)
    (ha0 : 0≤a) (hsmall : C0^2*((k:ℝ)*a)≤1) :
    upperActualBaseline k alpha C0 d a≤1 := by
  have hK : (0:ℝ)<k := by exact_mod_cast hk
  have hb : 0≤alpha-1 := by linarith only [ha]
  have hC : 0<C0 := zero_lt_one.trans_le hC0
  have hm := upperOrderFloor_le_twice_gap ha
  have hpow : C0^upperOrderFloor alpha≤(C0^2)^(alpha-1) := by
    rw [←Real.rpow_natCast,←Real.rpow_natCast C0 2,←Real.rpow_mul hC.le]
    exact Real.rpow_le_rpow_of_exponent_le hC0 (by simpa only [Nat.cast_ofNat] using hm)
  have hcore : C0^upperOrderFloor alpha*((k:ℝ)*a)^(alpha-1)≤1 := by
    have hh := mul_le_mul_of_nonneg_right hpow (Real.rpow_nonneg (mul_nonneg hK.le ha0) (alpha-1))
    rw [←Real.mul_rpow (sq_nonneg C0) (mul_nonneg hK.le ha0)] at hh
    exact hh.trans (Real.rpow_le_one (mul_nonneg (sq_nonneg C0) (mul_nonneg hK.le ha0)) hsmall hb)
  have hchi0 : 0≤min (alpha-1) 1 := le_min hb (by norm_num)
  have hcoef : min (alpha-1) 1*d≤1 := mul_le_one₀ (min_le_right _ _) hd hd1
  have hmul := mul_le_mul hcoef hcore (by positivity : 0≤C0^upperOrderFloor alpha*((k:ℝ)*a)^(alpha-1)) (by norm_num : (0:ℝ)≤1)
  unfold upperActualBaseline
  nlinarith only [hmul]

/-- D alone makes the actual cutoff correction no greater than the target P. -/
theorem actualCutoffBudget_uniform_le_powerSum {eps Ch cb lambda CL cL C0 d : ℝ}
    (heps : 0<eps) (hCh : 0≤Ch) (hcb : 0<cb) (hlambda : 0<lambda)
    (hCL : 1≤CL) (hcL : 0<cL) (hC0 : 1≤C0) (hd : 0≤d) (hd1 : d≤1) :
    ∃ D0 : ℝ, 0<D0 ∧ ∀ (k : ℕ) (alpha D : ℝ),
      0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → D0≤D →
      ∀p : Simplex k, actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d≤powerSum p alpha := by
  obtain ⟨r,R,hr,hR,hcut⟩ := upper_actual_cutoff heps hCh hcb hlambda hCL hcL
  refine ⟨max 1 (C0^2*R),zero_lt_one.trans_le (le_max_left _ _),?_⟩
  intro k alpha D hk ha hg hg1 hD0 p
  have hD : 0<D := zero_lt_one.trans_le ((le_max_left _ _).trans hD0)
  have hDR : C0^2*R≤D := (le_max_right _ _).trans hD0
  have ha1 : 1<alpha := by linarith only [ha]
  have hc := hcut k alpha D hk ha1 hg hg1 hD
  have hka := upper_cutoff_scaled_upper hk ha1 hg hg1 hR hD hc.2
  have hapos : 0<upperA k alpha eps Ch D cb lambda CL cL := by
    have hratio : 0<upperA k alpha eps Ch D cb lambda CL cL/((alpha-1)/(alpha*k)) :=
      (mul_pos (div_pos hr hD) (Real.exp_pos _)).trans_le hc.1
    have hK : (0:ℝ)<k := by exact_mod_cast hk
    have hden : 0<(alpha-1)/(alpha*k) := div_pos (sub_pos.mpr ha1) (mul_pos (by linarith only [ha]) hK)
    exact (div_pos_iff_of_pos_right hden).mp hratio
  have hsmall : C0^2*((k:ℝ)*upperA k alpha eps Ch D cb lambda CL cL)≤1 := by
    have hh := mul_le_mul_of_nonneg_left hka (sq_nonneg C0)
    have hratio : C0^2*(R/D)≤1 := by
      simpa only [mul_div_assoc] using (div_le_one hD).mpr hDR
    exact hh.trans hratio
  have hbase := actualBaseline_le_one_of_small_cutoff hk ha hC0 hd hd1 hapos.le hsmall
  have hP := simplex_powerSum_uniform_lower hk p (by linarith only [ha])
  have hmul := mul_le_mul_of_nonneg_right hbase (Real.rpow_nonneg (Nat.cast_nonneg k) (1-alpha))
  have hh : actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d≤(k:ℝ)^(1-alpha) := by
    simpa only [one_mul,actualCutoffBudget] using hmul
  exact hh.trans hP

/-- Once the cutoff baseline is at most P, the complete source margin is
bounded by (u0+2)P, uniformly over alpha and the alphabet. -/
theorem actualBiasBudget_le_powerSum {k : ℕ} (p : Simplex k)
    {alpha eps Ch D cb lambda CL cL C0 d u0 : ℝ}
    (ha : 1<alpha) (heps : 0≤eps) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (hu0 : 0<u0)
    (hbase : actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d≤powerSum p alpha) :
    actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d u0≤(u0+2)*powerSum p alpha := by
  have hP := (simplex_powerSum_pos p alpha).le
  have hk0 : 0≤upperKappa alpha eps := (Real.exp_pos _).le
  have hk1 : upperKappa alpha eps≤1 := Real.exp_le_one_iff.mpr (by
    nlinarith only [mul_nonneg heps (sub_pos.mpr ha).le])
  have hu := upperU_pos (k:=k) (eps:=eps) ha hg hg1 hu0
  have hu1 : upperU k alpha eps u0≤u0 := min_le_right _ _
  have hprod : upperKappa alpha eps*upperU k alpha eps u0≤u0 :=
    (mul_le_of_le_one_left hu.le hk1).trans hu1
  have hbonus : actualForwardBonus p alpha eps D cb CL cL≤powerSum p alpha := by
    apply Finset.sum_le_sum
    intro i _
    exact mul_le_of_le_one_right (Real.rpow_nonneg (p.nonneg i) _) (min_le_right _ _)
  have hchi : 0≤min (alpha-1) 1 := le_min (sub_pos.mpr ha).le (by norm_num)
  have hpref : min (alpha-1) 1*upperKappa alpha eps≤1 := mul_le_one₀ (min_le_right _ _) hk0 hk1
  have hbonus' := (mul_le_mul_of_nonneg_left hbonus (mul_nonneg hchi hk0)).trans
    (mul_le_of_le_one_left hP hpref)
  have hmiddle := mul_le_mul_of_nonneg_right hprod hP
  unfold actualBiasBudget
  nlinarith only [hbase,hbonus',hmiddle]

end Renyi
