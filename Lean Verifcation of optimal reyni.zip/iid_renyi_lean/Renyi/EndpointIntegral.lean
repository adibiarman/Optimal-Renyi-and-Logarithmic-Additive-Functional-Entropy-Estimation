import Renyi.EndpointKernel
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic

/-! Actual local and integral estimates for the Chebyshev endpoint kernel. -/
noncomputable section
open scoped BigOperators
open MeasureTheory Set
namespace Renyi

lemma endpointAngle_le_two_sqrt {x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    endpointAngle x ≤ 2 * Real.sqrt x := by
  have hθ := endpointAngle_nonneg (x := x)
  have h := Real.mul_le_sin hθ (Real.arcsin_le_pi_div_two (Real.sqrt x))
  rw [endpointAngle_sin hx hx1] at h
  have h' := (div_le_iff₀ Real.pi_pos).mp
    (show 2 * endpointAngle x / Real.pi ≤ Real.sqrt x by convert h using 1; ring)
  nlinarith [Real.sqrt_nonneg x, Real.pi_lt_four]

lemma endpointAngle_ge_sqrt {x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    Real.sqrt x ≤ endpointAngle x := by
  simpa [endpointAngle_sin hx hx1] using Real.sin_le (endpointAngle_nonneg (x := x))

lemma endpoint_chebyshev_local_lower {N : ℕ} (hN : 0 < N) {x : ℝ}
    (hx : 0 ≤ x) (hx1 : x ≤ 1) (hy : (N : ℝ)^2*x ≤ 1/4) :
    1 - (N : ℝ)^2*x ≤
      (Polynomial.Chebyshev.U ℝ ((N : ℤ)-1)).eval (Real.sqrt (1-x)) / N := by
  rcases hx.eq_or_lt with rfl | hx
  · simp [Polynomial.Chebyshev.U_eval_one, Nat.ne_of_gt hN]
  have hn : 0 < (N : ℝ) := by exact_mod_cast hN
  have hs : 0 < Real.sqrt x := Real.sqrt_pos.mpr hx
  have hθ := endpointAngle_nonneg (x := x)
  have hθlo := endpointAngle_ge_sqrt hx.le hx1
  have hθhi := endpointAngle_le_two_sqrt hx.le hx1
  have htpos : 0 < (N : ℝ) * endpointAngle x := mul_pos hn (hs.trans_le hθlo)
  have htsq : ((N : ℝ) * endpointAngle x)^2 ≤ 4 * (N : ℝ)^2 * x := by
    have hh := pow_le_pow_left₀ hθ hθhi 2
    have hh' := mul_le_mul_of_nonneg_left hh (sq_nonneg (N : ℝ))
    nlinarith [Real.sq_sqrt hx.le]
  have ht1 : (N : ℝ) * endpointAngle x ≤ 1 := by nlinarith
  have hsin := (Real.sin_gt_sub_cube htpos ht1).le
  have hprod : (N : ℝ) * Real.sqrt x * (1 - (N : ℝ)^2*x) ≤
      ((N : ℝ)*endpointAngle x) * (1 - ((N : ℝ)*endpointAngle x)^2/4) := by
    apply mul_le_mul
    · exact mul_le_mul_of_nonneg_left hθlo hn.le
    · nlinarith
    · nlinarith [sq_nonneg (N : ℝ)]
    · positivity
  have hquot : (1 - (N : ℝ)^2*x) ≤
      Real.sin ((N : ℝ)*endpointAngle x) / ((N : ℝ)*Real.sqrt x) := by
    apply (le_div_iff₀ (mul_pos hn hs)).mpr
    nlinarith
  have hsine := endpoint_chebyshev_sine hx.le hx1 N
  have hidentity :
      (Polynomial.Chebyshev.U ℝ ((N : ℤ)-1)).eval (Real.sqrt (1-x)) / N =
        Real.sin ((N : ℝ)*endpointAngle x) / ((N : ℝ)*Real.sqrt x) := by
    rw [← hsine]
    field_simp
  rw [hidentity]
  exact hquot

/-- Uniform linear deficit for the constructed kernel, including both source exponents. -/
theorem endpointKernel_linear_deficit {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    1 - 12 * (N : ℝ)^2*x ≤ endpointKernel N d x := by
  by_cases hy : (N : ℝ)^2*x ≤ 1/4
  · have hq := endpoint_chebyshev_local_lower hN hx hx1 hy
    have hy0 : 0 ≤ (N : ℝ)^2*x := by positivity
    have hp : 1 - (2*d : ℕ) * ((N : ℝ)^2*x) ≤
        (1 - (N : ℝ)^2*x)^(2*d) := by
      have h := one_add_mul_le_pow (show (-2 : ℝ) ≤ -((N : ℝ)^2*x) by linarith) (2*d)
      convert h using 1; push_cast; ring
    have hpow := pow_le_pow_left₀ (show 0 ≤ 1 - (N : ℝ)^2*x by linarith) hq (2*d)
    have hdc : (2*d : ℕ) ≤ 12 := by omega
    have hdcR : ((2*d : ℕ) : ℝ) ≤ 12 := by exact_mod_cast hdc
    unfold endpointKernel
    nlinarith [mul_nonneg (sub_nonneg.mpr hdcR) hy0]
  · have hn := endpointKernel_nonneg N d x
    linarith

def endpointIntegral (N d : ℕ) (s : ℝ) : ℝ :=
  ∫ x in (0 : ℝ)..1, x^(s-1)*endpointKernel N d x

def endpointPrimitive (N d : ℕ) (s x : ℝ) : ℝ :=
  ∫ t in (0 : ℝ)..x, t^(s-1)*endpointKernel N d t

def endpointProfile (N d : ℕ) (s x : ℝ) : ℝ :=
  endpointPrimitive N d s x / endpointIntegral N d s

lemma endpointKernel_weight_integrable (N d : ℕ) {s : ℝ} (hs : 0 < s) (a b : ℝ) :
    IntervalIntegrable (fun x : ℝ => x^(s-1)*endpointKernel N d x) volume a b := by
  exact (intervalIntegral.intervalIntegrable_rpow' (by linarith : -1 < s-1)).mul_continuousOn
    (endpointKernel_continuous N d).continuousOn

lemma endpointPrimitive_nonneg (N d : ℕ) {s x : ℝ} (hx : 0 ≤ x) :
    0 ≤ endpointPrimitive N d s x := by
  apply intervalIntegral.integral_nonneg hx
  intro t ht
  exact mul_nonneg (Real.rpow_nonneg ht.1 _) (endpointKernel_nonneg N d t)

lemma endpointPrimitive_le_integral (N d : ℕ) {s x : ℝ} (hs : 0 < s)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    endpointPrimitive N d s x ≤ endpointIntegral N d s := by
  apply intervalIntegral.integral_mono_interval le_rfl hx hx1
  · filter_upwards [ae_restrict_mem measurableSet_Ioc] with t ht
    exact mul_nonneg (Real.rpow_nonneg ht.1.le _) (endpointKernel_nonneg N d t)
  · exact endpointKernel_weight_integrable N d hs 0 1

/-- The linear deficit integrates exactly; no assumed kernel certificate is used. -/
theorem endpointIntegral_lower {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s : ℝ} (hs : 0 < s) :
    ((12*(N : ℝ)^2)⁻¹)^s / (s*(s+1)) ≤ endpointIntegral N d s := by
  let a : ℝ := (12*(N : ℝ)^2)⁻¹
  have hn : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have ha : 0 < a := by dsimp [a]; positivity
  have ha1 : a ≤ 1 := by
    dsimp [a]
    apply inv_le_one_of_one_le₀
    nlinarith
  have hp0 : IntervalIntegrable (fun x : ℝ => x^(s-1)) volume 0 a :=
    intervalIntegral.intervalIntegrable_rpow' (by linarith)
  have hp1 : IntervalIntegrable (fun x : ℝ => x^s) volume 0 a :=
    intervalIntegral.intervalIntegrable_rpow' (by linarith)
  have hmono := intervalIntegral.integral_mono_on ha.le
    (hp0.sub (hp1.const_mul (12*(N : ℝ)^2)))
    (endpointKernel_weight_integrable N d hs 0 a) (fun x hx => ?_)
  · have heval : (∫ x in (0:ℝ)..a, x^(s-1) - 12*(N : ℝ)^2*x^s) =
        a^s / (s*(s+1)) := by
      rw [intervalIntegral.integral_sub hp0 (hp1.const_mul _), intervalIntegral.integral_const_mul,
        integral_rpow (Or.inl (by linarith : -1 < s-1)),
        integral_rpow (Or.inl (by linarith : -1 < s))]
      rw [show s-1+1=s by ring, Real.zero_rpow hs.ne', Real.zero_rpow (by linarith : s+1 ≠ 0),
        sub_zero, sub_zero, Real.rpow_add_one ha.ne' s]
      have hid : 12*(N : ℝ)^2*a=1 := by dsimp [a]; field_simp
      field_simp
      nlinarith
    rw [heval] at hmono
    exact hmono.trans (endpointPrimitive_le_integral N d hs ha.le ha1)
  · have hx0 := hx.1
    have hx1 := hx.2.trans ha1
    have hk := endpointKernel_linear_deficit hN hd hx0 hx1
    have hmul := mul_le_mul_of_nonneg_left hk (Real.rpow_nonneg hx0 (s-1))
    have hr : x^s = x^(s-1)*x := by
      have h := Real.rpow_add_one' hx0 (show s-1+1 ≠ 0 by linarith)
      simpa only [sub_add_cancel] using h
    rw [hr]
    nlinarith

theorem endpointIntegral_pos {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s : ℝ} (hs : 0 < s) : 0 < endpointIntegral N d s := by
  have hbase : 0 < (12*(N : ℝ)^2)⁻¹ := by positivity
  exact (div_pos (Real.rpow_pos_of_pos hbase s) (mul_pos hs (by linarith))).trans_le
    (endpointIntegral_lower hN hd hs)

theorem endpointProfile_range {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    0 ≤ endpointProfile N d s x ∧ endpointProfile N d s x ≤ 1 := by
  have hi := endpointIntegral_pos hN hd hs
  exact ⟨div_nonneg (endpointPrimitive_nonneg N d hx) hi.le,
    (div_le_one hi).mpr (endpointPrimitive_le_integral N d hs hx hx1)⟩

@[simp] theorem endpointProfile_zero (N d : ℕ) (s : ℝ) : endpointProfile N d s 0 = 0 := by
  simp [endpointProfile, endpointPrimitive]

@[simp] theorem endpointProfile_one {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s : ℝ} (hs : 0 < s) : endpointProfile N d s 1 = 1 := by
  unfold endpointProfile endpointPrimitive
  change endpointIntegral N d s / endpointIntegral N d s = 1
  exact div_self (endpointIntegral_pos hN hd hs).ne'

/-- Normalization lower bound has logarithmic error linear in s, uniformly in N. -/
theorem endpointIntegral_normalized_lower {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s : ℝ} (hs : 0 < s) :
    Real.exp (-(Real.log 12 + 1)*s) ≤
      s*(N : ℝ)^(2*s)*endpointIntegral N d s := by
  have hn : 0 < (N : ℝ) := by exact_mod_cast hN
  have hn2 : 0 < (N : ℝ)^2 := sq_pos_of_pos hn
  let a : ℝ := (12*(N : ℝ)^2)⁻¹
  have ha : 0 < a := by dsimp [a]; positivity
  have h := mul_le_mul_of_nonneg_left (endpointIntegral_lower hN hd hs)
    (show 0 ≤ s*(N : ℝ)^(2*s) by positivity)
  have hid : s*(N : ℝ)^(2*s)*(a^s/(s*(s+1))) = (12:ℝ)^(-s)/(s+1) := by
    have hnPow : (N : ℝ)^(2*s) = ((N : ℝ)^2)^s := by
      simpa using (Real.rpow_natCast_mul hn.le 2 s)
    rw [hnPow]
    have hpow : ((N : ℝ)^2)^s*a^s = (12:ℝ)^(-s) := by
      rw [← Real.mul_rpow hn2.le ha.le, Real.rpow_neg_eq_inv_rpow]
      congr 1
      dsimp [a]
      field_simp
    field_simp
    nlinarith
  change s*(N : ℝ)^(2*s)*(a^s/(s*(s+1))) ≤ _ at h
  rw [hid] at h
  have hexp : Real.exp (-s) ≤ 1/(s+1) := by
    rw [Real.exp_neg]
    simpa only [one_div] using
      one_div_le_one_div_of_le (by linarith : 0 < s+1) (Real.add_one_le_exp s)
  have hmul := mul_le_mul_of_nonneg_left hexp (Real.rpow_pos_of_pos (by norm_num : (0:ℝ)<12) (-s)).le
  have heq : Real.exp (-(Real.log 12+1)*s) = (12:ℝ)^(-s)*Real.exp (-s) := by
    rw [Real.rpow_def_of_pos (by norm_num : (0:ℝ)<12), ← Real.exp_add]
    congr 1
    ring
  rw [← heq] at hmul
  have hmul' : Real.exp (-(Real.log 12+1)*s) ≤ (12:ℝ)^(-s)/(s+1) := by
    simpa [div_eq_mul_inv] using hmul
  exact hmul'.trans h

def endpointTailIntegral (N d : ℕ) (s x : ℝ) : ℝ :=
  ∫ t in x..1, t^(s-1)*endpointKernel N d t

lemma endpoint_tail_power_identity {N d : ℕ} (hN : 0 < N) {s x : ℝ} (hx : 0 < x) :
    x^(s-1) * (((N : ℝ)^2*x)⁻¹)^d =
      (((N : ℝ)^2)^d)⁻¹ * x^(s-1-(d:ℝ)) := by
  have hn : (N : ℝ) ≠ 0 := by exact_mod_cast hN.ne'
  rw [Real.rpow_sub hx (s-1) (d:ℝ), Real.rpow_natCast]
  rw [mul_inv, mul_pow, inv_pow]
  field_simp [hx.ne']
  simp [hx.ne']

/-- Upper tail of the actual endpoint-weight integral. -/
theorem endpointTailIntegral_upper {N d : ℕ} (hN : 0 < N) {s x : ℝ}
    (hsd : s < (d:ℝ)) (hx : 0 < x) (hx1 : x ≤ 1) :
    endpointTailIntegral N d s x ≤
      (((N : ℝ)^2)^d)⁻¹ * x^(s-(d:ℝ)) / ((d:ℝ)-s) := by
  have hzero : (0:ℝ) ∉ Set.uIcc x 1 := by
    rw [Set.uIcc_of_le hx1]
    simp only [Set.mem_Icc, not_and_or, not_le]
    exact Or.inl hx
  have hp : IntervalIntegrable (fun t:ℝ => t^(s-1-(d:ℝ))) volume x 1 :=
    intervalIntegral.intervalIntegrable_rpow (Or.inr hzero)
  have hk : IntervalIntegrable (fun t:ℝ => t^(s-1)*endpointKernel N d t) volume x 1 := by
    apply IntervalIntegrable.mul_continuousOn
      (intervalIntegral.intervalIntegrable_rpow (Or.inr hzero))
    exact (endpointKernel_continuous N d).continuousOn
  have hmono := intervalIntegral.integral_mono_on hx1 hk
    (hp.const_mul ((((N : ℝ)^2)^d)⁻¹)) (fun t ht => ?_)
  · have heval : (∫ t in x..1, (((N : ℝ)^2)^d)⁻¹*t^(s-1-(d:ℝ))) =
        (((N : ℝ)^2)^d)⁻¹ * (x^(s-(d:ℝ))-1) / ((d:ℝ)-s) := by
      rw [intervalIntegral.integral_const_mul,
        integral_rpow (Or.inr ⟨by linarith,hzero⟩), Real.one_rpow]
      rw [show s-1-(d:ℝ)+1=s-(d:ℝ) by ring]
      rw [show (d:ℝ)-s=-(s-(d:ℝ)) by ring, div_neg]
      ring
    rw [heval] at hmono
    apply hmono.trans
    apply div_le_div_of_nonneg_right _ (by linarith : 0 ≤ (d:ℝ)-s)
    have hnonneg : 0 ≤ (((N : ℝ)^2)^d)⁻¹ := by positivity
    nlinarith
  · have ht0 : 0 < t := hx.trans_le ht.1
    have hK := endpointKernel_le_inverse_power hN d ht0 ht.2
    have hmul := mul_le_mul_of_nonneg_left hK (Real.rpow_nonneg ht0.le (s-1))
    rw [endpoint_tail_power_identity hN ht0] at hmul
    exact hmul

lemma endpointPrimitive_upper {N d : ℕ} (hN : 0 < N) {s x : ℝ}
    (hs : 0 < s) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    endpointPrimitive N d s x ≤ x^s/s := by
  have hp := intervalIntegral.intervalIntegrable_rpow' (a:=0) (b:=x) (by linarith : -1<s-1)
  have hmono := intervalIntegral.integral_mono_on hx
    (endpointKernel_weight_integrable N d hs 0 x) hp (fun t ht => ?_)
  · have heval : (∫ t in (0:ℝ)..x, t^(s-1))=x^s/s := by
      rw [integral_rpow (Or.inl (by linarith : -1<s-1)), show s-1+1=s by ring,
        Real.zero_rpow hs.ne', sub_zero]
    exact hmono.trans_eq heval
  · have hK := endpointKernel_le_one hN d ht.1 (ht.2.trans hx1)
    simpa only [mul_one] using mul_le_mul_of_nonneg_left hK (Real.rpow_nonneg ht.1 (s-1))

/-- The normalized integral has the required exp(O(s)) upper bound uniformly in N. -/
theorem endpointIntegral_normalized_upper {N d : ℕ} (hN : 0 < N) (hd : 2 ≤ d)
    {s : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) :
    s*(N : ℝ)^(2*s)*endpointIntegral N d s ≤ Real.exp s := by
  have hn : 0 < (N : ℝ) := by exact_mod_cast hN
  have hn1 : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hdR : (2:ℝ) ≤ d := by exact_mod_cast hd
  have hden : 1 ≤ (d:ℝ)-s := by linarith
  have hsd : s < (d:ℝ) := by linarith
  let a : ℝ := ((N : ℝ)^2)⁻¹
  have ha : 0 < a := by dsimp [a]; positivity
  have ha1 : a ≤ 1 := by
    dsimp [a]
    apply inv_le_one_of_one_le₀
    nlinarith
  have hlow := endpointPrimitive_upper (d:=d) hN hs ha.le ha1
  have htail := endpointTailIntegral_upper (d:=d) hN hsd ha ha1
  have hidtail : (((N : ℝ)^2)^d)⁻¹*a^(s-(d:ℝ)) = a^s := by
    rw [Real.rpow_sub ha, Real.rpow_natCast]
    have haeq : (((N : ℝ)^2)^d)⁻¹ = a^d := by dsimp [a]; rw [inv_pow]
    rw [haeq]
    field_simp
  rw [hidtail] at htail
  have hsplit : endpointPrimitive N d s a + endpointTailIntegral N d s a = endpointIntegral N d s :=
    intervalIntegral.integral_add_adjacent_intervals
      (endpointKernel_weight_integrable N d hs 0 a) (endpointKernel_weight_integrable N d hs a 1)
  have hI : endpointIntegral N d s ≤ a^s/s+a^s/((d:ℝ)-s) := by linarith
  have hnorm := mul_le_mul_of_nonneg_left hI (show 0 ≤ s*(N : ℝ)^(2*s) by positivity)
  have hidpow : (N : ℝ)^(2*s)*a^s=1 := by
    have hnPow : (N : ℝ)^(2*s)=((N : ℝ)^2)^s := by
      simpa using Real.rpow_natCast_mul hn.le 2 s
    rw [hnPow, ← Real.mul_rpow (sq_nonneg (N:ℝ)) ha.le]
    have heq : (N : ℝ)^2*a=1 := by dsimp [a]; field_simp
    rw [heq, Real.one_rpow]
  have heval : s*(N : ℝ)^(2*s)*(a^s/s+a^s/((d:ℝ)-s)) = 1+s/((d:ℝ)-s) := by
    calc
      _ = (N : ℝ)^(2*s)*a^s + ((N : ℝ)^(2*s)*a^s)*(s/((d:ℝ)-s)) := by
        field_simp
      _ = _ := by rw [hidpow]; ring
  rw [heval] at hnorm
  have hfrac : s/((d:ℝ)-s) ≤ s := by
    apply (div_le_iff₀ (by linarith : 0<(d:ℝ)-s)).mpr
    nlinarith
  exact hnorm.trans ((by linarith : 1+s/((d:ℝ)-s) ≤ s+1).trans (Real.add_one_le_exp s))

/-- Complete logarithmic normalization part of the source endpoint-kernel lemma. -/
theorem endpointIntegral_normalization {N d : ℕ} (hN : 0 < N) (hd0 : 2 ≤ d) (hd1 : d ≤ 6)
    {s : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) :
    Real.exp (-(Real.log 12+1)*s) ≤ s*(N : ℝ)^(2*s)*endpointIntegral N d s ∧
      s*(N : ℝ)^(2*s)*endpointIntegral N d s ≤ Real.exp s :=
  ⟨endpointIntegral_normalized_lower hN hd1 hs, endpointIntegral_normalized_upper hN hd0 hs hs1⟩

lemma endpointProfile_complement {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) :
    1-endpointProfile N d s x = endpointTailIntegral N d s x / endpointIntegral N d s := by
  have hsplit := intervalIntegral.integral_add_adjacent_intervals
    (endpointKernel_weight_integrable N d hs 0 x) (endpointKernel_weight_integrable N d hs x 1)
  change endpointPrimitive N d s x+endpointTailIntegral N d s x=endpointIntegral N d s at hsplit
  have hi := (endpointIntegral_pos hN hd hs).ne'
  unfold endpointProfile
  field_simp
  linarith

lemma endpoint_scale_power_identity {N d : ℕ} (hN : 0 < N) {s x : ℝ} (hx : 0 < x) :
    (N : ℝ)^(2*s)*((((N : ℝ)^2)^d)⁻¹*x^(s-(d:ℝ))) =
      ((N : ℝ)^2*x)^(s-(d:ℝ)) := by
  have hn : 0 < (N:ℝ) := by exact_mod_cast hN
  have hp : (N : ℝ)^(2*s)=((N : ℝ)^2)^s := by
    simpa using Real.rpow_natCast_mul hn.le 2 s
  rw [hp, Real.mul_rpow (sq_nonneg (N:ℝ)) hx.le,
    Real.rpow_sub (sq_pos_of_pos hn), Real.rpow_natCast]
  ring

/-- Complete normalized tail bound, with an absolute constant for 2<=d<=6. -/
theorem endpointProfile_tail {N d : ℕ} (hN : 0 < N) (hd0 : 2 ≤ d) (hd1 : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hx : 0 < x) (hx1 : x ≤ 1) :
    1-endpointProfile N d s x ≤
      Real.exp (Real.log 12+1)*s*((N : ℝ)^2*x)^(s-(d:ℝ)) := by
  have hdR : (2:ℝ) ≤ d := by exact_mod_cast hd0
  have hden : 1 ≤ (d:ℝ)-s := by linarith
  have hI := endpointIntegral_pos hN hd1 hs
  have hP : 0 < (N : ℝ)^(2*s) := Real.rpow_pos_of_pos (by exact_mod_cast hN) _
  have htail := endpointTailIntegral_upper (d:=d) (s:=s) hN (by linarith) hx hx1
  have hb0 : 0 ≤ (((N : ℝ)^2)^d)⁻¹*x^(s-(d:ℝ)) := by positivity
  have htail' : endpointTailIntegral N d s x ≤ (((N : ℝ)^2)^d)⁻¹*x^(s-(d:ℝ)) := by
    apply htail.trans
    apply (div_le_iff₀ (by linarith : 0<(d:ℝ)-s)).mpr
    nlinarith
  have hnorm := endpointIntegral_normalized_lower hN hd1 hs
  have hexp := mul_le_mul_of_nonneg_left hnorm (Real.exp_pos ((Real.log 12+1)*s)).le
  have hexpid : Real.exp ((Real.log 12+1)*s)*Real.exp (-(Real.log 12+1)*s)=1 := by
    rw [← Real.exp_add]
    have hz : (Real.log 12+1)*s+(-(Real.log 12+1))*s=0 := by ring
    rw [hz,Real.exp_zero]
  rw [hexpid] at hexp
  have hCpos : 0 < Real.log 12+1 := by have h := Real.log_nonneg (by norm_num : (1:ℝ)≤12);linarith
  have hC := Real.exp_le_exp.mpr (mul_le_of_le_one_right hCpos.le hs1)
  have hexp' : 1 ≤ Real.exp (Real.log 12+1)*s*(N : ℝ)^(2*s)*endpointIntegral N d s := by
    have hmul := mul_le_mul_of_nonneg_right hC (show 0 ≤ s*(N : ℝ)^(2*s)*endpointIntegral N d s by positivity)
    nlinarith
  rw [endpointProfile_complement hN hd1 hs]
  apply (div_le_iff₀ hI).mpr
  apply htail'.trans
  have hmul := mul_le_mul_of_nonneg_left hexp' hb0
  calc
    _ ≤ ((((N : ℝ)^2)^d)⁻¹*x^(s-(d:ℝ))) *
        (Real.exp (Real.log 12+1)*s*(N : ℝ)^(2*s)*endpointIntegral N d s) := by simpa using hmul
    _ = Real.exp (Real.log 12+1)*s*((N : ℝ)^(2*s)*
        ((((N : ℝ)^2)^d)⁻¹*x^(s-(d:ℝ))))*endpointIntegral N d s := by ring
    _ = _ := by rw [endpoint_scale_power_identity hN hx]

lemma endpointPrimitive_mono (N d : ℕ) {s a b : ℝ} (hs : 0 < s)
    (ha : 0 ≤ a) (hab : a ≤ b) : endpointPrimitive N d s a ≤ endpointPrimitive N d s b := by
  apply intervalIntegral.integral_mono_interval le_rfl ha hab
  · filter_upwards [ae_restrict_mem measurableSet_Ioc] with t ht
    exact mul_nonneg (Real.rpow_nonneg ht.1.le _) (endpointKernel_nonneg N d t)
  · exact endpointKernel_weight_integrable N d hs 0 b

lemma endpointPrimitive_linear_lower {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) (hx : 0 < x) (hx1 : x ≤ 1) :
    x^s/s - 12*(N : ℝ)^2*x^(s+1)/(s+1) ≤ endpointPrimitive N d s x := by
  have hp0 : IntervalIntegrable (fun t:ℝ => t^(s-1)) volume 0 x :=
    intervalIntegral.intervalIntegrable_rpow' (by linarith)
  have hp1 : IntervalIntegrable (fun t:ℝ => t^s) volume 0 x :=
    intervalIntegral.intervalIntegrable_rpow' (by linarith)
  have hmono := intervalIntegral.integral_mono_on hx.le
    (hp0.sub (hp1.const_mul (12*(N : ℝ)^2)))
    (endpointKernel_weight_integrable N d hs 0 x) (fun t ht => ?_)
  · have heval : (∫ t in (0:ℝ)..x, t^(s-1)-12*(N : ℝ)^2*t^s) =
        x^s/s-12*(N : ℝ)^2*x^(s+1)/(s+1) := by
      rw [intervalIntegral.integral_sub hp0 (hp1.const_mul _), intervalIntegral.integral_const_mul,
        integral_rpow (Or.inl (by linarith : -1<s-1)),
        integral_rpow (Or.inl (by linarith : -1<s)), show s-1+1=s by ring,
        Real.zero_rpow hs.ne', Real.zero_rpow (by linarith : s+1 ≠ 0), sub_zero, sub_zero]
      ring
    rw [heval] at hmono
    exact hmono
  · have hk := endpointKernel_linear_deficit hN hd ht.1 (ht.2.trans hx1)
    have hmul := mul_le_mul_of_nonneg_left hk (Real.rpow_nonneg ht.1 (s-1))
    have hr : t^s=t^(s-1)*t := by
      simpa only [sub_add_cancel] using Real.rpow_add_one' ht.1 (show s-1+1 ≠ 0 by linarith)
    rw [hr]
    nlinarith

lemma endpointPrimitive_lower_local {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) (hx : 0 < x) (hx1 : x ≤ 1)
    (hy : (N : ℝ)^2*x ≤ 1) :
    (x/12)^s/(s*(s+1)) ≤ endpointPrimitive N d s x := by
  let a : ℝ := x/12
  have ha : 0 < a := by dsimp [a]; positivity
  have hax : a ≤ x := by dsimp [a]; linarith
  have ha1 : a ≤ 1 := hax.trans hx1
  have hca : 12*(N : ℝ)^2*a ≤ 1 := by dsimp [a]; nlinarith
  have hlower := endpointPrimitive_linear_lower hN hd hs ha ha1
  have heval : a^s/s-12*(N : ℝ)^2*a^(s+1)/(s+1) =
      a^s*(s+1-12*(N : ℝ)^2*a*s)/(s*(s+1)) := by
    rw [Real.rpow_add_one ha.ne']
    field_simp
  rw [heval] at hlower
  have hbound : a^s/(s*(s+1)) ≤ a^s*(s+1-12*(N : ℝ)^2*a*s)/(s*(s+1)) := by
    apply div_le_div_of_nonneg_right _ (by positivity : 0 ≤ s*(s+1))
    have hp : 0 ≤ a^s := Real.rpow_nonneg ha.le s
    have hcoeff : 1 ≤ s+1-12*(N : ℝ)^2*a*s := by nlinarith
    nlinarith
  exact (hbound.trans hlower).trans (endpointPrimitive_mono N d hs ha.le hax)

lemma endpoint_scale_power {N : ℕ} (hN : 0 < N) {s x : ℝ} (hx : 0 ≤ x) :
    (N : ℝ)^(2*s)*x^s=((N : ℝ)^2*x)^s := by
  have hn : 0 ≤ (N:ℝ) := by exact_mod_cast hN.le
  have hp : (N : ℝ)^(2*s)=((N : ℝ)^2)^s := by
    simpa using Real.rpow_natCast_mul hn 2 s
  rw [hp, Real.mul_rpow (sq_nonneg (N:ℝ)) hx]

/-- Local power upper bound, with the required O(s) logarithmic error. -/
theorem endpointProfile_upper_power {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    endpointProfile N d s x ≤ Real.exp ((Real.log 12+1)*s)*((N : ℝ)^2*x)^s := by
  have hI := endpointIntegral_pos hN hd hs
  have hnorm := endpointIntegral_normalized_lower hN hd hs
  have he := mul_le_mul_of_nonneg_left hnorm (Real.exp_pos ((Real.log 12+1)*s)).le
  have heid : Real.exp ((Real.log 12+1)*s)*Real.exp (-(Real.log 12+1)*s)=1 := by
    rw [←Real.exp_add]
    have hz : (Real.log 12+1)*s+(-(Real.log 12+1))*s=0 := by ring
    rw [hz,Real.exp_zero]
  rw [heid] at he
  unfold endpointProfile
  apply (div_le_iff₀ hI).mpr
  apply (endpointPrimitive_upper hN hs hx hx1).trans
  have hm := mul_le_mul_of_nonneg_left he (show 0 ≤ x^s/s by positivity)
  calc
    _ ≤ x^s/s*(Real.exp ((Real.log 12+1)*s)*(s*(N : ℝ)^(2*s)*endpointIntegral N d s)) := by
      simpa using hm
    _ = Real.exp ((Real.log 12+1)*s)*((N : ℝ)^(2*s)*x^s)*endpointIntegral N d s := by
      field_simp
    _ = _ := by rw [endpoint_scale_power hN hx]

/-- Local lower power bound for the actual normalized integral. -/
theorem endpointProfile_lower_power {N d : ℕ} (hN : 0 < N) (hd0 : 2 ≤ d) (hd1 : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hx : 0 < x) (hx1 : x ≤ 1)
    (hy : (N : ℝ)^2*x ≤ 1) :
    Real.exp (-(Real.log 12+2)*s)*((N : ℝ)^2*x)^s ≤ endpointProfile N d s x := by
  have hI := endpointIntegral_pos hN hd1 hs
  have hNp : 0 < (N : ℝ)^(2*s) := Real.rpow_pos_of_pos (by exact_mod_cast hN) _
  have hnorm := endpointIntegral_normalized_upper hN hd0 hs hs1
  have hfactor : Real.exp (-(Real.log 12+2)*s)*Real.exp s ≤ (12:ℝ)^(-s)/(s+1) := by
    have he : Real.exp (-s) ≤ 1/(s+1) := by
      rw [Real.exp_neg]
      simpa only [one_div] using one_div_le_one_div_of_le
        (by linarith : 0<s+1) (Real.add_one_le_exp s)
    have hm := mul_le_mul_of_nonneg_left he (Real.rpow_pos_of_pos (by norm_num : (0:ℝ)<12) (-s)).le
    have hid : Real.exp (-(Real.log 12+2)*s)*Real.exp s = (12:ℝ)^(-s)*Real.exp (-s) := by
      rw [Real.rpow_def_of_pos (by norm_num : (0:ℝ)<12)]
      simp only [←Real.exp_add]
      congr 1
      ring
    rw [hid]
    simpa only [div_eq_mul_inv, one_mul] using hm
  have hscale : ((N : ℝ)^2*x)^s*(12:ℝ)^(-s) = (N : ℝ)^(2*s)*(x/12)^s := by
    rw [←endpoint_scale_power hN hx.le, Real.div_rpow hx.le (by norm_num : (0:ℝ)≤12),
      Real.rpow_neg (by norm_num : (0:ℝ)≤12)]
    ring
  have hnormmul := mul_le_mul_of_nonneg_left hnorm
    (show 0 ≤ Real.exp (-(Real.log 12+2)*s)*((N : ℝ)^2*x)^s by positivity)
  have hfactor' := mul_le_mul_of_nonneg_left hfactor
    (Real.rpow_nonneg (show 0 ≤ (N : ℝ)^2*x by positivity) s)
  have hstep : s*(N : ℝ)^(2*s)*
      (Real.exp (-(Real.log 12+2)*s)*((N : ℝ)^2*x)^s*endpointIntegral N d s) ≤
      s*(N : ℝ)^(2*s)*((x/12)^s/(s*(s+1))) := by
    calc
      _ = Real.exp (-(Real.log 12+2)*s)*((N : ℝ)^2*x)^s*
          (s*(N : ℝ)^(2*s)*endpointIntegral N d s) := by ring
      _ ≤ Real.exp (-(Real.log 12+2)*s)*((N : ℝ)^2*x)^s*Real.exp s := hnormmul
      _ ≤ ((N : ℝ)^2*x)^s*((12:ℝ)^(-s)/(s+1)) := by nlinarith [hfactor']
      _ = (N : ℝ)^(2*s)*(x/12)^s/(s+1) := by rw [←mul_div_assoc,hscale]
      _ = _ := by field_simp
  have hstep' := (mul_le_mul_iff_right₀ (mul_pos hs hNp)).mp hstep
  unfold endpointProfile
  apply (le_div_iff₀ hI).mpr
  exact hstep'.trans (endpointPrimitive_lower_local hN hd1 hs hx hx1 hy)

/-- The source local normalized-integral comparison, with explicit absolute constants. -/
theorem endpointProfile_local_power {N d : ℕ} (hN : 0 < N) (hd0 : 2 ≤ d) (hd1 : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hx : 0 < x) (hx1 : x ≤ 1)
    (hy : (N : ℝ)^2*x ≤ 1) :
    Real.exp (-(Real.log 12+2)*s)*((N : ℝ)^2*x)^s ≤ endpointProfile N d s x ∧
      endpointProfile N d s x ≤ Real.exp ((Real.log 12+1)*s)*((N : ℝ)^2*x)^s :=
  ⟨endpointProfile_lower_power hN hd0 hd1 hs hs1 hx hx1 hy,
    endpointProfile_upper_power hN hd1 hs hx.le hx1⟩

lemma endpointProfile_mono {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s a b : ℝ} (hs : 0 < s) (ha : 0 ≤ a) (hab : a ≤ b) :
    endpointProfile N d s a ≤ endpointProfile N d s b := by
  exact div_le_div_of_nonneg_right (endpointPrimitive_mono N d hs ha hab)
    (endpointIntegral_pos hN hd hs).le

/-- Complete normalized profile floor beyond the endpoint scale. -/
theorem endpointProfile_floor {N d : ℕ} (hN : 0 < N) (hd0 : 2 ≤ d) (hd1 : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (_hx : 0 < x) (hx1 : x ≤ 1)
    (hy : 1 ≤ (N : ℝ)^2*x) :
    Real.exp (-(Real.log 12+2)*s) ≤ endpointProfile N d s x := by
  have hn : (1:ℝ) ≤ N := by exact_mod_cast hN
  let a : ℝ := ((N : ℝ)^2)⁻¹
  have ha : 0 < a := by dsimp [a]; positivity
  have ha1 : a ≤ 1 := by
    dsimp [a]
    apply inv_le_one_of_one_le₀
    nlinarith
  have hascale : (N : ℝ)^2*a=1 := by dsimp [a];field_simp
  have hax : a ≤ x := by
    apply (mul_le_mul_iff_right₀ (by positivity : 0<(N : ℝ)^2)).mp
    rw [hascale]
    exact hy
  have hlocal := endpointProfile_lower_power hN hd0 hd1 hs hs1 ha ha1 (by rw [hascale])
  rw [hascale,Real.one_rpow,mul_one] at hlocal
  exact hlocal.trans (endpointProfile_mono hN hd1 hs ha.le hax)

lemma endpoint_cos_quadratic_upper {u : ℝ} (hu : 0 ≤ u) (hu1 : u ≤ 3/2) :
    Real.cos u ≤ 1-u^2/3 := by
  rcases hu.eq_or_lt with rfl | hu
  · simp
  have hsin := (Real.sin_gt_sub_cube (by linarith : 0<u/2) (by linarith : u/2≤1)).le
  have hsq : u^2 ≤ 9/4 := by nlinarith
  have hcube : u^3 ≤ (9/4)*u := by nlinarith [mul_nonneg (by nlinarith : 0≤9/4-u^2) hu.le]
  have hsin' : 5*u/12 ≤ Real.sin (u/2) := by nlinarith
  have hprod := mul_nonneg (sub_nonneg.mpr hsin') (show 0≤Real.sin (u/2)+5*u/12 by linarith)
  have hcos := Real.cos_two_mul (u/2)
  rw [show 2*(u/2)=u by ring] at hcos
  nlinarith [Real.sin_sq_add_cos_sq (u/2)]

lemma endpoint_sin_cubic_upper {t : ℝ} (ht : 0 ≤ t) (ht1 : t ≤ 3/2) :
    Real.sin t ≤ t-t^3/9 := by
  have hc : IntervalIntegrable Real.cos volume 0 t := Real.continuous_cos.intervalIntegrable _ _
  have hp : IntervalIntegrable (fun u:ℝ => 1-u^2/3) volume 0 t :=
    (continuous_const.sub ((continuous_id.pow 2).div_const 3)).intervalIntegrable _ _
  have hmono := intervalIntegral.integral_mono_on ht hc hp
    (fun u hu => endpoint_cos_quadratic_upper hu.1 (hu.2.trans ht1))
  have hcosI : (∫ u in (0:ℝ)..t,Real.cos u)=Real.sin t := by simp
  have hpolyI : (∫ u in (0:ℝ)..t,1-u^2/3)=t-t^3/9 := by
    have hconst : IntervalIntegrable (fun _:ℝ => (1:ℝ)) volume 0 t := intervalIntegrable_const
    have hp2 : IntervalIntegrable (fun u:ℝ => u^2/3) volume 0 t :=
      ((continuous_id.pow 2).div_const 3).intervalIntegrable _ _
    rw [intervalIntegral.integral_sub hconst hp2,
      intervalIntegral.integral_div, integral_pow]
    simp
    ring
  rw [hcosI,hpolyI] at hmono
  exact hmono

/-- A uniform strict upper bound before the endpoint-scaled coordinate reaches 5/4. -/
theorem endpoint_chebyshev_local_upper {N : ℕ} (hN : 2 ≤ N) {x : ℝ}
    (hx : 0 < x) (hx1 : x ≤ 1) (hy : (N : ℝ)^2*x ≤ 5/4) :
    (Polynomial.Chebyshev.U ℝ ((N : ℤ)-1)).eval (Real.sqrt (1-x)) / N ≤
      1-(N : ℝ)^2*x/32 := by
  have hn : (2:ℝ) ≤ N := by exact_mod_cast hN
  have hn0 : 0 < (N:ℝ) := by linarith
  have hsqrt := Real.sqrt_nonneg x
  have hsqrtpos := Real.sqrt_pos.mpr hx
  have hsqrteq := Real.sq_sqrt hx.le
  have hN2 : (4:ℝ) ≤ (N:ℝ)^2 := by nlinarith only [hn]
  have hN2x := mul_le_mul_of_nonneg_right hN2 hx.le
  have hxsmall : x ≤ 5/16 := by nlinarith only [hN2x,hy]
  have hroot : Real.sqrt x ≤ 3/4 := by nlinarith only [hsqrt,hsqrteq,hxsmall]
  have hsin1 : (3/4:ℝ) ≤ Real.sin 1 := by
    have h := Real.sin_gt_sub_cube (by norm_num : (0:ℝ)<1) (by norm_num : (1:ℝ)≤1)
    norm_num at h
    exact h.le
  have hθ1 : endpointAngle x ≤ 1 := by
    apply (Real.arcsin_le_iff_le_sin ⟨by linarith only [hsqrt], by linarith only [hroot]⟩
      ⟨by nlinarith only [Real.pi_gt_three], by nlinarith only [Real.pi_gt_three]⟩).mpr
    exact hroot.trans hsin1
  have hθ0 : 0 < endpointAngle x := hsqrtpos.trans_le (endpointAngle_ge_sqrt hx.le hx1)
  have hθsin := (Real.sin_gt_sub_cube hθ0 hθ1).le
  rw [endpointAngle_sin hx.le hx1] at hθsin
  have hθsq : endpointAngle x^2 ≤ 1 := by nlinarith only [hθ0,hθ1]
  have hθcube : endpointAngle x^3 ≤ endpointAngle x := by
    nlinarith only [mul_nonneg (sub_nonneg.mpr hθsq) hθ0.le]
  have hθbound : endpointAngle x ≤ 4/3*Real.sqrt x := by nlinarith only [hθsin,hθcube]
  let t : ℝ := (N:ℝ)*endpointAngle x
  have ht : 0 < t := mul_pos hn0 hθ0
  have htsq : t^2 ≤ 16/9*((N:ℝ)^2*x) := by
    have hsq := pow_le_pow_left₀ hθ0.le hθbound 2
    have hmul := mul_le_mul_of_nonneg_left hsq (sq_nonneg (N:ℝ))
    dsimp [t]
    nlinarith only [hmul,hsqrteq]
  have ht1 : t ≤ 3/2 := by nlinarith only [ht,htsq,hy]
  have hθtsq : 4*endpointAngle x^2 ≤ t^2 := by
    have hmul := mul_nonneg (show 0≤(N:ℝ)^2-4 by linarith only [hN2]) (sq_nonneg (endpointAngle x))
    dsimp [t]
    nlinarith only [hmul]
  have hylo : (N:ℝ)^2*x ≤ t^2 := by
    have hsq := pow_le_pow_left₀ hsqrt (endpointAngle_ge_sqrt hx.le hx1) 2
    have hmul := mul_le_mul_of_nonneg_left hsq (sq_nonneg (N:ℝ))
    dsimp [t]
    nlinarith only [hmul,hsqrteq]
  have hD : t*(1-t^2/16) ≤ (N:ℝ)*Real.sqrt x := by
    have hmul := mul_le_mul_of_nonneg_left hθsin hn0.le
    have hmul' := mul_le_mul_of_nonneg_left hθtsq ht.le
    have hm : t*(1-endpointAngle x^2/4) ≤ (N:ℝ)*Real.sqrt x := by
      convert hmul using 1; dsimp [t]; ring
    nlinarith only [hm,hmul']
  have hu : 0 ≤ 1-t^2/32 := by nlinarith only [ht,ht1]
  have hmult := mul_le_mul_of_nonneg_left hD hu
  have hpoly : t-t^3/9 ≤ (1-t^2/32)*(t*(1-t^2/16)) := by
    have hp : 0 ≤ t^3*(5/288+t^2/512) := by positivity
    nlinarith only [hp]
  have hsinupper := endpoint_sin_cubic_upper ht.le ht1
  have hratio : Real.sin t / ((N:ℝ)*Real.sqrt x) ≤ 1-t^2/32 := by
    apply (div_le_iff₀ (mul_pos hn0 hsqrtpos)).mpr
    nlinarith only [hsinupper,hpoly,hmult]
  have hsine := endpoint_chebyshev_sine hx.le hx1 N
  have hid : (Polynomial.Chebyshev.U ℝ ((N : ℤ)-1)).eval (Real.sqrt (1-x))/N =
      Real.sin t/((N:ℝ)*Real.sqrt x) := by
    dsimp [t]
    rw [←hsine]
    field_simp
  rw [hid]
  exact hratio.trans (by nlinarith only [hylo])

/-- Local exponential upper bound for the actual kernel, uniformly in N and d. -/
theorem endpointKernel_local_exp_upper {N d : ℕ} (hN : 2 ≤ N) (hd : 1 ≤ d)
    {x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1) (hy : (N : ℝ)^2*x ≤ 5/4) :
    endpointKernel N d x ≤ Real.exp (-((N : ℝ)^2*x)/32) := by
  rcases hx.eq_or_lt with rfl | hx
  · simp [endpointKernel_zero (by omega : 0<N) d]
  have hn : 0 < (N:ℝ) := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_two hN)
  have hsqrt := Real.sqrt_nonneg x
  have hθ := endpointAngle_nonneg (x:=x)
  have hθhi := endpointAngle_le_two_sqrt hx.le hx1
  have hsq := pow_le_pow_left₀ hθ hθhi 2
  have hsq' := mul_le_mul_of_nonneg_left hsq (sq_nonneg (N:ℝ))
  have ht0 : 0 ≤ (N:ℝ)*endpointAngle x := mul_nonneg hn.le hθ
  have ht3 : (N:ℝ)*endpointAngle x ≤ 3 := by nlinarith only [hsq',hy,Real.sq_sqrt hx.le,ht0]
  have hsin := Real.sin_nonneg_of_nonneg_of_le_pi ht0 (ht3.trans Real.pi_gt_three.le)
  have hsine := endpoint_chebyshev_sine hx.le hx1 N
  have hU0 : 0 ≤ (Polynomial.Chebyshev.U ℝ ((N : ℤ)-1)).eval (Real.sqrt (1-x)) := by
    have hspos := Real.sqrt_pos.mpr hx
    nlinarith only [hsine,hsin,hspos]
  have hq0 := div_nonneg hU0 hn.le
  have hq := endpoint_chebyshev_local_upper hN hx hx1 hy
  have hq1 : (Polynomial.Chebyshev.U ℝ ((N : ℤ)-1)).eval (Real.sqrt (1-x))/N ≤ 1 := by
    nlinarith only [hq,mul_nonneg (sq_nonneg (N:ℝ)) hx.le]
  have hpow := pow_le_pow_of_le_one hq0 hq1 (show 1 ≤ 2*d by omega)
  have hexp := Real.add_one_le_exp (-((N : ℝ)^2*x)/32)
  unfold endpointKernel
  have hpow' : ((Polynomial.Chebyshev.U ℝ ((N : ℤ)-1)).eval (Real.sqrt (1-x))/N)^(2*d) ≤
      (Polynomial.Chebyshev.U ℝ ((N : ℤ)-1)).eval (Real.sqrt (1-x))/N := by
    simpa only [pow_one] using hpow
  exact hpow'.trans (hq.trans (by linarith only [hexp]))

/-- The source uniform gap away from the endpoint, with explicit y0=1/4. -/
theorem endpointKernel_uniform_gap {N d : ℕ} (hN : 2 ≤ N) (hd : 1 ≤ d)
    {x : ℝ} (hx : 0 < x) (hx1 : x ≤ 1) (hy : 1/4 ≤ (N : ℝ)^2*x) :
    endpointKernel N d x ≤ Real.exp (-(1:ℝ)/128) := by
  by_cases hy1 : (N : ℝ)^2*x ≤ 5/4
  · exact (endpointKernel_local_exp_upper hN hd hx.le hx1 hy1).trans
      (Real.exp_le_exp.mpr (by linarith only [hy]))
  · have hN0 : 0<N := by omega
    have hy0 : 0 < (N:ℝ)^2*x := by positivity
    have hinv : ((N:ℝ)^2*x)⁻¹ ≤ 4/5 := by
      rw [←one_div]
      apply (div_le_iff₀ hy0).mpr
      linarith only [hy1]
    have hinv0 : 0 ≤ ((N:ℝ)^2*x)⁻¹ := by positivity
    have hpow := pow_le_pow_of_le_one hinv0 (show ((N:ℝ)^2*x)⁻¹ ≤ 1 by linarith) hd
    have htail := endpointKernel_le_inverse_power hN0 d hx hx1
    have he := Real.add_one_le_exp (-(1:ℝ)/128)
    exact (htail.trans (by simpa only [pow_one] using hpow)).trans (hinv.trans (by linarith only [he]))

lemma endpoint_exp_weight_max {s y : ℝ} (hs : 0 < s) (hy : 0 < y) :
    y^s*Real.exp (-y/32) ≤ (32*s)^s := by
  have h32 : 0 < 32*s := by positivity
  have hlog := Real.log_le_sub_one_of_pos (div_pos hy h32)
  rw [Real.log_div hy.ne' h32.ne'] at hlog
  have hm := mul_le_mul_of_nonneg_left hlog hs.le
  have hid : s*(y/(32*s)-1)=y/32-s := by field_simp
  rw [hid] at hm
  rw [Real.rpow_def_of_pos hy, Real.rpow_def_of_pos h32, ←Real.exp_add]
  apply Real.exp_le_exp.mpr
  nlinarith only [hm,hs]

lemma endpoint_scaled_power_floor {s : ℝ} (hs : 0 < s) :
    (31/32:ℝ) ≤ (32*s)^s := by
  have hp : 0 < 32*s := by positivity
  have hlog := Real.one_sub_inv_le_log_of_pos hp
  have hm := mul_le_mul_of_nonneg_left hlog hs.le
  have hid : s*(1-(32*s)⁻¹)=s-1/32 := by field_simp
  rw [hid] at hm
  have he := Real.exp_le_exp.mpr (show -(1:ℝ)/32 ≤ Real.log (32*s)*s by nlinarith only [hm,hs])
  rw [←Real.rpow_def_of_pos hp] at he
  have hfloor := Real.add_one_le_exp (-(1:ℝ)/32)
  exact (by linarith only [hfloor] : (31/32:ℝ) ≤ Real.exp (-(1:ℝ)/32)).trans he

/-- Sharp upper maximum scale of the actual Chebyshev kernel. -/
theorem endpointKernel_sharp_weight_upper {N d : ℕ} (hN : 2 ≤ N) (hd : 2 ≤ d)
    {s x : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    (N : ℝ)^(2*s)*(x^s*endpointKernel N d x) ≤ (32*s)^s := by
  rcases hx.eq_or_lt with rfl | hx
  · simp only [Real.zero_rpow hs.ne',zero_mul,mul_zero]
    positivity
  have hN0 : 0<N := by omega
  have hd1 : 1≤d := by omega
  have hy0 : 0 < (N:ℝ)^2*x := by positivity
  have hscale : (N : ℝ)^(2*s)*(x^s*endpointKernel N d x) =
      ((N:ℝ)^2*x)^s*endpointKernel N d x := by
    rw [←endpoint_scale_power hN0 hx.le]
    ring
  rw [hscale]
  by_cases hy : (N:ℝ)^2*x ≤ 5/4
  · exact (mul_le_mul_of_nonneg_left (endpointKernel_local_exp_upper hN hd1 hx.le hx1 hy)
      (Real.rpow_nonneg hy0.le s)).trans (endpoint_exp_weight_max hs hy0)
  · have hy1 : 1 ≤ (N:ℝ)^2*x := by linarith only [hy]
    have htail := endpointKernel_le_inverse_power hN0 d hx hx1
    have hmul := mul_le_mul_of_nonneg_left htail (Real.rpow_nonneg hy0.le s)
    have hid : ((N:ℝ)^2*x)^s*(((N:ℝ)^2*x)⁻¹)^d = ((N:ℝ)^2*x)^(s-(d:ℝ)) := by
      rw [Real.rpow_sub hy0,Real.rpow_natCast,inv_pow]
      field_simp
    rw [hid] at hmul
    have hdR : (2:ℝ) ≤ d := by exact_mod_cast hd
    have hexp := Real.rpow_le_rpow_of_exponent_le hy1 (show s-(d:ℝ) ≤ -1 by linarith only [hs1,hdR])
    rw [Real.rpow_neg_one] at hexp
    have hinv : ((N:ℝ)^2*x)⁻¹ ≤ 4/5 := by
      rw [←one_div]
      apply (div_le_iff₀ hy0).mpr
      linarith only [hy]
    exact (hmul.trans hexp).trans (hinv.trans (by linarith only [endpoint_scaled_power_floor hs]))

lemma endpoint_exp_neg_le_half {s : ℝ} (hs : 0 ≤ s) (hs1 : s ≤ 1) :
    Real.exp (-s) ≤ 1-s/2 := by
  rw [Real.exp_neg,inv_eq_one_div]
  calc
    _ ≤ 1/(1+s) := one_div_le_one_div_of_le (by linarith)
      (by simpa only [add_comm] using Real.add_one_le_exp s)
    _ ≤ 1-s/2 := by
      apply (div_le_iff₀ (by linarith : 0<1+s)).mpr
      nlinarith only [mul_nonneg hs (sub_nonneg.mpr hs1)]

/-- The lower sharp-maximum witness occurs on the correct s/N² scale. -/
theorem endpointKernel_sharp_weight_witness {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) :
    ∃ x ∈ Icc (0:ℝ) 1, (s/24)^s*Real.exp (-s) ≤
      (N : ℝ)^(2*s)*(x^s*endpointKernel N d x) := by
  let x : ℝ := s/(24*(N:ℝ)^2)
  have hn : (1:ℝ) ≤ N := by exact_mod_cast hN
  have hden : 0 < 24*(N:ℝ)^2 := by positivity
  have hx : 0 < x := div_pos hs hden
  have hx1 : x ≤ 1 := by
    apply (div_le_one hden).mpr
    nlinarith only [hs1,hn]
  have hscale : (N:ℝ)^2*x=s/24 := by dsimp [x];field_simp
  have hK := endpointKernel_linear_deficit hN hd hx.le hx1
  rw [mul_assoc 12 ((N:ℝ)^2) x,hscale] at hK
  have hlow : Real.exp (-s) ≤ endpointKernel N d x :=
    (endpoint_exp_neg_le_half hs.le hs1).trans (by linarith only [hK])
  refine ⟨x,⟨hx.le,hx1⟩,?_⟩
  calc
    _ ≤ (s/24)^s*endpointKernel N d x := mul_le_mul_of_nonneg_left hlow (by positivity)
    _ = _ := by rw [←hscale,←endpoint_scale_power hN hx.le];ring

/-- Complete sharp-maximum assertion as a witness plus a uniform upper bound. -/
theorem endpointKernel_sharp_maximum {N d : ℕ} (hN : 2 ≤ N) (hd0 : 2 ≤ d) (hd1 : d ≤ 6)
    {s : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) :
    (∃ x ∈ Icc (0:ℝ) 1, (s/24)^s*Real.exp (-s) ≤
      (N:ℝ)^(2*s)*(x^s*endpointKernel N d x)) ∧
    (∀ x ∈ Icc (0:ℝ) 1, (N:ℝ)^(2*s)*(x^s*endpointKernel N d x) ≤ (32*s)^s) := by
  exact ⟨endpointKernel_sharp_weight_witness (by omega) hd1 hs hs1,
    fun _x hx => endpointKernel_sharp_weight_upper hN hd0 hs hs1 hx.1 hx.2⟩

/-- The matching local exponential lower bound uses the actual linear deficit. -/
theorem endpointKernel_local_exp_lower {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1) (hy : (N:ℝ)^2*x ≤ 1/24) :
    Real.exp (-24*((N:ℝ)^2*x)) ≤ endpointKernel N d x := by
  have hy0 : 0 ≤ (N:ℝ)^2*x := by positivity
  have he := endpoint_exp_neg_le_half (show 0≤24*((N:ℝ)^2*x) by positivity)
    (show 24*((N:ℝ)^2*x)≤1 by linarith only [hy])
  have hk := endpointKernel_linear_deficit hN hd hx hx1
  calc
    _ = Real.exp (-(24*((N:ℝ)^2*x))) := by congr 1;ring
    _ ≤ 1-24*((N:ℝ)^2*x)/2 := he
    _ ≤ _ := by nlinarith only [hk]

/-- Uniform strict gap at any fixed scaled distance at most one. -/
theorem endpointKernel_uniform_gap_scale {N d : ℕ} (hN : 2 ≤ N) (hd : 1 ≤ d)
    {x η : ℝ} (hx : 0 < x) (hx1 : x ≤ 1) (_hη : 0 < η) (hη1 : η ≤ 1)
    (hy : η ≤ (N:ℝ)^2*x) : endpointKernel N d x ≤ Real.exp (-η/32) := by
  by_cases hy1 : (N:ℝ)^2*x ≤ 5/4
  · exact (endpointKernel_local_exp_upper hN hd hx.le hx1 hy1).trans
      (Real.exp_le_exp.mpr (by linarith only [hy]))
  · have hN0 : 0<N := by omega
    have hy0 : 0 < (N:ℝ)^2*x := by positivity
    have hinv : ((N:ℝ)^2*x)⁻¹ ≤ 4/5 := by
      rw [←one_div]
      apply (div_le_iff₀ hy0).mpr
      linarith only [hy1]
    have hinv0 : 0 ≤ ((N:ℝ)^2*x)⁻¹ := by positivity
    have hpow := pow_le_pow_of_le_one hinv0 (show ((N:ℝ)^2*x)⁻¹ ≤ 1 by linarith only [hinv]) hd
    have htail := endpointKernel_le_inverse_power hN0 d hx hx1
    have he := Real.add_one_le_exp (-η/32)
    exact (htail.trans (by simpa only [pow_one] using hpow)).trans
      (hinv.trans (by linarith only [he,hη1]))

lemma endpointAngle_scaled_le_three_halves {N : ℕ} (hN : 2≤N) {x : ℝ}
    (hx : 0<x) (hx1 : x≤1) (hy : (N:ℝ)^2*x≤5/4) :
    (N:ℝ)*endpointAngle x≤3/2 := by
  have hn : (2:ℝ)≤N := by exact_mod_cast hN
  have hN2 : (4:ℝ)≤(N:ℝ)^2 := by nlinarith only [hn]
  have hNx := mul_le_mul_of_nonneg_right hN2 hx.le
  have hxsmall : x≤5/16 := by nlinarith only [hNx,hy]
  have hr0 := Real.sqrt_nonneg x
  have hrpos := Real.sqrt_pos.mpr hx
  have hrsq := Real.sq_sqrt hx.le
  have hr : Real.sqrt x≤3/4 := by nlinarith only [hr0,hrsq,hxsmall]
  have hsin1 : (3/4:ℝ)≤Real.sin 1 := by
    have h := Real.sin_gt_sub_cube (by norm_num : (0:ℝ)<1) (by norm_num : (1:ℝ)≤1)
    norm_num at h
    exact h.le
  have hθ1 : endpointAngle x≤1 := by
    apply (Real.arcsin_le_iff_le_sin ⟨by linarith only [hr0],by linarith only [hr]⟩
      ⟨by nlinarith only [Real.pi_gt_three],by nlinarith only [Real.pi_gt_three]⟩).mpr
    exact hr.trans hsin1
  have hθ0 := hrpos.trans_le (endpointAngle_ge_sqrt hx.le hx1)
  have hsin := (Real.sin_gt_sub_cube hθ0 hθ1).le
  rw [endpointAngle_sin hx.le hx1] at hsin
  have hsquare : endpointAngle x^2≤1 := by nlinarith only [hθ0,hθ1]
  have hcube : endpointAngle x^3≤endpointAngle x := by
    nlinarith only [mul_nonneg (sub_nonneg.mpr hsquare) hθ0.le]
  have hb : endpointAngle x≤4/3*Real.sqrt x := by nlinarith only [hsin,hcube]
  have hsq := mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hθ0.le hb 2) (sq_nonneg (N:ℝ))
  have ht0 : 0≤(N:ℝ)*endpointAngle x := mul_nonneg (by linarith only [hn]) hθ0.le
  nlinarith only [hsq,hrsq,hy,ht0]

lemma endpoint_chebyshev_half_lower {N : ℕ} (hN : 2≤N) {x : ℝ}
    (hx : 0<x) (hx1 : x≤1) (hy : (N:ℝ)^2*x≤5/4) :
    (1/2:ℝ) ≤ (Polynomial.Chebyshev.U ℝ ((N:ℤ)-1)).eval (Real.sqrt (1-x))/N := by
  have hn : 0<(N:ℝ) := by exact_mod_cast (show 0<N by omega)
  have hθ := endpointAngle_nonneg (x:=x)
  have ht0 : 0≤(N:ℝ)*endpointAngle x := mul_nonneg hn.le hθ
  have htb := endpointAngle_scaled_le_three_halves hN hx hx1 hy
  have htpi : (N:ℝ)*endpointAngle x≤Real.pi/2 := by nlinarith only [htb,Real.pi_gt_three]
  have hsine := Real.mul_le_sin ht0 htpi
  have hhalf : (1/2:ℝ) ≤ 2/Real.pi := by
    apply (le_div_iff₀ Real.pi_pos).mpr
    nlinarith only [Real.pi_lt_four]
  have hθlo := endpointAngle_ge_sqrt hx.le hx1
  have hm := mul_le_mul_of_nonneg_left hθlo hn.le
  have hm' := mul_le_mul_of_nonneg_right hhalf (mul_nonneg hn.le (Real.sqrt_nonneg x))
  have hm'' := mul_le_mul_of_nonneg_left hm (show 0≤2/Real.pi by positivity)
  have hidentity := endpoint_chebyshev_sine hx.le hx1 N
  have hrootpos := Real.sqrt_pos.mpr hx
  apply (le_div_iff₀ hn).mpr
  nlinarith only [hsine,hm',hm'',hidentity,hrootpos]

/-- A fixed positive lower kernel bound throughout the endpoint-scaled unit interval. -/
theorem endpointKernel_unit_scale_lower {N d : ℕ} (hN : 2≤N) (hd : d≤6)
    {x : ℝ} (hx : 0≤x) (hx1 : x≤1) (hy : (N:ℝ)^2*x≤1) :
    ((1/2:ℝ)^12) ≤ endpointKernel N d x := by
  rcases hx.eq_or_lt with rfl | hx
  · rw [endpointKernel_zero (by omega) d]
    norm_num
  have hq := endpoint_chebyshev_half_lower hN hx hx1 (by linarith only [hy])
  have hp := pow_le_pow_left₀ (by norm_num : (0:ℝ)≤1/2) hq (2*d)
  have hexp := pow_le_pow_of_le_one (by norm_num : (0:ℝ)≤1/2) (by norm_num : (1/2:ℝ)≤1)
    (show 2*d≤12 by omega)
  exact hexp.trans hp

/-- Kernel lower bound at every local profile scale y<=s, with error linear in s. -/
theorem endpointKernel_profile_local_lower {N d : ℕ} (hN : 2≤N) (hd : d≤6)
    {s x : ℝ} (hs : 0<s) (hs1 : s≤1) (hx : 0≤x) (hx1 : x≤1)
    (hy : (N:ℝ)^2*x≤s) :
    Real.exp (-288*s) ≤ endpointKernel N d x := by
  by_cases hsmall : (N:ℝ)^2*x≤1/24
  · exact (Real.exp_le_exp.mpr (by nlinarith only [hy,hs])).trans
      (endpointKernel_local_exp_lower (by omega) hd hx hx1 hsmall)
  · have he1 : Real.exp (-1:ℝ)≤1/2 := by
      rw [Real.exp_neg]
      simpa only [one_div] using one_div_le_one_div_of_le (by norm_num : (0:ℝ)<2)
        (by linarith only [Real.add_one_le_exp 1])
    have hp := pow_le_pow_left₀ (Real.exp_pos (-1)).le he1 12
    have heq : (Real.exp (-1:ℝ))^12=Real.exp (-12:ℝ) := by
      rw [←Real.exp_nat_mul]
      norm_num
    rw [heq] at hp
    have hslarge : (1/24:ℝ)≤s := by linarith only [hsmall,hy]
    exact (Real.exp_le_exp.mpr (by nlinarith only [hslarge])).trans
      (hp.trans (endpointKernel_unit_scale_lower hN hd hx hx1 (hy.trans hs1)))

lemma endpoint_self_power_lower {s : ℝ} (hs : 0<s) : Real.exp (-1:ℝ)≤s^s := by
  have hlog := Real.neg_inv_le_log hs.le
  have hm := mul_le_mul_of_nonneg_left hlog hs.le
  have hid : s*(-s⁻¹)=(-1:ℝ) := by field_simp
  rw [hid] at hm
  rw [Real.rpow_def_of_pos hs]
  apply Real.exp_le_exp.mpr
  nlinarith only [hm]

/-- Uniform positive mass below the transition, sufficient for profile floors. -/
theorem endpointProfile_transition_floor {N d : ℕ} (hN : 0<N) (hd0 : 2≤d) (hd1 : d≤6)
    {s x : ℝ} (hs : 0<s) (hs1 : s≤1) (_hx : 0≤x) (_hx1 : x≤1)
    (hy : s≤(N:ℝ)^2*x) :
    Real.exp (-(Real.log 12+3))≤endpointProfile N d s x := by
  let a : ℝ := s/((N:ℝ)^2)
  have hn : (1:ℝ)≤N := by exact_mod_cast hN
  have hN2 : 0<(N:ℝ)^2 := by positivity
  have ha : 0<a := div_pos hs hN2
  have ha1 : a≤1 := by
    apply (div_le_one hN2).mpr
    nlinarith only [hs1,hn]
  have hascale : (N:ℝ)^2*a=s := by dsimp [a];field_simp
  have hax : a≤x := by
    apply (div_le_iff₀ hN2).mpr
    nlinarith only [hy]
  have hlocal := endpointProfile_lower_power hN hd0 hd1 hs hs1 ha ha1 (by rw [hascale];exact hs1)
  rw [hascale] at hlocal
  have hC : 0<Real.log 12+2 := by have h := Real.log_nonneg (by norm_num : (1:ℝ)≤12);linarith
  have he := Real.exp_le_exp.mpr (show -(Real.log 12+2)≤-(Real.log 12+2)*s by nlinarith only [hs1,hC])
  have hp := mul_le_mul he (endpoint_self_power_lower hs) (Real.exp_pos (-1)).le
    (Real.exp_pos (-(Real.log 12+2)*s)).le
  have heq : Real.exp (-(Real.log 12+2))*Real.exp (-1)=Real.exp (-(Real.log 12+3)) := by
    rw [←Real.exp_add]
    congr 1
    ring
  rw [heq] at hp
  exact (hp.trans hlocal).trans (endpointProfile_mono hN hd1 hs ha.le hax)

end Renyi
