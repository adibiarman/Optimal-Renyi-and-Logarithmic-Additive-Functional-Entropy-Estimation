import Renyi.InterpolationNodes
import Renyi.OneDefect
import Renyi.RootCharacterization
import Renyi.Normalization

/-!
# Quantitative lower-prior calibration

This module assembles proved estimates for the actual finite interpolation
priors. Individual helper results explicitly state their hypotheses; they
are not assertions of the full asymptotic minimax theorem.
-/

noncomputable section
open scoped BigOperators
namespace Renyi

/-- The tensor power-moment ratio decreases with either negative mass. -/
theorem parity_ratio_antitone_left {r s q : ℝ}
    (hrs : r ≤ s) (hq₀ : 0 ≤ q) (hq₁ : q ≤ 1) (hden : 0 < r + q) :
    (1 + s * q) / (s + q) ≤ (1 + r * q) / (r + q) := by
  have hsden : 0 < s + q := by linarith
  apply (div_le_div_iff₀ hsden hden).mpr
  have hsq : 0 ≤ 1 - q ^ 2 := by nlinarith
  nlinarith [mul_nonneg (sub_nonneg.mpr hrs) hsq]

theorem parity_ratio_antitone_right {r q s : ℝ}
    (hqs : q ≤ s) (hr₀ : 0 ≤ r) (hr₁ : r ≤ 1) (hden : 0 < r + q) :
    (1 + r * s) / (r + s) ≤ (1 + r * q) / (r + q) := by
  simpa only [mul_comm, add_comm] using parity_ratio_antitone_left hqs hr₀ hr₁
    (show 0 < q + r by linarith)

/-- The logarithmic loss retains the factor `1-κ²`, which is essential
when the entropy order tends to one. -/
theorem parity_logarithmic_loss {ζ κ : ℝ} (hζ : 0 ≤ ζ) (hκ₀ : 0 ≤ κ) (hκ₁ : κ ≤ 1) :
    Real.log (1 + ζ) - Real.log (1 + ζ * κ ^ 2) ≤ ζ * (1 - κ ^ 2) := by
  have ha : 0 < 1 + ζ * κ ^ 2 := by positivity
  have hb : 0 < 1 + ζ := by positivity
  rw [← Real.log_div (ne_of_gt hb) (ne_of_gt ha)]
  apply (Real.log_le_sub_one_of_pos (div_pos hb ha)).trans
  have he : (1 + ζ) / (1 + ζ * κ ^ 2) - 1 =
      (ζ * (1 - κ ^ 2)) / (1 + ζ * κ ^ 2) := by field_simp; ring
  rw [he]
  apply div_le_self
  · exact mul_nonneg hζ (by nlinarith)
  · nlinarith [mul_nonneg hζ (sq_nonneg κ)]

/-- A direct exponential bound on the loss in κ². -/
theorem calibration_kappa_loss {E w : ℝ} (hE : 0 ≤ E) (hw : 0 ≤ w) :
    1 - (Real.exp (-E - 4 * w)) ^ 2 ≤ 2 * (1 - Real.exp (-E)) + 8 * w := by
  let p := Real.exp (-E)
  let q := Real.exp (-4 * w)
  have hp₀ : 0 ≤ p := Real.exp_nonneg _
  have hq₀ : 0 ≤ q := Real.exp_nonneg _
  have hp₁ : p ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
  have hq₁ : q ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
  have hqbound : 1 - q ≤ 4 * w := by
    have hh := Real.add_one_le_exp (-4 * w)
    dsimp [q]
    linarith
  have hk : Real.exp (-E - 4 * w) = p * q := by
    dsimp [p, q]
    rw [← Real.exp_add]
    congr 1
    ring
  rw [hk]
  change 1 - (p * q) ^ 2 ≤ 2 * (1 - p) + 8 * w
  have hprod := mul_nonneg (sub_nonneg.mpr hp₁) (sub_nonneg.mpr hq₁)
  nlinarith [sq_nonneg (1 - p * q)]

/-- Step 4 of the lower calibration, with the explicit choice `C₀=4`.
The negative-mass assumptions are intermediate inputs supplied by the two
interpolation factors; the entropy-gap conclusion is proved here. -/
theorem calibrated_parity_entropy_gap {E w c Rs Rc : ℝ}
    (hE : 0 < E) (hw : 0 < w) (hc₀ : 0 ≤ c) (hc₁ : c ≤ 1 / 2)
    (hζsmall : c * w / (1 - Real.exp (-E)) ≤ 1 / 8)
    (_hRs₀ : 0 ≤ Rs) (hRc₀ : 0 ≤ Rc)
    (hRs : Rs ≤ Real.exp (-E - 4 * w))
    (hRc : Rc ≤ (c * w / (1 - Real.exp (-E))) * Real.exp (-E - 4 * w))
    (hRpos : 0 < Rs + Rc) :
    E + w ≤ Real.log ((1 + Rs * Rc) / (Rs + Rc)) := by
  let κ := Real.exp (-E - 4 * w)
  let ζ := c * w / (1 - Real.exp (-E))
  have hden : 0 < 1 - Real.exp (-E) := by
    apply sub_pos.mpr
    exact Real.exp_lt_one_iff.mpr (by linarith)
  have hκ₀ : 0 < κ := Real.exp_pos _
  have hκ₁ : κ ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
  have hζ₀ : 0 ≤ ζ := div_nonneg (mul_nonneg hc₀ hw.le) hden.le
  have hζ₁ : ζ ≤ 1 / 8 := hζsmall
  have hRc₁ : Rc ≤ 1 := by
    have hh := mul_le_mul_of_nonneg_left hκ₁ hζ₀
    change Rc ≤ ζ * κ at hRc
    nlinarith
  have hκRc : 0 < κ + Rc := add_pos_of_pos_of_nonneg hκ₀ hRc₀
  have hκζ : 0 < κ + ζ * κ := add_pos_of_pos_of_nonneg hκ₀ (mul_nonneg hζ₀ hκ₀.le)
  have hfirst := parity_ratio_antitone_left hRs hRc₀ hRc₁ hRpos
  have hsecond := parity_ratio_antitone_right hRc hκ₀.le hκ₁ hκRc
  have hratio : (1 + κ * (ζ * κ)) / (κ + ζ * κ) ≤ (1 + Rs * Rc) / (Rs + Rc) :=
    hsecond.trans hfirst
  have hboundpos : 0 < (1 + κ * (ζ * κ)) / (κ + ζ * κ) := by positivity
  have hlog := Real.log_le_log hboundpos hratio
  have hnum : 1 + κ * (ζ * κ) = 1 + ζ * κ ^ 2 := by ring
  have hdeneq : κ + ζ * κ = κ * (1 + ζ) := by ring
  have hlogκ : Real.log κ = -E - 4 * w := Real.log_exp _
  have hlogeq : Real.log ((1 + κ * (ζ * κ)) / (κ + ζ * κ)) =
      E + 4 * w + Real.log (1 + ζ * κ ^ 2) - Real.log (1 + ζ) := by
    rw [hnum, hdeneq, Real.log_div (by positivity) (by positivity),
      Real.log_mul (ne_of_gt hκ₀) (by positivity), hlogκ]
    ring
  have hloss := parity_logarithmic_loss hζ₀ hκ₀.le hκ₁
  have hkloss := calibration_kappa_loss hE.le hw.le
  change 1 - κ ^ 2 ≤ 2 * (1 - Real.exp (-E)) + 8 * w at hkloss
  have hscaled := mul_le_mul_of_nonneg_left hkloss hζ₀
  have hζeq : ζ * (1 - Real.exp (-E)) = c * w := by
    dsimp [ζ]
    field_simp
  have hlossbound : ζ * (1 - κ ^ 2) ≤ 2 * w := by
    have hcprod := mul_le_mul_of_nonneg_right hc₁ hw.le
    have hζprod := mul_le_mul_of_nonneg_right hζ₁ hw.le
    nlinarith
  rw [hlogeq] at hlog
  linarith

/-- The perturbation changes the total weighted nodal mass by at most its
explicit multiplicative factor `1+ρ a/b`. -/
theorem perturbed_nodal_mass_bound {n : ℕ} (u : Fin (n + 1) → ℝ)
    (a b ρ s : ℝ) (ha : 0 ≤ a) (hb : 0 < b) (hρ : 0 ≤ ρ)
    (hu : ∀ i, b ≤ u i) (hs : 0 ≤ s) :
    (∑ i, |weightedInterpolation u a ρ s (some i)|) ≤
      b ^ (-s) * (1 + ρ * a / b) * (∑ i, |lagrangeWeight u a i|) := by
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i _
  have hui : 0 < u i := hb.trans_le (hu i)
  have hfac₀ : 0 ≤ 1 + ρ * a / u i := by positivity
  have hfac₁ : 1 + ρ * a / u i ≤ 1 + ρ * a / b :=
    add_le_add_left (div_le_div_of_nonneg_left (mul_nonneg hρ ha) hb (hu i)) 1
  have hpow := Real.rpow_le_rpow_of_nonpos hb (hu i) (neg_nonpos.mpr hs)
  simp only [weightedInterpolation, interpolationWeights, interpolationNodes,
    Option.elim_some, neg_mul, abs_neg, abs_mul]
  rw [abs_of_nonneg hfac₀, abs_of_nonneg (Real.rpow_nonneg hui.le _)]
  have hh := mul_le_mul
    (mul_le_mul_of_nonneg_left hfac₁ (abs_nonneg (lagrangeWeight u a i))) hpow
    (Real.rpow_nonneg hui.le _)
    (mul_nonneg (abs_nonneg (lagrangeWeight u a i)) (by positivity : 0 ≤ 1 + ρ * a / b))
  convert hh using 1
  ring

/-- The elementary exponential majorant used to pay for the nodal perturbation. -/
theorem active_nodal_exponential_bound {ζ : ℝ} (hζ : 0 ≤ ζ) :
    (1 + ζ) * (1 + ζ / 2) ≤ Real.exp (2 * ζ) := by
  have h₁ : 1 + ζ ≤ Real.exp ζ := by linarith [Real.add_one_le_exp ζ]
  have h₂ : 1 + ζ / 2 ≤ Real.exp ζ := by linarith
  have hh := mul_le_mul h₁ h₂ (by positivity : 0 ≤ 1 + ζ / 2) (Real.exp_nonneg ζ)
  rw [← Real.exp_add, show ζ + ζ = 2 * ζ by ring] at hh
  exact hh

/-- Positive-degree active factor: the common perturbation rule forces its
normalized negative mass below κ. The scalar condition `ρ a/b ≤ ζ` is the
remaining root-calibration input, explicitly separated from the mass proof. -/
theorem active_interpolation_mass_bound (n : ℕ) (ζ a s κ : ℝ)
    (hn : 0 < n) (hζ₀ : 0 < ζ) (hζ₁ : ζ ≤ 3 / 5)
    (ha₀ : 0 < a) (ha₁ : a ≤ ((ζ / 8) / ((n : ℝ) + 1) ^ 2) / 2)
    (hs : 0 ≤ s) (hκ₀ : 0 < κ) (hκ₁ : κ ≤ 1)
    (hpert :
      max (((a / ((ζ / 8) / ((n : ℝ) + 1) ^ 2)) ^ s / κ) *
        Real.exp (4 * ζ * (n : ℝ) / ((n : ℝ) + 1)) - 1) 0 *
        a / ((ζ / 8) / ((n : ℝ) + 1) ^ 2) ≤ ζ) :
    let b := (ζ / 8) / ((n : ℝ) + 1) ^ 2
    let ρ := max (((a / b) ^ s / κ) * Real.exp (4 * ζ * (n : ℝ) / ((n : ℝ) + 1)) - 1) 0
    let u := chebyshevNode n b
    (∑ i, negativeCoeff (normalizedInterpolation u a ρ s i)) ≤ κ ∧
      (1 / 2 : ℝ) ≤ normalizedInterpolation u a ρ s none := by
  dsimp only
  let b := (ζ / 8) / ((n : ℝ) + 1) ^ 2
  let ρ := max (((a / b) ^ s / κ) * Real.exp (4 * ζ * (n : ℝ) / ((n : ℝ) + 1)) - 1) 0
  let u := chebyshevNode n b
  let W := weightedInterpolation u a ρ s
  let e := Real.exp (4 * ζ * (n : ℝ) / ((n : ℝ) + 1))
  have hb₀ : 0 < b := by dsimp [b]; positivity
  have hb₁ : b < 1 := by
    apply (div_lt_one (by positivity : (0 : ℝ) < ((n : ℝ) + 1) ^ 2)).mpr
    have hn₀ : (0 : ℝ) ≤ n := Nat.cast_nonneg _
    nlinarith
  have hρ : 0 ≤ ρ := le_max_right _ _
  have hW : W none = (1 + ρ) * a ^ (-s) := rfl
  have hWpos : 0 < W none := by rw [hW]; positivity
  have hu : ∀ i, b ≤ u i := fun i => (chebyshevNode_bounds n b hb₁.le i).1
  have hsum : (∑ i, |lagrangeWeight u a i|) ≤ 1 + ζ / 2 :=
    (chebyshev_nodes_small_interval n ζ a hn hζ₀ hζ₁ ha₀ ha₁).1
  have hfactor : 1 + ρ * a / b ≤ 1 + ζ := by change ρ * a / b ≤ ζ at hpert; linarith
  have hexp : Real.exp (2 * ζ) ≤ e := by
    apply Real.exp_le_exp.mpr
    apply (le_div_iff₀ (by positivity : (0 : ℝ) < (n : ℝ) + 1)).mpr
    have hn₁ : (1 : ℝ) ≤ n := by exact_mod_cast hn
    nlinarith
  have hρbound : ((a / b) ^ s / κ) * e ≤ 1 + ρ := by
    have hh := le_max_left ((((a / b) ^ s / κ) * e) - 1) 0
    change ((a / b) ^ s / κ) * e - 1 ≤ ρ at hh
    linarith
  have hscale : (κ * a ^ (-s)) * ((a / b) ^ s / κ) = b ^ (-s) := by
    rw [Real.div_rpow ha₀.le hb₀.le, Real.rpow_neg ha₀.le, Real.rpow_neg hb₀.le]
    field_simp [ne_of_gt (Real.rpow_pos_of_pos ha₀ s)]
  have hpay : b ^ (-s) * e ≤ κ * W none := by
    have hh := mul_le_mul_of_nonneg_left hρbound
      (mul_nonneg hκ₀.le (Real.rpow_nonneg ha₀.le (-s)))
    rw [← mul_assoc, hscale] at hh
    rw [hW]
    convert hh using 1
    ring
  have hnodal : (∑ i, |W (some i)|) ≤ κ * W none := by
    have hraw := perturbed_nodal_mass_bound u a b ρ s ha₀.le hb₀ hρ hu hs
    calc
      _ ≤ b ^ (-s) * (1 + ρ * a / b) * (∑ i, |lagrangeWeight u a i|) := hraw
      _ ≤ b ^ (-s) * (1 + ζ) * (1 + ζ / 2) :=
        mul_le_mul (mul_le_mul_of_nonneg_left hfactor (Real.rpow_nonneg hb₀.le _)) hsum
          (Finset.sum_nonneg (fun i _ => abs_nonneg _)) (by positivity)
      _ = b ^ (-s) * ((1 + ζ) * (1 + ζ / 2)) := by ring
      _ ≤ b ^ (-s) * Real.exp (2 * ζ) :=
        mul_le_mul_of_nonneg_left (active_nodal_exponential_bound hζ₀.le) (Real.rpow_nonneg hb₀.le _)
      _ ≤ b ^ (-s) * e := mul_le_mul_of_nonneg_left hexp (Real.rpow_nonneg hb₀.le _)
      _ ≤ κ * W none := hpay
  have hh := signed_atom_normalization_bounds W κ hWpos hκ₀.le hκ₁ hnodal
  simpa only [W, normalizedInterpolation, interpolationNormalizer] using hh

/-- A logarithmic relative bound for two positive quantities in `[1,M]`. -/
theorem interval_sub_le_log {x y M : ℝ}
    (hx : 1 ≤ x) (hy : 1 ≤ y) (hxM : x ≤ M) :
    x - y ≤ x * Real.log M := by
  have hxpos : 0 < x := by linarith
  have hypos : 0 < y := by linarith
  have hh := Real.log_le_sub_one_of_pos (div_pos hypos hxpos)
  rw [Real.log_div (ne_of_gt hypos) (ne_of_gt hxpos)] at hh
  have hm := mul_le_mul_of_nonneg_left hh hxpos.le
  have he : x * (y / x - 1) = y - x := by field_simp
  rw [he] at hm
  have hlogx := Real.log_le_log hxpos hxM
  have hlogy := Real.log_nonneg hy
  have hloggap : Real.log x - Real.log y ≤ Real.log M := by linarith
  have hg := mul_le_mul_of_nonneg_left hloggap hxpos.le
  linarith

theorem interval_abs_sub_bound {x y M : ℝ}
    (hx : 1 ≤ x) (hy : 1 ≤ y) (hxM : x ≤ M) (hyM : y ≤ M) :
    |x - y| ≤ max x y * min 1 (Real.log M) := by
  by_cases hxy : y ≤ x
  · rw [max_eq_left hxy, abs_of_nonneg (sub_nonneg.mpr hxy), mul_min_of_nonneg 1 (Real.log M) (by linarith : 0 ≤ x)]
    apply le_min
    · simp only [mul_one]; linarith
    · exact interval_sub_le_log hx hy hxM
  · have hxy' : x ≤ y := le_of_not_ge hxy
    rw [max_eq_right hxy', abs_of_nonpos (sub_nonpos.mpr hxy'), mul_min_of_nonneg 1 (Real.log M) (by linarith : 0 ≤ y)]
    apply le_min
    · simp only [mul_one]; linarith
    · have hh := interval_sub_le_log hy hx hyM
      linarith

/-- The exact scalar cancellation behind the normalization noise bound. -/
theorem affine_power_residual_bound {u A B α : ℝ}
    (hα : 1 < α) (hB : 1 ≤ B) (hA₀ : 1 ≤ A) (hA₁ : A ≤ B ^ (α - 1))
    (hu : u = 0 ∨ (1 ≤ u ∧ u ≤ B)) :
    (u ^ α - A * u) ^ 2 ≤
      (min 1 ((α - 1) * Real.log B)) ^ 2 * (u ^ (2 * α) + A ^ 2 * u ^ 2) := by
  have hαpos : 0 < α := by linarith
  rcases hu with rfl | ⟨hu₁, huB⟩
  · simp [Real.zero_rpow (ne_of_gt hαpos), Real.zero_rpow (by linarith : 2 * α ≠ 0)]
  have hu₀ : 0 < u := by linarith
  have hB₀ : 0 < B := by linarith
  have hx₀ : 1 ≤ u ^ (α - 1) := Real.one_le_rpow hu₁ (by linarith)
  have hx₁ : u ^ (α - 1) ≤ B ^ (α - 1) := Real.rpow_le_rpow hu₀.le huB (by linarith)
  have hgap := interval_abs_sub_bound hx₀ hA₀ hx₁ hA₁
  rw [Real.log_rpow hB₀] at hgap
  let d := min 1 ((α - 1) * Real.log B)
  have hd : 0 ≤ d := le_min zero_le_one (mul_nonneg (by linarith) (Real.log_nonneg hB))
  have hpow : u * u ^ (α - 1) = u ^ α := by
    calc
      u * u ^ (α - 1) = u ^ (1 : ℝ) * u ^ (α - 1) := by rw [Real.rpow_one]
      _ = u ^ ((1 : ℝ) + (α - 1)) := (Real.rpow_add hu₀ _ _).symm
      _ = u ^ α := by congr 1; ring
  have htwopow : u ^ (2 * α) = (u ^ α) ^ 2 := by
    rw [show 2 * α = α * (2 : ℝ) by ring, Real.rpow_mul hu₀.le, Real.rpow_two]
  have habs : |u ^ α - A * u| ≤ u * max (u ^ (α - 1)) A * d := by
    have hh := mul_le_mul_of_nonneg_left hgap hu₀.le
    have he : u ^ α - A * u = u * (u ^ (α - 1) - A) := by rw [mul_sub, hpow]; ring
    rw [he, abs_mul, abs_of_pos hu₀]
    convert hh using 1
    ring
  change (u ^ α - A * u) ^ 2 ≤ d ^ 2 * (u ^ (2 * α) + A ^ 2 * u ^ 2)
  by_cases hxA : u ^ (α - 1) ≤ A
  · rw [max_eq_right hxA] at habs
    have hsq := (sq_le_sq₀ (abs_nonneg _) (show 0 ≤ u * A * d by positivity)).mpr habs
    rw [sq_abs] at hsq
    rw [htwopow]
    nlinarith [mul_nonneg (sq_nonneg d) (sq_nonneg (u ^ α))]
  · have hAx : A ≤ u ^ (α - 1) := le_of_not_ge hxA
    rw [max_eq_left hAx, hpow] at habs
    have hsq := (sq_le_sq₀ (abs_nonneg _) (show 0 ≤ u ^ α * d by positivity)).mpr habs
    rw [sq_abs] at hsq
    rw [htwopow]
    nlinarith [mul_nonneg (sq_nonneg d) (mul_nonneg (sq_nonneg A) (sq_nonneg u))]

/-- Mean one and support `{0} ∪ [1,B]` give the required power-moment bounds
without an unproved Jensen certificate. -/
theorem finite_prior_power_bounds {ι : Type*} [Fintype ι] (p : FiniteAtomicPrior ι)
    (α B : ℝ) (hα : 1 < α) (_hB : 1 ≤ B)
    (hsupp : ∀ i, p.value i = 0 ∨ (1 ≤ p.value i ∧ p.value i ≤ B))
    (hmean : priorMoment p 1 = 1) :
    1 ≤ priorMoment p α ∧ priorMoment p α ≤ B ^ (α - 1) := by
  have hmean' : (∑ i, p.mass i * p.value i) = 1 := by simpa [priorMoment] using hmean
  have hp (i : ι) : p.value i ≤ (p.value i) ^ α ∧
      (p.value i) ^ α ≤ B ^ (α - 1) * p.value i := by
    rcases hsupp i with hi | ⟨hi₁, hiB⟩
    · simp [hi, Real.zero_rpow (by linarith : α ≠ 0)]
    have hi₀ : 0 < p.value i := by linarith
    constructor
    · simpa only [Real.rpow_one] using Real.rpow_le_rpow_of_exponent_le hi₁ (show 1 ≤ α by linarith)
    · have hh := mul_le_mul_of_nonneg_right
        (Real.rpow_le_rpow hi₀.le hiB (show 0 ≤ α - 1 by linarith)) hi₀.le
      have he : (p.value i) ^ (α - 1) * p.value i = (p.value i) ^ α := by
        rw [Real.rpow_sub_one (ne_of_gt hi₀)]
        field_simp
      rwa [he] at hh
  constructor
  · rw [← hmean']
    exact Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left (hp i).1 (p.mass_nonneg i))
  · calc
      _ ≤ ∑ i, p.mass i * (B ^ (α - 1) * p.value i) :=
        Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left (hp i).2 (p.mass_nonneg i))
      _ = B ^ (α - 1) * (∑ i, p.mass i * p.value i) := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro i _
        ring
      _ = _ := by rw [hmean', mul_one]

/-- The second moment is controlled by the support bound and the exact mean. -/
theorem finite_prior_second_moment_le {ι : Type*} [Fintype ι] (p : FiniteAtomicPrior ι)
    (B : ℝ) (hsupp : ∀ i, 0 ≤ p.value i ∧ p.value i ≤ B)
    (hmean : priorMoment p 1 = 1) : priorMoment p 2 ≤ B := by
  have hmean' : (∑ i, p.mass i * p.value i) = 1 := by simpa [priorMoment] using hmean
  calc
    _ ≤ ∑ i, p.mass i * (B * p.value i) := by
      unfold priorMoment
      apply Finset.sum_le_sum
      intro i _
      rw [Real.rpow_two]
      exact mul_le_mul_of_nonneg_left
        (by nlinarith [mul_nonneg (hsupp i).1 (sub_nonneg.mpr (hsupp i).2)]) (p.mass_nonneg i)
    _ = B * (∑ i, p.mass i * p.value i) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro i _
      ring
    _ = B := by rw [hmean', mul_one]

def priorResidualSecondMoment {ι : Type*} [Fintype ι] (p : FiniteAtomicPrior ι) (α : ℝ) : ℝ :=
  ∑ i, p.mass i * ((p.value i) ^ α - priorMoment p α * p.value i) ^ 2

/-- Step 8's uniform affine-residual estimate for an actual finite probability law.
The factor `min(1,(α-1) log B)^2` is retained explicitly. -/
theorem finite_prior_residual_noise_bound {ι : Type*} [Fintype ι] (p : FiniteAtomicPrior ι)
    (α B : ℝ) (hα : 1 < α) (hB : 1 ≤ B)
    (hsupp : ∀ i, p.value i = 0 ∨ (1 ≤ p.value i ∧ p.value i ≤ B))
    (hmean : priorMoment p 1 = 1) :
    priorResidualSecondMoment p α / (priorMoment p α) ^ 2 ≤
      (min 1 ((α - 1) * Real.log B)) ^ 2 *
        (priorMoment p (2 * α) / (priorMoment p α) ^ 2 + B) := by
  let A := priorMoment p α
  let d := min 1 ((α - 1) * Real.log B)
  have hA := finite_prior_power_bounds p α B hα hB hsupp hmean
  have hApos : 0 < A := by dsimp [A]; linarith
  have hsupp' : ∀ i, 0 ≤ p.value i ∧ p.value i ≤ B := by
    intro i
    rcases hsupp i with hi | ⟨hi₁, hiB⟩
    · rw [hi]; constructor <;> linarith
    · constructor <;> linarith
  have hsecond := finite_prior_second_moment_le p B hsupp' hmean
  have hsum : priorResidualSecondMoment p α ≤
      d ^ 2 * (priorMoment p (2 * α) + A ^ 2 * priorMoment p 2) := by
    calc
      _ ≤ ∑ i, p.mass i * (d ^ 2 * ((p.value i) ^ (2 * α) + A ^ 2 * (p.value i) ^ 2)) :=
        Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left
          (affine_power_residual_bound hα hB hA.1 hA.2 (hsupp i)) (p.mass_nonneg i))
      _ = _ := by
        unfold priorMoment
        simp only [Real.rpow_two, mul_add, Finset.mul_sum]
        rw [← Finset.sum_add_distrib]
        apply Finset.sum_congr rfl
        intro i _
        ring
  change priorResidualSecondMoment p α / A ^ 2 ≤ d ^ 2 * (priorMoment p (2 * α) / A ^ 2 + B)
  calc
    _ ≤ (d ^ 2 * (priorMoment p (2 * α) + A ^ 2 * priorMoment p 2)) / A ^ 2 :=
      div_le_div_of_nonneg_right hsum (sq_nonneg A)
    _ = d ^ 2 * (priorMoment p (2 * α) / A ^ 2 + priorMoment p 2) := by field_simp
    _ ≤ _ := mul_le_mul_of_nonneg_left (add_le_add_left hsecond _) (sq_nonneg d)

end Renyi
