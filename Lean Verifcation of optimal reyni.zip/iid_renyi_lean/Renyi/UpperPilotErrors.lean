import Renyi.UpperPilotBoundary
import Renyi.CoupledPolynomialRange

/-! Exponentially damped polynomial boundary errors of the actual pilot. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Polynomial
namespace Renyi
set_option maxHeartbeats 500000

/-- The actual false-light polynomial and ideal Gamma mean have the same exponential budget. -/
theorem false_light_difference_mass {P : ℝ[X]} {n b p L C Cd cstar cp cb B alpha omega : ℝ}
    (hn : 0<n) (hb : 0<b) (hp : b≤p) (hL : 0≤L)
    (hC : 0≤C) (hCd : 0≤Cd) (hcstar : 0≤cstar)
    (hcp0 : 0<cp) (ha : 0≤alpha) (hnb : n*b=cb*L)
    (hcutoff : 2*B*alpha≤n*b)
    (hdegree : (P.natDegree:ℝ)≤Cd*L)
    (hcoef : coefficientMass P≤Real.exp (C*L))
    (hcp : 8*(C+Cd+cstar)≤cp*cb) (hw : 0≤omega) (hw1 : omega≤1) :
    poissonLowerMass ⟨cp*n*p,mul_nonneg (mul_nonneg hcp0.le hn.le) (hb.le.trans hp)⟩ (cp*B*alpha)*
      (|b^alpha*P.eval (p/b)|+omega*p^alpha)≤2*Real.exp (-cstar*L)*p^alpha := by
  have hp0 : 0≤p := hb.le.trans hp
  have hpoly := false_light_mean_bound hn hb hp hL hC hCd hcstar hcp0 ha hnb hcutoff hdegree hcoef hcp
  have hnp := mul_le_mul_of_nonneg_left hp hn.le
  have hthreshold : cp*B*alpha≤cp*n*p/2 := by
    have hh := mul_le_mul_of_nonneg_left (hcutoff.trans hnp) hcp0.le
    nlinarith only [hh]
  have htail := poissonLowerMass_half (⟨cp*n*p,by positivity⟩:ℝ≥0) hthreshold
  have hcp' : 8*cstar≤cp*cb := by linarith only [hcp,hC,hCd]
  have hmul := mul_le_mul_of_nonneg_right hcp' hL
  have hnp' := mul_le_mul_of_nonneg_left hnp hcp0.le
  rw [hnb] at hnp'
  have he : Real.exp (-(cp*n*p)/8)≤Real.exp (-cstar*L) :=
    Real.exp_le_exp.mpr (by nlinarith only [hmul,hnp'])
  have htail' := htail.trans he
  have hpPow : 0≤p^alpha := Real.rpow_nonneg (hb.le.trans hp) _
  have homega : omega*p^alpha≤p^alpha := mul_le_of_le_one_left hpPow hw1
  have hgamma := mul_le_mul htail' homega (mul_nonneg hw hpPow) (Real.exp_pos _).le
  nlinarith only [hpoly,hgamma]

/-- False-heavy polynomial expectations preserve the tiny-intensity gain. -/
theorem false_heavy_polynomial_mass {cp B alpha C Q p : ℝ} (hcp : 1≤cp)
    (hB : 16≤B) (ha : 1≤alpha) (_hC : 0≤C) (_hp : 0≤p)
    (lam : ℝ≥0) (hlam : (lam:ℝ)≤B*alpha/2) (hQ : |Q|≤C*p^alpha) :
    poissonUpperMass ⟨cp*lam,mul_nonneg (by linarith only [hcp]) lam.coe_nonneg⟩ (cp*B*alpha)*|Q|≤
      C*Real.exp (-cp*alpha)*p^alpha*min (lam:ℝ) 1 := by
  have htail := false_heavy_pilot_min hcp hB ha lam hlam
  have hh := mul_le_mul htail hQ (abs_nonneg Q)
    (mul_nonneg (Real.exp_pos _).le (le_min lam.coe_nonneg (by norm_num)))
  nlinarith only [hh]

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}

lemma poisson_upper_switch_integrable (lam : ℝ≥0) (T V : ℝ) :
    Integrable (fun y:ℕ => if T<(y:ℝ) then V else 0) (poissonMeasure lam) := by
  apply (integrable_const |V|).mono' (measurable_of_countable _).aestronglyMeasurable
  apply Filter.Eventually.of_forall
  intro y
  split_ifs <;> simp [Real.norm_eq_abs,abs_nonneg]

lemma poisson_upper_switch_integral (lam : ℝ≥0) (T V : ℝ) :
    (∫ y:ℕ,(if T<(y:ℝ) then V else 0) ∂poissonMeasure lam)=poissonUpperMass lam T*V := by
  rw [poisson_integral_eq_tsum lam _ (poisson_upper_switch_integrable lam T V)]
  calc
    _=∑' y:ℕ,(if T<(y:ℝ) then poissonPMFReal lam y else 0)*V := by
      apply tsum_congr
      intro y
      split_ifs <;> ring
    _=_ := (poissonUpperMass_summable lam T).tsum_mul_right V

/-- Arbitrary finite sums of the actual selected Gamma errors have an L1 budget;
there is no union bound over the alphabet and no deterministic-pilot assumption. -/
theorem false_heavy_gamma_sum {ι : Type*} [Fintype ι]
    {B alpha cp cstar n omega L : ℝ} (hB : 16≤B) (ha : 3/2≤alpha) (hcstar : 0≤cstar)
    (hcp : 2*B+cstar+11≤cp) (hn : 0<n) (hw : 0≤omega) (hw1 : omega≤1) (hL : 1≤L)
    (p : ι→ℝ) (hp : ∀i,0≤p i) (Y N : ι→Ω→ℕ) (lam : ι→ℝ≥0)
    (hlam : ∀i,(lam i:ℝ)=n*p i)
    (hY : ∀i,MeasurePreserving (Y i) μ (poissonMeasure ⟨cp*lam i,mul_nonneg (by linarith only [hcp,hB,hcstar]) (lam i).coe_nonneg⟩))
    (hN : ∀i,MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hind : ∀i,IndepFun (Y i) (N i) μ) :
    let F : Ω→ℝ := fun w => ∑i,if n*p i<B*alpha/2 then
      (if cp*B*alpha<(Y i w:ℝ) then |omega*analyticCount alpha (N i w)/n^alpha| else 0) else 0
    Integrable F μ ∧ (∫w,F w ∂μ)≤Real.exp (-cstar*alpha)*conditionalCountBonus p alpha n L := by
  dsimp only
  let F : ι→Ω→ℝ := fun i w => if n*p i<B*alpha/2 then
      (if cp*B*alpha<(Y i w:ℝ) then |omega*analyticCount alpha (N i w)/n^alpha| else 0) else 0
  have hcoord (i:ι) : Integrable (F i) μ ∧ (∫w,F i w ∂μ)≤
      Real.exp (-cstar*alpha)*p i^alpha*min (L*(n*p i)) 1 := by
    by_cases hs : n*p i<B*alpha/2
    · dsimp [F]
      simp only [if_pos hs]
      have hh := false_heavy_gamma_coordinate hB ha hcstar hcp hn (hp i) hw hw1 (Y i) (N i) (lam i) (hlam i) (hY i) (hN i) (hind i) hs.le
      refine ⟨hh.1,hh.2.trans ?_⟩
      apply mul_le_mul_of_nonneg_left _ (mul_nonneg (Real.exp_pos _).le (Real.rpow_nonneg (hp i) _))
      exact min_le_min_right 1 (by have hh := mul_le_mul_of_nonneg_right hL (mul_nonneg hn.le (hp i));simpa only [one_mul] using hh)
    · dsimp [F]
      simp only [if_neg hs,integrable_zero,integral_zero,true_and]
      exact mul_nonneg (mul_nonneg (Real.exp_pos _).le (Real.rpow_nonneg (hp i) _))
        (le_min (mul_nonneg (by linarith only [hL]) (mul_nonneg hn.le (hp i))) (by norm_num))
  refine ⟨integrable_finset_sum _ (fun i _ => (hcoord i).1),?_⟩
  rw [integral_finset_sum Finset.univ (fun i _ => (hcoord i).1)]
  calc
    _≤∑i,Real.exp (-cstar*alpha)*p i^alpha*min (L*(n*p i)) 1 := Finset.sum_le_sum (fun i _ => (hcoord i).2)
    _=_ := by unfold conditionalCountBonus;rw [Finset.mul_sum];apply Finset.sum_congr rfl;intro i _;ring

end Renyi
