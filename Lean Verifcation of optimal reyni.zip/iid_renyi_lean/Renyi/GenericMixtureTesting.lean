import Renyi.IIDOverlap

noncomputable section
open scoped BigOperators
namespace Renyi

/-- Actual fixed-size iid testing against a uniform alternative mixture. -/
theorem iidUniformMixture_target_impossibility {k m n : ℕ} (p : Simplex k)
    (q : Fin m → Simplex k) (hm : 0 < m) (target : Simplex k → ℝ) (eps : ℝ)
    (hgap : ∀ s, 2 * eps < target p - target (q s))
    (hTV : finiteTV (iidMass p n) (iidUniformMixture q n) ≤ 1 / 4) :
    ¬ (∃ est : Estimator k n, ∀ r : Simplex k,
      (∑ x, iidMass r n x * (est x {z : ℝ | eps < |z - target r|} : ℝ)) ≤ 1 / 3) := by
  rintro ⟨est, hest⟩
  let low : Set ℝ := Set.Iio (target p - eps)
  let t : Sample k n → ℝ := fun x => (est x low : ℝ)
  have ht0 : ∀ x, 0 ≤ t x := fun _ => NNReal.coe_nonneg _
  have ht1 : ∀ x, t x ≤ 1 := by
    intro x
    exact_mod_cast (est x).apply_le_one low
  have htest := finite_testing_lower_bound (iidMass p n) (iidUniformMixture q n) t
    (iidMass_sum p n) (iidUniformMixture_sum q n hm) ht0 ht1
  have hleft : ∑ x, iidMass p n x * t x ≤ (∑ x, iidMass p n x * (est x {z : ℝ | eps < |z - target p|} : ℝ)) := by
    apply Finset.sum_le_sum
    intro x _
    apply mul_le_mul_of_nonneg_left _ (iidMass_nonneg p x)
    apply NNReal.coe_le_coe.mpr
    apply (est x).apply_mono
    intro z hz
    change z < target p - eps at hz
    change eps < |z - target p|
    exact (by linarith : eps < -(z - target p)).trans_le (neg_le_abs _)
  have hright (s : Fin m) : ∑ x, iidMass (q s) n x * (1 - t x) ≤
      (∑ x, iidMass (q s) n x * (est x {z : ℝ | eps < |z - target (q s)|} : ℝ)) := by
    apply Finset.sum_le_sum
    intro x _
    apply mul_le_mul_of_nonneg_left _ (iidMass_nonneg (q s) x)
    have hcomp : (est x low : ℝ) + (est x lowᶜ : ℝ) = 1 := by
      simpa only [MeasureTheory.ProbabilityMeasure.measureReal_eq_coe_coeFn,
        MeasureTheory.ProbabilityMeasure.coeFn_univ, NNReal.coe_one] using
        (MeasureTheory.measureReal_add_measureReal_compl (μ := (est x : MeasureTheory.Measure ℝ))
          (show MeasurableSet low from measurableSet_Iio))
    have hb : (est x lowᶜ : ℝ) ≤ (est x {z | eps < |z - target (q s)|} : ℝ) := by
      apply NNReal.coe_le_coe.mpr
      apply (est x).apply_mono
      intro z hz
      have hz' : target p - eps ≤ z := le_of_not_gt hz
      exact (by linarith [hgap s] : eps < z - target (q s)).trans_le (le_abs_self _)
    dsimp [t]
    linarith
  have hmix : ∑ x, iidUniformMixture q n x * (1 - t x) ≤ 1 / 3 := by
    have hbound := Finset.sum_le_sum (s := Finset.univ)
      (fun s _ => (hright s).trans (hest (q s)))
    have hmpos : 0 < (m : ℝ) := by exact_mod_cast hm
    unfold iidUniformMixture
    simp_rw [div_mul_eq_mul_div, Finset.sum_mul]
    rw [← Finset.sum_div, Finset.sum_comm]
    apply (div_le_iff₀ hmpos).2
    simpa [mul_comm] using hbound
  rw [Finset.sum_add_distrib] at htest
  linarith [hleft.trans (hest p)]


end Renyi
