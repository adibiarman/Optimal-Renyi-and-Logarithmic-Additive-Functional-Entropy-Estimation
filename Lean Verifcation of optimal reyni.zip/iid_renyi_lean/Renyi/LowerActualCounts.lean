import Renyi.LowerConstructedCounts
import Renyi.LowerActivation

/-! Actual-root priors with their full count and power-moment experiment. -/
noncomputable section
namespace Renyi

theorem lower_actual_positive_count_priors {k r : ℕ} {s ε : ℝ}
    (hk : 0 < k) (hr : 2 ≤ r) (hs : 0 < s) (hs1 : s ≤ 1/2) (hε : 0 < ε)
    (hx : lowerPriorRootCutoff ε ≤ rootMultiplier k ((r : ℝ)+s) ε) :
    let α := (r : ℝ)+s
    let x := rootMultiplier k α ε
    let L := Nat.ceil (10*α*(1+Real.log x))
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let ac := Real.exp (-5)*((1-s)/(((L-r : ℕ) : ℝ)+1)^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
    let a := θ/((1/100)*(L : ℝ)*ac)
    lowerPositiveCountConclusion r L s E w c a θ := by
  let α := (r : ℝ)+s
  let x := rootMultiplier k α ε
  let L := Nat.ceil (10*α*(1+Real.log x))
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ds : ℝ := ((r-1 : ℕ) : ℝ)+1
  let dc : ℝ := ((L-r : ℕ) : ℝ)+1
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*(L : ℝ)*ac)
  have hrR : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hα : 3/2 ≤ α := by dsimp [α]; linarith
  have hα1 : 1 < α := by linarith
  have hα0 : 0 < α := by linarith
  have hγ : fractionalPart α = s := fractionalPart_nat_add_small r hs.le (by linarith)
  have hγ₀ : 0 < fractionalPart α := by rwa [hγ]
  have hγ₁ : fractionalPart α < 1 := by rw [hγ]; linarith
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hx0 : 0 < x := by linarith
  have hlog : 0 ≤ Real.log x := Real.log_nonneg (by linarith)
  have hLlo : 10*α*(1+Real.log x) ≤ (L : ℝ) := Nat.le_ceil _
  have hLr : r ≤ L := by
    have : (r : ℝ) ≤ L := by dsimp [α] at *; nlinarith
    exact_mod_cast this
  have hds : 0 < ds := by dsimp [ds]; positivity
  have hdc : 0 < dc := by dsimp [dc]; positivity
  have hds_eq : ds = (r : ℝ) := by
    dsimp [ds]
    rw [Nat.cast_sub (by omega : 1 ≤ r)]
    push_cast
    ring
  have hdchi : dc ≤ (L : ℝ)+1 := by
    dsimp [dc]
    exact add_le_add_right (by exact_mod_cast (Nat.sub_le L r)) 1
  have hdim : ds*dc ≤ α*((L : ℝ)+1) := by
    have h1 := mul_le_mul_of_nonneg_left hdchi (by positivity : 0 ≤ ds)
    rw [hds_eq] at h1
    have h2 := mul_le_mul_of_nonneg_right (show (r : ℝ) ≤ α by dsimp [α]; linarith)
      (show 0 ≤ (L : ℝ)+1 by positivity)
    rw [hds_eq]
    exact h1.trans h2
  have hc := lowerPriorCoefficient_bounds hε
  have hβ0 : 0 < α-1 := sub_pos.mpr hα1
  have hE : 0 < E := by dsimp [E]; positivity
  have hv : 0 ≤ v := by dsimp [v]; positivity
  have hw : 0 < w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv
  have hcon := lower_actual_principal_constraints hk hα hε hs hs1 hγ₀ hγ₁
    (Or.inl hγ.symm) hx hds hdc hdim
  dsimp only at hcon
  let bs := (ζ/8)/ds^2
  let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
  change 0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 at hcon
  have hmul : 4*ζ*((ds-1)/ds) = 4*ζ*((r-1 : ℕ) : ℝ)/(((r-1 : ℕ) : ℝ)+1) := by
    dsimp [ds]
    ring
  have hpert : max (((a/bs)^s/κ)*
      Real.exp (4*ζ*((r-1 : ℕ) : ℝ)/(((r-1 : ℕ) : ℝ)+1))-1) 0 * a / bs ≤ ζ := by
    rw [← hmul]
    exact hcon.2.2.2.1
  have hθ : 0<θ := by
    dsimp [θ,lowerPriorIntensityConstant]
    exact mul_pos (mul_pos (mul_pos (Real.exp_pos _) hα0)
      (Real.rpow_pos_of_pos (by exact_mod_cast hk) _)) hx0
  have hLpos : (0:ℝ)<L := (show 0<10*α*(1+Real.log x) by positivity).trans_le hLlo
  have hζ0 : 0<ζ := hcon.2.2.2.2.1
  have hξ0 : 0<1-s := by linarith
  have hac : 0<ac := by dsimp [ac,κ]; positivity
  have hκ1 : κ≤1 := Real.exp_le_one_iff.mpr (by linarith)
  have hLα : 10*α≤L := by nlinarith
  have hlong : (L:ℝ)≤2*dc := lower_long_dimension (show (r:ℝ)≤α by dsimp [α]; linarith) hLα
  have hscale : θ/a=(1/100)*(L:ℝ)*ac := by dsimp [a]; field_simp
  have hsmall := (positive_designated_count_means (u:=a) (by positivity : (0:ℝ)≤L)
    (show 1≤dc by dsimp [dc]; exact le_add_of_nonneg_left (Nat.cast_nonneg _)) hlong hcon.2.2.2.2.1 hcon.2.2.2.2.2
    (Real.exp_pos _) hκ1 (show 0<1-s by linarith) (by linarith) hcon.1 le_rfl hθ.le hscale).1
  exact positive_sign_constructed_count_priors r L s E w c a θ hr hLr hs hs1 hE hw
    hc.1 (by linarith [hc.2]) hcon.2.2.2.2.2 hcon.1 hθ.le hcon.2.1 hpert hsmall


theorem lower_actual_negative_count_priors {k m : ℕ} {s ε : ℝ}
    (hk : 0 < k) (hm : 1 ≤ m) (hs : 0 < s) (hs1 : s ≤ 1/2) (hε : 0 < ε)
    (hx : lowerPriorRootCutoff ε ≤ rootMultiplier k ((m : ℝ)+(1-s)) ε) :
    let α := (m : ℝ)+(1-s)
    let x := rootMultiplier k α ε
    let L := Nat.ceil (10*α*(1+Real.log x))
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let ac := Real.exp (-5)*((1-s)/(((m-1 : ℕ) : ℝ)+1)^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
    let a := θ/((1/100)*(L : ℝ)*ac)
    lowerNegativeCountConclusion m L s E w c a θ := by
  let α := (m : ℝ)+(1-s)
  let x := rootMultiplier k α ε
  let L := Nat.ceil (10*α*(1+Real.log x))
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ds : ℝ := ((L-m : ℕ) : ℝ)+1
  let dc : ℝ := ((m-1 : ℕ) : ℝ)+1
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*(L : ℝ)*ac)
  have hmR : (1 : ℝ) ≤ m := by exact_mod_cast hm
  have hα : 3/2 ≤ α := by dsimp [α]; linarith
  have hα1 : 1 < α := by linarith
  have hα0 : 0 < α := by linarith
  have hγ : fractionalPart α = 1-s :=
    fractionalPart_nat_add_small m (by linarith) (by linarith)
  have hγ₀ : 0 < fractionalPart α := by rw [hγ]; linarith
  have hγ₁ : fractionalPart α < 1 := by rw [hγ]; linarith
  have hnear : s = 1-fractionalPart α := by rw [hγ]; ring
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hx0 : 0 < x := by linarith
  have hlog : 0 ≤ Real.log x := Real.log_nonneg (by linarith)
  have hLlo : 10*α*(1+Real.log x) ≤ (L : ℝ) := Nat.le_ceil _
  have hLm : m+1 ≤ L := by
    have : (m : ℝ)+1 ≤ L := by dsimp [α] at *; nlinarith
    exact_mod_cast this
  have hds : 0 < ds := by dsimp [ds]; positivity
  have hdc : 0 < dc := by dsimp [dc]; positivity
  have hdc_eq : dc = (m : ℝ) := by
    dsimp [dc]
    rw [Nat.cast_sub hm]
    push_cast
    ring
  have hdshi : ds ≤ (L : ℝ)+1 := by
    dsimp [ds]
    exact add_le_add_right (by exact_mod_cast (Nat.sub_le L m)) 1
  have hdim : ds*dc ≤ α*((L : ℝ)+1) := by
    have h1 := mul_le_mul_of_nonneg_right hdshi (by positivity : 0 ≤ dc)
    rw [hdc_eq] at h1
    have h2 := mul_le_mul_of_nonneg_left (show (m : ℝ) ≤ α by dsimp [α]; linarith)
      (show 0 ≤ (L : ℝ)+1 by positivity)
    rw [hdc_eq]
    exact h1.trans (by nlinarith only [h2])
  have hc := lowerPriorCoefficient_bounds hε
  have hβ0 : 0 < α-1 := sub_pos.mpr hα1
  have hE : 0 < E := by dsimp [E]; positivity
  have hv : 0 ≤ v := by dsimp [v]; positivity
  have hw : 0 < w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv
  have hcon := lower_actual_principal_constraints hk hα hε hs hs1 hγ₀ hγ₁
    (Or.inr hnear) hx hds hdc hdim
  dsimp only at hcon
  let bs := (ζ/8)/ds^2
  let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
  change 0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 at hcon
  have hmul : 4*ζ*((ds-1)/ds) = 4*ζ*((L-m : ℕ) : ℝ)/(((L-m : ℕ) : ℝ)+1) := by
    dsimp [ds]
    ring
  have hpert : max (((a/bs)^s/κ)*
      Real.exp (4*ζ*((L-m : ℕ) : ℝ)/(((L-m : ℕ) : ℝ)+1))-1) 0 * a / bs ≤ ζ := by
    rw [← hmul]
    exact hcon.2.2.2.1
  have hθ : 0<θ := by
    dsimp [θ,lowerPriorIntensityConstant]
    exact mul_pos (mul_pos (mul_pos (Real.exp_pos _) hα0)
      (Real.rpow_pos_of_pos (by exact_mod_cast hk) _)) hx0
  have hLpos : (0:ℝ)<L := (show 0<10*α*(1+Real.log x) by positivity).trans_le hLlo
  have hζ0 : 0<ζ := hcon.2.2.2.2.1
  have hξ0 : 0<1-s := by linarith
  have hac : 0<ac := by dsimp [ac,κ]; positivity
  have hκ1 : κ≤1 := Real.exp_le_one_iff.mpr (by linarith)
  have hLα : 10*α≤L := by nlinarith
  have hlong : (L:ℝ)≤2*ds := lower_long_dimension (show (m:ℝ)≤α by dsimp [α]; linarith) hLα
  have hscale : θ*(ac*a)⁻¹=(1/100)*(L:ℝ) := by dsimp [a]; field_simp
  have hsmall := (negative_designated_count_means (by positivity : (0:ℝ)≤L)
    (show 1≤ds by dsimp [ds]; exact le_add_of_nonneg_left (Nat.cast_nonneg _)) hlong hcon.2.2.2.2.1 hcon.2.2.2.2.2
    hac hcon.1 hθ.le (hcon.2.1.trans (by have hh := hcon.1; have hh2 := hcon.2.1; linarith)) hscale).2
  have hnode : chebyshevNode (L-m) bs 0=bs := chebyshevNode_zero (L-m) bs (by omega)
  have hsmall' : θ*(ac*a)⁻¹*chebyshevNode (L-m) bs 0≤1 := by
    rw [hnode]
    exact hsmall
  exact negative_sign_constructed_count_priors m L s E w c a θ hm hLm hs hs1 hE hw
    hc.1 (by linarith [hc.2]) hcon.2.2.2.2.2 hcon.1 hθ.le hcon.2.1 hpert hsmall'


end Renyi
