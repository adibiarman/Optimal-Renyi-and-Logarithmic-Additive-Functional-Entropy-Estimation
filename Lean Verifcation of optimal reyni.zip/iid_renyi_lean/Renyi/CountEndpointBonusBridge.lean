import Renyi.ActualCountCoupledBridge

/-! The two actual local bonus conventions differ by only the fixed cutoff constant. -/
noncomputable section
open scoped BigOperators
namespace Renyi

lemma min_scaled_unit_le {c x : ℝ} (hx : 0 ≤ x) :
    min (c * x) 1 ≤ max 1 c * min x 1 := by
  by_cases hx1 : x ≤ 1
  · rw [min_eq_left hx1]
    exact (min_le_left (c * x) 1).trans (mul_le_mul_of_nonneg_right (le_max_right 1 c) hx)
  · rw [min_eq_right (le_of_lt (lt_of_not_ge hx1)), mul_one]
    exact (min_le_right (c * x) 1).trans (le_max_left 1 c)

variable {ι : Type*} [Fintype ι]

/-- This relates the exact count bonus to the exact deterministic endpoint bonus. -/
theorem conditionalCountBonus_le_endpoint_bonus (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    {alpha n b cb L : ℝ} (hb : 0 < b)
    (hnb : n * b = cb * L) :
    conditionalCountBonus p alpha n L ≤
      max 1 cb * (∑ i, p i ^ alpha * min (L ^ 2 * (p i / b)) 1) := by
  unfold conditionalCountBonus
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i _
  have hid : L * (n * p i) = cb * (L ^ 2 * (p i / b)) := by
    apply (mul_left_inj' hb.ne').mp
    calc
      _ = L * p i * (n * b) := by ring
      _ = L * p i * (cb * L) := by rw [hnb]
      _ = _ := by field_simp
  rw [hid]
  have hh := mul_le_mul_of_nonneg_left
    (min_scaled_unit_le (c := cb) (mul_nonneg (sq_nonneg L) (div_nonneg (hp i) hb.le)))
    (Real.rpow_nonneg (hp i) alpha)
  convert hh using 1
  ring

end Renyi
