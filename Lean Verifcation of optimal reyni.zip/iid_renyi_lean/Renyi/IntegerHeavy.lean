import Renyi.Foundations
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Data.Nat.Factorial.BigOperators

/-! Deterministic lower bound for the frequent-coordinate collision statistic. -/
noncomputable section
open scoped BigOperators
namespace Renyi

theorem factorial_lower_nat (N r : ℕ) : (N - r) ^ r ≤ N.descFactorial r := by
  rw [Nat.descFactorial_eq_prod_range]
  calc
    (N - r) ^ r = ∏ _i ∈ Finset.range r, (N - r) := by simp
    _ ≤ ∏ i ∈ Finset.range r, (N - i) := by
      exact Finset.prod_le_prod (fun _ _ => Nat.zero_le _)
        (fun i hi => Nat.sub_le_sub_left (Finset.mem_range.mp hi).le N)

theorem factorial_lower_real (N r : ℕ) :
    (max 0 ((N : ℝ) - r)) ^ r ≤ (N.descFactorial r : ℝ) := by
  have hid : max 0 ((N : ℝ) - r) = ((N - r : ℕ) : ℝ) := by
    by_cases h : r ≤ N
    · have hreal : (r : ℝ) ≤ N := by exact_mod_cast h
      rw [Nat.cast_sub h, max_eq_right (sub_nonneg.mpr hreal)]
    · have h' : N ≤ r := (Nat.le_of_not_ge h)
      rw [Nat.sub_eq_zero_of_le h', Nat.cast_zero,
        max_eq_left (by exact_mod_cast (show (N : ℤ) - r ≤ 0 by omega))]
  rw [hid]
  exact_mod_cast factorial_lower_nat N r

/-- Jensen's inequality applied to the one weighted mean of frequent counts. -/
theorem weighted_factorial_lower {ι : Type*} [Fintype ι]
    (N : ι → ℕ) (r : ℕ) (w lam : ι → ℝ) {T : ℝ}
    (hw : ∀ i, 0 ≤ w i) (hw1 : ∑ i, w i = 1)
    (hT : 0 < T) (hlam : ∀ i, T ≤ lam i) :
    (max 0 ((∑ i, w i / lam i * (N i : ℝ)) - (r : ℝ) / T)) ^ r ≤
      ∑ i, w i * ((N i).descFactorial r : ℝ) / (lam i) ^ r := by
  let z : ι → ℝ := fun i => max 0 ((N i : ℝ) - r) / lam i
  have hlampos : ∀ i, 0 < lam i := fun i => hT.trans_le (hlam i)
  have hz : ∀ i, 0 ≤ z i := fun i => div_nonneg (le_max_left _ _) (hlampos i).le
  have hsum0 : 0 ≤ ∑ i, w i * z i := Finset.sum_nonneg (fun i _ => mul_nonneg (hw i) (hz i))
  have hpoint : ∀ i, w i / lam i * (N i : ℝ) - w i * ((r : ℝ) / T) ≤ w i * z i := by
    intro i
    have hrecip : (r : ℝ) / lam i ≤ (r : ℝ) / T :=
      div_le_div_of_nonneg_left (by positivity) hT (hlam i)
    have hzlower : ((N i : ℝ) - r) / lam i ≤ z i :=
      div_le_div_of_nonneg_right (le_max_right _ _) (hlampos i).le
    have hid : (N i : ℝ) / lam i - (r : ℝ) / T ≤ z i := by
      rw [sub_div] at hzlower
      linarith
    have h := mul_le_mul_of_nonneg_left hid (hw i)
    convert h using 1
    ring
  have hsum := Finset.sum_le_sum (fun i (_ : i ∈ (Finset.univ : Finset ι)) => hpoint i)
  rw [Finset.sum_sub_distrib, ← Finset.sum_mul, hw1, one_mul] at hsum
  have hmax : max 0 ((∑ i, w i / lam i * (N i : ℝ)) - (r : ℝ) / T) ≤
      ∑ i, w i * z i := max_le hsum0 hsum
  calc
    (max 0 ((∑ i, w i / lam i * (N i : ℝ)) - (r : ℝ) / T)) ^ r ≤
        (∑ i, w i * z i) ^ r := pow_le_pow_left₀ (le_max_left _ _) hmax r
    _ ≤ ∑ i, w i * (z i) ^ r :=
      Real.pow_arith_mean_le_arith_mean_pow Finset.univ w z
        (fun i _ => hw i) hw1 (fun i _ => hz i) r
    _ ≤ ∑ i, w i * ((N i).descFactorial r : ℝ) / (lam i) ^ r := by
      apply Finset.sum_le_sum
      intro i _
      have h := div_le_div_of_nonneg_right (factorial_lower_real (N i) r)
        (pow_nonneg (hlampos i).le r)
      have h' := mul_le_mul_of_nonneg_left h (hw i)
      simpa only [z, div_pow, mul_div_assoc] using h'

/-- The deterministic frequent-coordinate bound in the manuscript's units. -/
theorem heavy_collision_lower {ι : Type*} [Fintype ι]
    (N : ι → ℕ) (r : ℕ) (p lam : ι → ℝ) {n T : ℝ}
    (hp : ∀ i, 0 ≤ p i) (hn : 0 < n) (hT : 0 < T)
    (hlam : ∀ i, lam i = n * p i) (hheavy : ∀ i, T ≤ lam i)
    (hH : 0 < ∑ i, p i ^ r) :
    (∑ i, p i ^ r) *
      (max 0 ((∑ i, (p i ^ r / (∑ j, p j ^ r)) / lam i * (N i : ℝ)) -
        (r : ℝ) / T)) ^ r ≤
      ∑ i, ((N i).descFactorial r : ℝ) / n ^ r := by
  let H := ∑ i, p i ^ r
  have hw1 : ∑ i, p i ^ r / H = 1 := by rw [← Finset.sum_div]; exact div_self (ne_of_gt hH)
  have h := weighted_factorial_lower N r (fun i => p i ^ r / H) lam
    (fun i => div_nonneg (pow_nonneg (hp i) r) hH.le) hw1 hT hheavy
  have hscaled := mul_le_mul_of_nonneg_left h hH.le
  have hid : H * (∑ i, (p i ^ r / H) * ((N i).descFactorial r : ℝ) / lam i ^ r) =
      ∑ i, ((N i).descFactorial r : ℝ) / n ^ r := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    have hlpos : 0 < lam i := hT.trans_le (hheavy i)
    have hpi : 0 < p i := by rw [hlam i] at hlpos; nlinarith
    have hHne : H ≠ 0 := ne_of_gt hH
    rw [hlam i, mul_pow]
    field_simp [hHne]
  rw [hid] at hscaled
  exact hscaled

end Renyi
