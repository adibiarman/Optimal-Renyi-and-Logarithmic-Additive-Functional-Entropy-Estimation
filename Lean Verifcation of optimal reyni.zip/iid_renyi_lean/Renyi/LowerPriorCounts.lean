import Renyi.LowerDefectAtoms
import Renyi.TensorPriorMoments

/-! Actual tensor priors carrying the exact moment defect and count
probability lower bounds needed for the one-defect experiment. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- Positive-active interpolation priors with their actual count experiment.
The only count-scale condition is the explicit principal-atom mean. -/
theorem positive_tensor_priors_with_counts {r L : ℕ}
    (u : Fin ((r-1)+1)→ℝ) (w : Fin ((L-r)+1)→ℝ)
    (hu : StrictMono u) (hw : StrictMono w) {a b ρ s θ : ℝ}
    (hr : 2≤r) (_hrL : r≤L) (hs : 0<s) (_hs1 : s<1)
    (ha : 0<a) (ha1 : a<1) (hb : 0<b) (hb1 : b<1) (hρ : 0≤ρ)
    (hau : ∀ i, a<u i) (hu1 : ∀ i, u i≤1)
    (hbw : ∀ j, b<w j) (hw1 : ∀ j, w j≤1)
    (hθ : 0≤θ) (hsmall : θ/a≤1) :
    let α := (r:ℝ)+s
    let l := normalizedInterpolation u a ρ s
    let t := normalizedInterpolation w b 0 (1-s)
    let U := interpolationNodes u a
    let W := interpolationNodes w b
    let Rs := ∑ i, negativeCoeff (l i)
    let Rc := ∑ j, negativeCoeff (t j)
    let B := (a*b)⁻¹
    let Z := tensorNormalizer l t U W a α
    let D := B^((r:ℝ)-1)/Z*(a^(-s)*b⁻¹/(interpolationNormalizer u a ρ s*interpolationNormalizer w b 0 (1-s)))
    0<Z ∧ 0<D ∧ ∃ p₀ p₁ : FiniteAtomicPrior
      (Option ((Option (Fin ((r-1)+1))) × (Option (Fin ((L-r)+1))))),
      (∀ i, p₀.value i=0 ∨ (1≤p₀.value i ∧ p₀.value i≤B)) ∧
      (∀ i, p₁.value i=0 ∨ (1≤p₁.value i ∧ p₁.value i≤B)) ∧
      priorMoment p₀ 1=1 ∧ priorMoment p₁ 1=1 ∧
      (∀ j : ℕ, 1≤j → j≤L+1 → j≠r → priorMoment p₁ (j:ℝ)=priorMoment p₀ (j:ℝ)) ∧
      priorMoment p₁ α=B^(α-1)/Z*(1+Rs*Rc) ∧
      priorMoment p₀ α=B^(α-1)/Z*(Rs+Rc) ∧
      Real.log (priorMoment p₁ α/priorMoment p₀ α)=Real.log ((1+Rs*Rc)/(Rs+Rc)) ∧
      (∀ j : ℝ, 0<j → priorMoment p₀ j=B^(j-1)/Z*(∑ ij, tensorNegative l t ij*tensorAtom U W a ij^(j-α))) ∧
      (∀ j : ℝ, 0<j → priorMoment p₁ j=B^(j-1)/Z*(∑ ij, tensorPositive l t ij*tensorAtom U W a ij^(j-α))) ∧
      |priorMoment p₁ (r:ℝ)-priorMoment p₀ (r:ℝ)|≤ρ*D ∧
      (∀ j : ℕ, j≤r → Real.exp (-1)*θ^r*D/(j.factorial:ℝ)≤poissonMixture p₀.mass p₀.value θ j) ∧
      (∀ j : ℕ, j≤r → Real.exp (-1)*θ^r*D/(j.factorial:ℝ)≤poissonMixture p₁.mass p₁.value θ j) := by
  let α := (r:ℝ)+s
  let l := normalizedInterpolation u a ρ s
  let t := normalizedInterpolation w b 0 (1-s)
  let U := interpolationNodes u a
  let W := interpolationNodes w b
  let Rs := ∑ i, negativeCoeff (l i)
  let Rc := ∑ j, negativeCoeff (t j)
  let B := (a*b)⁻¹
  let Z := tensorNormalizer l t U W a α
  let D := B^((r:ℝ)-1)/Z*(a^(-s)*b⁻¹/(interpolationNormalizer u a ρ s*interpolationNormalizer w b 0 (1-s)))
  have hα : 1<α := by
    have hh : (2:ℝ)≤r := by exact_mod_cast hr
    dsimp [α]
    linarith
  have hr0 : (0:ℝ)<r := by exact_mod_cast (show 0<r by omega)
  have hl : ∑ i, positiveCoeff (l i)=1 := normalizedInterpolation_positive_mass u ha hρ
  have ht : ∑ j, positiveCoeff (t j)=1 := normalizedInterpolation_positive_mass w hb (by norm_num)
  have hRs : 0≤Rs := Finset.sum_nonneg (fun _ _ => le_max_right _ _)
  have hRc : 0<Rc := normalizedInterpolation_negative_mass_pos w hw hb hbw (by norm_num)
  have hR : 0<Rs+Rc := add_pos_of_nonneg_of_pos hRs hRc
  have hUa : ∀ i, a≤U i := by intro i; cases i with | none => exact le_rfl | some i => exact (hau i).le
  have hU1 : ∀ i, U i≤1 := by intro i; cases i with | none => exact ha1.le | some i => exact hu1 i
  have hWb : ∀ i, b≤W i := by intro i; cases i with | none => exact le_rfl | some i => exact (hbw i).le
  have hW1 : ∀ i, W i≤1 := by intro i; cases i with | none => exact hb1.le | some i => exact hw1 i
  have hmean : (∑ i, l i*U i^(α-1))*(∑ j, t j*W j^(1-α))=0 := by
    have hz := low_integer_factor_zero u hu.injective (ρ:=ρ) (γ:=s) ha hau 1
      (by norm_num) (by omega) (Or.inl (by omega))
    simp only [Nat.cast_one] at hz
    change (∑ i, l i*U i^(α-1))=0 at hz
    rw [hz,zero_mul]
  obtain ⟨hZ,p₀,p₁,hp₀,hp₁,hm₀,hm₁,hdiff,hA₁,hA₀,hlog,hmoment₀,hmoment₁,
    hmass₀,hmass₁,hvalue₀,hvalue₁,_,_⟩ :=
    tensor_priors_with_atoms l t U W hα ha hb hUa hU1 hWb hW1 hl ht rfl rfl hR hmean
  have hB : 0<B := inv_pos.mpr (mul_pos ha hb)
  have hPs := interpolationNormalizer_pos u (e:=s) ha hρ
  have hPc := interpolationNormalizer_pos w (e:=1-s) hb (show (0:ℝ)≤0 by norm_num)
  have hD : 0<D := by dsimp [D]; positivity
  have hv₀ : ∀ i, 0≤p₀.value i := fun i => (hp₀ i).elim (fun h => h ▸ le_rfl) (fun h => le_trans zero_le_one h.1)
  have hv₁ : ∀ i, 0≤p₁.value i := fun i => (hp₁ i).elim (fun h => h ▸ le_rfl) (fun h => le_trans zero_le_one h.1)
  have he₀ : α-(r:ℝ)=s := by dsimp [α]; ring
  have he₁ : (r:ℝ)-α= -s := by dsimp [α]; ring
  have hfirst := lagrangeWeight_first_ge_one u hu (hau 0).le
  have hatoms := positive_tensor_designated_atoms u w (s:=s) ha hb
    (fun i => ha.trans (hau i)) (fun i => hb.trans (hbw i)) hρ hfirst
  dsimp only at hatoms
  have hz : ∀ ij, 0<tensorAtom U W a ij :=
    tensorAtom_pos U W ha (interpolationNodes_pos u ha hau) (interpolationNodes_pos w hb hbw)
  have hvalp : B*tensorAtom U W a (none,none)=1/a := by
    dsimp [B,tensorAtom,U,W,interpolationNodes]
    field_simp
  have hvaln : B*tensorAtom U W a (some 0,none)=1/u 0 := by
    dsimp [B,tensorAtom,U,W,interpolationNodes]
    field_simp [(ha.trans (hau 0)).ne']
  refine ⟨hZ,hD,p₀,p₁,hp₀,hp₁,hm₀,hm₁,?_,hA₁,hA₀,hlog,hmoment₀,hmoment₁,?_,?_,?_⟩
  · intro j hj1 hjL hjr
    have hj : (0:ℝ)<j := by exact_mod_cast (show 0<j by omega)
    have hh := hdiff (j:ℝ) hj
    have hz := noninteger_tensor_factor_cancellation u w hu.injective hw.injective
      (ρl:=ρ) (ρr:=0) (γ:=s) ha hb hau hbw j hj1 hjL (Or.inl hjr) (Or.inr rfl)
    change (∑ i, l i*(U i/a)^(α-(j:ℝ)))*(∑ v, t v*W v^((j:ℝ)-α))=0 at hz
    rw [hz,mul_zero] at hh
    exact sub_eq_zero.mp hh
  · rw [hdiff (r:ℝ) hr0,he₀,he₁]
    exact positive_tensor_defect_bound u w hu.injective hw.injective ha hb hρ (by positivity) hau hbw
  · intro j hj
    apply prior_count_atom_of_reweightedMass p₀ (some (some 0,none)) hB hZ (hz _) hθ hv₀
      (hmass₀ _) (hvalue₀ _)
    · rw [he₁]
      exact hatoms.2
    · rw [hvaln]
      have hh := (div_le_div_of_nonneg_left hθ ha (hau 0).le).trans hsmall
      simpa only [mul_one_div] using hh
    · exact hj
  · intro j hj
    apply prior_count_atom_of_reweightedMass p₁ (some (none,none)) hB hZ (hz _) hθ hv₁
      (hmass₁ _) (hvalue₁ _)
    · rw [he₁]
      exact hatoms.1
    · rw [hvalp]
      simpa only [mul_one_div] using hsmall
    · exact hj


/-- Negative-active interpolation priors with their actual count experiment. -/
theorem negative_tensor_priors_with_counts {r L : ℕ}
    (u : Fin ((r-1)+1)→ℝ) (w : Fin ((L-r)+1)→ℝ)
    (hu : StrictMono u) (hw : StrictMono w) {a b ρ s θ : ℝ}
    (hr : 1≤r) (_hrL : r≤L) (_hs : 0<s) (hs1 : s<1)
    (ha : 0<a) (ha1 : a<1) (hb : 0<b) (hb1 : b<1) (hρ : 0≤ρ)
    (hau : ∀ i, a<u i) (hu1 : ∀ i, u i≤1)
    (hbw : ∀ j, b<w j) (hw1 : ∀ j, w j≤1)
    (hθ : 0≤θ) (hsmall : θ*(a*b)⁻¹*w 0≤1) :
    let α := (r:ℝ)+(1-s)
    let l := normalizedInterpolation u a 0 (1-s)
    let t := normalizedInterpolation w b ρ s
    let U := interpolationNodes u a
    let W := interpolationNodes w b
    let Rs := ∑ i, negativeCoeff (l i)
    let Rc := ∑ j, negativeCoeff (t j)
    let B := (a*b)⁻¹
    let Z := tensorNormalizer l t U W a α
    let D := B^(((r+1:ℕ):ℝ)-1)/Z*(a^(s-1)/(interpolationNormalizer u a 0 (1-s)*interpolationNormalizer w b ρ s))
    0<Z ∧ 0<D ∧ ∃ p₀ p₁ : FiniteAtomicPrior
      (Option ((Option (Fin ((r-1)+1))) × (Option (Fin ((L-r)+1))))),
      (∀ i, p₀.value i=0 ∨ (1≤p₀.value i ∧ p₀.value i≤B)) ∧
      (∀ i, p₁.value i=0 ∨ (1≤p₁.value i ∧ p₁.value i≤B)) ∧
      priorMoment p₀ 1=1 ∧ priorMoment p₁ 1=1 ∧
      (∀ j : ℕ, 1≤j → j≤L+1 → j≠r+1 → priorMoment p₁ (j:ℝ)=priorMoment p₀ (j:ℝ)) ∧
      priorMoment p₁ α=B^(α-1)/Z*(1+Rs*Rc) ∧
      priorMoment p₀ α=B^(α-1)/Z*(Rs+Rc) ∧
      Real.log (priorMoment p₁ α/priorMoment p₀ α)=Real.log ((1+Rs*Rc)/(Rs+Rc)) ∧
      (∀ j : ℝ, 0<j → priorMoment p₀ j=B^(j-1)/Z*(∑ ij, tensorNegative l t ij*tensorAtom U W a ij^(j-α))) ∧
      (∀ j : ℝ, 0<j → priorMoment p₁ j=B^(j-1)/Z*(∑ ij, tensorPositive l t ij*tensorAtom U W a ij^(j-α))) ∧
      |priorMoment p₁ ((r+1:ℕ):ℝ)-priorMoment p₀ ((r+1:ℕ):ℝ)|≤ρ*D ∧
      (∀ j : ℕ, j≤r+1 → Real.exp (-1)*θ^(r+1)*D/(j.factorial:ℝ)≤poissonMixture p₀.mass p₀.value θ j) ∧
      (∀ j : ℕ, j≤r+1 → Real.exp (-1)*θ^(r+1)*D/(j.factorial:ℝ)≤poissonMixture p₁.mass p₁.value θ j) := by
  let α := (r:ℝ)+(1-s)
  let l := normalizedInterpolation u a 0 (1-s)
  let t := normalizedInterpolation w b ρ s
  let U := interpolationNodes u a
  let W := interpolationNodes w b
  let Rs := ∑ i, negativeCoeff (l i)
  let Rc := ∑ j, negativeCoeff (t j)
  let B := (a*b)⁻¹
  let Z := tensorNormalizer l t U W a α
  let D := B^(((r+1:ℕ):ℝ)-1)/Z*(a^(s-1)/(interpolationNormalizer u a 0 (1-s)*interpolationNormalizer w b ρ s))
  have hα : 1<α := by
    have hh : (1:ℝ)≤r := by exact_mod_cast hr
    dsimp [α]
    linarith
  have hr0 : (0:ℝ)<((r+1:ℕ):ℝ) := by exact_mod_cast (show 0<r+1 by omega)
  have hl : ∑ i, positiveCoeff (l i)=1 := normalizedInterpolation_positive_mass u ha (by norm_num)
  have ht : ∑ j, positiveCoeff (t j)=1 := normalizedInterpolation_positive_mass w hb hρ
  have hRs : 0≤Rs := Finset.sum_nonneg (fun _ _ => le_max_right _ _)
  have hRc : 0<Rc := normalizedInterpolation_negative_mass_pos w hw hb hbw hρ
  have hR : 0<Rs+Rc := add_pos_of_nonneg_of_pos hRs hRc
  have hUa : ∀ i, a≤U i := by intro i; cases i with | none => exact le_rfl | some i => exact (hau i).le
  have hU1 : ∀ i, U i≤1 := by intro i; cases i with | none => exact ha1.le | some i => exact hu1 i
  have hWb : ∀ i, b≤W i := by intro i; cases i with | none => exact le_rfl | some i => exact (hbw i).le
  have hW1 : ∀ i, W i≤1 := by intro i; cases i with | none => exact hb1.le | some i => exact hw1 i
  have hmean : (∑ i, l i*U i^(α-1))*(∑ j, t j*W j^(1-α))=0 := by
    have hz := low_integer_factor_zero u hu.injective (ρ:=0) (γ:=1-s) ha hau 1
      (by norm_num) (by omega) (Or.inr rfl)
    simp only [Nat.cast_one] at hz
    change (∑ i, l i*U i^(α-1))=0 at hz
    rw [hz,zero_mul]
  obtain ⟨hZ,p₀,p₁,hp₀,hp₁,hm₀,hm₁,hdiff,hA₁,hA₀,hlog,hmoment₀,hmoment₁,
    hmass₀,hmass₁,hvalue₀,hvalue₁,_,_⟩ :=
    tensor_priors_with_atoms l t U W hα ha hb hUa hU1 hWb hW1 hl ht rfl rfl hR hmean
  have hB : 0<B := inv_pos.mpr (mul_pos ha hb)
  have hPs := interpolationNormalizer_pos u (e:=1-s) ha (show (0:ℝ)≤0 by norm_num)
  have hPc := interpolationNormalizer_pos w (e:=s) hb hρ
  have hD : 0<D := by dsimp [D]; positivity
  have hv₀ : ∀ i, 0≤p₀.value i := fun i => (hp₀ i).elim (fun h => h ▸ le_rfl) (fun h => le_trans zero_le_one h.1)
  have hv₁ : ∀ i, 0≤p₁.value i := fun i => (hp₁ i).elim (fun h => h ▸ le_rfl) (fun h => le_trans zero_le_one h.1)
  have he₀ : α-((r+1:ℕ):ℝ)= -s := by dsimp [α]; push_cast; ring
  have he₁ : ((r+1:ℕ):ℝ)-α=s := by dsimp [α]; push_cast; ring
  have hfirst := lagrangeWeight_first_ge_one w hw (hbw 0).le
  have hatoms := negative_tensor_designated_atoms u w (s:=s) ha hb
    (fun i => ha.trans (hau i)) (fun i => hb.trans (hbw i)) hρ hfirst
  dsimp only at hatoms
  have hz : ∀ ij, 0<tensorAtom U W a ij :=
    tensorAtom_pos U W ha (interpolationNodes_pos u ha hau) (interpolationNodes_pos w hb hbw)
  have hvaln : B*tensorAtom U W a (none,some 0)=B*w 0 := by
    dsimp [tensorAtom,U,W,interpolationNodes]
    field_simp
  have hsmallp : θ*(B*tensorAtom U W a (none,none))≤1 := by
    have hvalue : tensorAtom U W a (none,none)=b := by
      dsimp [tensorAtom,U,W,interpolationNodes]
      field_simp
    rw [hvalue]
    have hh := mul_le_mul_of_nonneg_left (hbw 0).le (show 0≤θ*B by positivity)
    change θ*B*w 0≤1 at hsmall
    nlinarith only [hh,hsmall]
  refine ⟨hZ,hD,p₀,p₁,hp₀,hp₁,hm₀,hm₁,?_,hA₁,hA₀,hlog,hmoment₀,hmoment₁,?_,?_,?_⟩
  · intro j hj1 hjL hjr
    have hj : (0:ℝ)<j := by exact_mod_cast (show 0<j by omega)
    have hh := hdiff (j:ℝ) hj
    have hz := noninteger_tensor_factor_cancellation u w hu.injective hw.injective
      (ρl:=0) (ρr:=ρ) (γ:=1-s) ha hb hau hbw j hj1 hjL (Or.inr rfl) (Or.inl hjr)
    rw [show 1-(1-s)=s by ring] at hz
    change (∑ i, l i*(U i/a)^(α-(j:ℝ)))*(∑ v, t v*W v^((j:ℝ)-α))=0 at hz
    rw [hz,mul_zero] at hh
    exact sub_eq_zero.mp hh
  · rw [hdiff ((r+1:ℕ):ℝ) hr0,he₀,he₁]
    exact negative_tensor_defect_bound u w hu.injective hw.injective ha hb hρ (by positivity) hau hbw
  · intro j hj
    apply prior_count_atom_of_reweightedMass p₀ (some (none,some 0)) hB hZ (hz _) hθ hv₀
      (hmass₀ _) (hvalue₀ _)
    · rw [he₁]
      exact hatoms.2
    · rw [hvaln]
      simpa only [mul_assoc] using hsmall
    · exact hj
  · intro j hj
    apply prior_count_atom_of_reweightedMass p₁ (some (none,none)) hB hZ (hz _) hθ hv₁
      (hmass₁ _) (hvalue₁ _)
    · rw [he₁]
      exact hatoms.1
    · exact hsmallp
    · exact hj

end Renyi
