import Renyi.NearOneMeanSmallScale

/-! Fixed scalar choices for the iid near-one entropy estimator. -/
noncomputable section
namespace Renyi

/-- The large-mean Gamma error can be made arbitrarily small by a fixed cutoff. -/
theorem near_one_large_cutoff {eta:ℝ} (heta:0<eta) :
    ∃B:ℝ,16≤B ∧ Real.exp (-B/2)≤eta := by
  refine ⟨max 16 (-2*Real.log eta),le_max_left _ _,?_⟩
  calc
    Real.exp (-max 16 (-2*Real.log eta)/2)≤Real.exp (Real.log eta) := by
      apply Real.exp_le_exp.mpr
      have hh:=le_max_right (16:ℝ) (-2*Real.log eta)
      linarith only [hh]
    _=eta:=Real.exp_log heta

/-- Explicit small approximation budgets leave half the source entropy margin. -/
theorem near_one_iid_small_budgets {eps:ℝ} (heps:0<eps) :
    let cm:=nearOneMarginConstant eps (1/2)
    let cu:=cm/16
    let eta:=cm/16
    0<cu ∧ 0<eta ∧ 2*cu+4*eta≤cm/2 := by
  have hcm:=nearOneMarginConstant_pos heps (by norm_num : (0:ℝ)<1/2) (by norm_num : (1/2:ℝ)<1)
  dsimp only
  constructor
  · positivity
  constructor
  · positivity
  · linarith only [hcm]


/-- All fixed scalar parameters for the near-one mean are chosen before cL;
the final sample multiplier is chosen after that logarithmic degree slope. -/
theorem near_one_iid_mean_parameters {eps:ℝ} (heps:0<eps) :
    ∃cu B CL cp:ℝ,0<cu ∧ 16≤B ∧ 1≤CL ∧ 80≤cp ∧ 2*Real.exp 1≤cp ∧
      ∀cL:ℝ,0<cL → ∃D0:ℝ,1≤D0 ∧ ∀(k:ℕ) (alpha D:ℝ),
      0<k → 1<alpha → alpha≤3/2 → D0≤D → ∀p:Simplex k,
      let N:=upperDegree alpha CL cL (rootMultiplier k alpha eps)
      |actualNearOneExpectedMean N alpha eps 0 D 1 1 CL cL 1 0 (1/2) (1/2) cu 1 cp B 0 p-
        upperOmega k alpha eps 0 (1/2)*powerSum p alpha|≤
          nearOneMarginConstant eps (1/2)*(alpha-1)*powerSum p alpha/2 := by
  let cm:=nearOneMarginConstant eps (1/2)
  let cu:=cm/16
  let eta:=cm/16
  have hcm:0<cm:=nearOneMarginConstant_pos heps (by norm_num) (by norm_num)
  have hcu:0<cu:=by dsimp [cu]; positivity
  have heta:0<eta:=by dsimp [eta]; positivity
  obtain ⟨B,hB,hlarge⟩:=near_one_large_cutoff heta
  let CL:=2*B+1
  have hCL:1≤CL:=by dsimp [CL]; linarith only [hB]
  have hCLB:2*B≤1*CL:=by dsimp [CL]; linarith
  obtain ⟨cp0,hcp0,hmean⟩:=actual_near_one_expected_mean_calibrated
    (eps:=eps) (cb:=1) (lambda:=1) (CL:=CL) (cmin:=1) (q:=1) (Q:=1)
    (M:=0) (cw:=1/2) (f:=1/2) (cu:=cu) (u0:=1) (B:=B) (eta:=eta)
    heps (by norm_num) (by norm_num) hCL (by norm_num) (by norm_num) (by norm_num)
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
    hcu.le (by norm_num) hB hCLB heta hlarge
  let cp:=max cp0 (max 80 (2*Real.exp 1))
  have hcp0cp:cp0≤cp:=le_max_left _ _
  have hcp:80≤cp:=(le_max_left _ _).trans (le_max_right _ _)
  have hcpExp:2*Real.exp 1≤cp:=(le_max_right _ _).trans (le_max_right _ _)
  refine ⟨cu,B,CL,cp,hcu,hB,hCL,hcp,hcpExp,?_⟩
  intro cL hcL
  obtain ⟨D0,hD0,hsmall⟩:=hmean cp hcp0cp cL hcL
  refine ⟨D0,hD0,?_⟩
  intro k alpha D hk ha ha1 hD p
  dsimp only
  let N:=upperDegree alpha CL cL (rootMultiplier k alpha eps)
  have hh:=hsmall k N alpha 0 D 1 hk ha ha1 (by norm_num) hD
    (by norm_num) (by norm_num) (by simp only [N,one_mul,le_refl])
    (by simp only [N,one_mul,le_refl]) p
  have hbudget:2*cu+4*eta≤cm/2:=by dsimp [cu,eta]; linarith only [hcm]
  have hP:0≤powerSum p alpha:=Finset.sum_nonneg (fun i _=>Real.rpow_nonneg (p.nonneg i) _)
  have hbeta:0≤alpha-1:=by linarith only [ha]
  exact hh.trans (by
    change (2*cu+4*eta)*(alpha-1)*powerSum p alpha≤cm*(alpha-1)*powerSum p alpha/2
    have hm:=mul_le_mul_of_nonneg_right hbudget (mul_nonneg hbeta hP)
    nlinarith only [hm])

end Renyi
