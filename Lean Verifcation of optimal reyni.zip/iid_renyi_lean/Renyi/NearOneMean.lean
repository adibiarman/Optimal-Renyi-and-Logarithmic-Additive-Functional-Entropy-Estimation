import Renyi.AnalyticNoise
import Renyi.FalseClassification
import Renyi.NearOnePolynomial
import Renyi.NearOneActualBias

/-! Actual mean ingredients for the near-one hybrid estimator. -/
noncomputable section
open scoped NNReal BigOperators
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- Uniform signed Gamma bias, including the zero-mean Poisson law. -/
theorem analyticMean_near_one_bias_all {beta : ℝ} (hb : 0<beta) (hb1 : beta≤1/2)
    (lam : ℝ≥0) :
    |analyticMean lam (1+beta)-(lam:ℝ)^(1+beta)|≤2*beta*Real.exp (-(lam:ℝ)) := by
  by_cases hl0 : lam=0
  · subst lam
    rw [analyticMean_zero]
    simp only [NNReal.coe_zero,Real.zero_rpow (by linarith : 1+beta≠0),sub_zero,
      neg_zero,Real.exp_zero,mul_one,show 1-(1+beta)=-beta by ring]
    rw [gamma_inv_recurrence]
    have hG : 0<Real.Gamma (1-beta) := Real.Gamma_pos_of_pos (by linarith)
    have hG1 := gamma_one_le_of_pos_le_one (by linarith : 0<1-beta) (by linarith : 1-beta≤1)
    have hi : (Real.Gamma (1-beta))⁻¹≤1 := (inv_le_one₀ hG).mpr hG1
    rw [show -beta+1=1-beta by ring,abs_mul,abs_neg,abs_of_nonneg hb.le,
      abs_of_nonneg (inv_nonneg.mpr hG.le)]
    nlinarith
  have hl : 0<(lam:ℝ) := by exact_mod_cast (pos_iff_ne_zero.mpr hl0)
  have hG : Real.Gamma (1+beta+1)≤2 := by
    have h := Real.Gamma_strictMonoOn_Ici.monotoneOn
      (by simp only [Set.mem_Ici]; linarith : 1+beta+1∈Set.Ici (2:ℝ))
      (by norm_num : (3:ℝ)∈Set.Ici (2:ℝ)) (by linarith : 1+beta+1≤3)
    norm_num [Real.Gamma_add_one] at h
    exact h
  have hs : |Real.sin (Real.pi*(1+beta))|≤Real.pi*beta := by
    rw [show Real.pi*(1+beta)=Real.pi*beta+Real.pi by ring,Real.sin_add_pi,abs_neg]
    exact (Real.abs_sin_le_abs (x:=Real.pi*beta)).trans_eq (abs_of_nonneg (by positivity))
  have hmin : min (1+beta)⁻¹ (lam:ℝ)⁻¹≤1 :=
    (min_le_left _ _).trans ((inv_le_one₀ (by linarith : 0<1+beta)).mpr (by linarith))
  have h := analyticMean_bias_bound lam hl (1+beta) (by linarith)
  apply h.trans
  calc
    _ ≤ 2*(Real.pi*beta)/Real.pi*Real.exp (-(lam:ℝ))*1 := by
      gcongr
    _ = _ := by field_simp

theorem near_one_heavy_pilot_bias_factor {cp B alpha eta : ℝ}
    (hcp : 1≤cp) (hB : 16≤B) (ha : 1≤alpha) (heta : 0≤eta)
    (hlarge : Real.exp (-B/2)≤eta) (hsmall : Real.exp (-cp)≤eta)
    (lam : ℝ≥0) :
    poissonUpperMass ⟨cp*lam,mul_nonneg (by linarith) lam.coe_nonneg⟩ (cp*B*alpha)*
      Real.exp (-(lam:ℝ))≤eta*(lam:ℝ)^alpha := by
  have hcp0 : 0<cp := by linarith
  have ha0 : 0<alpha := by linarith
  have hmass := poissonUpperMass_nonneg
    ⟨cp*lam,mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp*B*alpha)
  have hmass1 : poissonUpperMass ⟨cp*lam,mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp*B*alpha)≤1 := by
    have h := poissonUpperMass_exp_bound
      ⟨cp*lam,mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp*B*alpha) (t:=0) le_rfl
    simpa using h
  have hex1 : Real.exp (-(lam:ℝ))≤1 := Real.exp_le_one_iff.mpr (neg_nonpos.mpr lam.coe_nonneg)
  by_cases hl0 : lam=0
  · subst lam
    simp only [NNReal.coe_zero,mul_zero,NNReal.mk_zero]
    rw [poissonUpperMass_zero (by positivity)]
    norm_num [Real.zero_rpow ha0.ne']
  have hl : 0<(lam:ℝ) := by exact_mod_cast (pos_iff_ne_zero.mpr hl0)
  by_cases hlargeLam : B*alpha/2≤(lam:ℝ)
  · have hBl : B/2≤(lam:ℝ) := by nlinarith
    have hl1 : 1≤(lam:ℝ) := by nlinarith
    have hex : Real.exp (-(lam:ℝ))≤eta :=
      (Real.exp_le_exp.mpr (by linarith : -(lam:ℝ)≤-B/2)).trans hlarge
    have hp : 1≤(lam:ℝ)^alpha := Real.one_le_rpow hl1 ha0.le
    have hh := mul_le_of_le_one_left (Real.exp_pos (-(lam:ℝ))).le hmass1
    exact (hh.trans hex).trans (by nlinarith)
  have hsmallLam : (lam:ℝ)≤B*alpha/2 := (lt_of_not_ge hlargeLam).le
  by_cases hl1 : 1≤(lam:ℝ)
  · have htail := false_heavy_pilot_large hcp0 hB ha0 lam hsmallLam
    have hex : Real.exp (-cp*alpha)≤eta :=
      (Real.exp_le_exp.mpr (by nlinarith : -cp*alpha≤-cp)).trans hsmall
    have hp : 1≤(lam:ℝ)^alpha := Real.one_le_rpow hl1 ha0.le
    have hh := mul_le_of_le_one_right hmass hex1
    exact (hh.trans (htail.trans hex)).trans (by nlinarith)
  have hl1' : (lam:ℝ)≤1 := (lt_of_not_ge hl1).le
  have htail := false_heavy_pilot_small hcp0 hB ha0 lam hl (hl1'.trans ha)
  have hex : Real.exp (-12*cp*alpha)≤eta :=
    (Real.exp_le_exp.mpr (by nlinarith : -12*cp*alpha≤-cp)).trans hsmall
  have hdiv : (lam:ℝ)/alpha≤(lam:ℝ) := (div_le_iff₀ ha0).mpr (by nlinarith)
  have hpow : ((lam:ℝ)/alpha)^(cp*B*alpha)≤(lam:ℝ)^alpha :=
    (Real.rpow_le_rpow (div_nonneg hl.le ha0.le) hdiv (by positivity)).trans
      (Real.rpow_le_rpow_of_exponent_ge hl hl1' (by nlinarith : alpha≤cp*B*alpha))
  have hh := mul_le_mul hex hpow (Real.rpow_nonneg (div_nonneg hl.le ha0.le) _) heta
  exact (mul_le_of_le_one_right hmass hex1).trans (htail.trans hh)


/-- Fixed pilot constants make the actual Gamma mean error arbitrarily small
relative to the power target, uniformly down to zero means and beta=0+. -/
theorem near_one_heavy_mean_uniform {eta : ℝ} (heta : 0<eta) :
    ∃ B cp0 : ℝ, 16≤B ∧ 1≤cp0 ∧ ∀ (cp : ℝ) (hcp1 : 1≤cp), cp0≤cp → ∀ beta : ℝ,
      0<beta → beta≤1/2 → ∀ lam : ℝ≥0,
      poissonUpperMass ⟨cp*lam,mul_nonneg (by linarith) lam.coe_nonneg⟩ (cp*B*(1+beta))*
        |analyticMean lam (1+beta)-(lam:ℝ)^(1+beta)|≤
          2*eta*beta*(lam:ℝ)^(1+beta) := by
  let B := max 16 (-2*Real.log eta)
  let cp0 := max 1 (-Real.log eta)
  have hB : 16≤B := le_max_left _ _
  have hcp0 : 1≤cp0 := le_max_left _ _
  refine ⟨B,cp0,hB,hcp0,?_⟩
  intro cp hcp1 hcp beta hb hb1 lam
  have hlarge : Real.exp (-B/2)≤eta := by
    rw [← Real.exp_log heta]
    apply Real.exp_le_exp.mpr
    have := le_max_right (16:ℝ) (-2*Real.log eta)
    change -2*Real.log eta≤B at this
    linarith
  have hsmall : Real.exp (-cp)≤eta := by
    rw [← Real.exp_log heta]
    apply Real.exp_le_exp.mpr
    have hh : -Real.log eta≤cp := (le_max_right _ _).trans hcp
    linarith
  have hfactor := near_one_heavy_pilot_bias_factor hcp1 hB (by linarith : 1≤1+beta)
    heta.le hlarge hsmall lam
  have hmean := analyticMean_near_one_bias_all hb hb1 lam
  have hmass := poissonUpperMass_nonneg
    ⟨cp*lam,mul_nonneg (by linarith) lam.coe_nonneg⟩ (cp*B*(1+beta))
  have hm := mul_le_mul_of_nonneg_left hmean hmass
  have hf := mul_le_mul_of_nonneg_left hfactor (by positivity : 0≤2*beta)
  nlinarith only [hm,hf]

end Renyi
