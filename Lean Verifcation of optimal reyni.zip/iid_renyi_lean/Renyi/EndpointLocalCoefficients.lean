import Renyi.EndpointKernel
import Renyi.CoupledProfiles
import Mathlib.Analysis.SpecialFunctions.Arsinh

/-! Local absolute coefficient norms of the actual endpoint kernel. -/

noncomputable section
open scoped BigOperators
open Polynomial Polynomial.Chebyshev
namespace Renyi

def unsignedEndpointSquare (n : ℕ) : ℝ[X] := (endpointSquarePolynomial n).comp (-X)

lemma polynomial_product_coeff_nonneg (P Q : ℝ[X]) (hP : ∀ j, 0 ≤ P.coeff j)
    (hQ : ∀ j, 0 ≤ Q.coeff j) (j : ℕ) : 0 ≤ (P * Q).coeff j := by
  rw [coeff_mul]
  exact Finset.sum_nonneg (fun ij _ => mul_nonneg (hP ij.1) (hQ ij.2))

lemma polynomial_nat_coeff_nonneg (n j : ℕ) : 0 ≤ (n : ℝ[X]).coeff j := by
  by_cases hj : j = 0
  · subst j; simp
  · simp [hj]

lemma polynomial_X_coeff_nonneg (j : ℕ) : 0 ≤ (X : ℝ[X]).coeff j := by
  rw [coeff_X]
  split_ifs <;> norm_num

lemma unsignedEndpointSquare_difference (n : ℕ) :
    unsignedEndpointSquare (n + 2) - unsignedEndpointSquare (n + 1) =
      (unsignedEndpointSquare (n + 1) - unsignedEndpointSquare n) +
        4 * X * unsignedEndpointSquare (n + 1) + 2 := by
  unfold unsignedEndpointSquare
  rw [endpointSquarePolynomial]
  simp only [add_comp, sub_comp, mul_comp, ofNat_comp, X_comp]
  ring

/-- The transformed kernel has positive coefficients and positive first differences. -/
theorem unsignedEndpointSquare_coeff_nonneg (n : ℕ) :
    (∀ j, 0 ≤ (unsignedEndpointSquare n).coeff j) ∧
      (∀ j, 0 ≤ (unsignedEndpointSquare (n + 1) - unsignedEndpointSquare n).coeff j) := by
  induction n with
  | zero =>
      constructor
      · intro j
        simpa [unsignedEndpointSquare, endpointSquarePolynomial] using polynomial_nat_coeff_nonneg 1 j
      · intro j
        have heq : unsignedEndpointSquare 1 - unsignedEndpointSquare 0 = (3 + 4 * X : ℝ[X]) := by
          simp only [unsignedEndpointSquare, endpointSquarePolynomial, sub_comp, mul_comp, ofNat_comp, X_comp, one_comp]
          ring
        rw [heq, coeff_add]
        have hp := polynomial_product_coeff_nonneg (4 : ℝ[X]) X (polynomial_nat_coeff_nonneg 4) polynomial_X_coeff_nonneg j
        exact add_nonneg (polynomial_nat_coeff_nonneg 3 j) hp
  | succ n ih =>
      have hn : ∀ j, 0 ≤ (unsignedEndpointSquare (n + 1)).coeff j := by
        intro j
        have h := ih.2 j
        rw [coeff_sub] at h
        linarith [ih.1 j]
      refine ⟨hn, ?_⟩
      intro j
      rw [show n.succ + 1 = n + 2 by omega, unsignedEndpointSquare_difference, coeff_add, coeff_add]
      have hprod := polynomial_product_coeff_nonneg (4 * X) (unsignedEndpointSquare (n + 1))
        (fun k => polynomial_product_coeff_nonneg 4 X (polynomial_nat_coeff_nonneg 4) polynomial_X_coeff_nonneg k) hn j
      exact add_nonneg (add_nonneg (ih.2 j) hprod) (polynomial_nat_coeff_nonneg 2 j)

lemma cosh_le_exp_nonnegative {x : ℝ} (hx : 0 ≤ x) : Real.cosh x ≤ Real.exp x := by
  rw [Real.cosh_eq]
  have h := Real.exp_le_exp.mpr (by linarith : -x ≤ x)
  linarith

lemma sinh_nat_mul_growth {θ : ℝ} (hθ : 0 ≤ θ) (n : ℕ) :
    Real.sinh (((n : ℝ) + 1) * θ) ≤
      ((n : ℝ) + 1) * Real.exp ((n : ℝ) * θ) * Real.sinh θ := by
  have hs : 0 ≤ Real.sinh θ := Real.sinh_nonneg_iff.mpr hθ
  induction n with
  | zero => simp
  | succ n ih =>
      have hn : 0 ≤ (n : ℝ) + 1 := by positivity
      have hc1 := cosh_le_exp_nonnegative hθ
      have hc2 := cosh_le_exp_nonnegative (mul_nonneg hn hθ)
      have hh : ((n + 1 : ℕ) : ℝ) + 1 = (n : ℝ) + 1 + 1 := by push_cast; ring
      rw [hh, add_mul, one_mul, Real.sinh_add]
      have hfirst := mul_le_mul ih hc1 (Real.cosh_pos _).le
        (by positivity : 0 ≤ ((n : ℝ) + 1) * Real.exp ((n : ℝ) * θ) * Real.sinh θ)
      have hsecond := mul_le_mul_of_nonneg_right hc2 hs
      have hid : Real.exp ((n : ℝ) * θ) * Real.exp θ = Real.exp (((n : ℝ) + 1) * θ) := by
        rw [← Real.exp_add]
        congr 1
        ring
      calc
        _ ≤ (((n : ℝ) + 1) * Real.exp ((n : ℝ) * θ) * Real.sinh θ) * Real.exp θ +
            Real.exp (((n : ℝ) + 1) * θ) * Real.sinh θ := add_le_add hfirst hsecond
        _ = _ := by
          push_cast
          rw [← hid]
          ring

/-- Chebyshev growth outside the unit interval has the correct endpoint scale. -/
theorem chebyshev_U_sqrt_growth {x : ℝ} (hx : 0 ≤ x) (n : ℕ) :
    |(U ℝ (n : ℤ)).eval (Real.sqrt (1 + x))| ≤
      ((n : ℝ) + 1) * Real.exp ((n : ℝ) * Real.sqrt x) := by
  by_cases hx0 : x = 0
  · simp [hx0, U_eval_one, abs_of_nonneg (by positivity : 0 ≤ (n : ℝ) + 1)]
  · have hxpos : 0 < x := lt_of_le_of_ne hx (Ne.symm hx0)
    let θ := Real.arsinh (Real.sqrt x)
    have hθ : 0 < θ := Real.arsinh_pos_iff.mpr (Real.sqrt_pos.mpr hxpos)
    have hcosh : Real.cosh θ = Real.sqrt (1 + x) := by
      dsimp [θ]
      rw [Real.cosh_arsinh, Real.sq_sqrt hx]
    have h := U_real_cosh θ (n : ℤ)
    rw [hcosh] at h
    push_cast at h
    have hS := sinh_nat_mul_growth hθ.le n
    rw [← h] at hS
    have hbound := (mul_le_mul_iff_left₀ (Real.sinh_pos_iff.mpr hθ)).mp hS
    have hUnonneg : 0 ≤ (U ℝ (n : ℤ)).eval (Real.sqrt (1 + x)) := by
      have hs := Real.sinh_nonneg_iff.mpr (show 0 ≤ ((n : ℝ) + 1) * θ by positivity)
      rw [← h] at hs
      nlinarith [Real.sinh_pos_iff.mpr hθ]
    rw [abs_of_nonneg hUnonneg]
    have hθupper : θ ≤ Real.sqrt x := by
      have hs := Real.self_le_sinh_iff.mpr hθ.le
      dsimp [θ] at hs ⊢
      rwa [Real.sinh_arsinh] at hs
    exact hbound.trans (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr
      (mul_le_mul_of_nonneg_left hθupper (Nat.cast_nonneg n))) (by positivity))

/-- Scaling a polynomial multiplies its coefficients by the corresponding count powers. -/
lemma coefficientMass_comp_scale_sum (P : ℝ[X]) (x : ℝ) :
    coefficientMass (P.comp (C x * X)) = P.sum (fun j a => |a * x ^ j|) := by
  unfold coefficientMass
  have hs : (P.comp (C x * X)).support ⊆ P.support := by
    intro j hj
    by_contra hn
    have hz := notMem_support_iff.mp hn
    have hscaled : (P.comp (C x * X)).coeff j = 0 := by rw [comp_C_mul_X_coeff, hz]; simp
    exact (mem_support_iff.mp hj) hscaled
  rw [Polynomial.sum_eq_of_subset _ (by simp) hs]
  simp only [comp_C_mul_X_coeff, Polynomial.sum_def]

/-- The positive transformed coefficient is the absolute original coefficient. -/
lemma unsignedEndpointSquare_coeff_abs (n j : ℕ) :
    (unsignedEndpointSquare n).coeff j = |(endpointSquarePolynomial n).coeff j| := by
  have hcoeff : (unsignedEndpointSquare n).coeff j =
      (endpointSquarePolynomial n).coeff j * (-1 : ℝ) ^ j := by
    unfold unsignedEndpointSquare
    have h := comp_C_mul_X_coeff (p := endpointSquarePolynomial n) (r := (-1 : ℝ)) (n := j)
    simpa using h
  calc
    _ = |(unsignedEndpointSquare n).coeff j| := (abs_of_nonneg ((unsignedEndpointSquare_coeff_nonneg n).1 j)).symm
    _ = _ := by rw [hcoeff, abs_mul, abs_pow]; simp

/-- The local absolute coefficient norm is exactly the external Chebyshev value. -/
theorem endpointSquarePolynomial_local_mass {x : ℝ} (hx : 0 ≤ x) (n : ℕ) :
    coefficientMass ((endpointSquarePolynomial n).comp (C x * X)) =
      (U ℝ (n : ℤ)).eval (Real.sqrt (1 + x)) ^ 2 := by
  rw [coefficientMass_comp_scale_sum]
  have heq : (endpointSquarePolynomial n).sum (fun j a => |a * x ^ j|) =
      (unsignedEndpointSquare n).eval x := by
    unfold unsignedEndpointSquare
    rw [eval_comp, eval_neg, eval_X, eval_eq_sum]
    simp only [Polynomial.sum_def]
    apply Finset.sum_congr rfl
    intro j _
    have habs := unsignedEndpointSquare_coeff_abs n j
    have hcoeff : (unsignedEndpointSquare n).coeff j =
        (endpointSquarePolynomial n).coeff j * (-1 : ℝ) ^ j := by
      unfold unsignedEndpointSquare
      have h := comp_C_mul_X_coeff (p := endpointSquarePolynomial n) (r := (-1 : ℝ)) (n := j)
      simpa using h
    rw [hcoeff] at habs
    rw [abs_mul, abs_of_nonneg (pow_nonneg hx _), ← habs,
      show -x = (-1 : ℝ) * x by ring, mul_pow]
    ring
  rw [heq]
  unfold unsignedEndpointSquare
  rw [eval_comp, eval_neg, eval_X, endpointSquarePolynomial_eval _ (by linarith : -x ≤ 1)]
  rw [sub_neg_eq_add]

/-- The actual endpoint kernel has a uniform local coefficient norm at scale N^-2. -/
theorem endpointKernelPolynomial_local_mass {x : ℝ} (hx : 0 ≤ x) {N : ℕ}
    (hN : 0 < N) (d : ℕ) :
    coefficientMass ((endpointKernelPolynomial N d).comp (C x * X)) ≤
      Real.exp (2 * (d : ℝ) * (N : ℝ) * Real.sqrt x) := by
  have hN0 : 0 < (N : ℝ) := by exact_mod_cast hN
  have hn : ((N - 1 : ℕ) : ℝ) + 1 = (N : ℝ) := by exact_mod_cast Nat.sub_add_cancel hN
  have hu := chebyshev_U_sqrt_growth hx (N - 1)
  rw [hn] at hu
  have hu2 := (sq_le_sq₀ (abs_nonneg _) (by positivity :
    0 ≤ (N : ℝ) * Real.exp (((N - 1 : ℕ) : ℝ) * Real.sqrt x))).mpr hu
  rw [sq_abs] at hu2
  have hnorm : ((N : ℝ) ^ 2)⁻¹ *
      coefficientMass ((endpointSquarePolynomial (N - 1)).comp (C x * X)) ≤
        Real.exp (2 * (((N - 1 : ℕ) : ℝ) * Real.sqrt x)) := by
    rw [endpointSquarePolynomial_local_mass hx]
    apply (mul_le_mul_of_nonneg_left hu2 (inv_nonneg.mpr (sq_nonneg (N : ℝ)))).trans_eq
    rw [mul_pow]
    have heq : ((N : ℝ) ^ 2)⁻¹ * ((N : ℝ) ^ 2 *
        Real.exp (((N - 1 : ℕ) : ℝ) * Real.sqrt x) ^ 2) =
          Real.exp (((N - 1 : ℕ) : ℝ) * Real.sqrt x) ^ 2 := by field_simp
    rw [heq, ← Real.exp_nat_mul]
    norm_num
  unfold endpointKernelPolynomial
  rw [pow_comp, mul_comp, C_comp]
  have hbase : coefficientMass (C ((N : ℝ) ^ 2)⁻¹ *
      (endpointSquarePolynomial (N - 1)).comp (C x * X)) ≤
        Real.exp (2 * (((N - 1 : ℕ) : ℝ) * Real.sqrt x)) := by
    rw [coefficientMass_C_mul, abs_of_nonneg (inv_nonneg.mpr (sq_nonneg (N : ℝ)))]
    exact hnorm
  apply (coefficientMass_pow_le _ d).trans
  apply (pow_le_pow_left₀ (coefficientMass_nonneg _) hbase d).trans
  rw [← Real.exp_nat_mul]
  apply Real.exp_le_exp.mpr
  have hNm1 : ((N - 1 : ℕ) : ℝ) ≤ (N : ℝ) := by exact_mod_cast Nat.sub_le N 1
  have hscale := mul_le_mul_of_nonneg_left hNm1 (by positivity : 0 ≤ 2 * (d : ℝ) * Real.sqrt x)
  nlinarith

/-- A dimensionless endpoint-scale constraint yields a constant local norm. -/
theorem endpointKernelPolynomial_local_mass_uniform {x Z : ℝ} (hx : 0 ≤ x) {N : ℕ}
    (hN : 0 < N) (d : ℕ) (hZ : (N : ℝ) ^ 2 * x ≤ Z) :
    coefficientMass ((endpointKernelPolynomial N d).comp (C x * X)) ≤
      Real.exp (2 * (d : ℝ) * Real.sqrt Z) := by
  have hZ0 : 0 ≤ Z := (by positivity : 0 ≤ (N : ℝ) ^ 2 * x).trans hZ
  have hroot : (N : ℝ) * Real.sqrt x ≤ Real.sqrt Z := by
    have hxroot := Real.sq_sqrt hx
    have hZroot := Real.sq_sqrt hZ0
    have hnon : 0 ≤ (N : ℝ) * Real.sqrt x := by positivity
    nlinarith [Real.sqrt_nonneg Z]
  apply (endpointKernelPolynomial_local_mass hx hN d).trans
  apply Real.exp_le_exp.mpr
  have h := mul_le_mul_of_nonneg_left hroot (by positivity : 0 ≤ 2 * (d : ℝ))
  nlinarith

lemma weightedPrimitivePolynomial_coeff (P : ℝ[X]) (s : ℝ) (j : ℕ) :
    (weightedPrimitivePolynomial P s).coeff j = P.coeff j / (s + j) := by
  by_cases hj : j ∈ P.support
  · simp [weightedPrimitivePolynomial, coeff_monomial, hj]
  · simp [weightedPrimitivePolynomial, coeff_monomial, hj, notMem_support_iff.mp hj]

lemma weightedPrimitivePolynomial_comp_scale (P : ℝ[X]) (s x : ℝ) :
    (weightedPrimitivePolynomial P s).comp (C x * X) =
      weightedPrimitivePolynomial (P.comp (C x * X)) s := by
  ext j
  rw [comp_C_mul_X_coeff, weightedPrimitivePolynomial_coeff,
    weightedPrimitivePolynomial_coeff, comp_C_mul_X_coeff]
  ring

/-- Normalized integral profiles inherit the same local kernel coefficient bound. -/
theorem endpointProfilePolynomial_local_mass {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hx : 0 ≤ x) :
    coefficientMass ((endpointProfilePolynomial N d s).comp (C x * X)) ≤
      24 * (N : ℝ) ^ 2 * Real.exp (2 * (d : ℝ) * (N : ℝ) * Real.sqrt x) := by
  have hi := endpointIntegral_pos hN hd hs
  have hw := weightedPrimitivePolynomial_coefficientMass ((endpointKernelPolynomial N d).comp (C x * X)) hs
  have hk := endpointKernelPolynomial_local_mass hx hN d
  have hi' := endpointIntegral_inverse_weight_bound hN hd hs hs1
  unfold endpointProfilePolynomial
  rw [mul_comp, C_comp, weightedPrimitivePolynomial_comp_scale,
    coefficientMass_C_mul, abs_of_pos (inv_pos.mpr hi)]
  calc
    _ ≤ (endpointIntegral N d s)⁻¹ *
        (coefficientMass ((endpointKernelPolynomial N d).comp (C x * X)) / s) :=
      mul_le_mul_of_nonneg_left hw (inv_nonneg.mpr hi.le)
    _ = (s * endpointIntegral N d s)⁻¹ *
        coefficientMass ((endpointKernelPolynomial N d).comp (C x * X)) := by field_simp
    _ ≤ _ := mul_le_mul hi' hk (coefficientMass_nonneg _) (by positivity)

/-- The cumulative cutoff x J_1(x) cancels the profile's N² normalization. -/
theorem endpointCutoffPolynomial_local_mass {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {x : ℝ} (hx : 0 ≤ x) :
    coefficientMass ((X * endpointProfilePolynomial N d 1).comp (C x * X)) ≤
      24 * (N : ℝ) ^ 2 * x * Real.exp (2 * (d : ℝ) * (N : ℝ) * Real.sqrt x) := by
  rw [mul_comp, X_comp]
  have hm := coefficientMass_mul_le (C x * X)
    ((endpointProfilePolynomial N d 1).comp (C x * X))
  have hprofile := endpointProfilePolynomial_local_mass hN hd (by norm_num : (0 : ℝ) < 1)
    (by norm_num : (1 : ℝ) ≤ 1) hx
  have hmass : coefficientMass (C x * X) = x := by
    rw [coefficientMass_C_mul, coefficientMass_X, mul_one, abs_of_nonneg hx]
  rw [hmass] at hm
  exact hm.trans ((mul_le_mul_of_nonneg_left hprofile hx).trans_eq (by ring))

/-- The actual cutoff has a constant weighted coefficient norm under N²x ≤ Z. -/
theorem endpointCutoffPolynomial_local_mass_uniform {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {x Z : ℝ} (hx : 0 ≤ x) (hZ : (N : ℝ) ^ 2 * x ≤ Z) :
    coefficientMass ((X * endpointProfilePolynomial N d 1).comp (C x * X)) ≤
      24 * Z * Real.exp (2 * (d : ℝ) * Real.sqrt Z) := by
  have hZ0 : 0 ≤ Z := (by positivity : 0 ≤ (N : ℝ) ^ 2 * x).trans hZ
  have hroot : (N : ℝ) * Real.sqrt x ≤ Real.sqrt Z := by
    have hxroot := Real.sq_sqrt hx
    have hZroot := Real.sq_sqrt hZ0
    have hnon : 0 ≤ (N : ℝ) * Real.sqrt x := by positivity
    nlinarith [Real.sqrt_nonneg Z]
  have hexp : Real.exp (2 * (d : ℝ) * (N : ℝ) * Real.sqrt x) ≤
      Real.exp (2 * (d : ℝ) * Real.sqrt Z) := by
    apply Real.exp_le_exp.mpr
    nlinarith [mul_le_mul_of_nonneg_left hroot (by positivity : 0 ≤ 2 * (d : ℝ))]
  apply (endpointCutoffPolynomial_local_mass hN hd hx).trans
  have hfactor : 24 * (N : ℝ) ^ 2 * x ≤ 24 * Z := by nlinarith
  exact mul_le_mul hfactor hexp (Real.exp_pos _).le (by positivity)

end Renyi
