import Renyi.LowerCalibrationFinal

/-! Actual-root activation estimates for the selected moment defect. -/
noncomputable section
namespace Renyi

theorem lower_actual_principal_constraints_with_activation {k : ℕ} {α ε s ds dc : ℝ}
    (hk : 0 < k) (hα : 3/2 ≤ α) (hε : 0 < ε)
    (hs : 0 < s) (hs1 : s ≤ 1/2)
    (hγ₀ : 0 < fractionalPart α) (hγ₁ : fractionalPart α < 1)
    (hnearest : s = fractionalPart α ∨ s = 1-fractionalPart α)
    (hx : lowerPriorRootCutoff ε ≤ rootMultiplier k α ε)
    (hds : 0 < ds) (hdc : 0 < dc)
    (hdim : ds*dc ≤ α*((Nat.ceil (10*α*(1+Real.log (rootMultiplier k α ε))) : ℝ)+1)) :
    let x := rootMultiplier k α ε
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
    let bs := (ζ/8)/ds^2
    let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
    let a := θ/((1/100)*L*ac)
    let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
    0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 ∧ ρ ≤ 1 ∧ ρ ≤ (41/2)*v ∧ (0<ρ → 2*s≤(41/4)*v) := by
  let x := rootMultiplier k α ε
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
  let bs := (ζ/8)/ds^2
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*L*ac)
  let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
  let G := 4-Real.log ((1/100 : ℝ)/8)+Real.log ((ds*dc)^2/(L*α^3*(1+Real.log x)))
  change 0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 ∧ ρ ≤ 1 ∧ ρ ≤ (41/2)*v ∧ (0<ρ → 2*s≤(41/4)*v)
  have hα1 : 1 < α := by linarith
  have hα0 : 0 < α := by linarith
  have hβ : 1/2 ≤ α-1 := by linarith
  have hβ0 : 0 < α-1 := by linarith
  have hc := (lowerPriorCoefficient_bounds hε).1
  have hC : 0 < lowerVelocityConstant ε c := by
    unfold lowerVelocityConstant
    have hd : 0 < 1-Real.exp (-ε) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
    positivity
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hxe : 2/ε ≤ x := (le_trans (le_max_left _ _) (le_max_right _ _)).trans hx
  have hxC : 2*lowerVelocityConstant ε c ≤ x :=
    (le_trans (le_max_right _ _) (le_max_right _ _)).trans hx
  have hx1 : 1 < x := by linarith
  have hx0 : 0 < x := by linarith
  have hv := lower_velocity_from_root_size hα1 hε hs hs1 hC hx4 hxe hxC
  change 0 ≤ v ∧ 4*v ≤ E ∧ w ≤ 1/2 ∧ v ≤ 1/(2*lowerVelocityConstant ε c) at hv
  have hE : ε ≤ E := by dsimp [E]; nlinarith
  have hE0 : 0 < E := hε.trans_le hE
  have hd : 0 < 1-Real.exp (-ε) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  have hdE : 0 < 1-Real.exp (-E) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  have hden : 1-Real.exp (-ε) ≤ 1-Real.exp (-E) := by
    have h := Real.exp_le_exp.mpr (neg_le_neg hE)
    linarith
  have hw0 : 0 < w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv.1
  have hζ0 : 0 < ζ := div_pos (mul_pos hc hw0) hdE
  have hζ1 : ζ ≤ 1/8 := by
    have hdiv := div_le_div_of_nonneg_left (mul_pos hc hw0).le hd hden
    change ζ ≤ c*w/(1-Real.exp (-ε)) at hdiv
    have heq : c*w/(1-Real.exp (-ε)) = w/16 := by
      dsimp [c, lowerPriorCoefficient]
      field_simp
    rw [heq] at hdiv
    linarith [hv.2.2.1]
  have hslt : s < 1 := by linarith
  have hL : 0 < L := (show 0 < 10*α*(1+Real.log x) by
    have hlog := Real.log_pos hx1
    positivity).trans_le (Nat.le_ceil _)
  have hbs : 0 < bs := by dsimp [bs]; positivity
  have hξpos : 0 < 1-s := by linarith
  have hac : 0 < ac := by dsimp [ac, κ]; positivity
  have hθ : 0 < θ := by
    dsimp [θ, lowerPriorIntensityConstant]
    exact mul_pos (mul_pos (mul_pos (Real.exp_pos _) hα0)
      (Real.rpow_pos_of_pos (by exact_mod_cast hk) _)) hx0
  have ha : 0 < a := div_pos hθ (by positivity)
  have hG : G ≤ 1000 := lower_ceiling_log_geometry hα1.le hx1.le hds hdc hdim
  have hη : (ds-1)/ds ≤ 1 := (div_le_one hds).mpr (by linarith)
  have hcal := lower_scalar_positive_degree_with_activation hε hc hs hs1 hβ hE hv.1 hv.2.1
    hv.2.2.1 hη hG hv.2.2.2
  have hlog := root_principal_ratio_log hk hα1 hγ₀ hγ₁ hx1 hs hslt hnearest hζ0
    (Real.exp_pos (lowerLogSampleConstant ε c)) (by norm_num : (0 : ℝ) < 1/100) hL hds hdc
  change Real.log (a/bs) = lowerPrincipalLog s E v ζ (α-1)
    (Real.log (Real.exp (lowerLogSampleConstant ε c))) G at hlog
  rw [Real.log_exp] at hlog
  have hA : Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G) = a/bs := by
    rw [← hlog, Real.exp_log (div_pos ha hbs)]
  dsimp only at hcal
  change (Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G) ≤ 1/2) ∧
    0 ≤ max (((Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G))^s/κ)*
      Real.exp (4*ζ*((ds-1)/ds))-1) 0 ∧
    max (((Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G))^s/κ)*
      Real.exp (4*ζ*((ds-1)/ds))-1) 0 ≤ 2*lowerVelocityConstant ε c*v ∧
    max (((Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G))^s/κ)*
      Real.exp (4*ζ*((ds-1)/ds))-1) 0 *
      Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G) ≤ ζ ∧
    (0 < max (((Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G))^s/κ)*
      Real.exp (4*ζ*((ds-1)/ds))-1) 0 → 2*s≤lowerVelocityConstant ε c*v) at hcal
  rw [hA] at hcal
  have hCeq : lowerVelocityConstant ε c=41/4 := by
    dsimp [lowerVelocityConstant,c,lowerPriorCoefficient]
    field_simp
    ring
  refine ⟨ha, ?_, hcal.2.1, ?_, hζ0, hζ1, ?_, ?_, ?_⟩
  · have h := (div_le_iff₀ hbs).mp hcal.1
    nlinarith
  · convert hcal.2.2.2.1 using 1
    ring

  · have hvC := (le_div_iff₀ (show 0 < 2*lowerVelocityConstant ε c by positivity)).mp hv.2.2.2
    have hh := hcal.2.2.1
    nlinarith only [hvC, hh]


  · rw [hCeq] at hcal
    convert hcal.2.2.1 using 1
    ring
  · rw [hCeq] at hcal
    exact hcal.2.2.2.2

end Renyi
