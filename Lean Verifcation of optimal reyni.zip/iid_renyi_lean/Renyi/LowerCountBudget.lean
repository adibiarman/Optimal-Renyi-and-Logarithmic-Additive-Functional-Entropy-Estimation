import Renyi.LowerRemainderBudget

/-! Actual-root one-defect count-distance budget for finite priors. -/
noncomputable section
namespace Renyi

/-- The actual root implies the scalar lower envelope on zeta used by the
Taylor remainder. -/
theorem lower_actual_zeta_power_floor {α ε s x : ℝ}
    (hα : 3/2≤α) (hε : 0<ε) (hs : 0≤s) (hs1 : s≤1) (hx : 0<x) :
    let c := lowerPriorCoefficient ε
    let v := (α-1)/α*x^(-α)
    (c/3)*x^(-α)≤c*(s*(1-s)+v)/(1-Real.exp (-(2*ε*(α-1)))) := by
  have hα0 : 0<α := by linarith
  have hβ : 0<α-1 := by linarith
  have hc := (lowerPriorCoefficient_bounds hε).1
  have hratio : (1:ℝ)/3≤(α-1)/α := (le_div_iff₀ hα0).mpr (by linarith)
  have hh := mul_le_mul_of_nonneg_right hratio (Real.rpow_nonneg hx.le (-α))
  have hh' := mul_le_mul_of_nonneg_left hh hc.le
  apply le_trans _ (lower_zeta_velocity_floor hc (by positivity) hs hs1 (by positivity))
  convert hh' using 1
  ring

/-- Finite normalized priors with the constructed selected-moment scale and
power-mean envelopes have close actual Poisson count laws at the root rate. -/
theorem lower_actual_small_count_budget {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    (p₀ : FiniteAtomicPrior ι₀) (p₁ : FiniteAtomicPrior ι₁)
    {k r L : ℕ} {α ε s θ B ζ ρ D : ℝ}
    (hk : 0<k) (hr : 2≤r) (hα : 3/2≤α) (hε : 0<ε) (hε1 : ε≤1/2)
    (hs : 0<s) (hs1 : s≤1/2)
    (hg : 0<fractionalPart α) (hg1 : fractionalPart α<1)
    (hnearest : s=fractionalPart α ∨ s=1-fractionalPart α)
    (hdegree : α-(r:ℝ)=s ∨ α-(r:ℝ)= -s)
    (hx : 1<rootMultiplier k α ε)
    (hL : 10*α*(1+Real.log (rootMultiplier k α ε))≤L)
    (hθdef : θ=lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*rootMultiplier k α ε)
    (hBdef : B=(1/100)*(L:ℝ)/θ)
    (hζdef : ζ=lowerPriorCoefficient ε*(s*(1-s)+(α-1)/α*rootMultiplier k α ε^(-α))/
      (1-Real.exp (-(2*ε*(α-1)))))
    (hρ : 0≤ρ) (hD : 0<D)
    (hρv : ρ≤(41/2)*((α-1)/α*rootMultiplier k α ε^(-α)))
    (hactivation : 0<ρ → 2*s≤(41/4)*((α-1)/α*rootMultiplier k α ε^(-α)))
    (hDbound : D≤Real.exp ((20+2/lowerPriorCoefficient ε)*r)/ζ)
    (hmean₀ : priorMoment p₀ α≤(lowerPriorIntensityConstant ε)^(-1/2:ℝ)*
      Real.exp ((20+2/lowerPriorCoefficient ε)*r)/ζ)
    (hmean₁ : priorMoment p₁ α≤(lowerPriorIntensityConstant ε)^(-1/2:ℝ)*
      Real.exp ((20+2/lowerPriorCoefficient ε)*r)/ζ)
    (hv₀ : ∀ i,0≤p₀.value i) (hv₁ : ∀ i,0≤p₁.value i)
    (hb₀ : ∀ i,p₀.value i≤B) (hb₁ : ∀ i,p₁.value i≤B)
    (hmatch : ∀ j : ℕ,1≤j → j≤L+1 → j≠r → priorMoment p₁ (j:ℝ)=priorMoment p₀ (j:ℝ))
    (hdefect : |priorMoment p₁ (r:ℝ)-priorMoment p₀ (r:ℝ)|≤ρ*D)
    (hden₀ : ∀ j : ℕ,1≤j → j≤r → Real.exp (-1)*θ^r*D/(j.factorial:ℝ)≤poissonMixture p₀.mass p₀.value θ j)
    (hden₁ : ∀ j : ℕ,1≤j → j≤r → Real.exp (-1)*θ^r*D/(j.factorial:ℝ)≤poissonMixture p₁.mass p₁.value θ j) :
    (k:ℝ)*countDistance (poissonMixture p₀.mass p₀.value θ) (poissonMixture p₁.mass p₁.value θ)≤1/32 := by
  have hα0 : 0<α := by linarith
  have hx0 : 0<rootMultiplier k α ε := by linarith
  have hlog : 0≤Real.log (rootMultiplier k α ε) := Real.log_nonneg hx.le
  have hLα : 10*α≤L := by nlinarith [mul_nonneg hα0.le hlog]
  have hL0 : (0:ℝ)<L := by linarith
  have hθ : 0<θ := by rw [hθdef]; unfold lowerPriorIntensityConstant; positivity
  have hB : 0<B := by rw [hBdef]; positivity
  have hαM : α≤(L+2:ℕ) := by push_cast; linarith
  have hαr : (r:ℝ)≤α+1/2 := by rcases hdegree with h | h <;> linarith
  have hrM : r<L+2 := by
    have hh : (r:ℝ)<(L:ℝ)+2 := by linarith
    exact_mod_cast hh
  have hmatch' : ∀ j : ℕ,j<L+2 → j≠r → atomicMoment p₁.mass p₁.value j=atomicMoment p₀.mass p₀.value j := by
    intro j hj hjr
    by_cases hj0 : j=0
    · subst j
      simp [atomicMoment,p₀.mass_sum,p₁.mass_sum]
    · simpa only [priorMoment,atomicMoment,Real.rpow_natCast] using hmatch j (by omega) (by omega) hjr
  have hdefect' : |atomicMoment p₁.mass p₁.value r-atomicMoment p₀.mass p₀.value r|≤ρ*D := by
    simpa only [priorMoment,atomicMoment,Real.rpow_natCast] using hdefect
  have hdist := one_defect_calibration_finite p₀.mass p₀.value p₁.mass p₁.value
    θ ρ D (Real.exp (-1)) α B (L+2) r p₀.mass_nonneg hv₀ p₁.mass_nonneg hv₁ hb₀ hb₁
    hθ hρ hD (Real.exp_pos _) hα0.le hαM hB hrM hmatch' hdefect' hden₀ hden₁
  have hdef := lower_actual_defect_budget hk hr hα hε hε1 hs hs1 hg hg1 hnearest hdegree hx hρ hD.le
    hρv hactivation (by simpa only [←hζdef] using hDbound)
  rw [←hθdef] at hdef
  have hζfloor := lower_actual_zeta_power_floor hα hε hs.le (by linarith) hx0
  dsimp only at hζfloor
  rw [←hζdef] at hζfloor
  have hA₀ : 0≤priorMoment p₀ α :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (p₀.mass_nonneg i) (Real.rpow_nonneg (hv₀ i) _))
  have hA₁ : 0≤priorMoment p₁ α :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (p₁.mass_nonneg i) (Real.rpow_nonneg (hv₁ i) _))
  have hrem := lower_remainder_term_budget (k:=(k:ℝ)) (cn:=lowerPriorIntensityConstant ε) (by exact_mod_cast hk) hα hx.le
    (Real.exp_pos _) (lowerPriorCoefficient_bounds hε).1 hαr hL (lower_actual_log_sample_bound hε)
    hζfloor hA₀ hA₁ hmean₀ hmean₁
  dsimp only at hrem
  rw [←hθdef,←hBdef] at hrem
  change (k:ℝ)*2*(priorMoment p₁ α+priorMoment p₀ α)*B^(-α)*
    (2*Real.exp 1*θ*B/(L+2:ℕ))^(L+2)≤1/256 at hrem
  have hh := mul_le_mul_of_nonneg_left hdist (show (0:ℝ)≤k by positivity)
  change (k:ℝ)*countDistance (poissonMixture p₀.mass p₀.value θ) (poissonMixture p₁.mass p₁.value θ)≤_
  change (k:ℝ)*countDistance _ _≤(k:ℝ)*(_+2*(priorMoment p₁ α+priorMoment p₀ α)*B^(-α)*
    (2*Real.exp 1*θ*B/(L+2:ℕ))^(L+2)) at hh
  nlinarith only [hh,hdef,hrem]

end Renyi
