import Renyi.LowerCountCalibration
import Renyi.LowerActualMassFloor
import Renyi.LowerNormalizationCalibration
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

/-! Uniform positive-degree normalization estimates derived from the actual root. -/
noncomputable section
open scoped BigOperators NNReal
namespace Renyi
set_option maxHeartbeats 1000000

/-- The actual root controls the normalization margin even arbitrarily close
to an integer order. -/
theorem lower_root_normalization_margin {k : ℕ} {alpha eps s : ℝ}
    (hk : 0<k) (ha : 3/2≤alpha) (he : 0<eps) (hs : 0<s) (hs1 : s≤1/2)
    (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (hnearest : s=fractionalPart alpha ∨ s=1-fractionalPart alpha)
    (hx : 1<rootMultiplier k alpha eps)
    (hvE : (alpha-1)/alpha*(rootMultiplier k alpha eps)^(-alpha)≤eps*(alpha-1)) :
    let x := rootMultiplier k alpha eps
    let v := (alpha-1)/alpha*x^(-alpha)
    let w := s*(1-s)+v
    (alpha-1)/w≤Real.log k/(eps*alpha) := by
  let x := rootMultiplier k alpha eps
  let v := (alpha-1)/alpha*x^(-alpha)
  let h := s*(1-s)
  let w := h+v
  have ha1 : 1<alpha := by linarith
  have ha0 : 0<alpha := by linarith
  have hb0 : 0<alpha-1 := by linarith
  have hslt : s<1 := by linarith
  have hxi : 0<1-s := by linarith
  have hh0 : 0<h := mul_pos hs hxi
  have hv : 0≤v := by dsimp [v]; positivity
  have hw0 : 0<w := add_pos_of_pos_of_nonneg hh0 hv
  have hprod : (3/4:ℝ)≤alpha*(alpha-1) := by nlinarith
  have hp0 : 0<alpha*(alpha-1) := mul_pos ha0 hb0
  have hinv : (alpha*(alpha-1))⁻¹≤4/3 := by
    apply (inv_le_iff_one_le_mul₀ hp0).mpr
    nlinarith
  have hlogs : -1/3≤Real.log alpha+Real.log (alpha-1) := by
    have hh := Real.one_sub_inv_le_log_of_pos hp0
    rw [Real.log_mul ha0.ne' hb0.ne'] at hh
    linarith
  have hlogx : 0≤Real.log x := Real.log_nonneg hx.le
  have hlogh : 0≤Real.log (1+Real.log x) := Real.log_nonneg (by linarith)
  have hlogs0 : Real.log s≤0 := Real.log_nonpos hs.le (by linarith)
  have hlogxi : Real.log (1-s)≤0 := Real.log_nonpos hxi.le (by linarith)
  have ht0 : 0≤-(1+1/(1-s))*Real.log s := mul_nonneg_of_nonpos_of_nonpos (neg_nonpos.mpr (by positivity : (0:ℝ)≤1+1/(1-s))) hlogs0
  have ht1 : 0≤-(1+1/s)*Real.log (1-s) := mul_nonneg_of_nonpos_of_nonpos (neg_nonpos.mpr (by positivity : (0:ℝ)≤1+1/s)) hlogxi
  have hroot := lower_root_log_alphabet hk ha1 hs hslt hg hg1 hnearest hx
  change Real.log k/alpha=2*Real.log alpha+2*Real.log (alpha-1)+Real.log (1+Real.log x)+1+Real.log x-
    (1+1/(1-s))*Real.log s-(1+1/s)*Real.log (1-s)+(2*eps*(alpha-1)-v)/h at hroot
  have hK : (2*eps*(alpha-1)-v)/h≤Real.log k/alpha := by linarith
  have hvelocity : eps*(alpha-1)≤2*eps*(alpha-1)-v := by linarith
  have hKH : eps*(alpha-1)/h≤Real.log k/alpha :=
    (div_le_div_of_nonneg_right hvelocity hh0.le).trans hK
  have hWH : eps*(alpha-1)/w≤eps*(alpha-1)/h :=
    div_le_div_of_nonneg_left (mul_pos he hb0).le hh0 (by dsimp [w]; linarith)
  have hh := hWH.trans hKH
  have hmul := (div_le_div_iff₀ hw0 ha0).mp hh
  apply (div_le_div_iff₀ hw0 (mul_pos he ha0)).mpr
  nlinarith only [hmul]

/-- A fixed explicit root cutoff absorbs every logarithmic support factor. -/
theorem lower_log_support_cutoff {C x : ℝ} (hC : 0<C)
    (hx1 : 1≤x) (hx : (4*C)^4≤x) :
    C*(1+Real.log x)≤x^(1/2:ℝ) := by
  have hx0 : 0<x := zero_lt_one.trans_le hx1
  have hxq : 0<x^(1/4:ℝ) := Real.rpow_pos_of_pos hx0 _
  have hlog := Real.log_le_sub_one_of_pos hxq
  rw [Real.log_rpow hx0] at hlog
  have hroot : 4*C≤x^(1/4:ℝ) := by
    have hp := Real.rpow_le_rpow (by positivity : (0:ℝ)≤(4*C)^4) hx (by norm_num : (0:ℝ)≤1/4)
    have hid : ((4*C)^4)^(1/4:ℝ)=4*C := by
      rw [←Real.rpow_natCast_mul (by positivity : (0:ℝ)≤4*C)]
      norm_num
    rwa [hid] at hp
  have hh := mul_le_mul_of_nonneg_right hroot hxq.le
  have hqeq : (x^(1/4:ℝ))^2=x^(1/2:ℝ) := by
    rw [←Real.rpow_two,←Real.rpow_mul hx0.le]
    norm_num
  have hclog := mul_le_mul_of_nonneg_left hlog hC.le
  nlinarith only [hclog,hh,hqeq,hC]

/-- Refined prior moments and the root-controlled margin give a uniform
positive-degree normalization envelope. -/
theorem prior_normalization_positive_margin {ι : Type*} [Fintype ι]
    (b : ℝ≥0) (hb : 0<(b:ℝ)) (P : FiniteAtomicPrior ι)
    {alpha B m R zeta C Cz : ℝ}
    (ha : 3/2≤alpha) (hB : 1≤B) (hm : 0<m) (hR : 1≤R)
    (hz : 0≤zeta) (hC : 0≤C) (hCz : 0≤Cz)
    (hmargin : (alpha-1)/m≤R) (hzeta : zeta≤Cz*m)
    (hsupp : ∀ i, P.value i=0 ∨ (1≤P.value i ∧ P.value i≤B))
    (hmean : priorMoment P 1=1)
    (hsecond : priorMoment P (2*alpha)/(priorMoment P alpha)^2≤C*zeta^2*B^alpha) :
    priorNormalizationMomentBudget b P alpha m≤
      (1280*R^2*B+256*C*Cz^2*B^alpha)/(b:ℝ) := by
  let A := priorMoment P alpha
  let t := min (1/4:ℝ) (m/(16*(alpha-1)))
  let d := min 1 ((alpha-1)*Real.log B)
  have ha1 : 1<alpha := by linarith
  have hbeta : 0<alpha-1 := by linarith
  have hR0 : 0<R := zero_lt_one.trans_le hR
  have hAB := finite_prior_power_bounds P alpha B ha1 hB hsupp hmean
  have hA0 : 0<A := by dsimp [A]; linarith
  have hmargin' : alpha-1≤R*m := (div_le_iff₀ hm).mp hmargin
  have ht : 1/(16*R)≤t := by
    apply le_min
    · apply (div_le_iff₀ (by positivity : (0:ℝ)<16*R)).mpr
      nlinarith
    · apply (div_le_div_iff₀ (by positivity : (0:ℝ)<16*R) (by positivity : (0:ℝ)<16*(alpha-1))).mpr
      nlinarith
  have ht0 : 0<t := (by positivity : (0:ℝ)<1/(16*R)).trans_le ht
  have hsupp' : ∀ i, 0≤P.value i ∧ P.value i≤B := by
    intro i
    rcases hsupp i with h | h
    · rw [h]; constructor <;> linarith
    · exact ⟨(zero_le_one.trans h.1),h.2⟩
  have hsecondBound := finite_prior_second_moment_le P B hsupp' hmean
  have hsecond0 : 0≤priorMoment P 2 :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (P.mass_nonneg i) (Real.rpow_nonneg (hsupp' i).1 _))
  have hfirst : priorMoment P 2/((b:ℝ)*t^2)≤256*R^2*B/b := by
    have hden : (b:ℝ)*(1/(16*R))^2≤(b:ℝ)*t^2 := by
      exact mul_le_mul_of_nonneg_left ((sq_le_sq₀ (by positivity) ht0.le).mpr ht) hb.le
    have hh := (div_le_div_of_nonneg_left hsecond0 (by positivity : (0:ℝ)<(b:ℝ)*(1/(16*R))^2) hden).trans
      (div_le_div_of_nonneg_right hsecondBound (by positivity : (0:ℝ)≤(b:ℝ)*(1/(16*R))^2))
    convert hh using 1; field_simp; ring
  have hd0 : 0≤d := le_min zero_le_one (mul_nonneg hbeta.le (Real.log_nonneg hB))
  have hd1 : d≤1 := min_le_left _ _
  have hd2 : d^2≤1 := by nlinarith
  have hres := finite_prior_residual_noise_bound P alpha B ha1 hB hsupp hmean
  have hres' : priorResidualSecondMoment P alpha/A^2≤C*zeta^2*B^alpha+B := by
    have hh := hres.trans (mul_le_mul_of_nonneg_left (add_le_add_right hsecond B) (sq_nonneg d))
    have hnonneg : 0≤C*zeta^2*B^alpha+B := by positivity
    have hh' := mul_le_mul_of_nonneg_right hd2 hnonneg
    nlinarith only [hh,hh']
  have hzinv : 0≤zeta/m ∧ zeta/m≤Cz := ⟨div_nonneg hz hm.le,(div_le_iff₀ hm).mpr hzeta⟩
  have hinv : 1/m≤2*R := by
    apply (div_le_iff₀ hm).mpr
    nlinarith
  have hzinv2 : (zeta/m)^2≤Cz^2 := (sq_le_sq₀ hzinv.1 hCz).mpr hzinv.2
  have hinv2 : (1/m)^2≤4*R^2 := by
    have hh := (sq_le_sq₀ (by positivity : (0:ℝ)≤1/m) (by positivity : (0:ℝ)≤2*R)).mpr hinv
    nlinarith only [hh]
  have hnoise : priorResidualSecondMoment P alpha/(A^2*m^2)≤C*Cz^2*B^alpha+4*R^2*B := by
    have hh := div_le_div_of_nonneg_right hres' (sq_nonneg m)
    have hζ := mul_le_mul_of_nonneg_left hzinv2 (show 0≤C*B^alpha by positivity)
    have hsmall := mul_le_mul_of_nonneg_right hinv2 (show 0≤B by linarith)
    calc
      _ ≤ (C*zeta^2*B^alpha+B)/m^2 := by convert hh using 1; field_simp
      _ = (C*B^alpha)*(zeta/m)^2+(1/m)^2*B := by field_simp
      _ ≤ _ := by nlinarith only [hζ,hsmall]
  have hfull := add_le_add hfirst (mul_le_mul_of_nonneg_left hnoise (show 0≤256/(b:ℝ) by positivity))
  convert hfull using 1
  · unfold priorNormalizationMomentBudget
    dsimp only [A,t] at *
    congr 1
    field_simp
    norm_num
  · ring

/-- Exact normalized support power at the manuscript's common intensity. -/
theorem lower_support_power_identity {k alpha x cn cm L : ℝ}
    (hk : 0<k) (ha : 0<alpha) (hx : 0<x) (hcn : 0<cn) (hcm : 0<cm) (hL : 0<L) :
    let theta := cn*alpha*k^(-1/alpha)*x
    let B := cm*L/theta
    B^alpha/k=(cm*L/(cn*alpha*x))^alpha := by
  let theta := cn*alpha*k^(-1/alpha)*x
  have htheta : 0<theta := by dsimp [theta]; positivity
  have hkp : (k^(-1/alpha))^alpha=k⁻¹ := by
    rw [←Real.rpow_mul hk.le]
    have he : (-1/alpha)*alpha=(-1:ℝ) := by field_simp
    rw [he,Real.rpow_neg_one]
  have hthetaPower : theta^alpha=(cn*alpha)^alpha*k⁻¹*x^alpha := by
    dsimp [theta]
    rw [Real.mul_rpow (by positivity) hx.le,
      Real.mul_rpow (mul_pos hcn ha).le (Real.rpow_nonneg hk.le _),hkp]
  dsimp only
  change (cm*L/theta)^alpha/k=_
  rw [Real.div_rpow (mul_pos hcm hL).le htheta.le,hthetaPower,
    Real.div_rpow (mul_pos hcm hL).le (by positivity : (0:ℝ)≤cn*alpha*x),
    Real.mul_rpow (mul_pos hcn ha).le hx.le]
  field_simp

/-- Uniformly in the order, a large root makes the normalized support power
smaller than a negative half power of that root. -/
theorem lower_support_power_decay {alpha x cn cm : ℝ}
    (ha : 1≤alpha) (hx : 1≤x) (hcn : 0<cn) (hcm : 0<cm)
    (hcut : (4*(11*cm/cn))^4≤x) :
    let L : ℝ := Nat.ceil (10*alpha*(1+Real.log x))
    (cm*L/(cn*alpha*x))^alpha≤x^(-alpha/2) := by
  let L : ℝ := Nat.ceil (10*alpha*(1+Real.log x))
  have ha0 : 0<alpha := zero_lt_one.trans_le ha
  have hx0 : 0<x := zero_lt_one.trans_le hx
  have hH : 1≤1+Real.log x := by linarith [Real.log_nonneg hx]
  have hLhi : L≤11*alpha*(1+Real.log x) := by
    have hh := (Nat.ceil_lt_add_one (show 0≤10*alpha*(1+Real.log x) by positivity)).le
    change L≤10*alpha*(1+Real.log x)+1 at hh
    nlinarith [mul_le_mul ha hH (by norm_num : (0:ℝ)≤1) ha0.le]
  have hroot := lower_log_support_cutoff (show 0<11*cm/cn by positivity) hx hcut
  have hratio : cm*L/(cn*alpha)≤x^(1/2:ℝ) := by
    apply (div_le_iff₀ (mul_pos hcn ha0)).mpr
    have hh := mul_le_mul_of_nonneg_left hLhi hcm.le
    have hh' := mul_le_mul_of_nonneg_right hroot (mul_pos hcn ha0).le
    have hid : (11*cm/cn)*(1+Real.log x)*(cn*alpha)=cm*(11*alpha*(1+Real.log x))  := by field_simp
    rw [hid] at hh'
    exact hh.trans hh'
  have hbase : cm*L/(cn*alpha*x)≤x^(-1/2:ℝ) := by
    have hh := div_le_div_of_nonneg_right hratio hx0.le
    have hid : cm*L/(cn*alpha*x)=(cm*L/(cn*alpha))/x := by ring
    rw [hid]
    apply hh.trans_eq
    rw [div_eq_mul_inv,←Real.rpow_neg_one x,←Real.rpow_add hx0]
    norm_num
  have hh := Real.rpow_le_rpow (by positivity : (0:ℝ)≤cm*L/(cn*alpha*x)) hbase ha0.le
  rw [←Real.rpow_mul hx0.le] at hh
  have heq : (-1/2:ℝ)*alpha=-alpha/2 := by ring
  rw [heq] at hh
  exact hh

/-- A normalized support power below one forces an alphabet decay rate
uniform for all orders at least three halves. -/
theorem lower_support_alphabet_decay {B k alpha : ℝ}
    (hB : 0<B) (hk : 1≤k) (ha : 3/2≤alpha) (hpower : B^alpha/k≤1) :
    B/k≤k^(-1/3:ℝ) := by
  have hk0 : 0<k := zero_lt_one.trans_le hk
  have ha0 : 0<alpha := by linarith
  have hpow : B^alpha≤k := by exact (div_le_one hk0).mp hpower
  have hh := Real.rpow_le_rpow (Real.rpow_nonneg hB.le _) hpow (one_div_pos.mpr ha0).le
  rw [←Real.rpow_mul hB.le,mul_one_div_cancel ha0.ne',Real.rpow_one] at hh
  have he : 1/alpha≤2/3 := (div_le_iff₀ ha0).mpr (by linarith)
  have hBbound : B≤k^(2/3:ℝ) := hh.trans (Real.rpow_le_rpow_of_exponent_le hk he)
  have heq : k^(-1/3:ℝ)*k=k^(2/3:ℝ) := by
    calc
      _=k^(-1/3:ℝ)*k^(1:ℝ) := by rw [Real.rpow_one]
      _=k^((-1/3:ℝ)+1) := (Real.rpow_add hk0 _ _).symm
      _=_ := by norm_num
  apply (div_le_iff₀ hk0).mpr
  rw [heq]
  exact hBbound

/-- One alphabet cutoff and one root cutoff control the full positive-degree
normalization envelope uniformly over all orders. -/
theorem lower_positive_normalization_cutoffs {eps C Cz : ℝ}
    (he : 0<eps) (hC : 0≤C) (_hCz : 0≤Cz) :
    ∃ k₀ : ℕ, ∃ X₀ : ℝ, 1≤X₀ ∧ ∀ k : ℕ, k₀≤k → ∀ x alpha : ℝ,
      X₀≤x → 3/2≤alpha →
      2560*(1+Real.log k/eps)^2*(k:ℝ)^(-1/3:ℝ)+
        512*C*Cz^2*x^(-alpha/2)≤1/64 := by
  have hcast : Filter.Tendsto (fun k:ℕ => (k:ℝ)) Filter.atTop Filter.atTop := tendsto_natCast_atTop_atTop
  have hlog : Filter.Tendsto (fun k:ℕ => Real.log k) Filter.atTop Filter.atTop := Real.tendsto_log_atTop.comp hcast
  have hp := (tendsto_rpow_mul_exp_neg_mul_atTop_nhds_zero (2:ℝ) (1/3:ℝ) (by norm_num)).comp hlog
  norm_num only [Real.rpow_two] at hp
  have hpoly : Filter.Tendsto (fun k:ℕ => (2560*(1+1/eps)^2)*(Real.log k)^2*Real.exp (-(1/3:ℝ)*Real.log k))
      Filter.atTop (nhds 0) := by
    convert hp.const_mul (2560*(1+1/eps)^2) using 1
    · funext k
      simp only [Function.comp_def]
      ring
    · simp
  have hevent : ∀ᶠ k:ℕ in Filter.atTop,
      1≤Real.log k ∧ (2560*(1+1/eps)^2)*(Real.log k)^2*Real.exp (-(1/3:ℝ)*Real.log k)≤1/128 := by
    filter_upwards [hlog.eventually_ge_atTop 1,hpoly.eventually_le_const (by norm_num : (0:ℝ)<1/128)] with k hk hsmall
    exact ⟨hk,hsmall⟩
  obtain ⟨K,hK⟩ := Filter.eventually_atTop.mp hevent
  have hxlim : Filter.Tendsto (fun x:ℝ => (512*C*Cz^2)*x^(-3/4:ℝ)) Filter.atTop (nhds 0) := by
    simpa only [mul_zero,neg_div] using (tendsto_rpow_neg_atTop (by norm_num : (0:ℝ)<3/4)).const_mul (512*C*Cz^2)
  obtain ⟨X,hX⟩ := Filter.eventually_atTop.mp (hxlim.eventually_le_const (by norm_num : (0:ℝ)<1/128))
  refine ⟨max 2 K,max 1 X,le_max_left _ _,?_⟩
  intro k hk x alpha hx ha
  have hk2 : 2≤k := (le_max_left _ _).trans hk
  have hk0 : (0:ℝ)<k := by exact_mod_cast (show 0<k by omega)
  obtain ⟨hlogK,hsmall⟩ := hK k ((le_max_right _ _).trans hk)
  have hR0 : 0≤1+Real.log k/eps := by positivity
  have hR : 1+Real.log k/eps≤(1+1/eps)*Real.log k := by
    have hid : (1+1/eps)*Real.log k-(1+Real.log k/eps)=Real.log k-1 := by ring
    linarith only [hid,hlogK]
  have hRsq := (sq_le_sq₀ hR0 (by positivity : (0:ℝ)≤(1+1/eps)*Real.log k)).mpr hR
  have hfirst : 2560*(1+Real.log k/eps)^2*(k:ℝ)^(-1/3:ℝ)≤1/128 := by
    have hh := mul_le_mul_of_nonneg_left hRsq (show 0≤2560*Real.exp (-(1/3:ℝ)*Real.log k) by positivity)
    have heq : (k:ℝ)^(-1/3:ℝ)=Real.exp (-(1/3:ℝ)*Real.log k) := by rw [Real.rpow_def_of_pos hk0]; congr 1; ring
    rw [heq]
    nlinarith only [hh,hsmall]
  have hx1 : 1≤x := (le_max_left _ _).trans hx
  have hp : x^(-alpha/2)≤x^(-3/4:ℝ) := Real.rpow_le_rpow_of_exponent_le hx1 (by linarith)
  have hh := mul_le_mul_of_nonneg_left hp (show 0≤512*C*Cz^2 by positivity)
  have hsecond := hX x ((le_max_right _ _).trans hx)
  linarith

/-- The root cutoff already makes its regularizing velocity smaller than
half the entropy exponent gap. -/
theorem lower_positive_velocity_margin {alpha eps x : ℝ}
    (ha : 3/2≤alpha) (he : 0<eps) (hx1 : 1≤x) (hx : 2/eps≤x) :
    (alpha-1)/alpha*x^(-alpha)≤eps*(alpha-1) := by
  have ha0 : 0<alpha := by linarith
  have hx0 : 0<x := zero_lt_one.trans_le hx1
  have hc : 0≤(alpha-1)/alpha ∧ (alpha-1)/alpha≤1 := by
    constructor
    · exact div_nonneg (by linarith) ha0.le
    · exact (div_le_one ha0).mpr (by linarith)
  have hp : x^(-alpha)≤1/x := by
    rw [one_div,←Real.rpow_neg_one x]
    exact Real.rpow_le_rpow_of_exponent_le hx1 (by linarith)
  have hi : 1/x≤eps/2 := by
    apply (div_le_iff₀ hx0).mpr
    have hh := (div_le_iff₀ he).mp hx
    nlinarith
  have hh := mul_le_mul hc.2 hp (Real.rpow_nonneg hx0.le _) (by norm_num : (0:ℝ)≤1)
  nlinarith

/-- At positive degree the target parameter is at most one sixteenth of
the normalization margin, uniformly over all orders. -/
theorem lower_target_margin_upper {eps E w : ℝ}
    (he : 0<eps) (hE : eps≤E) (hw : 0≤w) :
    lowerPriorCoefficient eps*w/(1-Real.exp (-E))≤w/16 := by
  have hd : 0<1-Real.exp (-eps) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  have hden : 1-Real.exp (-eps)≤1-Real.exp (-E) := by
    have hh := Real.exp_le_exp.mpr (neg_le_neg hE)
    linarith
  have hc : 0≤lowerPriorCoefficient eps := (lowerPriorCoefficient_bounds he).1.le
  have hh := div_le_div_of_nonneg_left (mul_nonneg hc hw) hd hden
  have hid : lowerPriorCoefficient eps*w/(1-Real.exp (-eps))=w/16 := by
    unfold lowerPriorCoefficient
    field_simp
  rw [hid] at hh
  exact hh

/-- At the actual support power scale, the refined normalization budget is
bounded by the two scalar errors used in the uniform cutoff. -/
theorem prior_normalization_positive_envelope {ι : Type*} [Fintype ι]
    (b : ℝ≥0) (P : FiniteAtomicPrior ι) {k : ℕ} {alpha eps x B m zeta C Cz : ℝ}
    (hk : 1≤k) (hb : (b:ℝ)=(k:ℝ)/2) (ha : 3/2≤alpha) (he : 0<eps)
    (hx : 1≤x) (hB : 1≤B) (hm : 0<m) (hz : 0≤zeta) (hC : 0≤C) (hCz : 0≤Cz)
    (hmargin : (alpha-1)/m≤Real.log k/(eps*alpha)) (hzeta : zeta≤Cz*m)
    (hpower : B^alpha/(k:ℝ)≤x^(-alpha/2))
    (hsupp : ∀ i, P.value i=0 ∨ (1≤P.value i ∧ P.value i≤B))
    (hmean : priorMoment P 1=1)
    (hsecond : priorMoment P (2*alpha)/(priorMoment P alpha)^2≤C*zeta^2*B^alpha) :
    priorNormalizationMomentBudget b P alpha m≤
      2560*(1+Real.log k/eps)^2*(k:ℝ)^(-1/3:ℝ)+512*C*Cz^2*x^(-alpha/2) := by
  let R := 1+Real.log k/eps
  have hkR : (1:ℝ)≤k := by exact_mod_cast hk
  have hk0 : (0:ℝ)<k := zero_lt_one.trans_le hkR
  have hb0 : 0<(b:ℝ) := by rw [hb]; positivity
  have hlog : 0≤Real.log k := Real.log_nonneg hkR
  have ha0 : 0<alpha := by linarith
  have hR : 1≤R := by
    have hh : 0≤Real.log k/eps := div_nonneg hlog he.le
    dsimp [R]
    linarith
  have hmarginR : (alpha-1)/m≤R := by
    have hden : eps≤eps*alpha := by nlinarith
    have hh := div_le_div_of_nonneg_left hlog he hden
    exact hmargin.trans (hh.trans (by dsimp [R]; linarith))
  have hh := prior_normalization_positive_margin b hb0 P ha hB hm hR hz hC hCz hmarginR hzeta hsupp hmean hsecond
  have hxpow : x^(-alpha/2)≤1 := Real.rpow_le_one_of_one_le_of_nonpos hx (by linarith)
  have hBdecay := lower_support_alphabet_decay (zero_lt_one.trans_le hB) hkR ha (hpower.trans hxpow)
  have hfirst := mul_le_mul_of_nonneg_left hBdecay (show 0≤2560*R^2 by positivity)
  have hlast := mul_le_mul_of_nonneg_left hpower (show 0≤512*C*Cz^2 by positivity)
  calc
    _ ≤ 2560*R^2*(B/(k:ℝ))+512*C*Cz^2*(B^alpha/(k:ℝ)) := by
      rw [hb] at hh
      convert hh using 1; field_simp; ring
    _ ≤ _ := by dsimp [R] at *; nlinarith only [hfirst,hlast]

/-- The positive-degree normalization theorem has one order-uniform
alphabet cutoff and one root cutoff once the actual moment constant is fixed. -/
theorem prior_normalization_positive_uniform {eps C Cz : ℝ}
    (he : 0<eps) (hC : 0≤C) (hCz : 0≤Cz) :
    ∃ k₀ : ℕ, ∃ X₀ : ℝ, 1≤X₀ ∧ ∀ k : ℕ, k₀≤k → 1≤k →
      ∀ x alpha B m zeta : ℝ, X₀≤x → 3/2≤alpha → 1≤B → 0<m → 0≤zeta →
      (alpha-1)/m≤Real.log k/(eps*alpha) → zeta≤Cz*m →
      B^alpha/(k:ℝ)≤x^(-alpha/2) →
      ∀ (ι : Type) [Fintype ι] (P : FiniteAtomicPrior ι) (b : ℝ≥0),
      (b:ℝ)=(k:ℝ)/2 →
      (∀ i, P.value i=0 ∨ (1≤P.value i ∧ P.value i≤B)) →
      priorMoment P 1=1 →
      priorMoment P (2*alpha)/(priorMoment P alpha)^2≤C*zeta^2*B^alpha →
      priorNormalizationMomentBudget b P alpha m≤1/64 := by
  obtain ⟨k₀,X₀,hX₀,hcut⟩ := lower_positive_normalization_cutoffs he hC hCz
  refine ⟨k₀,X₀,hX₀,?_⟩
  intro k hk hk1 x alpha B m zeta hx ha hB hm hz hmargin hzeta hpower ι inst P b hb hsupp hmean hsecond
  exact (prior_normalization_positive_envelope b P hk1 hb ha he (hX₀.trans hx) hB hm hz hC hCz hmargin hzeta hpower hsupp hmean hsecond).trans (hcut k hk x alpha hx ha)

end Renyi
