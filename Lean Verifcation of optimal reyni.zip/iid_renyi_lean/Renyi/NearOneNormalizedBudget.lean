import Renyi.NearOneActualVariance
import Renyi.NearOneGammaCalibration

/-! A dimensionless envelope for the full near-one variance budget. -/
set_option maxHeartbeats 800000
noncomputable section
open scoped BigOperators NNReal
namespace Renyi

theorem near_one_power_normalization {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {a x : ℝ} (ha : 1 < a) (hx : 0 < x) :
    x ^ (2 * a) / (powerSum p a) ^ 2 ≤ ((k : ℝ) * x) ^ (2 * a) / (k : ℝ) ^ 2 := by
  have hk0 : (0 : ℝ) < k := by exact_mod_cast hk
  have hP := simplex_powerSum_pos p a
  have hlow := simplex_powerSum_uniform_lower hk p ha.le
  have hs := pow_le_pow_left₀ (Real.rpow_nonneg hk0.le (1-a)) hlow 2
  have hp : ((k : ℝ) ^ (1-a)) ^ 2 = (k : ℝ) ^ (2-2*a) := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul hk0.le]; congr 1; ring
  rw [hp] at hs
  have h := div_le_div_of_nonneg_left (Real.rpow_nonneg hx.le (2*a)) (Real.rpow_pos_of_pos hk0 (2-2*a)) hs
  refine h.trans_eq ?_
  have he : (k : ℝ)^(2*a)/(k : ℝ)^2 = ((k : ℝ)^(2-2*a))⁻¹ := by
    rw [← Real.rpow_two, ← Real.rpow_sub hk0, show 2*a-2 = -(2-2*a) by ring, Real.rpow_neg hk0.le]
  rw [Real.mul_rpow hk0.le hx.le]
  calc
    _ = x^(2*a) * (((k : ℝ)^(2-2*a))⁻¹) := by ring
    _ = x^(2*a) * ((k : ℝ)^(2*a)/(k : ℝ)^2) := by rw [he]
    _ = _ := by ring

theorem near_one_tangent_normalization {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {a t H : ℝ} (ha : 1 < a) (ha1 : a ≤ 3/2) (ht : 0 < t)
    (hH : 1 ≤ H) (htH : (k : ℝ)*t ≤ H) :
    t ^ (2*(a-1)) / (powerSum p a)^2 ≤ H := by
  have hk0 : (0 : ℝ) < k := by exact_mod_cast hk
  have hlow := simplex_powerSum_uniform_lower hk p ha.le
  have hs := pow_le_pow_left₀ (Real.rpow_nonneg hk0.le (1-a)) hlow 2
  have hp : ((k : ℝ) ^ (1-a))^2 = (k : ℝ) ^ (-(2*(a-1))) := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul hk0.le]; congr 1; ring
  rw [hp] at hs
  have h := div_le_div_of_nonneg_left (Real.rpow_nonneg ht.le (2*(a-1)))
    (Real.rpow_pos_of_pos hk0 (-(2*(a-1)))) hs
  have heq : t^(2*(a-1)) / (k : ℝ)^(-(2*(a-1))) = ((k : ℝ)*t)^(2*(a-1)) := by
    rw [Real.rpow_neg hk0.le, div_inv_eq_mul, Real.mul_rpow hk0.le ht.le]; ring
  rw [heq] at h
  have hm := Real.rpow_le_rpow (by positivity : 0 ≤ (k : ℝ)*t) htH (by linarith : 0 ≤ 2*(a-1))
  exact h.trans (hm.trans ((Real.rpow_le_rpow_of_exponent_le hH (by linarith : 2*(a-1)≤1)).trans_eq (Real.rpow_one H)))

theorem near_one_normalized_small_base {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {a x H : ℝ} (ha : 1 < a) (ha1 : a ≤ 3/2) (hx : 0 < x)
    (hH : 1 ≤ H) (hxH : (k : ℝ)*x ≤ H) :
    x^(2*a)/(powerSum p a)^2 ≤ H^3/(k : ℝ)^2 := by
  have h := near_one_power_normalization hk p ha hx
  have hm := Real.rpow_le_rpow (by positivity : 0 ≤ (k : ℝ)*x) hxH (by linarith : 0≤2*a)
  have hm' := Real.rpow_le_rpow_of_exponent_le hH (by linarith : 2*a≤3)
  norm_num at hm'
  exact h.trans (div_le_div_of_nonneg_right (hm.trans hm') (sq_nonneg (k : ℝ)))

theorem near_one_normalized_inverse {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {a n H : ℝ} (ha : 1 < a) (ha1 : a ≤ 3/2) (hn : 0 < n)
    (hH : 1 ≤ H) (hnH : (k : ℝ)/n ≤ H) :
    (k : ℝ)/n^(2*a)/(powerSum p a)^2 ≤ H^3/(k : ℝ) := by
  have hk0 : (0 : ℝ) < k := by exact_mod_cast hk
  have hh := near_one_normalized_small_base hk p ha ha1 (one_div_pos.mpr hn) hH (by simpa only [mul_one_div] using hnH)
  rw [one_div, Real.inv_rpow hn.le] at hh
  have hm := mul_le_mul_of_nonneg_left hh hk0.le
  have heq : (k : ℝ)*(n^(2*a))⁻¹/(powerSum p a)^2 = (k : ℝ)/n^(2*a)/(powerSum p a)^2 := by ring
  have heq' : (k : ℝ)*(H^3/(k : ℝ)^2) = H^3/(k : ℝ) := by field_simp
  simpa only [← mul_div_assoc, heq, heq'] using hm

/-- Every stochastic contribution is controlled by one scalar envelope H.
This lemma retains the actual Gamma expectation and actual simplex. -/
theorem near_one_variance_budget_normalized {k d : ℕ} (hk : 0 < k) (p : Simplex k)
    (lam : Fin k → ℝ≥0) {a n t b A Cw K T M H : ℝ}
    (ha : 1 < a) (ha1 : a ≤ 3/2) (hn : 0 < n) (ht : 0 < t) (hb : 0 < b)
    (htb : t ≤ b) (hnt : n*t ≤ 1) (hH : 1 ≤ H)
    (hlam : ∀ i, (lam i : ℝ) = n*p.mass i)
    (hnH : (k : ℝ)/n ≤ H) (hbH : (k : ℝ)*b ≤ H) (hdH : (d : ℝ)+1 ≤ H)
    (hlognt : 1+|Real.log (n*t)| ≤ H) (hlogt : |Real.log (1/t)| ≤ H)
    (hK : K^2 ≤ H) (hCG : nearOneGammaAggregateConstant Cw ≤ H)
    (hCLow : (6:ℝ)^6 * Real.exp (Real.exp 1-1) * gammaResidualPilotConstant Cw^2 ≤ H)
    (hCSel : (6:ℝ)^6 * Real.exp T * gammaResidualPilotConstant Cw^2 ≤ H)
    (hA : A^2 * Real.exp (T+M*d) ≤ H) :
    nearOneHybridVarianceBudget lam n t b (a-1) A Cw K T M d ≤
      100*(a-1)^2*(powerSum p a)^2*H^8/(k : ℝ)^(2/3:ℝ) := by
  let P := powerSum p a
  let R := (a-1)^2*P^2
  have hk0 : (0:ℝ)<k := by exact_mod_cast hk
  have hk1 : (1:ℝ)≤k := by exact_mod_cast hk
  have hP : 0<P := simplex_powerSum_pos p a
  have hgap : 0<a-1 := by linarith
  have hPP : 0<powerSum p a := hP
  have hR : 0<R := by dsimp [R]; positivity
  have hH0 : 0≤H := by linarith
  have hnP : 0<n^(2*a) := Real.rpow_pos_of_pos hn _
  have hpoly := near_one_normalized_small_base hk p ha ha1 hb hH hbH
  have hinv := near_one_normalized_inverse hk p ha ha1 hn hH hnH
  have htH : (k:ℝ)*t≤H := (mul_le_mul_of_nonneg_left htb hk0.le).trans hbH
  have htan := near_one_tangent_normalization hk p ha ha1 ht hH htH
  have hrat := simplex_powerSum_near_one_ratio hk p ha ha1
  have hp6 : H^6 ≤ H^8 := pow_le_pow_right₀ hH (by norm_num)
  have hp5 : H^5 ≤ H^8 := pow_le_pow_right₀ hH (by norm_num)
  have hp4 : H^4 ≤ H^8 := pow_le_pow_right₀ hH (by norm_num)
  have hp3 : H^3 ≤ H^8 := pow_le_pow_right₀ hH (by norm_num)
  have hkpow : (k:ℝ)^(2/3:ℝ) ≤ k := by
    exact (Real.rpow_le_rpow_of_exponent_le hk1 (by norm_num : (2/3:ℝ)≤1)).trans_eq (Real.rpow_one _)
  have hkpow0 : 0<(k:ℝ)^(2/3:ℝ) := Real.rpow_pos_of_pos hk0 _
  have hkprod : (k:ℝ)^(1/3:ℝ)*(k:ℝ)^(2/3:ℝ) = k := by
    rw [← Real.rpow_add hk0]; norm_num
  have hlo : nearOneGammaLowBudget Cw (n*t) ≤ H^3 := by
    have hs := pow_le_pow_left₀ (by positivity : 0≤1+|Real.log (n*t)|) hlognt 2
    have hm := mul_le_mul hCLow hs (sq_nonneg _) hH0
    dsimp [nearOneGammaLowBudget]
    nlinarith only [hm]
  have hlg : 1+(Real.log (1/t))^2 ≤ 2*H^2 := by
    have hs := pow_le_pow_left₀ (abs_nonneg (Real.log (1/t))) hlogt 2
    rw [sq_abs] at hs
    have hHsq := pow_le_pow_left₀ (by norm_num : (0:ℝ)≤1) hH 2
    norm_num only [one_pow] at hHsq
    linarith
  have hCG0 : 0≤nearOneGammaAggregateConstant Cw := by
    dsimp [nearOneGammaAggregateConstant, orderOneNoiseConstant]; positivity
  have hGamma := near_one_gamma_scaled_envelope p lam hn ht hnt hlam (beta := a-1) (Cw := Cw)
  have hgammaNorm : (a-1)^2/n^(2*a)*(∑ i, nearOneGammaVarianceEnvelope (a-1) (n*t) Cw (lam i)) / R ≤
      H^6/(k:ℝ) + 2*H^4*((k:ℝ)^(1/3:ℝ)+H)/(k:ℝ) := by
    have hnorm := div_le_div_of_nonneg_right hGamma hR.le
    have heq : ((a-1)^2*((k:ℝ)*nearOneGammaLowBudget Cw (n*t)/n^(2*(1+(a-1))) +
        nearOneGammaAggregateConstant Cw*(1+(Real.log (1/t))^2)/n*
        (powerSum p (1+2*(a-1))+t^(2*(a-1)))))/R =
        nearOneGammaLowBudget Cw (n*t)*((k:ℝ)/n^(2*a)/P^2) +
        nearOneGammaAggregateConstant Cw*(1+(Real.log (1/t))^2)*((k:ℝ)/n)/(k:ℝ)*
        (powerSum p (2*a-1)/P^2+t^(2*(a-1))/P^2) := by
      dsimp [R,P]
      rw [show 1+(a-1)=a by ring, show 1+2*(a-1)=2*a-1 by ring]
      field_simp [ne_of_gt hgap, ne_of_gt hPP, ne_of_gt hk0, ne_of_gt hn]
    rw [heq] at hnorm
    have hm0 := mul_le_mul hlo hinv (by positivity : 0≤(k:ℝ)/n^(2*a)/P^2) (by positivity : 0≤H^3)
    have hm1 := mul_le_mul hCG hlg (by positivity : 0≤1+(Real.log (1/t))^2) hH0
    have hm2 := mul_le_mul hm1 hnH (by positivity : 0≤(k:ℝ)/n) (by positivity : 0≤H*(2*H^2))
    have hm3 := div_le_div_of_nonneg_right hm2 hk0.le
    have hm4 := mul_le_mul hm3 (add_le_add hrat htan)
      (add_nonneg (div_nonneg (Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (p.nonneg i) _)) (sq_nonneg P)) (by positivity))
      (by positivity : 0≤H*(2*H^2)*H/(k:ℝ))
    have hres := add_le_add hm0 hm4
    have he : (a-1)^2/n^(2*a)*(∑ i, nearOneGammaVarianceEnvelope (a-1) (n*t) Cw (lam i))/R =
        (a-1)^2/n^(2*(1+(a-1)))*(∑ i, nearOneGammaVarianceEnvelope (a-1) (n*t) Cw (lam i))/R := by
      rw [show 1+(a-1)=a by ring]
    rw [he]
    exact hnorm.trans (hres.trans_eq (by ring))
  have hlight : (8*(k:ℝ)*(((d:ℝ)+1)^2*((a-1)*A)^2*Real.exp (T+M*d)*b^(2*a)))/R ≤ 8*H^6/(k:ℝ) := by
    have hs := pow_le_pow_left₀ (by positivity : 0≤(d:ℝ)+1) hdH 2
    have hm := mul_le_mul hs hA (by positivity : 0≤A^2*Real.exp (T+M*d)) (by positivity : 0≤H^2)
    have hm' := mul_le_mul hm hpoly (by positivity : 0≤b^(2*a)/(powerSum p a)^2) (by positivity : 0≤H^2*H)
    have hm'' := mul_le_mul_of_nonneg_left hm' (by positivity : 0≤8*(k:ℝ))
    have heq : (8*(k:ℝ)*(((d:ℝ)+1)^2*((a-1)*A)^2*Real.exp (T+M*d)*b^(2*a)))/R =
        8*(k:ℝ)*((((d:ℝ)+1)^2*(A^2*Real.exp (T+M*d)))*(b^(2*a)/(powerSum p a)^2)) := by dsimp [R,P]; field_simp [ne_of_gt hgap, ne_of_gt hPP, ne_of_gt hn, ne_of_gt hk0]
    rw [heq]
    convert hm'' using 1; field_simp
  have hselected : (8*(k:ℝ)*((6:ℝ)^6*Real.exp T*gammaResidualPilotConstant Cw^2*(a-1)^2/n^(2*a)*(1+|Real.log (n*t)|)^2))/R ≤8*H^6/(k:ℝ) := by
    have hs := pow_le_pow_left₀ (by positivity : 0≤1+|Real.log (n*t)|) hlognt 2
    have hm := mul_le_mul hCSel hs (sq_nonneg _) hH0
    have hm' := mul_le_mul hm hinv (by positivity : 0≤(k:ℝ)/n^(2*a)/(powerSum p a)^2) (by positivity : 0≤H*H^2)
    have hm'' := mul_le_mul_of_nonneg_left hm' (by norm_num : (0:ℝ)≤8)
    have heq : (8*(k:ℝ)*((6:ℝ)^6*Real.exp T*gammaResidualPilotConstant Cw^2*(a-1)^2/n^(2*a)*(1+|Real.log (n*t)|)^2))/R =
        8*(((6:ℝ)^6*Real.exp T*gammaResidualPilotConstant Cw^2)*(1+|Real.log (n*t)|)^2)*((k:ℝ)/n^(2*a)/(powerSum p a)^2) := by dsimp [R,P]; field_simp [ne_of_gt hgap, ne_of_gt hPP, ne_of_gt hn, ne_of_gt hk0]
    rw [heq]
    convert hm'' using 1 <;> ring
  have hanchor : (2*K^2*(a-1)^2*t^(2*(a-1))/n)/R ≤2*H^3/(k:ℝ) := by
    have hm := mul_le_mul hK htan (by positivity : 0≤t^(2*(a-1))/(powerSum p a)^2) hH0
    have hm' := mul_le_mul hm hnH (by positivity : 0≤(k:ℝ)/n) (by positivity : 0≤H*H)
    have hm'' := mul_le_mul_of_nonneg_left hm' (by norm_num : (0:ℝ)≤2)
    have heq : (2*K^2*(a-1)^2*t^(2*(a-1))/n)/R = 2*(K^2*(t^(2*(a-1))/(powerSum p a)^2))*((k:ℝ)/n)/(k:ℝ) := by dsimp [R,P]; field_simp [ne_of_gt hgap, ne_of_gt hPP, ne_of_gt hn, ne_of_gt hk0]
    rw [heq]
    convert div_le_div_of_nonneg_right hm'' hk0.le using 1 <;> ring
  have hnorm : nearOneHybridVarianceBudget lam n t b (a-1) A Cw K T M d/R ≤
      4*(H^6/(k:ℝ)+2*H^4*((k:ℝ)^(1/3:ℝ)+H)/(k:ℝ)) + 8*H^6/(k:ℝ)+8*H^6/(k:ℝ)+2*H^3/(k:ℝ) := by
    dsimp [nearOneHybridVarianceBudget]
    simp only [Fintype.card_fin, show 1+(a-1)=a by ring]
    have hsum := add_le_add (add_le_add (add_le_add (mul_le_mul_of_nonneg_left hgammaNorm (by norm_num : (0:ℝ)≤4)) hlight) hselected) hanchor
    convert hsum using 1; ring
  have hlast : 4*(H^6/(k:ℝ)+2*H^4*((k:ℝ)^(1/3:ℝ)+H)/(k:ℝ)) + 8*H^6/(k:ℝ)+8*H^6/(k:ℝ)+2*H^3/(k:ℝ) ≤ 100*H^8/(k:ℝ)^(2/3:ℝ) := by
    have h6 := (div_le_div_of_nonneg_left (pow_nonneg hH0 6) hkpow0 hkpow).trans (div_le_div_of_nonneg_right hp6 hkpow0.le)
    have h5 := (div_le_div_of_nonneg_left (pow_nonneg hH0 5) hkpow0 hkpow).trans (div_le_div_of_nonneg_right hp5 hkpow0.le)
    have h3 := (div_le_div_of_nonneg_left (pow_nonneg hH0 3) hkpow0 hkpow).trans (div_le_div_of_nonneg_right hp3 hkpow0.le)
    have h4 : H^4*(k:ℝ)^(1/3:ℝ)/(k:ℝ)≤H^8/(k:ℝ)^(2/3:ℝ) := by
      apply (div_le_iff₀ hk0).2
      have hm := mul_le_mul_of_nonneg_right hp4 (Real.rpow_nonneg hk0.le (1/3:ℝ))
      have heq : H^8/(k:ℝ)^(2/3:ℝ)*(k:ℝ)=H^8*(k:ℝ)^(1/3:ℝ) := by
        calc
          _ = H^8/(k:ℝ)^(2/3:ℝ)*((k:ℝ)^(1/3:ℝ)*(k:ℝ)^(2/3:ℝ)) := by rw [hkprod]
          _ = _ := by field_simp
      rw [heq]
      exact hm
    have hpos : 0≤H^8/(k:ℝ)^(2/3:ℝ) := by positivity
    have heq : 4*(H^6/(k:ℝ)+2*H^4*((k:ℝ)^(1/3:ℝ)+H)/(k:ℝ)) + 8*H^6/(k:ℝ)+8*H^6/(k:ℝ)+2*H^3/(k:ℝ) =
        20*(H^6/(k:ℝ))+8*(H^4*(k:ℝ)^(1/3:ℝ)/(k:ℝ))+8*(H^5/(k:ℝ))+2*(H^3/(k:ℝ)) := by ring
    rw [heq]
    calc
      _ ≤ 38*(H^8/(k:ℝ)^(2/3:ℝ)) := by linarith only [h6,h5,h3,h4]
      _ ≤ 100*(H^8/(k:ℝ)^(2/3:ℝ)) := by linarith only [hpos]
      _ = _ := by ring
  have hfinal := hnorm.trans hlast
  apply (div_le_iff₀ hR).1 at hfinal
  dsimp [R,P] at hfinal ⊢
  exact hfinal.trans_eq (by ring)

end Renyi
