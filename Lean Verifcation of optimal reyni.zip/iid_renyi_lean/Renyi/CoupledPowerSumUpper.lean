import Renyi.CoupledPolynomialRange

/-! Actual finite-sum upper margins before the deterministic below-cutoff correction. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- The actual hybrid deterministic mean retains every light and heavy upper margin,
with only the proved below-a aggregate loss. -/
theorem coupledQPolynomial_power_sum_upper {fL f E : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) (hE : 0<E) :
    ∃ M c : ℝ, 1≤M ∧ 0<c ∧
      ∀ (k ℓ N m L : ℕ) (γ z ω a b : ℝ) (p : Fin k→ℝ) (light : Fin k→Bool),
        2≤ℓ → 2≤N → ℓ≤m → N≤L → 4*(ℓ-1)≤m →
        0<γ → γ<1 → 0<z → z≤Real.exp (-E) → 0≤ω → ω≤Real.exp (-E/8) →
        0<a → a≤b → (∀ i, 0≤p i) → (∀ i, light i=true → p i≤b) →
        a≤Real.exp (-2*coupledProfileConstant)*b*(γ*(1-γ))*z^(1/(γ*(1-γ))) /
          ((m:ℝ)^2*(L:ℝ)^2) →
        let Q := coupledQPolynomial ℓ N m γ a b fL f
          (overlapA γ z*Real.exp (-M*γ)) (overlapB γ z*Real.exp (-M*(1-γ))) ω
        (∑ i, if light i then Q.eval (p i) else ω*(p i)^((m:ℝ)+γ))+
          c*(∑ i, if light i then if a≤p i then
            (p i)^((m:ℝ)+γ)*min (γ*(1-γ)+(N:ℝ)^2*(p i/b)+min ((ℓ:ℝ)^2*(a/p i)) 1) 1 else 0 else 0)+
          (1-ω)*(∑ i, if light i then 0 else (p i)^((m:ℝ)+γ))≤
          (∑ i, (p i)^((m:ℝ)+γ))+(k:ℝ)*(100:ℝ)^(m+1)*a^((m:ℝ)+γ) := by
  obtain ⟨M,c,hM,hc,hupper⟩ := coupledQPolynomial_deterministic_upper hfL hfL1 hf hf1 hE
  refine ⟨M,c,hM,hc,?_⟩
  intro k ℓ N m L γ z ω a b p light hℓ hN hℓm hNL hdegree hγ hγ1 hz hzE hω hωE ha hab hp hlight hcapacity
  dsimp only
  let A := overlapA γ z*Real.exp (-M*γ)
  let B := overlapB γ z*Real.exp (-M*(1-γ))
  let Q := coupledQPolynomial ℓ N m γ a b fL f A B ω
  let err := (100:ℝ)^(m+1)*a^((m:ℝ)+γ)
  have hM0 : 0≤M := by linarith only [hM]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  have hω1 : ω<1 := hωE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE] : -E/8<0))
  have hweights := overlap_coefficients_unit hγ hγ1 hz hz1
  have hA : 0≤A := mul_nonneg hweights.1.le (Real.exp_pos _).le
  have hB : 0≤B := mul_nonneg hweights.2.2.1.le (Real.exp_pos _).le
  have hA1 : A≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hweights.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM0,hγ]))
  have hB1 : B≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hweights.2.2.2.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM0,hd]))
  have herr : 0≤err := by dsimp [err];positivity
  have hpoint (i : Fin k) :
      (if light i then Q.eval (p i) else ω*(p i)^((m:ℝ)+γ))+
        c*(if light i then if a≤p i then
          (p i)^((m:ℝ)+γ)*min (γ*(1-γ)+(N:ℝ)^2*(p i/b)+min ((ℓ:ℝ)^2*(a/p i)) 1) 1 else 0 else 0)+
        (1-ω)*(if light i then 0 else (p i)^((m:ℝ)+γ))≤(p i)^((m:ℝ)+γ)+err := by
    by_cases hl : light i=true
    · by_cases hpa : a≤p i
      · have hpi : 0<p i := ha.trans_le hpa
        have hi := hupper ℓ N m L γ z ω a b (p i) hℓ hN hℓm hNL hdegree hγ hγ1 hz hzE hω hωE
          ha hpa (hlight i hl) hcapacity
        have him := (div_le_iff₀ (Real.rpow_pos_of_pos hpi ((m:ℝ)+γ))).mp hi
        change Q.eval (p i)≤_*_ at him
        simp only [hl,hpa,ite_true,mul_zero,add_zero]
        nlinarith only [him,herr]
      · have hi := coupledQPolynomial_below_cutoff_exponential (by omega : 0<ℓ) (by omega : 0<N)
          hdegree hγ hγ1 ha hab (hp i) (le_of_lt (lt_of_not_ge hpa)) hfL.le hfL1 hf hf1.le hA hA1 hB hB1 hω hω1
        change |Q.eval (p i)|+(p i)^((m:ℝ)+γ)≤err at hi
        have habs := le_abs_self (Q.eval (p i))
        have hpα := Real.rpow_nonneg (hp i) ((m:ℝ)+γ)
        simp only [hl,hpa,ite_true,ite_false,mul_zero,add_zero]
        nlinarith only [hi,habs,hpα]
    · have hl' : light i=false := Bool.eq_false_iff.mpr hl
      simp only [hl',Bool.false_eq_true,ite_false,mul_zero,add_zero]
      nlinarith only [herr]
  have hsum := Finset.sum_le_sum (fun (i : Fin k) (_hi : i∈Finset.univ) => hpoint i)
  simpa only [Finset.sum_add_distrib,Finset.mul_sum,Finset.sum_const,Finset.card_univ,
    Fintype.card_fin,nsmul_eq_mul,mul_assoc] using hsum

end Renyi
