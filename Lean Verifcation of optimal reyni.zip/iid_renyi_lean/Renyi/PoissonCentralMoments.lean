import Renyi.HighOrderConcentration
import Renyi.NormalizationProbability

/-! Real central moments of a Poisson variable, with constants uniform in order. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

theorem rpow_le_scaled_exponential {x q t : ℝ} (hx : 0 ≤ x)
    (hq : 0 < q) (ht : 0 < t) :
    x ^ q ≤ (q / t) ^ q * Real.exp (t * x - q) := by
  rcases eq_or_lt_of_le hx with rfl | hx
  · rw [Real.zero_rpow hq.ne']
    positivity
  have hz : 0 < x * t / q := by positivity
  have hlog := Real.log_le_sub_one_of_pos hz
  have hid : Real.log (x * t / q) = Real.log x - Real.log (q / t) := by
    rw [Real.log_div (mul_ne_zero hx.ne' ht.ne') hq.ne',
      Real.log_mul hx.ne' ht.ne', Real.log_div hq.ne' ht.ne']
    ring
  rw [hid] at hlog
  rw [Real.rpow_def_of_pos hx, Real.rpow_def_of_pos (by positivity), ← Real.exp_add]
  apply Real.exp_le_exp.mpr
  have h := mul_le_mul_of_nonneg_right hlog hq.le
  have hcancel : (x * t / q - 1) * q = t * x - q := by field_simp
  rw [hcancel] at h
  nlinarith

theorem exp_mul_abs_le (t x : ℝ) :
    Real.exp (t * |x|) ≤ Real.exp (t * x) + Real.exp (-t * x) := by
  rcases le_total 0 x with hx | hx
  · rw [abs_of_nonneg hx]
    exact le_add_of_nonneg_right (Real.exp_pos _).le
  · rw [abs_of_nonpos hx]
    have heq : t * -x = -t * x := by ring
    rw [heq]
    exact le_add_of_nonneg_left (Real.exp_pos _).le

theorem poisson_centered_rpow_integrable (lam : ℝ≥0) {q : ℝ} (hq : 0 < q) :
    Integrable (fun n : ℕ => |(n : ℝ) - lam| ^ q) (poissonMeasure lam) := by
  let C := q ^ q * Real.exp (-q)
  have hp := poisson_centered_exponential_hasSum lam 1 0
  have hn := poisson_centered_exponential_hasSum lam (-1) 0
  have hs : Summable (fun n : ℕ =>
      C * (Real.exp ((n : ℝ) - lam) + Real.exp (-((n : ℝ) - lam))) *
        poissonPMFReal lam n) := by
    simpa only [one_mul, neg_one_mul, sub_zero, mul_add, add_mul, mul_assoc] using
      ((hp.add hn).mul_left C).summable
  apply poisson_integrable_of_summable
  apply Summable.of_nonneg_of_le (fun n => mul_nonneg (norm_nonneg _) poissonPMFReal_nonneg) (fun n => ?_) hs
  rw [Real.norm_of_nonneg (Real.rpow_nonneg (abs_nonneg _) _)]
  apply mul_le_mul_of_nonneg_right _ poissonPMFReal_nonneg
  have h := rpow_le_scaled_exponential (abs_nonneg ((n : ℝ) - lam)) hq (by norm_num : (0:ℝ)<1)
  simp only [div_one, one_mul] at h
  calc
    |(n : ℝ) - lam| ^ q ≤ q ^ q * Real.exp (|(n : ℝ) - lam| - q) := h
    _ = C * Real.exp (|(n : ℝ) - lam|) := by
      dsimp [C]
      rw [sub_eq_add_neg, Real.exp_add]
      ring
    _ ≤ _ := mul_le_mul_of_nonneg_left
      (by simpa using exp_mul_abs_le 1 ((n : ℝ) - lam)) (by dsimp [C]; positivity)

theorem poisson_centered_rpow_le_parameter (lam : ℝ≥0) {q t : ℝ}
    (hq : 0 < q) (ht : 0 < t) (ht1 : t ≤ 1) (hscale : (lam : ℝ) * t ^ 2 ≤ q) :
    (∫ n : ℕ, |(n : ℝ) - lam| ^ q ∂poissonMeasure lam) ≤ 2 * (q / t) ^ q := by
  let C := (q / t) ^ q
  have hp := poisson_centered_exponential_hasSum lam t q
  have hn := poisson_centered_exponential_hasSum lam (-t) q
  have hsum := (hp.add hn).mul_left C
  have hs := poisson_centered_rpow_integrable lam hq
  rw [poisson_integral_eq_tsum lam _ hs]
  have hpoint (n : ℕ) : |(n : ℝ) - lam| ^ q * poissonPMFReal lam n ≤
      C * (Real.exp (t * ((n : ℝ) - lam) - q) * poissonPMFReal lam n +
        Real.exp (-t * ((n : ℝ) - lam) - q) * poissonPMFReal lam n) := by
    have hb := rpow_le_scaled_exponential (abs_nonneg ((n : ℝ) - lam)) hq ht
    have he : Real.exp (t * |(n : ℝ) - lam| - q) ≤
        Real.exp (t * ((n : ℝ) - lam) - q) +
          Real.exp (-t * ((n : ℝ) - lam) - q) := by
      simp only [sub_eq_add_neg, Real.exp_add]
      exact (mul_le_mul_of_nonneg_right (exp_mul_abs_le t ((n : ℝ) - lam))
        (Real.exp_pos (-q)).le).trans_eq (add_mul _ _ _)
    have h := mul_le_mul_of_nonneg_right
      (hb.trans (mul_le_mul_of_nonneg_left he (by positivity)))
      (poissonPMFReal_nonneg (r := lam) (n := n))
    dsimp [C]
    nlinarith only [h]
  have hbound (v : ℝ) (hv : v = t ∨ v = -t) :
      Real.exp ((lam : ℝ) * (Real.exp v - 1 - v) - q) ≤ 1 := by
    have habs : |v| ≤ 1 := by
      rcases hv with rfl | rfl <;> simpa [abs_of_pos ht] using ht1
    have hv2 : v ^ 2 = t ^ 2 := by rcases hv with rfl | rfl <;> ring
    have hrem := (abs_le.mp (Real.abs_exp_sub_one_sub_id_le habs)).2
    rw [hv2] at hrem
    apply Real.exp_le_one_iff.mpr
    have hm := mul_le_mul_of_nonneg_left hrem lam.coe_nonneg
    linarith
  have hleft : Summable (fun n : ℕ => |(n : ℝ) - lam| ^ q * poissonPMFReal lam n) :=
    Summable.of_nonneg_of_le (fun n => mul_nonneg (Real.rpow_nonneg (abs_nonneg _) _)
      poissonPMFReal_nonneg) hpoint hsum.summable
  have h := hleft.tsum_le_tsum hpoint hsum.summable
  rw [hsum.tsum_eq] at h
  exact h.trans (by
    have hp1 := hbound t (Or.inl rfl)
    have hn1 := hbound (-t) (Or.inr rfl)
    have hC : 0 ≤ C := by dsimp [C]; positivity
    dsimp [C] at *
    nlinarith)

theorem poisson_centered_rpow_le (lam : ℝ≥0) {q : ℝ}
    (hq : 0 < q) (hql : q ≤ (lam : ℝ)) :
    (∫ n : ℕ, |(n : ℝ) - lam| ^ q ∂poissonMeasure lam) ≤
      2 * (Real.sqrt (q * lam)) ^ q := by
  have hl : 0 < (lam : ℝ) := hq.trans_le hql
  let t := Real.sqrt (q / lam)
  have ht : 0 < t := Real.sqrt_pos.mpr (by positivity)
  have ht1 : t ≤ 1 := by
    dsimp [t]
    exact (Real.sqrt_le_one).2 ((div_le_one hl).2 hql)
  have hscale : (lam : ℝ) * t ^ 2 = q := by
    dsimp [t]
    rw [Real.sq_sqrt (by positivity)]
    field_simp
  have hid : q / t = Real.sqrt (q * lam) := by
    dsimp [t]
    rw [Real.sqrt_div hq.le, div_div_eq_mul_div, Real.sqrt_mul hq.le]
    calc
      q * Real.sqrt (lam : ℝ) / Real.sqrt q =
          (q / Real.sqrt q) * Real.sqrt (lam : ℝ) := by ring
      _ = _ := by rw [Real.div_sqrt]
  simpa only [hid] using poisson_centered_rpow_le_parameter lam hq ht ht1 hscale.le

/-- A dimension-free relative moment estimate in the high-mean regime. -/
theorem poisson_centered_rpow_le_relative (lam : ℝ≥0) {q B : ℝ}
    (hq : 0 < q) (hB : 1 ≤ B) (hl : B * q ≤ (lam : ℝ)) :
    (∫ n : ℕ, |(n : ℝ) - lam| ^ q ∂poissonMeasure lam) ≤
      2 * (1 / Real.sqrt B) ^ q * (lam : ℝ) ^ q := by
  have hB0 : 0 < B := lt_of_lt_of_le zero_lt_one hB
  have hql : q ≤ (lam : ℝ) := by nlinarith
  have hl0 : 0 < (lam : ℝ) := hq.trans_le hql
  apply (poisson_centered_rpow_le lam hq hql).trans
  have hrad : q * (lam : ℝ) ≤ ((lam : ℝ) / Real.sqrt B) ^ 2 := by
    rw [div_pow, Real.sq_sqrt hB0.le]
    apply (le_div_iff₀ hB0).2
    nlinarith [mul_le_mul_of_nonneg_right hl hl0.le]
  have hs : Real.sqrt (q * (lam : ℝ)) ≤ (lam : ℝ) / Real.sqrt B := by
    exact Real.sqrt_le_iff.mpr ⟨by positivity, hrad⟩
  have hp := Real.rpow_le_rpow (Real.sqrt_nonneg _) hs hq.le
  calc
    2 * Real.sqrt (q * (lam : ℝ)) ^ q ≤ 2 * ((lam : ℝ) / Real.sqrt B) ^ q := by linarith
    _ = _ := by
      rw [div_eq_mul_inv, Real.mul_rpow hl0.le (by positivity), one_div]
      ring

end Renyi
