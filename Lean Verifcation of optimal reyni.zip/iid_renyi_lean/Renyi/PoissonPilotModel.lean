import Renyi.PoissonToIID

/-! A concrete independent Poisson experiment for main and pilot histograms. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

abbrev PilotHistogram (k : ℕ) := Fin k×Bool → ℕ

def pilotHistogramRate {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) (ib : Fin k×Bool) : ℝ≥0 :=
  if ib.2 then cp*(n*simplexNN p ib.1) else n*simplexNN p ib.1

def pilotHistogramPMF {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) : PMF (PilotHistogram k) :=
  finitePoissonPMF (pilotHistogramRate n cp p)

def pilotMainCount {k : ℕ} (i : Fin k) (h : PilotHistogram k) : ℕ := h (i,false)
def pilotSelectionCount {k : ℕ} (i : Fin k) (h : PilotHistogram k) : ℕ := h (i,true)

/-- This is an actual product probability measure, rather than assumed laws. -/
theorem pilotHistogram_measure {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) :
    (pilotHistogramPMF n cp p).toMeasure=Measure.pi (fun ib => poissonMeasure (pilotHistogramRate n cp p ib)) := by
  rw [pilotHistogramPMF,finitePoissonPMF,Measure.toPMF_toMeasure]

/-- All main and pilot coordinates are jointly independent. -/
theorem pilotHistogram_independent {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) :
    iIndepFun (fun ib (h:PilotHistogram k) => h ib) (pilotHistogramPMF n cp p).toMeasure := by
  rw [pilotHistogram_measure]
  exact iIndepFun_pi (fun _ => measurable_id.aemeasurable)

theorem pilotHistogram_coordinate_law {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) (ib : Fin k×Bool) :
    MeasurePreserving (fun h:PilotHistogram k => h ib) (pilotHistogramPMF n cp p).toMeasure
      (poissonMeasure (pilotHistogramRate n cp p ib)) := by
  rw [pilotHistogram_measure]
  exact measurePreserving_eval (fun ib => poissonMeasure (pilotHistogramRate n cp p ib)) ib

/-- The main histogram has the exact required means. -/
theorem pilotMainCount_law {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) (i : Fin k) :
    MeasurePreserving (pilotMainCount i) (pilotHistogramPMF n cp p).toMeasure
      (poissonMeasure (n*simplexNN p i)) := by
  exact pilotHistogram_coordinate_law n cp p (i,false)

/-- The pilot histogram has the exact independent amplified means. -/
theorem pilotSelectionCount_law {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) (i : Fin k) :
    MeasurePreserving (pilotSelectionCount i) (pilotHistogramPMF n cp p).toMeasure
      (poissonMeasure (cp*(n*simplexNN p i))) := by
  exact pilotHistogram_coordinate_law n cp p (i,true)

theorem pilotMainCount_law_real {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) (i : Fin k) :
    MeasurePreserving (pilotMainCount i) (pilotHistogramPMF n cp p).toMeasure
      (poissonMeasure (Real.toNNReal ((n:ℝ)*p.mass i))) := by
  have heq : n*simplexNN p i=Real.toNNReal ((n:ℝ)*p.mass i) := by
    apply NNReal.coe_injective
    simp only [NNReal.coe_mul,simplexNN_coe,Real.coe_toNNReal _ (mul_nonneg n.coe_nonneg (p.nonneg i))]
  rw [←heq]
  exact pilotMainCount_law n cp p i

/-- The pilot and main count at a given symbol are independent. -/
theorem pilotSelectionCount_independent_main {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) (i : Fin k) :
    IndepFun (pilotSelectionCount i) (pilotMainCount i) (pilotHistogramPMF n cp p).toMeasure := by
  exact (pilotHistogram_independent n cp p).indepFun (by simp : (i,true)≠(i,false))

/-- The pilot/main pairs are independent between distinct symbols. -/
theorem pilotHistogram_pairs_independent {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) :
    Pairwise (fun i j => IndepFun (fun h => (pilotSelectionCount i h,pilotMainCount i h))
      (fun h => (pilotSelectionCount j h,pilotMainCount j h)) (pilotHistogramPMF n cp p).toMeasure) := by
  intro i j hij
  exact (pilotHistogram_independent n cp p).indepFun_prodMk_prodMk
    (fun ib => measurable_pi_apply ib) (i,true) (i,false) (j,true) (j,false)
    (by simpa using hij) (by simp) (by simp) (by simpa using hij)

end Renyi
