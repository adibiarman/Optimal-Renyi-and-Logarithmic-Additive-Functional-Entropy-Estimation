import Renyi.CompletedPolynomialRange
import Renyi.CoupledLocalization

/-! Uniform spatial localization of the actual completed coupled polynomial. -/
noncomputable section
namespace Renyi
set_option maxHeartbeats 700000

def completedLocalizationConstant : ℝ :=
  4+2*Real.exp (Real.log 12+1)+coupledLocalizationConstant

lemma completedLocalizationConstant_pos : 0<completedLocalizationConstant := by
  unfold completedLocalizationConstant coupledLocalizationConstant
  positivity

lemma completedLowProfile_unit_range {ell : ℕ} (hell : 0<ell) {gamma f x : ℝ}
    (hg : 0<gamma) (hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1) :
    0≤completedLowProfile ell gamma (DegreeOneCompletion.coefficient gamma f) f x ∧
      completedLowProfile ell gamma (DegreeOneCompletion.coefficient gamma f) f x≤1 := by
  by_cases he : ell=1
  · simp only [completedLowProfile,he,if_true]
    exact DegreeOneCompletion.lowProfile_range (by norm_num : 0<1) hg hf hf1 hx hx1
  · simp only [completedLowProfile,if_neg he]
    exact lowProfile_range hell hg hf hf1 hx hx1

/-- Both endpoint profiles approach one at least at quadratic scaled speed. -/
lemma endpointProfile_quadratic_tail {N : ℕ} (hN : 0<N) {s x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hx : 0<x) (hx1 : x≤1)
    (hy : 1≤(N:ℝ)^2*x) :
    1-endpointProfile N 6 s x≤Real.exp (Real.log 12+1)*((N:ℝ)^2*x)^(-2:ℝ) := by
  have ht := endpointProfile_tail hN (by norm_num : 2≤6) (by norm_num : 6≤6) hs hs1 hx hx1
  have hp : ((N:ℝ)^2*x)^(s-(6:ℝ))≤((N:ℝ)^2*x)^(-2:ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hy (by linarith only [hs1])
  have hcoef : Real.exp (Real.log 12+1)*s≤Real.exp (Real.log 12+1) :=
    mul_le_of_le_one_right (Real.exp_pos _).le hs1
  exact ht.trans (mul_le_mul hcoef hp (Real.rpow_nonneg (by positivity) _) (Real.exp_pos _).le)

/-- Uniform tail of the exact completed polynomial, including ell=1. -/
theorem completedCoupledPolynomial_localization_tail {ell N m : ℕ}
    (hell : 0<ell) (hN : 0<N) (hm : 1≤m) (hdegree : 4*(ell-1)≤m)
    {gamma a b p fL f A B omega : ℝ}
    (hg : 0<gamma) (hg1 : gamma<1) (ha : 0<a) (hap : a≤p) (hpb : p≤b)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hA : 0≤A) (hA1 : A≤1) (hB : 0≤B) (hB1 : B≤1)
    (hw : 0≤omega) (hw1 : omega<1) (hy : 1≤(N:ℝ)^2*(p/b)) :
    |(completedCoupledPolynomial ell N m gamma a b (DegreeOneCompletion.coefficient gamma fL)
      fL f A B omega).eval p-omega*p^((m:ℝ)+gamma)|≤
      completedLocalizationConstant*p^((m:ℝ)+gamma)*((N:ℝ)^2*(p/b))^(-2:ℝ) := by
  have hp : 0<p := ha.trans_le hap
  have hb : 0<b := hp.trans_le hpb
  have hx : 0<p/b := div_pos hp hb
  have hx1 : p/b≤1 := (div_le_one hb).mpr hpb
  have hd : 0<1-gamma := sub_pos.mpr hg1
  let U := completedLowProfile ell gamma (DegreeOneCompletion.coefficient gamma fL) fL (a/p)
  let V := highProfile N (1-gamma) f omega (p/b)
  let H := endpointProfile N 6 1 (p/b)
  let J := endpointProfile N 6 (1-gamma) (p/b)
  let r := ((N:ℝ)^2*(p/b))^(-2:ℝ)
  let Ce := Real.exp (Real.log 12+1)
  have hr : 0≤r := Real.rpow_nonneg (by positivity) _
  have hCe : 0≤Ce := (Real.exp_pos _).le
  have hC : 0≤coupledLocalizationConstant := (Real.exp_pos _).le
  have hU := completedLowProfile_unit_range hell hg hfL hfL1
    (div_nonneg ha.le hp.le) ((div_le_one hp).mpr hap)
  change 0≤U ∧ U≤1 at hU
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hx.le hx1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hx.le hx1
  change 0≤H ∧ H≤1 at hH
  change 0≤J ∧ J≤1 at hJ
  have hHtail : 1-H≤Ce*r := endpointProfile_quadratic_tail hN (by norm_num) le_rfl hx hx1 hy
  have hJtail : 1-J≤Ce*r := endpointProfile_quadratic_tail hN hd (by linarith only [hg]) hx hx1 hy
  have hV := highProfile_localization_tail hN hd (by linarith only [hg]) hf hf1 hw hw1 hx.le hx1 hy
  have hpow : ((N:ℝ)^2*(p/b))^(-3:ℝ)≤r :=
    Real.rpow_le_rpow_of_exponent_le hy (by norm_num)
  have hVtail : |V-omega*J|≤coupledLocalizationConstant*r :=
    hV.trans (mul_le_mul_of_nonneg_left hpow hC)
  have hAU : A*U≤1 := mul_le_one₀ hA1 hU.1 hU.2
  have hLow0 : 0≤A*U*(1-H) := mul_nonneg (mul_nonneg hA hU.1) (sub_nonneg.mpr hH.2)
  have hLow : A*U*(1-H)≤Ce*r :=
    (mul_le_of_le_one_left (sub_nonneg.mpr hH.2) hAU).trans hHtail
  have hMid : |B*(V-omega*J)|≤coupledLocalizationConstant*r := by
    rw [abs_mul,abs_of_nonneg hB]
    exact (mul_le_of_le_one_left (abs_nonneg _) hB1).trans hVtail
  have hEnd0 : 0≤omega*(1-J) := mul_nonneg hw (sub_nonneg.mpr hJ.2)
  have hEnd : omega*(1-J)≤Ce*r :=
    (mul_le_of_le_one_left (sub_nonneg.mpr hJ.2) hw1.le).trans hJtail
  have hScalar : |A*U*(1-H)+B*V+omega*(1-B)*J-omega|≤
      completedLocalizationConstant*r := by
    have hmid := abs_le.mp hMid
    apply abs_le.mpr
    dsimp [completedLocalizationConstant]
    constructor <;> nlinarith only [hLow0,hLow,hmid.1,hmid.2,hEnd0,hEnd,hr]
  rw [completedCoupledPolynomial_eval hell hN hm hdegree hg hg1
    (DegreeOneCompletion.coefficient_pos hg hfL1) ha hap hpb]
  have hid : p^((m:ℝ)+gamma)*(A*U*(1-H)+B*V+omega*(1-B)*J)-omega*p^((m:ℝ)+gamma)=
      p^((m:ℝ)+gamma)*(A*U*(1-H)+B*V+omega*(1-B)*J-omega) := by ring
  change |p^((m:ℝ)+gamma)*(A*U*(1-H)+B*V+omega*(1-B)*J)-omega*p^((m:ℝ)+gamma)|≤_
  rw [hid,abs_mul,abs_of_nonneg (Real.rpow_nonneg hp.le _)]
  convert mul_le_mul_of_nonneg_left hScalar (Real.rpow_nonneg hp.le ((m:ℝ)+gamma)) using 1
  ring

/-- Full localization toward omega p^alpha with a fixed universal constant. -/
theorem completedCoupledPolynomial_localization {ell N m : ℕ}
    (hell : 0<ell) (hN : 0<N) (hm : 1≤m) (hdegree : 4*(ell-1)≤m)
    {gamma a b p fL f A B omega : ℝ}
    (hg : 0<gamma) (hg1 : gamma<1) (ha : 0<a) (hap : a≤p) (hpb : p≤b)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hA : 0≤A) (hA1 : A≤1) (hB : 0≤B) (hB1 : B≤1)
    (hw : 0≤omega) (hw1 : omega<1) :
    |(completedCoupledPolynomial ell N m gamma a b (DegreeOneCompletion.coefficient gamma fL)
      fL f A B omega).eval p-omega*p^((m:ℝ)+gamma)|≤
      completedLocalizationConstant*p^((m:ℝ)+gamma)*min 1 (((N:ℝ)^2*(p/b))^(-2:ℝ)) := by
  have hp : 0<p := ha.trans_le hap
  have hb : 0<b := hp.trans_le hpb
  have hy : 0<(N:ℝ)^2*(p/b) := by positivity
  by_cases hy1 : 1≤(N:ℝ)^2*(p/b)
  · rw [min_eq_right (Real.rpow_le_one_of_one_le_of_nonpos hy1 (by norm_num))]
    exact completedCoupledPolynomial_localization_tail hell hN hm hdegree hg hg1 ha hap hpb hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1 hy1
  · have hpow : 1≤((N:ℝ)^2*(p/b))^(-2:ℝ) :=
      Real.one_le_rpow_of_pos_of_le_one_of_nonpos hy (le_of_not_ge hy1) (by norm_num)
    rw [min_eq_left hpow,mul_one]
    have hQ := completedCoupledPolynomial_absolute_envelope hell hN hm hdegree hg hg1 ha hap hpb hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1
    have htri := abs_sub (completedCoupledPolynomial ell N m gamma a b
      (DegreeOneCompletion.coefficient gamma fL) fL f A B omega |>.eval p) (omega*p^((m:ℝ)+gamma))
    rw [abs_of_nonneg (mul_nonneg hw (Real.rpow_nonneg hp.le _))] at htri
    have hW := mul_le_of_le_one_left (Real.rpow_nonneg hp.le ((m:ℝ)+gamma)) hw1.le
    have hC : 4≤completedLocalizationConstant := by
      unfold completedLocalizationConstant coupledLocalizationConstant
      linarith only [Real.exp_pos (Real.log 12+1),Real.exp_pos (Real.log 24+2)]
    have hc := mul_le_mul_of_nonneg_right hC (Real.rpow_nonneg hp.le ((m:ℝ)+gamma))
    nlinarith only [hQ,htri,hW,hc]
end Renyi
