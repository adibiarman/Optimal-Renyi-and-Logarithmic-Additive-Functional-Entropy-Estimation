import Renyi.NearTwoHybridMargin

/-! The known cutoff correction is paid by the actual summed near-two upper margin. -/
noncomputable section
open scoped BigOperators
namespace Renyi

def nearTwoHybridReserve (eps lambda c cw : ℝ) : ℝ :=
  min c (1 - Real.exp (-cw * eps / 2)) * (nearTwoEndpointConstant eps lambda / 2)

lemma nearTwoHybridReserve_pos {eps lambda c cw : ℝ}
    (heps : 0 < eps) (hlambda : 0 < lambda) (hc : 0 < c) (hcw : 0 < cw) :
    0 < nearTwoHybridReserve eps lambda c cw := by
  have he : Real.exp (-cw * eps / 2) < 1 :=
    Real.exp_lt_one_iff.mpr (by nlinarith only [mul_pos hcw heps])
  have hg : 0 < 1 - Real.exp (-cw * eps / 2) := by linarith
  unfold nearTwoHybridReserve
  exact mul_pos (lt_min hc hg) (div_pos (nearTwoEndpointConstant_pos (eps := eps) hlambda) (by norm_num))

lemma upperOmega_near_two_gap {k : ℕ} {alpha eps Ch cw : ℝ}
    (halpha : 3 / 2 ≤ alpha) (halpha2 : alpha < 2) (heps : 0 < eps)
    (hCh : 0 ≤ Ch) (hcw : 0 ≤ cw) :
    1 - Real.exp (-cw * eps / 2) ≤ 1 - upperOmega k alpha eps Ch cw := by
  have ha : 1 < alpha := by linarith
  have hm := upperOrderFloor_eq_one_near_two ha halpha2
  have hgamma : fractionalPart alpha = alpha - 1 := by
    rw [fractionalPart_eq_upperOrderFloor ha, hm]; norm_num
  have hg : 0 < fractionalPart alpha := by rw [hgamma]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [hgamma]; linarith
  have hE := (upper_reserved_interval (k := k) ha hg hg1 heps hCh).1
  have hlow := mul_le_mul_of_nonneg_left (show (1 : ℝ) / 2 ≤ alpha - 1 by linarith) heps.le
  have hmul := mul_le_mul_of_nonneg_left (hlow.trans hE) hcw
  have he := Real.exp_le_exp.mpr (show -cw * upperE0 k alpha eps Ch ≤ -cw * eps / 2 by
    nlinarith only [hmul])
  exact sub_le_sub_left he 1

lemma upperActualBaseline_near_two_exact {k : ℕ} (hk : 0 < k)
    {alpha C0 d a : ℝ} (halpha : 3 / 2 ≤ alpha) (halpha2 : alpha < 2) (ha : 0 ≤ a) :
    upperActualBaseline k alpha C0 d a * (k : ℝ) ^ (1 - alpha) =
      (alpha - 1) * d * C0 * a ^ (alpha - 1) := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hm := upperOrderFloor_eq_one_near_two (by linarith : 1 < alpha) halpha2
  unfold upperActualBaseline
  rw [hm, pow_one, min_eq_left (show alpha - 1 ≤ 1 by linarith), Real.mul_rpow hkR.le ha]
  have hid : (k : ℝ) ^ (alpha - 1) * (k : ℝ) ^ (1 - alpha) = 1 := by
    rw [← Real.rpow_add hkR]
    simp
  calc
    _ = (alpha - 1) * d * C0 * a ^ (alpha - 1) *
        ((k : ℝ) ^ (alpha - 1) * (k : ℝ) ^ (1 - alpha)) := by ring
    _ = _ := by rw [hid, mul_one]

/-- The actual source baseline and all below-cutoff errors consume at most half of
the strict reserve, for all orders in [3/2,2), using one fixed d and one final D. -/
theorem upper_actual_near_two_correction_absorbed {eps Ch cb lambda CL cL C0 c cw : ℝ}
    (heps : 0 < eps) (hCh : 0 ≤ Ch) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hC0 : 0 < C0) (hc : 0 < c) (hcw : 0 < cw) :
    ∃ d0 D0 : ℝ, 0 < d0 ∧ d0 ≤ 1 ∧ 1 ≤ D0 ∧
      ∀ (k : ℕ) (alpha D d ell : ℝ), 0 < k → 3 / 2 ≤ alpha → alpha < 2 →
        D0 ≤ D → 0 ≤ d → d ≤ d0 → 1 ≤ ell → ∀ (p : Simplex k) (light : Fin k → Bool),
      let a := upperA k alpha eps Ch D cb lambda CL cL
      let b := upperB k alpha eps D cb CL cL
      let N := upperDegree alpha CL cL (rootMultiplier k alpha eps)
      let omega := upperOmega k alpha eps Ch cw
      4 * (upperActualBaseline k alpha C0 d a * (k : ℝ) ^ (1 - alpha)) +
        (k : ℝ) * 100 ^ (2 : ℕ) * a ^ alpha ≤
      (1 / 2 : ℝ) * (c * (∑ i, if light i then if a ≤ p.mass i then p.mass i ^ alpha *
        min ((alpha - 1) * (1 - (alpha - 1)) + ((N : ℝ) ^ 2 / b) * p.mass i +
          min (ell ^ 2 * (a / p.mass i)) 1) 1 else 0 else 0) +
        (1 - omega) * (∑ i, if light i then 0 else p.mass i ^ alpha)) := by
  let K := nearTwoHybridReserve eps lambda c cw
  have hK : 0 < K := nearTwoHybridReserve_pos heps hlambda hc hcw
  obtain ⟨Dm, hDm, hmargin⟩ := upper_actual_hybrid_endpoint_margin_near_two
    heps hCh hcb hlambda hCL hcL
  obtain ⟨Da, hDa, hcut⟩ := upper_cutoff_eventually_small heps hCh hcb hlambda hCL hcL
    (by positivity : (0 : ℝ) < K / 40000)
  let d0 := min 1 (K / (32 * C0))
  refine ⟨d0, max Dm Da, by dsimp [d0]; positivity, min_le_left _ _,
    hDm.trans (le_max_left _ _), ?_⟩
  intro k alpha D d ell hk halpha halpha2 hD hd hd0 hell p light
  dsimp only
  have ha1 : 1 < alpha := by linarith
  have hm := upperOrderFloor_eq_one_near_two ha1 halpha2
  have hgamma : fractionalPart alpha = alpha - 1 := by
    rw [fractionalPart_eq_upperOrderFloor ha1, hm]; norm_num
  have hg : 0 < fractionalPart alpha := by rw [hgamma]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [hgamma]; linarith
  have hDmD : Dm ≤ D := (le_max_left _ _).trans hD
  have hDaD : Da ≤ D := (le_max_right _ _).trans hD
  have hDpos : 0 < D := zero_lt_one.trans_le (hDm.trans hDmD)
  have hb := upperB_pos hk ha1 hg hg1 hDpos hcb hCL hcL (ε := eps)
  have hdelta : 0 ≤ 1 - fractionalPart alpha := by linarith
  have ha : 0 ≤ upperA k alpha eps Ch D cb lambda CL cL := by unfold upperA upperOverlapZ; positivity
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hka : (k : ℝ) * upperA k alpha eps Ch D cb lambda CL cL ≤ K / 40000 := by
    have hh := mul_le_mul_of_nonneg_left (hcut k alpha D hk ha1 hg hg1 hDaD) hkR.le
    have hid : (k : ℝ) * (K / 40000 * ((alpha - 1) / (alpha * k))) =
        K / 40000 * ((alpha - 1) / alpha) := by field_simp
    rw [hid] at hh
    have hratio : (alpha - 1) / alpha ≤ 1 := (div_le_one (by linarith : 0 < alpha)).mpr (by linarith)
    exact hh.trans (mul_le_of_le_one_right (by positivity) hratio)
  have hdK : d * C0 ≤ K / 32 := by
    have hdd := hd0.trans (min_le_right 1 (K / (32 * C0)))
    have hmul := (le_div_iff₀ (by positivity : 0 < 32 * C0)).mp hdd
    linarith
  have hbeta : 0 ≤ alpha - 1 := by linarith
  have hbeta1 : alpha - 1 ≤ 1 := by linarith
  have hbase := upperActualBaseline_near_two_exact hk halpha halpha2 ha
    (C0 := C0) (d := d)
  have hbaseB : upperActualBaseline k alpha C0 d (upperA k alpha eps Ch D cb lambda CL cL) *
      (k : ℝ) ^ (1 - alpha) ≤ K / 32 *
        upperA k alpha eps Ch D cb lambda CL cL ^ (alpha - 1) := by
    rw [hbase]
    have hbC : (alpha - 1) * d * C0 ≤ K / 32 := by
      have hh := mul_le_mul_of_nonneg_right hbeta1 (mul_nonneg hd hC0.le)
      nlinarith only [hh, hdK]
    exact mul_le_mul_of_nonneg_right hbC (Real.rpow_nonneg ha _)
  have herr : (k : ℝ) * 100 ^ (2 : ℕ) * upperA k alpha eps Ch D cb lambda CL cL ^ alpha ≤
      K / 4 * upperA k alpha eps Ch D cb lambda CL cL ^ (alpha - 1) := by
    have hpowa : upperA k alpha eps Ch D cb lambda CL cL ^ alpha =
        upperA k alpha eps Ch D cb lambda CL cL * upperA k alpha eps Ch D cb lambda CL cL ^ (alpha - 1) := by
      have heq : 1 + (alpha - 1) = alpha := by ring
      have hh := Real.rpow_add_of_nonneg ha (by norm_num : (0 : ℝ) ≤ 1) hbeta
      simpa only [heq, Real.rpow_one] using hh
    rw [hpowa]
    have hmul := mul_le_mul_of_nonneg_right hka
      (show 0 ≤ (100 : ℝ) ^ (2 : ℕ) * upperA k alpha eps Ch D cb lambda CL cL ^ (alpha - 1) by positivity)
    nlinarith only [hmul]
  have hgap := upperOmega_near_two_gap (k := k) halpha halpha2 heps hCh hcw.le
  have hgap0 : 0 ≤ 1 - upperOmega k alpha eps Ch cw := by
    have he : Real.exp (-cw * eps / 2) < 1 :=
      Real.exp_lt_one_iff.mpr (by nlinarith only [mul_pos hcw heps])
    linarith
  have hmargin' := hmargin k alpha D ell c (1 - upperOmega k alpha eps Ch cw)
    hk halpha halpha2 hDmD hell hc.le hgap0 p light
  have hKle : K ≤ min c (1 - upperOmega k alpha eps Ch cw) * (nearTwoEndpointConstant eps lambda / 2) := by
    exact mul_le_mul_of_nonneg_right (min_le_min (le_refl c) hgap)
      (div_nonneg (nearTwoEndpointConstant_pos (eps := eps) hlambda).le (by norm_num))
  have hreserve := (mul_le_mul_of_nonneg_right hKle (Real.rpow_nonneg ha (alpha - 1))).trans hmargin'
  nlinarith only [hbaseB, herr, hreserve, Real.rpow_nonneg ha (alpha - 1), hK]

end Renyi
