import Renyi.ActualCountGeometry
import Renyi.DegreeOneLowBounds

/-! The actual source polynomial and the root-width lower bound used in count calibration. -/
noncomputable section
open Polynomial
namespace Renyi

def actualUpperPolynomial (k : ℕ) (alpha eps Ch D cb lambda CL cL fL f M cw : ℝ) : ℝ[X] :=
  completedCoupledPolynomial (upperLowResolution alpha)
    (upperDegree alpha CL cL (rootMultiplier k alpha eps)) (upperOrderFloor alpha)
    (fractionalPart alpha) (upperA k alpha eps Ch D cb lambda CL cL)
    (upperB k alpha eps D cb CL cL) (DegreeOneCompletion.coefficient (fractionalPart alpha) fL) fL f
    (overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)) *
      Real.exp (-M * fractionalPart alpha))
    (overlapB (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)) *
      Real.exp (-M * (1 - fractionalPart alpha)))
    (upperOmega k alpha eps Ch cw)

theorem actualUpperPolynomial_natDegree {k : ℕ} {alpha eps Ch D cb lambda CL cL fL f M cw : ℝ}
    (halpha : 1 < alpha) :
    (actualUpperPolynomial k alpha eps Ch D cb lambda CL cL fL f M cw).natDegree ≤
      upperCountDegree k alpha eps CL cL := by
  exact completedCoupledPolynomial_natDegree (upperOrderFloor_one_le halpha) _ _ _ _ _ _ _ _ _ _ _

theorem upperU_root_width_lower {k : ℕ} {alpha eps u0 : ℝ}
    (halpha : 3 / 2 ≤ alpha) (hg : 0 < fractionalPart alpha)
    (hg1 : fractionalPart alpha < 1) (hu0 : 0 < u0) :
    min (1 / 3 : ℝ) u0 * rootMultiplier k alpha eps ^ (-alpha) ≤ upperU k alpha eps u0 := by
  have ha1 : 1 < alpha := by linarith
  have hX := one_le_rootMultiplier (k := k) (ε := eps) ha1 hg hg1
  have hX0 : 0 < rootMultiplier k alpha eps := zero_lt_one.trans_le hX
  have hxpow : rootMultiplier k alpha eps ^ (-alpha) ≤ 1 :=
    Real.rpow_le_one_of_one_le_of_nonpos hX (by linarith)
  unfold upperU upperV
  apply le_min
  · have h1 := mul_le_mul_of_nonneg_right
      ((min_le_left (1 / 3 : ℝ) u0).trans (upper_gap_ratio_ge_third halpha))
        (Real.rpow_nonneg hX0.le (-alpha))
    have hh : 0 ≤ fractionalPart alpha * (1 - fractionalPart alpha) :=
      mul_nonneg hg.le (sub_nonneg.mpr hg1.le)
    linarith
  · exact (mul_le_of_le_one_right (le_min (by norm_num) hu0.le) hxpow).trans (min_le_right _ _)

/-- Every scalar profile coefficient in the actual polynomial has its required range. -/
theorem upper_actual_count_profile_ranges {k : ℕ} {alpha eps Ch M cw fL : ℝ}
    (halpha : 1 < alpha) (hg : 0 < fractionalPart alpha) (hg1 : fractionalPart alpha < 1)
    (heps : 0 < eps) (hCh : 0 ≤ Ch) (hM : 0 ≤ M) (hcw : 0 < cw) (hfL1 : fL < 1) :
    let gamma := fractionalPart alpha
    let z := upperOverlapZ gamma (upperE0 k alpha eps Ch)
    (DegreeOneCompletion.coefficient gamma fL ∈ Set.Ioo (gamma / (1 + gamma)) 1) ∧
      0 ≤ overlapA gamma z * Real.exp (-M * gamma) ∧ overlapA gamma z * Real.exp (-M * gamma) ≤ 1 ∧
      0 ≤ overlapB gamma z * Real.exp (-M * (1 - gamma)) ∧ overlapB gamma z * Real.exp (-M * (1 - gamma)) ≤ 1 ∧
      0 ≤ upperOmega k alpha eps Ch cw ∧ upperOmega k alpha eps Ch cw < 1 := by
  dsimp only
  have hE : 0 < upperE0 k alpha eps Ch := (mul_pos heps (sub_pos.mpr halpha)).trans_le
    (upper_reserved_interval (k := k) halpha hg hg1 heps hCh).1
  have hz := (upperOverlapZ_spec hg hg1 hE).1
  have hweights := overlap_coefficients_unit hg hg1 hz.1 hz.2
  have heA : Real.exp (-M * fractionalPart alpha) ≤ 1 :=
    Real.exp_le_one_iff.mpr (by nlinarith only [hM, hg])
  have heB : Real.exp (-M * (1 - fractionalPart alpha)) ≤ 1 :=
    Real.exp_le_one_iff.mpr (by nlinarith only [hM, hg1])
  have homega : upperOmega k alpha eps Ch cw < 1 := by
    unfold upperOmega
    exact Real.exp_lt_one_iff.mpr (by nlinarith only [mul_pos hcw hE])
  refine ⟨(DegreeOneCompletion.coefficient_spec hg hfL1).1,
    mul_nonneg hweights.1.le (Real.exp_pos _).le, ?_,
    mul_nonneg hweights.2.2.1.le (Real.exp_pos _).le, ?_, (Real.exp_pos _).le, homega⟩
  · exact (mul_le_of_le_one_right hweights.1.le heA).trans hweights.2.1.le
  · exact (mul_le_of_le_one_right hweights.2.2.1.le heB).trans hweights.2.2.2.le

end Renyi
