import Renyi.NearOneCoefficients

/-! Exact affine coefficients and their sharp near-one cancellation. -/
noncomputable section
open Polynomial
namespace Renyi

lemma nearOneCoupledPolynomial_coeff_zero (N : ℕ) (β τ b f ω A B : ℝ) :
    (nearOneCoupledPolynomial N β τ b f ω A B).coeff 0 = -A*β*τ^(1+β) := by
  simp [nearOneCoupledPolynomial,nearOneTangentPolynomial,mul_coeff_zero]
  ring

lemma nearOneCoupledPolynomial_coeff_one {N : ℕ} (hN : 0<N) (β τ b f ω A B : ℝ) :
    (nearOneCoupledPolynomial N β τ b f ω A B).coeff 1 =
      A*(1+β)*τ^β+A*β*τ^(1+β)/b*(endpointIntegral N 6 1)⁻¹ := by
  unfold nearOneCoupledPolynomial
  simp only [coeff_add,mul_assoc,coeff_C_mul,coeff_X_pow_mul',Nat.not_ofNat_le_one,ite_false,mul_zero,add_zero]
  rw [mul_coeff_one]
  have hone : (1:ℝ[X]).coeff 1=0 := by simp only [Polynomial.coeff_one,Nat.one_ne_zero,if_false]
  have hcut : (C b⁻¹*X*(endpointProfilePolynomial N 6 1).comp (C b⁻¹*X)).coeff 1=
      b⁻¹*(endpointIntegral N 6 1)⁻¹ := by
    rw [mul_assoc,coeff_C_mul,show (1:ℕ)=0+1 by rfl,coeff_X_mul,comp_C_mul_X_coeff,
      endpointProfilePolynomial_coeff_zero hN]
    simp
  simp [nearOneTangentPolynomial,comp_C_mul_X_coeff,endpointProfilePolynomial_coeff_zero hN,hone,hcut];ring


lemma nearOne_unit_amplitude_cancellation {β r M C A ω : ℝ}
    (hβ : 0≤β) (hβ1 : β≤1) (hr : 0<r) (hM : |Real.log r|≤M)
    (hA : 0≤A) (hA1 : A≤1) (hclose : |A-ω|≤C*β) :
    |A*(1+β)*r^β-ω|≤(C+Real.exp M*(M+1))*β := by
  have hdiff := compact_rpow_difference hr hβ hβ1 hM
  have hM0 := (abs_nonneg (Real.log r)).trans hM
  have hp : r^β≤Real.exp M := by
    rw [Real.rpow_def_of_pos hr]
    apply Real.exp_le_exp.mpr
    have hl := mul_le_mul_of_nonneg_right ((le_abs_self _).trans hM) hβ
    nlinarith only [hl,mul_le_of_le_one_right hM0 hβ1]
  have hid : A*(1+β)*r^β-ω=(A-ω)+A*(r^β-1)+A*β*r^β := by ring
  rw [hid]
  apply (abs_add_le _ _).trans
  apply le_trans (add_le_add_right (abs_add_le _ _) _)
  rw [abs_mul,abs_of_nonneg hA,abs_of_nonneg (show 0≤A*β*r^β by positivity)]
  have h1 := (mul_le_of_le_one_left (abs_nonneg _) hA1).trans hdiff
  have h2 := mul_le_mul_of_nonneg_left hp (mul_nonneg hA hβ)
  have h3 := mul_le_of_le_one_left (show 0≤β*Real.exp M by positivity) hA1
  nlinarith only [hclose,h1,h2,h3]

lemma endpointIntegral_scaled_one_inverse {N : ℕ} (hN : 0<N) :
    ((N:ℝ)^2*endpointIntegral N 6 1)⁻¹≤Real.exp (Real.log 12+1) := by
  have h := endpointScaledTotal_inverse_bound hN (by norm_num : 6≤6)
    (by norm_num : (0:ℝ)<1) (by norm_num : (1:ℝ)≤1)
  rw [endpointScaledPrimitive_rescale hN 1 (sq_nonneg (N:ℝ)),Real.rpow_one,
    div_self (by positivity : (N:ℝ)^2≠0)] at h
  exact h

lemma nearOneCoupledPolynomial_coeff_one_scaled {N : ℕ} (hN : 0<N)
    {t r : ℝ} (ht : 0<t) (hr : 0<r) (β f ω A B : ℝ) :
    (nearOneCoupledPolynomial N β (t*r) (t*(N:ℝ)^2) f ω A B).coeff 1 =
      t^β*(A*(1+β)*r^β+A*β*r^(1+β)*((N:ℝ)^2*endpointIntegral N 6 1)⁻¹) := by
  rw [nearOneCoupledPolynomial_coeff_one hN,Real.mul_rpow ht.le hr.le,
    Real.mul_rpow ht.le hr.le,Real.rpow_add ht,Real.rpow_one]
  field_simp

/-- The constant coefficient has the small local scale and an explicit beta factor. -/
theorem nearOneCoupledPolynomial_constant_bound {N : ℕ} {β t r f ω A B M : ℝ}
    (hβ : 0≤β) (hβ1 : β≤1) (ht : 0<t) (hr : 0<r)
    (hM : |Real.log r|≤M) (hA : 0≤A) (hA1 : A≤1) :
    |(nearOneCoupledPolynomial N β (t*r) (t*(N:ℝ)^2) f ω A B).coeff 0|≤
      Real.exp (2*M)*β*t^(1+β) := by
  rw [nearOneCoupledPolynomial_coeff_zero,abs_mul,abs_mul,abs_neg,abs_of_nonneg hA,
    abs_of_nonneg hβ,abs_of_nonneg (Real.rpow_nonneg (mul_pos ht hr).le (1+β)),Real.mul_rpow ht.le hr.le]
  have hp := compact_rpow_upper hr (by linarith only [hβ] : 0≤1+β) (by linarith only [hβ1] : 1+β≤2) hM
  have hm := mul_le_mul_of_nonneg_left hp (show 0≤A*β*t^(1+β) by positivity)
  have hA' := mul_le_of_le_one_left (show 0≤β*t^(1+β)*Real.exp (2*M) by positivity) hA1
  nlinarith only [hm,hA']

def nearOneAffineConstant (M C : ℝ) : ℝ :=
  C+Real.exp M*(M+1)+Real.exp (2*M)*Real.exp (Real.log 12+1)

/-- The exact linear coefficient is within O(beta) of omega*t^beta uniformly in N. -/
theorem nearOneCoupledPolynomial_linear_bound {N : ℕ} (hN : 0<N)
    {β t r f ω A B M C : ℝ} (hβ : 0≤β) (hβ1 : β≤1) (ht : 0<t) (hr : 0<r)
    (hM : |Real.log r|≤M) (hA : 0≤A) (hA1 : A≤1) (hclose : |A-ω|≤C*β) :
    |(nearOneCoupledPolynomial N β (t*r) (t*(N:ℝ)^2) f ω A B).coeff 1-ω*t^β|≤
      nearOneAffineConstant M C*β*t^β := by
  rw [nearOneCoupledPolynomial_coeff_one_scaled hN ht hr]
  have hid : t^β*(A*(1+β)*r^β+A*β*r^(1+β)*((N:ℝ)^2*endpointIntegral N 6 1)⁻¹)-ω*t^β=
      t^β*((A*(1+β)*r^β-ω)+A*β*r^(1+β)*((N:ℝ)^2*endpointIntegral N 6 1)⁻¹) := by ring
  rw [hid,abs_mul,abs_of_nonneg (Real.rpow_nonneg ht.le β)]
  have hfirst := nearOne_unit_amplitude_cancellation hβ hβ1 hr hM hA hA1 hclose
  have hI := endpointIntegral_pos hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1)
  have hIinv : 0≤((N:ℝ)^2*endpointIntegral N 6 1)⁻¹ := by positivity
  have hp := compact_rpow_upper hr (by linarith only [hβ] : 0≤1+β) (by linarith only [hβ1] : 1+β≤2) hM
  have hp' := mul_le_mul hp (endpointIntegral_scaled_one_inverse hN) hIinv (Real.exp_pos _).le
  have hm := mul_le_mul_of_nonneg_left hp' (mul_nonneg hA hβ)
  have hA' := mul_le_of_le_one_left
    (show 0≤β*Real.exp (2*M)*Real.exp (Real.log 12+1) by positivity) hA1
  have hsecond : |A*β*r^(1+β)*((N:ℝ)^2*endpointIntegral N 6 1)⁻¹|≤
      β*Real.exp (2*M)*Real.exp (Real.log 12+1) := by
    rw [abs_of_nonneg (show 0≤A*β*r^(1+β)*((N:ℝ)^2*endpointIntegral N 6 1)⁻¹ by positivity)]
    nlinarith only [hm,hA']
  have hsum := (abs_add_le _ _).trans (add_le_add hfirst hsecond)
  have hbound := mul_le_mul_of_nonneg_left hsum (Real.rpow_nonneg ht.le β)
  unfold nearOneAffineConstant
  nlinarith only [hbound]

end Renyi
