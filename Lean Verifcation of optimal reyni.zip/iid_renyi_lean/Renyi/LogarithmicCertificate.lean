import Renyi.Foundations
import Mathlib.Probability.Moments.Variance
import Mathlib.Analysis.Complex.Trigonometric

/-!
# The exact logarithmic accuracy certificate

This module proves the deterministic logarithmic conversion and its complete
Chebyshev consequence for an arbitrary square-integrable real statistic.
-/

noncomputable section
open MeasureTheory ProbabilityTheory
namespace Renyi

theorem one_add_tanh_eq (x : ℝ) :
    1 + Real.tanh x = Real.exp x / Real.cosh x := by
  rw [Real.tanh_eq_sinh_div_cosh]
  apply (eq_div_iff (ne_of_gt (Real.cosh_pos x))).2
  field_simp
  exact Real.cosh_add_sinh x

theorem one_sub_tanh_eq (x : ℝ) :
    1 - Real.tanh x = Real.exp (-x) / Real.cosh x := by
  rw [Real.tanh_eq_sinh_div_cosh]
  apply (eq_div_iff (ne_of_gt (Real.cosh_pos x))).2
  field_simp
  exact Real.cosh_sub_sinh x

theorem tanh_positive_lt_one {x : ℝ} (hx : 0 < x) :
    0 < Real.tanh x ∧ Real.tanh x < 1 := by
  have hexp : Real.exp (-x) < Real.exp x := Real.exp_lt_exp.mpr (by linarith)
  have hsinh : 0 < Real.sinh x := by rw [Real.sinh_eq]; linarith
  constructor
  · rw [Real.tanh_eq_sinh_div_cosh]
    exact div_pos hsinh (Real.cosh_pos x)
  · have h : 0 < 1 - Real.tanh x := by
      rw [one_sub_tanh_eq]
      exact div_pos (Real.exp_pos _) (Real.cosh_pos x)
    linarith

theorem log_tanh_width (x : ℝ) :
    Real.log (1 + Real.tanh x) - Real.log (1 - Real.tanh x) = 2 * x := by
  rw [one_add_tanh_eq, one_sub_tanh_eq,
    Real.log_div (ne_of_gt (Real.exp_pos x)) (ne_of_gt (Real.cosh_pos x)),
    Real.log_div (ne_of_gt (Real.exp_pos (-x))) (ne_of_gt (Real.cosh_pos x)),
    Real.log_exp, Real.log_exp]
  ring

/-- A relative interval is converted using the midpoint of its two logarithms. -/
theorem entropy_of_relative_band {β F Z η : ℝ}
    (hβ : 0 < β) (hF : 0 < F) (hη0 : 0 ≤ η) (hη1 : η < 1)
    (hband : |Z - F| ≤ η * F) :
    |(entropyFromPower β Z + Real.log (1 - η ^ 2) / (2 * β)) -
      entropyFromPower β F| ≤
      (Real.log (1 + η) - Real.log (1 - η)) / (2 * β) := by
  have hm : 0 < 1 - η := by linarith
  have hp : 0 < 1 + η := by linarith
  rcases abs_le.mp hband with ⟨hlo, hhi⟩
  have hZF : (1 - η) * F ≤ Z := by nlinarith
  have hFZ : Z ≤ (1 + η) * F := by nlinarith
  have hZ : 0 < Z := lt_of_lt_of_le (mul_pos hm hF) hZF
  have hl := Real.log_le_log (mul_pos hm hF) hZF
  have hu := Real.log_le_log hZ hFZ
  rw [Real.log_mul (ne_of_gt hm) (ne_of_gt hF)] at hl
  rw [Real.log_mul (ne_of_gt hp) (ne_of_gt hF)] at hu
  have hc : Real.log (1 - η ^ 2) = Real.log (1 - η) + Real.log (1 + η) := by
    rw [show 1 - η ^ 2 = (1 - η) * (1 + η) by ring,
      Real.log_mul (ne_of_gt hm) (ne_of_gt hp)]
  unfold entropyFromPower
  rw [hc, abs_le]
  have hd : 0 < 2 * β := by positivity
  have hll := (div_le_div_iff_of_pos_right hβ).2 hl
  have huu := (div_le_div_iff_of_pos_right hβ).2 hu
  simp only [add_div] at hll huu
  have hdiv (a : ℝ) : a / (2 * β) = (a / β) / 2 := by ring
  simp only [neg_div, add_div, sub_div, hdiv]
  constructor <;> linarith

theorem entropy_of_tanh_band {β ε F Z : ℝ}
    (hβ : 0 < β) (hε : 0 < ε) (hF : 0 < F)
    (hband : |Z - F| ≤ Real.tanh (β * ε) * F) :
    |(entropyFromPower β Z + Real.log (1 - Real.tanh (β * ε) ^ 2) / (2 * β)) -
      entropyFromPower β F| ≤ ε := by
  rcases tanh_positive_lt_one (mul_pos hβ hε) with ⟨hη0, hη1⟩
  have h := entropy_of_relative_band hβ hF hη0.le hη1 hband
  rw [log_tanh_width] at h
  have hcancel : (2 * (β * ε)) / (2 * β) = ε := by field_simp
  simpa only [hcancel] using h

/-- Define the estimate arbitrarily at nonpositive observations. -/
def logarithmicEstimate (β ε z fallback : ℝ) : ℝ :=
  if 0 < z then
    entropyFromPower β z + Real.log (1 - Real.tanh (β * ε) ^ 2) / (2 * β)
  else fallback

/-- The complete exact-accuracy certificate for a square-integrable statistic.
The only probabilistic assumptions are its stated bias and variance bounds;
the required concentration bound is derived from Mathlib's Chebyshev theorem.
-/
theorem exact_logarithmic_certificate {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (Z : Ω → ℝ)
    (hZ : MemLp Z 2 μ) {β ε F δ : ℝ}
    (hβ : 0 < β) (hε : 0 < ε) (hF : 0 < F) (fallback : ℝ)
    (hbias : |(∫ ω, Z ω ∂μ) - F| ≤ Real.tanh (β * ε) * F / 2)
    (hvar : variance Z μ ≤ δ * Real.tanh (β * ε) ^ 2 / 4 * F ^ 2) :
    μ {ω | ε < |logarithmicEstimate β ε (Z ω) fallback - entropyFromPower β F|}
      ≤ ENNReal.ofReal δ := by
  let η := Real.tanh (β * ε)
  rcases tanh_positive_lt_one (mul_pos hβ hε) with ⟨hη0, hη1⟩
  have hc : 0 < η * F / 2 := by dsimp [η]; positivity
  have hsubset :
      {ω | ε < |logarithmicEstimate β ε (Z ω) fallback - entropyFromPower β F|} ⊆
      {ω | η * F / 2 ≤ |Z ω - (∫ s, Z s ∂μ)|} := by
    intro ω hω
    by_contra h
    have hsmall : |Z ω - (∫ s, Z s ∂μ)| ≤ η * F / 2 := (lt_of_not_ge h).le
    have hband : |Z ω - F| ≤ η * F := by
      calc
        |Z ω - F| ≤ |Z ω - (∫ s, Z s ∂μ)| + |(∫ s, Z s ∂μ) - F| := abs_sub_le _ _ _
        _ ≤ η * F / 2 + η * F / 2 := add_le_add hsmall hbias
        _ = η * F := by ring
    have hpos : 0 < Z ω := by
      have hlow := (abs_le.mp hband).1
      have hpositive : 0 < (1 - η) * F := mul_pos (by dsimp [η]; linarith) hF
      nlinarith
    have hgood := entropy_of_tanh_band hβ hε hF hband
    change ε < |logarithmicEstimate β ε (Z ω) fallback - entropyFromPower β F| at hω
    rw [logarithmicEstimate, if_pos hpos] at hω
    exact (not_lt_of_ge hgood) hω
  have hcheb := meas_ge_le_variance_div_sq hZ hc
  have hratio : variance Z μ / (η * F / 2) ^ 2 ≤ δ := by
    apply (div_le_iff₀ (sq_pos_of_pos hc)).2
    dsimp [η]
    nlinarith [hvar]
  exact (measure_mono hsubset).trans (hcheb.trans (ENNReal.ofReal_le_ofReal hratio))

end Renyi
