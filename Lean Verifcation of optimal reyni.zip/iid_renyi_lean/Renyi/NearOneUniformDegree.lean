import Renyi.NearOneResidualCoefficients

/-! Constants for the actual near-one polynomial are uniform in the degree calibration. -/
noncomputable section
open Polynomial
namespace Renyi

theorem near_one_variable_tangent_compact_degree_uniform {eps cb lambda CL cmin q Q : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q) :
    ∃ lo hi : ℝ, 0<lo ∧ 0<hi ∧ ∀ (cL : ℝ), 0<cL → ∀ (k : ℕ) (alpha Ch D N c : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      N≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) →
      lo≤(c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))/
        (upperB k alpha eps D cb CL cL/N^2) ∧
      (c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))/
        (upperB k alpha eps D cb CL cL/N^2)≤hi := by
  obtain ⟨T,_,ht⟩ := near_one_overlap_time_uniform heps
  refine ⟨cmin*lambda*q^2*(3/4)*Real.exp (-T),lambda*Q^2,by positivity,by positivity,?_⟩
  intro cL hcL k alpha Ch D N c hk ha ha1 hCh hD hc hc1 hNlo hNhi
  have hc0 : 0<c := hcmin.trans_le hc
  have htime := ht k alpha Ch ha ha1 hCh
  have h := near_one_tangent_comparison hk ha ha1 hD hcb hCL hcL hc0 hlambda hq hQ
    hNlo hNhi (heps.le.trans htime.1) htime.2
  constructor
  · apply le_trans _ h.1
    exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hc hlambda.le) (sq_nonneg q))
      (by norm_num : (0:ℝ)≤3/4)) (Real.exp_pos _).le
  · apply h.2.trans
    have hh := mul_le_mul_of_nonneg_right hc1 (mul_nonneg hlambda.le (sq_nonneg Q))
    nlinarith only [hh]


theorem actual_near_one_coefficients_degree_uniform {eps cb lambda CL cmin q Q M cw f : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hf : 0≤f) (hf1 : f≤1) :
    ∃ K : ℝ, 0<K ∧ ∀ (cL : ℝ), 0<cL → ∀ (k N j : ℕ) (alpha Ch D c s0 : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) →
      0≤s0 → s0≤1 → 2≤j →
      |(actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f s0).coeff j| *
          (upperB k alpha eps D cb CL cL)^j ≤
        K*(alpha-1)*(upperB k alpha eps D cb CL cL)^alpha*
          Real.exp (K*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)) := by
  obtain ⟨Ca,hCa,ha⟩ := near_one_attenuated_amplitudes_uniform heps hM hcw hcw1
  obtain ⟨lo,hi,hlo,hhi,hratio⟩ := near_one_variable_tangent_compact_degree_uniform heps hcb hlambda hCL hcmin hq hQ
  let ML := |Real.log lo|+|Real.log hi|
  let F := nearOneCoefficientConstant ML Ca
  let d := 2+18*Real.log 9
  let K := F+d*Q+1
  have hML : 0≤ML := add_nonneg (abs_nonneg _) (abs_nonneg _)
  have hF : 0<F := nearOneCoefficientConstant_pos hML hCa.le
  have hd : 0<d := by
    dsimp [d]
    have := Real.log_nonneg (by norm_num : (1:ℝ)≤9)
    positivity
  have hK : 0<K := by dsimp [K];positivity
  have hFK : F≤K := by dsimp [K];nlinarith only [mul_pos hd hQ]
  have hdK : d*Q≤K := by dsimp [K];linarith only [hF]
  refine ⟨K,hK,?_⟩
  intro cL hcL k N j alpha Ch D c s0 hk halpha halpha1 hCh hD hc hc1 hNlo hNhi hs0 hs1 hj
  have hβ : 0<alpha-1 := sub_pos.mpr halpha
  have hβ1 : alpha-1≤1/2 := by linarith only [halpha1]
  have hg : 0<fractionalPart alpha := by rw [(near_one_order halpha halpha1).2];exact hβ
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order halpha halpha1).2];linarith only [halpha1]
  have hL := upperDegree_pos halpha hCL hcL (one_le_rootMultiplier (k:=k) (ε:=eps) halpha hg hg1)
  have hNr : 0<(N:ℝ) := (mul_pos hq hL).trans_le hNlo
  have hN : 0<N := by exact_mod_cast hNr
  have hb := upperB_pos (ε:=eps) hk halpha hg hg1 hD hcb hCL hcL
  have ht : 0<upperB k alpha eps D cb CL cL/(N:ℝ)^2 := div_pos hb (sq_pos_of_pos hNr)
  have hr := hratio cL hcL k alpha Ch D N c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
  have hτ : 0<c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1) := by
    have hh := (lt_div_iff₀ ht).mp (hlo.trans_le hr.1)
    simpa only [zero_mul] using hh
  have hlog := log_abs_of_compact hlo hr.1 hr.2
  have hid : (c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))/
      (upperB k alpha eps D cb CL cL/(N:ℝ)^2)=
      (N:ℝ)^2*((c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))/
        upperB k alpha eps D cb CL cL) := by rw [div_div_eq_mul_div];ring
  rw [hid] at hlog
  have hamp := ha k alpha Ch halpha halpha1 hCh
  have hE := upper_reserved_interval (k:=k) halpha hg hg1 heps hCh
  have hEpos : 0<upperE0 k alpha eps Ch := (mul_pos heps hβ).trans_le hE.1
  have hw : 0≤upperOmega k alpha eps Ch cw := (Real.exp_pos _).le
  have hw1 : upperOmega k alpha eps Ch cw<1 := Real.exp_lt_one_iff.mpr (by nlinarith)
  have hz := (upperOverlapZ_spec hg hg1 hEpos).1
  have hcoeff := overlap_coefficients_unit hg hg1 hz.1 hz.2
  have hA0 : 0≤overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*
      Real.exp (-M*(alpha-1)) := mul_nonneg hcoeff.1.le (Real.exp_pos _).le
  have hA1 : overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*
      Real.exp (-M*(alpha-1))≤1 :=
    (mul_le_of_le_one_left (Real.exp_pos _).le hcoeff.2.1.le).trans
      (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hβ]))
  have hbnd := nearOneCoupledPolynomial_beta_coefficients_exponential hN hj hβ hβ1 hτ hb
    hf hf1 hw hw1 hA0 hA1 hCa.le hlog hamp.1 hamp.2
  have hscaled : |(actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f s0).coeff j| *
      (upperB k alpha eps D cb CL cL)^j≤
      (upperB k alpha eps D cb CL cL)^alpha*F*(alpha-1)*Real.exp (d*(N:ℝ)) := by
    unfold actualNearOnePolynomial
    rw [coeff_C_mul,abs_mul,abs_of_nonneg hs0]
    have hs := mul_le_of_le_one_left
      (show 0≤|(nearOneCoupledPolynomial N (alpha-1)
        (c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))
        (upperB k alpha eps D cb CL cL) f (upperOmega k alpha eps Ch cw)
        (overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(alpha-1)))
        (overlapB (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(2-alpha)))).coeff j| *
        (upperB k alpha eps D cb CL cL)^j by positivity) hs1
    have hbnd' := hbnd
    rw [show 1+(alpha-1)=alpha by ring] at hbnd'
    change _≤(upperB k alpha eps D cb CL cL)^alpha*F*(alpha-1)*Real.exp (d*(N:ℝ)) at hbnd'
    nlinarith only [hs,hbnd']
  have he : Real.exp (d*(N:ℝ))≤Real.exp (K*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)) := by
    apply Real.exp_le_exp.mpr
    have h1 := mul_le_mul_of_nonneg_left hNhi hd.le
    have h2 := mul_le_mul_of_nonneg_right hdK hL.le
    nlinarith only [h1,h2]
  have hFK' := mul_le_mul_of_nonneg_left hFK (show 0≤(upperB k alpha eps D cb CL cL)^alpha*(alpha-1) by positivity)
  have hfinal := mul_le_mul hFK' he (Real.exp_pos _).le (show 0≤(upperB k alpha eps D cb CL cL)^alpha*(alpha-1)*K by positivity)
  apply hscaled.trans
  nlinarith only [hfinal]


theorem actual_near_one_affine_degree_uniform {eps cb lambda CL cmin q Q M cw f cu u0 : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hcu : 0≤cu) (hu0 : 0<u0) :
    ∃ K : ℝ, 0<K ∧ ∀ (cL : ℝ), 0<cL → ∀ (k N : ℕ) (alpha Ch D c : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) →
      let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
        (upperRescaling k alpha eps cu u0)
      let t := upperB k alpha eps D cb CL cL/(N:ℝ)^2
      |P.coeff 0|≤K*(alpha-1)*t^alpha ∧
      |P.coeff 1-t^(alpha-1)|≤K*(alpha-1)*t^(alpha-1) ∧
      |P.coeff 1|≤(K+1)*t^(alpha-1) := by
  obtain ⟨Ca,hCa,ha⟩ := near_one_attenuated_amplitudes_uniform heps hM hcw hcw1
  obtain ⟨lo,hi,hlo,_hhi,hratio⟩ := near_one_variable_tangent_compact_degree_uniform heps hcb hlambda hCL hcmin hq hQ
  let ML := |Real.log lo|+|Real.log hi|
  let F := nearOneAffineConstant ML Ca
  let K := Real.exp (2*ML)+F+2*cu+2*cw*eps+1
  have hML : 0≤ML := add_nonneg (abs_nonneg _) (abs_nonneg _)
  have hF : 0<F := by dsimp [F,nearOneAffineConstant];positivity
  have hK : 0<K := by dsimp [K];positivity
  have hK0 : Real.exp (2*ML)≤K := by
    dsimp [K]
    nlinarith only [hF,hcu,mul_pos hcw heps]
  have hK1 : F+2*cu+2*cw*eps≤K := by dsimp [K];linarith [Real.exp_pos (2*ML)]
  refine ⟨K,hK,?_⟩
  intro cL hcL k N alpha Ch D c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
  dsimp only
  let t := upperB k alpha eps D cb CL cL/(N:ℝ)^2
  let τ := c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1)
  let r := τ/t
  let A := overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(alpha-1))
  let B := overlapB (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(2-alpha))
  let ω := upperOmega k alpha eps Ch cw
  let s := upperRescaling k alpha eps cu u0
  have hβ : 0<alpha-1 := sub_pos.mpr halpha
  have hβ1 : alpha-1≤1 := by linarith only [halpha1]
  have hg : 0<fractionalPart alpha := by rw [(near_one_order halpha halpha1).2];exact hβ
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order halpha halpha1).2];linarith only [halpha1]
  have hL := upperDegree_pos halpha hCL hcL (one_le_rootMultiplier (k:=k) (ε:=eps) halpha hg hg1)
  have hNr : 0<(N:ℝ) := (mul_pos hq hL).trans_le hNlo
  have hN : 0<N := by exact_mod_cast hNr
  have hb := upperB_pos (ε:=eps) hk halpha hg hg1 hD hcb hCL hcL
  have ht : 0<t := div_pos hb (sq_pos_of_pos hNr)
  have hrange := hratio cL hcL k alpha Ch D N c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
  have hr : 0<r := hlo.trans_le hrange.1
  have hlog : |Real.log r|≤ML := log_abs_of_compact hlo hrange.1 hrange.2
  have hamp := ha k alpha Ch halpha halpha1 hCh
  have hE := upper_reserved_interval (k:=k) halpha hg hg1 heps hCh
  have hEpos : 0<upperE0 k alpha eps Ch := (mul_pos heps hβ).trans_le hE.1
  have hz := (upperOverlapZ_spec hg hg1 hEpos).1
  have hcoeff := overlap_coefficients_unit hg hg1 hz.1 hz.2
  have hA0 : 0≤A := mul_nonneg hcoeff.1.le (Real.exp_pos _).le
  have hA1 : A≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hcoeff.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hβ]))
  have hs := upperRescaling_near_one (k:=k) (eps:=eps) halpha halpha1 hcu hu0
  have hw1 : ω≤1 := (Real.exp_le_one_iff.mpr (by nlinarith only [hcw,hEpos]))
  have hwclose : |ω-1|≤(2*cw*eps)*(alpha-1) := by
    rw [abs_of_nonpos (sub_nonpos.mpr hw1)]
    have hh := (upperOmega_near_one_margins (k:=k) halpha halpha1 hg hg1 heps hCh hcw hcw1).2
    linarith only [hh]
  have hτid : t*r=τ := by dsimp [r];field_simp
  have hbid : t*(N:ℝ)^2=upperB k alpha eps D cb CL cL := by dsimp [t];field_simp
  let P := nearOneCoupledPolynomial N (alpha-1) τ (upperB k alpha eps D cb CL cL) f ω A B
  have hzero : |P.coeff 0|≤Real.exp (2*ML)*(alpha-1)*t^alpha := by
    have hh := nearOneCoupledPolynomial_constant_bound (N:=N) (f:=f) (ω:=ω) (B:=B) hβ.le hβ1 ht hr hlog hA0 hA1
    rw [hτid,hbid,show 1+(alpha-1)=alpha by ring] at hh
    exact hh
  have hone : |P.coeff 1-ω*t^(alpha-1)|≤F*(alpha-1)*t^(alpha-1) := by
    have hh := nearOneCoupledPolynomial_linear_bound (f:=f) (B:=B) hN hβ.le hβ1 ht hr hlog hA0 hA1 hamp.1
    rw [hτid,hbid] at hh
    exact hh
  have hone' := affine_rescaling_error ht hs.1.le hs.2.1 hone hs.2.2 hwclose
  have hzero' : |s*P.coeff 0|≤K*(alpha-1)*t^alpha := by
    rw [abs_mul,abs_of_nonneg hs.1.le]
    apply (mul_le_of_le_one_left (abs_nonneg _) hs.2.1).trans
    apply hzero.trans
    have hh := mul_le_mul_of_nonneg_right hK0 (show 0≤(alpha-1)*t^alpha by positivity)
    nlinarith only [hh]
  have hone'' : |s*P.coeff 1-t^(alpha-1)|≤K*(alpha-1)*t^(alpha-1) := by
    apply hone'.trans
    have hh := mul_le_mul_of_nonneg_right hK1 (show 0≤(alpha-1)*t^(alpha-1) by positivity)
    nlinarith only [hh]
  have honeabs : |s*P.coeff 1|≤(K+1)*t^(alpha-1) := by
    have hh := abs_add_le (s*P.coeff 1-t^(alpha-1)) (t^(alpha-1))
    rw [sub_add_cancel,abs_of_nonneg (Real.rpow_nonneg ht.le _)] at hh
    have hβK := mul_le_mul_of_nonneg_left hβ1 hK.le
    have hβK' := mul_le_mul_of_nonneg_right hβK (Real.rpow_nonneg ht.le (alpha-1))
    nlinarith only [hh,hone'',hβK']
  change |(C s*P).coeff 0|≤_ ∧ |(C s*P).coeff 1-t^(alpha-1)|≤_ ∧ |(C s*P).coeff 1|≤_
  simp only [coeff_C_mul]
  exact ⟨hzero',hone'',honeabs⟩


theorem actual_near_one_residual_coefficients_degree_uniform {eps cb lambda CL cmin q Q M cw f cu u0 : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hf : 0≤f) (hf1 : f≤1)
    (hcu : 0≤cu) (hu0 : 0<u0) :
    ∃ K : ℝ, 0<K ∧ ∀ (cL : ℝ), 0<cL → ∀ (k N j : ℕ) (alpha Ch D c : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) →
      let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
        (upperRescaling k alpha eps cu u0)
      let t := upperB k alpha eps D cb CL cL/(N:ℝ)^2
      |(P-C (t^(alpha-1))*X).coeff j|≤
        K*(alpha-1)*(upperB k alpha eps D cb CL cL)^(alpha-(j:ℝ))*
          Real.exp (K*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)) := by
  obtain ⟨K0,hK0,haff⟩ := actual_near_one_affine_degree_uniform (f:=f) heps hcb hlambda hCL hcmin hq hQ hM hcw hcw1 hcu hu0
  obtain ⟨K1,hK1,hhigh⟩ := actual_near_one_coefficients_degree_uniform heps hcb hlambda hCL hcmin hq hQ hM hcw hcw1 hf hf1
  refine ⟨K0+K1+1,by positivity,?_⟩
  intro cL hcL k N j alpha Ch D c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
  dsimp only
  have hβ : 0<alpha-1 := sub_pos.mpr halpha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order halpha halpha1).2];exact hβ
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order halpha halpha1).2];linarith only [halpha1]
  have hL := upperDegree_pos halpha hCL hcL (one_le_rootMultiplier (k:=k) (ε:=eps) halpha hg hg1)
  have hNr : 0<(N:ℝ) := (mul_pos hq hL).trans_le hNlo
  have hN : 0<N := by exact_mod_cast hNr
  have hN1 : (1:ℝ)≤N := by exact_mod_cast hN
  have hb := upperB_pos (ε:=eps) hk halpha hg hg1 hD hcb hCL hcL
  have ht : 0<upperB k alpha eps D cb CL cL/(N:ℝ)^2 := div_pos hb (sq_pos_of_pos hNr)
  have htb : upperB k alpha eps D cb CL cL/(N:ℝ)^2≤upperB k alpha eps D cb CL cL := by
    apply (div_le_iff₀ (sq_pos_of_pos hNr)).mpr
    nlinarith only [mul_le_mul_of_nonneg_left (show (1:ℝ)≤(N:ℝ)^2 by nlinarith only [hN1]) hb.le]
  have hs := upperRescaling_near_one (k:=k) (eps:=eps) halpha halpha1 hcu hu0
  have ha := haff cL hcL k N alpha Ch D c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
  dsimp only at ha
  have hh (j : ℕ) (hj : 2≤j) := hhigh cL hcL k N j alpha Ch D c (upperRescaling k alpha eps cu u0)
    hk halpha halpha1 hCh hD hc hc1 hNlo hNhi hs.1.le hs.2.1 hj
  have hzero : |(actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
      (upperRescaling k alpha eps cu u0)).coeff 0|≤K0*(alpha-1)*
      (upperB k alpha eps D cb CL cL/(N:ℝ)^2)^(1+(alpha-1)) := by
    simpa only [show 1+(alpha-1)=alpha by ring] using ha.1
  have hh' (j : ℕ) (hj : 2≤j) :
      |(actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
        (upperRescaling k alpha eps cu u0)).coeff j| * (upperB k alpha eps D cb CL cL)^j≤
      K1*(alpha-1)*(upperB k alpha eps D cb CL cL)^(1+(alpha-1))*
        Real.exp (K1*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)) := by
    simpa only [show 1+(alpha-1)=alpha by ring] using hh j hj
  have h := affine_residual_coefficient_budget _ hβ ht htb hL.le hK0.le hK1.le hzero ha.2.1 hh' j
  rw [show 1+(alpha-1)=alpha by ring] at h
  have hdiv := (le_div_iff₀ (pow_pos hb j)).mpr h
  apply hdiv.trans_eq
  rw [Real.rpow_sub hb,Real.rpow_natCast]
  ring


end Renyi
