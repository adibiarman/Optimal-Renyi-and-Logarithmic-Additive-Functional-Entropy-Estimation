import Renyi.LowerRootCalibration

/-! Actual root-based principal-point and perturbation constraints. This is
one lower-prior construction step, not the full minimax lower theorem. -/
noncomputable section
namespace Renyi

def lowerPriorCoefficient (ε : ℝ) : ℝ := (1-Real.exp (-ε))/16

def lowerPriorIntensityConstant (ε : ℝ) : ℝ :=
  Real.exp (lowerLogSampleConstant ε (lowerPriorCoefficient ε))

def lowerPriorRootCutoff (ε : ℝ) : ℝ :=
  max 4 (max (2/ε) (2*lowerVelocityConstant ε (lowerPriorCoefficient ε)))

theorem lowerPriorCoefficient_bounds {ε : ℝ} (hε : 0 < ε) :
    0 < lowerPriorCoefficient ε ∧ lowerPriorCoefficient ε ≤ 1/16 := by
  have hp : 0 < 1-Real.exp (-ε) :=
    sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  unfold lowerPriorCoefficient
  constructor
  · positivity
  · linarith [Real.exp_pos (-ε)]

/-- The actual root and sample intensity imply both substantive scalar
conditions of the positive-active-degree prior construction. -/
theorem lower_actual_principal_constraints_with_perturbation {k : ℕ} {α ε s ds dc : ℝ}
    (hk : 0 < k) (hα : 3/2 ≤ α) (hε : 0 < ε)
    (hs : 0 < s) (hs1 : s ≤ 1/2)
    (hγ₀ : 0 < fractionalPart α) (hγ₁ : fractionalPart α < 1)
    (hnearest : s = fractionalPart α ∨ s = 1-fractionalPart α)
    (hx : lowerPriorRootCutoff ε ≤ rootMultiplier k α ε)
    (hds : 0 < ds) (hdc : 0 < dc)
    (hdim : ds*dc ≤ α*((Nat.ceil (10*α*(1+Real.log (rootMultiplier k α ε))) : ℝ)+1)) :
    let x := rootMultiplier k α ε
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
    let bs := (ζ/8)/ds^2
    let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
    let a := θ/((1/100)*L*ac)
    let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
    0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 ∧ ρ ≤ 1 := by
  let x := rootMultiplier k α ε
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
  let bs := (ζ/8)/ds^2
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*L*ac)
  let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
  let G := 4-Real.log ((1/100 : ℝ)/8)+Real.log ((ds*dc)^2/(L*α^3*(1+Real.log x)))
  change 0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 ∧ ρ ≤ 1
  have hα1 : 1 < α := by linarith
  have hα0 : 0 < α := by linarith
  have hβ : 1/2 ≤ α-1 := by linarith
  have hβ0 : 0 < α-1 := by linarith
  have hc := (lowerPriorCoefficient_bounds hε).1
  have hC : 0 < lowerVelocityConstant ε c := by
    unfold lowerVelocityConstant
    have hd : 0 < 1-Real.exp (-ε) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
    positivity
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hxe : 2/ε ≤ x := (le_trans (le_max_left _ _) (le_max_right _ _)).trans hx
  have hxC : 2*lowerVelocityConstant ε c ≤ x :=
    (le_trans (le_max_right _ _) (le_max_right _ _)).trans hx
  have hx1 : 1 < x := by linarith
  have hx0 : 0 < x := by linarith
  have hv := lower_velocity_from_root_size hα1 hε hs hs1 hC hx4 hxe hxC
  change 0 ≤ v ∧ 4*v ≤ E ∧ w ≤ 1/2 ∧ v ≤ 1/(2*lowerVelocityConstant ε c) at hv
  have hE : ε ≤ E := by dsimp [E]; nlinarith
  have hE0 : 0 < E := hε.trans_le hE
  have hd : 0 < 1-Real.exp (-ε) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  have hdE : 0 < 1-Real.exp (-E) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  have hden : 1-Real.exp (-ε) ≤ 1-Real.exp (-E) := by
    have h := Real.exp_le_exp.mpr (neg_le_neg hE)
    linarith
  have hw0 : 0 < w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv.1
  have hζ0 : 0 < ζ := div_pos (mul_pos hc hw0) hdE
  have hζ1 : ζ ≤ 1/8 := by
    have hdiv := div_le_div_of_nonneg_left (mul_pos hc hw0).le hd hden
    change ζ ≤ c*w/(1-Real.exp (-ε)) at hdiv
    have heq : c*w/(1-Real.exp (-ε)) = w/16 := by
      dsimp [c, lowerPriorCoefficient]
      field_simp
    rw [heq] at hdiv
    linarith [hv.2.2.1]
  have hslt : s < 1 := by linarith
  have hL : 0 < L := (show 0 < 10*α*(1+Real.log x) by
    have hlog := Real.log_pos hx1
    positivity).trans_le (Nat.le_ceil _)
  have hbs : 0 < bs := by dsimp [bs]; positivity
  have hξpos : 0 < 1-s := by linarith
  have hac : 0 < ac := by dsimp [ac, κ]; positivity
  have hθ : 0 < θ := by
    dsimp [θ, lowerPriorIntensityConstant]
    exact mul_pos (mul_pos (mul_pos (Real.exp_pos _) hα0)
      (Real.rpow_pos_of_pos (by exact_mod_cast hk) _)) hx0
  have ha : 0 < a := div_pos hθ (by positivity)
  have hG : G ≤ 1000 := lower_ceiling_log_geometry hα1.le hx1.le hds hdc hdim
  have hη : (ds-1)/ds ≤ 1 := (div_le_one hds).mpr (by linarith)
  have hcal := lower_scalar_positive_degree hε hc hs hs1 hβ hE hv.1 hv.2.1
    hv.2.2.1 hη hG hv.2.2.2
  have hlog := root_principal_ratio_log hk hα1 hγ₀ hγ₁ hx1 hs hslt hnearest hζ0
    (Real.exp_pos (lowerLogSampleConstant ε c)) (by norm_num : (0 : ℝ) < 1/100) hL hds hdc
  change Real.log (a/bs) = lowerPrincipalLog s E v ζ (α-1)
    (Real.log (Real.exp (lowerLogSampleConstant ε c))) G at hlog
  rw [Real.log_exp] at hlog
  have hA : Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G) = a/bs := by
    rw [← hlog, Real.exp_log (div_pos ha hbs)]
  dsimp only at hcal
  change (Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G) ≤ 1/2) ∧
    0 ≤ max (((Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G))^s/κ)*
      Real.exp (4*ζ*((ds-1)/ds))-1) 0 ∧
    max (((Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G))^s/κ)*
      Real.exp (4*ζ*((ds-1)/ds))-1) 0 ≤ 2*lowerVelocityConstant ε c*v ∧
    max (((Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G))^s/κ)*
      Real.exp (4*ζ*((ds-1)/ds))-1) 0 *
      Real.exp (lowerPrincipalLog s E v ζ (α-1) (lowerLogSampleConstant ε c) G) ≤ ζ at hcal
  rw [hA] at hcal
  refine ⟨ha, ?_, hcal.2.1, ?_, hζ0, hζ1, ?_⟩
  · have h := (div_le_iff₀ hbs).mp hcal.1
    nlinarith
  · convert hcal.2.2.2 using 1
    ring

  · have hvC := (le_div_iff₀ (show 0 < 2*lowerVelocityConstant ε c by positivity)).mp hv.2.2.2
    have hh := hcal.2.2.1
    nlinarith only [hvC, hh]


/-- The principal constraints without the optional quantitative perturbation bound. -/
theorem lower_actual_principal_constraints {k : ℕ} {α ε s ds dc : ℝ}
    (hk : 0 < k) (hα : 3/2 ≤ α) (hε : 0 < ε)
    (hs : 0 < s) (hs1 : s ≤ 1/2)
    (hγ₀ : 0 < fractionalPart α) (hγ₁ : fractionalPart α < 1)
    (hnearest : s = fractionalPart α ∨ s = 1-fractionalPart α)
    (hx : lowerPriorRootCutoff ε ≤ rootMultiplier k α ε)
    (hds : 0 < ds) (hdc : 0 < dc)
    (hdim : ds*dc ≤ α*((Nat.ceil (10*α*(1+Real.log (rootMultiplier k α ε))) : ℝ)+1)) :
    let x := rootMultiplier k α ε
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
    let bs := (ζ/8)/ds^2
    let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
    let a := θ/((1/100)*L*ac)
    let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
    0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 := by
  have h := lower_actual_principal_constraints_with_perturbation hk hα hε hs hs1
    hγ₀ hγ₁ hnearest hx hds hdc hdim
  exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2.1, h.2.2.2.2.1, h.2.2.2.2.2.1⟩


theorem fractionalPart_nat_add_small (r : ℕ) {s : ℝ} (hs : 0 ≤ s) (hs1 : s < 1) :
    fractionalPart ((r : ℝ)+s) = s := by
  have hf : Int.floor ((r : ℝ)+s) = (r : ℤ) := by
    apply Int.floor_eq_iff.mpr
    constructor <;> push_cast <;> linarith
  unfold fractionalPart
  rw [hf]
  push_cast
  ring

/-- Actual finite priors for orders immediately above an integer at least two.
All principal-point and perturbation hypotheses are proved from the root.
The remaining lower-bound work is quantitative observation distance and
normalization, not the existence or entropy gap of these priors. -/
theorem lower_actual_positive_priors {k r : ℕ} {s ε : ℝ}
    (hk : 0 < k) (hr : 2 ≤ r) (hs : 0 < s) (hs1 : s ≤ 1/2) (hε : 0 < ε)
    (hx : lowerPriorRootCutoff ε ≤ rootMultiplier k ((r : ℝ)+s) ε) :
    let α := (r : ℝ)+s
    let x := rootMultiplier k α ε
    let L := Nat.ceil (10*α*(1+Real.log x))
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let ac := Real.exp (-5)*((1-s)/(((L-r : ℕ) : ℝ)+1)^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
    let a := θ/((1/100)*(L : ℝ)*ac)
    ∃ p₀ p₁ : FiniteAtomicPrior
        (Option ((Option (Fin ((r-1)+1))) × (Option (Fin ((L-r)+1))))),
      (∀ i, p₀.value i = 0 ∨ (1 ≤ p₀.value i ∧ p₀.value i ≤ (a*ac)⁻¹)) ∧
      (∀ i, p₁.value i = 0 ∨ (1 ≤ p₁.value i ∧ p₁.value i ≤ (a*ac)⁻¹)) ∧
      priorMoment p₀ 1 = 1 ∧ priorMoment p₁ 1 = 1 ∧
      (∀ j : ℕ, 1 ≤ j → j ≤ L+1 → j ≠ r →
        priorMoment p₁ (j : ℝ) = priorMoment p₀ (j : ℝ)) ∧
      2*ε*(α-1)+w ≤ Real.log (priorMoment p₁ α / priorMoment p₀ α) := by
  let α := (r : ℝ)+s
  let x := rootMultiplier k α ε
  let L := Nat.ceil (10*α*(1+Real.log x))
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ds : ℝ := ((r-1 : ℕ) : ℝ)+1
  let dc : ℝ := ((L-r : ℕ) : ℝ)+1
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*(L : ℝ)*ac)
  have hrR : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hα : 3/2 ≤ α := by dsimp [α]; linarith
  have hα1 : 1 < α := by linarith
  have hα0 : 0 < α := by linarith
  have hγ : fractionalPart α = s := fractionalPart_nat_add_small r hs.le (by linarith)
  have hγ₀ : 0 < fractionalPart α := by rwa [hγ]
  have hγ₁ : fractionalPart α < 1 := by rw [hγ]; linarith
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hx0 : 0 < x := by linarith
  have hlog : 0 ≤ Real.log x := Real.log_nonneg (by linarith)
  have hLlo : 10*α*(1+Real.log x) ≤ (L : ℝ) := Nat.le_ceil _
  have hLr : r ≤ L := by
    have : (r : ℝ) ≤ L := by dsimp [α] at *; nlinarith
    exact_mod_cast this
  have hds : 0 < ds := by dsimp [ds]; positivity
  have hdc : 0 < dc := by dsimp [dc]; positivity
  have hds_eq : ds = (r : ℝ) := by
    dsimp [ds]
    rw [Nat.cast_sub (by omega : 1 ≤ r)]
    push_cast
    ring
  have hdchi : dc ≤ (L : ℝ)+1 := by
    dsimp [dc]
    exact add_le_add_right (by exact_mod_cast (Nat.sub_le L r)) 1
  have hdim : ds*dc ≤ α*((L : ℝ)+1) := by
    have h1 := mul_le_mul_of_nonneg_left hdchi (by positivity : 0 ≤ ds)
    rw [hds_eq] at h1
    have h2 := mul_le_mul_of_nonneg_right (show (r : ℝ) ≤ α by dsimp [α]; linarith)
      (show 0 ≤ (L : ℝ)+1 by positivity)
    rw [hds_eq]
    exact h1.trans h2
  have hc := lowerPriorCoefficient_bounds hε
  have hβ0 : 0 < α-1 := sub_pos.mpr hα1
  have hE : 0 < E := by dsimp [E]; positivity
  have hv : 0 ≤ v := by dsimp [v]; positivity
  have hw : 0 < w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv
  have hcon := lower_actual_principal_constraints hk hα hε hs hs1 hγ₀ hγ₁
    (Or.inl hγ.symm) hx hds hdc hdim
  dsimp only at hcon
  let bs := (ζ/8)/ds^2
  let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
  change 0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 at hcon
  have hmul : 4*ζ*((ds-1)/ds) = 4*ζ*((r-1 : ℕ) : ℝ)/(((r-1 : ℕ) : ℝ)+1) := by
    dsimp [ds]
    ring
  have hpert : max (((a/bs)^s/κ)*
      Real.exp (4*ζ*((r-1 : ℕ) : ℝ)/(((r-1 : ℕ) : ℝ)+1))-1) 0 * a / bs ≤ ζ := by
    rw [← hmul]
    exact hcon.2.2.2.1
  have hresult := positive_sign_constructed_priors r L s E w c a hr hLr hs hs1 hE hw
    hc.1 (by linarith [hc.2]) hcon.2.2.2.2.2 hcon.1 hcon.2.1 hpert
  exact hresult


/-- Actual finite priors below the nearest integer, including orders in
[3/2,2). The possible moment defect is exactly the next integer. -/
theorem lower_actual_negative_priors {k m : ℕ} {s ε : ℝ}
    (hk : 0 < k) (hm : 1 ≤ m) (hs : 0 < s) (hs1 : s ≤ 1/2) (hε : 0 < ε)
    (hx : lowerPriorRootCutoff ε ≤ rootMultiplier k ((m : ℝ)+(1-s)) ε) :
    let α := (m : ℝ)+(1-s)
    let x := rootMultiplier k α ε
    let L := Nat.ceil (10*α*(1+Real.log x))
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let ac := Real.exp (-5)*((1-s)/(((m-1 : ℕ) : ℝ)+1)^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
    let a := θ/((1/100)*(L : ℝ)*ac)
    ∃ p₀ p₁ : FiniteAtomicPrior
        (Option ((Option (Fin ((m-1)+1))) × (Option (Fin ((L-m)+1))))),
      (∀ i, p₀.value i = 0 ∨ (1 ≤ p₀.value i ∧ p₀.value i ≤ (ac*a)⁻¹)) ∧
      (∀ i, p₁.value i = 0 ∨ (1 ≤ p₁.value i ∧ p₁.value i ≤ (ac*a)⁻¹)) ∧
      priorMoment p₀ 1 = 1 ∧ priorMoment p₁ 1 = 1 ∧
      (∀ j : ℕ, 1 ≤ j → j ≤ L+1 → j ≠ m+1 →
        priorMoment p₁ (j : ℝ) = priorMoment p₀ (j : ℝ)) ∧
      2*ε*(α-1)+w ≤ Real.log (priorMoment p₁ α / priorMoment p₀ α) := by
  let α := (m : ℝ)+(1-s)
  let x := rootMultiplier k α ε
  let L := Nat.ceil (10*α*(1+Real.log x))
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ds : ℝ := ((L-m : ℕ) : ℝ)+1
  let dc : ℝ := ((m-1 : ℕ) : ℝ)+1
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*(L : ℝ)*ac)
  have hmR : (1 : ℝ) ≤ m := by exact_mod_cast hm
  have hα : 3/2 ≤ α := by dsimp [α]; linarith
  have hα1 : 1 < α := by linarith
  have hα0 : 0 < α := by linarith
  have hγ : fractionalPart α = 1-s :=
    fractionalPart_nat_add_small m (by linarith) (by linarith)
  have hγ₀ : 0 < fractionalPart α := by rw [hγ]; linarith
  have hγ₁ : fractionalPart α < 1 := by rw [hγ]; linarith
  have hnear : s = 1-fractionalPart α := by rw [hγ]; ring
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hx0 : 0 < x := by linarith
  have hlog : 0 ≤ Real.log x := Real.log_nonneg (by linarith)
  have hLlo : 10*α*(1+Real.log x) ≤ (L : ℝ) := Nat.le_ceil _
  have hLm : m+1 ≤ L := by
    have : (m : ℝ)+1 ≤ L := by dsimp [α] at *; nlinarith
    exact_mod_cast this
  have hds : 0 < ds := by dsimp [ds]; positivity
  have hdc : 0 < dc := by dsimp [dc]; positivity
  have hdc_eq : dc = (m : ℝ) := by
    dsimp [dc]
    rw [Nat.cast_sub hm]
    push_cast
    ring
  have hdshi : ds ≤ (L : ℝ)+1 := by
    dsimp [ds]
    exact add_le_add_right (by exact_mod_cast (Nat.sub_le L m)) 1
  have hdim : ds*dc ≤ α*((L : ℝ)+1) := by
    have h1 := mul_le_mul_of_nonneg_right hdshi (by positivity : 0 ≤ dc)
    rw [hdc_eq] at h1
    have h2 := mul_le_mul_of_nonneg_left (show (m : ℝ) ≤ α by dsimp [α]; linarith)
      (show 0 ≤ (L : ℝ)+1 by positivity)
    rw [hdc_eq]
    exact h1.trans (by nlinarith only [h2])
  have hc := lowerPriorCoefficient_bounds hε
  have hβ0 : 0 < α-1 := sub_pos.mpr hα1
  have hE : 0 < E := by dsimp [E]; positivity
  have hv : 0 ≤ v := by dsimp [v]; positivity
  have hw : 0 < w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv
  have hcon := lower_actual_principal_constraints hk hα hε hs hs1 hγ₀ hγ₁
    (Or.inr hnear) hx hds hdc hdim
  dsimp only at hcon
  let bs := (ζ/8)/ds^2
  let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
  change 0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 at hcon
  have hmul : 4*ζ*((ds-1)/ds) = 4*ζ*((L-m : ℕ) : ℝ)/(((L-m : ℕ) : ℝ)+1) := by
    dsimp [ds]
    ring
  have hpert : max (((a/bs)^s/κ)*
      Real.exp (4*ζ*((L-m : ℕ) : ℝ)/(((L-m : ℕ) : ℝ)+1))-1) 0 * a / bs ≤ ζ := by
    rw [← hmul]
    exact hcon.2.2.2.1
  exact negative_sign_constructed_priors m L s E w c a hm hLm hs hs1 hE hw
    hc.1 (by linarith [hc.2]) hcon.2.2.2.2.2 hcon.1 hcon.2.1 hpert



set_option maxHeartbeats 1500000 in
/-- In the degree-zero active regime the apparent logarithmic singularities
cancel, and the actual perturbation vanishes. -/
theorem lower_scalar_zero_degree {ε c s E v ζ G : ℝ}
    (hε : 0 < ε) (hc : 0 < c) (hs : 0 < s) (hs1 : s ≤ 1/2)
    (hE : 0 ≤ E) (hv : 0 ≤ v) (hvs : v ≤ s/4)
    (hζ : c/2 ≤ ζ) (hG : G ≤ 1000) :
    let z := lowerPrincipalLog s E v ζ s (lowerLogSampleConstant ε c) G
    let A := Real.exp z
    let κ := Real.exp (-E-4*(s*(1-s)+v))
    A ≤ 1/2 ∧ A^s ≤ κ ∧ max (A^s/κ-1) 0 = 0 := by
  let ξ := 1-s
  let w := s*ξ+v
  let z := lowerPrincipalLog s E v ζ s (lowerLogSampleConstant ε c) G
  let A := Real.exp z
  let κ := Real.exp (-E-4*w)
  change A ≤ 1/2 ∧ A^s ≤ κ ∧ max (A^s/κ-1) 0 = 0
  have hξ : 1/2 ≤ ξ := by dsimp [ξ]; linarith
  have hξpos : 0 < ξ := by linarith
  have hξ1 : ξ ≤ 1 := by dsimp [ξ]; linarith
  have hζpos : 0 < ζ := by linarith
  have hwpos : 0 < w := add_pos_of_pos_of_nonneg (mul_pos hs hξpos) hv
  have hd : 0 < 1-Real.exp (-ε) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  have hC : 0 < lowerVelocityConstant ε c := by unfold lowerVelocityConstant; positivity
  have hD : 0 ≤ lowerPrincipalMargin ε c := by unfold lowerPrincipalMargin; positivity
  have hcoeff : 0 ≤ 1+1/ξ ∧ 1+1/ξ ≤ 3 := by
    have hh : 1/ξ ≤ 2 := (div_le_iff₀ hξpos).mpr (by linarith)
    constructor
    · positivity
    · linarith
  have hlogζ : -Real.log ζ ≤ 2/c := by
    have hratio : 1/ζ ≤ 2/c := (div_le_div_iff₀ hζpos hc).mpr (by linarith)
    have hh := Real.log_le_sub_one_of_pos (one_div_pos.mpr hζpos)
    rw [one_div, Real.log_inv] at hh
    simp only [one_div] at hratio
    linarith
  have hlogs : Real.log s ≤ 0 := Real.log_nonpos hs.le (by linarith)
  have hlogξ : Real.log ξ ≤ 0 := Real.log_nonpos hξpos.le hξ1
  have hlogsp : Real.log (s+1) ≤ s := by
    have hh := Real.log_le_sub_one_of_pos (by linarith : 0<s+1)
    linarith
  have hcancel : (1+1/ξ)*Real.log (s/ζ)+2*Real.log ((s+1)/s) =
      (s/ξ)*Real.log s+(1+1/ξ)*(-Real.log ζ)+2*Real.log (s+1) := by
    rw [Real.log_div hs.ne' hζpos.ne', Real.log_div (by linarith : s+1≠0) hs.ne']
    field_simp
    dsimp [ξ]
    ring
  have hlogterm : (1+1/ξ)*Real.log (s/ζ)+2*Real.log ((s+1)/s) ≤ 6/c+1 := by
    rw [hcancel]
    have hh := mul_le_mul_of_nonneg_left hlogζ hcoeff.1
    have hh' := mul_le_mul_of_nonneg_right hcoeff.2 (show 0≤2/c by positivity)
    have hslog : s/ξ*Real.log s ≤ 0 := mul_nonpos_of_nonneg_of_nonpos (by positivity) hlogs
    have hh2 : (1+1/ξ)*(-Real.log ζ) ≤ 6/c := by
      calc
        _ ≤ 3*(2/c) := hh.trans hh'
        _ = 6/c := by ring
    linarith only [hslog, hh2, hlogsp, hs1]
  have hwup : w ≤ 5*s/4 := by dsimp [w, ξ]; nlinarith [sq_nonneg s]
  have hvw : (v+4*w)/ξ ≤ 11*s := by
    apply (div_le_iff₀ hξpos).mpr
    nlinarith
  have hz_s : s*z+E+4*w = (v+4*w)/ξ+
      s*((1+1/ξ)*Real.log (s/ζ)+2*Real.log ((s+1)/s))+
      Real.log ξ+s*lowerLogSampleConstant ε c+s*G := by
    change s*(lowerLogSampleConstant ε c-E/s+v/(s*ξ)+4*w/ξ+
      (1+1/ξ)*Real.log (s/ζ)+Real.log ξ/s+2*Real.log ((s+1)/s)+G)+E+4*w = _
    field_simp [hs.ne', hξpos.ne']
    dsimp [ξ]
    ring
  have hpert : s*z+E+4*w ≤ -2*s := by
    rw [hz_s]
    have hl := mul_le_mul_of_nonneg_left hlogterm hs.le
    have hg := mul_le_mul_of_nonneg_left hG hs.le
    have hds := mul_nonneg hs.le hD
    have hxs : 0 ≤ s*(4*c/(1-Real.exp (-ε))) := by positivity
    unfold lowerLogSampleConstant
    nlinarith only [hl, hg, hvw, hlogξ, hds, hxs, hs.le]
  have hz : z ≤ -2 := by nlinarith
  have hA : A ≤ 1/2 := by
    calc
      A ≤ Real.exp (-2) := Real.exp_le_exp.mpr hz
      _ = 1/Real.exp 2 := by rw [Real.exp_neg, one_div]
      _ ≤ 1/2 := one_div_le_one_div_of_le (by norm_num) (by linarith [Real.add_one_le_exp 2])
  have hpow : A^s ≤ κ := by
    dsimp [A, κ]
    rw [← Real.exp_mul]
    apply Real.exp_le_exp.mpr
    nlinarith
  refine ⟨hA, hpow, ?_⟩
  apply max_eq_right
  have hκ : 0 < κ := Real.exp_pos _
  have hh : A^s/κ ≤ 1 := (div_le_one hκ).mpr hpow
  linarith



/-- The normalization scale stays uniformly positive and small near one;
the factor `s` in the numerator cancels that in the entropy scale. -/
theorem lower_near_one_zeta_bounds {ε s v : ℝ}
    (hε : 0 < ε) (hε1 : ε ≤ 1/2) (hs : 0 < s) (hs1 : s ≤ 1/2)
    (hv : 0 ≤ v) (hvs : v ≤ s/4) :
    let c := lowerPriorCoefficient ε
    let ζ := c*(s*(1-s)+v)/(1-Real.exp (-(2*ε*s)))
    c/2 ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 := by
  let c := lowerPriorCoefficient ε
  let E := 2*ε*s
  let w := s*(1-s)+v
  let d := 1-Real.exp (-E)
  let ζ := c*w/d
  change c/2 ≤ ζ ∧ 0<ζ ∧ ζ≤1/8
  have hc : 0 < c := (lowerPriorCoefficient_bounds hε).1
  have hcε : c ≤ ε/16 := by
    have hh := Real.add_one_le_exp (-ε)
    dsimp [c, lowerPriorCoefficient]
    linarith
  have hE : 0 < E := by dsimp [E]; positivity
  have hEs : E ≤ s := by dsimp [E]; nlinarith
  have hE1 : E ≤ 1 := by linarith
  have hd : 0 < d := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  have hdE : d ≤ E := by
    have hh := Real.add_one_le_exp (-E)
    dsimp [d]
    linarith
  have hwd : d/2 ≤ w := by dsimp [w]; nlinarith
  have hw : 0 < w := by dsimp [w]; nlinarith
  have hwup : w ≤ 5*s/4 := by dsimp [w]; nlinarith [sq_nonneg s]
  have hexp : (1+E)*Real.exp (-E) ≤ 1 := by
    have hh := mul_le_mul_of_nonneg_right (Real.add_one_le_exp E) (Real.exp_nonneg (-E))
    rw [← Real.exp_add] at hh
    simpa only [add_neg_cancel, Real.exp_zero, add_comm E 1] using hh
  have hdlo : E/2 ≤ d := by
    have hh := mul_le_mul_of_nonneg_left hE1 hd.le
    dsimp [d] at *
    nlinarith only [hexp, hh]
  have hζ : 0 < ζ := div_pos (mul_pos hc hw) hd
  refine ⟨?_, hζ, ?_⟩
  · apply (le_div_iff₀ hd).mpr
    nlinarith [mul_le_mul_of_nonneg_left hwd hc.le]
  · apply (div_le_iff₀ hd).mpr
    have hh := mul_le_mul hcε hwup hw.le (show 0≤ε/16 by positivity)
    dsimp [E] at hdlo
    nlinarith only [hh, hdlo, mul_pos hε hs]

/-- All scalar conditions for the unperturbed near-one prior follow from
the actual root and sample-intensity rule. -/
theorem lower_actual_zero_degree_constraints {k : ℕ} {s ε : ℝ}
    (hk : 0 < k) (hs : 0 < s) (hs1 : s ≤ 1/2)
    (hε : 0 < ε) (hε1 : ε ≤ 1/2)
    (hx : lowerPriorRootCutoff ε ≤ rootMultiplier k (1+s) ε) :
    let α := 1+s
    let x := rootMultiplier k α ε
    let c := lowerPriorCoefficient ε
    let E := 2*ε*s
    let v := s/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
    let bs := ζ/8
    let ac := Real.exp (-5)*((1-s)/L^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
    let a := θ/((1/100)*L*ac)
    0<a ∧ a≤bs/2 ∧ a^s≤κ ∧ 0<ζ ∧ ζ≤1/8 := by
  let α := 1+s
  let x := rootMultiplier k α ε
  let c := lowerPriorCoefficient ε
  let E := 2*ε*s
  let v := s/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
  let bs := ζ/8
  let ac := Real.exp (-5)*((1-s)/L^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*L*ac)
  let G := 4-Real.log ((1/100 : ℝ)/8)+Real.log ((1*L)^2/(L*α^3*(1+Real.log x)))
  change 0<a ∧ a≤bs/2 ∧ a^s≤κ ∧ 0<ζ ∧ ζ≤1/8
  have hα1 : 1<α := by dsimp [α]; linarith
  have hα0 : 0<α := by linarith
  have hx4 : 4≤x := (le_max_left _ _).trans hx
  have hx1 : 1<x := by linarith
  have hx0 : 0<x := by linarith
  have hL : 0<L := (show 0<10*α*(1+Real.log x) by
    have hh := Real.log_pos hx1
    positivity).trans_le (Nat.le_ceil _)
  have hc := (lowerPriorCoefficient_bounds hε).1
  have hγ : fractionalPart α=s := by
    simpa only [α, Nat.cast_one] using fractionalPart_nat_add_small 1 hs.le (by linarith : s<1)
  have hv : 0≤v := by dsimp [v]; positivity
  have hvs : v≤s/4 := by
    have hp : x^(-α)≤1/x := by
      simpa only [Real.rpow_neg_one, one_div] using
        Real.rpow_le_rpow_of_exponent_le hx1.le (neg_le_neg hα1.le)
    have hf : s/α≤s := div_le_self hs.le hα1.le
    have hxinv : 1/x≤1/4 := one_div_le_one_div_of_le (by norm_num) hx4
    calc
      v≤s*(1/x) := mul_le_mul hf hp (Real.rpow_nonneg hx0.le _) hs.le
      _≤s*(1/4) := mul_le_mul_of_nonneg_left hxinv hs.le
      _=s/4 := by ring
  have hzeta := lower_near_one_zeta_bounds hε hε1 hs hs1 hv hvs
  change c/2≤ζ ∧ 0<ζ ∧ ζ≤1/8 at hzeta
  have hζpos : 0<ζ := hzeta.2.1
  have hbs : 0<bs := by dsimp [bs]; positivity
  have hbs1 : bs≤1 := by dsimp [bs]; linarith [hzeta.2.2]
  have hξ : 0<1-s := by linarith
  have hac : 0<ac := by dsimp [ac, κ]; positivity
  have hθ : 0<θ := by
    dsimp [θ, lowerPriorIntensityConstant]
    exact mul_pos (mul_pos (mul_pos (Real.exp_pos _) hα0)
      (Real.rpow_pos_of_pos (by exact_mod_cast hk) _)) hx0
  have ha : 0<a := div_pos hθ (by positivity)
  have hdim : 1*L≤α*(L+1) := by nlinarith
  have hG : G≤1000 := lower_ceiling_log_geometry hα1.le hx1.le (by norm_num) hL hdim
  have hcal := lower_scalar_zero_degree hε hc hs hs1 (show 0≤E by dsimp [E]; positivity)
    hv hvs hzeta.1 hG
  have hlog := root_principal_ratio_log hk hα1 (by rwa [hγ])
    (show fractionalPart α<1 by rw [hγ]; linarith) hx1 hs (by linarith)
    (Or.inl hγ.symm) hzeta.2.1
    (Real.exp_pos (lowerLogSampleConstant ε c)) (by norm_num : (0:ℝ)<1/100)
    hL (by norm_num : (0:ℝ)<1) hL
  have hβ : α-1=s := by dsimp [α]; ring
  simp only [hβ, one_pow, div_one, Real.log_exp] at hlog
  change Real.log (a/bs)=lowerPrincipalLog s E v ζ s (lowerLogSampleConstant ε c) G at hlog
  dsimp only at hcal
  have hA : Real.exp (lowerPrincipalLog s E v ζ s (lowerLogSampleConstant ε c) G)=a/bs := by
    rw [←hlog, Real.exp_log (div_pos ha hbs)]
  rw [hA] at hcal
  refine ⟨ha, ?_, ?_, hzeta.2.1, hzeta.2.2⟩
  · have hh := (div_le_iff₀ hbs).mp hcal.1
    nlinarith
  · apply le_trans _ hcal.2.1
    apply Real.rpow_le_rpow ha.le _ hs.le
    exact (le_div_iff₀ hbs).mpr (mul_le_of_le_one_right ha.le hbs1)



set_option linter.unusedSimpArgs false in
open scoped BigOperators in
/-- The active degree-zero factor has exactly one negative atom. -/
theorem zero_degree_negative_mass {a s : ℝ} (ha : 0<a) :
    ∑ i, negativeCoeff (normalizedInterpolation (fun _ : Fin 1 => (1:ℝ)) a 0 s i)=a^s := by
  have hp : 0<a^(-s) := Real.rpow_pos_of_pos ha _
  have hn : interpolationNormalizer (fun _ : Fin 1 => (1:ℝ)) a 0 s=a^(-s) := by
    simp [interpolationNormalizer, positiveAtomicMass, weightedInterpolation, interpolationWeights,
      interpolationNodes, lagrangeWeight, Lagrange.basis, max_eq_left hp.le]
  have hnone : normalizedInterpolation (fun _ : Fin 1 => (1:ℝ)) a 0 s none=1 := by
    simp [normalizedInterpolation, hn, weightedInterpolation, interpolationWeights, interpolationNodes, hp.ne']
  have hsome : normalizedInterpolation (fun _ : Fin 1 => (1:ℝ)) a 0 s (some 0)= -(a^s) := by
    simp only [normalizedInterpolation, hn, weightedInterpolation, interpolationWeights, interpolationNodes,
      Option.elim_some, zero_mul, zero_div, add_zero, mul_one, Real.one_rpow]
    have hl : lagrangeWeight (fun _ : Fin 1 => (1:ℝ)) a 0=1 := by simp [lagrangeWeight, Lagrange.basis]
    rw [hl, neg_div, one_div, Real.rpow_neg ha.le, inv_inv]
  rw [Fintype.sum_option, Fin.sum_univ_one, hnone, hsome]
  simp [negativeCoeff, max_eq_left (Real.rpow_pos_of_pos ha s).le]


open scoped BigOperators in
/-- Near order one, the active factor is unperturbed and all moments through
`L+1` match exactly. Its entropy gap is obtained from the actual parity masses. -/
theorem zero_degree_constructed_priors (L : ℕ) (s E w c a : ℝ)
    (hL : 1≤L) (hs : 0<s) (hs1 : s≤1/2)
    (hE : 0<E) (hw : 0<w) (hc : 0<c) (hc1 : c≤1/2)
    (hζ1 : c*w/(1-Real.exp (-E))≤1/8) (ha : 0<a) (ha1 : a<1)
    (has : a^s≤Real.exp (-E-4*w)) :
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let ac := Real.exp (-5)*((1-s)/(L:ℝ)^2)*(ζ*κ)^(1/(1-s))
    ∃ p₀ p₁ : FiniteAtomicPrior (Option ((Option (Fin 1)) × (Option (Fin ((L-1)+1))))),
      (∀ i, p₀.value i=0 ∨ (1≤p₀.value i ∧ p₀.value i≤(a*ac)⁻¹)) ∧
      (∀ i, p₁.value i=0 ∨ (1≤p₁.value i ∧ p₁.value i≤(a*ac)⁻¹)) ∧
      priorMoment p₀ 1=1 ∧ priorMoment p₁ 1=1 ∧
      (∀ j : ℕ, 1≤j → j≤L+1 → priorMoment p₁ (j:ℝ)=priorMoment p₀ (j:ℝ)) ∧
      E+w≤Real.log (priorMoment p₁ (1+s)/priorMoment p₀ (1+s)) := by
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ξ := 1-s
  let nc := L-1
  let bc := ξ/((nc:ℝ)+1)^2
  let ac := Real.exp (-5)*bc*(ζ*κ)^(1/ξ)
  have hLcast : ((nc:ℝ)+1)=(L:ℝ) := by
    dsimp [nc]
    rw [Nat.cast_sub hL]
    push_cast
    ring
  change ∃ p₀ p₁ : FiniteAtomicPrior (Option ((Option (Fin 1)) × (Option (Fin ((L-1)+1))))), _
  have hζ : 0<ζ := div_pos (mul_pos hc hw) (sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith)))
  have hκ : 0<κ := Real.exp_pos _
  have hκ1 : κ≤1 := Real.exp_le_one_iff.mpr (by linarith)
  have hξ : 1/2≤ξ := by dsimp [ξ]; linarith
  have hξ0 : 0<ξ := by linarith
  have hξ1 : ξ<1 := by dsimp [ξ]; linarith
  have hz : 0<ζ*κ := mul_pos hζ hκ
  have hz1 : ζ*κ≤1 := by nlinarith [mul_le_mul_of_nonneg_left hκ1 hζ.le]
  have hbc : 0<bc := by dsimp [bc]; positivity
  have hbc1 : bc<1 := by
    apply (div_lt_one (by positivity : 0<((nc:ℝ)+1)^2)).mpr
    nlinarith [show (0:ℝ)≤nc from Nat.cast_nonneg nc]
  have hac : 0<ac := by dsimp [ac]; positivity
  have hacbc : ac<bc := by
    have hp := Real.rpow_le_one hz.le hz1 (by positivity : 0≤1/ξ)
    have hh := mul_le_mul_of_nonneg_left hp (mul_nonneg (Real.exp_nonneg (-5)) hbc.le)
    have he := Real.exp_lt_one_iff.mpr (show (-5:ℝ)<0 by norm_num)
    dsimp [ac]
    nlinarith
  let us := fun _ : Fin 1 => (1:ℝ)
  let uc := chebyshevNode nc bc
  let l := normalizedInterpolation us a 0 s
  let t := normalizedInterpolation uc ac 0 ξ
  let U := interpolationNodes us a
  let V := interpolationNodes uc ac
  let Rs := ∑ i, negativeCoeff (l i)
  let Rc := ∑ i, negativeCoeff (t i)
  have hus : Function.Injective us := Function.injective_of_subsingleton _
  have huc : Function.Injective uc := chebyshevNode_injective nc bc hbc1
  have hau : ∀ i, a<us i := fun _ => ha1
  have hacu : ∀ i, ac<uc i := fun i => hacbc.trans_le (chebyshevNode_bounds nc bc hbc1.le i).1
  have hRs : Rs≤κ := by
    change (∑ i, negativeCoeff (normalizedInterpolation (fun _ : Fin 1 => (1:ℝ)) a 0 s i))≤κ
    rw [zero_degree_negative_mass ha]
    exact has
  have hRc : Rc≤ζ*κ := by
    have hh := (chebyshev_nodes_weighted nc ξ (ζ*κ) hξ hξ1 hz hz1).1
    have he : Real.exp (-ξ)≤1 := Real.exp_le_one_iff.mpr (by linarith)
    exact hh.trans (by simpa only [one_mul] using mul_le_mul_of_nonneg_right he hz.le)
  have hRs0 : 0≤Rs := Finset.sum_nonneg (fun _ _ => le_max_right _ _)
  have hRc0 : 0≤Rc := Finset.sum_nonneg (fun _ _ => le_max_right _ _)
  have hRcpos : 0<Rc := normalizedInterpolation_negative_mass_pos uc
    (chebyshevNode_strictMono nc bc hbc1) hac hacu (by norm_num)
  have hR : 0<Rs+Rc := add_pos_of_nonneg_of_pos hRs0 hRcpos
  have hgap := calibrated_parity_entropy_gap hE hw hc.le hc1 hζ1 hRs0 hRc0 hRs hRc hR
  have hl : ∑ i, positiveCoeff (l i)=1 := normalizedInterpolation_positive_mass us ha (by norm_num)
  have ht : ∑ i, positiveCoeff (t i)=1 := normalizedInterpolation_positive_mass uc hac (by norm_num)
  have hUa : ∀ i, a≤U i := by
    intro i
    cases i with
    | none => exact le_rfl
    | some i => exact (hau i).le
  have hU1 : ∀ i, U i≤1 := by
    intro i
    cases i with
    | none => exact ha1.le
    | some i => exact le_rfl
  have hVac : ∀ i, ac≤V i := by
    intro i
    cases i with
    | none => exact le_rfl
    | some i => exact (hacu i).le
  have hV1 : ∀ i, V i≤1 := by
    intro i
    cases i with
    | none => exact (hacbc.trans hbc1).le
    | some i => exact (chebyshevNode_bounds nc bc hbc1.le i).2
  have hmean : (∑ i, l i*U i^((1:ℝ)+s-1))*(∑ j, t j*V j^(1-((1:ℝ)+s)))=0 := by
    have hz := low_integer_factor_zero (m:=1) us hus (ρ:=0) (γ:=s) ha hau 1
      (by norm_num) (by norm_num) (Or.inr rfl)
    simp only [Nat.cast_one] at hz
    change (∑ i, l i*U i^((1:ℝ)+s-1))=0 at hz
    rw [hz, zero_mul]
  obtain ⟨_, p₀, p₁, hp₀, hp₁, hm₀, hm₁, hdiff, _, _, hlog⟩ :=
    tensor_priors l t U V (show 1<1+s by linarith) ha hac hUa hU1 hVac hV1 hl ht rfl rfl hR hmean
  have hac_eq : ac=Real.exp (-5)*((1-s)/(L:ℝ)^2)*(ζ*κ)^(1/(1-s)) := by
    dsimp only [ac, bc, ξ]
    rw [hLcast]
  refine ⟨p₀, p₁, ?_, ?_, hm₀, hm₁, ?_, ?_⟩
  · rw [hac_eq] at hp₀
    exact hp₀
  · rw [hac_eq] at hp₁
    exact hp₁
  · intro j hj1 hjL
    have hj : (0:ℝ)<j := by exact_mod_cast (show 0<j by omega)
    have hd := hdiff (j:ℝ) hj
    have hz := noninteger_tensor_factor_cancellation (m:=1) (L:=L) us uc hus huc
      (ρl:=0) (ρr:=0) (γ:=s) ha hac hau hacu j hj1 hjL (Or.inr rfl) (Or.inr rfl)
    simp only [Nat.cast_one] at hz
    change (∑ i, l i*(U i/a)^((1:ℝ)+s-(j:ℝ)))*(∑ v, t v*V v^((j:ℝ)-((1:ℝ)+s)))=0 at hz
    rw [hz, mul_zero] at hd
    exact sub_eq_zero.mp hd
  · rw [hlog]
    exact hgap



/-- Actual near-one priors at the common root/sample rule. There are no
unmatched moments in this case. -/
theorem lower_actual_near_one_priors {k : ℕ} {s ε : ℝ}
    (hk : 0<k) (hs : 0<s) (hs1 : s≤1/2) (hε : 0<ε) (hε1 : ε≤1/2)
    (hx : lowerPriorRootCutoff ε≤rootMultiplier k (1+s) ε) :
    let α := 1+s
    let x := rootMultiplier k α ε
    let L := Nat.ceil (10*α*(1+Real.log x))
    let c := lowerPriorCoefficient ε
    let E := 2*ε*s
    let v := s/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let ac := Real.exp (-5)*((1-s)/(L:ℝ)^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
    let a := θ/((1/100)*(L:ℝ)*ac)
    ∃ p₀ p₁ : FiniteAtomicPrior (Option ((Option (Fin 1)) × (Option (Fin ((L-1)+1))))),
      (∀ i, p₀.value i=0 ∨ (1≤p₀.value i ∧ p₀.value i≤(a*ac)⁻¹)) ∧
      (∀ i, p₁.value i=0 ∨ (1≤p₁.value i ∧ p₁.value i≤(a*ac)⁻¹)) ∧
      priorMoment p₀ 1=1 ∧ priorMoment p₁ 1=1 ∧
      (∀ j : ℕ, 1≤j → j≤L+1 → priorMoment p₁ (j:ℝ)=priorMoment p₀ (j:ℝ)) ∧
      2*ε*(α-1)+w≤Real.log (priorMoment p₁ α/priorMoment p₀ α) := by
  let α := 1+s
  let x := rootMultiplier k α ε
  let L := Nat.ceil (10*α*(1+Real.log x))
  let c := lowerPriorCoefficient ε
  let E := 2*ε*s
  let v := s/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ac := Real.exp (-5)*((1-s)/(L:ℝ)^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
  let a := θ/((1/100)*(L:ℝ)*ac)
  have hcon := lower_actual_zero_degree_constraints hk hs hs1 hε hε1 hx
  change 0<a ∧ a≤(ζ/8)/2 ∧ a^s≤κ ∧ 0<ζ ∧ ζ≤1/8 at hcon
  have hx4 : 4≤x := (le_max_left _ _).trans hx
  have hα : 1≤α := by dsimp [α]; linarith
  have hlog : 0≤Real.log x := Real.log_nonneg (by linarith)
  have hL : 1≤L := by
    have hh : (1:ℝ)≤L := by
      have hh := Nat.le_ceil (10*α*(1+Real.log x))
      change 10*α*(1+Real.log x)≤(L:ℝ) at hh
      nlinarith
    exact_mod_cast hh
  have hc := lowerPriorCoefficient_bounds hε
  have hE : 0<E := by dsimp [E]; positivity
  have hα0 : 0<α := by linarith
  have hx0 : 0<x := by linarith
  have hv : 0≤v := by dsimp [v]; positivity
  have hw : 0<w := by dsimp [w]; nlinarith
  have ha1 : a<1 := by linarith [hcon.2.1, hcon.2.2.2.2]
  have hresult := zero_degree_constructed_priors L s E w c a hL hs hs1 hE hw hc.1
    (by linarith [hc.2]) hcon.2.2.2.2 hcon.1 ha1 hcon.2.2.1
  simpa only [E, add_sub_cancel_left] using hresult

end Renyi
