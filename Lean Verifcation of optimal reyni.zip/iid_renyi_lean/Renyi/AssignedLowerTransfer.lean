import Renyi.CorrectedLowerTransfer

/-! The lower deterministic transfer permits a realized heavy aggregate. -/
noncomputable section
namespace Renyi

lemma assigned_corrected_lower_margin_transfer {P PL PH B Bt QL VH err e kappa u u0 r base kappa0
    cb cg r0 sH chi : ℝ}
    (hP : P=PL+PH) (hPL : 0≤PL) (hPH : 0≤PH) (hB0 : 0≤B) (hBt : 0≤Bt)
    (herr : 0≤err) (he : err≤e) (hkappa : 0≤kappa) (hkappa1 : kappa≤1) (hk0 : kappa≤kappa0)
    (hu : 0≤u) (hu0 : u≤u0) (hr0 : 0<r0) (hr : r0≤r) (hr1 : r≤1)
    (hcb : 0<cb) (hcg : 0<cg) (hsH : 0<sH) (_hchi : 0≤chi) (hchi1 : chi≤1)
    (hbase : kappa+cb*kappa*u≤r*base)
    (hmean : base*PL+cg*kappa0*Bt≤QL+err)
    (hheavy : kappa*PH+sH*kappa*PH≤r*VH)
    (hB : B≤Bt+PH+err) :
    let c := min (1/2:ℝ) (min cb (min (r0*cg) (sH/(1+u0))))
    kappa*P+c*(e+kappa*u*P+chi*kappa*B)≤r*(QL+VH)+2*e := by
  dsimp only
  let c := min (1/2:ℝ) (min cb (min (r0*cg) (sH/(1+u0))))
  have hu00 : 0≤u0 := hu.trans hu0
  have hc : 0≤c := (lt_min (by norm_num) (lt_min hcb (lt_min (mul_pos hr0 hcg) (by positivity)))).le
  have hc2 : c≤1/2 := min_le_left _ _
  have hccb : c≤cb := (min_le_right _ _).trans (min_le_left _ _)
  have hccg : c≤r0*cg := ((min_le_right _ _).trans (min_le_right _ _)).trans (min_le_left _ _)
  have hcsH : c≤sH/(1+u0) := ((min_le_right _ _).trans (min_le_right _ _)).trans (min_le_right _ _)
  have hrpos : 0≤r := hr0.le.trans hr
  have he0 : 0≤e := herr.trans he
  have hmain := mul_le_mul_of_nonneg_left hmean hrpos
  have hb := mul_le_mul_of_nonneg_right hbase hPL
  have hg0 : r0*cg*kappa≤r*cg*kappa0 := by
    exact mul_le_mul (mul_le_mul_of_nonneg_right hr hcg.le) hk0 hkappa (mul_nonneg hrpos hcg.le)
  have hg := mul_le_mul_of_nonneg_right hg0 hBt
  have heR := mul_le_of_le_one_left herr hr1
  have hreg := mul_le_mul_of_nonneg_right hccb (mul_nonneg (mul_nonneg hkappa hu) hPL)
  have hbonus := mul_le_mul_of_nonneg_right hccg (mul_nonneg hkappa hBt)
  have hBχ := mul_le_of_le_one_left hB0 hchi1
  have hB' := mul_le_mul_of_nonneg_left (hBχ.trans hB) (mul_nonneg hc hkappa)
  have hbudget : c*(1+u)≤sH := by
    have hh := (le_div_iff₀ (by positivity : 0<1+u0)).mp hcsH
    have hh' := mul_le_mul_of_nonneg_left hu0 hc
    nlinarith only [hh,hh']
  have hbudget' := mul_le_mul_of_nonneg_right hbudget (mul_nonneg hkappa hPH)
  have heC := mul_le_mul_of_nonneg_right hc2 he0
  have heκ := mul_le_mul_of_nonneg_left (mul_le_of_le_one_left herr hkappa1) hc
  have heCerr := (mul_le_mul_of_nonneg_left he hc).trans heC
  change kappa*P+c*(e+kappa*u*P+chi*kappa*B)≤_
  rw [hP]
  nlinarith only [hmain,hb,hg,heR,hreg,hbonus,hB',hbudget',heC,heκ,heCerr,he,hheavy]

end Renyi
