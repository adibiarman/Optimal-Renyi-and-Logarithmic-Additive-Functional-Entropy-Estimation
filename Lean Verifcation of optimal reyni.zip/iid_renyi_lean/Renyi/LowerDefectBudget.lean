import Renyi.LowerCountCalibration
import Renyi.LowerActivation
import Renyi.OneDefect
import Mathlib.Analysis.Complex.ExponentialBounds

/-! Uniform numerical absorption of the activated defect term. -/
noncomputable section
namespace Renyi

/-- The factorial removes the integer-order growth in the sample intensity. -/
theorem lower_factorial_order_bound {r : ℕ} {α : ℝ}
    (hr : 2≤r) (hα : 0≤α) (hαr : α≤(r:ℝ)+1/2) :
    (2:ℝ)^r*α^r/(r.factorial:ℝ)≤Real.exp (3*r) := by
  have hr0 : 0<r := by omega
  have hrR : (2:ℝ)≤r := by exact_mod_cast hr
  have hrpos : (0:ℝ)<r := by exact_mod_cast hr0
  have hfac := reciprocal_factorial_le_exp r hr0
  have hh := mul_le_mul_of_nonneg_left hfac (show 0≤(2:ℝ)^r*α^r by positivity)
  have hbase : 2*α*Real.exp 1/(r:ℝ)≤Real.exp 3 := by
    have har : 2*α/(r:ℝ)≤3 := (div_le_iff₀ hrpos).mpr (by linarith)
    have hh := mul_le_mul_of_nonneg_right har (Real.exp_nonneg 1)
    have he : 3≤Real.exp 2 := by have h := Real.add_one_le_exp (2:ℝ); linarith
    have hh' := mul_le_mul_of_nonneg_right he (Real.exp_nonneg 1)
    rw [←Real.exp_add] at hh'
    norm_num at hh'
    convert hh.trans hh' using 1
    ring
  calc
    _≤(2*α*Real.exp 1/(r:ℝ))^r := by
      simpa only [div_pow,mul_pow,mul_one_div,mul_div_assoc] using hh
    _≤(Real.exp 3)^r := pow_le_pow_left₀ (by positivity) hbase r
    _=Real.exp (3*r) := by rw [←Real.exp_nat_mul]; congr 1; ring

/-- The selected sample constant absorbs the explicit defect envelope. -/
theorem lower_actual_defect_constant {ε : ℝ} (hε : 0<ε) :
    let c := lowerPriorCoefficient ε
    let cn := lowerPriorIntensityConstant ε
    cn*Real.exp ((20+2/c)+23)≤1/(8*((441*Real.exp 1/c)+1)) := by
  let c := lowerPriorCoefficient ε
  have hc : 0<c := (lowerPriorCoefficient_bounds hε).1
  have hc1 : c≤1 := (lowerPriorCoefficient_bounds hε).2.trans (by norm_num)
  have hd : 0<1-Real.exp (-ε) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  have hlog : lowerLogSampleConstant ε c≤ -1000-26/c := by
    have hC : lowerVelocityConstant ε c=41/4 := by
      dsimp [lowerVelocityConstant,c,lowerPriorCoefficient]
      field_simp
      ring
    have hdC : 4*c/(1-Real.exp (-ε))=1/4 := by
      dsimp [c,lowerPriorCoefficient]
      field_simp
      ring
    unfold lowerLogSampleConstant lowerPrincipalMargin
    rw [hC,hdC]
    have hi : 0<1/c := by positivity
    field_simp at *
    nlinarith
  have hexp : lowerPriorIntensityConstant ε*Real.exp ((20+2/c)+23)≤Real.exp (-11-12/c) := by
    unfold lowerPriorIntensityConstant
    rw [←Real.exp_add]
    apply Real.exp_le_exp.mpr
    change lowerLogSampleConstant ε c+(20+2/c+23)≤ -11-12/c
    have hpos : 0<1/c := by positivity
    have hid : 26/c=26*(1/c) := by ring
    have hid2 : 2/c=2*(1/c) := by ring
    have hid12 : 12/c=12*(1/c) := by ring
    rw [hid] at hlog
    rw [hid2,hid12]
    linarith
  have he1 : Real.exp 1≤3 := le_of_lt (Real.exp_one_lt_d9.trans (by norm_num))
  have he11 : (2048:ℝ)≤Real.exp 11 := by
    have he : (2:ℝ)≤Real.exp 1 := by have h := Real.add_one_le_exp (1:ℝ); linarith
    have hh := pow_le_pow_left₀ (by norm_num : (0:ℝ)≤2) he 11
    norm_num at hh
    exact hh
  have hefrac : 1+12/c≤Real.exp (12/c) := by simpa only [add_comm] using Real.add_one_le_exp (12/c)
  have hden : 8*(441*Real.exp 1/c+1)≤Real.exp (11+12/c) := by
    have hh := mul_le_mul he11 hefrac (by positivity) (Real.exp_nonneg 11)
    rw [←Real.exp_add] at hh
    have he := div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left he1 (by norm_num : (0:ℝ)≤441)) hc.le
    have hi : (1:ℝ)≤1/c := (le_div_iff₀ hc).mpr (by simpa only [one_mul] using hc1)
    have he' : 441*Real.exp 1/c≤1323*(1/c) := by convert he using 1; ring
    have heq : (1+12/c)=1+12*(1/c) := by ring
    rw [heq] at hh
    nlinarith only [hh,he',hi]
  change lowerPriorIntensityConstant ε*Real.exp ((20+2/c)+23)≤_
  apply hexp.trans
  rw [show -11-12/c= -(11+12/c) by ring,Real.exp_neg]
  simpa only [one_div] using one_div_le_one_div_of_le (by positivity : 0<8*(441*Real.exp 1/c+1)) hden

/-- All alphabet dependence in the activated defect term is absorbed by
its exact root correction and the factorial order estimate. -/
theorem lower_defect_term_bound {k α x cn c ζ ρ D C : ℝ} {r : ℕ}
    (hk : 0<k) (hα : 1<α) (hx : 0<x) (hcn : 0<cn) (hc : 0<c) (hζ : 0<ζ)
    (hr : 2≤r) (hαr : α≤(r:ℝ)+1/2) (hρ : 0≤ρ) (hD : 0≤D)
    (hρv : ρ≤(41/2)*((α-1)/α*x^(-α)))
    (hvζ : ((α-1)/α*x^(-α))/ζ≤1/c)
    (hDbound : D≤Real.exp (C*r)/ζ)
    (hcorrection : (k*x^(-α))^((α-(r:ℝ))/α)≤Real.exp (20*r)) :
    let θ := cn*α*k^(-1/α)*x
    k*((2:ℝ)^r/(Real.exp (-1)*(r.factorial:ℝ)))*θ^r*ρ^2*D ≤
      (441*Real.exp 1/c)*(cn*Real.exp (C+23))^r := by
  let θ := cn*α*k^(-1/α)*x
  let v := (α-1)/α*x^(-α)
  let q := (k*x^(-α))^((α-(r:ℝ))/α)
  have hα0 : 0<α := by linarith
  have hβ : 0<α-1 := by linarith
  have hv : 0≤v := by dsimp [v]; positivity
  have hθ : 0<θ := by dsimp [θ]; positivity
  have hq : 0≤q := by dsimp [q]; positivity
  have hfac : (0:ℝ)<r.factorial := by positivity
  have hαratio : 0≤(α-1)/α := by positivity
  have hαratio1 : (α-1)/α≤1 := (div_le_one hα0).mpr (by linarith)
  have hρsquare : ρ^2≤441*v^2 := by
    have hρ21 : ρ≤21*v := by change ρ≤(41/2)*v at hρv; linarith
    have hh := pow_le_pow_left₀ hρ hρ21 2
    nlinarith only [hh]
  have hscale := lower_defect_scale_identity (cn:=cn) r hk hα0 hx
  change k*θ^r*v^2=(cn*α)^r*((α-1)/α)*v*q at hscale
  have hfactor := lower_factorial_order_bound hr hα0.le hαr
  change k*((2:ℝ)^r/(Real.exp (-1)*(r.factorial:ℝ)))*θ^r*ρ^2*D≤_
  calc
    _≤k*((2:ℝ)^r/(Real.exp (-1)*(r.factorial:ℝ)))*θ^r*(441*v^2)*D := by gcongr
    _=441*Real.exp 1*((2:ℝ)^r*α^r/(r.factorial:ℝ))*cn^r*((α-1)/α)*v*D*q := by
      calc
        _=441*((2:ℝ)^r/(Real.exp (-1)*(r.factorial:ℝ)))*D*(k*θ^r*v^2) := by ring
        _=_ := by rw [hscale,mul_pow,Real.exp_neg]; field_simp
    _≤441*Real.exp 1*((2:ℝ)^r*α^r/(r.factorial:ℝ))*cn^r*((α-1)/α)*v*(Real.exp (C*r)/ζ)*q := by gcongr
    _=441*Real.exp 1*cn^r*(((2:ℝ)^r*α^r/(r.factorial:ℝ))*((α-1)/α)*(v/ζ)*Real.exp (C*r)*q) := by ring
    _≤441*Real.exp 1*cn^r*(Real.exp (3*r)*1*(1/c)*Real.exp (C*r)*Real.exp (20*r)) := by
      gcongr
    _=(441*Real.exp 1/c)*(cn*Real.exp (C+23))^r := by
      rw [mul_one,mul_pow,←Real.exp_nat_mul]
      have he : Real.exp (3*r)*Real.exp (C*r)*Real.exp (20*r)=Real.exp ((r:ℝ)*(C+23)) := by
        rw [←Real.exp_add,←Real.exp_add]
        congr 1
        ring
      calc
        _=(441*Real.exp 1/c)*cn^r*(Real.exp (3*r)*Real.exp (C*r)*Real.exp (20*r)) := by ring
        _=_ := by rw [he]; ring

/-- The regularizing velocity is retained in zeta with its full coefficient. -/
theorem lower_zeta_velocity_floor {c E s v : ℝ}
    (hc : 0<c) (hE : 0<E) (hs : 0≤s) (hs1 : s≤1) (hv : 0≤v) :
    c*v≤c*(s*(1-s)+v)/(1-Real.exp (-E)) := by
  have hd : 0<1-Real.exp (-E) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  apply (le_div_iff₀ hd).mpr
  have hh := mul_nonneg (mul_nonneg hc.le hv) (Real.exp_nonneg (-E))
  have hsprod := mul_nonneg hs (show 0≤1-s by linarith)
  have hprod := mul_nonneg hc.le hsprod
  nlinarith only [hh,hprod]

/-- The activated defect contribution at the actual root is at most 1/64,
with zero contribution when the perturbation is inactive. -/
theorem lower_actual_defect_budget {k r : ℕ} {α ε s ρ D : ℝ}
    (hk : 0<k) (hr : 2≤r) (hα : 3/2≤α) (hε : 0<ε) (hε1 : ε≤1/2)
    (hs : 0<s) (hs1 : s≤1/2)
    (hg : 0<fractionalPart α) (hg1 : fractionalPart α<1)
    (hnearest : s=fractionalPart α ∨ s=1-fractionalPart α)
    (hdegree : α-(r:ℝ)=s ∨ α-(r:ℝ)= -s)
    (hx : 1<rootMultiplier k α ε) (hρ : 0≤ρ) (hD : 0≤D)
    (hρv : ρ≤(41/2)*((α-1)/α*rootMultiplier k α ε^(-α)))
    (hactivation : 0<ρ → 2*s≤(41/4)*((α-1)/α*rootMultiplier k α ε^(-α)))
    (hDbound :
      let c := lowerPriorCoefficient ε
      let v := (α-1)/α*rootMultiplier k α ε^(-α)
      let ζ := c*(s*(1-s)+v)/(1-Real.exp (-(2*ε*(α-1))))
      D≤Real.exp ((20+2/c)*r)/ζ) :
    let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*rootMultiplier k α ε
    (k:ℝ)*((2:ℝ)^r/(Real.exp (-1)*(r.factorial:ℝ)))*θ^r*ρ^2*D≤1/64 := by
  by_cases hρzero : ρ=0
  · simp only [hρzero,zero_pow (by decide : 2≠0),mul_zero]
    norm_num
  have hρpos : 0<ρ := lt_of_le_of_ne hρ (Ne.symm hρzero)
  let c := lowerPriorCoefficient ε
  let x := rootMultiplier k α ε
  let v := (α-1)/α*x^(-α)
  let E := 2*ε*(α-1)
  let ζ := c*(s*(1-s)+v)/(1-Real.exp (-E))
  have hα0 : 0<α := by linarith
  have hα1 : 1<α := by linarith
  have hβ : 0<α-1 := by linarith
  have hx0 : 0<x := by dsimp [x]; linarith
  have hc : 0<c := (lowerPriorCoefficient_bounds hε).1
  have hv : 0≤v := by dsimp [v]; positivity
  have hE : 0<E := by dsimp [E]; positivity
  have hζ : 0<ζ := by
    have hd : 0<1-Real.exp (-E) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
    have hw : 0<s*(1-s)+v := add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv
    exact div_pos (mul_pos hc hw) hd
  have hvlo : c*v≤ζ := lower_zeta_velocity_floor hc hE hs.le (by linarith) hv
  have hvζ : v/ζ≤1/c := (div_le_div_iff₀ hζ hc).mpr (by nlinarith only [hvlo])
  have hαr : α≤(r:ℝ)+1/2 := by rcases hdegree with h | h <;> linarith
  have hcorr := lower_activated_power_correction hk hr hα hε1 hs hs1 hg hg1 hnearest hdegree hx
    (hactivation hρpos)
  have hterm := lower_defect_term_bound (cn:=lowerPriorIntensityConstant ε) (C:=20+2/c) (by exact_mod_cast hk) hα1 hx0
    (Real.exp_pos _) hc hζ hr hαr hρ hD hρv hvζ hDbound hcorr
  apply hterm.trans
  apply lower_defect_exponential_budget hr (Real.exp_nonneg _) (by positivity)
  exact lower_actual_defect_constant hε

end Renyi
