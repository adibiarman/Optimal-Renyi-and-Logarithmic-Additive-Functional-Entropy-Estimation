import Renyi.CoupledHighMoments
import Renyi.CoupledCountVariance
import Renyi.CoupledLeadingCoefficient
import Renyi.PoissonPairMoments
import Renyi.NearOneEstimator
import Renyi.CoupledCoefficientExponential

/-! Actual high-degree count noise, keeping the leading coefficient separate. -/
set_option maxHeartbeats 700000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def highCountCoefficients (r : ℕ) (c : ℕ → ℝ) (j : ℕ) : ℝ :=
  if r ≤ j then c j else 0

def highTailCoefficients (r : ℕ) (c : ℕ → ℝ) (j : ℕ) : ℝ :=
  if r < j then c j else 0

theorem factorialStatistic_high_split {r d : ℕ} (hrd : r ≤ d) (c : ℕ → ℝ) (j : ℕ) :
    factorialStatistic d (highCountCoefficients r c) j =
      c r * (j.descFactorial r : ℝ) + factorialStatistic d (highTailCoefficients r c) j := by
  have hmem : r ∈ Finset.range (d + 1) := Finset.mem_range.mpr (by omega)
  calc
    _ = ∑ k ∈ Finset.range (d + 1),
        ((if k = r then c r else 0) + highTailCoefficients r c k) * (j.descFactorial k : ℝ) := by
      apply Finset.sum_congr rfl
      intro k _
      dsimp [highCountCoefficients, highTailCoefficients]
      split_ifs <;> first | omega | simp_all
    _ = (∑ k ∈ Finset.range (d + 1), (if k = r then c r else 0) * (j.descFactorial k : ℝ)) +
        factorialStatistic d (highTailCoefficients r c) j := by
      simp only [add_mul, Finset.sum_add_distrib, factorialStatistic]
    _ = _ := by simp [hmem]

/-- A general finite factorial polynomial second-moment bound. -/
theorem poisson_polynomial_second_le (lam : ℝ≥0) (d : ℕ) (c : ℕ → ℝ) :
    (∫ j, factorialStatistic d c j ^ 2 ∂poissonMeasure lam) ≤
      ((d : ℝ) + 1) * ∑ k ∈ Finset.range (d + 1), c k ^ 2 * poissonFactorialSecond lam k := by
  have hterm (k : ℕ) : Integrable (fun j : ℕ => c k ^ 2 * (j.descFactorial k : ℝ) ^ 2)
      (poissonMeasure lam) := (poisson_factorial_memLp lam k).integrable_sq.const_mul _
  have hpoint (j : ℕ) : factorialStatistic d c j ^ 2 ≤
      ((d : ℝ) + 1) * ∑ k ∈ Finset.range (d + 1), c k ^ 2 * (j.descFactorial k : ℝ) ^ 2 := by
    have h := Finset.sum_mul_sq_le_sq_mul_sq (Finset.range (d + 1)) (fun _ : ℕ => (1 : ℝ))
      (fun k => c k * (j.descFactorial k : ℝ))
    simpa only [factorialStatistic, one_mul, one_pow, Finset.sum_const, Finset.card_range,
      nsmul_eq_mul, mul_one, Nat.cast_add, Nat.cast_one, mul_pow] using h
  have hsum := integrable_finset_sum (Finset.range (d + 1)) (fun k _ => hterm k)
  have hmono := integral_mono (poisson_polynomial_memLp lam d c).integrable_sq
    (hsum.const_mul ((d : ℝ) + 1)) hpoint
  rw [integral_const_mul, integral_finset_sum _ (fun k _ => hterm k)] at hmono
  simp_rw [integral_const_mul] at hmono
  have hmom (k : ℕ) : (∫ j : ℕ, (j.descFactorial k : ℝ) ^ 2 ∂poissonMeasure lam) =
      poissonFactorialSecond lam k := by
    rw [poisson_integral_eq_tsum lam _ (poisson_factorial_memLp lam k).integrable_sq]
    rfl
  simpa only [hmom] using hmono

/-- The fractional leading coefficient is harmless below the genuine tiny
cutoff; the bound is uniform as the fractional gap tends to zero. -/
theorem fractional_leading_tiny_damping {delta L lam : ℝ}
    (hd : 0 < delta) (hL : 0 < L)
    (hlam : 0 ≤ lam) (hsmall : lam ≤ Real.exp (-2 * L)) :
    (L / delta) ^ (2 * delta) * lam ^ delta ≤ Real.exp 2 := by
  have hm := Real.rpow_le_rpow hlam hsmall hd.le
  have hfirst := mul_le_mul_of_nonneg_left hm
    (Real.rpow_nonneg (by positivity : 0 ≤ L / delta) (2 * delta))
  have hlast : (L / delta) ^ (2 * delta) * (Real.exp (-2 * L)) ^ delta ≤ Real.exp 2 := by
    rw [Real.rpow_def_of_pos (div_pos hL hd), ← Real.exp_mul, ← Real.exp_add]
    apply Real.exp_le_exp.mpr
    rw [Real.log_div hL.ne' hd.ne']
    have hlogL := Real.log_le_sub_one_of_pos hL
    have hlogd := Real.log_le_sub_one_of_pos (inv_pos.mpr hd)
    rw [Real.log_inv] at hlogd
    have hdl := mul_le_mul_of_nonneg_left hlogL hd.le
    have hdd := mul_le_mul_of_nonneg_left hlogd hd.le
    have hid : delta * delta⁻¹ = 1 := mul_inv_cancel₀ hd.ne'
    nlinarith only [hdl, hdd, hid, hd.le]
  exact hfirst.trans hlast

/-- With d*lambda at most one, the nonleading tiny-count moments share one
extra power of lambda. -/
theorem poisson_high_tail_second_tiny (lam : ℝ≥0) (r d : ℕ) (c : ℕ → ℝ) {A : ℝ}
    (hA : 0 ≤ A) (hlam : (lam : ℝ) ≤ 1) (hdlam : (d : ℝ) * lam ≤ 1)
    (hc : ∀ j : ℕ, r < j → j ≤ d → |c j| ≤ A) :
    (∫ j, factorialStatistic d (highTailCoefficients r c) j ^ 2 ∂poissonMeasure lam) ≤
      ((d : ℝ) + 1) ^ 2 * A ^ 2 * Real.exp (2 * (d : ℝ)) *
        ((r + 1 : ℕ) : ℝ) ^ (r + 1) * (lam : ℝ) ^ (r + 1) := by
  have hterm (j : ℕ) (hj : j ∈ Finset.range (d + 1)) :
      highTailCoefficients r c j ^ 2 * poissonFactorialSecond lam j ≤
        A ^ 2 * Real.exp (2 * (d : ℝ)) * ((r + 1 : ℕ) : ℝ) ^ (r + 1) * (lam : ℝ) ^ (r + 1) := by
    have hjd : j ≤ d := by have := Finset.mem_range.mp hj; omega
    by_cases hrj : r < j
    · have hsq := mul_le_mul (hc j hrj hjd) (hc j hrj hjd) (abs_nonneg _) hA
      simp only [← pow_two, sq_abs] at hsq
      have hm := poisson_factorial_second_tiny_geometric lam (r := r + 1)
        (by omega) (by omega) hjd hlam
      have hgeom : (d : ℝ) ^ (j - (r + 1)) * (lam : ℝ) ^ j ≤ (lam : ℝ) ^ (r + 1) := by
        have hid : j = r + 1 + (j - (r + 1)) := by omega
        conv_lhs => arg 2; rw [hid, pow_add]
        have hp := pow_le_one₀ (n := j - (r + 1)) (by positivity : 0 ≤ (d : ℝ) * lam) hdlam
        rw [mul_pow] at hp
        have hh := mul_le_mul_of_nonneg_left hp (pow_nonneg lam.coe_nonneg (r + 1))
        nlinarith only [hh]
      have hm' := mul_le_mul_of_nonneg_left hgeom
        (by positivity : 0 ≤ Real.exp (2 * (d : ℝ)) * ((r + 1 : ℕ) : ℝ) ^ (r + 1))
      have hmoment : poissonFactorialSecond lam j ≤ Real.exp (2 * (d : ℝ)) *
          ((r + 1 : ℕ) : ℝ) ^ (r + 1) * (lam : ℝ) ^ (r + 1) := by
        exact hm.trans (by nlinarith only [hm'])
      dsimp [highTailCoefficients]
      rw [if_pos hrj]
      have hbound := mul_le_mul hsq hmoment (poissonFactorialSecond_nonneg lam j) (sq_nonneg A)
      simpa only [mul_assoc] using hbound
    · simp only [highTailCoefficients, if_neg hrj, zero_pow (by norm_num : 2 ≠ 0), zero_mul]
      positivity
  apply (poisson_polynomial_second_le lam d (highTailCoefficients r c)).trans
  have hsum := Finset.sum_le_sum (s := Finset.range (d + 1)) hterm
  have hm := mul_le_mul_of_nonneg_left hsum (by positivity : 0 ≤ (d : ℝ) + 1)
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul, Nat.cast_add, Nat.cast_one] at hm
  convert hm using 1
  push_cast
  ring

theorem high_tail_tiny_calibration {lam A Cb Cd Ct L a : ℝ} {r d : ℕ}
    (hlam0 : 0 ≤ lam) (hL : 0 < L) (hCb : 0 ≤ Cb) (hCd : 0 ≤ Cd)
    (hA0 : 0 ≤ A) (hA : A ≤ Real.exp (Cb * L))
    (hd : (d : ℝ) ≤ Cd * L) (ha : 0 < a) (har : a ≤ (r : ℝ))
    (hCt : 2 * Cb + 4 * Cd ≤ Ct) (hsmall : lam ≤ Real.exp (-Ct * L)) :
    ((d : ℝ) + 1) ^ 2 * A ^ 2 * Real.exp (2 * (d : ℝ)) * lam ^ (r + 1) ≤ lam ^ a := by
  by_cases hlam : lam = 0
  · subst lam
    simp [Real.zero_rpow ha.ne']
  have hlampos : 0 < lam := lt_of_le_of_ne hlam0 (Ne.symm hlam)
  have hCt0 : 0 ≤ Ct := (by positivity : 0 ≤ 2 * Cb + 4 * Cd).trans hCt
  have hlam1 : lam ≤ 1 := hsmall.trans (Real.exp_le_one_iff.mpr (by nlinarith))
  have hsq := mul_le_mul hA hA hA0 (Real.exp_pos _).le
  simp only [← pow_two] at hsq
  have hfirst := mul_le_mul_of_nonneg_right hsq
    (by positivity : 0 ≤ (((d : ℝ) + 1) ^ 2 * Real.exp (2 * (d : ℝ)) * lam ^ (r + 1)))
  have hbound : ((d : ℝ) + 1) ^ 2 * (Real.exp (Cb * L)) ^ 2 *
      Real.exp (2 * (d : ℝ)) * lam ^ (r + 1) ≤ lam ^ a := by
    have hleft : 0 < ((d : ℝ) + 1) ^ 2 * (Real.exp (Cb * L)) ^ 2 *
        Real.exp (2 * (d : ℝ)) * lam ^ (r + 1) := by positivity
    apply (Real.log_le_log_iff hleft (Real.rpow_pos_of_pos hlampos _)).1
    rw [Real.log_mul (by positivity) (by positivity),
      Real.log_mul (by positivity) (by positivity),
      Real.log_mul (by positivity) (by positivity), Real.log_pow, Real.log_pow,
      Real.log_exp, Real.log_exp, Real.log_pow, Real.log_rpow hlampos]
    have hlogd := Real.log_le_sub_one_of_pos (by positivity : 0 < (d : ℝ) + 1)
    have hloglam : Real.log lam ≤ -Ct * L := by
      have hh := Real.log_le_log hlampos hsmall
      simpa only [Real.log_exp] using hh
    have hloglam0 := Real.log_nonpos hlam0 hlam1
    have hr : a + 1 ≤ ((r + 1 : ℕ) : ℝ) := by push_cast; linarith
    have hrem := mul_le_mul_of_nonpos_right hr hloglam0
    have hcost := mul_le_mul_of_nonneg_right hCt hL.le
    have hdegree := mul_le_mul_of_nonneg_left hd (by norm_num : (0 : ℝ) ≤ 4)
    push_cast at hrem ⊢
    nlinarith only [hlogd, hloglam, hrem, hcost, hdegree]
  nlinarith only [hfirst, hbound]

theorem high_tiny_count_product {lam Cb Cd Ct L : ℝ} {d : ℕ}
    (hlam0 : 0 ≤ lam) (hL : 0 < L) (hCb : 0 ≤ Cb) (hCd : 0 ≤ Cd)
    (hd : (d : ℝ) ≤ Cd * L) (hCt : 2 * Cb + 4 * Cd ≤ Ct)
    (hsmall : lam ≤ Real.exp (-Ct * L)) : (d : ℝ) * lam ≤ 1 := by
  have hCtCd : Cd ≤ Ct := by nlinarith
  have hd' : (d : ℝ) ≤ Real.exp (Ct * L) := by
    have hscale := mul_le_mul_of_nonneg_right hCtCd hL.le
    have he := Real.add_one_le_exp (Ct * L)
    linarith
  have hm := mul_le_mul hd' hsmall hlam0 (Real.exp_pos _).le
  rw [← Real.exp_add, show Ct * L + -Ct * L = 0 by ring, Real.exp_zero] at hm
  exact hm

/-- Every selected high-degree coefficient obeys one actual intensity envelope. -/
theorem high_count_selected_variance_all (lam : ℝ≥0) {r d : ℕ}
    {a H A cp B M : ℝ} (hH : 0 < H) (ha : 0 < a) (har : a ≤ (r : ℝ))
    (hA : 0 ≤ A) (hcp0 : 0 < cp) (hB : 0 ≤ B) (hM : 0 ≤ M)
    (hd : (d : ℝ) ≤ M * H) (hcp : 4 * M ≤ cp) (c : ℕ → ℝ)
    (hc : ∀ j : ℕ, r ≤ j → j ≤ d → |c j| ≤ A * H ^ (a - j)) :
    poissonLowerMass ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp * B * a) *
      variance (factorialStatistic d (highCountCoefficients r c)) (poissonMeasure lam) ≤
      ((d : ℝ) + 1) ^ 2 * A ^ 2 * Real.exp (cp * B * a + M * d) * H ^ a * (lam : ℝ) ^ a := by
  let mu : ℝ≥0 := ⟨cp * lam, by positivity⟩
  let T := cp * B * a
  have hfirst := mul_le_mul_of_nonneg_left
    ((variance_le_expectation_sq (poisson_polynomial_memLp lam d (highCountCoefficients r c)).aestronglyMeasurable).trans
      (poisson_polynomial_second_le lam d (highCountCoefficients r c)))
    (poissonLowerMass_nonneg mu T)
  have hterm (j : ℕ) (hj : j ∈ Finset.range (d + 1)) :
      highCountCoefficients r c j ^ 2 * poissonPilotSecond lam mu T j ≤
        A ^ 2 * Real.exp (cp * B * a + M * d) * H ^ a * (lam : ℝ) ^ a := by
    have hjd : j ≤ d := by have := Finset.mem_range.mp hj; omega
    by_cases hrj : r ≤ j
    · have hjR : a ≤ (j : ℝ) := har.trans (by exact_mod_cast hrj)
      have hjM : (j : ℝ) ≤ M * (1 * H) := by simpa only [one_mul] using (show (j : ℝ) ≤ d by exact_mod_cast hjd).trans hd
      have hco : |c j| ≤ (1 : ℝ) * A * H ^ (a - j) := by simpa only [one_mul] using hc j hrj hjd
      have h := near_one_high_term_bound (by norm_num : (0 : ℝ) < 1) hH ha (by norm_num : (0 : ℝ) ≤ 1)
        hA hcp0 hB hM hcp lam hjR hjM hco
      have he := Real.exp_le_exp.mpr (add_le_add_left (mul_le_mul_of_nonneg_left
        (show (j : ℝ) ≤ d by exact_mod_cast hjd) hM) (cp * B * a))
      have he' := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left he (sq_nonneg A)) (Real.rpow_nonneg hH.le a))
          (Real.rpow_nonneg lam.coe_nonneg a)
      dsimp [highCountCoefficients]
      rw [if_pos hrj]
      have h' : c j ^ 2 * poissonPilotSecond lam mu T j ≤
          A ^ 2 * Real.exp (cp * B * a + M * j) * H ^ a * (lam : ℝ) ^ a := by
        simpa only [one_pow, div_one, one_mul, Real.one_rpow, mul_one] using h
      exact h'.trans he'
    · simp only [highCountCoefficients, if_neg hrj, zero_pow (by norm_num : 2 ≠ 0), zero_mul]
      positivity
  have hsum := Finset.sum_le_sum (s := Finset.range (d + 1)) hterm
  have hlast := mul_le_mul_of_nonneg_left hsum (by positivity : 0 ≤ (d : ℝ) + 1)
  have heq : poissonLowerMass mu T * (((d : ℝ) + 1) *
      ∑ j ∈ Finset.range (d + 1), highCountCoefficients r c j ^ 2 * poissonFactorialSecond lam j) =
      ((d : ℝ) + 1) * ∑ j ∈ Finset.range (d + 1),
        highCountCoefficients r c j ^ 2 * poissonPilotSecond lam mu T j := by
    simp only [poissonPilotSecond_factor, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j _
    ring
  rw [heq] at hfirst
  apply hfirst.trans
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul, Nat.cast_add, Nat.cast_one] at hlast
  convert hlast using 1
  ring

theorem high_leading_tiny_moment (lam : ℝ≥0) {r : ℕ} {a delta K L c : ℝ}
    (ha : 0 < a) (hd : 0 < delta) (hgap : (r : ℝ) = a + delta)
    (hK : 0 ≤ K) (hL : 0 < L) (hc : |c| ≤ K * (L / delta) ^ delta)
    (hsmall : (lam : ℝ) ≤ Real.exp (-2 * L)) :
    c ^ 2 * poissonFactorialSecond lam r ≤
      K ^ 2 * Real.exp 2 * (2 * (r : ℝ)) ^ r * (lam : ℝ) ^ a := by
  have hr0 : 0 < r := by exact_mod_cast (show (0 : ℝ) < r by linarith)
  have hlam1 : (lam : ℝ) ≤ 1 := hsmall.trans (Real.exp_le_one_iff.mpr (by linarith))
  have hm := poisson_factorial_second_tiny lam r (by omega) hlam1
  by_cases hlam : (lam : ℝ) = 0
  · have hzero : poissonFactorialSecond lam r = 0 := by
      have hn := poissonFactorialSecond_nonneg lam r
      rw [hlam, zero_pow (Nat.ne_of_gt hr0), mul_zero] at hm
      linarith
    rw [hzero, mul_zero, hlam, Real.zero_rpow ha.ne', mul_zero]
  have hlampos : 0 < (lam : ℝ) := lt_of_le_of_ne lam.coe_nonneg (Ne.symm hlam)
  have hsq := mul_le_mul hc hc (abs_nonneg _) (by positivity : 0 ≤ K * (L / delta) ^ delta)
  simp only [← pow_two, sq_abs] at hsq
  have hfirst := mul_le_mul hsq hm (poissonFactorialSecond_nonneg lam r)
    (sq_nonneg (K * (L / delta) ^ delta))
  have hp : ((L / delta) ^ delta) ^ (2 : ℕ) = (L / delta) ^ (2 * delta) := by
    rw [mul_comm (2 : ℝ), Real.rpow_mul (by positivity : 0 ≤ L / delta), Real.rpow_two]
  have hlamp : (lam : ℝ) ^ r = (lam : ℝ) ^ a * (lam : ℝ) ^ delta := by
    rw [← Real.rpow_natCast, hgap, Real.rpow_add hlampos]
  have hlast := mul_le_mul_of_nonneg_left
    (fractional_leading_tiny_damping hd hL lam.coe_nonneg hsmall)
    (by positivity : 0 ≤ K ^ 2 * (2 * (r : ℝ)) ^ r * (lam : ℝ) ^ a)
  rw [mul_pow, hp, hlamp] at hfirst
  nlinarith only [hfirst, hlast]

/-- The tiny high block has no exponential degree-scale loss. The leading
degree uses the sharp fractional coefficient, and the genuine tiny cutoff
absorbs all costs from the remaining degrees. -/
theorem high_count_variance_tiny (lam : ℝ≥0) {r d : ℕ}
    {a delta K A Cb Cd Ct L : ℝ}
    (ha : 0 < a) (hd : 0 < delta) (hgap : (r : ℝ) = a + delta)
    (hrd : r ≤ d) (hK : 0 ≤ K) (hL : 0 < L) (hCb : 0 ≤ Cb) (hCd : 0 ≤ Cd)
    (hA0 : 0 ≤ A) (hA : A ≤ Real.exp (Cb * L)) (hdegree : (d : ℝ) ≤ Cd * L)
    (hCt : 2 * Cb + 4 * Cd ≤ Ct) (hCt2 : 2 ≤ Ct)
    (c : ℕ → ℝ) (hlead : |c r| ≤ K * (L / delta) ^ delta)
    (htail : ∀ j : ℕ, r < j → j ≤ d → |c j| ≤ A)
    (hsmall : (lam : ℝ) ≤ Real.exp (-Ct * L)) :
    variance (factorialStatistic d (highCountCoefficients r c)) (poissonMeasure lam) ≤
      (2 * K ^ 2 * Real.exp 2 * (2 * (r : ℝ)) ^ r +
        2 * ((r + 1 : ℕ) : ℝ) ^ (r + 1)) * (lam : ℝ) ^ a := by
  have hsmall2 : (lam : ℝ) ≤ Real.exp (-2 * L) := hsmall.trans
    (Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_right hCt2 hL.le]))
  have hlam1 : (lam : ℝ) ≤ 1 := hsmall2.trans (Real.exp_le_one_iff.mpr (by linarith))
  have hdlam := high_tiny_count_product lam.coe_nonneg hL hCb hCd hdegree hCt hsmall
  have ht := poisson_high_tail_second_tiny lam r d c hA0 hlam1 hdlam htail
  have hcal := high_tail_tiny_calibration lam.coe_nonneg hL hCb hCd hA0 hA hdegree ha
    (show a ≤ (r : ℝ) by linarith) hCt hsmall
  have hcal' := mul_le_mul_of_nonneg_left hcal (by positivity : 0 ≤ ((r + 1 : ℕ) : ℝ) ^ (r + 1))
  have htailmoment : (∫ j, factorialStatistic d (highTailCoefficients r c) j ^ 2 ∂poissonMeasure lam) ≤
      ((r + 1 : ℕ) : ℝ) ^ (r + 1) * (lam : ℝ) ^ a := by
    nlinarith only [ht, hcal']
  have hlead := high_leading_tiny_moment lam ha hd hgap hK hL hlead hsmall2
  have hleadmem := (poisson_factorial_memLp lam r).const_mul (c r)
  have hleadvar := variance_le_expectation_sq hleadmem.aestronglyMeasurable
  change variance (fun j : ℕ => c r * (j.descFactorial r : ℝ)) (poissonMeasure lam) ≤
    ∫ j : ℕ, (c r * (j.descFactorial r : ℝ)) ^ 2 ∂poissonMeasure lam at hleadvar
  simp_rw [mul_pow] at hleadvar
  rw [integral_const_mul] at hleadvar
  have hmom : (∫ j : ℕ, (j.descFactorial r : ℝ) ^ 2 ∂poissonMeasure lam) =
      poissonFactorialSecond lam r := by
    rw [poisson_integral_eq_tsum lam _ (poisson_factorial_memLp lam r).integrable_sq]
    rfl
  rw [hmom] at hleadvar
  have htailmem := poisson_polynomial_memLp lam d (highTailCoefficients r c)
  have htailvar := (variance_le_expectation_sq htailmem.aestronglyMeasurable).trans htailmoment
  have htri := variance_fun_add_le_two hleadmem htailmem
  have heq : factorialStatistic d (highCountCoefficients r c) = fun j =>
      c r * (j.descFactorial r : ℝ) + factorialStatistic d (highTailCoefficients r c) j := by
    funext j
    exact factorialStatistic_high_split hrd c j
  rw [heq]
  nlinarith only [htri, hleadvar, hlead, htailvar]

theorem count_coefficient_scaled_bound {n b a q A : ℝ} (hn : 0 < n) (hb : 0 < b)
    (j : ℕ) (hq : |q| * b ^ j ≤ b ^ a * A) :
    |n ^ (a - j) * q| ≤ A * (n * b) ^ (a - j) := by
  have hp : b ^ (a - j) * b ^ j = b ^ a := by
    rw [← Real.rpow_natCast, ← Real.rpow_add hb]
    congr 1
    ring
  have hsingle : |q| ≤ A * b ^ (a - j) := by
    apply (mul_le_mul_iff_left₀ (pow_pos hb j)).mp
    calc
      |q| * b ^ j ≤ b ^ a * A := hq
      _ = (A * b ^ (a - j)) * b ^ j := by rw [mul_assoc, hp]; ring
  rw [abs_mul, abs_of_pos (Real.rpow_pos_of_pos hn _), Real.mul_rpow hn.le hb.le]
  have h := mul_le_mul_of_nonneg_left hsingle (Real.rpow_nonneg hn.le (a - j))
  nlinarith only [h]

theorem high_count_statistic_scaling {n a : ℝ} (hn : 0 < n)
    (r d : ℕ) (q : ℕ → ℝ) :
    factorialStatistic d (fun j => highCountCoefficients r q j / n ^ j) =
      fun z => n ^ (-a) * factorialStatistic d
        (highCountCoefficients r (fun j => n ^ (a - j) * q j)) z := by
  funext z
  dsimp [factorialStatistic]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j _
  dsimp [highCountCoefficients]
  split_ifs
  · have hp : n ^ (-a) * n ^ (a - j) = (n ^ j)⁻¹ := by
      rw [← Real.rpow_add hn, show -a + (a - (j : ℝ)) = -(j : ℝ) by ring,
        Real.rpow_neg hn.le, Real.rpow_natCast]
    calc
      q j / n ^ j * (z.descFactorial j : ℝ) =
        (n ^ (-a) * n ^ (a - j)) * q j * (z.descFactorial j : ℝ) := by rw [hp]; ring
      _ = _ := by ring
  · ring

theorem high_count_variance_scaling (lam : ℝ≥0) {n a : ℝ} (hn : 0 < n)
    (r d : ℕ) (q : ℕ → ℝ) :
    variance (factorialStatistic d (fun j => highCountCoefficients r q j / n ^ j)) (poissonMeasure lam) =
      n ^ (-2 * a) * variance (factorialStatistic d
        (highCountCoefficients r (fun j => n ^ (a - j) * q j))) (poissonMeasure lam) := by
  rw [high_count_statistic_scaling hn, variance_mul]
  have hp : (n ^ (-a)) ^ (2 : ℕ) = n ^ (-2 * a) := by
    rw [← Real.rpow_two, ← Real.rpow_mul hn.le]
    congr 1
    ring
  rw [hp]

/-- CC16 in count units for the actual coupled polynomial. The leading bound
is instantiated from its actual reciprocal-Gamma/profile coefficient, rather
than assumed as a coefficient certificate. -/
theorem coupledQ_high_count_variance {ell N m d : ℕ}
    (hell : 0 < ell) (hN : 0 < N) (hdegree : 4 * (ell - 1) ≤ m)
    {gamma aCut b n fL f A B omega L Cscale Cb Cd Ct cp Bpilot M : ℝ}
    (hgamma : 0 < gamma) (hgamma1 : gamma < 1)
    (haCut : 0 < aCut) (hab : aCut ≤ b) (hb : 0 < b) (hn : 0 < n)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hB : 0 ≤ B) (hB1 : B ≤ 1)
    (hw : 0 ≤ omega) (hw1 : omega < 1)
    (hlocal : (ell : ℝ) ^ 2 * (aCut * (N : ℝ) ^ 2 / b) ≤ 1)
    (hL : 0 < L) (hscale : 0 < Cscale) (hcountScale : (N : ℝ) ^ 2 / (n * b) ≤ Cscale * L)
    (hH : 1 ≤ n * b) (hrd : m + 1 ≤ d)
    (hCb : 0 ≤ Cb) (hCd : 0 ≤ Cd) (hdegreeL : (d : ℝ) ≤ Cd * L)
    (hCt : 2 * Cb + 4 * Cd ≤ Ct) (hCt2 : 2 ≤ Ct)
    (hbudget : coupledCoefficientBudget ell N gamma aCut b A B omega ≤ Real.exp (Cb * L))
    (hcp0 : 0 < cp) (hBpilot : 0 ≤ Bpilot) (hM : 0 ≤ M)
    (hdegreeH : (d : ℝ) ≤ M * (n * b)) (hcp : 4 * M ≤ cp) (lam : ℝ≥0) :
    let order : ℝ := (m : ℝ) + gamma
    let r := m + 1
    let Q := coupledQPolynomial ell N m gamma aCut b fL f A B omega
    let c : ℕ → ℝ := fun j => n ^ (order - j) * Q.coeff j
    let K := coupledLeadingCoefficientConstant * max 1 Cscale
    let tiny := 2 * K ^ 2 * Real.exp 2 * (2 * (r : ℝ)) ^ r +
      2 * ((r + 1 : ℕ) : ℝ) ^ (r + 1)
    let medium := ((d : ℝ) + 1) ^ 2 * (coupledCoefficientBudget ell N gamma aCut b A B omega) ^ 2 *
      Real.exp (cp * Bpilot * order + M * d)
    poissonLowerMass ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp * Bpilot * order) *
      variance (factorialStatistic d (highCountCoefficients r c)) (poissonMeasure lam) ≤
        tiny * (lam : ℝ) ^ order +
          if Real.exp (-Ct * L) < (lam : ℝ) then medium * (n * b) ^ order * (lam : ℝ) ^ order else 0 := by
  let order : ℝ := (m : ℝ) + gamma
  let r := m + 1
  let Q := coupledQPolynomial ell N m gamma aCut b fL f A B omega
  let c : ℕ → ℝ := fun j => n ^ (order - j) * Q.coeff j
  let K := coupledLeadingCoefficientConstant * max 1 Cscale
  let budget := coupledCoefficientBudget ell N gamma aCut b A B omega
  have horder : 0 < order := by dsimp [order]; have := Nat.cast_nonneg (α := ℝ) m; linarith
  have hgap : (r : ℝ) = order + (1 - gamma) := by dsimp [r, order]; push_cast; ring
  have hdelta : 0 < 1 - gamma := by linarith
  have har : order ≤ (r : ℝ) := by linarith
  have hbudget0 : 0 ≤ budget := by
    dsimp [budget, coupledCoefficientBudget]
    have := sub_nonneg.mpr hB1
    positivity
  have hK : 0 ≤ K := mul_nonneg coupledLeadingCoefficientConstant_pos.le (by positivity)
  have hc (j : ℕ) : |c j| ≤ budget * (n * b) ^ (order - j) := by
    exact count_coefficient_scaled_bound hn hb j
      (coupledQPolynomial_coefficient_bound hell hN hdegree hgamma hgamma1 haCut.le hab hb
        hfL hfL1 hf hf1 hA hB hB1 hw hw1 j)
  have hlead : |c r| ≤ K * (L / (1 - gamma)) ^ (1 - gamma) := by
    have h := coupledQPolynomial_leading_count_uniform hell hN hdegree hgamma hgamma1 haCut hb hn
      hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1 hlocal hL hscale hcountScale
    have he : order - (r : ℝ) = -(1 - gamma) := by linarith
    change |n ^ (order - (r : ℝ)) * Q.coeff r| ≤ _
    rw [he]
    exact h
  have htail (j : ℕ) (hrj : r < j) (_hjd : j ≤ d) : |c j| ≤ budget := by
    have hexp : order - (j : ℝ) ≤ 0 := by
      have hj : (r : ℝ) < j := by exact_mod_cast hrj
      linarith
    have hp := Real.rpow_le_one_of_one_le_of_nonpos hH hexp
    exact (hc j).trans (by simpa only [mul_one] using mul_le_mul_of_nonneg_left hp hbudget0)
  have hall := high_count_selected_variance_all lam (lt_of_lt_of_le (by norm_num : (0 : ℝ) < 1) hH)
    horder har hbudget0 hcp0 hBpilot hM hdegreeH hcp c (fun j _ _ => hc j)
  dsimp only
  by_cases hsmall : (lam : ℝ) ≤ Real.exp (-Ct * L)
  · rw [if_neg (not_lt.mpr hsmall), add_zero]
    have htiny := high_count_variance_tiny lam horder hdelta hgap hrd hK hL hCb hCd hbudget0
      hbudget hdegreeL hCt hCt2 c hlead htail hsmall
    have hselected : poissonLowerMass ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp * Bpilot * order) *
        variance (factorialStatistic d (highCountCoefficients r c)) (poissonMeasure lam) ≤
        variance (factorialStatistic d (highCountCoefficients r c)) (poissonMeasure lam) :=
      mul_le_of_le_one_left (variance_nonneg _ _) (poissonLowerMass_le_one _ _)
    exact hselected.trans htiny
  · rw [if_pos (lt_of_not_ge hsmall)]
    exact hall.trans (le_add_of_nonneg_left (by positivity))

theorem bounded_order_power_exponential {a s : ℝ} (ha : 1 ≤ a) (has : a ≤ s)
    (hsa : s ≤ a + 2) : s ^ s ≤ Real.exp (6 * a) * a ^ a := by
  have ha0 : 0 < a := by linarith
  have hs0 : 0 < s := ha0.trans_le has
  have hlogA : 0 ≤ Real.log a := Real.log_nonneg ha
  have hlogS : 0 ≤ Real.log (s / a) := Real.log_nonneg ((one_le_div ha0).2 has)
  have hlogRatio : Real.log (s / a) ≤ 2 / a := by
    have h := Real.log_le_sub_one_of_pos (div_pos hs0 ha0)
    apply h.trans
    apply (le_div_iff₀ ha0).2
    field_simp
    nlinarith only [hsa]
  have hs3 : s ≤ 3 * a := by linarith
  have hprod := mul_le_mul hs3 hlogRatio hlogS (by positivity : 0 ≤ 3 * a)
  have hprod6 : s * Real.log (s / a) ≤ 6 := by
    have he : 3 * a * (2 / a) = 6 := by field_simp; norm_num
    simpa only [he] using hprod
  have hdiff := mul_le_mul_of_nonneg_right (show s - a ≤ 2 by linarith) hlogA
  have hlogAup := Real.log_le_sub_one_of_pos ha0
  rw [Real.rpow_def_of_pos hs0, Real.rpow_def_of_pos ha0, ← Real.exp_add]
  apply Real.exp_le_exp.mpr
  rw [Real.log_div hs0.ne' ha0.ne'] at hprod6
  nlinarith only [hprod6, hdiff, hlogAup, ha]

theorem high_tiny_budget_exponential {a K : ℝ} {r : ℕ}
    (ha : 1 ≤ a) (har : a ≤ (r : ℝ)) (hra : (r : ℝ) ≤ a + 1) :
    2 * K ^ 2 * Real.exp 2 * (2 * (r : ℝ)) ^ r +
      2 * ((r + 1 : ℕ) : ℝ) ^ (r + 1) ≤
        (2 * K ^ 2 * Real.exp 2 + 2) * Real.exp (8 * a) * a ^ a := by
  have hrpow := bounded_order_power_exponential ha har (by linarith : (r : ℝ) ≤ a + 2)
  rw [Real.rpow_natCast] at hrpow
  have ht : (2 : ℝ) ^ r ≤ Real.exp (r : ℝ) := by
    have h2 : (2 : ℝ) ≤ Real.exp 1 := by linarith [Real.add_one_le_exp (1 : ℝ)]
    have hp := pow_le_pow_left₀ (by norm_num : (0 : ℝ) ≤ 2) h2 r
    simpa only [← Real.exp_nat_mul, mul_one] using hp
  have hr2a : (r : ℝ) ≤ 2 * a := by linarith
  have hbig := mul_le_mul ht hrpow (by positivity : 0 ≤ (r : ℝ) ^ r) (Real.exp_pos _).le
  have he : Real.exp (r : ℝ) * Real.exp (6 * a) ≤ Real.exp (8 * a) := by
    rw [← Real.exp_add]
    exact Real.exp_le_exp.mpr (by linarith)
  have he' := mul_le_mul_of_nonneg_right he (Real.rpow_nonneg (by linarith : 0 ≤ a) a)
  have hfirst : (2 * (r : ℝ)) ^ r ≤ Real.exp (8 * a) * a ^ a := by
    rw [mul_pow]
    nlinarith only [hbig, he']
  have hsecond := bounded_order_power_exponential ha
    (show a ≤ ((r + 1 : ℕ) : ℝ) by push_cast; linarith)
    (show ((r + 1 : ℕ) : ℝ) ≤ a + 2 by push_cast; linarith)
  rw [Real.rpow_natCast] at hsecond
  have he2 := mul_le_mul_of_nonneg_right
    (Real.exp_le_exp.mpr (show 6 * a ≤ 8 * a by linarith)) (Real.rpow_nonneg (by linarith : 0 ≤ a) a)
  have hfirst' := mul_le_mul_of_nonneg_left hfirst (by positivity : 0 ≤ 2 * K ^ 2 * Real.exp 2)
  nlinarith only [hfirst', hsecond, he2]

theorem high_medium_budget_exponential {a A Cb Cd L cp B M : ℝ} {d : ℕ}
    (hA0 : 0 ≤ A)
    (hA : A ≤ Real.exp (Cb * L)) (hd : (d : ℝ) ≤ Cd * L) (haL : a ≤ L)
    (hcpB : 0 ≤ cp * B) (hM : 0 ≤ M) :
    ((d : ℝ) + 1) ^ 2 * A ^ 2 * Real.exp (cp * B * a + M * d) ≤
      Real.exp ((cp * B + 2 * Cb + (M + 2) * Cd) * L) := by
  have hsq := mul_le_mul hA hA hA0 (Real.exp_pos _).le
  simp only [← pow_two] at hsq
  have hfirst := mul_le_mul_of_nonneg_right hsq
    (by positivity : 0 ≤ ((d : ℝ) + 1) ^ 2 * Real.exp (cp * B * a + M * d))
  have hbound : ((d : ℝ) + 1) ^ 2 * Real.exp (Cb * L) ^ 2 *
      Real.exp (cp * B * a + M * d) ≤ Real.exp ((cp * B + 2 * Cb + (M + 2) * Cd) * L) := by
    apply (Real.log_le_log_iff (by positivity) (Real.exp_pos _)).1
    rw [Real.log_mul (by positivity) (by positivity), Real.log_mul (by positivity) (by positivity),
      Real.log_pow, Real.log_pow, Real.log_exp, Real.log_exp, Real.log_exp]
    have hlog := Real.log_le_sub_one_of_pos (by positivity : 0 < (d : ℝ) + 1)
    have hdegree := mul_le_mul_of_nonneg_left hd (show 0 ≤ M + 2 by linarith)
    have horder := mul_le_mul_of_nonneg_left haL hcpB
    push_cast
    nlinarith only [hlog, hdegree, horder]
  nlinarith only [hfirst, hbound]

variable {iota Omega Xi : Type*} [Fintype iota] [MeasurableSpace Omega] [MeasurableSpace Xi]
variable {mu : Measure Omega} {nu : Measure Xi}

/-- The actual pilot-averaged high-block count variance, with the full tiny /
larger-mean split and the exact probability-unit scaling. -/
theorem coupledQ_high_averaged_count_variance {ell N m d : ℕ}
    (hell : 0 < ell) (hN : 0 < N) (hdegree : 4 * (ell - 1) ≤ m)
    {gamma aCut b n fL f A B omega L Cscale Cd Ct cp Bpilot M : ℝ}
    (hgamma : 0 < gamma) (hgamma1 : gamma < 1)
    (haCut : 0 < aCut) (hab : aCut ≤ b) (hb : 0 < b) (hn : 0 < n)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hB : 0 ≤ B) (hB1 : B ≤ 1)
    (hw : 0 ≤ omega) (hw1 : omega < 1)
    (hlocal : (ell : ℝ) ^ 2 * (aCut * (N : ℝ) ^ 2 / b) ≤ 1)
    (hL : 1 ≤ L) (hellL : (ell : ℝ) ≤ L) (hNL : (N : ℝ) ≤ L)
    (hscale : 0 < Cscale) (hcountScale : (N : ℝ) ^ 2 / (n * b) ≤ Cscale * L)
    (hH : 1 ≤ n * b) (hrd : m + 1 ≤ d)
    (hCd : 0 ≤ Cd) (hdegreeL : (d : ℝ) ≤ Cd * L)
    (hCt : 2 * coupledCoefficientExponentialConstant + 4 * Cd ≤ Ct) (hCt2 : 2 ≤ Ct)
    (hcp0 : 0 < cp) (hBpilot : 0 ≤ Bpilot) (hM : 0 ≤ M)
    (hdegreeH : (d : ℝ) ≤ M * (n * b)) (hcp : 4 * M ≤ cp)
    (Counts : iota → Omega → ℕ) (lam : iota → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (Counts i) mu (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (Counts i) (Counts j) mu))
    (Pilot : iota → Xi → ℕ)
    (hPilot : ∀ i, MeasurePreserving (Pilot i) nu
      (poissonMeasure ⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩)) :
    let order : ℝ := (m : ℝ) + gamma
    let r := m + 1
    let Q := coupledQPolynomial ell N m gamma aCut b fL f A B omega
    let K := coupledLeadingCoefficientConstant * max 1 Cscale
    let tiny := 2 * K ^ 2 * Real.exp 2 * (2 * (r : ℝ)) ^ r +
      2 * ((r + 1 : ℕ) : ℝ) ^ (r + 1)
    let medium := ((d : ℝ) + 1) ^ 2 * (coupledCoefficientBudget ell N gamma aCut b A B omega) ^ 2 *
      Real.exp (cp * Bpilot * order + M * d)
    pilotAveragedCountVariance Counts Pilot (cp * Bpilot * order) d
      (highCountCoefficients r Q.coeff) n mu nu ≤
        n ^ (-2 * order) * (tiny * (∑ i, (lam i : ℝ) ^ order) +
          medium * (n * b) ^ order *
            ∑ i, if Real.exp (-Ct * L) < (lam i : ℝ) then (lam i : ℝ) ^ order else 0) := by
  let order : ℝ := (m : ℝ) + gamma
  let r := m + 1
  let Q := coupledQPolynomial ell N m gamma aCut b fL f A B omega
  let c : ℕ → ℝ := fun j => n ^ (order - j) * Q.coeff j
  let K := coupledLeadingCoefficientConstant * max 1 Cscale
  let tiny := 2 * K ^ 2 * Real.exp 2 * (2 * (r : ℝ)) ^ r + 2 * ((r + 1 : ℕ) : ℝ) ^ (r + 1)
  let medium := ((d : ℝ) + 1) ^ 2 * (coupledCoefficientBudget ell N gamma aCut b A B omega) ^ 2 *
    Real.exp (cp * Bpilot * order + M * d)
  have hLpos : 0 < L := lt_of_lt_of_le (by norm_num) hL
  have hbudget := coupledCoefficientBudget_exponential hgamma.le haCut.le hab hb hA hA1 hB hB1 hw hw1.le hL hellL hNL
  have hCb := coupledCoefficientExponentialConstant_pos.le
  have hscalar (i : iota) :
      poissonLowerMass ⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩ (cp * Bpilot * order) *
        variance (factorialStatistic d (highCountCoefficients r c)) (poissonMeasure (lam i)) ≤
          tiny * (lam i : ℝ) ^ order +
            if Real.exp (-Ct * L) < (lam i : ℝ) then medium * (n * b) ^ order * (lam i : ℝ) ^ order else 0 :=
    coupledQ_high_count_variance hell hN hdegree hgamma hgamma1 haCut hab hb hn hfL hfL1 hf hf1
      hA hA1 hB hB1 hw hw1 hlocal hLpos hscale hcountScale hH hrd hCb hCd hdegreeL hCt hCt2
        hbudget hcp0 hBpilot hM hdegreeH hcp (lam i)
  dsimp only
  rw [pilot_averaged_count_variance Counts lam hLaw hpair Pilot
    (fun i => (⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩ : ℝ≥0)) hPilot]
  have hterm (i : iota) :
      poissonLowerMass ⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩ (cp * Bpilot * order) *
        variance (factorialStatistic d (fun j => highCountCoefficients r Q.coeff j / n ^ j)) (poissonMeasure (lam i)) ≤
      n ^ (-2 * order) * (tiny * (lam i : ℝ) ^ order +
        medium * (n * b) ^ order * (if Real.exp (-Ct * L) < (lam i : ℝ) then (lam i : ℝ) ^ order else 0)) := by
    rw [high_count_variance_scaling (lam i) hn]
    have h := mul_le_mul_of_nonneg_left (hscalar i) (Real.rpow_nonneg hn.le (-2 * order))
    convert h using 1
    · ring
    · split_ifs <;> ring
  have hsum := Finset.sum_le_sum (s := Finset.univ) (fun i _ => hterm i)
  convert hsum using 1
  simp only [mul_add, Finset.sum_add_distrib, ← Finset.mul_sum]
  dsimp [order, r, K, tiny, medium]
  ring_nf

end Renyi
