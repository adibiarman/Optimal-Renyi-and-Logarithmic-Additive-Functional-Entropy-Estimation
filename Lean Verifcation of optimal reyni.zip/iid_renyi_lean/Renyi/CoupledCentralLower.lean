import Renyi.CoupledDeterministicUpper

/-! Actual central lower certificate and its reserved high arm. -/
noncomputable section
namespace Renyi

def coupledLocalLowerConstant (f : ℝ) : ℝ := 288+Real.log (endpointReserveConstant f)

theorem coupledLocalLowerConstant_nonneg {f : ℝ} (hf : 0≤f) (hf1 : f<1) :
    0≤coupledLocalLowerConstant f := by
  have hl := Real.log_nonneg (endpointReserveConstant_one_le hf hf1)
  unfold coupledLocalLowerConstant
  linarith only [hl]

lemma lowProfile_local_exponential_lower {N : ℕ} (hN : 2≤N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1)
    (hy : (N:ℝ)^2*x≤s) :
    Real.exp (-coupledLocalLowerConstant f*s)*(((N:ℝ)^2*x)/s)^s≤lowProfile N s f x := by
  have h := lowProfile_local_lower hN hs hs1 hf hf1 hx hx1 hy
  rw [profile_rescaled_power (by positivity) (endpointReserveConstant_pos hf1) hs] at h
  have hid : Real.exp (-coupledLocalLowerConstant f*s)=
      Real.exp (-Real.log (endpointReserveConstant f)*s)*Real.exp (-288*s) := by
    rw [←Real.exp_add]
    congr 1
    unfold coupledLocalLowerConstant
    ring
  rw [hid]
  nlinarith only [h]

lemma highProfile_local_exponential_lower {N : ℕ} (hN : 2≤N) {s f ω x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : (N:ℝ)^2*x≤s) :
    Real.exp (-coupledLocalLowerConstant f*s)*(((N:ℝ)^2*x)/s)^s≤highProfile N s f ω x := by
  have h := highProfile_local_lower hN hs hs1 hf hf1 hω hω1 hx hx1 hy
  rw [profile_rescaled_power (by positivity) (endpointReserveConstant_pos hf1) hs] at h
  have hid : Real.exp (-coupledLocalLowerConstant f*s)=
      Real.exp (-Real.log (endpointReserveConstant f)*s)*Real.exp (-288*s) := by
    rw [←Real.exp_add]
    congr 1
    unfold coupledLocalLowerConstant
    ring
  rw [hid]
  nlinarith only [h]

lemma weighted_product_lower_linear {γ A B u v : ℝ}
    (hγ : 0<γ) (hγ1 : γ<1) (hA : 0<A) (hB : 0<B) (hu : 0≤u) (hv : 0≤v) :
    (u^(1-γ)*v^γ)*(A/(1-γ))^(1-γ)*(B/γ)^γ≤A*u+B*v := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have h := Real.geom_mean_le_arith_mean2_weighted hd.le hγ.le
    (mul_nonneg (div_nonneg hA.le hd.le) hu) (mul_nonneg (div_nonneg hB.le hγ.le) hv)
    (show (1-γ)+γ=1 by ring)
  rw [Real.mul_rpow (div_nonneg hA.le hd.le) hu,
    Real.mul_rpow (div_nonneg hB.le hγ.le) hv] at h
  have hid : (1-γ)*(A/(1-γ)*u)+γ*(B/γ*v)=A*u+B*v := by field_simp
  rw [hid] at h
  nlinarith only [h]

lemma overlap_approximate_lower_bound {γ z u v D : ℝ}
    (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1) (hu : 0≤u) (hv : 0≤v)
    (hprod : z*Real.exp (-D)≤u^(1-γ)*v^γ) :
    overlapG γ z*Real.exp (-D)≤overlapA γ z*u+overlapB γ z*v := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hm := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_right hprod (Real.rpow_nonneg (div_nonneg hc.1.le hd.le) (1-γ)))
    (Real.rpow_nonneg (div_nonneg hc.2.2.1.le hγ.le) γ)
  rw [overlapG_factor hγ hγ1 hz hz1]
  have hw := weighted_product_lower_linear hγ hγ1 hc.1 hc.2.2.1 hu hv
  nlinarith only [hm,hw]

lemma coupled_lower_power_identity {γ Z Y C D : ℝ} (hγ : 0<γ) (hγ1 : γ<1)
    (hZ : 0≤Z) (hY : 0≤Y) :
    (Real.exp (-C*γ)*(Z/γ)^γ)^(1-γ)*
      (Real.exp (-D*(1-γ))*(Y/(1-γ))^(1-γ))^γ =
      Real.exp (-(C+D)*(γ*(1-γ)))*(Z*Y/(γ*(1-γ)))^(γ*(1-γ)) := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hZq := div_nonneg hZ hγ.le
  have hYq := div_nonneg hY hd.le
  rw [Real.mul_rpow (Real.exp_pos _).le (Real.rpow_nonneg hZq γ),
    Real.mul_rpow (Real.exp_pos _).le (Real.rpow_nonneg hYq (1-γ)),
    ←Real.exp_mul,←Real.exp_mul,←Real.rpow_mul hZq,←Real.rpow_mul hYq,
    show (1-γ)*γ=γ*(1-γ) by ring]
  calc
    _ = (Real.exp (-C*γ*(1-γ))*Real.exp (-D*(1-γ)*γ))*
        ((Z/γ)^(γ*(1-γ))*(Y/(1-γ))^(γ*(1-γ))) := by ring
    _ = _ := by
      rw [←Real.exp_add,←Real.mul_rpow hZq hYq]
      have hq : Z/γ*(Y/(1-γ))=Z*Y/(γ*(1-γ)) := by field_simp
      rw [hq]
      congr 2
      ring

/-- The two actual sharp endpoint profiles have the required reverse product in the central interval. -/
theorem coupledProfiles_central_product_lower {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z lam0 M fL f ω x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hlam0 : 0<lam0)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hZ : (ℓ:ℝ)^2*x≤γ) (hY : (N:ℝ)^2*y≤1-γ)
    (hcap : lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤((ℓ:ℝ)^2*x)*((N:ℝ)^2*y)) :
    z*Real.exp (-(2*M+1+coupledLocalLowerConstant fL+coupledLocalLowerConstant f-Real.log lam0)*(γ*(1-γ)))≤
      (Real.exp (-M*γ)*lowProfile ℓ γ fL x)^(1-γ)*
        (Real.exp (-(M+1)*(1-γ))*highProfile N (1-γ) f ω y)^γ := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hh : 0<γ*(1-γ) := mul_pos hγ hd
  have hlow := mul_le_mul_of_nonneg_left (lowProfile_local_exponential_lower hℓ hγ hγ1.le hfL hfL1 hx hx1 hZ)
    (Real.exp_pos (-M*γ)).le
  have hhigh := mul_le_mul_of_nonneg_left (highProfile_local_exponential_lower hN hd (by linarith only [hγ]) hf hf1 hω hω1 hy hy1 hY)
    (Real.exp_pos (-(M+1)*(1-γ))).le
  have hLid : Real.exp (-M*γ)*(Real.exp (-coupledLocalLowerConstant fL*γ)*(((ℓ:ℝ)^2*x)/γ)^γ)=
      Real.exp (-(M+coupledLocalLowerConstant fL)*γ)*(((ℓ:ℝ)^2*x)/γ)^γ := by
    rw [←mul_assoc,←Real.exp_add]
    congr 2
    ring
  have hRid : Real.exp (-(M+1)*(1-γ))*(Real.exp (-coupledLocalLowerConstant f*(1-γ))*(((N:ℝ)^2*y)/(1-γ))^(1-γ))=
      Real.exp (-(M+1+coupledLocalLowerConstant f)*(1-γ))*(((N:ℝ)^2*y)/(1-γ))^(1-γ) := by
    rw [←mul_assoc,←Real.exp_add]
    congr 2
    ring
  rw [hLid] at hlow
  rw [hRid] at hhigh
  have hu0 := (lowProfile_range (by omega : 0<ℓ) hγ hfL hfL1 hx hx1).1
  have hp := mul_le_mul (Real.rpow_le_rpow (by positivity) hlow hd.le)
    (Real.rpow_le_rpow (by positivity) hhigh hγ.le) (by positivity) (by positivity)
  rw [coupled_lower_power_identity hγ hγ1 (by positivity) (by positivity)] at hp
  have hq : lam0*z^(1/(γ*(1-γ)))≤(((ℓ:ℝ)^2*x)*((N:ℝ)^2*y))/(γ*(1-γ)) := by
    apply (le_div_iff₀ hh).mpr
    nlinarith only [hcap]
  have hraise := Real.rpow_le_rpow (by positivity) hq hh.le
  have hid : (lam0*z^(1/(γ*(1-γ))))^(γ*(1-γ))=Real.exp (Real.log lam0*(γ*(1-γ)))*z := by
    rw [Real.mul_rpow hlam0.le (Real.rpow_nonneg hz.le _),←Real.rpow_mul hz.le,
      one_div_mul_cancel hh.ne',Real.rpow_one,Real.rpow_def_of_pos hlam0]
  rw [hid] at hraise
  have hm := mul_le_mul_of_nonneg_left hraise
    (Real.exp_pos (-(M+coupledLocalLowerConstant fL+(M+1+coupledLocalLowerConstant f))*(γ*(1-γ)))).le
  have heq : Real.exp (-(M+coupledLocalLowerConstant fL+(M+1+coupledLocalLowerConstant f))*(γ*(1-γ)))*
      (Real.exp (Real.log lam0*(γ*(1-γ)))*z)=
      z*Real.exp (-(2*M+1+coupledLocalLowerConstant fL+coupledLocalLowerConstant f-Real.log lam0)*(γ*(1-γ))) := by
    rw [←mul_assoc,←Real.exp_add,mul_comm]
    congr 2
    ring
  rw [heq] at hm
  exact hm.trans hp

def coupledCentralLoss (fL f M lam0 : ℝ) : ℝ :=
  2*M+1+coupledLocalLowerConstant fL+coupledLocalLowerConstant f-Real.log lam0

def coupledReservedBase (ℓ N : ℕ) (γ z M fL f ω x y : ℝ) : ℝ :=
  (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ fL x+
    (overlapB γ z*Real.exp (-(M+1)*(1-γ)))*highProfile N (1-γ) f ω y

def coupledHighReserve (N : ℕ) (γ z M f ω y : ℝ) : ℝ :=
  (overlapB γ z*Real.exp (-M*(1-γ))-overlapB γ z*Real.exp (-(M+1)*(1-γ)))*
    highProfile N (1-γ) f ω y

/-- The actual reserved two-arm base has its central overlap lower bound. -/
theorem coupledProfiles_central_base_lower {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z lam0 M fL f ω x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1) (hlam0 : 0<lam0)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hZ : (ℓ:ℝ)^2*x≤γ) (hY : (N:ℝ)^2*y≤1-γ)
    (hcap : lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤((ℓ:ℝ)^2*x)*((N:ℝ)^2*y)) :
    overlapG γ z*Real.exp (-coupledCentralLoss fL f M lam0*(γ*(1-γ)))≤
      coupledReservedBase ℓ N γ z M fL f ω x y := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hprod := coupledProfiles_central_product_lower (M:=M) hℓ hN hγ hγ1 hz hlam0 hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hZ hY hcap
  have hu0 := (lowProfile_range (by omega : 0<ℓ) hγ hfL hfL1 hx hx1).1
  have hv0 := (highProfile_range (by omega : 0<N) hd hf hf1.le hω hω1 hy hy1).1
  have h := overlap_approximate_lower_bound
    (D:=coupledCentralLoss fL f M lam0*(γ*(1-γ))) hγ hγ1 hz hz1
    (mul_nonneg (Real.exp_pos (-M*γ)).le hu0)
    (mul_nonneg (Real.exp_pos (-(M+1)*(1-γ))).le hv0)
    (by simpa only [coupledCentralLoss,neg_mul] using hprod)
  unfold coupledReservedBase
  simpa only [neg_mul,mul_assoc] using h

lemma highProfile_local_linear_lower {N : ℕ} (hN : 2≤N) {s f ω x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : (N:ℝ)^2*x≤s) :
    Real.exp (-coupledLocalLowerConstant f)*((N:ℝ)^2*x)≤s*highProfile N s f ω x := by
  have hC := coupledLocalLowerConstant_nonneg hf hf1
  have hY : 0≤(N:ℝ)^2*x := by positivity
  have hquot0 : 0≤((N:ℝ)^2*x)/s := div_nonneg hY hs.le
  have hquot1 : ((N:ℝ)^2*x)/s≤1 := (div_le_one hs).mpr hy
  have hpow : ((N:ℝ)^2*x)/s≤(((N:ℝ)^2*x)/s)^s := by
    by_cases hq0 : ((N:ℝ)^2*x)/s=0
    · rw [hq0,Real.zero_rpow hs.ne']
    · have hp := Real.rpow_le_rpow_of_exponent_ge (lt_of_le_of_ne hquot0 (Ne.symm hq0)) hquot1 hs1
      simpa only [Real.rpow_one] using hp
  have hexp : Real.exp (-coupledLocalLowerConstant f)≤Real.exp (-coupledLocalLowerConstant f*s) :=
    Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_left hs1 hC])
  have hm := mul_le_mul hexp hpow hquot0 (Real.exp_pos _).le
  have hlocal := highProfile_local_exponential_lower hN hs hs1 hf hf1 hω hω1 hx hx1 hy
  have hscale := mul_le_mul_of_nonneg_left (hm.trans hlocal) hs.le
  have hid : s*(Real.exp (-coupledLocalLowerConstant f)*(((N:ℝ)^2*x)/s))=
      Real.exp (-coupledLocalLowerConstant f)*((N:ℝ)^2*x) := by field_simp
  rwa [hid] at hscale

def coupledReserveConstant (f E M : ℝ) : ℝ :=
  (1-Real.exp (-E))*Real.exp (-M)*Real.exp (-coupledLocalLowerConstant f)/2

theorem coupledReserveConstant_pos {f E M : ℝ} (hE : 0<E) : 0<coupledReserveConstant f E M := by
  have he : 0<1-Real.exp (-E) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  unfold coupledReserveConstant
  positivity

/-- Reserving a fixed exponential fraction of the actual high arm supplies its local linear gain. -/
theorem coupledProfiles_high_reserve_lower {N : ℕ} (hN : 2≤N)
    {γ z E M f ω y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hE : 0<E) (hzE : z≤Real.exp (-E)) (hM : 0≤M)
    (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hy : 0≤y) (hy1 : y≤1) (hY : (N:ℝ)^2*y≤1-γ) :
    coupledReserveConstant f E M*overlapG γ z*((N:ℝ)^2*y)≤coupledHighReserve N γ z M f ω y := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hG := overlapG_mem_Ioo hγ hγ1 hz hz1
  have hB : 1-Real.exp (-E)≤overlapB γ z := by
    have hh := overlap_complement_le_parameter hγ hγ1 hz hz1
    linarith only [hh,hzE]
  have he0 : 0≤1-Real.exp (-E) := sub_nonneg.mpr (Real.exp_le_one_iff.mpr (by linarith only [hE]))
  have hMexp : Real.exp (-M)≤Real.exp (-M*(1-γ)) := Real.exp_le_exp.mpr (by nlinarith only [mul_nonneg hM hγ.le])
  have hexp := exp_neg_le_linear_half hd.le hd1
  have hid : Real.exp (-(M+1)*(1-γ))=Real.exp (-M*(1-γ))*Real.exp (-(1-γ)) := by
    rw [←Real.exp_add]
    congr 1
    ring
  have hdiff : (1-Real.exp (-E))*Real.exp (-M)*((1-γ)/2)≤
      overlapB γ z*Real.exp (-M*(1-γ))-overlapB γ z*Real.exp (-(M+1)*(1-γ)) := by
    have hm := mul_le_mul hB hMexp (Real.exp_pos (-M)).le hc.2.2.1.le
    have hm' := mul_le_mul_of_nonneg_right hm (show 0≤(1-γ)/2 by positivity)
    have hhalf := mul_le_mul_of_nonneg_left hexp
      (mul_nonneg hc.2.2.1.le (Real.exp_pos (-M*(1-γ))).le)
    rw [hid]
    nlinarith only [hm',hhalf]
  have hv0 := (highProfile_range (by omega : 0<N) hd hf hf1.le hω hω1 hy hy1).1
  have hlocal := highProfile_local_linear_lower hN hd hd1 hf hf1 hω hω1 hy hy1 hY
  have hdiffv := mul_le_mul_of_nonneg_right hdiff hv0
  have hlin := mul_le_mul_of_nonneg_left hlocal
    (show 0≤(1-Real.exp (-E))*Real.exp (-M)/2 by positivity)
  have hgain : coupledReserveConstant f E M*((N:ℝ)^2*y)≤coupledHighReserve N γ z M f ω y := by
    unfold coupledReserveConstant coupledHighReserve
    nlinarith only [hdiffv,hlin]
  have hκ := mul_le_of_le_one_left (show 0≤coupledReserveConstant f E M*((N:ℝ)^2*y) by
    exact mul_nonneg (coupledReserveConstant_pos hE).le (by positivity)) hG.2.le
  nlinarith only [hκ,hgain]

end Renyi
