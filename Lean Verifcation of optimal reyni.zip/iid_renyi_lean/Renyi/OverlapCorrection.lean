import Renyi.Foundations
import Mathlib.Analysis.Convex.SpecificFunctions.Basic

/-! Uniform logarithmic overlap correction, with an explicit constant. -/
noncomputable section
namespace Renyi

def overlapLogTail (t : ℝ) : ℝ := -Real.log (1 - Real.exp (-t))

def overlapCorrection (γ t : ℝ) : ℝ :=
  (1 - γ) * overlapLogTail ((1 - γ) * t) + γ * overlapLogTail (γ * t) -
    overlapLogTail t

theorem one_sub_exp_neg_pos {t : ℝ} (ht : 0 < t) : 0 < 1 - Real.exp (-t) := by
  have h := Real.exp_lt_one_iff.mpr (neg_neg_of_pos ht)
  linarith

theorem overlapLogTail_nonneg {t : ℝ} (ht : 0 < t) : 0 ≤ overlapLogTail t := by
  have h := Real.log_nonpos (one_sub_exp_neg_pos ht).le
    (by linarith [Real.exp_pos (-t)] : 1 - Real.exp (-t) ≤ 1)
  exact neg_nonneg.mpr h

theorem overlapLogTail_antitone {s t : ℝ} (hs : 0 < s) (hst : s ≤ t) :
    overlapLogTail t ≤ overlapLogTail s := by
  have he := Real.exp_le_exp.mpr (neg_le_neg hst)
  exact neg_le_neg (Real.log_le_log (one_sub_exp_neg_pos hs) (by linarith))

theorem exp_tail_fractional_lower {t : ℝ} (ht : 0 < t) :
    t / (1 + t) ≤ 1 - Real.exp (-t) := by
  have he := Real.add_one_le_exp t
  have hexp := Real.exp_pos t
  rw [Real.exp_neg]
  apply (div_le_iff₀ (by linarith : 0 < 1 + t)).2
  have h : (t + 1) / Real.exp t ≤ 1 :=
    (div_le_iff₀ hexp).2 (by simpa only [one_mul] using he)
  have h' : (1 + t) * (Real.exp t)⁻¹ ≤ 1 := by
    simpa only [div_eq_mul_inv, mul_one, add_comm] using h
  nlinarith

theorem overlapLogTail_le_log {t : ℝ} (ht : 0 < t) :
    overlapLogTail t ≤ Real.log (1 + 1 / t) := by
  have h := Real.log_le_log (by positivity : 0 < t / (1 + t))
    (exp_tail_fractional_lower ht)
  have hid : -Real.log (t / (1 + t)) = Real.log (1 + 1 / t) := by
    rw [← Real.log_inv]
    congr 1
    field_simp
    ring
  unfold overlapLogTail
  linarith

theorem overlapLogTail_le_recip {t : ℝ} (ht : 0 < t) : overlapLogTail t ≤ 1 / t := by
  exact (overlapLogTail_le_log ht).trans
    (by have h := Real.log_le_sub_one_of_pos (by positivity : 0 < 1 + 1 / t); linarith)

theorem overlapLogTail_scaled_difference {b t : ℝ} (hb : 0 < b) (hb1 : b ≤ 1)
    (ht : 0 < t) : overlapLogTail (b * t) - overlapLogTail t ≤ (1 - b) / b := by
  have hbt : 0 < b * t := mul_pos hb ht
  have hconc := convexOn_exp.2 (Set.mem_univ (0 : ℝ)) (Set.mem_univ (-t))
    (by linarith : 0 ≤ 1 - b) hb.le (by ring : 1 - b + b = 1)
  simp only [smul_eq_mul, mul_zero, zero_add, Real.exp_zero, mul_one] at hconc
  have hden : b * (1 - Real.exp (-t)) ≤ 1 - Real.exp (-(b * t)) := by
    rw [show b * -t = -(b * t) by ring] at hconc
    linarith
  have hratio : (1 - Real.exp (-t)) / (1 - Real.exp (-(b * t))) ≤ 1 / b := by
    apply (div_le_div_iff₀ (one_sub_exp_neg_pos hbt) hb).2
    nlinarith
  have hid : overlapLogTail (b * t) - overlapLogTail t =
      Real.log ((1 - Real.exp (-t)) / (1 - Real.exp (-(b * t)))) := by
    rw [Real.log_div (ne_of_gt (one_sub_exp_neg_pos ht))
      (ne_of_gt (one_sub_exp_neg_pos hbt))]
    unfold overlapLogTail
    ring
  rw [hid]
  have hl := Real.log_le_sub_one_of_pos
    (div_pos (one_sub_exp_neg_pos ht) (one_sub_exp_neg_pos hbt))
  have hcalc : 1 / b - 1 = (1 - b) / b := by field_simp
  linarith

theorem overlapLogTail_capacity_comparison {a b t : ℝ}
    (ha : 0 < a) (hb : 1 / 2 ≤ b) (hb1 : b ≤ 1) (ht : 0 < t) :
    0 ≤ Real.log (1 + 1 / (a * b * t)) - overlapLogTail (a * t) ∧
    Real.log (1 + 1 / (a * b * t)) - overlapLogTail (a * t) ≤ 2 := by
  have hbpos : 0 < b := by linarith
  have hat : 0 < a * t := mul_pos ha ht
  have hab : 0 < a * b * t := by positivity
  have hrecip : 1 / (a * t) ≤ 1 / (a * b * t) :=
    one_div_le_one_div_of_le hab (by nlinarith)
  have hlogs : Real.log (1 + 1 / (a * t)) ≤ Real.log (1 + 1 / (a * b * t)) :=
    Real.log_le_log (by positivity : 0 < 1 + 1 / (a * t)) (by linarith)
  have hlower := (overlapLogTail_le_log hat).trans hlogs
  refine ⟨sub_nonneg.mpr hlower, ?_⟩
  have hsmall : 1 - Real.exp (-(a * t)) ≤ a * t := by
    have h := Real.add_one_le_exp (-(a * t))
    linarith
  have hunit : 1 - Real.exp (-(a * t)) ≤ 1 := by linarith [Real.exp_pos (-(a * t))]
  have hquot : (1 - Real.exp (-(a * t))) / (a * b * t) ≤ 2 := by
    apply (div_le_iff₀ hab).2
    nlinarith
  have hprod : (1 + 1 / (a * b * t)) * (1 - Real.exp (-(a * t))) ≤ 3 := by
    have hid : (1 + 1 / (a * b * t)) * (1 - Real.exp (-(a * t))) =
        (1 - Real.exp (-(a * t))) + (1 - Real.exp (-(a * t))) / (a * b * t) := by ring
    rw [hid]
    linarith
  have hid : Real.log (1 + 1 / (a * b * t)) - overlapLogTail (a * t) =
      Real.log ((1 + 1 / (a * b * t)) * (1 - Real.exp (-(a * t)))) := by
    rw [Real.log_mul (by positivity : 1 + 1 / (a * b * t) ≠ 0)
      (ne_of_gt (one_sub_exp_neg_pos hat))]
    unfold overlapLogTail
    ring
  rw [hid]
  have hp : 0 < (1 + 1 / (a * b * t)) * (1 - Real.exp (-(a * t))) :=
    mul_pos (by positivity) (one_sub_exp_neg_pos hat)
  have hl := Real.log_le_sub_one_of_pos hp
  linarith

/-- Explicit uniform estimate when the smaller endpoint weight is a. -/
theorem overlapCorrection_bound_half {a t η : ℝ} (ha : 0 < a)
    (ha1 : a ≤ 1 / 2) (hη : 0 < η) (htη : η ≤ t) :
    |overlapCorrection a t / (a * (1 - a)) -
      Real.log (1 + 1 / (a * (1 - a) * t))| ≤ 2 + 2 / η := by
  let b := 1 - a
  have hb : 1 / 2 ≤ b := by dsimp [b]; linarith
  have hbpos : 0 < b := by linarith
  have hb1 : b ≤ 1 := by dsimp [b]; linarith
  have ht : 0 < t := hη.trans_le htη
  have hat : 0 < a * t := mul_pos ha ht
  have hbt : 0 < b * t := mul_pos hbpos ht
  have hdiff0 : 0 ≤ overlapLogTail (b * t) - overlapLogTail t :=
    sub_nonneg.mpr (overlapLogTail_antitone hbt (by nlinarith))
  have hdiff := overlapLogTail_scaled_difference hbpos hb1 ht
  have hab : 1 - b = a := by dsimp [b]; ring
  rw [hab] at hdiff
  have habdiv : a / b ≤ 2 * a := by
    apply (div_le_iff₀ hbpos).2
    nlinarith
  have hfirst0 : 0 ≤ (overlapLogTail (b * t) - overlapLogTail t) / a :=
    div_nonneg hdiff0 ha.le
  have hfirst : (overlapLogTail (b * t) - overlapLogTail t) / a ≤ 2 :=
    (div_le_iff₀ ha).2 (by linarith)
  have hrecip : 1 / (b * t) ≤ 2 / t := by
    apply (div_le_div_iff₀ hbt ht).2
    nlinarith
  have hpos0 : 0 ≤ a / b * overlapLogTail (a * t) :=
    mul_nonneg (div_nonneg ha.le hbpos.le) (overlapLogTail_nonneg hat)
  have hpos : a / b * overlapLogTail (a * t) ≤ 2 / t := by
    calc
      a / b * overlapLogTail (a * t) ≤ a / b * (1 / (a * t)) :=
        mul_le_mul_of_nonneg_left (overlapLogTail_le_recip hat) (by positivity)
      _ = 1 / (b * t) := by field_simp
      _ ≤ 2 / t := hrecip
  have hneg0 : 0 ≤ overlapLogTail t / b :=
    div_nonneg (overlapLogTail_nonneg ht) hbpos.le
  have hneg : overlapLogTail t / b ≤ 2 / t := by
    calc
      overlapLogTail t / b ≤ (1 / t) / b :=
        div_le_div_of_nonneg_right (overlapLogTail_le_recip ht) hbpos.le
      _ = 1 / (b * t) := by field_simp
      _ ≤ 2 / t := hrecip
  have hcap := overlapLogTail_capacity_comparison ha hb hb1 ht
  have hid : overlapCorrection a t / (a * b) =
      (overlapLogTail (b * t) - overlapLogTail t) / a +
      a / b * overlapLogTail (a * t) - overlapLogTail t / b +
      overlapLogTail (a * t) := by
    unfold overlapCorrection
    change (b * overlapLogTail (b * t) + a * overlapLogTail (a * t) -
      overlapLogTail t) / (a * b) = _
    field_simp
    dsimp [b]
    ring
  have hηrecip : 2 / t ≤ 2 / η := by
    exact div_le_div_of_nonneg_left (by norm_num) hη htη
  change |overlapCorrection a t / (a * b) - Real.log (1 + 1 / (a * b * t))| ≤ _
  rw [hid, abs_le]
  constructor <;> linarith [hcap.1, hcap.2]

/-- The overlap correction estimate, uniform all the way to either integer.
For every t ≥ η > 0 the error is at most the explicit constant 2 + 2/η. -/
theorem overlapCorrection_uniform {γ t η : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hη : 0 < η) (htη : η ≤ t) :
    |overlapCorrection γ t / (γ * (1 - γ)) -
      Real.log (1 + 1 / (γ * (1 - γ) * t))| ≤ 2 + 2 / η := by
  by_cases hhalf : γ ≤ 1 / 2
  · exact overlapCorrection_bound_half hγ hhalf hη htη
  · have hδ : 0 < 1 - γ := by linarith
    have hδhalf : 1 - γ ≤ 1 / 2 := by linarith
    have h := overlapCorrection_bound_half hδ hδhalf hη htη
    have hsym : overlapCorrection (1 - γ) t = overlapCorrection γ t := by
      unfold overlapCorrection
      rw [show 1 - (1 - γ) = γ by ring]
      ring
    have hprod : (1 - γ) * (1 - (1 - γ)) = γ * (1 - γ) := by ring
    rwa [hsym, hprod] at h

end Renyi
