import Renyi.NearOneHistogram
import Renyi.NearOneIIDParameters
import Renyi.NearOneIIDCertificate
import Renyi.NearOneVarianceSource

/-! The complete near-one iid upper bound with all auxiliary parameters chosen. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- Uniform near-one achievability in the actual iid statistical model. -/
theorem near_one_iid_upper_uniform {eps:ℝ} (heps:0<eps) :
    ∃C:ℝ,0<C ∧ ∃K:ℕ,1≤K ∧ ∀k:ℕ,K≤k → ∀alpha:ℝ,1<alpha → alpha≤3/2 →
      ∃m:ℕ,(m:ℝ)≤C*(alpha*(k:ℝ)^(1-1/alpha)*rootMultiplier k alpha eps) ∧
        Achievable k m alpha eps := by
  obtain ⟨cu,B,CL,cpR,hcu,hB,hCL,hcp,hcpExp,hmeanParameters⟩:=near_one_iid_mean_parameters heps
  let cp:ℝ≥0:=⟨cpR,by linarith only [hcp]⟩
  have hcpcoe:(cp:ℝ)=cpR:=rfl
  obtain ⟨Kv,hKv,hvariance⟩:=nearOneHistogramStatistic_variance_uniform
    heps hcu.le hCL (by linarith only [hB]) cp hcp hcpExp
  let cm:=nearOneMarginConstant eps (1/2)
  have hcm:0<cm:=nearOneMarginConstant_pos heps (by norm_num) (by norm_num)
  obtain ⟨cL,hcL,hcL1,hvarianceParameters⟩:=near_one_variance_budget_source_calibrated
    (eps:=eps) (CL:=CL) (K:=Kv) (cp:=cpR) (B:=B) (eta:=cm^2/16)
    heps hCL hKv (by linarith only [hcp]) (by linarith only [hB]) (by positivity)
  obtain ⟨D0,hD0,hmean⟩:=hmeanParameters cL hcL
  let D:=max D0 (max 1 (3*Real.log 12))
  have hD0D:D0≤D:=le_max_left _ _
  have hD1:1≤D:=(le_max_left _ _).trans (le_max_right _ _)
  have hDtail:3*Real.log 12≤D:=(le_max_right _ _).trans (le_max_right _ _)
  have hD:0<D:=zero_lt_one.trans_le hD1
  obtain ⟨k0,hsmall⟩:=hvarianceParameters D hD
  let C:=3*(1+cpR)*D
  have hcp0:0<cpR:=by linarith only [hcp]
  have hC:0<C:=by dsimp [C]; positivity
  refine ⟨C,hC,max 1 k0,le_max_left _ _,?_⟩
  intro k hk alpha ha ha1
  have hk0:k0≤k:=(le_max_right _ _).trans hk
  have hkpos:0<k:=lt_of_lt_of_le (by norm_num : 0<1) ((le_max_left _ _).trans hk)
  let N:=upperDegree alpha CL cL (rootMultiplier k alpha eps)
  let F:=nearOneHistogramStatistic k N alpha eps 0 D 1 1 CL cL 1 0 (1/2) (1/2) cu 1 cp B 0
  have hg:0<fractionalPart alpha:=by rw [(near_one_order ha ha1).2]; linarith only [ha]
  have hg1:fractionalPart alpha<1:=by rw [(near_one_order ha ha1).2]; linarith only [ha1]
  have hNr:0<(N:ℝ):=upperDegree_pos ha hCL hcL (one_le_rootMultiplier ha hg hg1)
  have hN:0<N:=by exact_mod_cast hNr
  have hstat:∀p:Simplex k,
      let mu:=(pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure
      MemLp F 2 mu ∧
      |(∫h,F h ∂mu)-upperOmega k alpha eps 0 (1/2)*powerSum p alpha|≤
        nearOneMarginConstant eps (1/2)*(alpha-1)*powerSum p alpha/2 ∧
      variance F mu≤(nearOneMarginConstant eps (1/2))^2*(alpha-1)^2*(powerSum p alpha)^2/16 := by
    intro p
    dsimp only
    have hv:=hvariance cL hcL k alpha D hkpos ha ha1 hD p
    dsimp only at hv
    refine ⟨hv.1,?_,hv.2.trans ?_⟩
    · dsimp only [F]
      rw [nearOneHistogramStatistic_mean hkpos ha ha1 hD (by norm_num) hCL hcL hN cp p]
      exact hmean k alpha D hkpos ha ha1 hD0D p
    · have hs:=hsmall k hk0 alpha ha ha1 p
      convert hs using 1
      dsimp only [cm,N]
      ring
  have hfinal:=near_one_iid_of_histogram_moments hkpos ha ha1 heps (by norm_num)
    (by norm_num : (0:ℝ)<1/2) (by norm_num : (1/2:ℝ)<1) hD1 hDtail cp F hstat
  simpa only [hcpcoe] using hfinal


/-- The same result expressed directly using the public unsaturated rate. -/
theorem near_one_iid_rate_upper_uniform {eps:ℝ} (heps:0<eps) :
    ∃C:ℝ,0<C ∧ ∃K:ℕ,1≤K ∧ ∀k:ℕ,K≤k → ∀alpha:ℝ,1<alpha → alpha≤3/2 →
      alpha<Real.log k → ∃m:ℕ,(m:ℝ)≤C*rate k alpha eps ∧ Achievable k m alpha eps := by
  obtain ⟨C,hC,K,hK,hupper⟩:=near_one_iid_upper_uniform heps
  refine ⟨C,hC,K,hK,?_⟩
  intro k hk alpha ha ha1 horder
  have hnotint:¬∃r:ℕ,alpha=(r:ℝ):=by
    rintro ⟨r,hr⟩
    have hr1:(1:ℝ)<r:=by rw [←hr]; exact ha
    have hrN:1<r:=by exact_mod_cast hr1
    have hr2:(2:ℝ)≤r:=by exact_mod_cast (show 2≤r by omega)
    rw [hr] at ha1
    linarith only [hr2,ha1]
  obtain ⟨m,hm,hach⟩:=hupper k hk alpha ha ha1
  refine ⟨m,?_,hach⟩
  simpa only [rate,extendedMultiplier,if_neg (not_le.mpr horder),if_neg hnotint] using hm

end Renyi
