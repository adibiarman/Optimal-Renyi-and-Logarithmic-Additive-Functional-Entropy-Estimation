import Renyi.ActualConditionalCount
import Renyi.ActualCoupledPolynomial
import Renyi.PilotCountScaling

/-! Exact bridge from the count calibration polynomial to the common estimator polynomial. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

theorem actualUpperPolynomial_eq_actualCoupledPolynomial
    (k : ℕ) (alpha eps Ch D cb lambda CL cL fL f M : ℝ) :
    actualUpperPolynomial k alpha eps Ch D cb lambda CL cL fL f M (1 / 8) =
      actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M := by
  unfold actualUpperPolynomial actualCoupledPolynomial upperOmega
  congr 2
  ring

/-- The fully calibrated count certificate for the exact common coupled polynomial.
Every design constant is chosen before all probability spaces and experiments. -/
theorem actual_coupled_conditional_count_variance_uniform_experiments
    {eps Ch cb lambda CL cp Bpilot M fL f u0 eta cLbound : ℝ}
    (heps : 0 < eps) (hCh : 0 ≤ Ch) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hlambda4 : lambda ≤ 4) (hCL : 1 ≤ CL) (hcbCL : 1 ≤ cb * CL)
    (hcp : 0 < cp) (hcpDegree : 80 / cb ≤ cp) (hBpilot : 0 < Bpilot)
    (hM : 0 ≤ M) (hfL : 0 ≤ fL) (hfL1 : fL < 1)
    (hf : 0 ≤ f) (hf1 : f ≤ 1) (hu0 : 0 < u0) (heta : 0 < eta) (hcLbound : 0 < cLbound) :
    ∃ cL C0 : ℝ, 0 < cL ∧ cL ≤ cLbound ∧ 1 ≤ C0 ∧ coupledLowCoefficientConstant ≤ C0 ∧
      ∀ db : ℝ, 0 < db → db ≤ 1 → ∃ D0 : ℝ, 1 ≤ D0 ∧ ∀ (k : ℕ) (alpha D : ℝ),
        0 < k → 3 / 2 ≤ alpha → 0 < fractionalPart alpha → fractionalPart alpha < 1 → D0 ≤ D →
        ∀ {Ω Ξ : Type*} [MeasurableSpace Ω] [MeasurableSpace Ξ] (μ : Measure Ω) (ν : Measure Ξ),
        ∀ (p : Simplex k) (Counts : Fin k → Ω → ℕ) (Pilot : Fin k → Ξ → ℕ) (lam : Fin k → ℝ≥0),
        (∀ i, MeasurePreserving (Counts i) μ (poissonMeasure (lam i))) →
        Pairwise (fun i j => IndepFun (Counts i) (Counts j) μ) →
        (∀ i, MeasurePreserving (Pilot i) ν
          (poissonMeasure ⟨cp * lam i, mul_nonneg hcp.le (lam i).coe_nonneg⟩)) →
        (∀ i, (lam i : ℝ) = upperSample k alpha eps D * p.mass i) →
        pilotAveragedCountVariance Counts Pilot (cp * Bpilot * alpha)
          (upperCountDegree k alpha eps CL cL)
          (actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).coeff
          (upperSample k alpha eps D) μ ν ≤
        eta * (upperActualBaseline k alpha C0 db (upperA k alpha eps Ch D cb lambda CL cL) *
            (k : ℝ) ^ (1 - alpha) +
          upperKappa alpha eps * upperU k alpha eps u0 * powerSum p alpha +
          min (alpha - 1) 1 * upperKappa alpha eps * conditionalCountBonus p.mass alpha (upperSample k alpha eps D)
            (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)) ^ 2 := by
  simpa only [actualUpperPolynomial_eq_actualCoupledPolynomial] using
    actual_upper_conditional_count_variance_uniform_experiments heps hCh hcb hlambda hlambda4 hCL hcbCL
      hcp hcpDegree hBpilot hM (by norm_num : (0 : ℝ) < 1 / 8) hfL hfL1 hf hf1 hu0 heta hcLbound

end Renyi
