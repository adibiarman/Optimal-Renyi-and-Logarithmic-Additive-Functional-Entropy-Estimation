import Renyi.NearOneActualCoefficients
import Renyi.NearOneAffineCoefficients
import Renyi.UpperRescaling

/-! Affine cancellation for the actual rescaled near-one estimator polynomial. -/
noncomputable section
open Polynomial
namespace Renyi

lemma affine_rescaling_error {q t β s ω F Cs Cw : ℝ}
    (ht : 0<t) (hs : 0≤s) (hs1 : s≤1)
    (hq : |q-ω*t^β|≤F*β*t^β) (hsclose : |s-1|≤Cs*β)
    (hwclose : |ω-1|≤Cw*β) :
    |s*q-t^β|≤(F+Cs+Cw)*β*t^β := by
  have hid : s*q-t^β=s*(q-ω*t^β)+(s*ω-1)*t^β := by ring
  have hwid : s*ω-1=s*(ω-1)+(s-1) := by ring
  have hw : |s*ω-1|≤(Cs+Cw)*β := by
    rw [hwid]
    apply (abs_add_le _ _).trans
    rw [abs_mul,abs_of_nonneg hs]
    have hh := (mul_le_of_le_one_left (abs_nonneg _) hs1).trans hwclose
    linarith only [hh,hsclose]
  rw [hid]
  apply (abs_add_le _ _).trans
  rw [abs_mul,abs_mul,abs_of_nonneg hs,abs_of_nonneg (Real.rpow_nonneg ht.le β)]
  have hh := (mul_le_of_le_one_left (abs_nonneg _) hs1).trans hq
  have hh2 := mul_le_mul_of_nonneg_right hw (Real.rpow_nonneg ht.le β)
  nlinarith only [hh,hh2]

/-- The actual q0 and q1 satisfy the sharp beta bounds, including the actual rescaling. -/
theorem actual_near_one_affine_uniform {eps cb lambda CL cL cmin q Q M cw f cu u0 : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcL : 0<cL) (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hcu : 0≤cu) (hu0 : 0<u0) :
    ∃ K : ℝ, 0<K ∧ ∀ (k N : ℕ) (alpha Ch D c : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) →
      let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
        (upperRescaling k alpha eps cu u0)
      let t := upperB k alpha eps D cb CL cL/(N:ℝ)^2
      |P.coeff 0|≤K*(alpha-1)*t^alpha ∧
      |P.coeff 1-t^(alpha-1)|≤K*(alpha-1)*t^(alpha-1) ∧
      |P.coeff 1|≤(K+1)*t^(alpha-1) := by
  obtain ⟨Ca,hCa,ha⟩ := near_one_attenuated_amplitudes_uniform heps hM hcw hcw1
  obtain ⟨lo,hi,hlo,_hhi,hratio⟩ := near_one_variable_tangent_compact heps hcb hlambda hCL hcL hcmin hq hQ
  let ML := |Real.log lo|+|Real.log hi|
  let F := nearOneAffineConstant ML Ca
  let K := Real.exp (2*ML)+F+2*cu+2*cw*eps+1
  have hML : 0≤ML := add_nonneg (abs_nonneg _) (abs_nonneg _)
  have hF : 0<F := by dsimp [F,nearOneAffineConstant];positivity
  have hK : 0<K := by dsimp [K];positivity
  have hK0 : Real.exp (2*ML)≤K := by
    dsimp [K]
    nlinarith only [hF,hcu,mul_pos hcw heps]
  have hK1 : F+2*cu+2*cw*eps≤K := by dsimp [K];linarith [Real.exp_pos (2*ML)]
  refine ⟨K,hK,?_⟩
  intro k N alpha Ch D c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
  dsimp only
  let t := upperB k alpha eps D cb CL cL/(N:ℝ)^2
  let τ := c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1)
  let r := τ/t
  let A := overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(alpha-1))
  let B := overlapB (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(2-alpha))
  let ω := upperOmega k alpha eps Ch cw
  let s := upperRescaling k alpha eps cu u0
  have hβ : 0<alpha-1 := sub_pos.mpr halpha
  have hβ1 : alpha-1≤1 := by linarith only [halpha1]
  have hg : 0<fractionalPart alpha := by rw [(near_one_order halpha halpha1).2];exact hβ
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order halpha halpha1).2];linarith only [halpha1]
  have hL := upperDegree_pos halpha hCL hcL (one_le_rootMultiplier (k:=k) (ε:=eps) halpha hg hg1)
  have hNr : 0<(N:ℝ) := (mul_pos hq hL).trans_le hNlo
  have hN : 0<N := by exact_mod_cast hNr
  have hb := upperB_pos (ε:=eps) hk halpha hg hg1 hD hcb hCL hcL
  have ht : 0<t := div_pos hb (sq_pos_of_pos hNr)
  have hrange := hratio k alpha Ch D N c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
  have hr : 0<r := hlo.trans_le hrange.1
  have hlog : |Real.log r|≤ML := log_abs_of_compact hlo hrange.1 hrange.2
  have hamp := ha k alpha Ch halpha halpha1 hCh
  have hE := upper_reserved_interval (k:=k) halpha hg hg1 heps hCh
  have hEpos : 0<upperE0 k alpha eps Ch := (mul_pos heps hβ).trans_le hE.1
  have hz := (upperOverlapZ_spec hg hg1 hEpos).1
  have hcoeff := overlap_coefficients_unit hg hg1 hz.1 hz.2
  have hA0 : 0≤A := mul_nonneg hcoeff.1.le (Real.exp_pos _).le
  have hA1 : A≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hcoeff.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hβ]))
  have hs := upperRescaling_near_one (k:=k) (eps:=eps) halpha halpha1 hcu hu0
  have hw1 : ω≤1 := (Real.exp_le_one_iff.mpr (by nlinarith only [hcw,hEpos]))
  have hwclose : |ω-1|≤(2*cw*eps)*(alpha-1) := by
    rw [abs_of_nonpos (sub_nonpos.mpr hw1)]
    have hh := (upperOmega_near_one_margins (k:=k) halpha halpha1 hg hg1 heps hCh hcw hcw1).2
    linarith only [hh]
  have hτid : t*r=τ := by dsimp [r];field_simp
  have hbid : t*(N:ℝ)^2=upperB k alpha eps D cb CL cL := by dsimp [t];field_simp
  let P := nearOneCoupledPolynomial N (alpha-1) τ (upperB k alpha eps D cb CL cL) f ω A B
  have hzero : |P.coeff 0|≤Real.exp (2*ML)*(alpha-1)*t^alpha := by
    have hh := nearOneCoupledPolynomial_constant_bound (N:=N) (f:=f) (ω:=ω) (B:=B) hβ.le hβ1 ht hr hlog hA0 hA1
    rw [hτid,hbid,show 1+(alpha-1)=alpha by ring] at hh
    exact hh
  have hone : |P.coeff 1-ω*t^(alpha-1)|≤F*(alpha-1)*t^(alpha-1) := by
    have hh := nearOneCoupledPolynomial_linear_bound (f:=f) (B:=B) hN hβ.le hβ1 ht hr hlog hA0 hA1 hamp.1
    rw [hτid,hbid] at hh
    exact hh
  have hone' := affine_rescaling_error ht hs.1.le hs.2.1 hone hs.2.2 hwclose
  have hzero' : |s*P.coeff 0|≤K*(alpha-1)*t^alpha := by
    rw [abs_mul,abs_of_nonneg hs.1.le]
    apply (mul_le_of_le_one_left (abs_nonneg _) hs.2.1).trans
    apply hzero.trans
    have hh := mul_le_mul_of_nonneg_right hK0 (show 0≤(alpha-1)*t^alpha by positivity)
    nlinarith only [hh]
  have hone'' : |s*P.coeff 1-t^(alpha-1)|≤K*(alpha-1)*t^(alpha-1) := by
    apply hone'.trans
    have hh := mul_le_mul_of_nonneg_right hK1 (show 0≤(alpha-1)*t^(alpha-1) by positivity)
    nlinarith only [hh]
  have honeabs : |s*P.coeff 1|≤(K+1)*t^(alpha-1) := by
    have hh := abs_add_le (s*P.coeff 1-t^(alpha-1)) (t^(alpha-1))
    rw [sub_add_cancel,abs_of_nonneg (Real.rpow_nonneg ht.le _)] at hh
    have hβK := mul_le_mul_of_nonneg_left hβ1 hK.le
    have hβK' := mul_le_mul_of_nonneg_right hβK (Real.rpow_nonneg ht.le (alpha-1))
    nlinarith only [hh,hone'',hβK']
  change |(C s*P).coeff 0|≤_ ∧ |(C s*P).coeff 1-t^(alpha-1)|≤_ ∧ |(C s*P).coeff 1|≤_
  simp only [coeff_C_mul]
  exact ⟨hzero',hone'',honeabs⟩

end Renyi
