import Renyi.LowerCalibratedPriors

/-! Explicit scalar estimates for the lower construction. The logarithmic
principal-point formula used below is the expression obtained by substituting
the regularized root equation. Its identification with the original sample
intensity is kept separate from these estimates. -/

noncomputable section
namespace Renyi

def lowerPrincipalLog (s E v ζ β logcn G : ℝ) : ℝ :=
  logcn - E / s + v / (s * (1-s)) + 4 * (s*(1-s)+v) / (1-s) +
  (1+1/(1-s))*Real.log (s/ζ) + Real.log (1-s)/s +
  2*Real.log ((β+1)/β) + G

def lowerVelocityConstant (ε c : ℝ) : ℝ := 10 + 4*c/(1-Real.exp (-ε))
def lowerPrincipalMargin (ε c : ℝ) : ℝ := 2 + 2*lowerVelocityConstant ε c/c
def lowerLogSampleConstant (ε c : ℝ) : ℝ :=
  -(1020 + 6/c + lowerPrincipalMargin ε c + 4*c/(1-Real.exp (-ε)))

set_option maxHeartbeats 1500000 in
/-- Explicit positive-active-degree perturbation calibration. No conclusion
about the principal point or perturbation is supplied as a premise. -/
theorem lower_scalar_positive_degree_with_activation {ε c s E v β η G : ℝ}
    (hε : 0 < ε) (hc : 0 < c) (hs : 0 < s) (hs1 : s ≤ 1/2)
    (hβ : 1/2 ≤ β) (hE : ε ≤ E) (hv : 0 ≤ v) (hvE : 4*v ≤ E)
    (hw : s*(1-s)+v ≤ 1/2) (hη : η ≤ 1) (hG : G ≤ 1000)
    (hvsmall : v ≤ 1/(2*lowerVelocityConstant ε c)) :
    let ζ := c*(s*(1-s)+v)/(1-Real.exp (-E))
    let A := Real.exp (lowerPrincipalLog s E v ζ β (lowerLogSampleConstant ε c) G)
    let κ := Real.exp (-E-4*(s*(1-s)+v))
    let ρ := max ((A^s/κ)*Real.exp (4*ζ*η)-1) 0
    A ≤ 1/2 ∧ 0 ≤ ρ ∧ ρ ≤ 2*lowerVelocityConstant ε c*v ∧ ρ*A ≤ ζ ∧ (0<ρ → 2*s≤lowerVelocityConstant ε c*v) := by
  dsimp only
  let ξ := 1-s
  let w := s*ξ+v
  let d := 1-Real.exp (-ε)
  let dE := 1-Real.exp (-E)
  let C := lowerVelocityConstant ε c
  let D := lowerPrincipalMargin ε c
  let ζ := c*w/dE
  let z := lowerPrincipalLog s E v ζ β (lowerLogSampleConstant ε c) G
  let A := Real.exp z
  let κ := Real.exp (-E-4*w)
  let ρ := max ((A^s/κ)*Real.exp (4*ζ*η)-1) 0
  change A ≤ 1/2 ∧ 0 ≤ ρ ∧ ρ ≤ 2*C*v ∧ ρ*A ≤ ζ ∧ (0<ρ → 2*s≤C*v)
  have hξ : 1/2 ≤ ξ := by dsimp [ξ]; linarith
  have hξpos : 0 < ξ := by linarith
  have hξ1 : ξ ≤ 1 := by dsimp [ξ]; linarith
  have hwpos : 0 < w := add_pos_of_pos_of_nonneg (mul_pos hs hξpos) hv
  have hw1 : w ≤ 1/2 := hw
  have hd : 0 < d := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  have hdE : d ≤ dE := by
    dsimp [d, dE]
    have hh := Real.exp_le_exp.mpr (neg_le_neg hE)
    linarith
  have hdEpos : 0 < dE := hd.trans_le hdE
  have hdE1 : dE ≤ 1 := by dsimp [dE]; linarith [Real.exp_pos (-E)]
  have hζpos : 0 < ζ := div_pos (mul_pos hc hwpos) hdEpos
  have hζlo : c*w ≤ ζ := by
    apply (le_div_iff₀ hdEpos).mpr
    exact mul_le_of_le_one_right (mul_nonneg hc.le hwpos.le) hdE1
  have hζhi : ζ ≤ (c/d)*w := by
    calc
      ζ ≤ c*w/d := div_le_div_of_nonneg_left (mul_pos hc hwpos).le hd hdE
      _ = (c/d)*w := by ring
  have hsw : s/2 ≤ w := by dsimp [w]; nlinarith
  have hratio : s/ζ ≤ 2/c := by
    apply (div_le_div_iff₀ hζpos hc).mpr
    have hh := mul_le_mul_of_nonneg_left hsw hc.le
    nlinarith
  have hlogratio : Real.log (s/ζ) ≤ 2/c :=
    (Real.log_le_sub_one_of_pos (div_pos hs hζpos)).trans (by linarith)
  have hcoeff : 0 ≤ 1+1/ξ ∧ 1+1/ξ ≤ 3 := by
    have hh : 1/ξ ≤ 2 := (div_le_iff₀ hξpos).mpr (by linarith)
    constructor
    · positivity
    · linarith
  have hlogterm : (1+1/ξ)*Real.log (s/ζ) ≤ 6/c := by
    calc
      _ ≤ (1+1/ξ)*(2/c) := mul_le_mul_of_nonneg_left hlogratio hcoeff.1
      _ ≤ 3*(2/c) := mul_le_mul_of_nonneg_right hcoeff.2 (by positivity)
      _ = 6/c := by ring
  have hβpos : 0 < β := by linarith
  have hbetaratio : (β+1)/β ≤ 3 := (div_le_iff₀ hβpos).mpr (by linarith)
  have hlogbeta : Real.log ((β+1)/β) ≤ 3 :=
    (Real.log_le_sub_one_of_pos (by positivity)).trans (by linarith)
  have hlogξ : Real.log ξ ≤ 0 := Real.log_nonpos hξpos.le hξ1
  have hlogξs : Real.log ξ/s ≤ 0 := div_nonpos_of_nonpos_of_nonneg hlogξ hs.le
  have hbig : -E/s+v/(s*ξ) ≤ 0 := by
    have he : v/ξ ≤ E := (div_le_iff₀ hξpos).mpr (by nlinarith)
    have hh := (div_le_div_iff_of_pos_right hs).mpr he
    rw [div_div, mul_comm ξ s] at hh
    rw [neg_div]
    linarith only [hh]
  have hwdiv : 4*w/ξ ≤ 4 := (div_le_iff₀ hξpos).mpr (by nlinarith)
  have hC : 0 < C := by dsimp [C, lowerVelocityConstant]; positivity
  have hD : 2 ≤ D := by
    change 2 ≤ 2+2*C/c
    have hh : 0 ≤ 2*C/c := by positivity
    linarith only [hh]
  have hz : z ≤ -D := by
    have hextra : 0 ≤ 4*c/d := by positivity
    change lowerLogSampleConstant ε c - E/s + v/(s*ξ) + 4*w/ξ +
      (1+1/ξ)*Real.log (s/ζ) + Real.log ξ/s + 2*Real.log ((β+1)/β) + G ≤ -D
    unfold lowerLogSampleConstant
    change -(1020+6/c+D+4*c/d) - E/s + v/(s*ξ) + 4*w/ξ +
      (1+1/ξ)*Real.log (s/ζ) + Real.log ξ/s + 2*Real.log ((β+1)/β) + G ≤ -D
    ring_nf at hbig hwdiv hlogterm hlogξs hlogbeta hG hextra ⊢
    linarith only [hbig, hwdiv, hlogterm, hlogξs, hlogbeta, hG, hextra] 
  have hA : A ≤ 1/D := by
    have hDpos : 0 < D := by linarith
    calc
      A ≤ Real.exp (-D) := Real.exp_le_exp.mpr hz
      _ = 1/Real.exp D := by rw [Real.exp_neg, one_div]
      _ ≤ 1/D := one_div_le_one_div_of_le hDpos (by linarith [Real.add_one_le_exp D])
  have hAhalf : A ≤ 1/2 := hA.trans (one_div_le_one_div_of_le (by norm_num) hD)
  have hAc : A ≤ c/(2*C) := by
    apply hA.trans
    apply (div_le_div_iff₀ (by linarith : 0 < D) (by positivity : 0 < 2*C)).mpr
    have heq : D*c = 2*c+2*C := by
      change (2+2*C/c)*c = 2*c+2*C
      field_simp [hc.ne']
    linarith
  have hpert_exp : (A^s/κ)*Real.exp (4*ζ*η) = Real.exp (s*z+E+4*w+4*ζ*η) := by
    dsimp [A, κ]
    rw [← Real.exp_mul, ← Real.exp_sub, ← Real.exp_add]
    congr 1
    ring
  have hz_s : s*z+E+4*w =
      (v+4*w)/ξ + s*(1+1/ξ)*Real.log (s/ζ) + Real.log ξ +
      s*lowerLogSampleConstant ε c + 2*s*Real.log ((β+1)/β)+s*G := by
    change s*(lowerLogSampleConstant ε c-E/s+v/(s*ξ)+4*w/ξ+
      (1+1/ξ)*Real.log (s/ζ)+Real.log ξ/s+2*Real.log ((β+1)/β)+G)+E+4*w = _
    field_simp [hs.ne', hξpos.ne']
    dsimp [ξ]
    ring
  have hw_upper : w ≤ s+v := by dsimp [w]; nlinarith
  have hvwdiv : (v+4*w)/ξ ≤ 8*s+10*v := by
    apply (div_le_iff₀ hξpos).mpr
    have hh := mul_le_mul_of_nonneg_left hξ (show 0 ≤ 8*s+10*v by positivity)
    nlinarith only [hh, hw_upper]
  have hpert4 : 4*ζ*η ≤ (4*c/d)*(s+v) := by
    calc
      4*ζ*η ≤ 4*ζ := mul_le_of_le_one_right (by positivity) hη
      _ ≤ 4*((c/d)*w) := mul_le_mul_of_nonneg_left hζhi (by norm_num)
      _ ≤ 4*((c/d)*(s+v)) := by gcongr
      _ = (4*c/d)*(s+v) := by ring
  have hzpert : s*z+E+4*w+4*ζ*η ≤ C*v-2*s := by
    rw [hz_s]
    have hls := mul_le_mul_of_nonneg_left hlogterm hs.le
    have hlb := mul_le_mul_of_nonneg_left hlogbeta (show 0 ≤ 2*s by positivity)
    have hg := mul_le_mul_of_nonneg_left hG hs.le
    have hDnonneg := mul_nonneg hs.le (show 0 ≤ D by linarith)
    unfold lowerLogSampleConstant
    change (v+4*w)/ξ+s*(1+1/ξ)*Real.log (s/ζ)+Real.log ξ+
      s*(-(1020+6/c+D+4*c/d))+2*s*Real.log ((β+1)/β)+s*G+4*ζ*η ≤
      (10+4*c/d)*v-2*s
    nlinarith only [hvwdiv, hls, hlb, hg, hDnonneg, hpert4, hlogξ, hs.le]
  have hCv : 0 ≤ C*v ∧ C*v ≤ 1 := by
    constructor
    · positivity
    · have hh := (le_div_iff₀ (show 0 < 2*C by positivity)).mp hvsmall
      nlinarith
  have hrho : ρ ≤ 2*C*v := by
    apply max_le
    · rw [hpert_exp]
      have he := Real.exp_le_exp.mpr (hzpert.trans (by nlinarith : C*v-2*s ≤ C*v))
      have ht := (abs_le.mp (Real.abs_exp_sub_one_le (x := C*v) (by simpa only [abs_of_nonneg hCv.1] using hCv.2))).2
      rw [abs_of_nonneg hCv.1] at ht
      nlinarith only [he, ht]
    · positivity
  refine ⟨hAhalf, le_max_right _ _, hrho, ?_, ?_⟩
  · have hApos : 0 < A := Real.exp_pos _
    calc
      ρ*A ≤ (2*C*v)*(c/(2*C)) := mul_le_mul hrho hAc hApos.le (by positivity)
      _ = c*v := by
        rw [mul_comm (2*C) v, mul_assoc, mul_div_cancel₀ _ (by positivity : 2*C ≠ 0)]
        ring
      _ ≤ c*w := by dsimp [w]; nlinarith [mul_nonneg hc.le (mul_pos hs hξpos).le]
      _ ≤ ζ := hζlo
  · intro hρ
    have hp : 0 < (A^s/κ)*Real.exp (4*ζ*η)-1 := by
      have hh : 0 < max ((A^s/κ)*Real.exp (4*ζ*η)-1) 0 := hρ
      rcases (lt_max_iff.mp hh) with hh | hh
      · exact hh
      · exact False.elim (lt_irrefl _ hh)
    rw [hpert_exp] at hp
    have he : 0 < s*z+E+4*w+4*ζ*η := Real.one_lt_exp_iff.mp (by linarith)
    linarith only [he,hzpert]


/-- The principal scalar calibration, preserving its original public interface. -/
theorem lower_scalar_positive_degree {ε c s E v β η G : ℝ}
    (hε : 0 < ε) (hc : 0 < c) (hs : 0 < s) (hs1 : s ≤ 1/2)
    (hβ : 1/2 ≤ β) (hE : ε ≤ E) (hv : 0 ≤ v) (hvE : 4*v ≤ E)
    (hw : s*(1-s)+v ≤ 1/2) (hη : η ≤ 1) (hG : G ≤ 1000)
    (hvsmall : v ≤ 1/(2*lowerVelocityConstant ε c)) :
    let ζ := c*(s*(1-s)+v)/(1-Real.exp (-E))
    let A := Real.exp (lowerPrincipalLog s E v ζ β (lowerLogSampleConstant ε c) G)
    let κ := Real.exp (-E-4*(s*(1-s)+v))
    let ρ := max ((A^s/κ)*Real.exp (4*ζ*η)-1) 0
    A ≤ 1/2 ∧ 0 ≤ ρ ∧ ρ ≤ 2*lowerVelocityConstant ε c*v ∧ ρ*A ≤ ζ := by
  have h := lower_scalar_positive_degree_with_activation hε hc hs hs1 hβ hE hv hvE hw hη hG hvsmall
  exact ⟨h.1,h.2.1,h.2.2.1,h.2.2.2.1⟩


/-- The actual regularized root determines the logarithm of the sample
intensity exactly whenever its floor at one is inactive. -/
theorem regularized_root_log_intensity {k : ℕ} {α ε : ℝ}
    (hk : 0 < k) (hα : 1 < α) (hγ₀ : 0 < fractionalPart α)
    (hγ₁ : fractionalPart α < 1) (hx : 1 < rootMultiplier k α ε) :
    let γ := fractionalPart α
    let β := α-1
    let h := γ*(1-γ)
    let Ψ := γ^(1+1/(1-γ))*(1-γ)^(1+1/γ)
    let x := rootMultiplier k α ε
    let v := β/α*x^(-α)
    Real.log (α*(k : ℝ)^(-1/α)*x) =
      Real.log Ψ-Real.log α-2*Real.log β-Real.log (1+Real.log x)-1-
        (2*ε*β-v)/h := by
  let γ := fractionalPart α
  let β := α-1
  let h := γ*(1-γ)
  let Ψ := γ^(1+1/(1-γ))*(1-γ)^(1+1/γ)
  let x := rootMultiplier k α ε
  let v := β/α*x^(-α)
  have hkpos : 0 < (k : ℝ) := by exact_mod_cast hk
  have hαpos : 0 < α := by linarith
  have hβpos : 0 < β := sub_pos.mpr hα
  have hδpos : 0 < 1-γ := sub_pos.mpr hγ₁
  have hΨpos : 0 < Ψ := mul_pos (Real.rpow_pos_of_pos hγ₀ _) (Real.rpow_pos_of_pos hδpos _)
  have hxpos : 0 < x := by change 0 < rootMultiplier k α ε; linarith
  have hxlog : 0 < 1+Real.log x := by
    have hh := Real.log_pos hx
    change 0 < 1+Real.log (rootMultiplier k α ε)
    linarith
  obtain ⟨_, hslack, heq⟩ := regularized_root_slack hα hγ₀ hγ₁
  rw [hslack hx, sub_zero] at heq
  change rootQSquared k α ε/x = (1+Real.log x)*Real.exp (1-v/h) at heq
  have hlog := congrArg Real.log heq
  rw [Real.log_div (rootQSquared_pos hα hγ₀ hγ₁).ne' hxpos.ne',
    Real.log_mul hxlog.ne' (Real.exp_pos _).ne', Real.log_exp] at hlog
  have hqlog : Real.log (rootQSquared k α ε) =
      Real.log Ψ-2*Real.log α-2*Real.log β+Real.log k/α-(2*ε*β)/h := by
    change Real.log (Ψ/(α^2*β^2)*Real.exp (Real.log k/α-(2*ε*β)/h)) = _
    rw [Real.log_mul (by positivity) (Real.exp_pos _).ne',
      Real.log_div hΨpos.ne' (by positivity),
      Real.log_mul (show α^2 ≠ 0 by positivity) (show β^2 ≠ 0 by positivity), Real.log_pow, Real.log_pow, Real.log_exp]
    ring
  rw [hqlog] at hlog
  change Real.log (α*(k : ℝ)^(-1/α)*x) = _
  rw [Real.log_mul (by positivity) hxpos.ne',
    Real.log_mul hαpos.ne' (Real.rpow_pos_of_pos hkpos _).ne', Real.log_rpow hkpos]
  change Real.log α+(-1/α)*Real.log k+Real.log x =
    Real.log Ψ-Real.log α-2*Real.log β-Real.log (1+Real.log x)-1-(2*ε*β-v)/h
  rw [sub_div]
  linear_combination -hlog


set_option maxHeartbeats 1500000 in
/-- Exact Step-2 substitution: the principal point obtained from the actual
root and sample intensity has the stated logarithm. Degrees enter only
through their actual positive dimensions `ds` and `dc`. -/
theorem root_principal_ratio_log {k : ℕ} {α ε s ζ cn cm L ds dc : ℝ}
    (hk : 0 < k) (hα : 1 < α) (hγ₀ : 0 < fractionalPart α)
    (hγ₁ : fractionalPart α < 1) (hx : 1 < rootMultiplier k α ε)
    (hs : 0 < s) (hs1 : s < 1)
    (hnearest : s = fractionalPart α ∨ s = 1-fractionalPart α)
    (hζ : 0 < ζ) (hcn : 0 < cn) (hcm : 0 < cm) (hL : 0 < L)
    (hds : 0 < ds) (hdc : 0 < dc) :
    let β := α-1
    let ξ := 1-s
    let x := rootMultiplier k α ε
    let E := 2*ε*β
    let v := β/α*x^(-α)
    let w := s*ξ+v
    let κ := Real.exp (-E-4*w)
    let bs := (ζ/8)/ds^2
    let bc := ξ/dc^2
    let ac := Real.exp (-5)*bc*(ζ*κ)^(1/ξ)
    let θ := cn*α*(k : ℝ)^(-1/α)*x
    let a := θ/(cm*L*ac)
    let G := 4-Real.log (cm/8)+Real.log ((ds*dc)^2/(L*α^3*(1+Real.log x)))
    Real.log (a/bs) = lowerPrincipalLog s E v ζ β (Real.log cn) G := by
  let β := α-1
  let ξ := 1-s
  let x := rootMultiplier k α ε
  let E := 2*ε*β
  let v := β/α*x^(-α)
  let w := s*ξ+v
  let κ := Real.exp (-E-4*w)
  let bs := (ζ/8)/ds^2
  let bc := ξ/dc^2
  let ac := Real.exp (-5)*bc*(ζ*κ)^(1/ξ)
  let θ := cn*α*(k : ℝ)^(-1/α)*x
  let a := θ/(cm*L*ac)
  let G := 4-Real.log (cm/8)+Real.log ((ds*dc)^2/(L*α^3*(1+Real.log x)))
  change Real.log (a/bs) = lowerPrincipalLog s E v ζ β (Real.log cn) G
  have hαpos : 0 < α := by linarith
  have hβpos : 0 < β := sub_pos.mpr hα
  have hξpos : 0 < ξ := sub_pos.mpr hs1
  have hxpos : 0 < x := by change 0 < rootMultiplier k α ε; linarith
  have hkpos : 0 < (k : ℝ) := by exact_mod_cast hk
  have hxlog : 0 < 1+Real.log x := by
    have hh : 0 < Real.log x := Real.log_pos hx
    linarith
  have hκ : 0 < κ := Real.exp_pos _
  have hbs : 0 < bs := by dsimp [bs]; positivity
  have hbc : 0 < bc := by dsimp [bc]; positivity
  have hac : 0 < ac := by dsimp [ac]; positivity
  have hθ : 0 < θ := by dsimp [θ]; positivity
  have ha : 0 < a := by dsimp [a]; positivity
  have hh : fractionalPart α*(1-fractionalPart α) = s*ξ := by
    rcases hnearest with h | h
    · dsimp [ξ]; rw [h]
    · dsimp [ξ]; rw [h]; ring
  have hΨ : (fractionalPart α)^(1+1/(1-fractionalPart α))*
      (1-fractionalPart α)^(1+1/fractionalPart α) = s^(1+1/ξ)*ξ^(1+1/s) := by
    rcases hnearest with h | h
    · dsimp [ξ]; rw [h]
    · dsimp [ξ]; rw [h]
      rw [show 1-(1-fractionalPart α) = fractionalPart α by ring]
      ring
  have hroot := regularized_root_log_intensity hk hα hγ₀ hγ₁ hx
  dsimp only at hroot
  rw [hh, hΨ, Real.log_mul (Real.rpow_pos_of_pos hs _).ne'
    (Real.rpow_pos_of_pos hξpos _).ne', Real.log_rpow hs, Real.log_rpow hξpos] at hroot
  change Real.log (α*(k : ℝ)^(-1/α)*x) =
    (1+1/ξ)*Real.log s+(1+1/s)*Real.log ξ-Real.log α-2*Real.log β-
      Real.log (1+Real.log x)-1-(E-v)/(s*ξ) at hroot
  have hθlog : Real.log θ = Real.log cn+Real.log (α*(k : ℝ)^(-1/α)*x) := by
    dsimp [θ]
    rw [show cn*α*(k : ℝ)^(-1/α)*x = cn*(α*(k : ℝ)^(-1/α)*x) by ring]
    exact Real.log_mul hcn.ne' (by positivity)
  have haclog : Real.log ac = -5+Real.log ξ-2*Real.log dc+
      (1/ξ)*(Real.log ζ-E-4*w) := by
    dsimp [ac, bc]
    rw [Real.log_mul (by positivity) (by positivity),
      Real.log_mul (Real.exp_pos _).ne' (by positivity), Real.log_exp,
      Real.log_div hξpos.ne' (by positivity), Real.log_pow,
      Real.log_rpow (mul_pos hζ hκ), Real.log_mul hζ.ne' hκ.ne']
    change -5+(Real.log ξ-2*Real.log dc)+(1/ξ)*(Real.log ζ+Real.log κ) = _
    dsimp [κ]
    rw [Real.log_exp]
    ring
  have hbslog : Real.log bs = Real.log ζ-Real.log 8-2*Real.log ds := by
    dsimp [bs]
    rw [Real.log_div (by positivity) (by positivity), Real.log_div hζ.ne' (by norm_num), Real.log_pow]
    norm_num
  have hGlog : G = 4-Real.log cm+Real.log 8+2*Real.log ds+2*Real.log dc-
      Real.log L-3*Real.log α-Real.log (1+Real.log x) := by
    dsimp [G]
    rw [Real.log_div hcm.ne' (by norm_num), Real.log_div (by positivity) (by positivity),
      Real.log_pow, Real.log_mul hds.ne' hdc.ne',
      Real.log_mul (by positivity) hxlog.ne', Real.log_mul hL.ne' (by positivity), Real.log_pow]
    ring
  rw [Real.log_div ha.ne' hbs.ne']
  have halog : Real.log a = Real.log θ-Real.log cm-Real.log L-Real.log ac := by
    dsimp [a]
    rw [Real.log_div hθ.ne' (by positivity), Real.log_mul (by positivity) hac.ne',
      Real.log_mul hcm.ne' hL.ne']
    ring
  rw [halog, hθlog, hroot, haclog, hbslog]
  unfold lowerPrincipalLog
  rw [show 1-s = ξ by rfl, show s*ξ+v = w by rfl,
    show β+1 = α by dsimp [β]; ring, Real.log_div hs.ne' hζ.ne',
    Real.log_div hαpos.ne' hβpos.ne', hGlog]
  field_simp [hs.ne', hξpos.ne']
  dsimp [ξ]
  ring


/-- The actual ceiling degree gives a universal geometric factor. -/
theorem lower_ceiling_geometric_factor {α x ds dc : ℝ}
    (hα : 1 ≤ α) (hx : 1 ≤ x) (hds : 0 < ds) (hdc : 0 < dc)
    (hdim : ds*dc ≤ α*((Nat.ceil (10*α*(1+Real.log x)) : ℝ)+1)) :
    let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
    (ds*dc)^2/(L*α^3*(1+Real.log x)) ≤ 44 := by
  let t := 1+Real.log x
  let L : ℝ := Nat.ceil (10*α*t)
  have hαpos : 0 < α := by linarith
  have ht : 1 ≤ t := by dsimp [t]; linarith [Real.log_nonneg hx]
  have htpos : 0 < t := by linarith
  have hat : 1 ≤ α*t := one_le_mul_of_one_le_of_one_le hα ht
  have hLlo : 10*α*t ≤ L := Nat.le_ceil _
  have hLhi : L ≤ 11*α*t := by
    have hh := (Nat.ceil_lt_add_one (show 0 ≤ 10*α*t by positivity)).le
    change L ≤ 10*α*t+1 at hh
    nlinarith only [hh, hat]
  have hL1 : 1 ≤ L := by nlinarith only [hLlo, hat]
  have hLpos : 0 < L := by linarith
  have hdim' : ds*dc ≤ 2*α*L := by
    have hh := mul_le_mul_of_nonneg_left (show L+1 ≤ 2*L by linarith only [hL1]) hαpos.le
    change ds*dc ≤ α*(L+1) at hdim
    nlinarith only [hdim, hh]
  have hsquare : (ds*dc)^2 ≤ (2*α*L)^2 :=
    pow_le_pow_left₀ (mul_pos hds hdc).le hdim' _
  change (ds*dc)^2/(L*α^3*t) ≤ 44
  apply (div_le_iff₀ (by positivity : 0 < L*α^3*t)).mpr
  have hh := mul_le_mul_of_nonneg_left hLhi (show 0 ≤ 4*α^2*L by positivity)
  nlinarith only [hsquare, hh]

/-- Fixed support constant `cm = 1/100` and node constant `cb = 1/8`
make the logarithmic geometric remainder at most 1000. -/
theorem lower_ceiling_log_geometry {α x ds dc : ℝ}
    (hα : 1 ≤ α) (hx : 1 ≤ x) (hds : 0 < ds) (hdc : 0 < dc)
    (hdim : ds*dc ≤ α*((Nat.ceil (10*α*(1+Real.log x)) : ℝ)+1)) :
    let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
    4-Real.log ((1/100 : ℝ)/8)+Real.log ((ds*dc)^2/(L*α^3*(1+Real.log x))) ≤ 1000 := by
  have hg := lower_ceiling_geometric_factor hα hx hds hdc hdim
  dsimp only at hg ⊢
  have hαpos : 0 < α := by linarith
  have ht : 0 < 1+Real.log x := by linarith [Real.log_nonneg hx]
  have hL : (0 : ℝ) < Nat.ceil (10*α*(1+Real.log x)) :=
    (show 0 < 10*α*(1+Real.log x) by positivity).trans_le (Nat.le_ceil _)
  have hq : 0 < (ds*dc)^2/((Nat.ceil (10*α*(1+Real.log x)) : ℝ)*α^3*(1+Real.log x)) := by positivity
  have hl := Real.log_le_sub_one_of_pos hq
  have h800 := Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 800)
  rw [show (1/100 : ℝ)/8 = (800 : ℝ)⁻¹ by norm_num, Real.log_inv]
  linarith only [hg, hl, h800]


/-- All small-velocity hypotheses follow from one explicit lower bound on
`x`; the bound is independent of the order. -/
theorem lower_velocity_from_root_size {α ε s C x : ℝ}
    (hα : 1 < α) (hε : 0 < ε) (hs : 0 < s) (hs1 : s ≤ 1/2) (hC : 0 < C)
    (hx4 : 4 ≤ x) (hxε : 2/ε ≤ x) (hxC : 2*C ≤ x) :
    let v := (α-1)/α*x^(-α)
    0 ≤ v ∧ 4*v ≤ 2*ε*(α-1) ∧ s*(1-s)+v ≤ 1/2 ∧ v ≤ 1/(2*C) := by
  let v := (α-1)/α*x^(-α)
  change 0 ≤ v ∧ 4*v ≤ 2*ε*(α-1) ∧ s*(1-s)+v ≤ 1/2 ∧ v ≤ 1/(2*C)
  have hαpos : 0 < α := by linarith
  have hβ : 0 < α-1 := sub_pos.mpr hα
  have hxpos : 0 < x := by linarith
  have hx1 : 1 ≤ x := by linarith
  have hp : x^(-α) ≤ 1/x := by
    have hh := Real.rpow_le_rpow_of_exponent_le hx1 (neg_le_neg hα.le)
    simpa only [Real.rpow_neg_one, one_div] using hh
  have hf : (α-1)/α ≤ 1 := (div_le_one hαpos).mpr (by linarith)
  have hfb : (α-1)/α ≤ α-1 := div_le_self hβ.le hα.le
  have hv : 0 ≤ v := by dsimp [v]; positivity
  have hvx : v ≤ 1/x := by
    calc
      v ≤ 1*x^(-α) := mul_le_mul_of_nonneg_right hf (Real.rpow_nonneg hxpos.le _)
      _ ≤ 1/x := by simpa only [one_mul] using hp
  have hvβ : v ≤ (α-1)/x := by
    calc
      v ≤ (α-1)*(1/x) := mul_le_mul hfb hp (Real.rpow_nonneg hxpos.le _) hβ.le
      _ = (α-1)/x := by ring
  have hxe : 1/x ≤ ε/2 := by
    apply (div_le_iff₀ hxpos).mpr
    have hh := (div_le_iff₀ hε).mp hxε
    nlinarith only [hh]
  have hvε : v ≤ (α-1)*ε/2 := by
    calc
      v ≤ (α-1)/x := hvβ
      _ = (α-1)*(1/x) := by ring
      _ ≤ (α-1)*(ε/2) := mul_le_mul_of_nonneg_left hxe hβ.le
      _ = (α-1)*ε/2 := by ring
  have hv4 : v ≤ 1/4 := hvx.trans (one_div_le_one_div_of_le (by norm_num) hx4)
  refine ⟨hv, ?_, ?_, hvx.trans (one_div_le_one_div_of_le (by positivity) hxC)⟩
  · nlinarith only [hvε]
  · nlinarith only [hv4, sq_nonneg (s-1/2)]

end Renyi
