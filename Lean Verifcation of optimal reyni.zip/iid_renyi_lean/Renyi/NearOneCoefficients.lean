import Renyi.NearOnePolynomial
import Renyi.NearOneBias
import Renyi.EndpointCoefficientDifference

/-! Beta cancellation for the coefficients of the actual degree-one coupled polynomial. -/
noncomputable section
open Polynomial
namespace Renyi

def nearOneNormalizedPolynomial (N : ℕ) (β r f ω A B : ℝ) : ℝ[X] :=
  C A*nearOneTangentPolynomial β r*(1-X*endpointProfilePolynomial N 6 1)+
  C B*X^2*highProfilePolynomial N (1-β) f ω+
  C (ω*(1-B))*X^2*endpointProfilePolynomial N 6 (1-β)

lemma nearOneTangentPolynomial_scale {β τ b : ℝ} (hτ : 0≤τ) (hb : 0<b) :
    (nearOneTangentPolynomial β τ).comp (C b*X) =
      C (b^(1+β))*nearOneTangentPolynomial β (τ/b) := by
  have hr := reverse_fractional_identity 1 β hτ hb
  simp only [Nat.cast_one,pow_one] at hr
  have hp : b^(1+β)*(τ/b)^(1+β)=τ^(1+β) := by
    rw [Real.div_rpow hτ hb.le]
    field_simp
  apply Polynomial.funext
  intro x
  simp only [eval_comp,eval_mul,eval_C,eval_X,nearOneTangentPolynomial_eval]
  calc
    _ = ((1+β)*x)*(τ^β*b)-β*τ^(1+β) := by ring
    _ = _ := by rw [←hr,←hp];ring

/-- Exact b-normalization of every coefficient of the actual polynomial. -/
theorem nearOneCoupledPolynomial_scale {N : ℕ} {β τ b f ω A B : ℝ}
    (hτ : 0≤τ) (hb : 0<b) :
    (nearOneCoupledPolynomial N β τ b f ω A B).comp (C b*X) =
      C (b^(1+β))*nearOneNormalizedPolynomial N β (τ/b) f ω A B := by
  have hp : b^2/b^(1-β)=b^(1+β) := by
    have h := forward_fractional_identity 1 β hb hb
    simpa only [Nat.cast_one,Nat.reduceAdd,div_self hb.ne',Real.one_rpow,mul_one] using h.symm
  unfold nearOneCoupledPolynomial nearOneNormalizedPolynomial
  simp only [add_comp,mul_comp,sub_comp,one_comp,C_comp,pow_comp,X_comp,
    comp_assoc,inverse_scale_comp hb.ne',comp_X,nearOneTangentPolynomial_scale hτ hb]
  have hscale (c : ℝ) : C (c/b^(1-β))*(C b*X)^2 = C (b^(1+β))*C c*X^2 := by
    rw [mul_pow,←C_pow,←mul_assoc,←C_mul]
    have hid : c/b^(1-β)*b^2=b^(1+β)*c := by rw [←hp];ring
    rw [hid,C_mul]
  rw [hscale B,hscale (ω*(1-B))]
  ring

/-- Exact cancellation decomposition after removing the affine tangent. -/
lemma nearOneNormalizedPolynomial_remainder (N : ℕ) (β r f ω A B κ : ℝ) :
    nearOneNormalizedPolynomial N β r f ω A B-C A*nearOneTangentPolynomial β r =
      X^2*(C ω*(endpointProfilePolynomial N 6 (1-β)-C κ*endpointProfilePolynomial N 6 1)+
        C (ω*κ-A*(1+β)*r^β)*endpointProfilePolynomial N 6 1+
        C B*(highProfilePolynomial N (1-β) f ω-C ω*endpointProfilePolynomial N 6 (1-β)))+
      C (A*β*r^(1+β))*X*endpointProfilePolynomial N 6 1 := by
  unfold nearOneNormalizedPolynomial nearOneTangentPolynomial
  simp only [map_sub,map_mul,map_add,map_one]
  ring

lemma nearOneTangentPolynomial_coeff_zero {j : ℕ} (hj : 2≤j) (β τ : ℝ) :
    (nearOneTangentPolynomial β τ).coeff j=0 := by
  simp only [nearOneTangentPolynomial,coeff_sub,coeff_C_mul,coeff_X,coeff_C]
  rw [if_neg (by omega : ¬1=j),if_neg (by omega : ¬j=0)]
  ring

lemma coefficientMass_X_pow_mul_le (P : ℝ[X]) (n : ℕ) :
    coefficientMass (X^n*P)≤coefficientMass P := by
  have hp := coefficientMass_pow_le (X:ℝ[X]) n
  simp only [coefficientMass_X,one_pow] at hp
  exact (coefficientMass_mul_le _ _).trans
    ((mul_le_mul_of_nonneg_right hp (coefficientMass_nonneg P)).trans_eq (by ring))

lemma nearOneNormalizedPolynomial_coeff_bound {N j : ℕ} (hj : 2≤j)
    (β r f ω A B κ : ℝ) :
    |(nearOneNormalizedPolynomial N β r f ω A B).coeff j| ≤
      |ω| * coefficientMass (endpointProfilePolynomial N 6 (1-β)-C κ*endpointProfilePolynomial N 6 1)+
      |ω*κ-A*(1+β)*r^β| * coefficientMass (endpointProfilePolynomial N 6 1)+
      |B| * (coefficientMass (highProfilePolynomial N (1-β) f ω)+|ω| * coefficientMass (endpointProfilePolynomial N 6 (1-β)))+
      |A*β*r^(1+β)| * coefficientMass (endpointProfilePolynomial N 6 1) := by
  have hc := abs_coeff_le_coefficientMass
    (nearOneNormalizedPolynomial N β r f ω A B-C A*nearOneTangentPolynomial β r) j
  simp only [coeff_sub,coeff_C_mul,nearOneTangentPolynomial_coeff_zero hj,mul_zero,sub_zero] at hc
  rw [nearOneNormalizedPolynomial_remainder N β r f ω A B κ] at hc
  have h1 := coefficientMass_C_mul ω (endpointProfilePolynomial N 6 (1-β)-C κ*endpointProfilePolynomial N 6 1)
  have h2 := coefficientMass_C_mul (ω*κ-A*(1+β)*r^β) (endpointProfilePolynomial N 6 1)
  have h3 : coefficientMass (C B*(highProfilePolynomial N (1-β) f ω-C ω*endpointProfilePolynomial N 6 (1-β)))≤
      |B| * (coefficientMass (highProfilePolynomial N (1-β) f ω)+|ω| * coefficientMass (endpointProfilePolynomial N 6 (1-β))) := by
    rw [coefficientMass_C_mul]
    apply mul_le_mul_of_nonneg_left _ (abs_nonneg B)
    exact (coefficientMass_sub_le _ _).trans_eq (by rw [coefficientMass_C_mul])
  have h4 : coefficientMass (C (A*β*r^(1+β))*X*endpointProfilePolynomial N 6 1)≤
      |A*β*r^(1+β)| * coefficientMass (endpointProfilePolynomial N 6 1) := by
    rw [mul_assoc,coefficientMass_C_mul]
    have hm := coefficientMass_mul_le (X:ℝ[X]) (endpointProfilePolynomial N 6 1)
    simp only [coefficientMass_X,one_mul] at hm
    exact mul_le_mul_of_nonneg_left hm (abs_nonneg _)
  apply hc.trans
  apply (coefficientMass_add_le _ _).trans
  apply add_le_add _ h4
  apply (coefficientMass_X_pow_mul_le _ 2).trans
  apply (coefficientMass_add_le _ _).trans
  apply add_le_add _ h3
  exact (coefficientMass_add_le _ _).trans_eq (by rw [h1,h2])


lemma nearOne_scale_power {N : ℕ} (hN : 0<N) {β r : ℝ} (hr : 0≤r) :
    r^β=(N:ℝ)^(-2*β)*((N:ℝ)^2*r)^β := by
  have hp := endpoint_scale_power (s:=β) hN hr
  have hn : 0<(N:ℝ) := by exact_mod_cast hN
  rw [show -2*β=-(2*β) by ring,Real.rpow_neg hn.le,←hp]
  field_simp

lemma nearOne_amplitude_cancellation {N : ℕ} (hN : 0<N)
    {β r M C A ω : ℝ} (hβ : 0≤β) (hβ1 : β≤1) (hr : 0<r)
    (hM : |Real.log ((N:ℝ)^2*r)|≤M) (hA : 0≤A) (hA1 : A≤1)
    (hclose : |A-ω|≤C*β) :
    |ω*(N:ℝ)^(-2*β)-A*(1+β)*r^β|≤(C+Real.exp M*(M+1))*β := by
  have hR : 0<(N:ℝ)^2*r := by positivity
  have hdiff := compact_rpow_difference hR hβ hβ1 hM
  have hpow' : ((N:ℝ)^2*r)^β≤Real.exp M := by
    rw [Real.rpow_def_of_pos hR]
    apply Real.exp_le_exp.mpr
    have hM0 := (abs_nonneg (Real.log ((N:ℝ)^2*r))).trans hM
    have hl := mul_le_mul_of_nonneg_right ((le_abs_self _).trans hM) hβ
    nlinarith only [hl,mul_le_of_le_one_right hM0 hβ1]
  have hinner : |ω-A*(1+β)*((N:ℝ)^2*r)^β|≤(C+Real.exp M*(M+1))*β := by
    have hid : ω-A*(1+β)*((N:ℝ)^2*r)^β =
        (ω-A)+A*(1-((N:ℝ)^2*r)^β)-A*β*((N:ℝ)^2*r)^β := by ring
    rw [hid]
    apply (abs_sub_le _ 0 _).trans
    simp only [sub_zero,zero_sub,abs_neg]
    apply le_trans (add_le_add_right (abs_add_le _ _) _)
    rw [abs_sub_comm ω A,abs_mul,abs_of_nonneg hA,abs_sub_comm (1:ℝ),
      abs_of_nonneg (show 0≤A*β*((N:ℝ)^2*r)^β by positivity)]
    have h1 := (mul_le_of_le_one_left (abs_nonneg _) hA1).trans hdiff
    have h2 := mul_le_mul_of_nonneg_left hpow' (mul_nonneg hA hβ)
    have h3 := mul_le_of_le_one_left (show 0≤β*Real.exp M by positivity) hA1
    nlinarith only [hclose,h1,h2,h3]
  have hκ0 : 0≤(N:ℝ)^(-2*β) := Real.rpow_nonneg (Nat.cast_nonneg N) _
  have hκ1 : (N:ℝ)^(-2*β)≤1 := Real.rpow_le_one_of_one_le_of_nonpos
    (by exact_mod_cast hN : (1:ℝ)≤N) (by nlinarith only [hβ])
  rw [nearOne_scale_power hN hr.le]
  have hid : ω*(N:ℝ)^(-2*β)-A*(1+β)*((N:ℝ)^(-2*β)*((N:ℝ)^2*r)^β)=
      (N:ℝ)^(-2*β)*(ω-A*(1+β)*((N:ℝ)^2*r)^β) := by ring
  rw [hid,abs_mul,abs_of_nonneg hκ0]
  exact (mul_le_of_le_one_left (abs_nonneg _) hκ1).trans hinner

lemma nearOne_tangent_constant_bound {N : ℕ} (hN : 0<N)
    {β r M A : ℝ} (hβ : 0≤β) (hβ1 : β≤1) (hr : 0<r)
    (hM : |Real.log ((N:ℝ)^2*r)|≤M) (hA : 0≤A) (hA1 : A≤1) :
    |A*β*r^(1+β)|≤β*Real.exp (2*M) := by
  have hR : 0<(N:ℝ)^2*r := by positivity
  have hN1 : (1:ℝ)≤N := by exact_mod_cast hN
  have hrR : r≤(N:ℝ)^2*r := by nlinarith only [mul_le_mul_of_nonneg_right (show (1:ℝ)≤(N:ℝ)^2 by nlinarith only [hN1]) hr.le]
  have hp := (Real.rpow_le_rpow hr.le hrR (by linarith only [hβ] : 0≤1+β)).trans
    (compact_rpow_upper hR (by linarith only [hβ] : 0≤1+β) (by linarith only [hβ1] : 1+β≤2) hM)
  rw [abs_of_nonneg (show 0≤A*β*r^(1+β) by positivity)]
  have h1 := mul_le_mul_of_nonneg_left hp (mul_nonneg hA hβ)
  have h2 := mul_le_of_le_one_left (show 0≤β*Real.exp (2*M) by positivity) hA1
  nlinarith only [h1,h2]


def nearOneCoefficientConstant (M C : ℝ) : ℝ :=
  endpointCoefficientDifferenceConstant+24*(C+Real.exp M*(M+1))+312*C+24*Real.exp (2*M)

/-- Every nonlinear coefficient of the actual normalized polynomial has a beta factor. -/
theorem nearOneNormalizedPolynomial_beta_coefficients {N j : ℕ} (hN : 0<N) (hj : 2≤j)
    {β r f ω A B M C : ℝ} (hβ : 0<β) (hβ1 : β≤1/2) (hr : 0<r)
    (hf : 0≤f) (hf1 : f≤1) (hω : 0≤ω) (hω1 : ω<1)
    (hA : 0≤A) (hA1 : A≤1) (hC : 0≤C)
    (hM : |Real.log ((N:ℝ)^2*r)|≤M) (hclose : |A-ω|≤C*β) (hB : |B|≤C*β) :
    |(nearOneNormalizedPolynomial N β r f ω A B).coeff j|≤
      nearOneCoefficientConstant M C*β*(N:ℝ)^2*(9:ℝ)^(18*(N-1)) := by
  let K : ℝ := (N:ℝ)^2*(9:ℝ)^(18*(N-1))
  have hK : 0≤K := by dsimp [K];positivity
  have hM0 := (abs_nonneg (Real.log ((N:ℝ)^2*r))).trans hM
  have hβone : β≤1 := by linarith only [hβ1]
  have hδ : 0<1-β := by linarith only [hβ1]
  have hδ1 : 1-β≤1 := by linarith only [hβ]
  have hpow : (9:ℝ)^((N-1)*6)≤(9:ℝ)^(18*(N-1)) :=
    pow_le_pow_right₀ (by norm_num : (1:ℝ)≤9) (by omega)
  have hJ1 : coefficientMass (endpointProfilePolynomial N 6 1)≤24*K := by
    have h := endpointProfilePolynomial_coefficientMass hN (by norm_num : 6≤6)
      (by norm_num : (0:ℝ)<1) (by norm_num : (1:ℝ)≤1)
    have hm := mul_le_mul_of_nonneg_left hpow (show 0≤24*(N:ℝ)^2 by positivity)
    apply h.trans
    dsimp only [K]
    nlinarith only [hm]
  have hJδ : coefficientMass (endpointProfilePolynomial N 6 (1-β))≤24*K := by
    have h := endpointProfilePolynomial_coefficientMass hN (by norm_num : 6≤6) hδ hδ1
    have hm := mul_le_mul_of_nonneg_left hpow (show 0≤24*(N:ℝ)^2 by positivity)
    apply h.trans
    dsimp only [K]
    nlinarith only [hm]
  have hV : coefficientMass (highProfilePolynomial N (1-β) f ω)≤288*K := by
    have h := highProfilePolynomial_coefficientMass hN hδ hδ1 hf hf1 hω hω1
    dsimp only [K]
    nlinarith only [h]
  have hdiff : coefficientMass (endpointProfilePolynomial N 6 (1-β)-Polynomial.C ((N:ℝ)^(-2*β))*endpointProfilePolynomial N 6 1)≤
      endpointCoefficientDifferenceConstant*β*K := by
    have h := endpointProfilePolynomial_near_one_difference_mass hN (by norm_num : 2≤6) (by norm_num : 6≤6) hβ hβ1
    have hm := mul_le_mul_of_nonneg_left hpow
      (show 0≤endpointCoefficientDifferenceConstant*β*(N:ℝ)^2 by have := endpointCoefficientDifferenceConstant_pos;positivity)
    apply h.trans
    dsimp only [K]
    nlinarith only [hm]
  have hamp := nearOne_amplitude_cancellation hN hβ.le hβone hr hM hA hA1 hclose
  have hconst := nearOne_tangent_constant_bound hN hβ.le hβone hr hM hA hA1
  have hbase := nearOneNormalizedPolynomial_coeff_bound (N:=N) hj β r f ω A B ((N:ℝ)^(-2*β))
  rw [abs_of_nonneg hω] at hbase
  have h1 := (mul_le_of_le_one_left (coefficientMass_nonneg _) hω1.le).trans hdiff
  have h2 := mul_le_mul hamp hJ1 (coefficientMass_nonneg _)
    (show 0≤(C+Real.exp M*(M+1))*β by positivity)
  have hωJ := (mul_le_of_le_one_left (coefficientMass_nonneg (endpointProfilePolynomial N 6 (1-β))) hω1.le).trans hJδ
  have h3 := mul_le_mul hB (add_le_add hV hωJ)
    (show 0≤coefficientMass (highProfilePolynomial N (1-β) f ω)+ω*coefficientMass (endpointProfilePolynomial N 6 (1-β)) by
      exact add_nonneg (coefficientMass_nonneg _) (mul_nonneg hω (coefficientMass_nonneg _)))
    (mul_nonneg hC hβ.le)
  have h4 := mul_le_mul hconst hJ1 (coefficientMass_nonneg _) (by positivity : 0≤β*Real.exp (2*M))
  unfold nearOneCoefficientConstant
  change _≤(endpointCoefficientDifferenceConstant+24*(C+Real.exp M*(M+1))+312*C+24*Real.exp (2*M))*β*(N:ℝ)^2*(9:ℝ)^(18*(N-1))
  have hsum : |(nearOneNormalizedPolynomial N β r f ω A B).coeff j|≤
      (endpointCoefficientDifferenceConstant+24*(C+Real.exp M*(M+1))+312*C+24*Real.exp (2*M))*β*K := by
    nlinarith only [hbase,h1,h2,h3,h4]
  simpa only [K,mul_assoc] using hsum

/-- Actual coefficients at scale b, retaining beta before taking the count variance. -/
theorem nearOneCoupledPolynomial_beta_coefficients {N j : ℕ} (hN : 0<N) (hj : 2≤j)
    {β τ b f ω A B M C : ℝ} (hβ : 0<β) (hβ1 : β≤1/2) (hτ : 0<τ) (hb : 0<b)
    (hf : 0≤f) (hf1 : f≤1) (hω : 0≤ω) (hω1 : ω<1)
    (hA : 0≤A) (hA1 : A≤1) (hC : 0≤C)
    (hM : |Real.log ((N:ℝ)^2*(τ/b))|≤M) (hclose : |A-ω|≤C*β) (hB : |B|≤C*β) :
    |(nearOneCoupledPolynomial N β τ b f ω A B).coeff j| * b^j≤
      b^(1+β)*(nearOneCoefficientConstant M C*β*(N:ℝ)^2*(9:ℝ)^(18*(N-1))) := by
  have h := nearOneNormalizedPolynomial_beta_coefficients hN hj hβ hβ1 (div_pos hτ hb)
    hf hf1 hω hω1 hA hA1 hC hM hclose hB
  have he := congrArg (fun P : ℝ[X] => |P.coeff j|) (nearOneCoupledPolynomial_scale (N:=N) (β:=β) (f:=f) (ω:=ω) (A:=A) (B:=B) hτ.le hb)
  simp only [comp_C_mul_X_coeff,coeff_C_mul,abs_mul,abs_of_nonneg (pow_nonneg hb.le j),
    abs_of_nonneg (Real.rpow_nonneg hb.le (1+β))] at he
  rw [he]
  exact mul_le_mul_of_nonneg_left h (Real.rpow_nonneg hb.le (1+β))


lemma nearOneCoefficientConstant_pos {M C : ℝ} (hM : 0≤M) (hC : 0≤C) :
    0<nearOneCoefficientConstant M C := by
  unfold nearOneCoefficientConstant
  have := endpointCoefficientDifferenceConstant_pos
  positivity

lemma nearOne_coefficient_degree_budget (N : ℕ) :
    (N:ℝ)^2*(9:ℝ)^(18*(N-1))≤Real.exp ((2+18*Real.log 9)*(N:ℝ)) := by
  have hN0 : 0≤(N:ℝ) := Nat.cast_nonneg N
  have hNexp : (N:ℝ)^2≤Real.exp (2*(N:ℝ)) := by
    have hb : (N:ℝ)≤Real.exp (N:ℝ) := by linarith [Real.add_one_le_exp (N:ℝ)]
    have hs := pow_le_pow_left₀ hN0 hb 2
    rw [←Real.exp_nat_mul] at hs
    norm_num at hs
    exact hs
  have hlog : 0≤Real.log 9 := Real.log_nonneg (by norm_num : (1:ℝ)≤9)
  have hdegree : ((18*(N-1):ℕ):ℝ)≤18*(N:ℝ) := by exact_mod_cast Nat.mul_le_mul_left 18 (Nat.sub_le N 1)
  have hkernel : (9:ℝ)^(18*(N-1))≤Real.exp ((18*Real.log 9)*(N:ℝ)) := by
    rw [←Real.rpow_natCast,Real.rpow_def_of_pos (by norm_num : (0:ℝ)<9)]
    apply Real.exp_le_exp.mpr
    nlinarith only [mul_le_mul_of_nonneg_left hdegree hlog]
  have hm := mul_le_mul hNexp hkernel (by positivity : 0≤(9:ℝ)^(18*(N-1))) (Real.exp_pos _).le
  apply hm.trans_eq
  rw [←Real.exp_add]
  congr 1
  ring

/-- Exponential degree version used by the near-one count bounds. -/
theorem nearOneCoupledPolynomial_beta_coefficients_exponential {N j : ℕ} (hN : 0<N) (hj : 2≤j)
    {β τ b f ω A B M C : ℝ} (hβ : 0<β) (hβ1 : β≤1/2) (hτ : 0<τ) (hb : 0<b)
    (hf : 0≤f) (hf1 : f≤1) (hω : 0≤ω) (hω1 : ω<1)
    (hA : 0≤A) (hA1 : A≤1) (hC : 0≤C)
    (hM : |Real.log ((N:ℝ)^2*(τ/b))|≤M) (hclose : |A-ω|≤C*β) (hB : |B|≤C*β) :
    |(nearOneCoupledPolynomial N β τ b f ω A B).coeff j| * b^j≤
      b^(1+β)*nearOneCoefficientConstant M C*β*Real.exp ((2+18*Real.log 9)*(N:ℝ)) := by
  have h := nearOneCoupledPolynomial_beta_coefficients hN hj hβ hβ1 hτ hb hf hf1 hω hω1 hA hA1 hC hM hclose hB
  have hM0 := (abs_nonneg (Real.log ((N:ℝ)^2*(τ/b)))).trans hM
  have hCpos := nearOneCoefficientConstant_pos hM0 hC
  have hm := mul_le_mul_of_nonneg_left (nearOne_coefficient_degree_budget N)
    (show 0≤b^(1+β)*nearOneCoefficientConstant M C*β by positivity)
  apply h.trans
  nlinarith only [hm]

end Renyi
