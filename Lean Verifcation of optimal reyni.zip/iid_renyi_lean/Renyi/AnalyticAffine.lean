import Renyi.AnalyticBias

/-!
# Exact removal of affine Poisson count noise

The covariance and affine residual variance are proved directly from the
analytic-count order recurrence. No infinite Charlier expansion is assumed.
-/

noncomputable section
open scoped NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

theorem analyticCount_mul_count (a : ℝ) (j : ℕ) :
    analyticCount a j * (j : ℝ) = analyticCount (a + 1) j + a * analyticCount a j := by
  rw [analyticCount_order_succ]
  ring

/-- Exact covariance with the Poisson count, including zero intensity. -/
theorem analyticCount_covariance_count (lam : ℝ≥0) (a : ℝ) :
    covariance (analyticCount a) (fun j : ℕ => (j : ℝ)) (poissonMeasure lam) =
      (lam : ℝ) * a * analyticMean lam (a - 1) := by
  have hmean : (∫ j, analyticCount a j * (j : ℝ) ∂poissonMeasure lam) =
      analyticMean lam (a + 1) + a * analyticMean lam a := by
    simp_rw [analyticCount_mul_count]
    rw [integral_add ((analyticCount_memLp lam (a + 1)).integrable one_le_two)
      (((analyticCount_memLp lam a).integrable one_le_two).const_mul a), integral_const_mul]
    rfl
  rw [covariance_eq_sub (analyticCount_memLp lam a) (poisson_nat_memLp lam)]
  simp only [Pi.mul_apply]
  rw [hmean, poisson_nat_mean]
  change analyticMean lam (a + 1) + a * analyticMean lam a - analyticMean lam a * (lam : ℝ) = _
  have hp := analyticMean_order_succ lam (a - 1)
  rw [sub_add_cancel] at hp
  have hc : (Real.Gamma (-a))⁻¹ = -a * (Real.Gamma (-(a - 1)))⁻¹ := by
    rw [gamma_inv_recurrence (-a)]
    rw [show -a + 1 = -(a - 1) by ring]
  rw [analyticMean_order_succ, hp, div_eq_mul_inv, div_eq_mul_inv, hc]
  ring

/-- Exact effect of subtracting an arbitrary affine term. -/
theorem analyticCount_affine_variance (lam : ℝ≥0) (a c d : ℝ) :
    variance (fun j : ℕ => analyticCount a j - c * (j : ℝ) - d) (poissonMeasure lam) =
      variance (analyticCount a) (poissonMeasure lam) + c ^ 2 * (lam : ℝ) -
        2 * c * (lam : ℝ) * a * analyticMean lam (a - 1) := by
  have hres : MemLp (fun j : ℕ => analyticCount a j - c * (j : ℝ)) 2 (poissonMeasure lam) :=
    (analyticCount_memLp lam a).sub ((poisson_nat_memLp lam).const_mul c)
  rw [variance_sub_const hres.1 d]
  rw [variance_fun_sub (analyticCount_memLp lam a) ((poisson_nat_memLp lam).const_mul c),
    variance_mul, covariance_mul_right, poisson_nat_variance, analyticCount_covariance_count]
  ring

/-- Variance remaining after removing the optimal linear count term. -/
def analyticHigherVariance (lam : ℝ≥0) (a : ℝ) : ℝ :=
  variance (analyticCount a) (poissonMeasure lam) -
    (lam : ℝ) * (a * analyticMean lam (a - 1)) ^ 2

/-- Affine subtraction changes exactly the first orthogonal component. -/
theorem analyticCount_affine_energy (lam : ℝ≥0) (a c d : ℝ) :
    variance (fun j : ℕ => analyticCount a j - c * (j : ℝ) - d) (poissonMeasure lam) =
      (lam : ℝ) * (a * analyticMean lam (a - 1) - c) ^ 2 + analyticHigherVariance lam a := by
  rw [analyticCount_affine_variance]
  unfold analyticHigherVariance
  ring

theorem analyticHigherVariance_nonneg (lam : ℝ≥0) (a : ℝ) :
    0 ≤ analyticHigherVariance lam a := by
  have h := variance_nonneg
    (fun j : ℕ => analyticCount a j - (a * analyticMean lam (a - 1)) * (j : ℝ) - 0)
    (poissonMeasure lam)
  rw [analyticCount_affine_energy] at h
  simpa using h

end Renyi
