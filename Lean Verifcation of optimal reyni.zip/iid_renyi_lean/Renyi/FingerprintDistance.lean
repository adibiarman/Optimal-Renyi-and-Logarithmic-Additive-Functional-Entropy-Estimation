import Renyi.PoissonFingerprint
import Renyi.PoissonOverlap
import Renyi.Hellinger
import Renyi.DiscreteTesting
import Mathlib.Probability.Independence.InfinitePi

/-!
# Hellinger affinity of the actual Poisson random-length marking experiment
-/

noncomputable section
open scoped BigOperators ENNReal NNReal
open MeasureTheory ProbabilityTheory

namespace Renyi

/-- A mass function's real-valued probabilities sum to one. -/
theorem pmfReal_hasSum {κ : Type*} (q : PMF κ) :
    HasSum (fun j => (q j).toReal) 1 := by
  have hs := ENNReal.summable_toReal (f := fun j => q j) (by
    rw [q.tsum_coe]
    exact ENNReal.one_ne_top)
  have heq : (∑' j, (q j).toReal) = 1 := by
    rw [← ENNReal.tsum_toReal_eq (fun j => q.apply_ne_top j), q.tsum_coe]
    rfl
  exact heq ▸ hs.hasSum

/-- Finite products of nonnegative summable countable factors, with an arbitrary mark space. -/
theorem hasSum_ordered_product {κ : Type*} (n : ℕ) (f : Fin n → κ → ℝ)
    (a : Fin n → ℝ) (hf0 : ∀ i j, 0 ≤ f i j)
    (hf : ∀ i, HasSum (f i) (a i)) :
    HasSum (fun x : Fin n → κ => ∏ i, f i (x i)) (∏ i, a i) := by
  induction n with
  | zero => simp
  | succ n ih =>
    have htail := ih (fun i => f i.succ) (fun i => a i.succ)
      (fun i j => hf0 i.succ j) (fun i => hf i.succ)
    have hsum := hasSum_mul_nonneg_real (hf 0) htail
      (fun j => hf0 0 j) (fun x => Finset.prod_nonneg (fun i _ => hf0 i.succ (x i)))
    apply (Fin.consEquiv (fun _ : Fin (n + 1) => κ)).hasSum_iff.mp
    simpa [Fin.prod_univ_succ] using hsum

variable {κ : Type*} [Countable κ] [MeasurableSpace κ] [MeasurableSingletonClass κ]

/-- The exact probability of a random-length ordered sample. -/
theorem poissonCountableSamplePMF_apply (b : ℝ≥0) (q : PMF κ)
    (x : PoissonMarkedSample κ) :
    poissonCountableSamplePMF b q x = poissonPMF b x.1 * ∏ k, q (x.2 k) := by
  classical
  rcases x with ⟨n, x⟩
  rw [poissonCountableSamplePMF, PMF.bind_apply, tsum_eq_single n]
  · congr 1
    rw [PMF.map_apply, tsum_eq_single x]
    · simp [iidCountablePMF_apply]
    · intro y hy
      have hne : (⟨n, x⟩ : PoissonMarkedSample κ) ≠ ⟨n, y⟩ := by
        intro h
        exact hy (sigma_mk_injective h).symm
      simp [hne]
  · intro m hm
    have hne (y : Fin m → κ) : (⟨n, x⟩ : PoissonMarkedSample κ) ≠ ⟨m, y⟩ := by
      intro h
      exact hm (congrArg Sigma.fst h).symm
    simp only [PMF.map_apply, hne, if_false, tsum_zero, mul_zero]

/-- Real form of the exact sample probability. -/
theorem poissonCountableSamplePMF_toReal (b : ℝ≥0) (q : PMF κ)
    (x : PoissonMarkedSample κ) :
    (poissonCountableSamplePMF b q x).toReal =
      poissonPMFReal b x.1 * ∏ k, (q (x.2 k)).toReal := by
  rw [poissonCountableSamplePMF_apply, ENNReal.toReal_mul, ENNReal.toReal_prod]
  congr 1
  exact ENNReal.toReal_ofReal poissonPMFReal_nonneg

private theorem sqrt_finprod {ι : Type*} (s : Finset ι) (f : ι → ℝ)
    (hf : ∀ i, 0 ≤ f i) : Real.sqrt (∏ i ∈ s, f i) = ∏ i ∈ s, Real.sqrt (f i) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
    rw [Finset.prod_insert hi, Finset.prod_insert hi, Real.sqrt_mul (hf i), ih]

/-- Exact square-root overlap of two Poisson masses. -/
theorem sqrt_poisson_mass_product (b₀ b₁ : ℝ≥0) (n : ℕ) :
    Real.sqrt (poissonPMFReal b₀ n * poissonPMFReal b₁ n) =
      Real.exp (-((b₀ : ℝ) + b₁) / 2) *
        (Real.sqrt ((b₀ : ℝ) * b₁)) ^ n / (n.factorial : ℝ) := by
  apply (Real.sqrt_eq_iff_eq_sq
    (mul_nonneg poissonPMFReal_nonneg poissonPMFReal_nonneg) (by positivity)).mpr
  have hexp : Real.exp (-((b₀ : ℝ) + b₁) / 2) ^ 2 =
      Real.exp (-(b₀ : ℝ)) * Real.exp (-(b₁ : ℝ)) := by
    rw [← Real.exp_nat_mul, ← Real.exp_add]
    congr 1
    ring
  have hpow : (Real.sqrt ((b₀ : ℝ) * b₁) ^ n) ^ 2 =
      (b₀ : ℝ) ^ n * (b₁ : ℝ) ^ n := by
    rw [← pow_mul, mul_comm n 2, pow_mul,
      Real.sq_sqrt (mul_nonneg b₀.coe_nonneg b₁.coe_nonneg), mul_pow]
  rw [div_pow, mul_pow, hexp, hpow]
  simp only [poissonPMFReal]
  ring

/-- The square-root overlap of a sample factors into the sample-size and mark overlaps. -/
theorem poissonSample_sqrt_product (b₀ b₁ : ℝ≥0) (q₀ q₁ : PMF κ)
    (x : PoissonMarkedSample κ) :
    Real.sqrt ((poissonCountableSamplePMF b₀ q₀ x).toReal *
      (poissonCountableSamplePMF b₁ q₁ x).toReal) =
      Real.sqrt (poissonPMFReal b₀ x.1 * poissonPMFReal b₁ x.1) *
        ∏ k, Real.sqrt ((q₀ (x.2 k)).toReal * (q₁ (x.2 k)).toReal) := by
  rw [poissonCountableSamplePMF_toReal, poissonCountableSamplePMF_toReal]
  rw [show (poissonPMFReal b₀ x.1 * ∏ k, (q₀ (x.2 k)).toReal) *
      (poissonPMFReal b₁ x.1 * ∏ k, (q₁ (x.2 k)).toReal) =
      (poissonPMFReal b₀ x.1 * poissonPMFReal b₁ x.1) *
        ∏ k, ((q₀ (x.2 k)).toReal * (q₁ (x.2 k)).toReal) by
      rw [Finset.prod_mul_distrib]; ring]
  rw [Real.sqrt_mul (mul_nonneg poissonPMFReal_nonneg poissonPMFReal_nonneg),
    sqrt_finprod _ _ (fun _ => mul_nonneg ENNReal.toReal_nonneg ENNReal.toReal_nonneg)]

/-- Exact marked-Poisson affinity, with the mark affinity given by its actual convergent sum. -/
theorem poissonSample_affinity (b₀ b₁ : ℝ≥0) (q₀ q₁ : PMF κ)
    :
    HasSum (fun x : PoissonMarkedSample κ =>
      Real.sqrt ((poissonCountableSamplePMF b₀ q₀ x).toReal *
        (poissonCountableSamplePMF b₁ q₁ x).toReal))
      (Real.exp (-((b₀ : ℝ) + b₁) / 2 + Real.sqrt ((b₀ : ℝ) * b₁) *
        ∑' j, Real.sqrt ((q₀ j).toReal * (q₁ j).toReal))) := by
  have hmark : Summable (fun j => Real.sqrt ((q₀ j).toReal * (q₁ j).toReal)) := by
    simpa only [Real.sqrt_mul ENNReal.toReal_nonneg] using
      hellinger_affinity_summable (fun j => (q₀ j).toReal) (fun j => (q₁ j).toReal)
        (fun _ => ENNReal.toReal_nonneg) (fun _ => ENNReal.toReal_nonneg)
        (pmfReal_hasSum q₀) (pmfReal_hasSum q₁)
  let A := ∑' j, Real.sqrt ((q₀ j).toReal * (q₁ j).toReal)
  let r : ℝ≥0 := ⟨Real.sqrt ((b₀ : ℝ) * b₁), Real.sqrt_nonneg _⟩
  let c := Real.exp ((r : ℝ) - ((b₀ : ℝ) + b₁) / 2)
  have hrow (n : ℕ) : HasSum (fun x : Fin n → κ =>
      Real.sqrt ((poissonCountableSamplePMF b₀ q₀ ⟨n, x⟩).toReal *
        (poissonCountableSamplePMF b₁ q₁ ⟨n, x⟩).toReal))
      (Real.sqrt (poissonPMFReal b₀ n * poissonPMFReal b₁ n) * A ^ n) := by
    have h := (hasSum_ordered_product n
      (fun _ j => Real.sqrt ((q₀ j).toReal * (q₁ j).toReal)) (fun _ => A)
      (fun _ _ => Real.sqrt_nonneg _) (fun _ => hmark.hasSum)).mul_left
      (Real.sqrt (poissonPMFReal b₀ n * poissonPMFReal b₁ n))
    simpa only [poissonSample_sqrt_product, Finset.prod_const, Finset.card_univ,
      Fintype.card_fin] using h
  have hsize : HasSum (fun n => Real.sqrt (poissonPMFReal b₀ n * poissonPMFReal b₁ n) * A ^ n)
      (Real.exp (-((b₀ : ℝ) + b₁) / 2 + (r : ℝ) * A)) := by
    have h := (poisson_pgf_hasSum r A).mul_left c
    have hc (n : ℕ) : c * (poissonPMFReal r n * A ^ n) =
        Real.sqrt (poissonPMFReal b₀ n * poissonPMFReal b₁ n) * A ^ n := by
      have hexp : c * Real.exp (-(r : ℝ)) = Real.exp (-((b₀ : ℝ) + b₁) / 2) := by
        dsimp [c]
        rw [← Real.exp_add]
        congr 1
        ring
      calc
        c * (poissonPMFReal r n * A ^ n) =
            (c * Real.exp (-(r : ℝ))) * (r : ℝ) ^ n / (n.factorial : ℝ) * A ^ n := by
          simp only [poissonPMFReal]
          ring
        _ = Real.exp (-((b₀ : ℝ) + b₁) / 2) *
            Real.sqrt ((b₀ : ℝ) * b₁) ^ n / (n.factorial : ℝ) * A ^ n := by
          rw [hexp]
          rfl
        _ = _ := by rw [sqrt_poisson_mass_product]
    have hv : c * Real.exp ((r : ℝ) * (A - 1)) =
        Real.exp (-((b₀ : ℝ) + b₁) / 2 + (r : ℝ) * A) := by
      rw [← Real.exp_add]
      congr 1
      ring
    simpa only [hc, hv] using h
  have hs : Summable (fun x : PoissonMarkedSample κ =>
      Real.sqrt ((poissonCountableSamplePMF b₀ q₀ x).toReal *
        (poissonCountableSamplePMF b₁ q₁ x).toReal)) :=
    (summable_sigma_of_nonneg (fun _ => Real.sqrt_nonneg _)).mpr
      ⟨fun n => (hrow n).summable, by
        simpa only [(hrow _).tsum_eq] using hsize.summable⟩
  have hsum := hs.tsum_sigma
  simp only [(hrow _).tsum_eq] at hsum
  exact (hsum.trans hsize.tsum_eq) ▸ hs.hasSum

/-- Total variation of the actual random-length ordered samples is controlled by
the squared distance between their square-root intensities. -/
theorem poissonSample_tv_le (b₀ b₁ : ℝ≥0) (q₀ q₁ : PMF κ) :
    (∑' x : PoissonMarkedSample κ,
      |(poissonCountableSamplePMF b₀ q₀ x).toReal -
        (poissonCountableSamplePMF b₁ q₁ x).toReal|) / 2 ≤
      Real.sqrt ((b₀ : ℝ) + b₁ - 2 * Real.sqrt ((b₀ : ℝ) * b₁) *
        ∑' j, Real.sqrt ((q₀ j).toReal * (q₁ j).toReal)) := by
  have h := discrete_tv_le_hellinger
    (fun x => (poissonCountableSamplePMF b₀ q₀ x).toReal)
    (fun x => (poissonCountableSamplePMF b₁ q₁ x).toReal)
    (fun _ => ENNReal.toReal_nonneg) (fun _ => ENNReal.toReal_nonneg)
    (pmfReal_hasSum _) (pmfReal_hasSum _)
  simp_rw [← Real.sqrt_mul ENNReal.toReal_nonneg] at h
  rw [(poissonSample_affinity b₀ b₁ q₀ q₁).tsum_eq] at h
  apply h.trans
  apply Real.sqrt_le_sqrt
  have he := Real.add_one_le_exp (-((b₀ : ℝ) + b₁) / 2 +
    Real.sqrt ((b₀ : ℝ) * b₁) * ∑' j, Real.sqrt ((q₀ j).toReal * (q₁ j).toReal))
  linarith

/-- The joint fingerprint law is the genuine countable product of its Poisson marginals. -/
theorem poisson_count_vector_law [DecidableEq κ] (b : ℝ≥0) (q : PMF κ) :
    (poissonCountableSamplePMF b q).toMeasure.map
      (fun x j => poissonMarkCount j x) =
      Measure.infinitePi (fun j => poissonMeasure (b * (q j).toNNReal)) := by
  have h := (iIndepFun_iff_map_fun_eq_infinitePi_map
    (fun j => measurable_of_countable (poissonMarkCount j))).mp
      (poisson_mark_counts_independent b q)
  simpa only [poisson_mark_count_law] using h

/-- Removing zero marks is represented by an ordinary Poisson iid marking
experiment with the same positive-mark intensities. -/
theorem visible_fingerprint_law_eq (b b' : ℝ≥0) (q q' : PMF ℕ)
    (hrate : ∀ j, b' * (q' j).toNNReal = b * (q (j + 1)).toNNReal) :
    (poissonCountableSamplePMF b q).toMeasure.map
      (fun x j => poissonMarkCount (j + 1) x) =
    (poissonCountableSamplePMF b' q').toMeasure.map
      (fun x j => poissonMarkCount j x) := by
  have hi := (poisson_mark_counts_independent b q).precomp
    (g := fun j : ℕ => j + 1) (fun i j h => Nat.add_right_cancel h)
  have h := (iIndepFun_iff_map_fun_eq_infinitePi_map
    (fun j => measurable_of_countable (poissonMarkCount (j + 1)))).mp hi
  rw [poisson_count_vector_law]
  simpa only [poisson_mark_count_law, hrate] using h

omit [Countable κ] [MeasurableSpace κ] [MeasurableSingletonClass κ] in
/-- The exact square-root intensity energy appearing in marked-Poisson total variation. -/
theorem poissonSample_intensity_energy (b₀ b₁ : ℝ≥0) (q₀ q₁ : PMF κ) :
    HasSum (fun j =>
      (Real.sqrt ((b₀ : ℝ) * (q₀ j).toReal) -
        Real.sqrt ((b₁ : ℝ) * (q₁ j).toReal)) ^ 2)
      ((b₀ : ℝ) + b₁ - 2 * Real.sqrt ((b₀ : ℝ) * b₁) *
        ∑' j, Real.sqrt ((q₀ j).toReal * (q₁ j).toReal)) := by
  have hmark : Summable (fun j => Real.sqrt ((q₀ j).toReal * (q₁ j).toReal)) := by
    simpa only [Real.sqrt_mul ENNReal.toReal_nonneg] using
      hellinger_affinity_summable (fun j => (q₀ j).toReal) (fun j => (q₁ j).toReal)
        (fun _ => ENNReal.toReal_nonneg) (fun _ => ENNReal.toReal_nonneg)
        (pmfReal_hasSum q₀) (pmfReal_hasSum q₁)
  have hs := (((pmfReal_hasSum q₀).mul_left (b₀ : ℝ)).add
    ((pmfReal_hasSum q₁).mul_left (b₁ : ℝ))).sub
      (hmark.hasSum.mul_left (2 * Real.sqrt ((b₀ : ℝ) * b₁)))
  convert hs using 1
  · funext j
    rw [sub_sq, Real.sq_sqrt (mul_nonneg b₀.coe_nonneg ENNReal.toReal_nonneg),
      Real.sq_sqrt (mul_nonneg b₁.coe_nonneg ENNReal.toReal_nonneg)]
    simp only [Real.sqrt_mul b₀.coe_nonneg, Real.sqrt_mul b₁.coe_nonneg,
      Real.sqrt_mul ENNReal.toReal_nonneg]
    ring
  · ring

/-- Total probability of a nonzero mark. -/
def positiveMarkMass (q : PMF ℕ) : ℝ≥0 :=
  ⟨∑' j, (q (j + 1)).toReal, tsum_nonneg (fun _ => ENNReal.toReal_nonneg)⟩

/-- Summability of the probabilities of positive marks. -/
theorem positiveMarkMass_hasSum (q : PMF ℕ) :
    HasSum (fun j => (q (j + 1)).toReal) (positiveMarkMass q : ℝ) :=
  ((summable_nat_add_iff 1).mpr (pmfReal_hasSum q).summable).hasSum

/-- The conditional distribution of a visible mark, reindexed from `j+1` to `j`. -/
def positiveMarkPMF (q : PMF ℕ) (hpos : 0 < (positiveMarkMass q : ℝ)) : PMF ℕ := by
  refine ⟨fun j => ENNReal.ofReal ((q (j + 1)).toReal / positiveMarkMass q), ?_⟩
  apply ENNReal.hasSum_coe.mpr
  rw [← Real.toNNReal_one]
  apply HasSum.toNNReal (fun j => div_nonneg ENNReal.toReal_nonneg hpos.le)
  have h := (positiveMarkMass_hasSum q).div_const (positiveMarkMass q : ℝ)
  simpa only [div_self (ne_of_gt hpos)] using h

@[simp] theorem positiveMarkPMF_toReal (q : PMF ℕ)
    (hpos : 0 < (positiveMarkMass q : ℝ)) (j : ℕ) :
    (positiveMarkPMF q hpos j).toReal = (q (j + 1)).toReal / positiveMarkMass q :=
  ENNReal.toReal_ofReal (div_nonneg ENNReal.toReal_nonneg hpos.le)

/-- Replacing the sample-size mean and conditioning the marks preserves every visible intensity. -/
theorem positiveMarkPMF_intensity (b : ℝ≥0) (q : PMF ℕ)
    (hpos : 0 < (positiveMarkMass q : ℝ)) (j : ℕ) :
    (b * positiveMarkMass q) * (positiveMarkPMF q hpos j).toNNReal =
      b * (q (j + 1)).toNNReal := by
  apply NNReal.eq
  simp only [NNReal.coe_mul, ENNReal.coe_toNNReal_eq_toReal, positiveMarkPMF_toReal]
  field_simp

/-- The true positive fingerprint equals the fingerprint of the visible-mark sample. -/
theorem positive_fingerprint_law (b : ℝ≥0) (q : PMF ℕ)
    (hpos : 0 < (positiveMarkMass q : ℝ)) :
    (poissonCountableSamplePMF b q).toMeasure.map
      (fun x j => poissonMarkCount (j + 1) x) =
    (poissonCountableSamplePMF (b * positiveMarkMass q) (positiveMarkPMF q hpos)).toMeasure.map
      (fun x j => poissonMarkCount j x) :=
  visible_fingerprint_law_eq b (b * positiveMarkMass q) q (positiveMarkPMF q hpos)
    (positiveMarkPMF_intensity b q hpos)

/-- A visible-mark law defined also when no positive mark has any probability.
The arbitrary mark in that case is harmless because its Poisson mean is zero. -/
def visibleMarkPMF (q : PMF ℕ) : PMF ℕ :=
  if h : 0 < (positiveMarkMass q : ℝ) then positiveMarkPMF q h else PMF.pure 0

/-- Visible intensities are exact even for the degenerate all-zero mark law. -/
theorem visibleMarkPMF_intensity (b : ℝ≥0) (q : PMF ℕ) (j : ℕ) :
    (b * positiveMarkMass q) * (visibleMarkPMF q j).toNNReal =
      b * (q (j + 1)).toNNReal := by
  by_cases hpos : 0 < (positiveMarkMass q : ℝ)
  · simpa only [visibleMarkPMF, dif_pos hpos] using positiveMarkPMF_intensity b q hpos j
  · have hs0 : (positiveMarkMass q : ℝ) = 0 :=
      le_antisymm (le_of_not_gt hpos) (positiveMarkMass q).coe_nonneg
    have hjle := (positiveMarkMass_hasSum q).summable.le_tsum j
      (fun _ _ => ENNReal.toReal_nonneg)
    have hj0 : (q (j + 1)).toReal = 0 := by
      change (q (j + 1)).toReal ≤ (positiveMarkMass q : ℝ) at hjle
      exact le_antisymm (hs0 ▸ hjle) ENNReal.toReal_nonneg
    apply NNReal.eq
    simp only [NNReal.coe_mul, ENNReal.coe_toNNReal_eq_toReal, hs0, hj0, mul_zero, zero_mul]

/-- The full positive fingerprint law equals a visible-mark experiment, with no
nondegeneracy assumption. -/
theorem visible_fingerprint_law (b : ℝ≥0) (q : PMF ℕ) :
    (poissonCountableSamplePMF b q).toMeasure.map
      (fun x j => poissonMarkCount (j + 1) x) =
    (poissonCountableSamplePMF (b * positiveMarkMass q) (visibleMarkPMF q)).toMeasure.map
      (fun x j => poissonMarkCount j x) :=
  visible_fingerprint_law_eq b (b * positiveMarkMass q) q (visibleMarkPMF q)
    (visibleMarkPMF_intensity b q)

/-- Exact source count-distance bound before histogramming the visible sample.
Only positive counts occur in countDistance; zero-count discrepancies are absent. -/
theorem visible_poisson_sample_tv_le_countDistance (b : ℝ≥0) (q₀ q₁ : PMF ℕ)
    :
    (∑' x : PoissonMarkedSample ℕ,
      |(poissonCountableSamplePMF (b * positiveMarkMass q₀) (visibleMarkPMF q₀) x).toReal -
        (poissonCountableSamplePMF (b * positiveMarkMass q₁) (visibleMarkPMF q₁) x).toReal|) / 2 ≤
      Real.sqrt ((b : ℝ) * countDistance (fun j => (q₀ j).toReal) (fun j => (q₁ j).toReal)) := by
  have htv := poissonSample_tv_le (b * positiveMarkMass q₀) (b * positiveMarkMass q₁)
    (visibleMarkPMF q₀) (visibleMarkPMF q₁)
  have henergy := poissonSample_intensity_energy
    (b * positiveMarkMass q₀) (b * positiveMarkMass q₁)
      (visibleMarkPMF q₀) (visibleMarkPMF q₁)
  have hrate₀ (j : ℕ) : ((b * positiveMarkMass q₀ : ℝ≥0) : ℝ) *
      (visibleMarkPMF q₀ j).toReal = (b : ℝ) * (q₀ (j + 1)).toReal := by
    simpa only [NNReal.coe_mul, ENNReal.coe_toNNReal_eq_toReal] using
      congrArg (fun r : ℝ≥0 => (r : ℝ)) (visibleMarkPMF_intensity b q₀ j)
  have hrate₁ (j : ℕ) : ((b * positiveMarkMass q₁ : ℝ≥0) : ℝ) *
      (visibleMarkPMF q₁ j).toReal = (b : ℝ) * (q₁ (j + 1)).toReal := by
    simpa only [NNReal.coe_mul, ENNReal.coe_toNNReal_eq_toReal] using
      congrArg (fun r : ℝ≥0 => (r : ℝ)) (visibleMarkPMF_intensity b q₁ j)
  have hterm (j : ℕ) :
      (Real.sqrt (((b * positiveMarkMass q₀ : ℝ≥0) : ℝ) * (visibleMarkPMF q₀ j).toReal) -
        Real.sqrt (((b * positiveMarkMass q₁ : ℝ≥0) : ℝ) * (visibleMarkPMF q₁ j).toReal)) ^ 2 ≤
      (b : ℝ) * countDistanceTerm (fun j => (q₀ j).toReal) (fun j => (q₁ j).toReal) (j + 1) := by
    rw [hrate₀, hrate₁, Real.sqrt_mul b.coe_nonneg, Real.sqrt_mul b.coe_nonneg,
      ← mul_sub, mul_pow, Real.sq_sqrt b.coe_nonneg]
    apply mul_le_mul_of_nonneg_left _ b.coe_nonneg
    simpa only [countDistanceTerm, Nat.add_eq_zero_iff, Nat.one_ne_zero,
      and_false, if_false, add_comm, sub_sq_comm] using
      sqrt_distance_sq_le (x := (q₀ (j + 1)).toReal) (y := (q₁ (j + 1)).toReal)
        ENNReal.toReal_nonneg ENNReal.toReal_nonneg
  have hD := countDistanceTerm_summable (fun j => (q₀ j).toReal) (fun j => (q₁ j).toReal)
    (pmfReal_hasSum q₀).summable (pmfReal_hasSum q₁).summable
    (fun _ => ENNReal.toReal_nonneg) (fun _ => ENNReal.toReal_nonneg)
  have hshift : (∑' j, countDistanceTerm (fun j => (q₀ j).toReal)
      (fun j => (q₁ j).toReal) (j + 1)) =
      countDistance (fun j => (q₀ j).toReal) (fun j => (q₁ j).toReal) := by
    simpa only [countDistance, countDistanceTerm, if_pos rfl, ite_true, zero_add] using
      hD.tsum_eq_zero_add.symm
  have hbound := henergy.summable.tsum_le_tsum hterm
    (((summable_nat_add_iff 1).mpr hD).mul_left (b : ℝ))
  rw [henergy.tsum_eq, tsum_mul_left, hshift] at hbound
  exact htv.trans (Real.sqrt_le_sqrt hbound)

/-- Every event of the actual positive fingerprint satisfies the source total
variation bound. This is an event formulation of TV on the countable product
observation space; no assumed data-processing or marking certificate is used. -/
theorem fingerprint_event_distance (b : ℝ≥0) (q₀ q₁ : PMF ℕ)
    (E : Set (ℕ → ℕ)) (hE : MeasurableSet E) :
    |(poissonCountableSamplePMF b q₀).toMeasure.real
        {x | (fun j => poissonMarkCount (j + 1) x) ∈ E} -
      (poissonCountableSamplePMF b q₁).toMeasure.real
        {x | (fun j => poissonMarkCount (j + 1) x) ∈ E}| ≤
      Real.sqrt ((b : ℝ) * countDistance (fun j => (q₀ j).toReal) (fun j => (q₁ j).toReal)) := by
  have hevent (q : PMF ℕ) : (poissonCountableSamplePMF b q).toMeasure.real
      {x | (fun j => poissonMarkCount (j + 1) x) ∈ E} =
      (poissonCountableSamplePMF (b * positiveMarkMass q) (visibleMarkPMF q)).toMeasure.real
        {x | (fun j => poissonMarkCount j x) ∈ E} := by
    have h := congrArg (fun μ : Measure (ℕ → ℕ) => μ E) (visible_fingerprint_law b q)
    dsimp only at h
    rw [Measure.map_apply (measurable_of_countable _) hE,
      Measure.map_apply (measurable_of_countable _) hE] at h
    exact congrArg ENNReal.toReal h
  rw [hevent q₀, hevent q₁]
  exact (pmf_event_tv_bound _ _ _).trans (visible_poisson_sample_tv_le_countDistance b q₀ q₁)

/-- Integrating out latent atom labels preserves every reported fingerprint event. -/
theorem transformed_fingerprint_event_eq (b : ℝ≥0) (q : PMF κ) (f : κ → ℕ)
    (E : Set (ℕ → ℕ)) :
    (poissonCountableSamplePMF b q).toMeasure.real
      {x | (fun j => poissonMarkCount (j + 1) (mapPoissonMarks f x)) ∈ E} =
    (poissonCountableSamplePMF b (q.map f)).toMeasure.real
      {x | (fun j => poissonMarkCount (j + 1) x) ∈ E} := by
  let S := {x : PoissonMarkedSample ℕ | (fun j => poissonMarkCount (j + 1) x) ∈ E}
  have hmap := PMF.toMeasure_map (mapPoissonMarks f) (poissonCountableSamplePMF b q)
    (measurable_of_countable _)
  rw [poissonCountableSamplePMF_map] at hmap
  have h := congrArg (fun μ : Measure (PoissonMarkedSample ℕ) => μ S) hmap
  dsimp only at h
  rw [Measure.map_apply (measurable_of_countable _) (Set.to_countable S).measurableSet] at h
  exact congrArg ENNReal.toReal h

/-- The distance part of the source fingerprint-transfer lemma for the original
two-stage finite atomic prior experiments. Their atom supports may differ. -/
theorem atomic_fingerprint_event_distance
    {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    [MeasurableSpace ι₀] [MeasurableSingletonClass ι₀]
    [MeasurableSpace ι₁] [MeasurableSingletonClass ι₁]
    (b : ℝ≥0) (mass₀ value₀ : ι₀ → ℝ) (mass₁ value₁ : ι₁ → ℝ) (θ : ℝ)
    (hmass₀ : ∀ i, 0 ≤ mass₀ i) (hprob₀ : ∑ i, mass₀ i = 1)
    (hvalue₀ : ∀ i, 0 ≤ value₀ i)
    (hmass₁ : ∀ i, 0 ≤ mass₁ i) (hprob₁ : ∑ i, mass₁ i = 1)
    (hvalue₁ : ∀ i, 0 ≤ value₁ i) (hθ : 0 ≤ θ)
    (E : Set (ℕ → ℕ)) (hE : MeasurableSet E) :
    |(poissonCountableSamplePMF b
        (atomicPoissonMarkPMF mass₀ value₀ θ hmass₀ hprob₀ hvalue₀ hθ)).toMeasure.real
        {x | (fun j => poissonMarkCount (j + 1) (mapPoissonMarks Prod.snd x)) ∈ E} -
      (poissonCountableSamplePMF b
        (atomicPoissonMarkPMF mass₁ value₁ θ hmass₁ hprob₁ hvalue₁ hθ)).toMeasure.real
        {x | (fun j => poissonMarkCount (j + 1) (mapPoissonMarks Prod.snd x)) ∈ E}| ≤
      Real.sqrt ((b : ℝ) * countDistance
        (poissonMixture mass₀ value₀ θ) (poissonMixture mass₁ value₁ θ)) := by
  rw [transformed_fingerprint_event_eq, transformed_fingerprint_event_eq]
  have h := fingerprint_event_distance b
    ((atomicPoissonMarkPMF mass₀ value₀ θ hmass₀ hprob₀ hvalue₀ hθ).map Prod.snd)
    ((atomicPoissonMarkPMF mass₁ value₁ θ hmass₁ hprob₁ hvalue₁ hθ).map Prod.snd) E hE
  simpa only [atomicPoissonMarkPMF_snd_apply, ENNReal.toReal_ofReal
    (poissonMixture_nonneg mass₀ value₀ θ _ hmass₀ hvalue₀ hθ),
    ENNReal.toReal_ofReal (poissonMixture_nonneg mass₁ value₁ θ _ hmass₁ hvalue₁ hθ)] using h

end Renyi




