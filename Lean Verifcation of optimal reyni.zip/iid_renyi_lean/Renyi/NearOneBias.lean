import Renyi.NearOneTangent
import Renyi.NearOneMargins
import Renyi.CoupledLocalization

/-! Localized bias of the actual tangent/endpoint construction near order one. -/
noncomputable section
namespace Renyi

theorem abs_exp_sub_one_bound (z : ℝ) :
    |Real.exp z-1|≤Real.exp |z| * |z| := by
  by_cases hz : 0≤z
  · have he : 1≤Real.exp z := Real.one_le_exp_iff.mpr hz
    rw [abs_of_nonneg hz, abs_of_nonneg (sub_nonneg.mpr he)]
    have h := exp_difference_tangent z 0
    simp only [Real.exp_zero,zero_sub] at h
    nlinarith
  · have hz' : z≤0 := (lt_of_not_ge hz).le
    have he : Real.exp z≤1 := Real.exp_le_one_iff.mpr hz'
    rw [abs_of_nonpos hz',abs_of_nonpos (sub_nonpos.mpr he)]
    have h := Real.add_one_le_exp z
    have hE : 1≤Real.exp (-z) := Real.one_le_exp_iff.mpr (by linarith)
    have hh := mul_le_mul_of_nonneg_right hE (by linarith : 0≤-z)
    nlinarith

theorem compact_rpow_difference {r beta M : ℝ} (hr : 0<r) (hb : 0≤beta)
    (hb1 : beta≤1) (hM : |Real.log r|≤M) :
    |r^beta-1|≤(Real.exp M*M)*beta := by
  have hM0 : 0≤M := (abs_nonneg _).trans hM
  have hz : |Real.log r*beta|≤M*beta := by
    rw [abs_mul,abs_of_nonneg hb]
    exact mul_le_mul_of_nonneg_right hM hb
  have hzM : |Real.log r*beta|≤M := hz.trans (mul_le_of_le_one_right hM0 hb1)
  have h := abs_exp_sub_one_bound (Real.log r*beta)
  rw [← Real.rpow_def_of_pos hr] at h
  have hh := mul_le_mul (Real.exp_le_exp.mpr hzM) hz (abs_nonneg _)
    (Real.exp_pos _).le
  nlinarith only [h,hh]

theorem compact_rpow_upper {r q M : ℝ} (hr : 0<r) (hq : 0≤q)
    (hq2 : q≤2) (hM : |Real.log r|≤M) : r^q≤Real.exp (2*M) := by
  rw [Real.rpow_def_of_pos hr]
  apply Real.exp_le_exp.mpr
  have hM0 : 0≤M := (abs_nonneg _).trans hM
  have hh := mul_le_mul_of_nonneg_right ((le_abs_self _).trans hM) hq
  nlinarith

theorem endpoint_cutoff_linear_bound {N : ℕ} (hN : 0<N) {y : ℝ}
    (hy : 0≤y) (hyR : y≤(N:ℝ)^2) :
    y*(1-endpointProfile N 6 1 (y/(N:ℝ)^2)) ≤ 1+Real.exp (Real.log 12+1) := by
  have hR : 0<(N:ℝ)^2 := by positivity
  have hx1 : y/(N:ℝ)^2≤1 := (div_le_one hR).mpr hyR
  have hJ := endpointProfile_range (d:=6) hN (by norm_num) (s:=1) (by norm_num)
    (div_nonneg hy hR.le) hx1
  by_cases hy1 : y≤1
  · have hh := mul_le_of_le_one_left (by linarith : 0≤1-endpointProfile N 6 1 (y/(N:ℝ)^2)) hy1
    nlinarith [Real.exp_pos (Real.log 12+1)]
  · have hy1' : 1≤y := (lt_of_not_ge hy1).le
    have hypos : 0<y := zero_lt_one.trans_le hy1'
    have ht := endpointProfile_tail (d:=6) hN (by norm_num) (by norm_num)
      (s:=1) (by norm_num) le_rfl (div_pos hypos hR) hx1
    rw [mul_div_cancel₀ _ hR.ne'] at ht
    have ht' : 1-endpointProfile N 6 1 (y/(N:ℝ)^2)≤
        Real.exp (Real.log 12+1)*y^(-(5:ℝ)) := by
      convert ht using 1
      norm_num
    have hh := mul_le_mul_of_nonneg_left ht' hy
    have hp : y*y^(-(5:ℝ))≤1 := by
      calc
        _ = y^(1:ℝ)*y^(-(5:ℝ)) := by rw [Real.rpow_one]
        _ = y^(-(4:ℝ)) := by rw [← Real.rpow_add hypos]; norm_num
        _ ≤ 1 := Real.rpow_le_one_of_one_le_of_nonpos hy1' (by norm_num)
    have hp' := mul_le_mul_of_nonneg_left hp (Real.exp_pos (Real.log 12+1)).le
    nlinarith only [hh,hp']

def unitTangent (r beta y : ℝ) : ℝ := (1+beta)*r^beta*y-beta*r^(1+beta)

def tangentReplacementConstant (M : ℝ) : ℝ :=
  2*Real.exp M*M*(1+Real.exp (Real.log 12+1))+Real.exp (2*M)+1

theorem tangent_replacement_cutoff {N : ℕ} (hN : 0<N) {r beta M y : ℝ}
    (hr : 0<r) (hb : 0≤beta) (hb1 : beta≤1/2) (hM : |Real.log r|≤M)
    (hy : 0≤y) (hyR : y≤(N:ℝ)^2) :
    |(unitTangent r beta y-unitTangent 1 beta y)*
      (1-endpointProfile N 6 1 (y/(N:ℝ)^2))|≤tangentReplacementConstant M*beta := by
  have hM0 : 0≤M := (abs_nonneg _).trans hM
  have hR : 0<(N:ℝ)^2 := by positivity
  have hJ := endpointProfile_range (d:=6) hN (by norm_num) (s:=1) (by norm_num)
    (div_nonneg hy hR.le) ((div_le_one hR).mpr hyR)
  have hcut0 : 0≤1-endpointProfile N 6 1 (y/(N:ℝ)^2) := by linarith [hJ.2]
  have hcut1 : 1-endpointProfile N 6 1 (y/(N:ℝ)^2)≤1 := by linarith [hJ.1]
  have hrp := compact_rpow_difference hr hb (by linarith) hM
  have hrp' := compact_rpow_upper hr (by linarith : 0≤1+beta) (by linarith) hM
  have hsecond : |r^(1+beta)-1|≤Real.exp (2*M)+1 := by
    have h := abs_sub_le (r^(1+beta)) 0 1
    simp only [sub_zero,zero_sub,abs_neg,abs_one,
      abs_of_nonneg (Real.rpow_nonneg hr.le _)] at h
    exact h.trans (add_le_add_right hrp' 1)
  have hid : unitTangent r beta y-unitTangent 1 beta y =
      (1+beta)*(r^beta-1)*y-beta*(r^(1+beta)-1) := by
    simp only [unitTangent,Real.one_rpow]
    ring
  rw [hid,abs_mul,abs_of_nonneg hcut0]
  have habs := abs_sub_le ((1+beta)*(r^beta-1)*y) 0 (beta*(r^(1+beta)-1))
  simp only [sub_zero,zero_sub,abs_neg,abs_mul,abs_of_nonneg (by linarith : 0≤1+beta),
    abs_of_nonneg hy,abs_of_nonneg hb] at habs
  have h1 := mul_le_mul_of_nonneg_left hrp (by linarith : 0≤1+beta)
  have h2 := mul_le_mul_of_nonneg_left hsecond hb
  have h3 := mul_le_mul_of_nonneg_right h1 hy
  have h4 := mul_le_mul_of_nonneg_right (show
      |(1+beta)*(r^beta-1)*y-beta*(r^(1+beta)-1)|≤
        (1+beta)*(Real.exp M*M*beta)*y+beta*(Real.exp (2*M)+1) by linarith)
    hcut0
  have hlin := endpoint_cutoff_linear_bound hN hy hyR
  have h5 := mul_le_mul_of_nonneg_left hlin (by positivity : 0≤(1+beta)*(Real.exp M*M*beta))
  have h6 := mul_le_mul_of_nonneg_left hcut1 (by positivity : 0≤beta*(Real.exp (2*M)+1))
  have h7 := mul_le_mul_of_nonneg_right (show 1+beta≤2 by linarith)
    (by positivity : 0≤Real.exp M*M*beta*(1+Real.exp (Real.log 12+1)))
  dsimp [tangentReplacementConstant]
  nlinarith only [h4,h5,h6,h7]


def tangentCutoffConstant (M : ℝ) : ℝ :=
  (3+2*Real.exp (Real.log 12+1))*Real.exp (2*M)

theorem tangent_cutoff_bound {N : ℕ} (hN : 0<N) {r beta M y : ℝ}
    (hr : 0<r) (hb : 0≤beta) (hb1 : beta≤1/2) (hM : |Real.log r|≤M)
    (hy : 0≤y) (hyR : y≤(N:ℝ)^2) :
    |unitTangent r beta y*(1-endpointProfile N 6 1 (y/(N:ℝ)^2))|≤
      tangentCutoffConstant M := by
  have hR : 0<(N:ℝ)^2 := by positivity
  have hJ := endpointProfile_range (d:=6) hN (by norm_num) (s:=1) (by norm_num)
    (div_nonneg hy hR.le) ((div_le_one hR).mpr hyR)
  have hcut0 : 0≤1-endpointProfile N 6 1 (y/(N:ℝ)^2) := by linarith [hJ.2]
  have hcut1 : 1-endpointProfile N 6 1 (y/(N:ℝ)^2)≤1 := by linarith [hJ.1]
  have hp := compact_rpow_upper hr hb (by linarith) hM
  have hp' := compact_rpow_upper hr (by linarith : 0≤1+beta) (by linarith) hM
  have hlin := endpoint_cutoff_linear_bound hN hy hyR
  have ha := abs_sub_le ((1+beta)*r^beta*y) 0 (beta*r^(1+beta))
  simp only [sub_zero,zero_sub,abs_neg,
    abs_of_nonneg (by positivity : 0≤(1+beta)*r^beta*y),
    abs_of_nonneg (by positivity : 0≤beta*r^(1+beta))] at ha
  rw [abs_mul,abs_of_nonneg hcut0]
  have h0 := mul_le_mul_of_nonneg_right ha hcut0
  have h1 := mul_le_mul hp hlin (mul_nonneg hy hcut0) (Real.exp_pos _).le
  have h2 := mul_le_mul_of_nonneg_left h1 (by linarith : 0≤1+beta)
  have h3 := mul_le_mul hp' hcut1 hcut0 (Real.exp_pos _).le
  have h4 := mul_le_mul_of_nonneg_left h3 hb
  have h5 := mul_le_mul_of_nonneg_right (show 1+beta≤2 by linarith)
    (by positivity : 0≤Real.exp (2*M)*(1+Real.exp (Real.log 12+1)))
  have h6 := mul_le_mul_of_nonneg_right (show beta≤1 by linarith) (Real.exp_pos (2*M)).le
  dsimp [unitTangent,tangentCutoffConstant] at *
  nlinarith only [h0,h2,h4,h5,h6]

theorem high_profile_near_one_weighted {N : ℕ} (hN : 0<N) {beta f omega y : ℝ}
    (hb : 0≤beta) (hb1 : beta≤1/2) (hf : 0≤f) (hf1 : f≤1)
    (hw : 0≤omega) (hw1 : omega<1) (hy : 0≤y) (hyR : y≤(N:ℝ)^2) :
    |y^(1+beta)*(highProfile N (1-beta) f omega (y/(N:ℝ)^2)-
      omega*endpointProfile N 6 (1-beta) (y/(N:ℝ)^2))|≤coupledLocalizationConstant := by
  have hR : 0<(N:ℝ)^2 := by positivity
  have h := highProfile_localization hN (s:=1-beta) (by linarith) (by linarith)
    hf hf1 hw hw1 (div_nonneg hy hR.le) ((div_le_one hR).mpr hyR)
  rw [mul_div_cancel₀ _ hR.ne'] at h
  rw [abs_mul,abs_of_nonneg (Real.rpow_nonneg hy _)]
  have hp : y^(1+beta)*min (y^(1-beta)) (y^(-3:ℝ))≤1 := by
    by_cases hy0 : y=0
    · subst y
      simp only [Real.zero_rpow (by linarith : 1+beta≠0),zero_mul]
      norm_num
    have hypos : 0<y := lt_of_le_of_ne hy (Ne.symm hy0)
    by_cases hy1 : y≤1
    · calc
        _ ≤ y^(1+beta)*y^(1-beta) :=
          mul_le_mul_of_nonneg_left (min_le_left _ _) (Real.rpow_nonneg hy _)
        _ = y^(2:ℝ) := by rw [← Real.rpow_add hypos]; congr 1; ring
        _ ≤ 1 := Real.rpow_le_one hy hy1 (by norm_num)
    · calc
        _ ≤ y^(1+beta)*y^(-3:ℝ) :=
          mul_le_mul_of_nonneg_left (min_le_right _ _) (Real.rpow_nonneg hy _)
        _ = y^(1+beta-3) := by rw [← Real.rpow_add hypos]; congr 1
        _ ≤ 1 := Real.rpow_le_one_of_one_le_of_nonpos (le_of_not_ge hy1) (by linarith)
  have hh := mul_le_mul_of_nonneg_left h (Real.rpow_nonneg hy (1+beta))
  have hp' := mul_le_mul_of_nonneg_left hp
    (show 0≤coupledLocalizationConstant from (Real.exp_pos _).le)
  nlinarith only [hh,hp']


def scaledNearOneExpression (N : ℕ) (r beta f omega A B s0 y : ℝ) : ℝ :=
  s0*(A*unitTangent r beta y*(1-endpointProfile N 6 1 (y/(N:ℝ)^2)) +
    omega*y^(1+beta)*endpointProfile N 6 (1-beta) (y/(N:ℝ)^2) +
    B*y^(1+beta)*(highProfile N (1-beta) f omega (y/(N:ℝ)^2)-
      omega*endpointProfile N 6 (1-beta) (y/(N:ℝ)^2)))

theorem scaled_near_one_bias {N : ℕ} (hN : 0<N) {r beta f omega A B s0 M C y : ℝ}
    (hr : 0<r) (hb : 0≤beta) (hb1 : beta≤1/2) (hM : |Real.log r|≤M)
    (hf : 0≤f) (hf1 : f≤1) (hw : 0≤omega) (hw1 : omega<1)
    (hs0 : 0≤s0) (hs1 : s0≤1) (hC : 0≤C)
    (hA : |A-omega|≤C*beta) (hB : |B|≤C*beta)
    (hy : 0≤y) (hyR : y≤(N:ℝ)^2) :
    |scaledNearOneExpression N r beta f omega A B s0 y-s0*omega*y^(1+beta)| ≤
      (nearOneTangentConstant+tangentReplacementConstant M+
        C*(tangentCutoffConstant M+coupledLocalizationConstant))*beta := by
  let cut := 1-endpointProfile N 6 1 (y/(N:ℝ)^2)
  let Js := endpointProfile N 6 (1-beta) (y/(N:ℝ)^2)
  let V := highProfile N (1-beta) f omega (y/(N:ℝ)^2)
  let X := unitTangent r beta y*cut+y^(1+beta)*Js-y^(1+beta)
  let T := unitTangent r beta y*cut
  let H := y^(1+beta)*(V-omega*Js)
  have hbase := endpoint_tangent_cancellation hN hb hb1 hy hyR
  have hb' : |unitTangent 1 beta y*cut+y^(1+beta)*Js-y^(1+beta)|≤
      nearOneTangentConstant*beta := by
    convert hbase using 1
    congr 1
    simp only [unitTangent,Real.one_rpow,unitTangentError,cut,Js]
    ring
  have hrep := tangent_replacement_cutoff hN hr hb hb1 hM hy hyR
  have hX : |X|≤(nearOneTangentConstant+tangentReplacementConstant M)*beta := by
    have heq : X=(unitTangent 1 beta y*cut+y^(1+beta)*Js-y^(1+beta))+
        (unitTangent r beta y-unitTangent 1 beta y)*cut := by dsimp [X]; ring
    rw [heq]
    have ha := abs_add_le
      (unitTangent 1 beta y*cut+y^(1+beta)*Js-y^(1+beta))
      ((unitTangent r beta y-unitTangent 1 beta y)*cut)
    change |(unitTangent r beta y-unitTangent 1 beta y)*cut|≤_ at hrep
    linarith
  have hT : |T|≤tangentCutoffConstant M := tangent_cutoff_bound hN hr hb hb1 hM hy hyR
  have hH : |H|≤coupledLocalizationConstant :=
    high_profile_near_one_weighted hN hb hb1 hf hf1 hw hw1 hy hyR
  have hT0 : 0≤tangentCutoffConstant M := (abs_nonneg _).trans hT
  have hH0 : 0≤coupledLocalizationConstant := (abs_nonneg _).trans hH
  have heq : scaledNearOneExpression N r beta f omega A B s0 y-s0*omega*y^(1+beta)=
      s0*(omega*X+(A-omega)*T+B*H) := by
    dsimp [scaledNearOneExpression,X,T,H,cut,Js,V]
    ring
  rw [heq,abs_mul,abs_of_nonneg hs0]
  have ha1 := abs_add_le (omega*X+(A-omega)*T) (B*H)
  have ha2 := abs_add_le (omega*X) ((A-omega)*T)
  rw [abs_mul,abs_of_nonneg hw] at ha2
  rw [abs_mul] at ha1
  have hbnd1 : omega*|X|≤(nearOneTangentConstant+tangentReplacementConstant M)*beta :=
    (mul_le_of_le_one_left (abs_nonneg X) hw1.le).trans hX
  have hbnd2 := mul_le_mul hA hT (abs_nonneg T) (mul_nonneg hC hb)
  have hbnd3 := mul_le_mul hB hH (abs_nonneg H) (mul_nonneg hC hb)
  rw [abs_mul] at ha2
  have hsum : |omega*X+(A-omega)*T+B*H|≤
      (nearOneTangentConstant+tangentReplacementConstant M+
        C*(tangentCutoffConstant M+coupledLocalizationConstant))*beta := by
    nlinarith only [ha1,ha2,hbnd1,hbnd2,hbnd3]
  exact (mul_le_of_le_one_left (abs_nonneg _) hs1).trans hsum


def tangentPlane (tau beta p : ℝ) : ℝ :=
  (1+beta)*tau^beta*p-beta*tau^(1+beta)

def nearOneExpression (N : ℕ) (tau beta f omega A B s0 b p : ℝ) : ℝ :=
  s0*(A*tangentPlane tau beta p*(1-endpointProfile N 6 1 (p/b)) +
    omega*p^(1+beta)*endpointProfile N 6 (1-beta) (p/b) +
    B*p^(1+beta)*(highProfile N (1-beta) f omega (p/b)-
      omega*endpointProfile N 6 (1-beta) (p/b)))

theorem tangentPlane_rescale {t r y : ℝ} (ht : 0<t) (hr : 0≤r)
    (beta : ℝ) : tangentPlane (t*r) beta (t*y)=t^(1+beta)*unitTangent r beta y := by
  unfold tangentPlane unitTangent
  rw [Real.mul_rpow ht.le hr,Real.mul_rpow ht.le hr]
  have hp : t*t^beta=t^(1+beta) := by
    calc
      _ = t^(1:ℝ)*t^beta := by rw [Real.rpow_one]
      _ = _ := (Real.rpow_add ht _ _).symm
  rw [← hp]
  ring

theorem nearOneExpression_rescale (N : ℕ) {t r y : ℝ} (ht : 0<t)
    (hr : 0≤r) (hy : 0≤y) (beta f omega A B s0 : ℝ) :
    nearOneExpression N (t*r) beta f omega A B s0 (t*(N:ℝ)^2) (t*y)=
      t^(1+beta)*scaledNearOneExpression N r beta f omega A B s0 y := by
  have hquot : (t*y)/(t*(N:ℝ)^2)=y/(N:ℝ)^2 := mul_div_mul_left y _ ht.ne'
  unfold nearOneExpression scaledNearOneExpression
  rw [hquot,tangentPlane_rescale ht hr,Real.mul_rpow ht.le hy]
  ring

/-- Localized bias in the manuscript probability units, including p=0. -/
theorem near_one_expression_bias {N : ℕ} (hN : 0<N)
    {tau beta f omega A B s0 b p M C : ℝ} (htau : 0<tau) (hb : 0<b)
    (hbeta : 0≤beta) (hbeta1 : beta≤1/2)
    (hM : |Real.log (tau/(b/(N:ℝ)^2))|≤M)
    (hf : 0≤f) (hf1 : f≤1) (hw : 0≤omega) (hw1 : omega<1)
    (hs0 : 0≤s0) (hs1 : s0≤1) (hC : 0≤C)
    (hA : |A-omega|≤C*beta) (hB : |B|≤C*beta) (hp : 0≤p) (hpb : p≤b) :
    |nearOneExpression N tau beta f omega A B s0 b p-s0*omega*p^(1+beta)| ≤
      (nearOneTangentConstant+tangentReplacementConstant M+
        C*(tangentCutoffConstant M+coupledLocalizationConstant))*beta*(b/(N:ℝ)^2)^(1+beta) := by
  let t := b/(N:ℝ)^2
  let r := tau/t
  let y := p/t
  have hR : 0<(N:ℝ)^2 := by positivity
  have ht : 0<t := div_pos hb hR
  have hr : 0<r := div_pos htau ht
  have hy : 0≤y := div_nonneg hp ht.le
  have htR : t*(N:ℝ)^2=b := by dsimp [t]; field_simp
  have hyR : y≤(N:ℝ)^2 := (div_le_iff₀ ht).mpr (by rw [mul_comm,htR]; exact hpb)
  have htr : t*r=tau := by dsimp [r]; field_simp
  have hty : t*y=p := by dsimp [y]; field_simp
  have hid := nearOneExpression_rescale N ht hr.le hy beta f omega A B s0
  rw [htr,hty,htR] at hid
  have hpPower : p^(1+beta)=t^(1+beta)*y^(1+beta) := by
    rw [← hty,Real.mul_rpow ht.le hy]
  have h := scaled_near_one_bias hN hr hbeta hbeta1 hM hf hf1 hw hw1 hs0 hs1 hC hA hB hy hyR
  rw [hid,hpPower,show t^(1+beta)*scaledNearOneExpression N r beta f omega A B s0 y-
    s0*omega*(t^(1+beta)*y^(1+beta))=
      t^(1+beta)*(scaledNearOneExpression N r beta f omega A B s0 y-s0*omega*y^(1+beta)) by ring,
    abs_mul,abs_of_nonneg (Real.rpow_nonneg ht.le _)]
  have hh := mul_le_mul_of_nonneg_left h (Real.rpow_nonneg ht.le (1+beta))
  nlinarith only [hh]

end Renyi
