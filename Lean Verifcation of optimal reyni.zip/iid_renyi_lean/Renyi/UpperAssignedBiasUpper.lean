import Renyi.AssignedUpperTransfer
import Renyi.FixedHeavyCorrectionAbsorption

/-! The actual corrected source mean has a full upper budget with a realized heavy aggregate. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 700000

/-- The upper spatial reserve covers the complete forward bonus up to the known cutoff loss. -/
lemma actualForwardBonus_le_assigned_spatial {k : ℕ} {alpha eps Ch D cb lambda CL cL : ℝ}
    (ha : 0≤upperA k alpha eps Ch D cb lambda CL cL) (halpha : 0≤alpha)
    (hg : 0≤fractionalPart alpha) (hg1 : fractionalPart alpha≤1)
    (p : Simplex k) (light : Fin k→Bool) :
    actualForwardBonus p alpha eps D cb CL cL≤
      actualLightSpatialMargin p light alpha eps Ch D cb lambda CL cL+
        assignedHeavyPower p light alpha+(k:ℝ)*(upperA k alpha eps Ch D cb lambda CL cL)^alpha := by
  let a := upperA k alpha eps Ch D cb lambda CL cL
  let b := upperB k alpha eps D cb CL cL
  let N := upperDegree alpha CL cL (rootMultiplier k alpha eps)
  let ell := upperLowResolution alpha
  have hcut := assigned_forward_bonus_cutoff_loss (N:=N) (b:=b) ha halpha p light
  have hsum : (∑ i, if light i then if a≤p.mass i then
      (p.mass i)^alpha*min ((N:ℝ)^2*(p.mass i/b)) 1 else 0 else 0)≤
      actualLightSpatialMargin p light alpha eps Ch D cb lambda CL cL := by
    change (∑ i, if light i then if a≤p.mass i then (p.mass i)^alpha*min ((N:ℝ)^2*(p.mass i/b)) 1 else 0 else 0)≤
      ∑ i, if light i then if a≤p.mass i then (p.mass i)^alpha*
        min (fractionalPart alpha*(1-fractionalPart alpha)+(N:ℝ)^2*(p.mass i/b)+min ((ell:ℝ)^2*(a/p.mass i)) 1) 1 else 0 else 0
    apply Finset.sum_le_sum
    intro i _
    by_cases hl : light i=true
    · by_cases hpa : a≤p.mass i
      · simp only [hl,hpa,ite_true]
        have hZ : 0≤min ((ell:ℝ)^2*(a/p.mass i)) 1 :=
          le_min (mul_nonneg (sq_nonneg _) (div_nonneg ha (p.nonneg i))) zero_le_one
        have hh : 0≤fractionalPart alpha*(1-fractionalPart alpha) := mul_nonneg hg (sub_nonneg.mpr hg1)
        exact mul_le_mul_of_nonneg_left (min_le_min (by linarith only [hh,hZ]) (le_refl _))
          (Real.rpow_nonneg (p.nonneg i) _)
      · simp only [hl,hpa,ite_true,ite_false,le_refl]
    · have hl' : light i=false := Bool.eq_false_iff.mpr hl
      simp only [hl',Bool.false_eq_true,ite_false,le_refl]
  exact hcut.trans (add_le_add_right (add_le_add_right hsum _) _)

/-- Fixed light and realized-heavy upper gaps yield the corrected full source
margin. The resulting margin is chosen before the count and coefficient constants. -/
theorem upper_actual_assigned_bias_upper {eps fL f : ℝ}
    (heps : 0<eps) (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) :
    ∃ M0 : ℝ, 1≤M0 ∧ ∀ (M : ℝ), M0≤M → ∀ (Ch cu u0 cH : ℝ),
      0≤Ch → 0<cu → 0<u0 → cu*u0≤1 → 0<cH →
      ∃ c : ℝ, 0<c ∧ ∀ (cb lambda CL cL C0 : ℝ),
        0<cb → 0<lambda → lambda≤Real.exp (-2*coupledProfileConstant) →
        1≤CL → 0<cL → 1≤cb*CL → 100≤C0 →
        ∃ d0 D0 : ℝ, 0<d0 ∧ d0≤1 ∧ 1≤D0 ∧ ∀ (d : ℝ), 0≤d → d≤d0 →
          ∀ (k : ℕ) (alpha D heavy : ℝ),
            0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → D0≤D →
            ∀ (p : Simplex k) (light : Fin k→Bool),
              (∀ i, light i=true → p.mass i≤upperB k alpha eps D cb CL cL) →
              heavy≤(1-cH)*assignedHeavyPower p light alpha →
          actualAssignedOracleMean p light heavy alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d+
            c*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d u0≤powerSum p alpha := by
  obtain ⟨M0,cRaw,hM0,hcRaw,hupper⟩ := actualAssignedPolynomial_power_sum_upper heps hfL hfL1 hf hf1
  refine ⟨M0,hM0,?_⟩
  intro M hM Ch cu u0 cH hCh hcu hu0 hcuu0 hcH
  let r0 := (1+cu*u0)⁻¹
  let K := min cRaw cH
  let cB := K/(1+K/2)
  let g := r0*cu
  let c := min 1 (min g (r0*cB/4))
  have hden0 : 0<1+cu*u0 := by positivity
  have hr0 : 0<r0 := inv_pos.mpr hden0
  have hrhalf : 1/2≤r0 := by
    have hh : (1/2:ℝ)≤1/(1+cu*u0) := (le_div_iff₀ hden0).mpr (by linarith only [hcuu0])
    simpa only [r0,one_div] using hh
  have hK : 0<K := lt_min hcRaw hcH
  have hcB : 0<cB := by dsimp [cB];positivity
  have hg : 0<g := mul_pos hr0 hcu
  have hc : 0<c := lt_min zero_lt_one (lt_min hg (by positivity))
  refine ⟨c,hc,?_⟩
  intro cb lambda CL cL C0 hcb hlambda hlambdaC hCL hcL hcbCL hC0
  obtain ⟨d0,D0,hd0,hd01,hD0,hpaid⟩ := upper_actual_fixed_heavy_correction_absorbed
    heps hCh hcb hlambda hCL hcL hC0 hcRaw hcH
  refine ⟨d0,D0,hd0,hd01,hD0,?_⟩
  intro d hd hdd k alpha D heavy hk ha hγ hγ1 hD p light hlight hheavy
  have ha1 : 1<alpha := by linarith only [ha]
  have hDpos : 0<D := zero_lt_one.trans_le (hD0.trans hD)
  let a := upperA k alpha eps Ch D cb lambda CL cL
  let b := upperB k alpha eps D cb CL cL
  let err := (k:ℝ)*100^(upperOrderFloor alpha+1)*a^alpha
  have hb : 0<b := upperB_pos hk ha1 hγ hγ1 hDpos hcb hCL hcL (ε:=eps)
  have ha0 : 0≤a := (upper_actual_count_geometry hk ha hγ hγ1 heps hCh hDpos hcb hlambda
    (by linarith only [coupled_capacity_lambda_le_one hlambdaC] : lambda≤4) hCL hcL hcbCL).1.le
  have herr : 0≤err := by dsimp [err];positivity
  have he : 0≤actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d :=
    mul_nonneg (upperActualBaseline_nonneg ha1.le (by linarith only [hC0]) hd ha0)
      (Real.rpow_nonneg (Nat.cast_nonneg k) _)
  have hP : 0≤powerSum p alpha := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (p.nonneg i) _)
  have hPH : 0≤assignedHeavyPower p light alpha := by
    apply Finset.sum_nonneg
    intro i _
    split_ifs
    · exact le_refl _
    · exact Real.rpow_nonneg (p.nonneg i) _
  have hL : 0≤actualLightSpatialMargin p light alpha eps Ch D cb lambda CL cL := by
    apply Finset.sum_nonneg
    intro i _
    split_ifs
    · have hZ : 0≤min ((upperLowResolution alpha:ℝ)^2*(a/p.mass i)) 1 :=
        le_min (mul_nonneg (sq_nonneg _) (div_nonneg ha0 (p.nonneg i))) zero_le_one
      have hY : 0≤(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2*(p.mass i/b) :=
        mul_nonneg (sq_nonneg _) (div_nonneg (p.nonneg i) hb.le)
      have hh : 0≤fractionalPart alpha*(1-fractionalPart alpha) := mul_nonneg hγ.le (sub_nonneg.mpr hγ1.le)
      exact mul_nonneg (Real.rpow_nonneg (p.nonneg i) _) (le_min (by linarith only [hZ,hY,hh]) zero_le_one)
    · exact le_refl _
    · exact le_refl _
  have hB0 : 0≤actualForwardBonus p alpha eps D cb CL cL := by
    apply Finset.sum_nonneg
    intro i _
    exact mul_nonneg (Real.rpow_nonneg (p.nonneg i) _)
      (le_min (mul_nonneg (sq_nonneg _) (div_nonneg (p.nonneg i) hb.le)) zero_le_one)
  have hbonus := actualForwardBonus_le_assigned_spatial ha0 (by linarith only [ha] : 0≤alpha) hγ.le hγ1.le p light
  have hpow : (1:ℝ)≤100^(upperOrderFloor alpha+1) := one_le_pow₀ (by norm_num : (1:ℝ)≤100)
  have hlowerr : (k:ℝ)*a^alpha≤err := by
    have hh := mul_le_mul_of_nonneg_right hpow (mul_nonneg (Nat.cast_nonneg k) (Real.rpow_nonneg ha0 alpha))
    dsimp only [err]
    nlinarith only [hh]
  have hB := hbonus.trans (add_le_add_left hlowerr
    (actualLightSpatialMargin p light alpha eps Ch D cb lambda CL cL+assignedHeavyPower p light alpha))
  have hκ : 0≤upperKappa alpha eps := (Real.exp_pos _).le
  have hκ1 : upperKappa alpha eps≤1 := Real.exp_le_one_iff.mpr (by nlinarith only [heps,ha1])
  have hchi : 0≤min (alpha-1) 1 := le_min (by linarith only [ha1]) zero_le_one
  have hu := (upperU_pos (k:=k) (eps:=eps) ha1 hγ hγ1 hu0).le
  have huU : upperU k alpha eps u0≤u0 := min_le_right _ _
  have hrange := upperRescaling_range (k:=k) (eps:=eps) ha1 hγ hγ1 hcu.le hu0
  have hden : 0<1+cu*upperU k alpha eps u0 := by positivity
  have hr : r0≤upperRescaling k alpha eps cu u0 := by
    have hh := add_le_add_left (mul_le_mul_of_nonneg_left huU hcu.le) 1
    simpa only [r0,upperRescaling,one_div] using one_div_le_one_div_of_le hden hh
  have hrescale : g*upperU k alpha eps u0≤1-upperRescaling k alpha eps cu u0 := by
    have hid : upperRescaling k alpha eps cu u0*(1+cu*upperU k alpha eps u0)=1 := by
      dsimp only [upperRescaling]
      exact inv_mul_cancel₀ hden.ne'
    have hm := mul_le_mul_of_nonneg_right hr (mul_nonneg hcu.le hu)
    dsimp only [g]
    nlinarith only [hm,hid]
  have hmean := hupper M hM k alpha Ch D cb lambda CL cL heavy cH hk ha hγ hγ1 hCh hDpos
    hcb hlambda hlambdaC hCL hcL hcbCL p light hlight hheavy
  have hpay := hpaid k alpha D d hk ha hγ hγ1 hD hd hdd p light
  have hh := assigned_corrected_upper_margin_transfer
    (F:=actualLightPolynomialMean p light alpha eps Ch D cb lambda CL cL fL f M+heavy) (err:=err)
    hP hL hPH hB0 herr he hκ hκ1 hchi
    (min_le_right _ _) hu hrhalf hr hrange.2 hcRaw hcH hg hrescale
    (by dsimp only [err,a];linarith only [hmean]) (by dsimp only [err,a];linarith only [hpay]) hB
  simpa only [actualAssignedOracleMean,actualBiasBudget,c,K,cB,g,r0] using hh

end Renyi
