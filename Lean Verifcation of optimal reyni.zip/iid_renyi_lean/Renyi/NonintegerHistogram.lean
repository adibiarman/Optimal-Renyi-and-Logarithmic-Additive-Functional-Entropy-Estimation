import Renyi.CompletedPilotCountBridge
import Renyi.CommonAnchor
import Renyi.PoissonPilotLaws
import Renyi.NonintegerIID
import Renyi.UpperBandAssembly

/-! The actual general noninteger polynomial/Gamma estimator and its noise terms. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Polynomial
namespace Renyi

/-- A fixed statistic of the main and pilot histograms. The common linear
term is removed from both selected arms and restored once globally. -/
def nonintegerHistogramStatistic {k:ℕ} (n cp:ℝ≥0) (Q:ℝ[X]) (d:ℕ)
    (alpha B omega correction:ℝ) : PilotHistogram k→ℝ := fun h =>
  correction+Q.coeff 1+∑i,
    if (pilotSelectionCount i h:ℝ)≤(cp:ℝ)*B*alpha then
      polynomialCountCoordinate Q d n pilotMainCount i h-Q.coeff 1*(pilotMainCount i h:ℝ)/n
    else omega*analyticCount alpha (pilotMainCount i h)/(n:ℝ)^alpha-
      Q.coeff 1*(pilotMainCount i h:ℝ)/n

/-- The actual exposure is the root-scale sample parameter. -/
def actualNonintegerHistogramStatistic {k:ℕ} (Q:ℝ[X]) (d:ℕ)
    (alpha eps D:ℝ) (cp:ℝ≥0) (B omega correction:ℝ) : PilotHistogram k→ℝ :=
  nonintegerHistogramStatistic (nonintegerPoissonMean k alpha eps D) cp Q d alpha B omega correction

def nonintegerHistogramIdeal {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) (Q:ℝ[X])
    (b alpha B omega correction:ℝ) : PilotHistogram k→ℝ := fun h =>
  correction+pilotIdealPower p.mass (fun i=>Q.eval (p.mass i)) pilotSelectionCount pilotMainCount
    n b alpha cp B omega h

def nonintegerHistogramCenteredPolynomial {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) (Q:ℝ[X])
    (d:ℕ) (alpha B:ℝ) : PilotHistogram k→ℝ :=
  pilotCenteredPolynomial (fun i=>Q.eval (p.mass i))
    (polynomialCountCoordinate Q d n pilotMainCount) pilotSelectionCount alpha cp B

def nonintegerHistogramBoundary {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) (Q:ℝ[X])
    (b alpha B omega:ℝ) : PilotHistogram k→ℝ :=
  pilotTotalBoundary p.mass (fun i=>Q.eval (p.mass i)) pilotSelectionCount pilotMainCount
    n b alpha cp B omega

/-- Exact pointwise decomposition, including the shared affine term. -/
theorem nonintegerHistogramStatistic_decomposition {k:ℕ} (n cp:ℝ≥0) (Q:ℝ[X]) (d:ℕ)
    (alpha B omega correction:ℝ) (h:PilotHistogram k) :
    nonintegerHistogramStatistic n cp Q d alpha B omega correction h=
      correction+pilotHybridPower (polynomialCountCoordinate Q d n pilotMainCount)
        pilotSelectionCount pilotMainCount n alpha cp B omega h+
        poissonAffineAnchor pilotMainCount n (Q.coeff 1) h := by
  unfold nonintegerHistogramStatistic pilotHybridPower poissonAffineAnchor
  have hsum:(∑i,if (pilotSelectionCount i h:ℝ)≤(cp:ℝ)*B*alpha then
      polynomialCountCoordinate Q d n pilotMainCount i h-Q.coeff 1*(pilotMainCount i h:ℝ)/n
      else omega*analyticCount alpha (pilotMainCount i h)/(n:ℝ)^alpha-
        Q.coeff 1*(pilotMainCount i h:ℝ)/n)=
      (∑i,if (pilotSelectionCount i h:ℝ)≤(cp:ℝ)*B*alpha then
        polynomialCountCoordinate Q d n pilotMainCount i h
        else omega*analyticCount alpha (pilotMainCount i h)/(n:ℝ)^alpha)-
        ∑i,Q.coeff 1*(pilotMainCount i h:ℝ)/n := by
    rw [←Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i _
    split_ifs <;> rfl
  rw [hsum,←Finset.sum_div,←Finset.mul_sum]
  ring

/-- The actual statistic differs from its ideal by precisely the centered
selected polynomial term, the common anchor, and the boundary envelope. -/
theorem nonintegerHistogramStatistic_comparison {k:ℕ} (n cp:ℝ≥0) (p:Simplex k)
    (Q:ℝ[X]) (d:ℕ) (b alpha B omega correction:ℝ) (hw:0≤omega) (h:PilotHistogram k) :
    |nonintegerHistogramStatistic n cp Q d alpha B omega correction h-
      nonintegerHistogramIdeal n cp p Q b alpha B omega correction h-
      nonintegerHistogramCenteredPolynomial n cp p Q d alpha B h-
      poissonAffineAnchor pilotMainCount n (Q.coeff 1) h|≤
        nonintegerHistogramBoundary n cp p Q b alpha B omega h := by
  rw [nonintegerHistogramStatistic_decomposition]
  unfold nonintegerHistogramIdeal nonintegerHistogramCenteredPolynomial nonintegerHistogramBoundary
  have hid (a z c A:ℝ):(correction+a+A)-(correction+z)-c-A=a-z-c:=by ring
  rw [hid]
  exact pilot_sum_comparison p.mass (fun i=>Q.eval (p.mass i)) p.nonneg
    (polynomialCountCoordinate Q d n pilotMainCount) pilotSelectionCount pilotMainCount
    n b alpha cp B omega hw h

/-- Every selected-polynomial noise term has its actual mean and variance;
no probability-law or independence certificate is assumed. -/
theorem nonintegerHistogramCenteredPolynomial_moments {k:ℕ} (n cp:ℝ≥0) (hn:0<(n:ℝ))
    (p:Simplex k) (Q:ℝ[X]) {d:ℕ} (hd:Q.natDegree≤d) (alpha B:ℝ) :
    let mu:=(pilotHistogramPMF n cp p).toMeasure
    let Z:=nonintegerHistogramCenteredPolynomial n cp p Q d alpha B
    MemLp Z 2 mu ∧ (∫h,Z h ∂mu)=0 ∧
      variance Z mu=pilotAveragedCountVariance pilotMainCount pilotSelectionCount
        ((cp:ℝ)*B*alpha) d Q.coeff n mu mu := by
  exact pilot_centered_polynomial_moments_actual Q hd n hn.ne' p.mass
    pilotSelectionCount pilotMainCount
    (fun i=>cp*(n*simplexNN p i)) (fun i=>n*simplexNN p i)
    (pilotSelectionCount_law n cp p) (pilotMainCount_law n cp p)
    (pilotSelectionCount_independent_main n cp p) (pilotHistogram_pairs_independent n cp p)
    (fun i=>by simp only [NNReal.coe_mul,simplexNN_coe]) alpha cp B

/-- The common affine term is centered and has exactly the source variance. -/
theorem nonintegerHistogramAnchor_moments {k:ℕ} (n cp:ℝ≥0) (hn:0<(n:ℝ))
    (p:Simplex k) (q:ℝ) :
    let mu:=(pilotHistogramPMF n cp p).toMeasure
    MemLp (poissonAffineAnchor (pilotMainCount (k:=k)) n q) 2 mu ∧
      (∫h,poissonAffineAnchor pilotMainCount n q h ∂mu)=0 ∧
      variance (poissonAffineAnchor pilotMainCount n q) mu=q^2/n := by
  apply common_affine_anchor_moments pilotMainCount (fun i=>n*simplexNN p i)
    (pilotMainCount_law n cp p) (pilotMainCount_independent n cp p) hn _ q
  simp only [NNReal.coe_mul,simplexNN_coe,←Finset.mul_sum,p.normalized,mul_one]

/-- A frozen pilot vector gives the actual selected polynomial values. -/
theorem nonintegerHistogram_frozen_polynomial_mean {k:ℕ} (n cp:ℝ≥0) (hn:0<(n:ℝ))
    (p:Simplex k) (Q:ℝ[X]) {d:ℕ} (hd:Q.natDegree≤d) (y:Fin k→ℕ) (T:ℝ) :
    (∫h,pilotSelectedCountEstimator pilotMainCount y T d Q.coeff n h
      ∂(pilotHistogramPMF n cp p).toMeasure)=∑i,if (y i:ℝ)≤T then Q.eval (p.mass i) else 0 := by
  exact pilot_selected_actual_polynomial_mean Q hd n hn.ne' p.mass pilotMainCount
    (fun i=>n*simplexNN p i) (pilotMainCount_law n cp p)
    (fun i=>by simp only [NNReal.coe_mul,simplexNN_coe]) y T

/-- The calibrated numerical budgets plug directly into the concrete estimator.
The main and pilot laws, centered count moments, anchor moments and comparison
are all supplied by the actual product histogram experiment. -/
theorem nonintegerHistogram_band {k:ℕ} (n cp:ℝ≥0) (hn:0<(n:ℝ)) (p:Simplex k)
    (Q:ℝ[X]) {d:ℕ} (hd:Q.natDegree≤d) (b alpha B omega correction:ℝ)
    (hw:0≤omega) (G:Set (PilotHistogram k))
    {lo hi r deltaH deltaC deltaA deltaE:ℝ} (hr:0<r)
    (hgood:(pilotHistogramPMF n cp p).toMeasure.real Gᶜ≤deltaH)
    (hideal:∀h∈G,lo+3*r≤nonintegerHistogramIdeal n cp p Q b alpha B omega correction h ∧
      nonintegerHistogramIdeal n cp p Q b alpha B omega correction h+3*r≤hi)
    (hcount:pilotAveragedCountVariance pilotMainCount pilotSelectionCount ((cp:ℝ)*B*alpha)
      d Q.coeff n (pilotHistogramPMF n cp p).toMeasure (pilotHistogramPMF n cp p).toMeasure≤deltaC*r^2)
    (hanchor:(Q.coeff 1)^2/n≤deltaA*r^2)
    (hboundary:Integrable (nonintegerHistogramBoundary n cp p Q b alpha B omega)
      (pilotHistogramPMF n cp p).toMeasure)
    (hboundaryMean:(∫h,nonintegerHistogramBoundary n cp p Q b alpha B omega h
      ∂(pilotHistogramPMF n cp p).toMeasure)≤deltaE*r) :
    (pilotHistogramPMF n cp p).toMeasure.real
      {h | nonintegerHistogramStatistic n cp Q d alpha B omega correction h<lo ∨
        hi<nonintegerHistogramStatistic n cp Q d alpha B omega correction h}≤
          deltaH+deltaC+deltaA+deltaE := by
  have hC:=nonintegerHistogramCenteredPolynomial_moments n cp hn p Q hd alpha B
  have hA:=nonintegerHistogramAnchor_moments n cp hn p (Q.coeff 1)
  apply upper_band_of_ideal_and_noise
    (nonintegerHistogramStatistic n cp Q d alpha B omega correction)
    (nonintegerHistogramIdeal n cp p Q b alpha B omega correction)
    (nonintegerHistogramCenteredPolynomial n cp p Q d alpha B)
    (poissonAffineAnchor pilotMainCount n (Q.coeff 1))
    (nonintegerHistogramBoundary n cp p Q b alpha B omega) G hr hgood hideal
    (nonintegerHistogramStatistic_comparison n cp p Q d b alpha B omega correction hw)
    hC.1 hC.2.1 _ hA.1 hA.2.1 _ hboundary
    (pilotTotalBoundary_nonneg p.mass (fun i=>Q.eval (p.mass i)) p.nonneg
      pilotSelectionCount pilotMainCount n b alpha cp B omega hw) hboundaryMean
  · rw [hC.2.2]
    exact hcount
  · rw [hA.2.2]
    exact hanchor

end Renyi
