import Renyi.DegreeOneLowBounds

/-! Source lower envelopes for the actual unique degree-one completion. -/
noncomputable section
open Set
namespace Renyi.DegreeOneCompletion

lemma completionFloor_eq {f : ℝ} (hf : 0<f) (hf1 : f<1) : completionFloor f=f := by
  unfold completionFloor
  exact if_pos (And.intro hf hf1)

/-- Uniform actual coefficient bounds used by the near-one tangent calibration. -/
theorem coefficient_uniform_bounds {s f : ℝ} (hs : 0<s) (hs1 : s≤1)
    (hf : 0<f) (hf1 : f<1) :
    1-f≤coefficient s f ∧ coefficient s f≤1-f/4 := by
  have hc := coefficient_spec hs hf1
  rw [completionFloor_eq hf hf1] at hc
  exact degreeOneCoefficient_uniform_bounds hs hs1 hc.1 hf hc.2

/-- Any coefficient satisfying the prescribed source equation is the selected one. -/
theorem coefficient_unique {s f c : ℝ} (hs : 0<s) (hf : 0<f) (hf1 : f<1)
    (hc : c∈Ioo (s/(1+s)) 1) (hboundary : degreeOneBoundary s c=f) :
    c=coefficient s f := by
  obtain ⟨c0,_hc0,huniq⟩ := degreeOneBoundary_existsUnique hs hf hf1
  have hselected := coefficient_spec hs hf1
  rw [completionFloor_eq hf hf1] at hselected
  exact (huniq c ⟨hc,hboundary⟩).trans (huniq (coefficient s f) hselected).symm

/-- The full minimum envelope, with the prescribed positive floor. -/
theorem lowProfile_global_min_lower {N : ℕ} {s f q x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0<f) (hf1 : f<1) (hq : q≤f)
    (hx : 0≤x) (hx1 : x≤1) :
    min q (Real.exp (Real.log (1-f)*s)*(x/s)^s)≤lowProfile N s f x := by
  have hc := coefficient_spec hs hf1
  rw [completionFloor_eq hf hf1] at hc
  exact (min_le_min hq (le_refl _)).trans
    (degreeOneProfile_power_lower hs hs1 hc.1 hf hf1 hc.2 ⟨hx,hx1⟩)

def localEnvelopeConstant (f : ℝ) : ℝ := max (2-Real.log (1-f)) (-2*Real.log f)

theorem localEnvelopeConstant_pos {f : ℝ} (hf : 0<f) (hf1 : f<1) :
    0<localEnvelopeConstant f := by
  have hh := Real.log_nonpos (by linarith only [hf1] : 0≤1-f) (by linarith only [hf] : 1-f≤1)
  exact (by linarith only [hh] : 0<2-Real.log (1-f)).trans_le (le_max_left _ _)

/-- Sharp local power lower bound with an exp(O(s)) normalization error. -/
theorem lowProfile_local_power_lower {N : ℕ} {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0<f) (hf1 : f<1)
    (hx : 0≤x) (hxs : x≤s) :
    Real.exp (-localEnvelopeConstant f*s)*(x/s)^s≤lowProfile N s f x := by
  have hx1 := hxs.trans hs1
  have hc := coefficient_spec hs hf1
  rw [completionFloor_eq hf hf1] at hc
  have hc0 := coefficient_pos hs hf1
  have hcmin := (degreeOneCoefficient_uniform_bounds hs hs1 hc.1 hf hc.2).1
  have hpow0 : 0≤(x/s)^s := Real.rpow_nonneg (div_nonneg hx hs.le) s
  have hC : 2-Real.log (1-f)≤localEnvelopeConstant f := le_max_left _ _
  by_cases hsmall : s≤1/2
  · have hexp : Real.exp (-2*s)≤1-s := by
      rw [show -2*s=-(2*s) by ring,Real.exp_neg,inv_eq_one_div]
      apply (div_le_iff₀ (Real.exp_pos (2*s))).mpr
      have he := Real.add_one_le_exp (2*s)
      have hm := mul_le_mul_of_nonneg_right he (by linarith only [hsmall] : 0≤1-s)
      have hsquare := mul_nonneg hs.le (by linarith only [hsmall] : 0≤1-2*s)
      nlinarith only [hm,hsquare]
    have hlin : Real.exp (-2*s)≤1-coefficient s f*x := by
      have hh := mul_le_mul_of_nonneg_right hc.1.2.le hx
      linarith only [hexp,hh,hxs]
    have hp := Real.rpow_le_rpow
      (mul_nonneg (by linarith only [hf1] : 0≤1-f) (div_nonneg hx hs.le))
      (mul_le_mul_of_nonneg_right hcmin (div_nonneg hx hs.le)) hs.le
    rw [Real.mul_rpow (by linarith only [hf1]) (div_nonneg hx hs.le),
      Real.rpow_def_of_pos (by linarith only [hf1] : 0<1-f)] at hp
    have hfac : 1≤(1+s)^(1+s) := Real.one_le_rpow (by linarith only [hs]) (by linarith only [hs])
    have hfacmul := mul_le_mul_of_nonneg_right hfac (show 0≤1-coefficient s f*x by linarith only [hlin,Real.exp_pos (-2*s)])
    simp only [one_mul] at hfacmul
    have hp' : Real.exp (Real.log (1-f)*s)*(x/s)^s≤(coefficient s f*x/s)^s := by
      simpa only [mul_div_assoc] using hp
    have hm := mul_le_mul hp' (hlin.trans hfacmul) (Real.exp_pos (-2*s)).le
      (Real.rpow_nonneg (by positivity : 0≤coefficient s f*x/s) s)
    have he := Real.exp_le_exp.mpr (show -localEnvelopeConstant f*s≤(Real.log (1-f)-2)*s by
      nlinarith only [mul_le_mul_of_nonneg_right hC hs.le])
    have hm2 := mul_le_mul_of_nonneg_right he hpow0
    rw [lowProfile,degreeOneProfile_factor hs hc0 hx]
    simp only [←mul_assoc] at hm
    apply le_trans _ hm
    apply hm2.trans_eq
    calc
      _ = (Real.exp (Real.log (1-f)*s)*Real.exp (-2*s))*(x/s)^s := by
        rw [←Real.exp_add]
        congr 2
        ring
      _ = _ := by ring
  · have hhalf : (1:ℝ)/2≤s := (lt_of_not_ge hsmall).le
    have hlogf : Real.log f≤0 := Real.log_nonpos hf.le hf1.le
    have hCf : -2*Real.log f≤localEnvelopeConstant f := le_max_right _ _
    have he1 : Real.exp (-localEnvelopeConstant f*s)≤f := by
      apply (Real.le_log_iff_exp_le hf).mp
      have hm := mul_le_mul_of_nonneg_right hCf hs.le
      have hm2 := mul_le_mul_of_nonpos_left hhalf hlogf
      nlinarith only [hm,hm2]
    have he2 : Real.exp (-localEnvelopeConstant f*s)≤Real.exp (Real.log (1-f)*s) := by
      apply Real.exp_le_exp.mpr
      nlinarith only [mul_le_mul_of_nonneg_right hC hs.le,hs]
    have hpow1 := Real.rpow_le_one (div_nonneg hx hs.le) ((div_le_one hs).mpr hxs) hs.le
    have hlo := lowProfile_global_min_lower (N:=N) hs hs1 hf hf1 (le_refl f) hx hx1
    apply le_trans _ hlo
    apply le_min
    · exact (mul_le_of_le_one_right (Real.exp_pos _).le hpow1).trans he1
    · exact mul_le_mul_of_nonneg_right he2 hpow0

end Renyi.DegreeOneCompletion
