import Renyi.CoupledFractionMargin

/-! Uniform strict upper certificate for the actual coupled endpoint construction. -/
noncomputable section
namespace Renyi

lemma exists_fraction_margin_threshold {fL f ρ E : ℝ}
    (hfL : 0≤fL) (hfL1 : fL<1) (hρ : 0<ρ) (hE : 0<E) :
    ∃ σ : ℝ, 0<σ ∧ σ≤1/2 ∧ σ≤lowDeficitOrder fL ∧ 16*Real.sqrt σ≤E ∧
      (40*Real.exp (Real.log 12+1))*σ≤ρ/4 ∧
      8*σ*(-Real.log (1/(8*(1+highProfileIntegralConstant f))))≤E ∧
      (1+highProfileIntegralConstant f)*Real.exp (coupledProfileConstant+1)*Real.sqrt σ≤
        (1-fractionSeparationLevel E)/2 := by
  let K := 1+highProfileIntegralConstant f
  let W := K*Real.exp (coupledProfileConstant+1)
  let R := (1-fractionSeparationLevel E)/2
  let B := -Real.log (1/(8*K))
  let C := 40*Real.exp (Real.log 12+1)
  have hK : 1<K := by have hp := highProfileIntegralConstant_pos f;dsimp [K];linarith only [hp]
  have hW : 0<W := mul_pos (by linarith only [hK]) (Real.exp_pos _)
  have hR : 0<R := by dsimp [R];linarith only [fractionSeparationLevel_lt_one hE]
  have hB : 0<B := by
    have hq : (1:ℝ)/(8*K)<1 := (div_lt_one (by positivity : 0<8*K)).mpr (by linarith only [hK])
    exact neg_pos.mpr (Real.log_neg (by positivity) hq)
  have hC : 0<C := by dsimp [C];positivity
  have horder := lowDeficitOrder_pos hfL hfL1
  let σ := min (1/2) (min (lowDeficitOrder fL)
    (min ((E/16)^2) (min (ρ/(4*C)) (min (E/(8*B)) ((R/W)^2)))))
  have hσ : 0<σ := by dsimp [σ];positivity
  have hσhalf : σ≤1/2 := min_le_left _ _
  have hσorder : σ≤lowDeficitOrder fL := (min_le_right _ _).trans (min_le_left _ _)
  have hσroot : σ≤(E/16)^2 := (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
  have hσerr : σ≤ρ/(4*C) := (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _)))
  have hσlog : σ≤E/(8*B) := (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))))
  have hσforward : σ≤(R/W)^2 := (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _))))
  refine ⟨σ,hσ,hσhalf,hσorder,?_,?_,?_,?_⟩
  · have hs := (Real.sqrt_le_left (show 0≤E/16 by positivity)).mpr hσroot
    linarith only [hs]
  · have hs := (le_div_iff₀ (show 0<4*C by positivity)).mp hσerr
    dsimp [C] at hs
    nlinarith only [hs]
  · have hs := (le_div_iff₀ (show 0<8*B by positivity)).mp hσlog
    dsimp [B,K] at hs
    nlinarith only [hs]
  · have hs := (Real.sqrt_le_left (show 0≤R/W by positivity)).mpr hσforward
    have hm := (le_div_iff₀ hW).mp hs
    dsimp [W,R,K] at hm
    nlinarith only [hm]

lemma exists_complement_margin_threshold {ρ E : ℝ}
    (hρ : 0<ρ) (hρ1 : ρ≤1) (hE : 0<E) :
    ∃ τ : ℝ, 0<τ ∧ τ≤1/2 ∧ τ≤lowDeficitOrder (1-ρ) ∧
      8*Real.sqrt τ≤E ∧ 4*τ*(-Real.log (ρ/4))≤E := by
  let B := -Real.log (ρ/4)
  have hB : 0<B := neg_pos.mpr (Real.log_neg (by positivity) (by linarith only [hρ1] : ρ/4<1))
  have horder := lowDeficitOrder_pos (by linarith only [hρ1] : 0≤1-ρ) (by linarith only [hρ] : 1-ρ<1)
  let τ := min (1/2) (min (lowDeficitOrder (1-ρ)) (min ((E/8)^2) (E/(4*B))))
  have hτ : 0<τ := by dsimp [τ];positivity
  refine ⟨τ,hτ,min_le_left _ _,(min_le_right _ _).trans (min_le_left _ _),?_,?_⟩
  · have hsq : τ≤(E/8)^2 := (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
    have hs := (Real.sqrt_le_left (show 0≤E/8 by positivity)).mpr hsq
    linarith only [hs]
  · have hlog : τ≤E/(4*B) := (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _))
    have hs := (le_div_iff₀ (show 0<4*B by positivity)).mp hlog
    dsimp [B] at hs
    nlinarith only [hs]

lemma exp_neg_le_of_large {t c : ℝ} (hc : 0<c) (ht : 1/c≤t) : Real.exp (-t)≤c := by
  have he : 1/c≤Real.exp t := ht.trans (by have hh := Real.add_one_le_exp t;linarith only [hh])
  rw [Real.exp_neg]
  have h := one_div_le_one_div_of_le (one_div_pos.mpr hc) he
  simpa only [one_div,inv_inv] using h

lemma coupled_spatial_min_le_sum {γ Y Z : ℝ} (hγ : 0≤γ) (hγ1 : γ≤1)
    (_hY : 0≤Y) (hZ : 0≤Z) :
    min (γ*(1-γ)+Y+min Z 1) 1≤γ+min Y 1+min Z 1 ∧
    min (γ*(1-γ)+Y+min Z 1) 1≤(1-γ)+min Y 1+min Z 1 := by
  have hZ0 : 0≤min Z 1 := le_min hZ (by norm_num)
  by_cases hY1 : Y≤1
  · rw [min_eq_left hY1]
    have hm := min_le_left (γ*(1-γ)+Y+min Z 1) 1
    constructor <;> nlinarith only [hm,mul_nonneg hγ hγ,mul_nonneg (sub_nonneg.mpr hγ1) (sub_nonneg.mpr hγ1)]
  · rw [min_eq_right (le_of_not_ge hY1)]
    have hm := min_le_right (γ*(1-γ)+Y+min Z 1) 1
    constructor <;> nlinarith only [hm,hγ,hγ1,hZ0]

lemma strict_margin_weaken {T a c S R : ℝ} (hc : 0≤c) (hca : c≤a)
    (hR : 0≤R) (hRS : R≤S) (hT : T≤1-a*S) : T≤1-c*R := by
  have hm1 := mul_le_mul_of_nonneg_left hRS hc
  have hm2 := mul_le_mul_of_nonneg_right hca (hR.trans hRS)
  nlinarith only [hT,hm1,hm2]

/-- A fixed margin when complement damping is already macroscopic. -/
theorem coupledProfiles_complement_large_damping_gap {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z M ω ρ fL f x y : ℝ} (hγhalf : (1:ℝ)/2≤γ) (hγ1 : γ<1)
    (hM : 0≤M) (hMd : 1≤M*(1-γ)) (hρ : 0<ρ)
    (hMρ : Real.exp (-M/2)≤ρ/4) (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωρ : ω≤1-ρ) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hz1 : z<1) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤1-ρ/4 := by
  have hγ : 0<γ := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hy hy1
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have ha : a≤ρ/4 := by
    apply (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
    apply le_trans _ hMρ
    apply Real.exp_le_exp.mpr
    nlinarith only [mul_le_mul_of_nonneg_left hγhalf hM]
  have hb : b≤(1:ℝ)/2 := by
    apply (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
    have he : Real.exp (-M*(1-γ))≤Real.exp (-1) := Real.exp_le_exp.mpr (by nlinarith only [hMd])
    have hh := Real.add_one_le_exp (1:ℝ)
    have hi := one_div_le_one_div_of_le (by norm_num : (0:ℝ)<2) (show 2≤Real.exp 1 by linarith only [hh])
    have hehalf : Real.exp (-1)≤(1:ℝ)/2 := by simpa only [Real.exp_neg,one_div] using hi
    exact he.trans hehalf
  have hb1 : b≤1 := by linarith only [hb]
  have hlow := (mul_le_of_le_one_right ha0 hu.2).trans ha
  have hlowcut := mul_le_of_le_one_right (mul_nonneg ha0 hu.1)
    (by linarith only [hH.1] : 1-endpointProfile N 6 1 y≤1)
  have hhigh := mul_le_of_le_one_right hb0 hv.2
  have hlast := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hb1)) hJ.2
  have hlastω := mul_le_mul_of_nonneg_right hωρ (sub_nonneg.mpr hb1)
  have hbρ := mul_le_mul_of_nonneg_left hb hρ.le
  unfold coupledDampedExpression
  change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+
    b*highProfile N (1-γ) f ω y+ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
  nlinarith only [hlow,hlowcut,hhigh,hlast,hlastω,hbρ]

/-- The actual coupled construction has the manuscript's global strict upper envelope.
All damping and margin constants are chosen from the fixed floor parameters and energy gap. -/
theorem coupledProfiles_global_strict_upper {fL f E : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) (hE : 0<E) :
    ∃ M c : ℝ, 1≤M ∧ 0<c ∧
      ∀ (ℓ N : ℕ) (γ z ω x y : ℝ), 2≤ℓ → 2≤N → 0<γ → γ<1 →
        0<z → z≤Real.exp (-E) → 0≤ω → ω≤Real.exp (-E/8) →
        0≤x → x≤1 → 0≤y → y≤1 →
        ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y)≤
          Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) →
        coupledDampedExpression ℓ N γ z M ω fL f x y≤1-c*
          min (γ*(1-γ)+(N:ℝ)^2*y+min ((ℓ:ℝ)^2*x) 1) 1 := by
  let ρ := 1-Real.exp (-E/8)
  have hρ : 0<ρ := by dsimp [ρ];linarith only [Real.exp_lt_one_iff.mpr (show -E/8<0 by linarith only [hE])]
  have hρ1 : ρ≤1 := by dsimp [ρ];linarith only [Real.exp_pos (-E/8)]
  have hEρ : Real.exp (-E/2)≤1-ρ := by
    dsimp [ρ]
    have he : Real.exp (-E/2)≤Real.exp (-E/8) := Real.exp_le_exp.mpr (by linarith only [hE])
    linarith only [he]
  obtain ⟨σ,hσ,hσhalf,hσorder,hσroot,hσerror,hσlog,hσforward⟩ :=
    exists_fraction_margin_threshold (f:=f) hfL.le hfL1 hρ hE
  obtain ⟨τ,hτ,hτhalf,hτorder,hτroot,hτlog⟩ := exists_complement_margin_threshold hρ hρ1 hE
  let θ := min σ τ
  have hθ : 0<θ := lt_min hσ hτ
  let M := max 1 (max (8/ρ) (4/(ρ*θ)))
  have hM : 1≤M := le_max_left _ _
  have hM0 : 0≤M := by linarith only [hM]
  have hMρ0 : 8/ρ≤M := (le_max_left _ _).trans (le_max_right _ _)
  have hMθ0 : 4/(ρ*θ)≤M := (le_max_right _ _).trans (le_max_right _ _)
  have hMρ : Real.exp (-M/2)≤ρ/4 := by
    have hm := (div_le_iff₀ hρ).mp hMρ0
    have hscale : 1/(ρ/4)≤M/2 := by
      apply (div_le_iff₀ (show 0<ρ/4 by positivity)).mpr
      nlinarith only [hm]
    simpa only [neg_div] using exp_neg_le_of_large (by positivity : 0<ρ/4) hscale
  have hMθ : Real.exp (-M*θ)≤ρ/4 := by
    have hm := (div_le_iff₀ (mul_pos hρ hθ)).mp hMθ0
    have hscale : 1/(ρ/4)≤M*θ := by
      apply (div_le_iff₀ (show 0<ρ/4 by positivity)).mpr
      nlinarith only [hm]
    simpa only [neg_mul] using exp_neg_le_of_large (by positivity : 0<ρ/4) hscale
  let c := min (fractionMarginConstant fL ρ E) (min (complementMarginConstant fL ρ) (ρ/4))
  have hc : 0<c := lt_min (fractionMarginConstant_pos hfL1 hρ hE)
    (lt_min (complementMarginConstant_pos hfL hρ) (by positivity))
  refine ⟨M,c,hM,hc,?_⟩
  intro ℓ N γ z ω x y hℓ hN hγ hγ1 hz hzE hω hωE hx hx1 hy hy1 hcap
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hωρ : ω≤1-ρ := by dsimp [ρ];linarith only [hωE]
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  let R := min (γ*(1-γ)+(N:ℝ)^2*y+min ((ℓ:ℝ)^2*x) 1) 1
  have hR0 : 0≤R := le_min (add_nonneg (add_nonneg (mul_nonneg hγ.le hd.le) (by positivity))
    (le_min (by positivity) (by norm_num))) (by norm_num)
  have hR1 : R≤1 := min_le_right _ _
  have hRs := coupled_spatial_min_le_sum hγ.le hγ1.le (show 0≤(N:ℝ)^2*y by positivity)
    (show 0≤(ℓ:ℝ)^2*x by positivity)
  by_cases hγσ : γ≤σ
  · have hroot : 16*Real.sqrt γ≤E := (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hγσ) (by norm_num : (0:ℝ)≤16)).trans hσroot
    have herror := (mul_le_mul_of_nonneg_left hγσ (show 0≤40*Real.exp (Real.log 12+1) by positivity)).trans hσerror
    have hlog := (mul_le_mul_of_nonneg_left hγσ (show 0≤8*(-Real.log (1/(8*(1+highProfileIntegralConstant f)))) by
      have hK := highProfileIntegralConstant_pos f
      have hq : 1/(8*(1+highProfileIntegralConstant f))≤1 := (div_le_one (by positivity)).mpr (by linarith only [hK])
      exact mul_nonneg (by norm_num) (neg_nonneg.mpr (Real.log_nonpos (by positivity) hq))))
    have hlog' : 8*γ*(-Real.log (1/(8*(1+highProfileIntegralConstant f))))≤E := by nlinarith only [hlog,hσlog]
    have hforward := (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hγσ)
      (show 0≤(1+highProfileIntegralConstant f)*Real.exp (coupledProfileConstant+1) by
        have hK := highProfileIntegralConstant_pos f;positivity)).trans hσforward
    have hgap := coupledProfiles_fraction_spatial_gap hℓ hN hγ (hγσ.trans hσhalf) hM hρ hω hωρ
      hMρ hEρ hroot herror hlog' hforward hfL.le hfL1 hf hf1 hx hx1 hy hy1 hz hzE (hγσ.trans hσorder) hcap
    exact strict_margin_weaken hc.le (min_le_left _ _) hR0 hRs.1 hgap
  by_cases hδτ : 1-γ≤τ
  · have hγhalf : (1:ℝ)/2≤γ := by linarith only [hδτ,hτhalf]
    by_cases hMd : M*(1-γ)≤1
    · have hroot : 8*Real.sqrt (1-γ)≤E := (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hδτ) (by norm_num : (0:ℝ)≤8)).trans hτroot
      have hlog := mul_le_mul_of_nonneg_left hδτ (show 0≤4*(-Real.log (ρ/4)) by
        exact mul_nonneg (by norm_num) (neg_nonneg.mpr (Real.log_nonpos (by positivity) (by linarith only [hρ1] : ρ/4≤1))))
      have hlog' : 4*(1-γ)*(-Real.log (ρ/4))≤E := by nlinarith only [hlog,hτlog]
      have hgap := coupledProfiles_complement_spatial_gap hℓ hN hγhalf hγ1 hM hMd hρ hρ1
        (hMρ.trans (by linarith only [hρ] : ρ/4≤ρ/2)) hEρ hroot hlog'
        hfL hfL1 hf hf1.le hω hωρ hx hx1 hy hy1 hz hzE (hδτ.trans hτorder) hcap
      exact strict_margin_weaken hc.le ((min_le_right _ _).trans (min_le_left _ _)) hR0 hRs.2 hgap
    · have hgap := coupledProfiles_complement_large_damping_gap (by omega : 0<ℓ) (by omega : 0<N)
        hγhalf hγ1 hM0 (le_of_lt (lt_of_not_ge hMd)) hρ hMρ hfL.le hfL1 hf hf1.le hω hωρ hx hx1 hy hy1 hz hz1
      exact strict_margin_weaken hc.le ((min_le_right _ _).trans (min_le_right _ _)) hR0 hR1 (by simpa only [mul_one] using hgap)
  · have hσγ : θ≤γ := (min_le_left _ _).trans (le_of_lt (lt_of_not_ge hγσ))
    have hτδ : θ≤1-γ := (min_le_right _ _).trans (le_of_lt (lt_of_not_ge hδτ))
    have hgap := coupledProfiles_interior_upper_gap (by omega : 0<ℓ) (by omega : 0<N)
      hγ hγ1 hM0 hσγ hτδ hρ hω hωρ hMθ hfL.le hfL1 hf hf1.le hx hx1 hy hy1 hz hz1
    have hcoef : c≤ρ/2 := ((min_le_right _ _).trans (min_le_right _ _)).trans (by linarith only [hρ] : ρ/4≤ρ/2)
    exact strict_margin_weaken hc.le hcoef hR0 hR1 (by simpa only [mul_one] using hgap)

end Renyi
