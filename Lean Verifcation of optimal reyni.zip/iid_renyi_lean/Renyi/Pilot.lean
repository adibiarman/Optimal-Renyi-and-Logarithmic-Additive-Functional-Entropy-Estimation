import Renyi.FactorialEnergy

/-!
# The pilot factorial-moment lemma

The probabilities and moments here are sums against the actual Poisson pmf.
The pilot is independent of the main count: their joint mass is the product
of the two Poisson masses. No tail or moment bound is assumed.
-/

noncomputable section
open scoped BigOperators NNReal
open ProbabilityTheory
namespace Renyi

/-- The full exponential generating identity for a Poisson count. -/
theorem poisson_exp_hasSum (lam : ℝ≥0) (t : ℝ) :
    HasSum (fun n : ℕ => Real.exp (t * n) * poissonPMFReal lam n)
      (Real.exp ((lam : ℝ) * (Real.exp t - 1))) := by
  have h := (NormedSpace.expSeries_div_hasSum_exp ℝ
    ((lam : ℝ) * Real.exp t)).mul_left (Real.exp (-(lam : ℝ)))
  rw [← Real.exp_eq_exp_ℝ] at h
  have heq (n : ℕ) :
      Real.exp (t * n) * poissonPMFReal lam n =
        Real.exp (-(lam : ℝ)) * (((lam : ℝ) * Real.exp t) ^ n / n.factorial) := by
    unfold poissonPMFReal
    rw [mul_pow, ← Real.exp_nat_mul]
    rw [mul_comm t (n : ℝ)]
    ring
  have hout : Real.exp (-(lam : ℝ)) * Real.exp ((lam : ℝ) * Real.exp t) =
      Real.exp ((lam : ℝ) * (Real.exp t - 1)) := by
    rw [← Real.exp_add]
    congr 1
    ring
  simpa only [← heq, hout] using h

def poissonLowerMass (lam : ℝ≥0) (T : ℝ) : ℝ :=
  ∑' y : ℕ, if (y : ℝ) ≤ T then poissonPMFReal lam y else 0

theorem poissonLowerMass_summable (lam : ℝ≥0) (T : ℝ) :
    Summable (fun y : ℕ => if (y : ℝ) ≤ T then poissonPMFReal lam y else 0) := by
  apply (poissonPMFRealSum lam).summable.of_nonneg_of_le
  · intro y
    split_ifs <;> simp [poissonPMFReal_nonneg]
  · intro y
    split_ifs <;> simp [poissonPMFReal_nonneg]

theorem poissonLowerMass_nonneg (lam : ℝ≥0) (T : ℝ) : 0 ≤ poissonLowerMass lam T := by
  apply tsum_nonneg
  intro y
  split_ifs <;> simp [poissonPMFReal_nonneg]

theorem poissonLowerMass_le_one (lam : ℝ≥0) (T : ℝ) : poissonLowerMass lam T ≤ 1 := by
  rw [← (poissonPMFRealSum lam).tsum_eq]
  apply (poissonLowerMass_summable lam T).tsum_le_tsum _ (poissonPMFRealSum lam).summable
  intro y
  split_ifs <;> simp [poissonPMFReal_nonneg]

/-- Exponential Markov bound proved by comparison of the individual masses. -/
theorem poissonLowerMass_exp_bound (lam : ℝ≥0) (T : ℝ) :
    poissonLowerMass lam T ≤ Real.exp (T + (lam : ℝ) * (Real.exp (-1) - 1)) := by
  have hg := (poisson_exp_hasSum lam (-1)).mul_left (Real.exp T)
  have hbound : ∀ y : ℕ,
      (if (y : ℝ) ≤ T then poissonPMFReal lam y else 0) ≤
        Real.exp T * (Real.exp (-1 * y) * poissonPMFReal lam y) := by
    intro y
    split_ifs with hy
    · have he : 1 ≤ Real.exp (T - y) := Real.one_le_exp_iff.mpr (sub_nonneg.mpr hy)
      have hmul := mul_le_mul_of_nonneg_right he (poissonPMFReal_nonneg (r := lam) (n := y))
      simpa only [one_mul, Real.exp_sub, Real.exp_neg, neg_one_mul,
        div_eq_mul_inv, mul_assoc] using hmul
    · exact mul_nonneg (Real.exp_pos T).le
        (mul_nonneg (Real.exp_pos _).le poissonPMFReal_nonneg)
  have h := (poissonLowerMass_summable lam T).tsum_le_tsum hbound hg.summable
  rw [hg.tsum_eq, ← Real.exp_add] at h
  exact h

theorem exp_neg_one_le_three_eighths : Real.exp (-1 : ℝ) ≤ 3 / 8 := by
  have h := Real.sum_le_exp_of_nonneg (by norm_num : (0 : ℝ) ≤ 1) 4
  norm_num [Finset.sum_range_succ] at h
  rw [Real.exp_neg, inv_le_iff_one_le_mul₀ (Real.exp_pos 1)]
  nlinarith

/-- A Poisson count falls below half its mean with probability at most exp(-mu/8). -/
theorem poissonLowerMass_half (lam : ℝ≥0) {T : ℝ} (hT : T ≤ (lam : ℝ) / 2) :
    poissonLowerMass lam T ≤ Real.exp (-(lam : ℝ) / 8) := by
  apply (poissonLowerMass_exp_bound lam T).trans
  apply Real.exp_le_exp.mpr
  have h := mul_le_mul_of_nonneg_left exp_neg_one_le_three_eighths lam.coe_nonneg
  nlinarith

def poissonFactorialSecond (lam : ℝ≥0) (j : ℕ) : ℝ :=
  ∑' n : ℕ, (n.descFactorial j : ℝ) ^ 2 * poissonPMFReal lam n

theorem poissonFactorialSecond_summable (lam : ℝ≥0) (j : ℕ) :
    Summable (fun n : ℕ => (n.descFactorial j : ℝ) ^ 2 * poissonPMFReal lam n) := by
  simpa only [pow_two] using (poisson_factorial_cross_hasSum lam j j).summable

theorem poissonFactorialSecond_nonneg (lam : ℝ≥0) (j : ℕ) :
    0 ≤ poissonFactorialSecond lam j := by
  apply tsum_nonneg
  intro n
  exact mul_nonneg (sq_nonneg _) poissonPMFReal_nonneg

/-- All degrees: the exact factorial product expansion implies this useful bound. -/
theorem poissonFactorialSecond_le (lam : ℝ≥0) (j : ℕ) :
    poissonFactorialSecond lam j ≤ (lam : ℝ) ^ j * ((lam : ℝ) + j) ^ j := by
  have hm := (poisson_factorial_cross_hasSum lam j j).tsum_eq
  simp only [min_self] at hm
  unfold poissonFactorialSecond
  simp only [pow_two]
  rw [hm]
  have hc (r : ℕ) : (j.choose r : ℝ) * (j.choose r : ℝ) * (r.factorial : ℝ) =
      (j.choose r : ℝ) * (j.descFactorial r : ℝ) := by
    rw [Nat.descFactorial_eq_factorial_mul_choose]
    push_cast
    ring
  have hterm (r : ℕ) (hr : r ∈ Finset.range (j + 1)) :
      (j.choose r : ℝ) * (j.choose r : ℝ) * (r.factorial : ℝ) *
          (lam : ℝ) ^ (j + j - r) ≤
        (lam : ℝ) ^ j * ((j : ℝ) ^ r * (lam : ℝ) ^ (j - r) * (j.choose r : ℝ)) := by
    have hrj : r ≤ j := Nat.le_of_lt_succ (Finset.mem_range.mp hr)
    have hexp : j + j - r = j + (j - r) := by omega
    rw [hc, hexp, pow_add]
    have hd : (j.descFactorial r : ℝ) ≤ (j : ℝ) ^ r := by
      exact_mod_cast Nat.descFactorial_le_pow j r
    have h := mul_le_mul_of_nonneg_left hd (show 0 ≤
      (j.choose r : ℝ) * ((lam : ℝ) ^ j * (lam : ℝ) ^ (j - r)) by positivity)
    nlinarith [h]
  calc
    (∑ r ∈ Finset.range (j + 1),
      (j.choose r : ℝ) * (j.choose r : ℝ) * (r.factorial : ℝ) *
        (lam : ℝ) ^ (j + j - r)) ≤
      ∑ r ∈ Finset.range (j + 1),
        (lam : ℝ) ^ j * ((j : ℝ) ^ r * (lam : ℝ) ^ (j - r) * (j.choose r : ℝ)) :=
          Finset.sum_le_sum hterm
    _ = (lam : ℝ) ^ j * ((j : ℝ) + (lam : ℝ)) ^ j := by
      rw [← Finset.mul_sum, add_pow]
    _ = (lam : ℝ) ^ j * ((lam : ℝ) + j) ^ j := by rw [add_comm (j : ℝ)]

/-- Exponential damping controls every positive integer degree uniformly. -/
theorem exp_damped_power_le {c x : ℝ} (hc : 0 < c) (hx : 0 ≤ x)
    {j : ℕ} (hj : 0 < j) :
    Real.exp (-c * x) * (x + j) ^ j ≤ ((1 + 1 / c) * j) ^ j := by
  have hjr : 0 < (j : ℝ) := by exact_mod_cast hj
  let u := c * x / j
  let A := (1 + 1 / c) * j
  have hA : 0 ≤ A := by dsimp [A]; positivity
  have hexp : 1 + u ≤ Real.exp u := by simpa [add_comm] using Real.add_one_le_exp u
  have hid : A * (1 + u) = x + j + j / c + c * x := by
    dsimp [A, u]
    field_simp
    ring
  have hlin : x + j ≤ A * Real.exp u := by
    have h := mul_le_mul_of_nonneg_left hexp hA
    rw [hid] at h
    have hd : 0 ≤ (j : ℝ) / c := by positivity
    have hm : 0 ≤ c * x := mul_nonneg hc.le hx
    linarith
  have hb : Real.exp (-u) * (x + j) ≤ A := by
    calc
      Real.exp (-u) * (x + j) ≤ Real.exp (-u) * (A * Real.exp u) :=
        mul_le_mul_of_nonneg_left hlin (Real.exp_pos _).le
      _ = A := by
        rw [mul_left_comm, ← Real.exp_add]
        simp
  have hp := pow_le_pow_left₀
    (mul_nonneg (Real.exp_pos _).le (by positivity : 0 ≤ x + (j : ℝ))) hb j
  rw [mul_pow, ← Real.exp_nat_mul] at hp
  have hu : (j : ℝ) * -u = -c * x := by
    dsimp [u]
    field_simp
  simpa only [hu, A] using hp

/-- The actual second moment under the product law of the independent counts. -/
def poissonPilotSecond (lam mu : ℝ≥0) (T : ℝ) (j : ℕ) : ℝ :=
  ∑' y : ℕ, ∑' n : ℕ,
    (if (y : ℝ) ≤ T then (n.descFactorial j : ℝ) ^ 2 else 0) *
      (poissonPMFReal lam n * poissonPMFReal mu y)

/-- Independence factors the pilot event from the main-count moment. -/
theorem poissonPilotSecond_factor (lam mu : ℝ≥0) (T : ℝ) (j : ℕ) :
    poissonPilotSecond lam mu T j =
      poissonLowerMass mu T * poissonFactorialSecond lam j := by
  unfold poissonPilotSecond poissonLowerMass poissonFactorialSecond
  have hi (y : ℕ) :
      (∑' n : ℕ, (if (y : ℝ) ≤ T then (n.descFactorial j : ℝ) ^ 2 else 0) *
        (poissonPMFReal lam n * poissonPMFReal mu y)) =
      (if (y : ℝ) ≤ T then poissonPMFReal mu y else 0) *
        (∑' n : ℕ, (n.descFactorial j : ℝ) ^ 2 * poissonPMFReal lam n) := by
    split_ifs with hy
    · simpa only [mul_assoc, mul_comm, mul_left_comm] using
        (poissonFactorialSecond_summable lam j).tsum_mul_left (poissonPMFReal mu y)
    · simp
  simp_rw [hi]
  exact (poissonLowerMass_summable mu T).tsum_mul_right _

/-- Absolute convergence and evaluation of the joint-law sum on count pairs. -/
theorem poissonPilotSecond_joint_hasSum (lam mu : ℝ≥0) (T : ℝ) (j : ℕ) :
    HasSum (fun z : ℕ × ℕ =>
      (if (z.1 : ℝ) ≤ T then (z.2.descFactorial j : ℝ) ^ 2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1))
      (poissonPilotSecond lam mu T j) := by
  let f : ℕ → ℝ := fun y => if (y : ℝ) ≤ T then poissonPMFReal mu y else 0
  let g : ℕ → ℝ := fun n => (n.descFactorial j : ℝ) ^ 2 * poissonPMFReal lam n
  have hf : Summable f := poissonLowerMass_summable mu T
  have hg : Summable g := poissonFactorialSecond_summable lam j
  have hf0 : 0 ≤ f := by
    intro y
    dsimp [f]
    split_ifs <;> simp [poissonPMFReal_nonneg]
  have hg0 : 0 ≤ g := fun n => mul_nonneg (sq_nonneg _) poissonPMFReal_nonneg
  have hfg := hf.mul_of_nonneg hg hf0 hg0
  have h := hf.hasSum.mul hg.hasSum hfg
  have heq (z : ℕ × ℕ) :
      f z.1 * g z.2 =
      (if (z.1 : ℝ) ≤ T then (z.2.descFactorial j : ℝ) ^ 2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1) := by
    dsimp [f, g]
    split_ifs <;> ring
  simp_rw [heq] at h
  rw [poissonPilotSecond_factor]
  exact h

/-- Explicit constant for the manuscript's independent Poisson pilot lemma. -/
def pilotConstant (B cp : ℝ) : ℝ := max (2 * B + 1) (1 + 8 / cp)

/-- Lemma cc-pilot, with an explicit constant depending only on B and c_p. -/
theorem poisson_pilot_factorial_second_bound (B cp alpha : ℝ)
    (hB : 0 < B) (hcp : 0 < cp) (lam : ℝ≥0) {j : ℕ}
    (hj : 1 ≤ j) (hja : (j : ℝ) ≤ alpha) :
    poissonPilotSecond lam ⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩
      (cp * B * alpha) j ≤
        (pilotConstant B cp * alpha) ^ j * (lam : ℝ) ^ j := by
  have hjpos : 0 < j := lt_of_lt_of_le Nat.zero_lt_one hj
  have hjr : 0 < (j : ℝ) := by exact_mod_cast hjpos
  have ha : 0 < alpha := lt_of_lt_of_le hjr hja
  have hC : 0 ≤ pilotConstant B cp := by
    exact le_trans (by positivity : 0 ≤ 2 * B + 1) (le_max_left _ _)
  rw [poissonPilotSecond_factor]
  have hmoment := poissonFactorialSecond_le lam j
  have hmnon := poissonFactorialSecond_nonneg lam j
  have hpilot := poissonLowerMass_nonneg
    (⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ : ℝ≥0) (cp * B * alpha)
  by_cases hsmall : (lam : ℝ) ≤ 2 * B * alpha
  · have hlow := poissonLowerMass_le_one
      (⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ : ℝ≥0) (cp * B * alpha)
    have hbase : (lam : ℝ) + j ≤ pilotConstant B cp * alpha := by
      have hCleft := mul_le_mul_of_nonneg_right (le_max_left (2 * B + 1) (1 + 8 / cp)) ha.le
      dsimp [pilotConstant]
      nlinarith
    have hpow := pow_le_pow_left₀ (by positivity : 0 ≤ (lam : ℝ) + j) hbase j
    calc
      _ ≤ poissonFactorialSecond lam j := by nlinarith
      _ ≤ (lam : ℝ) ^ j * ((lam : ℝ) + j) ^ j := hmoment
      _ ≤ (pilotConstant B cp * alpha) ^ j * (lam : ℝ) ^ j := by
        nlinarith [mul_le_mul_of_nonneg_left hpow (pow_nonneg lam.coe_nonneg j)]
  · have hlarge : 2 * B * alpha < (lam : ℝ) := lt_of_not_ge hsmall
    have hthreshold : cp * B * alpha ≤
        ((⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ : ℝ≥0) : ℝ) / 2 := by
      dsimp
      nlinarith
    have htail := poissonLowerMass_half
      (⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ : ℝ≥0) hthreshold
    have hdamp := exp_damped_power_le (div_pos hcp (by norm_num : (0 : ℝ) < 8))
      lam.coe_nonneg hjpos
    have hexpeq : -(cp * (lam : ℝ)) / 8 = -(cp / 8) * (lam : ℝ) := by ring
    have hconst : 1 + 1 / (cp / 8) = 1 + 8 / cp := by field_simp
    have hbase : (1 + 8 / cp) * (j : ℝ) ≤ pilotConstant B cp * alpha := by
      have hc : 0 ≤ 1 + 8 / cp := by positivity
      exact (mul_le_mul_of_nonneg_left hja hc).trans
        (mul_le_mul_of_nonneg_right (le_max_right _ _) ha.le)
    have hpow := pow_le_pow_left₀ (by positivity : 0 ≤ (1 + 8 / cp) * (j : ℝ)) hbase j
    simp only [hconst] at hdamp
    have htail' : poissonLowerMass
        (⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ : ℝ≥0) (cp * B * alpha) ≤
        Real.exp (-(cp / 8) * (lam : ℝ)) := by
      simpa only [NNReal.coe_mk, hexpeq] using htail
    calc
      _ ≤ Real.exp (-(cp / 8) * (lam : ℝ)) *
          ((lam : ℝ) ^ j * ((lam : ℝ) + j) ^ j) :=
        mul_le_mul htail' hmoment hmnon (Real.exp_pos _).le
      _ = (Real.exp (-(cp / 8) * (lam : ℝ)) * ((lam : ℝ) + j) ^ j) *
          (lam : ℝ) ^ j := by ring
      _ ≤ ((1 + 8 / cp) * (j : ℝ)) ^ j * (lam : ℝ) ^ j :=
        mul_le_mul_of_nonneg_right hdamp (pow_nonneg lam.coe_nonneg j)
      _ ≤ (pilotConstant B cp * alpha) ^ j * (lam : ℝ) ^ j :=
        mul_le_mul_of_nonneg_right hpow (pow_nonneg lam.coe_nonneg j)

/-- The same pilot estimate written directly as a sum over the independent joint law. -/
theorem poisson_pilot_joint_second_bound (B cp alpha : ℝ)
    (hB : 0 < B) (hcp : 0 < cp) (lam : ℝ≥0) {j : ℕ}
    (hj : 1 ≤ j) (hja : (j : ℝ) ≤ alpha) :
    (∑' z : ℕ × ℕ,
      (if (z.1 : ℝ) ≤ cp * B * alpha then (z.2.descFactorial j : ℝ) ^ 2 else 0) *
        (poissonPMFReal lam z.2 *
          poissonPMFReal ⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ z.1)) ≤
        (pilotConstant B cp * alpha) ^ j * (lam : ℝ) ^ j := by
  rw [(poissonPilotSecond_joint_hasSum _ _ _ _).tsum_eq]
  exact poisson_pilot_factorial_second_bound B cp alpha hB hcp lam hj hja

end Renyi
