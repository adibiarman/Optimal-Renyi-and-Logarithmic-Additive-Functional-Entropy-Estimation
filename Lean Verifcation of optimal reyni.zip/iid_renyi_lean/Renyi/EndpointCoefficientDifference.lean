import Renyi.EndpointExponent
import Renyi.CoupledLeadingCoefficient

/-! Coefficient cancellation of the actual normalized integral profile near exponent one. -/
noncomputable section
open scoped BigOperators
open Polynomial
namespace Renyi

def endpointCoefficientDifferenceConstant : ℝ :=
  40 * Real.exp (2 * (Real.log 12 + 1)) + 2 * Real.exp (Real.log 12 + 1)

lemma endpointCoefficientDifferenceConstant_pos : 0 < endpointCoefficientDifferenceConstant := by
  unfold endpointCoefficientDifferenceConstant
  positivity

lemma weightedPrimitivePolynomial_difference_mass (P : ℝ[X]) {s : ℝ}
    (hs : 1 / 2 ≤ s) (hs1 : s ≤ 1) :
    coefficientMass (weightedPrimitivePolynomial P s - weightedPrimitivePolynomial P 1) ≤
      2 * (1 - s) * coefficientMass P := by
  have hp (j : ℕ) : |P.coeff j / (s + j) - P.coeff j / (1 + j)| ≤
      2 * (1 - s) * |P.coeff j| := by
    have hj : 0 ≤ (j : ℝ) := Nat.cast_nonneg j
    have h1 : 0 < s + j := by linarith
    have h2 : 0 < 1 + (j : ℝ) := by positivity
    have hden : 1 / 2 ≤ (s + j) * (1 + j) := by nlinarith
    have hid : P.coeff j / (s + j) - P.coeff j / (1 + j) =
        P.coeff j * ((1 - s) / ((s + j) * (1 + j))) := by field_simp; ring
    rw [hid, abs_mul, abs_div, abs_of_nonneg (by linarith : 0 ≤ 1 - s),
      abs_of_pos (mul_pos h1 h2)]
    have hd : (1 - s) / ((s + j) * (1 + j)) ≤ 2 * (1 - s) := by
      apply (div_le_iff₀ (mul_pos h1 h2)).mpr
      nlinarith
    nlinarith [abs_nonneg (P.coeff j)]
  unfold weightedPrimitivePolynomial
  rw [← Finset.sum_sub_distrib]
  calc
    _ ≤ ∑ j ∈ P.support, coefficientMass
        (monomial j (P.coeff j / (s + j)) - monomial j (P.coeff j / (1 + j))) :=
      coefficientMass_sum_le _ _
    _ ≤ ∑ j ∈ P.support, 2 * (1 - s) * |P.coeff j| := by
      apply Finset.sum_le_sum
      intro j _
      rw [← monomial_sub, coefficientMass_monomial]
      exact hp j
    _ = _ := by simp [coefficientMass, Polynomial.sum_def, Finset.mul_sum]

lemma endpointScaledTotal_inverse_bound {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) :
    (endpointScaledPrimitive N d s ((N : ℝ) ^ 2))⁻¹ ≤ Real.exp (Real.log 12 + 1) := by
  have hl := endpointScaledPrimitive_total_lower hN hd hs hs1
  have h := one_div_le_one_div_of_le (Real.exp_pos (-(Real.log 12 + 1))) hl
  simpa only [one_div, Real.exp_neg, inv_inv] using h

lemma endpointScaledTotal_inverse_difference {N d : ℕ} (hN : 0 < N)
    (hd0 : 2 ≤ d) (hd1 : d ≤ 6) {s : ℝ} (hs : 1 / 2 ≤ s) (hs1 : s ≤ 1) :
    |(endpointScaledPrimitive N d s ((N : ℝ) ^ 2))⁻¹ -
      (endpointScaledPrimitive N d 1 ((N : ℝ) ^ 2))⁻¹| ≤
        20 * (1 - s) * Real.exp (2 * (Real.log 12 + 1)) := by
  let U := endpointScaledPrimitive N d s ((N : ℝ) ^ 2)
  let V := endpointScaledPrimitive N d 1 ((N : ℝ) ^ 2)
  have hs0 : 0 < s := by linarith
  have hbeta0 : 0 ≤ 1 - s := sub_nonneg.mpr hs1
  have hU : 0 < U := (Real.exp_pos (-(Real.log 12 + 1))).trans_le
    (endpointScaledPrimitive_total_lower hN hd1 hs0 hs1)
  have hV : 0 < V := (Real.exp_pos (-(Real.log 12 + 1))).trans_le
    (endpointScaledPrimitive_total_lower hN hd1 (by norm_num) (by norm_num))
  have hUi := endpointScaledTotal_inverse_bound hN hd1 hs0 hs1
  have hVi := endpointScaledTotal_inverse_bound hN hd1 (by norm_num : (0 : ℝ) < 1) le_rfl
  have hdiff := endpointScaledPrimitive_difference hN hd0 hs hs1
    (by positivity : 0 ≤ (N : ℝ) ^ 2) le_rfl
  have hid : U⁻¹ - V⁻¹ = (V - U) * U⁻¹ * V⁻¹ := by field_simp
  change |U⁻¹ - V⁻¹| ≤ _
  rw [hid, abs_mul, abs_mul, abs_sub_comm, abs_of_pos (inv_pos.mpr hU), abs_of_pos (inv_pos.mpr hV)]
  have h := mul_le_mul (mul_le_mul hdiff hUi (inv_nonneg.mpr hU.le) (by linarith)) hVi
    (inv_nonneg.mpr hV.le) (by positivity)
  apply h.trans_eq
  have heq : Real.exp (Real.log 12 + 1) * Real.exp (Real.log 12 + 1) =
      Real.exp (2 * (Real.log 12 + 1)) := by
    rw [← Real.exp_add]
    congr 1
    ring
  calc
    _ = 20 * (1 - s) * (Real.exp (Real.log 12 + 1) * Real.exp (Real.log 12 + 1)) := by ring
    _ = _ := by rw [heq]

lemma endpointProfilePolynomial_scaled_normalizer {N : ℕ} (hN : 0 < N) (d : ℕ) (s : ℝ) :
    endpointProfilePolynomial N d s = C (((N : ℝ) ^ 2) ^ s) *
      (C (endpointScaledPrimitive N d s ((N : ℝ) ^ 2))⁻¹ *
        weightedPrimitivePolynomial (endpointKernelPolynomial N d) s) := by
  have hR : 0 < (N : ℝ) ^ 2 := by positivity
  have hT : endpointScaledPrimitive N d s ((N : ℝ) ^ 2) =
      ((N : ℝ) ^ 2) ^ s * endpointIntegral N d s := by
    rw [endpointScaledPrimitive_rescale hN s hR.le, div_self hR.ne']
    rfl
  have hpow := (Real.rpow_pos_of_pos hR s).ne'
  have hid : ((N : ℝ) ^ 2) ^ s * (endpointScaledPrimitive N d s ((N : ℝ) ^ 2))⁻¹ =
      (endpointIntegral N d s)⁻¹ := by rw [hT]; field_simp
  unfold endpointProfilePolynomial
  rw [← mul_assoc, ← C_mul, hid]

/-- The normalized integral polynomial has coefficient cancellation at exponent one. -/
theorem endpointProfilePolynomial_exponent_difference_mass {N d : ℕ} (hN : 0 < N)
    (hd0 : 2 ≤ d) (hd1 : d ≤ 6) {s : ℝ} (hs : 1 / 2 ≤ s) (hs1 : s ≤ 1) :
    coefficientMass (endpointProfilePolynomial N d s -
      C (((N : ℝ) ^ 2) ^ (s - 1)) * endpointProfilePolynomial N d 1) ≤
        endpointCoefficientDifferenceConstant * (1 - s) *
          (((N : ℝ) ^ 2) ^ s) * coefficientMass (endpointKernelPolynomial N d) := by
  let R := (N : ℝ) ^ 2
  let U := endpointScaledPrimitive N d s R
  let V := endpointScaledPrimitive N d 1 R
  let W := weightedPrimitivePolynomial (endpointKernelPolynomial N d) s
  let W1 := weightedPrimitivePolynomial (endpointKernelPolynomial N d) 1
  have hR : 0 < R := by dsimp [R]; positivity
  have hs0 : 0 < s := by linarith
  have hbeta0 : 0 ≤ 1 - s := sub_nonneg.mpr hs1
  have hV : 0 < V := (Real.exp_pos (-(Real.log 12 + 1))).trans_le
    (endpointScaledPrimitive_total_lower hN hd1 (by norm_num) (by norm_num))
  have hdiff := endpointScaledTotal_inverse_difference hN hd0 hd1 hs hs1
  have hVi := endpointScaledTotal_inverse_bound hN hd1 (by norm_num : (0 : ℝ) < 1) le_rfl
  have hW : coefficientMass W ≤ 2 * coefficientMass (endpointKernelPolynomial N d) := by
    apply (weightedPrimitivePolynomial_coefficientMass _ hs0).trans
    apply (div_le_iff₀ hs0).mpr
    nlinarith [coefficientMass_nonneg (endpointKernelPolynomial N d)]
  have hWdiff := weightedPrimitivePolynomial_difference_mass (endpointKernelPolynomial N d) hs hs1
  have hscale : R ^ (s - 1) * R = R ^ s := by rw [← Real.rpow_add_one hR.ne', sub_add_cancel]
  have heq : endpointProfilePolynomial N d s - C (R ^ (s - 1)) * endpointProfilePolynomial N d 1 =
      C (R ^ s) * (C (U⁻¹ - V⁻¹) * W + C V⁻¹ * (W - W1)) := by
    rw [endpointProfilePolynomial_scaled_normalizer hN d s, endpointProfilePolynomial_scaled_normalizer hN d 1]
    change C (R ^ s) * (C U⁻¹ * W) - C (R ^ (s - 1)) * (C (R ^ (1 : ℝ)) * (C V⁻¹ * W1)) = _
    rw [Real.rpow_one]
    have hC : C (R ^ (s - 1)) * C R = C (R ^ s) := by rw [← C_mul, hscale]
    calc
      _ = C (R ^ s) * (C U⁻¹ * W) - (C (R ^ (s - 1)) * C R) * (C V⁻¹ * W1) := by ring
      _ = _ := by rw [hC, map_sub]; ring
  rw [heq, coefficientMass_C_mul, abs_of_pos (Real.rpow_pos_of_pos hR s)]
  have hfirst : coefficientMass (C (U⁻¹ - V⁻¹) * W) ≤
      40 * (1 - s) * Real.exp (2 * (Real.log 12 + 1)) * coefficientMass (endpointKernelPolynomial N d) := by
    rw [coefficientMass_C_mul]
    exact (mul_le_mul hdiff hW (coefficientMass_nonneg _) (by positivity)).trans_eq (by ring)
  have hsecond : coefficientMass (C V⁻¹ * (W - W1)) ≤
      2 * (1 - s) * Real.exp (Real.log 12 + 1) * coefficientMass (endpointKernelPolynomial N d) := by
    rw [coefficientMass_C_mul, abs_of_pos (inv_pos.mpr hV)]
    exact (mul_le_mul hVi hWdiff (coefficientMass_nonneg _) (Real.exp_pos _).le).trans_eq (by ring)
  have hinner := (coefficientMass_add_le _ _).trans (add_le_add hfirst hsecond)
  apply (mul_le_mul_of_nonneg_left hinner (Real.rpow_pos_of_pos hR s).le).trans_eq
  unfold endpointCoefficientDifferenceConstant
  ring

/-- Explicit beta cancellation, with the manuscript's N^(-2 beta) scaling. -/
theorem endpointProfilePolynomial_near_one_difference_mass {N d : ℕ} (hN : 0 < N)
    (hd0 : 2 ≤ d) (hd1 : d ≤ 6) {β : ℝ} (hβ : 0 < β) (hβ1 : β ≤ 1 / 2) :
    coefficientMass (endpointProfilePolynomial N d (1 - β) -
      C ((N : ℝ) ^ (-2 * β)) * endpointProfilePolynomial N d 1) ≤
        endpointCoefficientDifferenceConstant * β * (N : ℝ) ^ 2 * (9 : ℝ) ^ ((N - 1) * d) := by
  have hN0 : 0 < (N : ℝ) := by exact_mod_cast hN
  have hN1 : 1 ≤ (N : ℝ) := by exact_mod_cast hN
  have hR1 : 1 ≤ (N : ℝ) ^ 2 := by nlinarith
  have hscale : ((N : ℝ) ^ 2) ^ ((1 - β) - 1) = (N : ℝ) ^ (-2 * β) := by
    rw [← Real.rpow_natCast_mul hN0.le 2 ((1 - β) - 1)]
    congr 1
    ring
  have h := endpointProfilePolynomial_exponent_difference_mass hN hd0 hd1
    (by linarith : 1 / 2 ≤ 1 - β) (by linarith : 1 - β ≤ 1)
  rw [hscale, show 1 - (1 - β) = β by ring] at h
  have hpow : ((N : ℝ) ^ 2) ^ (1 - β) ≤ (N : ℝ) ^ 2 := by
    simpa using Real.rpow_le_rpow_of_exponent_le hR1 (by linarith : 1 - β ≤ 1)
  have hmass := endpointKernelPolynomial_coefficientMass hN d
  apply h.trans
  have hC : 0 ≤ endpointCoefficientDifferenceConstant * β :=
    mul_nonneg endpointCoefficientDifferenceConstant_pos.le hβ.le
  exact mul_le_mul (mul_le_mul_of_nonneg_left hpow hC) hmass
    (coefficientMass_nonneg _) (mul_nonneg hC (sq_nonneg _))

/-- A single exponential degree envelope absorbs the polynomial normalization costs. -/
theorem endpointProfilePolynomial_near_one_difference_exponential {N d : ℕ} (hN : 0 < N)
    (hd0 : 2 ≤ d) (hd1 : d ≤ 6) {β : ℝ} (hβ : 0 < β) (hβ1 : β ≤ 1 / 2) :
    coefficientMass (endpointProfilePolynomial N d (1 - β) -
      C ((N : ℝ) ^ (-2 * β)) * endpointProfilePolynomial N d 1) ≤
        endpointCoefficientDifferenceConstant * β *
          Real.exp ((2 + 6 * Real.log 9) * (N : ℝ)) := by
  have h := endpointProfilePolynomial_near_one_difference_mass hN hd0 hd1 hβ hβ1
  have hN0 : 0 ≤ (N : ℝ) := Nat.cast_nonneg N
  have hNexp : (N : ℝ) ^ 2 ≤ Real.exp (2 * (N : ℝ)) := by
    have hb : (N : ℝ) ≤ Real.exp (N : ℝ) := by linarith [Real.add_one_le_exp (N : ℝ)]
    have hsq := pow_le_pow_left₀ hN0 hb 2
    rw [← Real.exp_nat_mul] at hsq
    norm_num at hsq
    exact hsq
  have hlog : 0 ≤ Real.log 9 := Real.log_nonneg (by norm_num : (1 : ℝ) ≤ 9)
  have hdegree : (((N - 1) * d : ℕ) : ℝ) ≤ 6 * (N : ℝ) := by
    exact_mod_cast (calc (N - 1) * d ≤ N * 6 := Nat.mul_le_mul (Nat.sub_le N 1) hd1
                         _ = 6 * N := Nat.mul_comm _ _)
  have hkernel : (9 : ℝ) ^ ((N - 1) * d) ≤ Real.exp ((6 * Real.log 9) * (N : ℝ)) := by
    rw [← Real.rpow_natCast, Real.rpow_def_of_pos (by norm_num : (0 : ℝ) < 9)]
    apply Real.exp_le_exp.mpr
    nlinarith [mul_le_mul_of_nonneg_left hdegree hlog]
  apply h.trans
  have hp := mul_le_mul hNexp hkernel (by positivity : 0 ≤ (9 : ℝ) ^ ((N - 1) * d)) (Real.exp_pos _).le
  have hm := mul_le_mul_of_nonneg_left hp
    (by have := endpointCoefficientDifferenceConstant_pos.le; positivity : 0 ≤ endpointCoefficientDifferenceConstant * β)
  apply (le_of_eq (by ring)).trans (hm.trans_eq ?_)
  rw [← Real.exp_add]
  congr 2
  ring

end Renyi
