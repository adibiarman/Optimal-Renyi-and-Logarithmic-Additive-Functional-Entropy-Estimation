import Renyi.PoissonOverlap

/-! Discrete Hellinger affinity and total variation, with convergence proved. -/
noncomputable section
namespace Renyi

theorem sqrt_distance_sq_le {x y : ℝ} (hx : 0 ≤ x) (hy : 0 ≤ y) :
    (Real.sqrt x - Real.sqrt y) ^ 2 ≤ (x - y) ^ 2 / (x + y) := by
  by_cases hsum : x + y = 0
  · have hx0 : x = 0 := by linarith
    have hy0 : y = 0 := by linarith
    simp [hx0, hy0]
  have hpos : 0 < x + y := lt_of_le_of_ne (add_nonneg hx hy) (Ne.symm hsum)
  apply (le_div_iff₀ hpos).2
  have hsx := Real.sq_sqrt hx
  have hsy := Real.sq_sqrt hy
  have hxy := mul_nonneg (Real.sqrt_nonneg x) (Real.sqrt_nonneg y)
  have hf := sq_nonneg (Real.sqrt x - Real.sqrt y)
  nlinarith [mul_nonneg hxy hf]

theorem sqrt_product_le_average {x y : ℝ} (hx : 0 ≤ x) (hy : 0 ≤ y) :
    Real.sqrt x * Real.sqrt y ≤ (x + y) / 2 := by
  nlinarith [sq_nonneg (Real.sqrt x - Real.sqrt y), Real.sq_sqrt hx, Real.sq_sqrt hy]

theorem hellinger_affinity_summable {ι : Type*} (p q : ι → ℝ)
    (hp0 : ∀ i, 0 ≤ p i) (hq0 : ∀ i, 0 ≤ q i)
    (hp : HasSum p 1) (hq : HasSum q 1) :
    Summable (fun i => Real.sqrt (p i) * Real.sqrt (q i)) := by
  apply ((hp.summable.add hq.summable).div_const 2).of_nonneg_of_le
  · intro i
    positivity
  · intro i
    exact sqrt_product_le_average (hp0 i) (hq0 i)

theorem hellinger_affinity_bounds {ι : Type*} (p q : ι → ℝ)
    (hp0 : ∀ i, 0 ≤ p i) (hq0 : ∀ i, 0 ≤ q i)
    (hp : HasSum p 1) (hq : HasSum q 1) :
    0 ≤ (∑' i, Real.sqrt (p i) * Real.sqrt (q i)) ∧
      (∑' i, Real.sqrt (p i) * Real.sqrt (q i)) ≤ 1 := by
  refine ⟨tsum_nonneg (fun _ => by positivity), ?_⟩
  have hs := (hp.add hq).div_const 2
  have h := (hellinger_affinity_summable p q hp0 hq0 hp hq).tsum_le_tsum
    (fun i => sqrt_product_le_average (hp0 i) (hq0 i)) hs.summable
  rw [hs.tsum_eq] at h
  norm_num at h ⊢
  exact h

theorem hellinger_squared_hasSum {ι : Type*} (p q : ι → ℝ)
    (hp0 : ∀ i, 0 ≤ p i) (hq0 : ∀ i, 0 ≤ q i)
    (hp : HasSum p 1) (hq : HasSum q 1) :
    HasSum (fun i => (Real.sqrt (p i) - Real.sqrt (q i)) ^ 2)
      (2 * (1 - ∑' i, Real.sqrt (p i) * Real.sqrt (q i))) := by
  have hs := (hp.add hq).sub
    ((hellinger_affinity_summable p q hp0 hq0 hp hq).hasSum.mul_left 2)
  convert hs using 1
  · funext i
    nlinarith [Real.sq_sqrt (hp0 i), Real.sq_sqrt (hq0 i)]
  · ring

theorem discrete_tv_le_hellinger {ι : Type*} (p q : ι → ℝ)
    (hp0 : ∀ i, 0 ≤ p i) (hq0 : ∀ i, 0 ≤ q i)
    (hp : HasSum p 1) (hq : HasSum q 1) :
    (∑' i, |p i - q i|) / 2 ≤
      Real.sqrt (2 * (1 - ∑' i, Real.sqrt (p i) * Real.sqrt (q i))) := by
  let A := ∑' i, |p i - q i|
  let c := ∑' i, Real.sqrt (p i) * Real.sqrt (q i)
  let H := 2 * (1 - c)
  let B := 2 * (1 + c)
  have hc := hellinger_affinity_bounds p q hp0 hq0 hp hq
  have hB : 0 < B := by dsimp [B, c]; linarith [hc.1]
  have hH : 0 ≤ H := by dsimp [H, c]; linarith [hc.2]
  have hB4 : B ≤ 4 := by dsimp [B, c]; linarith [hc.2]
  have hf := hellinger_squared_hasSum p q hp0 hq0 hp hq
  change HasSum (fun i => (Real.sqrt (p i) - Real.sqrt (q i)) ^ 2) H at hf
  have hg : HasSum (fun i => (Real.sqrt (p i) + Real.sqrt (q i)) ^ 2) B := by
    have hs := (hp.add hq).add
      ((hellinger_affinity_summable p q hp0 hq0 hp hq).hasSum.mul_left 2)
    convert hs using 1
    · funext i
      nlinarith [Real.sq_sqrt (hp0 i), Real.sq_sqrt (hq0 i)]
    · dsimp [B]
      ring
  have habs : HasSum (fun i => |p i - q i|) A := by
    apply Summable.hasSum
    apply (hp.summable.add hq.summable).of_nonneg_of_le (fun _ => abs_nonneg _)
    intro i
    have h := abs_sub (p i) (q i)
    simpa only [abs_of_nonneg (hp0 i), abs_of_nonneg (hq0 i)] using h
  have hfg (i : ι) : |Real.sqrt (p i) - Real.sqrt (q i)| *
      (Real.sqrt (p i) + Real.sqrt (q i)) = |p i - q i| := by
    rw [← abs_of_nonneg (add_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)),
      ← abs_mul]
    congr 1
    nlinarith [Real.sq_sqrt (hp0 i), Real.sq_sqrt (hq0 i)]
  have hquad : HasSum (fun i =>
      (B * |Real.sqrt (p i) - Real.sqrt (q i)| -
        A * (Real.sqrt (p i) + Real.sqrt (q i))) ^ 2) (B ^ 2 * H - B * A ^ 2) := by
    have hs := ((hf.mul_left (B ^ 2)).sub (habs.mul_left (2 * B * A))).add
      (hg.mul_left (A ^ 2))
    convert hs using 1
    · funext i
      rw [sub_sq, mul_pow, mul_pow, sq_abs]
      rw [show 2 * (B * |Real.sqrt (p i) - Real.sqrt (q i)|) *
        (A * (Real.sqrt (p i) + Real.sqrt (q i))) =
          (2 * B * A) * (|Real.sqrt (p i) - Real.sqrt (q i)| *
            (Real.sqrt (p i) + Real.sqrt (q i))) by ring, hfg]
      ring
    · ring
  have hn : 0 ≤ B ^ 2 * H - B * A ^ 2 := by
    rw [← hquad.tsum_eq]
    exact tsum_nonneg (fun _ => sq_nonneg _)
  have hCS : A ^ 2 ≤ B * H := by nlinarith
  have hbound : (A / 2) ^ 2 ≤ H := by nlinarith [mul_le_mul_of_nonneg_right hB4 hH]
  exact Real.le_sqrt_of_sq_le hbound

end Renyi
