import Renyi.IntegerCollision
import Renyi.IntegerHeavy
import Renyi.IntegerTails

/-! The complete probability bound for the actual integer collision estimator. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

variable {ι Ω : Type*} [Fintype ι] [MeasurableSpace Ω]
variable {μ : Measure Ω} [IsProbabilityMeasure μ]

/-- The frequent-coordinate collision statistic obeys its lower-tail bound,
including the case in which its true contribution is zero. -/
theorem integer_heavy_collision_tail
    (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (r : ℕ) (hr : 2 ≤ r) (n : ℝ) (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    (eps : ℝ) (heps : 0 < eps) (hepshalf : eps ≤ 1/2)
    (hn : 0 < n) (hlam : ∀ i, (lam i : ℝ) = n*p i)
    (hheavy : ∀ i, integerThreshold eps r ≤ (lam i : ℝ)) :
    μ.real {ω | rawCollision N r n ω < Real.exp (-integerEta eps r)*powerSumNat p r}
      ≤ 1/32 := by
  have hH0 := powerSumNat_nonneg p hp r
  by_cases hH : powerSumNat p r = 0
  · have hempty : {ω | rawCollision N r n ω < Real.exp (-integerEta eps r)*powerSumNat p r} = ∅ := by
      ext ω
      simp only [hH, mul_zero, Set.mem_setOf_eq, Set.mem_empty_iff_false, iff_false]
      exact not_lt_of_ge (rawCollision_nonneg N r hn.le ω)
    rw [hempty, measureReal_empty]
    norm_num
  have hHpos : 0 < powerSumNat p r := lt_of_le_of_ne hH0 (Ne.symm hH)
  let w : ι → ℝ := fun i => p i^r / powerSumNat p r
  have hw : ∀ i, 0 ≤ w i := fun i => div_nonneg (pow_nonneg (hp i) r) hH0
  have hw1 : ∑ i, w i = 1 := by
    dsimp [w]
    rw [← Finset.sum_div]
    exact div_self hH
  have htail := integer_frequent_mean_tail_probability N lam w hLaw hpair hw hw1 heps hr hheavy
  apply (measureReal_mono (μ := μ) (s₁ := {ω | rawCollision N r n ω <
    Real.exp (-integerEta eps r)*powerSumNat p r})
    (s₂ := {ω | poissonWeightedMean N lam w ω < 1-eps/16}) ?_).trans htail
  intro ω hω
  by_contra hnot
  have hZ : 1-eps/16 ≤ poissonWeightedMean N lam w ω := le_of_not_gt hnot
  have hdet := heavy_collision_lower (fun i => N i ω) r p (fun i => (lam i : ℝ))
    hp hn (integerThreshold_pos heps hr) hlam hheavy hHpos
  have hbase : 1-eps/8 ≤ max 0 (poissonWeightedMean N lam w ω - (r : ℝ)/integerThreshold eps r) := by
    have hb := integer_frequent_base_budget heps hepshalf hr
    exact le_trans (by linarith) (le_max_right _ _)
  have hpow := pow_le_pow_left₀ (by linarith : (0 : ℝ) ≤ 1-eps/8) hbase r
  have hbudget := (integer_frequent_power_budget heps hepshalf hr).trans hpow
  have hlower := (mul_le_mul_of_nonneg_left hbudget hH0).trans hdet
  change powerSumNat p r * Real.exp (-integerEta eps r) ≤ rawCollision N r n ω at hlower
  dsimp only [Set.mem_setOf_eq] at hω
  nlinarith

/-- Complete Poisson-band bound from the natural sample-scale inequality.
Every moment and variance bound is derived from the independent Poisson laws. -/
theorem integer_raw_poisson_band_of_scale
    (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (r : ℕ) (hr : 2 ≤ r) (n : ℝ) (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    (eps : ℝ) (heps : 0 < eps) (hepshalf : eps ≤ 1/2)
    (hn : 0 < n) (hlam : ∀ i, (lam i : ℝ) = n*p i)
    (M : ℝ) (hM : 0 < M) (hP : powerSumNat p r = M^r)
    (hscale : integerSampleConstant eps * r ≤ n*M) :
    μ.real {ω | rawCollision N r n ω < Real.exp (-eps*((r : ℝ)-1))*powerSumNat p r ∨
      Real.exp (eps*((r : ℝ)-1))*powerSumNat p r < rawCollision N r n ω} < 1/12 := by
  classical
  have hr0 : 0 < r := by omega
  have hPpos : 0 < powerSumNat p r := by rw [hP]; positivity
  have hD := integerSampleConstant_pos heps
  have hT := integerThreshold_pos heps hr
  let rare : ι → Prop := fun i => (lam i : ℝ) ≤ integerThreshold eps r
  let NR : {i // rare i} → Ω → ℕ := fun i => N i.val
  let NH : {i // ¬rare i} → Ω → ℕ := fun i => N i.val
  let lamR : {i // rare i} → ℝ≥0 := fun i => lam i.val
  let lamH : {i // ¬rare i} → ℝ≥0 := fun i => lam i.val
  let pR : {i // rare i} → ℝ := fun i => p i.val
  let pH : {i // ¬rare i} → ℝ := fun i => p i.val
  have hLawR : ∀ i, MeasurePreserving (NR i) μ (poissonMeasure (lamR i)) := fun i => hLaw i.val
  have hLawH : ∀ i, MeasurePreserving (NH i) μ (poissonMeasure (lamH i)) := fun i => hLaw i.val
  have hpairR : Pairwise (fun i j => IndepFun (NR i) (NR j) μ) :=
    hpair.comp_of_injective Subtype.val_injective
  have hpairH : Pairwise (fun i j => IndepFun (NH i) (NH j) μ) :=
    hpair.comp_of_injective Subtype.val_injective
  have hpR : ∀ i, 0 ≤ pR i := fun i => hp i.val
  have hpH : ∀ i, 0 ≤ pH i := fun i => hp i.val
  have hlamR : ∀ i, (lamR i : ℝ) = n*pR i := fun i => hlam i.val
  have hlamH : ∀ i, (lamH i : ℝ) = n*pH i := fun i => hlam i.val
  have hrare : ∀ i, (lamR i : ℝ) ≤ integerThreshold eps r := fun i => i.property
  have hheavy : ∀ i, integerThreshold eps r ≤ (lamH i : ℝ) :=
    fun i => (lt_of_not_ge i.property).le
  have hparts : powerSumNat p r = powerSumNat pR r + powerSumNat pH r :=
    (Fintype.sum_subtype_add_sum_subtype rare (fun i => p i^r)).symm
  have hrawparts (ω : Ω) : rawCollision N r n ω = rawCollision NR r n ω + rawCollision NH r n ω :=
    (Fintype.sum_subtype_add_sum_subtype rare (fun i => (N i ω |>.descFactorial r : ℝ)/n^r)).symm
  have hL0 := powerSumNat_nonneg pR hpR r
  have hH0 := powerSumNat_nonneg pH hpH r
  have hLP : powerSumNat pR r ≤ powerSumNat p r := by linarith
  have hvarR := rawCollision_rare_relative_variance NR lamR hLawR hpairR r hr0 n pR hpR hn hlamR
    (integerThreshold eps r) hT.le hrare (powerSumNat p r) M (integerSampleConstant eps)
    hM hP hLP hD hscale
  have hbase : (integerThreshold eps r + r) / (integerSampleConstant eps * r) = integerRareBase eps := by
    unfold integerThreshold integerRareBase
    field_simp
  rw [hbase] at hvarR
  have hrareTail := integer_rare_tail_probability heps hepshalf hr hPpos
    (rawCollision_memLp NR lamR hLawR r n)
    (rawCollision_mean NR lamR hLawR r n pR hn.ne' hlamR) hvarR
  have hheavyTail := integer_heavy_collision_tail NH lamH hLawH hpairH r hr n pH hpH
    eps heps hepshalf hn hlamH hheavy
  have hvarU := rawCollision_integer_relative_variance N lam hLaw hpair r hr0 n p hp hn hlam
    M hM hP (integerSampleConstant eps) hD hscale
  have hupperTail := integer_upper_tail_probability heps hepshalf hr hPpos
    (rawCollision_memLp N lam hLaw r n) (rawCollision_mean N lam hLaw r n p hn.ne' hlam) hvarU
  let U : Set Ω := {ω | Real.exp (eps*((r : ℝ)-1))*powerSumNat p r < rawCollision N r n ω}
  let R : Set Ω := {ω | rawCollision NR r n ω < powerSumNat pR r-integerRareGap eps r*powerSumNat p r}
  let H : Set Ω := {ω | rawCollision NH r n ω < Real.exp (-integerEta eps r)*powerSumNat pH r}
  have hsub : {ω | rawCollision N r n ω < Real.exp (-eps*((r : ℝ)-1))*powerSumNat p r ∨
      Real.exp (eps*((r : ℝ)-1))*powerSumNat p r < rawCollision N r n ω} ⊆ U ∪ (R ∪ H) := by
    intro ω hω
    by_contra hh
    simp only [Set.mem_union, Set.mem_setOf_eq, U, R, H, not_or, not_lt] at hh
    have hlow := integer_lower_band_combine heps hr hL0 hparts hh.2.1 hh.2.2
    rw [← hrawparts] at hlow
    rcases hω with hl | hu
    · exact not_lt_of_ge hlow hl
    · exact not_lt_of_ge hh.1 hu
  calc
    _ ≤ μ.real (U ∪ (R ∪ H)) := measureReal_mono hsub
    _ ≤ μ.real U + μ.real (R ∪ H) := measureReal_union_le _ _
    _ ≤ μ.real U + (μ.real R + μ.real H) := add_le_add_left (measureReal_union_le _ _) _
    _ ≤ 1/100 + (4/10000 + 1/32) := add_le_add hupperTail (add_le_add hrareTail hheavyTail)
    _ < 1/12 := by norm_num

/-- The actual raw-collision estimator achieves the full multiplicative band
at `D_epsilon r k^(1-1/r)` Poisson samples, uniformly over probability vectors. -/
theorem integer_raw_poisson_band
    (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (r : ℕ) (hr : 2 ≤ r) (n : ℝ) (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    (hsum : ∑ i, p i = 1) (eps : ℝ) (heps : 0 < eps) (hepshalf : eps ≤ 1/2)
    (hn : 0 < n) (hlam : ∀ i, (lam i : ℝ) = n*p i)
    (hsize : integerSampleConstant eps * r * (Fintype.card ι : ℝ) ^ (1-1/(r : ℝ)) ≤ n) :
    μ.real {ω | rawCollision N r n ω < Real.exp (-eps*((r : ℝ)-1))*powerSumNat p r ∨
      Real.exp (eps*((r : ℝ)-1))*powerSumNat p r < rawCollision N r n ω} < 1/12 := by
  have hPpos := powerSumNat_pos p hp hsum r
  let M := powerSumNat p r ^ (1/(r : ℝ))
  have hM : 0 < M := Real.rpow_pos_of_pos hPpos _
  have hP : powerSumNat p r = M^r := by
    dsimp [M]
    rw [one_div, Real.rpow_inv_natCast_pow hPpos.le (by omega : r ≠ 0)]
  have hscale := integer_sample_scale p hp hsum r (by omega) M hM.le hP
    (integerSampleConstant eps) (integerSampleConstant_pos heps).le n hsize
  exact integer_raw_poisson_band_of_scale N lam hLaw hpair r hr n p hp eps heps hepshalf hn hlam
    M hM hP hscale

end Renyi
