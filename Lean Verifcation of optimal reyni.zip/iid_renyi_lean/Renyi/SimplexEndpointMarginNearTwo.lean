import Renyi.SimplexEndpointMargin
import Mathlib.Analysis.MeanInequalities
import Renyi.ClippedOverlapLower

/-! The two endpoint arms jointly pay the baseline for orders between 3/2 and two. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- Geometric interpolation between the reverse and forward endpoint arms. -/
lemma endpoint_two_arm_interpolation {beta a theta s : ℝ}
    (hbeta : 0 ≤ beta) (hbeta1 : beta ≤ 1) (ha : 0 < a)
    (htheta : 0 < theta) (hs : 0 < s) :
    a ^ ((beta + 1) / 2) * theta ^ ((1 - beta) / 2) ≤
      a * s ^ (beta - 1) + theta * s ^ (beta + 1) := by
  have hx : 0 < a * s ^ (beta - 1) := by positivity
  have hy : 0 < theta * s ^ (beta + 1) := by positivity
  have hid : (a * s ^ (beta - 1)) ^ ((beta + 1) / 2) *
      (theta * s ^ (beta + 1)) ^ ((1 - beta) / 2) =
      a ^ ((beta + 1) / 2) * theta ^ ((1 - beta) / 2) := by
    apply Real.log_injOn_pos (by apply Set.mem_Ioi.mpr; positivity)
      (by apply Set.mem_Ioi.mpr; positivity)
    simp (disch := positivity) only [Real.log_mul, Real.log_rpow]
    ring
  have h := Real.geom_mean_le_arith_mean2_weighted
    (show 0 ≤ (beta + 1) / 2 by linarith)
    (show 0 ≤ (1 - beta) / 2 by linarith) hx.le hy.le
    (show (beta + 1) / 2 + (1 - beta) / 2 = 1 by ring)
  rw [hid] at h
  have h1 := mul_le_mul_of_nonneg_right
    (show (beta + 1) / 2 ≤ 1 by linarith) hx.le
  have h2 := mul_le_mul_of_nonneg_right
    (show (1 - beta) / 2 ≤ 1 by linarith) hy.le
  nlinarith only [h, h1, h2]

lemma endpoint_two_arm_point_lower {beta a theta t p : ℝ}
    (hbeta : 0 ≤ beta) (hbeta1 : beta ≤ 1) (ha : 0 < a)
    (htheta : 0 < theta) (ht : 0 < t) (htp : t ≤ p) :
    p * min (a ^ ((beta + 1) / 2) * theta ^ ((1 - beta) / 2)) (t ^ beta) ≤
      p ^ (1 + beta) * min (a / p + theta * p) 1 := by
  have hp : 0 < p := ht.trans_le htp
  have hgeom := endpoint_two_arm_interpolation hbeta hbeta1 ha htheta hp
  have htow := Real.rpow_le_rpow ht.le htp hbeta
  have hid : a * p ^ (beta - 1) + theta * p ^ (beta + 1) =
      p ^ beta * (a / p + theta * p) := by
    rw [Real.rpow_sub hp beta 1, Real.rpow_add hp beta 1]
    simp only [Real.rpow_one]
    field_simp
  rw [hid] at hgeom
  have hmin := min_le_min hgeom htow
  have hmul := mul_le_mul_of_nonneg_left hmin hp.le
  have hid2 : p ^ (1 + beta) = p * p ^ beta := by
    rw [Real.rpow_add hp 1 beta, Real.rpow_one]
  rw [hid2, mul_assoc, mul_min_of_nonneg _ _
    (Real.rpow_nonneg hp.le beta), mul_one]
  exact hmul

/-- A dimension-free summed lower bound, with an explicit geometric endpoint factor. -/
theorem simplex_two_arm_endpoint_margin {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {beta a theta : ℝ} (hbeta : 0 ≤ beta) (hbeta1 : beta ≤ 1)
    (ha : 0 < a) (htheta : 0 < theta) (hcut : a ≤ (1 : ℝ) / (2 * k)) :
    (1 : ℝ) / 2 *
      min (a ^ ((beta + 1) / 2) * theta ^ ((1 - beta) / 2))
        (((1 : ℝ) / (2 * k)) ^ beta) ≤
      ∑ i, if a ≤ p.mass i then
        p.mass i ^ (1 + beta) * min (a / p.mass i + theta * p.mass i) 1 else 0 := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  let t := (1 : ℝ) / (2 * k)
  let G := min (a ^ ((beta + 1) / 2) * theta ^ ((1 - beta) / 2)) (t ^ beta)
  have ht : 0 < t := by dsimp [t]; positivity
  have hG : 0 ≤ G := by dsimp [G]; positivity
  have hpoint (i : Fin k) : G * (if t ≤ p.mass i then p.mass i else 0) ≤
      if a ≤ p.mass i then
        p.mass i ^ (1 + beta) * min (a / p.mass i + theta * p.mass i) 1 else 0 := by
    by_cases hi : t ≤ p.mass i
    · have hai := hcut.trans hi
      simp only [hi, hai, ite_true]
      have hh := endpoint_two_arm_point_lower hbeta hbeta1 ha htheta ht hi
      dsimp [G]
      nlinarith only [hh]
    · simp only [hi, ite_false, mul_zero]
      split
      · exact mul_nonneg (Real.rpow_nonneg (p.nonneg i) _)
          (le_min (add_nonneg (div_nonneg ha.le (p.nonneg i))
            (mul_nonneg htheta.le (p.nonneg i))) zero_le_one)
      · exact le_refl _
  have hsum := Finset.sum_le_sum (fun i (_hi : i ∈ Finset.univ) => hpoint i)
  have hmass := mul_le_mul_of_nonneg_left (simplex_half_mass_above_uniform_threshold hk p) hG
  rw [Finset.mul_sum] at hmass
  nlinarith only [hsum, hmass]

end Renyi
