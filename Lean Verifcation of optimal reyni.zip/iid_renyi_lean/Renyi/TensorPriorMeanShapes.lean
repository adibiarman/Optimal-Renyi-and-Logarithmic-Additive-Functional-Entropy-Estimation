import Renyi.TensorMeanShapes

/-! Explicit mean-power upper bounds for both short-factor orientations. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 1000000

/-- Actual short active factor: the power mean has a uniform fourth-power
dimensional envelope after preserving the target-mass cancellation. -/
theorem tensor_prior_active_mean_shape {ν τ : Type*} [Fintype ν] [Fintype τ]
    (p : FiniteAtomicPrior τ) (r w : ν→ℝ) (n : ℕ)
    (zeta a rho s alpha kappa delta c b M : ℝ)
    (hn : 0<n) (hz0 : 0<zeta) (hz1 : zeta≤3/5)
    (ha : 0<a) (hrho : 0≤rho) (hrho1 : rho≤1)
    (hs : 0<s) (hs1 : s≤1) (hk : 0<kappa) (hd : 0<delta)
    (hc : 0<c) (hc1 : c≤1) (hzc : c*s≤zeta) (hb : 0<b)
    (halpha : s+2≤alpha)
    (haB : a≤((zeta/8)/((n:ℝ)+1)^2)/2)
    (hpert : rho*a/((zeta/8)/((n:ℝ)+1)^2)≤zeta)
    (hprincipal : 1/2≤normalizedInterpolation (chebyshevNode n ((zeta/8)/((n:ℝ)+1)^2)) a rho s none)
    (hfloor : delta*kappa≤(a/((zeta/8)/((n:ℝ)+1)^2))^s)
    (hw : ∀ j, 0<w j) (hwb : ∀ j, b≤w j)
    (hr : ∑ j, positiveCoeff (r j)=1) (hnr : (∑ j, negativeCoeff (r j))≤1)
    (j₀ : ν) (hw₀ : w j₀=b) (hpr : 1/2≤|r j₀|)
    (hM : 0≤M) (hM2 : M≤2) :
    let bs := (zeta/8)/((n:ℝ)+1)^2
    let us := chebyshevNode n bs
    let l := normalizedInterpolation us a rho s
    let U := interpolationNodes us a
    (∑ i, l i*U i^(alpha-1)=0) →
    (priorMoment p alpha=((a*b)⁻¹)^(alpha-1)/tensorNormalizer l r U w a alpha*M) →
    priorMoment p alpha≤4096*Real.exp 1*((n:ℝ)+1)^4/(delta*kappa*c*zeta) := by
  let bs := (zeta/8)/((n:ℝ)+1)^2
  let us := chebyshevNode n bs
  let l := normalizedInterpolation us a rho s
  let U := interpolationNodes us a
  dsimp only
  intro hcancel hA
  have hJ := active_jordan_uniform_lower n zeta a rho s (alpha-1) kappa delta c hn hz0 hz1 ha hrho hrho1 hs hs1 hk hd hc hc1 hzc haB hpert (by linarith) hprincipal hcancel hfloor
  let J₀ := delta*kappa*c*Real.exp (-1)*zeta/(1024*((n:ℝ)+1)^4)
  have hJ₀ : 0<J₀ := by dsimp [J₀]; positivity
  have hbs0 : 0<bs := by dsimp [bs]; positivity
  have hn0 : (0:ℝ)≤n := Nat.cast_nonneg n
  have hden : (1:ℝ)≤((n:ℝ)+1)^2 := by nlinarith
  have hbs1 : bs<1 := by apply (div_lt_one (by positivity)).mpr; linarith
  have hu (i) : 0<U i := by
    cases i with
    | none => exact ha
    | some i => exact hbs0.trans_le (chebyshevNode_bounds n bs hbs1.le i).1
  have hh := tensor_prior_mean_upper l U r w p ha hb (by linarith) hu hw hwb hr hnr j₀ hw₀ hpr hcancel hJ₀ hJ hM hM2 hA
  have heq : 4/J₀=4096*Real.exp 1*((n:ℝ)+1)^4/(delta*kappa*c*zeta) := by
    dsimp [J₀]
    rw [Real.exp_neg]
    field_simp
    ring
  exact hh.trans_eq heq

/-- Actual short complementary factor, including degree zero: the mean
power has an explicit fourth-power dimensional envelope. -/
theorem tensor_prior_complementary_mean_shape {ν τ : Type*} [Fintype ν] [Fintype τ]
    (p : FiniteAtomicPrior τ) (r w : ν→ℝ) (n : ℕ)
    (xi z alpha b M : ℝ)
    (hxi0 : 1/2≤xi) (hxi1 : xi<1) (hz0 : 0<z) (hz1 : z≤1)
    (halpha : 1≤alpha) (hb : 0<b)
    (hw : ∀ j, 0<w j) (hwb : ∀ j, b≤w j)
    (hr : ∑ j, positiveCoeff (r j)=1) (hnr : (∑ j, negativeCoeff (r j))≤1)
    (j₀ : ν) (hw₀ : w j₀=b) (hpr : 1/2≤|r j₀|)
    (hM : 0≤M) (hM2 : M≤2) :
    let bc := xi/((n:ℝ)+1)^2
    let ac := Real.exp (-5)*bc*z^(1/xi)
    let uc := chebyshevNode n bc
    let l := normalizedInterpolation uc ac 0 xi
    let U := interpolationNodes uc ac
    (∑ i, l i*U i^(alpha-1)=0) →
    (priorMoment p alpha=((ac*b)⁻¹)^(alpha-1)/tensorNormalizer l r U w ac alpha*M) →
    priorMoment p alpha≤128*Real.exp 5*((n:ℝ)+1)^4/z := by
  let bc := xi/((n:ℝ)+1)^2
  let ac := Real.exp (-5)*bc*z^(1/xi)
  let uc := chebyshevNode n bc
  let l := normalizedInterpolation uc ac 0 xi
  let U := interpolationNodes uc ac
  dsimp only
  intro hcancel hA
  have hJ := complementary_jordan_lower n xi z (alpha-1) hxi0 hxi1 hz0 hz1 hcancel
  let J₀ := Real.exp (-5)*z/(32*((n:ℝ)+1)^4)
  have hJ₀ : 0<J₀ := by dsimp [J₀]; positivity
  have hxi : 0<xi := by linarith
  have hbc0 : 0<bc := by dsimp [bc]; positivity
  have hac : 0<ac := by dsimp [ac]; positivity
  have hn0 : (0:ℝ)≤n := Nat.cast_nonneg n
  have hden : (1:ℝ)≤((n:ℝ)+1)^2 := by nlinarith
  have hbc1 : bc<1 := by apply (div_lt_one (by positivity)).mpr; linarith
  have hu (i) : 0<U i := by
    cases i with
    | none => exact hac
    | some i => exact hbc0.trans_le (chebyshevNode_bounds n bc hbc1.le i).1
  have hh := tensor_prior_mean_upper l U r w p hac hb halpha hu hw hwb hr hnr j₀ hw₀ hpr hcancel hJ₀ hJ hM hM2 hA
  have heq : 4/J₀=128*Real.exp 5*((n:ℝ)+1)^4/z := by
    dsimp [J₀]
    rw [Real.exp_neg]
    field_simp
    ring
  exact hh.trans_eq heq

end Renyi
