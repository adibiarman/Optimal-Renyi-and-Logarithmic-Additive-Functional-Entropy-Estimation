import Renyi.CompletedDampingThreshold
import Renyi.CompletedCoupledPolynomial

/-! The strict deterministic upper bound for the full single coupled polynomial. -/
noncomputable section
namespace Renyi

/-- Both source low branches share a single damping threshold and spatial margin. -/
theorem completedProfiles_strict_upper {fL f E : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) (hE : 0<E) :
    ∃ M0 c : ℝ, 1≤M0 ∧ 0<c ∧ ∀ (M : ℝ), M0≤M →
      ∀ (ℓ N : ℕ) (γ z ω x y : ℝ), 0<ℓ → 2≤N → 0<γ → γ<1 →
        0<z → z≤Real.exp (-E) → 0≤ω → ω≤Real.exp (-E/8) →
        0≤x → x≤1 → 0≤y → y≤1 →
        ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y)≤
          Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) →
        (overlapA γ z*Real.exp (-M*γ))*
          completedLowProfile ℓ γ (DegreeOneCompletion.coefficient γ fL) fL x*(1-endpointProfile N 6 1 y)+
          (overlapB γ z*Real.exp (-M*(1-γ)))*highProfile N (1-γ) f ω y+
          ω*(1-overlapB γ z*Real.exp (-M*(1-γ)))*endpointProfile N 6 (1-γ) y≤
          1-c*min (γ*(1-γ)+(N:ℝ)^2*y+min ((ℓ:ℝ)^2*x) 1) 1 := by
  obtain ⟨MC,cC,hMC,hcC,hC⟩ := coupledProfiles_strict_upper_damping_uniform hfL hfL1 hf hf1 hE
  obtain ⟨MD,cD,hMD,hcD,hD⟩ := DegreeOneCompletion.coupledProfiles_strict_upper_damping_uniform hfL hfL1 hf hf1 hE
  refine ⟨max MC MD,min cC cD,hMC.trans (le_max_left _ _),lt_min hcC hcD,?_⟩
  intro M hM ℓ N γ z ω x y hℓ hN hγ hγ1 hz hzE hω hωE hx hx1 hy hy1 hcap
  have hR : 0≤min (γ*(1-γ)+(N:ℝ)^2*y+min ((ℓ:ℝ)^2*x) 1) 1 :=
    le_min (add_nonneg (add_nonneg (mul_nonneg hγ.le (sub_nonneg.mpr hγ1.le)) (by positivity))
      (le_min (by positivity) (by norm_num))) (by norm_num)
  by_cases hℓ1 : ℓ=1
  · subst ℓ
    have hcap' : x*((N:ℝ)^2*y)≤
        Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) := by
      simpa only [Nat.cast_one,one_pow,one_mul] using hcap
    have hh := hD M ((le_max_right _ _).trans hM) 2 N γ z ω x y (by norm_num) hN hγ hγ1
      hz hzE hω hωE hx hx1 hy hy1 hcap'
    have hcoef := mul_le_mul_of_nonneg_right (min_le_right cC cD) hR
    simp only [Nat.cast_one,one_pow,one_mul] at hcoef ⊢
    simp only [completedLowProfile,if_true]
    dsimp only [DegreeOneCompletion.coupledDampedExpression,DegreeOneCompletion.lowProfile] at hh
    linarith only [hh,hcoef]
  · have hh := hC M ((le_max_left _ _).trans hM) ℓ N γ z ω x y (by omega) hN hγ hγ1
      hz hzE hω hωE hx hx1 hy hy1 hcap
    have hcoef := mul_le_mul_of_nonneg_right (min_le_left cC cD) hR
    simp only [completedLowProfile,if_neg hℓ1]
    dsimp only [coupledDampedExpression] at hh
    linarith only [hh,hcoef]

/-- Strict upper enclosure for the exact completed polynomial, including ℓ=1. -/
theorem completedCoupledPolynomial_strict_upper {fL f E : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) (hE : 0<E) :
    ∃ M0 c : ℝ, 1≤M0 ∧ 0<c ∧ ∀ (M : ℝ), M0≤M →
      ∀ (ℓ N m : ℕ) (γ z ω a b p : ℝ), 0<ℓ → 2≤N → 1≤m → 4*(ℓ-1)≤m →
        0<γ → γ<1 → 0<z → z≤Real.exp (-E) → 0≤ω → ω≤Real.exp (-E/8) →
        0<a → a≤p → p≤b →
        ((ℓ:ℝ)^2*(a/p))*((N:ℝ)^2*(p/b))≤
          Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) →
        (completedCoupledPolynomial ℓ N m γ a b (DegreeOneCompletion.coefficient γ fL) fL f
          (overlapA γ z*Real.exp (-M*γ)) (overlapB γ z*Real.exp (-M*(1-γ))) ω).eval p≤
          p^((m:ℝ)+γ)*(1-c*
            min (γ*(1-γ)+(N:ℝ)^2*(p/b)+min ((ℓ:ℝ)^2*(a/p)) 1) 1) := by
  obtain ⟨M0,c,hM0,hc,hbound⟩ := completedProfiles_strict_upper hfL hfL1 hf hf1 hE
  refine ⟨M0,c,hM0,hc,?_⟩
  intro M hM ℓ N m γ z ω a b p hℓ hN hm hdegree hγ hγ1 hz hzE hω hωE ha hap hpb hcap
  have hp : 0<p := ha.trans_le hap
  have hb : 0<b := hp.trans_le hpb
  have hh := hbound M hM ℓ N γ z ω (a/p) (p/b) hℓ hN hγ hγ1 hz hzE hω hωE
    (div_nonneg ha.le hp.le) ((div_le_one hp).mpr hap)
    (div_nonneg hp.le hb.le) ((div_le_one hb).mpr hpb) hcap
  rw [completedCoupledPolynomial_eval hℓ (by omega : 0<N) hm hdegree hγ hγ1
    (DegreeOneCompletion.coefficient_pos hγ hfL1) ha hap hpb]
  exact mul_le_mul_of_nonneg_left hh (Real.rpow_nonneg hp.le _)

end Renyi
