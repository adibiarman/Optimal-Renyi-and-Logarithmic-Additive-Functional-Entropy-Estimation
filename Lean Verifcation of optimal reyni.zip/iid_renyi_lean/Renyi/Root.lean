import Renyi.Model

/-!
# Basic well-posedness of the noninteger scalar root

These lemmas establish nonemptiness and the lower endpoint of the infimum.
They do not establish the uniform calibration estimates needed in the proof.
-/

noncomputable section
namespace Renyi

/-- The defining set has a point for every positive coefficient, order, and q. -/
theorem scalar_root_set_nonempty {c α q : ℝ}
    (hc : 0 < c) (hα : 0 < α) (hq : 0 < q) :
    {x : ℝ | 1 ≤ x ∧ 1 ≤ c * x ^ α *
      max (1 + Real.log (x * (1 + Real.log x) / q)) 0}.Nonempty := by
  let x := max 1 (max q ((1 / c) ^ (1 / α)))
  have hx1 : 1 ≤ x := le_max_left _ _
  have hxq : q ≤ x := (le_max_left _ _).trans (le_max_right _ _)
  have hxp : (1 / c) ^ (1 / α) ≤ x := (le_max_right _ _).trans (le_max_right _ _)
  have hxpos : 0 < x := lt_of_lt_of_le zero_lt_one hx1
  have hcp : 0 < 1 / c := by positivity
  have hpower := Real.rpow_le_rpow (Real.rpow_nonneg hcp.le _) hxp hα.le
  rw [← Real.rpow_mul hcp.le, one_div_mul_cancel (ne_of_gt hα),
    Real.rpow_one] at hpower
  have hcx : 1 ≤ c * x ^ α := by
    have h := mul_le_mul_of_nonneg_left hpower hc.le
    have hcancel : c * (1 / c) = 1 := by field_simp
    simpa only [hcancel] using h
  have hlogx : 0 ≤ Real.log x := Real.log_nonneg hx1
  have hquot : 1 ≤ x * (1 + Real.log x) / q := by
    apply (le_div_iff₀ hq).2
    nlinarith [mul_nonneg hxpos.le hlogx]
  have hlog : 0 ≤ Real.log (x * (1 + Real.log x) / q) := Real.log_nonneg hquot
  have hbracket : 1 ≤ max (1 + Real.log (x * (1 + Real.log x) / q)) 0 :=
    le_trans (by linarith) (le_max_left _ _)
  refine ⟨x, hx1, ?_⟩
  have h := mul_le_mul_of_nonneg_left hbracket (by positivity : 0 ≤ c * x ^ α)
  simp only [mul_one] at h
  exact hcx.trans h

theorem rootQSquared_pos {k : ℕ} {α ε : ℝ} (hα : 1 < α)
    (hγ0 : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1) :
    0 < rootQSquared k α ε := by
  have hβ : 0 < α - 1 := sub_pos.mpr hα
  have hα0 : 0 < α := by linarith
  have hδ : 0 < 1 - fractionalPart α := sub_pos.mpr hγ1
  unfold rootQSquared
  dsimp only
  positivity

theorem root_set_nonempty {k : ℕ} {α ε : ℝ} (hα : 1 < α)
    (hγ0 : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1) :
    {x : ℝ | 1 ≤ x ∧ 1 ≤
      (α * (fractionalPart α * (1 - fractionalPart α)) / (α - 1)) * x ^ α *
      max (1 + Real.log (x * (1 + Real.log x) / rootQSquared k α ε)) 0}.Nonempty := by
  have hβ : 0 < α - 1 := sub_pos.mpr hα
  have hα0 : 0 < α := by linarith
  have hδ : 0 < 1 - fractionalPart α := sub_pos.mpr hγ1
  exact scalar_root_set_nonempty (by positivity) hα0 (rootQSquared_pos hα hγ0 hγ1)

/-- Unlike the extended multiplier, the noninteger root is always at least one. -/
theorem one_le_rootMultiplier {k : ℕ} {α ε : ℝ} (hα : 1 < α)
    (hγ0 : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1) :
    1 ≤ rootMultiplier k α ε := by
  exact le_csInf (root_set_nonempty hα hγ0 hγ1) (fun _ hx => hx.1)

/-- The fractional-part hypotheses follow from being noninteger. -/
theorem one_le_rootMultiplier_of_noninteger {k : ℕ} {α ε : ℝ}
    (hα : 1 < α) (hn : ∀ m : ℤ, α ≠ (m : ℝ)) :
    1 ≤ rootMultiplier k α ε := by
  apply one_le_rootMultiplier hα
  · exact Int.fract_pos.mpr (hn _)
  · exact Int.fract_lt_one α

/-- If the criterion already holds at one, the infimum is exactly one. -/
theorem rootMultiplier_eq_one {k : ℕ} {α ε : ℝ} (hα : 1 < α)
    (hγ0 : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1)
    (hcriterion : 1 ≤
      (α * (fractionalPart α * (1 - fractionalPart α)) / (α - 1)) *
        max (1 + Real.log (1 / rootQSquared k α ε)) 0) :
    rootMultiplier k α ε = 1 := by
  apply le_antisymm _ (one_le_rootMultiplier hα hγ0 hγ1)
  apply csInf_le
  · exact ⟨1, fun _ hx => hx.1⟩
  · exact ⟨le_rfl, by simpa using hcriterion⟩

end Renyi
