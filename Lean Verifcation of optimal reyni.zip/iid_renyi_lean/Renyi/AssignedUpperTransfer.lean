import Renyi.ActualAssignedMean

/-! Scalar upper transfer with one realized heavy aggregate and the full source budget. -/
noncomputable section
namespace Renyi

lemma assigned_corrected_upper_margin_transfer {P L PH B F err e kappa chi u r r0 cRaw cH g : ℝ}
    (hP : 0≤P) (hL : 0≤L) (hPH : 0≤PH) (hB0 : 0≤B) (herr : 0≤err) (he : 0≤e)
    (hkappa : 0≤kappa) (hkappa1 : kappa≤1) (hchi : 0≤chi) (hchi1 : chi≤1) (hu : 0≤u)
    (hr0 : 1/2≤r0) (hr : r0≤r) (_hr1 : r≤1) (hcRaw : 0<cRaw) (hcH : 0<cH) (hg : 0<g)
    (hrescale : g*u≤1-r) (hmean : F+(cRaw*L+cH*PH)≤P+err)
    (hpay : 4*e+err≤(cRaw*L+cH*PH)/2) (hB : B≤L+PH+err) :
    let K := min cRaw cH
    let cB := K/(1+K/2)
    let c := min 1 (min g (r0*cB/4))
    r*F+2*e+c*(e+kappa*u*P+chi*kappa*B)≤P := by
  dsimp only
  let S := cRaw*L+cH*PH
  let K := min cRaw cH
  let cB := K/(1+K/2)
  let c := min 1 (min g (r0*cB/4))
  have hS : 0≤S := add_nonneg (mul_nonneg hcRaw.le hL) (mul_nonneg hcH.le hPH)
  have hK : 0<K := lt_min hcRaw hcH
  have hcB : 0<cB := by dsimp [cB];positivity
  have hr00 : 0<r0 := lt_of_lt_of_le (by norm_num) hr0
  have hrpos : 0≤r := hr00.le.trans hr
  have hrhalf : 1/2≤r := hr0.trans hr
  have hc : 0≤c := (lt_min zero_lt_one (lt_min hg (by positivity))).le
  have hc1 : c≤1 := min_le_left _ _
  have hcg : c≤g := (min_le_right _ _).trans (min_le_left _ _)
  have hcb : c≤r0*cB/4 := (min_le_right _ _).trans (min_le_right _ _)
  have hSsmall : K*(L+PH)≤S := by
    have h1 := mul_le_mul_of_nonneg_right (min_le_left cRaw cH) hL
    have h2 := mul_le_mul_of_nonneg_right (min_le_right cRaw cH) hPH
    nlinarith only [h1,h2]
  have hErrS : err≤S/2 := by linarith only [hpay,he]
  have hBscaled := mul_le_mul_of_nonneg_left hB hK.le
  have herrscaled := mul_le_mul_of_nonneg_left hErrS hK.le
  have hBS : cB*B≤S := by
    have hh : K*B≤(1+K/2)*S := by nlinarith only [hBscaled,herrscaled,hSsmall]
    have hden : 0<1+K/2 := by positivity
    dsimp only [cB]
    rw [div_mul_eq_mul_div]
    apply (div_le_iff₀ hden).mpr
    change K*B≤S*(1+K/2)
    nlinarith only [hh]
  have hmain := mul_le_mul_of_nonneg_left hmean hrpos
  have hpayR := mul_le_mul_of_nonneg_left hpay hrpos
  have heR := mul_le_mul_of_nonneg_right hrhalf he
  have hresP := mul_le_mul_of_nonneg_right hrescale hP
  have hκreg := mul_le_of_le_one_left (mul_nonneg hu hP) hkappa1
  have hreg := mul_le_mul_of_nonneg_left hκreg hg.le
  have hκχ : 0≤chi*kappa := mul_nonneg hchi hkappa
  have hκχ1 : chi*kappa≤1 := by simpa only [one_mul] using mul_le_mul hchi1 hkappa1 hkappa (by norm_num : (0:ℝ)≤1)
  have hBχ := mul_le_of_le_one_left hB0 hκχ1
  have hBχ' := mul_le_mul_of_nonneg_left hBχ hcB.le
  have hBhalf : (r0*cB/4)*(chi*kappa*B)≤r*S/4 := by
    have h1 := mul_le_mul_of_nonneg_left (hBχ'.trans hBS) (div_nonneg hr00.le (by norm_num : (0:ℝ)≤4))
    have h2 := mul_le_mul_of_nonneg_right hr hS
    nlinarith only [h1,h2]
  have hehalf : e≤r*S/4 := by
    have h1 := mul_le_mul_of_nonneg_right hrhalf hS
    nlinarith only [hpay,herr,h1]
  have hce := mul_le_of_le_one_left he hc1
  have hcr := mul_le_mul_of_nonneg_right hcg (mul_nonneg (mul_nonneg hkappa hu) hP)
  have hcb' := mul_le_mul_of_nonneg_right hcb (mul_nonneg hκχ hB0)
  change r*F+2*e+c*(e+kappa*u*P+chi*kappa*B)≤P
  nlinarith only [hmain,hpayR,heR,hresP,hreg,hBhalf,hehalf,hce,hcr,hcb']

end Renyi
