import Renyi.OverlapEnvelope
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv

/-! Strict monotonicity of the exact envelope, derived from its formula. -/
noncomputable section
open Set
namespace Renyi

/-- This is the manuscript's `J(t/2)`, in exponential coordinates. -/
def overlapJ (t : ℝ) : ℝ := t / 2 + t / (Real.exp t - 1)

theorem overlapJ_hasDerivAt {t : ℝ} (ht : 0 < t) :
    HasDerivAt overlapJ
      (1/2 + ((Real.exp t - 1) - t * Real.exp t) / (Real.exp t - 1)^2) t := by
  have he : Real.exp t - 1 ≠ 0 := (sub_pos.mpr (Real.one_lt_exp_iff.mpr ht)).ne'
  convert ((hasDerivAt_id t).div_const 2).add
    ((hasDerivAt_id t).div ((Real.hasDerivAt_exp t).sub_const 1) he) using 1; simp

theorem overlapJ_deriv_pos {t : ℝ} (ht : 0 < t) : 0 < deriv overlapJ t := by
  rw [(overlapJ_hasDerivAt ht).deriv]
  have he : 0 < Real.exp t - 1 := sub_pos.mpr (Real.one_lt_exp_iff.mpr ht)
  have hs := Real.self_lt_sinh_iff.mpr ht
  rw [Real.sinh_eq, Real.exp_neg] at hs
  have hexp := Real.exp_pos t
  have hp : 2*t*Real.exp t < (Real.exp t)^2 - 1 := by
    have hm := (mul_lt_mul_iff_of_pos_right hexp).2 hs
    field_simp at hm
    nlinarith
  have heq : 1/2 + ((Real.exp t-1)-t*Real.exp t)/(Real.exp t-1)^2 =
      ((Real.exp t)^2-1-2*t*Real.exp t)/(2*(Real.exp t-1)^2) := by
    field_simp
    ring
  rw [heq]
  exact div_pos (by linarith) (mul_pos (by norm_num) (sq_pos_of_pos he))

/-- The scalar auxiliary function is strictly increasing on the positive axis. -/
theorem overlapJ_strictMonoOn : StrictMonoOn overlapJ (Ioi (0 : ℝ)) := by
  apply strictMonoOn_of_deriv_pos (convex_Ioi 0)
  · intro t ht
    exact (overlapJ_hasDerivAt ht).continuousAt.continuousWithinAt
  · intro t ht
    exact overlapJ_deriv_pos (by simpa using ht)

/-- Negative log of the envelope after `z=exp(-γ(1-γ)t)`, in elementary terms. -/
def overlapF (γ t : ℝ) : ℝ :=
  γ*(1-γ)*t + Real.log (1-Real.exp (-t)) -
    (1-γ)*Real.log (1-Real.exp (-(1-γ)*t)) -
    γ*Real.log (1-Real.exp (-γ*t)) + (1-γ)*Real.log (1-γ) + γ*Real.log γ

private theorem one_sub_exp_neg_pos {t : ℝ} (ht : 0 < t) : 0 < 1-Real.exp (-t) := by
  apply sub_pos.mpr
  rw [Real.exp_lt_one_iff]
  linarith

/-- The elementary expression is exactly the logarithm of the original envelope. -/
theorem overlapF_eq_log {γ t : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) (ht : 0 < t) :
    overlapF γ t = -Real.log (overlapG γ (Real.exp (-γ*(1-γ)*t))) := by
  have hd : 0 < 1-γ := sub_pos.mpr hγ1
  have he : Real.exp (-γ*(1-γ)*t) < 1 := Real.exp_lt_one_iff.mpr (by nlinarith [mul_pos (mul_pos hγ hd) ht])
  have hA : overlapA γ (Real.exp (-γ*(1-γ)*t)) =
      (1-Real.exp (-(1-γ)*t))/(1-Real.exp (-t)) := by
    unfold overlapA
    rw [← Real.exp_mul, ← Real.exp_mul]
    congr 2 <;> congr 1 <;> field_simp
  have hB : overlapB γ (Real.exp (-γ*(1-γ)*t)) =
      (1-Real.exp (-γ*t))/(1-Real.exp (-t)) := by
    unfold overlapB
    rw [← Real.exp_mul, ← Real.exp_mul]
    congr 2 <;> congr 1 <;> field_simp
  have h0 := one_sub_exp_neg_pos ht
  have h1 : 0 < 1-Real.exp (-(1-γ)*t) := by
    simpa only [neg_mul] using one_sub_exp_neg_pos (mul_pos hd ht)
  have h2 : 0 < 1-Real.exp (-γ*t) := by
    simpa only [neg_mul] using one_sub_exp_neg_pos (mul_pos hγ ht)
  rw [overlapG_factor hγ hγ1 (Real.exp_pos _) he, hA, hB]
  rw [Real.log_mul (mul_pos (Real.exp_pos _) (Real.rpow_pos_of_pos (div_pos (div_pos h1 h0) hd) _)).ne'
      (Real.rpow_pos_of_pos (div_pos (div_pos h2 h0) hγ) _).ne',
    Real.log_mul (Real.exp_pos _).ne' (Real.rpow_pos_of_pos (div_pos (div_pos h1 h0) hd) _).ne',
    Real.log_exp, Real.log_rpow (div_pos (div_pos h1 h0) hd),
    Real.log_rpow (div_pos (div_pos h2 h0) hγ),
    Real.log_div (div_pos h1 h0).ne' hd.ne', Real.log_div h1.ne' h0.ne',
    Real.log_div (div_pos h2 h0).ne' hγ.ne', Real.log_div h2.ne' h0.ne']
  unfold overlapF
  ring

private theorem log_one_sub_exp_hasDerivAt {a t : ℝ} (ha : 0 < a) (ht : 0 < t) :
    HasDerivAt (fun t : ℝ => Real.log (1-Real.exp (-a*t)))
      (a / (Real.exp (a*t)-1)) t := by
  have h0 : 0 < 1-Real.exp (-a*t) := by
    simpa only [neg_mul] using one_sub_exp_neg_pos (mul_pos ha ht)
  have h := (((hasDerivAt_id t).const_mul (-a)).exp.const_sub 1).log h0.ne'
  convert h using 1
  simp only [id_eq, mul_one]
  rw [show -a*t = -(a*t) by ring, Real.exp_neg]
  field_simp

theorem overlapF_hasDerivAt {γ t : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) (ht : 0 < t) :
    HasDerivAt (overlapF γ)
      ((overlapJ t - (1-γ)*overlapJ ((1-γ)*t) - γ*overlapJ (γ*t))/t) t := by
  have hd : 0 < 1-γ := sub_pos.mpr hγ1
  have h := (((((hasDerivAt_id t).const_mul (γ*(1-γ))).add
    (log_one_sub_exp_hasDerivAt (a := 1) zero_lt_one ht)).sub
    ((log_one_sub_exp_hasDerivAt hd ht).const_mul (1-γ))).sub
    ((log_one_sub_exp_hasDerivAt hγ ht).const_mul γ)).add_const ((1-γ)*Real.log (1-γ)) |>.add_const (γ*Real.log γ)
  convert h using 1
  · funext s
    simp [overlapF]
  · unfold overlapJ
    simp only [one_mul]
    field_simp
    ring

/-- Strict increase follows from the strict increase of `overlapJ`. -/
theorem overlapF_strictMonoOn {γ : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    StrictMonoOn (overlapF γ) (Ioi (0 : ℝ)) := by
  have hd : 0 < 1-γ := sub_pos.mpr hγ1
  apply strictMonoOn_of_deriv_pos (convex_Ioi 0)
  · intro t ht
    exact (overlapF_hasDerivAt hγ hγ1 ht).continuousAt.continuousWithinAt
  · intro t ht
    have ht : 0 < t := by simpa using ht
    rw [(overlapF_hasDerivAt hγ hγ1 ht).deriv]
    apply div_pos _ ht
    have h1 := overlapJ_strictMonoOn (mul_pos hd ht) ht (show (1-γ)*t < t by nlinarith)
    have h2 := overlapJ_strictMonoOn (mul_pos hγ ht) ht (show γ*t < t by nlinarith)
    nlinarith [mul_pos hd (sub_pos.mpr h1), mul_pos hγ (sub_pos.mpr h2)]

/-- The original envelope is strictly increasing on `(0,1)`. -/
theorem overlapG_strictMonoOn {γ : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    StrictMonoOn (overlapG γ) (Ioo (0 : ℝ) 1) := by
  intro x hx y hy hxy
  have hd : 0 < 1-γ := sub_pos.mpr hγ1
  have hh : 0 < γ*(1-γ) := mul_pos hγ hd
  let tx := -Real.log x/(γ*(1-γ))
  let ty := -Real.log y/(γ*(1-γ))
  have htx : 0 < tx := div_pos (neg_pos.mpr (Real.log_neg hx.1 hx.2)) hh
  have hty : 0 < ty := div_pos (neg_pos.mpr (Real.log_neg hy.1 hy.2)) hh
  have htyx : ty < tx := (div_lt_div_iff_of_pos_right hh).2 (neg_lt_neg (Real.log_lt_log hx.1 hxy))
  have h := overlapF_strictMonoOn hγ hγ1 hty htx htyx
  have hex : Real.exp (-γ*(1-γ)*tx) = x := by
    have : -γ*(1-γ)*tx = Real.log x := by dsimp [tx]; field_simp
    rw [this, Real.exp_log hx.1]
  have hey : Real.exp (-γ*(1-γ)*ty) = y := by
    have : -γ*(1-γ)*ty = Real.log y := by dsimp [ty]; field_simp
    rw [this, Real.exp_log hy.1]
  rw [overlapF_eq_log hγ hγ1 hty, overlapF_eq_log hγ hγ1 htx, hex, hey] at h
  exact (Real.log_lt_log_iff (overlapG_mem_Ioo hγ hγ1 hx.1 hx.2).1
    (overlapG_mem_Ioo hγ hγ1 hy.1 hy.2).1).mp (neg_lt_neg_iff.mp h)

end Renyi
