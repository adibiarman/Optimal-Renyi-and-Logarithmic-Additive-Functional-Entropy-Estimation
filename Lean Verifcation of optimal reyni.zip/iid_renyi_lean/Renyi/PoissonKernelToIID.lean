import Renyi.PoissonToIID

/-! Actual fixed-iid estimators for randomized Poissonized procedures. -/
noncomputable section
open scoped BigOperators ENNReal NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- A randomized Poisson procedure uses the available iid prefix or a fallback. -/
def truncatedSampleKernel {k m : ℕ} (F : PoissonMarkedSample (Fin k) → PMF ℝ)
    (fallback : ℝ) (x : Sample k m) (q : ℕ) : PMF ℝ :=
  if h:q≤m then F ⟨q,samplePrefix h x⟩ else PMF.pure fallback

def poissonKernelToIIDEstimator {k m : ℕ} (b : ℝ≥0)
    (F : PoissonMarkedSample (Fin k) → PMF ℝ) (fallback : ℝ) : Estimator k m :=
  fun x => ⟨((poissonPMF b).bind (truncatedSampleKernel F fallback x)).toMeasure,inferInstance⟩

/-- The full output law, including all internal randomization. -/
theorem poissonKernelToIID_output_law {k m : ℕ} (b : ℝ≥0) (p : Simplex k)
    (F : PoissonMarkedSample (Fin k) → PMF ℝ) (fallback : ℝ) :
    (iidMarkPMF (simplexNN p) (simplexNN_sum p) m).bind
      (fun x => (poissonPMF b).bind (truncatedSampleKernel F fallback x)) =
      truncatedPoissonLaw b
        (fun q => (iidMarkPMF (simplexNN p) (simplexNN_sum p) q).bind
          (fun x => F ⟨q,x⟩)) fallback m := by
  unfold truncatedPoissonLaw
  rw [PMF.bind_comm]
  congr 1
  funext q
  by_cases hq:q≤m
  · rw [if_pos hq]
    change (iidMarkPMF (simplexNN p) (simplexNN_sum p) m).bind
      (fun x => truncatedSampleKernel F fallback x q)=_
    simp only [truncatedSampleKernel,hq,dif_pos]
    change (iidMarkPMF (simplexNN p) (simplexNN_sum p) m).bind
      ((fun x:Sample k q => F ⟨q,x⟩) ∘ samplePrefix hq)=_
    rw [←PMF.bind_map]
    rw [show (iidMarkPMF (simplexNN p) (simplexNN_sum p) m).map (samplePrefix hq)=
      iidMarkPMF (simplexNN p) (simplexNN_sum p) q from
      iidMarkPMF_prefix (simplexNN p) (simplexNN_sum p) hq]
  · simp [truncatedSampleKernel,hq,PMF.bind_const]

/-- Risk transfer loses only the actual Poisson overflow probability. -/
theorem poissonKernelToIID_error_le {k m : ℕ} (b : ℝ≥0) (p : Simplex k)
    (alpha eps : ℝ) (F : PoissonMarkedSample (Fin k) → PMF ℝ) (fallback : ℝ) :
    errorProbability p alpha eps (poissonKernelToIIDEstimator (m:=m) b F fallback)≤
      ((poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).bind F).toMeasure.real
        {z:ℝ | eps < |z - entropy p alpha| }+
      (poissonPMF b).toMeasure.real {q:ℕ | m<q} := by
  have hB : MeasurableSet {z:ℝ | eps < |z - entropy p alpha| } :=
    measurableSet_lt measurable_const (by fun_prop)
  unfold poissonKernelToIIDEstimator
  rw [errorProbability_of_pmf,poissonKernelToIID_output_law]
  have hh := truncatedPoissonLaw_real_event_le b
    (fun q => (iidMarkPMF (simplexNN p) (simplexNN_sum p) q).bind (fun x => F ⟨q,x⟩)) fallback m hB
  have hout : (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).bind F=
      (poissonPMF b).bind (fun q =>
        (iidMarkPMF (simplexNN p) (simplexNN_sum p) q).bind (fun x => F ⟨q,x⟩)) := by
    rw [poissonMarkedSamplePMF,PMF.bind_bind]
    simp only [PMF.bind_map,Function.comp_def]
  rw [←hout] at hh
  exact hh

/-- A concrete randomized Poisson kernel gives an actual fixed-iid estimator. -/
theorem achievable_of_poisson_kernel_error {k m : ℕ} (b : ℝ≥0)
    (alpha eps delta : ℝ) (F : PoissonMarkedSample (Fin k) → PMF ℝ)
    (herror : ∀ p:Simplex k,
      ((poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).bind F).toMeasure.real
        {z:ℝ | eps < |z - entropy p alpha| }≤delta)
    (hbudget : delta+(poissonPMF b).toMeasure.real {q:ℕ | m<q}≤1/3) :
    Achievable k m alpha eps := by
  refine ⟨poissonKernelToIIDEstimator b F 0,?_⟩
  intro p
  exact (poissonKernelToIID_error_le b p alpha eps F 0).trans
    ((add_le_add_right (herror p) _).trans hbudget)

/-- The concrete sample cap `ceil(2b)` and its proved Poisson tail. -/
theorem achievable_of_poisson_kernel_error_ceil_twice {k : ℕ} (b : ℝ≥0)
    (alpha eps delta : ℝ) (F : PoissonMarkedSample (Fin k) → PMF ℝ)
    (herror : ∀ p:Simplex k,
      ((poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).bind F).toMeasure.real
        {z:ℝ | eps < |z - entropy p alpha| }≤delta)
    (hbudget : delta+Real.exp (-(b:ℝ)/3)≤1/3) :
    Achievable k ⌈2*(b:ℝ)⌉₊ alpha eps := by
  exact achievable_of_poisson_kernel_error b alpha eps delta F herror
    ((add_le_add_left (poisson_tail_ceil_twice b) delta).trans hbudget)

end Renyi
