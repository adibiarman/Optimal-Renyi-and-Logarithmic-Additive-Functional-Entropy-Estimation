import Renyi.UpperPilotComparison
import Renyi.PowerBandCertificate

/-! Final finite-probability-budget assembly for the actual noninteger upper estimator. -/
noncomputable section
open MeasureTheory ProbabilityTheory
namespace Renyi
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

/-- A random ideal comparison, centered count fluctuation, common affine
anchor, and one nonnegative boundary envelope give the desired band. -/
theorem upper_band_of_ideal_and_noise
    (F Z C A E : Ω→ℝ) (G : Set Ω)
    {lo hi r deltaH deltaC deltaA deltaE : ℝ} (hr : 0<r)
    (hgood : μ.real Gᶜ≤deltaH)
    (hideal : ∀w∈G,lo+3*r≤Z w ∧ Z w+3*r≤hi)
    (hcomparison : ∀w,|F w-Z w-C w-A w|≤E w)
    (hC : MemLp C 2 μ) (hCmean : (∫w,C w ∂μ)=0)
    (hCvar : variance C μ≤deltaC*r^2)
    (hA : MemLp A 2 μ) (hAmean : (∫w,A w ∂μ)=0)
    (hAvar : variance A μ≤deltaA*r^2)
    (hE : Integrable E μ) (hE0 : ∀w,0≤E w)
    (hEmean : (∫w,E w ∂μ)≤deltaE*r) :
    μ.real {w | F w<lo ∨ hi<F w}≤deltaH+deltaC+deltaA+deltaE := by
  have hcount : μ.real {w | r < |C w|}≤deltaC := by
    have hh := real_chebyshev_gt hC hr
    rw [hCmean] at hh
    simp only [sub_zero] at hh
    exact hh.trans ((div_le_iff₀ (sq_pos_of_pos hr)).mpr hCvar)
  have hanchor : μ.real {w | r < |A w|}≤deltaA := by
    have hh := real_chebyshev_gt hA hr
    rw [hAmean] at hh
    simp only [sub_zero] at hh
    exact hh.trans ((div_le_iff₀ (sq_pos_of_pos hr)).mpr hAvar)
  have hboundary : μ.real {w | r<E w}≤deltaE := by
    have hh := pilot_boundary_markov hE hE0 (eta:=deltaE) (delta:=1) (M:=r) (by norm_num) hr hEmean
    simpa only [one_mul,div_one] using hh
  have hsubset : {w | F w<lo ∨ hi<F w}⊆
      ((Gᶜ∪{w | r < |C w|})∪{w | r < |A w|})∪{w | r<E w} := by
    intro w hw
    by_cases hg : w∈G
    · by_cases hc : r < |C w|
      · exact Or.inl (Or.inl (Or.inr hc))
      · by_cases ha : r < |A w|
        · exact Or.inl (Or.inr ha)
        · by_cases he : r<E w
          · exact Or.inr he
          · exfalso
            have hc' : |C w|≤r := le_of_not_gt hc
            have ha' : |A w|≤r := le_of_not_gt ha
            have he' : E w≤r := le_of_not_gt he
            have htriangle : |F w-Z w|≤E w+|C w|+|A w| := by
              have h1 := abs_add_le (F w-Z w-C w-A w) (C w)
              have h2 := abs_add_le ((F w-Z w-C w-A w)+C w) (A w)
              have hid : ((F w-Z w-C w-A w)+C w)+A w=F w-Z w := by ring
              rw [hid] at h2
              linarith only [h1,h2,hcomparison w]
            have hd : |F w-Z w|≤3*r := by linarith only [htriangle,hc',ha',he']
            have hi' := hideal w hg
            rcases hw with hw|hw
            · have hl := (abs_le.mp hd).1
              linarith only [hw,hi'.1,hl]
            · have hh := (abs_le.mp hd).2
              linarith only [hw,hi'.2,hh]
    · exact Or.inl (Or.inl (Or.inl hg))
  apply (measureReal_mono (μ:=μ) hsubset).trans
  have h1 := measureReal_union_le (μ:=μ) Gᶜ {w | r < |C w|}
  have h2 := measureReal_union_le (μ:=μ) (Gᶜ∪{w | r < |C w|}) {w | r < |A w|}
  have h3 := measureReal_union_le (μ:=μ) ((Gᶜ∪{w | r < |C w|})∪{w | r < |A w|}) {w | r<E w}
  linarith only [h1,h2,h3,hgood,hcount,hanchor,hboundary]

end Renyi
