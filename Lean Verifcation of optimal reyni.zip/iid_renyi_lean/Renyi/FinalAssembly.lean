import Renyi.LowerComplete
import Renyi.NearOneIIDComplete

/-! Assembly of the uniform minimax statement from the proved order regimes. -/
noncomputable section
namespace Renyi

/-- The positive-degree noninteger upper statement. Its unconditional proof is
`remaining_noninteger_iid_upper_verified` in `FullIIDVerification`. -/
def RemainingNonintegerUpperClaim : Prop :=
  ∀ eps : ℝ, 0<eps → eps<1/2 →
    ∃ C : ℝ, 0<C ∧ ∃ K : ℕ, ∀ k : ℕ, K≤k → 2<Real.log k →
      ∀ alpha : ℝ, 3/2<alpha → alpha<Real.log k →
        (¬∃r:ℕ,alpha=(r:ℝ)) →
        ∃ n : ℕ, (n:ℝ)≤C*rate k alpha eps ∧ Achievable k n alpha eps

/-- The noninteger upper statement, together with all other proved regimes,
establishes the precise full iid target. -/
theorem full_minimax_of_remaining_upper (hgeneral : RemainingNonintegerUpperClaim) :
    FullManuscriptClaim := by
  refine ⟨?_,min_entropy_minimax_verified⟩
  intro eps heps heps1
  obtain ⟨c,hc,KL,hKL,hLower⟩ := iid_uniform_lower_verified heps heps1.le
  obtain ⟨_cE,CE,_hcE,hCE,KE,hKE,hEndpoint⟩ := endpoint_iid_minimax_verified heps heps1.le
  obtain ⟨CN,hCN,KN,_hKN,hNear⟩ := near_one_iid_rate_upper_uniform heps
  obtain ⟨CG,hCG,KG,hGeneral⟩ := hgeneral eps heps heps1
  let C := max CE (max CN CG)
  let K := max KL (max KE (max KN KG))
  have hC : 0<C := hCE.trans_le (le_max_left _ _)
  refine ⟨c,C,K,hc,hC,?_⟩
  intro k hk hlog alpha halpha
  have hKLk : KL≤k := (le_max_left _ _).trans hk
  have hKEk : KE≤k := ((le_max_left _ _).trans (le_max_right _ _)).trans hk
  have hKNk : KN≤k := (((le_max_left _ _).trans (le_max_right _ _)).trans (le_max_right _ _)).trans hk
  have hKGk : KG≤k := (((le_max_right _ _).trans (le_max_right _ _)).trans (le_max_right _ _)).trans hk
  have hk1 : 1≤k := by omega
  have hrate : 0≤rate k alpha eps := rate_nonneg (by linarith only [halpha]) hk1
  constructor
  · have hmerge (C' : ℝ) (hCC : C'≤C)
        (hupper : ∃n:ℕ,(n:ℝ)≤C'*rate k alpha eps ∧ Achievable k n alpha eps) :
        ∃n:ℕ,(n:ℝ)≤C*rate k alpha eps ∧ Achievable k n alpha eps := by
      obtain ⟨n,hn,hach⟩ := hupper
      exact ⟨n,hn.trans (mul_le_mul_of_nonneg_right hCC hrate),hach⟩
    by_cases hEndpointCase : (∃r:ℕ,alpha=(r:ℝ)) ∨ Real.log k≤alpha
    · exact hmerge CE (le_max_left _ _) (hEndpoint k hKEk hlog alpha halpha hEndpointCase).1
    · have hnotint : ¬∃r:ℕ,alpha=(r:ℝ) := fun h => hEndpointCase (Or.inl h)
      have hLow : alpha<Real.log k := lt_of_not_ge (fun h => hEndpointCase (Or.inr h))
      by_cases hNearCase : alpha≤3/2
      · exact hmerge CN ((le_max_left _ _).trans (le_max_right _ _)) (hNear k hKNk alpha halpha hNearCase hLow)
      · exact hmerge CG ((le_max_right _ _).trans (le_max_right _ _)) (hGeneral k hKGk hlog alpha (lt_of_not_ge hNearCase) hLow hnotint)
  · exact hLower k hKLk hlog alpha halpha

end Renyi
