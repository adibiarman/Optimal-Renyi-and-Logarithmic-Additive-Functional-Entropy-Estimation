import Renyi.OmegaHeavyRandomSubset

/-! Fixed heavy upper deficit, uniform over the order and the experiment. -/
set_option maxHeartbeats 800000
noncomputable section
open scoped BigOperators NNReal
open Set MeasureTheory ProbabilityTheory
namespace Renyi

private theorem omegaHeavyFixed_basic_bounds {eps c0 : ℝ}
    (heps : 0 < eps) (hc0 : 0 < c0) (hc01 : c0 < 1) :
    0 < omegaHeavyDistance c0 ∧ omegaHeavyDistance c0 ≤ c0 / 2 ∧
      omegaHeavyDistance c0 ≤ 1 - c0 ∧
      0 < omegaHeavyTolerance eps c0 ∧ omegaHeavyTolerance eps c0 < 1 / 8 ∧
      omegaHeavyTolerance eps c0 ≤ omegaHeavyDistance c0 * eps / 12 ∧
      0 < omegaHeavyMargin eps c0 := by
  have hd : 0 < omegaHeavyDistance c0 := lt_min (by positivity) (by linarith)
  have ht : 0 < omegaHeavyTolerance eps c0 := lt_min (by norm_num) (by positivity)
  have ht1 : omegaHeavyTolerance eps c0 < 1 / 8 :=
    (min_le_left _ _).trans_lt (by norm_num)
  have hc : 0 < omegaHeavyMargin eps c0 := by
    unfold omegaHeavyMargin
    apply sub_pos.mpr
    exact Real.exp_lt_one_iff.mpr (neg_neg_of_pos (div_pos (mul_pos hd heps) (by norm_num)))
  exact ⟨hd, min_le_left _ _, min_le_right _ _, ht, ht1, min_le_right _ _, hc⟩

private theorem omegaHeavyFixed_log_one_sub_lower {t : ℝ} (ht : 0 < t) (ht1 : t < 1 / 8) :
    -4 * t ≤ Real.log (1 - 2 * t) := by
  have hx : 0 < 1 - 2 * t := by linarith
  have h := Real.log_le_sub_one_of_pos (inv_pos.mpr hx)
  rw [Real.log_inv] at h
  have hi : (1 - 2 * t)⁻¹ - 1 ≤ 4 * t := by
    apply (sub_le_iff_le_add).2
    apply (inv_le_iff_one_le_mul₀ hx).2
    nlinarith
  linarith

/-- Scalar margins with the same constants for every a at least three halves. -/
theorem omega_heavy_fixed_scalar_margins {eps c0 a E0 : ℝ}
    (heps : 0 < eps) (hc0 : 0 < c0) (hc01 : c0 < 1) (ha : 3 / 2 ≤ a)
    (hE0low : eps * (a - 1) ≤ E0) (hE0high : E0 ≤ 2 * eps * (a - 1)) :
    let kappa := Real.exp (-(2 * eps * (a - 1)))
    let omega := Real.exp (-c0 * E0)
    let t := omegaHeavyTolerance eps c0
    let c := omegaHeavyMargin eps c0
    kappa + c * kappa ≤ omega * (1 - 2 * t) ^ a ∧
      omega * (1 + 2 * t) ^ a ≤ 1 - c := by
  dsimp only
  obtain ⟨hd, hdc, hd1, ht, ht1, htbound, hc⟩ := omegaHeavyFixed_basic_bounds heps hc0 hc01
  let d := omegaHeavyDistance c0
  let t := omegaHeavyTolerance eps c0
  let E := 2 * eps * (a - 1)
  have hE : 0 < E := by dsimp [E]; exact mul_pos (by positivity) (by linarith)
  have hEeps : eps ≤ E := by dsimp [E]; nlinarith
  have herror : 4 * t * a ≤ d * E / 2 := by
    have haa : a ≤ 3 * (a - 1) := by linarith
    have hm := mul_le_mul_of_nonneg_left htbound (by nlinarith : 0 ≤ 12 * (a - 1))
    dsimp [E, d, t] at *
    nlinarith
  have hlo := omegaHeavyFixed_log_one_sub_lower ht ht1
  have hhi : Real.log (1 + 2 * t) ≤ 4 * t := by
    have h := Real.log_le_sub_one_of_pos (by positivity : 0 < 1 + 2 * t)
    linarith
  have hlowexp : -E + d * E / 2 ≤ -c0 * E0 + a * Real.log (1 - 2 * t) := by
    have hlog := mul_le_mul_of_nonneg_left hlo (by linarith : 0 ≤ a)
    have hmean := mul_le_mul_of_nonneg_left hE0high hc0.le
    have hdist := mul_le_mul_of_nonneg_right hd1 hE.le
    dsimp [E, d] at *
    nlinarith
  have hhighexp : -c0 * E0 + a * Real.log (1 + 2 * t) ≤ -d * E / 2 := by
    have hlog := mul_le_mul_of_nonneg_left hhi (by linarith : 0 ≤ a)
    have hmean := mul_le_mul_of_nonneg_left hE0low hc0.le
    have hdist := mul_le_mul_of_nonneg_right hdc hE.le
    dsimp [E, d] at *
    nlinarith
  have hcoeflow : Real.exp (-E) * Real.exp (d * E / 2) ≤
      Real.exp (-c0 * E0) * (1 - 2 * t) ^ a := by
    rw [Real.rpow_def_of_pos (by linarith : 0 < 1 - 2 * t), ← Real.exp_add, ← Real.exp_add]
    exact Real.exp_le_exp.mpr (by nlinarith [hlowexp])
  have hcoefhigh : Real.exp (-c0 * E0) * (1 + 2 * t) ^ a ≤ Real.exp (-d * E / 2) := by
    rw [Real.rpow_def_of_pos (by positivity : 0 < 1 + 2 * t), ← Real.exp_add]
    exact Real.exp_le_exp.mpr (by nlinarith [hhighexp])
  have hmargin : 1 + omegaHeavyMargin eps c0 ≤ Real.exp (d * E / 2) := by
    have hpair := Real.add_one_le_exp (d * eps / 2)
    have hpair' := Real.add_one_le_exp (-(d * eps / 2))
    have hmon : Real.exp (d * eps / 2) ≤ Real.exp (d * E / 2) :=
      Real.exp_le_exp.mpr (by nlinarith [mul_le_mul_of_nonneg_left hEeps hd.le])
    unfold omegaHeavyMargin
    dsimp [d] at *
    nlinarith
  have hupper : Real.exp (-d * E / 2) ≤ 1 - omegaHeavyMargin eps c0 := by
    unfold omegaHeavyMargin
    simp only [sub_sub_cancel]
    apply Real.exp_le_exp.mpr
    have hdist := mul_le_mul_of_nonneg_left hEeps hd.le
    dsimp [d] at *
    nlinarith
  constructor
  · change Real.exp (-E) + omegaHeavyMargin eps c0 * Real.exp (-E) ≤
      Real.exp (-c0 * E0) * (1 - 2 * t) ^ a
    calc
      _ = Real.exp (-E) * (1 + omegaHeavyMargin eps c0) := by ring
      _ ≤ Real.exp (-E) * Real.exp (d * E / 2) :=
        mul_le_mul_of_nonneg_left hmargin (Real.exp_pos (-E)).le
      _ ≤ _ := hcoeflow
  · change Real.exp (-c0 * E0) * (1 + 2 * t) ^ a ≤
      1 - omegaHeavyMargin eps c0
    exact hcoefhigh.trans hupper


/-- Explicit heavy constants precede every choice of probability space. The
upper deficit is fixed, rather than multiplied by kappa. -/
theorem omega_heavy_fixed_concentration_uniform {eps c0 rho : ℝ}
    (heps : 0<eps) (hc0 : 0<c0) (hc01 : c0<1) (hrho : 0<rho) (hrho1 : rho<1) :
    0<omegaHeavyMargin eps c0 ∧ 1≤omegaHeavyScale eps c0 rho ∧
    ∀ {Omega : Type*} [MeasurableSpace Omega] (mu : Measure Omega) [IsProbabilityMeasure mu],
    ∀ (k : ℕ) (a E0 : ℝ), 3/2≤a → eps*(a-1)≤E0 → E0≤2*eps*(a-1) →
      ∀ (N : Fin k→Omega→ℕ) (lam : Fin k→ℝ≥0),
      (∀i,MeasurePreserving (N i) mu (poissonMeasure (lam i))) →
      (∀i,omegaHeavyScale eps c0 rho*a≤(lam i:ℝ)) →
      1-rho≤mu.real {w |
        (Real.exp (-(2*eps*(a-1)))+omegaHeavyMargin eps c0*Real.exp (-(2*eps*(a-1))))*
          ∑i,(lam i:ℝ)^a≤Real.exp (-c0*E0)*∑i,analyticCount a (N i w) ∧
        Real.exp (-c0*E0)*(∑i,analyticCount a (N i w))≤
          (1-omegaHeavyMargin eps c0)*∑i,(lam i:ℝ)^a} := by
  obtain ⟨_hd,_hdc,_hd1,ht,ht1,_htbound,hc⟩ := omegaHeavyFixed_basic_bounds heps hc0 hc01
  have hB := (high_mean_gamma_concentration_explicit (μ:=Measure.dirac ()) ht ht1 hrho hrho1).1
  refine ⟨hc,hB,?_⟩
  intro Omega instOmega mu instMu k a E0 ha hElow hEhigh N lam hLaw hmeans
  have h := (high_mean_gamma_concentration_explicit (μ:=mu) ht ht1 hrho hrho1).2
    k a ha N lam hLaw hmeans
  have hscalar := omega_heavy_fixed_scalar_margins heps hc0 hc01 ha hElow hEhigh
  have hS : 0≤∑i,(lam i:ℝ)^a := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (lam i).coe_nonneg _)
  apply h.trans
  refine measureReal_mono ?_ (by finiteness)
  intro w hw
  dsimp only at hw ⊢ hscalar
  constructor
  · have hleft := mul_le_mul_of_nonneg_right hscalar.1 hS
    have hmain := mul_le_mul_of_nonneg_left hw.1 (Real.exp_pos (-c0*E0)).le
    nlinarith only [hleft,hmain]
  · have hright := mul_le_mul_of_nonneg_right hscalar.2 hS
    have hmain := mul_le_mul_of_nonneg_left hw.2 (Real.exp_pos (-c0*E0)).le
    nlinarith only [hright,hmain]

/-- The exact fixed-deficit event for a deterministic heavy subset. -/
def omegaHeavyFixedSubsetEvent {Omega : Type*} {k : ℕ} (N : Fin k→Omega→ℕ)
    (lam : Fin k→ℝ≥0) (a E0 eps c0 c : ℝ) (S : Finset (Fin k)) : Set Omega :=
  {w | (Real.exp (-(2*eps*(a-1)))+c*Real.exp (-(2*eps*(a-1))))*
      ∑i∈S,(lam i:ℝ)^a≤Real.exp (-c0*E0)*∑i∈S,analyticCount a (N i w) ∧
    Real.exp (-c0*E0)*(∑i∈S,analyticCount a (N i w))≤(1-c)*∑i∈S,(lam i:ℝ)^a}

theorem omega_heavy_fixed_subset_concentration {eps c0 rho : ℝ}
    (heps : 0<eps) (hc0 : 0<c0) (hc01 : c0<1) (hrho : 0<rho) (hrho1 : rho<1) :
    ∀ {Omega : Type*} [MeasurableSpace Omega] (mu : Measure Omega) [IsProbabilityMeasure mu],
    ∀ (k : ℕ) (a E0 : ℝ), 3/2≤a → eps*(a-1)≤E0 → E0≤2*eps*(a-1) →
      ∀ (N : Fin k→Omega→ℕ) (lam : Fin k→ℝ≥0),
      (∀i,MeasurePreserving (N i) mu (poissonMeasure (lam i))) →
      ∀ S : Finset (Fin k), (∀i∈S,omegaHeavyScale eps c0 rho*a≤(lam i:ℝ)) →
      1-rho≤mu.real (omegaHeavyFixedSubsetEvent N lam a E0 eps c0 (omegaHeavyMargin eps c0) S) := by
  intro Omega instOmega mu instMu k a E0 ha hElow hEhigh N lam hLaw S hmean
  let e := (Fintype.equivFin S).symm
  have hh := (omega_heavy_fixed_concentration_uniform heps hc0 hc01 hrho hrho1).2.2 mu
    (Fintype.card S) a E0 ha hElow hEhigh (fun j => N (e j)) (fun j => lam (e j))
    (fun j => hLaw (e j)) (fun j => hmean (e j) (e j).property)
  have hsum (f : Fin k→ℝ) : (∑j:Fin (Fintype.card S),f (e j))=∑i∈S,f i := by
    have he := e.sum_comp (fun i:S => f i)
    simpa only [Finset.sum_coe_sort] using he
  dsimp only at hh
  have hsum1 := hsum (fun i => (lam i:ℝ)^a)
  have hsum2 (w : Omega) := hsum (fun i => analyticCount a (N i w))
  simp only [hsum1,hsum2] at hh
  exact hh

end Renyi
