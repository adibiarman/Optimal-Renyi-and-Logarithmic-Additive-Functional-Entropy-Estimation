import Renyi.FingerprintDistance
import Renyi.UniformInjection
import Renyi.PaddedSimplex
import Renyi.PoissonToIID
import Renyi.PMFExpectation
import Renyi.MixtureTesting

/-!
# Recovering iid ordered records from Poisson count histograms

The ordering kernel below is uniform on the finite fiber of the histogram map.
Its definition does not depend on the unknown sampling probabilities.
-/
noncomputable section
open scoped BigOperators ENNReal NNReal
open MeasureTheory ProbabilityTheory

namespace Renyi

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Ordered records realizing a prescribed count vector. -/
def histogramFiber (n : ℕ) (c : ι → ℕ) : Finset (Fin n → ι) :=
  Finset.univ.filter (fun x => markHistogram x = c)

@[simp] theorem mem_histogramFiber (n : ℕ) (c : ι → ℕ) (x : Fin n → ι) :
    x ∈ histogramFiber n c ↔ markHistogram x = c := by
  simp [histogramFiber]

/-- The multinomial coefficient counts the ordered records in a histogram fiber. -/
theorem histogramFiber_card (n : ℕ) (c : ι → ℕ) (hc : ∑ i, c i = n) :
    (histogramFiber n c).card = Nat.multinomial Finset.univ c := by
  have h := iid_histogram_mass (fun _ : ι => (1 : ℝ≥0∞)) n c
  have heq : ((histogramFiber n c).card : ℝ≥0∞) = Nat.multinomial Finset.univ c := by
    simpa [histogramFiber, hc] using h
  exact_mod_cast heq

/-- A compatible histogram always has at least one ordered realization. -/
theorem histogramFiber_nonempty (n : ℕ) (c : ι → ℕ) (hc : ∑ i, c i = n) :
    (histogramFiber n c).Nonempty := by
  apply Finset.card_pos.mp
  rw [histogramFiber_card n c hc]
  exact Nat.multinomial_pos _ _

/-- The total of an actual histogram is the sample length. -/
theorem sum_markHistogram {n : ℕ} (x : Fin n → ι) : ∑ i, markHistogram x i = n := by
  classical
  simp only [markHistogram]
  rw [Finset.sum_comm]
  simp

/-- Products of sampling probabilities depend only on the histogram. -/
theorem product_eq_histogram_power {R : Type*} [CommMonoid R]
    (p : ι → R) {n : ℕ} (x : Fin n → ι) :
    (∏ k, p (x k)) = ∏ i, p i ^ markHistogram x i := by
  classical
  have h := Finset.prod_fiberwise' (Finset.univ : Finset (Fin n)) x p
  simpa [markHistogram] using h.symm

/-- Uniformly order a prescribed histogram. Incompatible histograms use a fixed
record; they have probability zero under the multinomial input law. -/
def uniformHistogramPMF [Inhabited ι] (n : ℕ) (c : ι → ℕ) : PMF (Fin n → ι) :=
  if h : ∑ i, c i = n then
    PMF.uniformOfFinset (histogramFiber n c) (histogramFiber_nonempty n c h)
  else PMF.pure (fun _ => default)

/-- On every compatible count vector the kernel is exactly uniform over its fiber. -/
theorem uniformHistogramPMF_apply [Inhabited ι] (n : ℕ) (c : ι → ℕ)
    (hc : ∑ i, c i = n) (x : Fin n → ι) :
    uniformHistogramPMF n c x =
      if markHistogram x = c then (Nat.multinomial Finset.univ c : ℝ≥0∞)⁻¹ else 0 := by
  simp [uniformHistogramPMF, hc, PMF.uniformOfFinset_apply, histogramFiber_card n c hc]

/-- A multinomial count law followed by the common uniform ordering kernel is
exactly the ordered iid law. This verifies the conditional-on-length iid step. -/
theorem multinomial_uniform_ordering [Inhabited ι] (p : ι → ℝ≥0)
    (hp : ∑ i, p i = 1) (n : ℕ) :
    (multinomialPMF p hp n).bind (uniformHistogramPMF n) = iidMarkPMF p hp n := by
  classical
  ext x
  rw [PMF.bind_apply, tsum_eq_single (markHistogram x)]
  · rw [multinomialPMF_apply, if_pos (sum_markHistogram x),
      uniformHistogramPMF_apply n (markHistogram x) (sum_markHistogram x), if_pos rfl,
      iidMarkPMF_apply, product_eq_histogram_power (fun i => (p i : ℝ≥0∞)) x]
    unfold multinomialMass
    have hnonzero : (Nat.multinomial Finset.univ (markHistogram x) : ℝ≥0∞) ≠ 0 := by
      exact_mod_cast ne_of_gt (Nat.multinomial_pos Finset.univ (markHistogram x))
    rw [mul_right_comm, ENNReal.mul_inv_cancel hnonzero (ENNReal.natCast_ne_top _), one_mul]
  · intro c hc
    by_cases htotal : ∑ i, c i = n
    · rw [uniformHistogramPMF_apply n c htotal, if_neg (Ne.symm hc), mul_zero]
    · rw [multinomialPMF_apply, if_neg htotal, zero_mul]

/-- The uniform ordering kernel, with the record length determined by the counts.
It is defined for empty alphabets as well, where the record is necessarily empty. -/
def randomOrderPMF (c : ι → ℕ) : PMF (PoissonMarkedSample ι) :=
  (PMF.uniformOfFinset (histogramFiber (∑ i, c i) c)
    (histogramFiber_nonempty _ _ rfl)).map (fun x => ⟨∑ i, c i, x⟩)

/-- The ordering kernel has constant mass on each compatible histogram fiber. -/
theorem randomOrderPMF_apply (c : ι → ℕ) (x : PoissonMarkedSample ι) :
    randomOrderPMF c x = if markHistogram x.2 = c then
      (Nat.multinomial Finset.univ c : ℝ≥0∞)⁻¹ else 0 := by
  classical
  by_cases hx : markHistogram x.2 = c
  · rw [if_pos hx]
    rcases x with ⟨n, x⟩
    have htotal : ∑ i, c i = n := by rw [← hx, sum_markHistogram]
    subst n
    unfold randomOrderPMF
    rw [PMF.map_apply, tsum_eq_single x]
    · simp only [PMF.uniformOfFinset_apply, mem_histogramFiber, hx,
        histogramFiber_card _ _ rfl, ite_true]
    · intro y hy
      have hne : (⟨∑ i, c i, x⟩ : PoissonMarkedSample ι) ≠ ⟨∑ i, c i, y⟩ := by
        intro h
        exact hy (sigma_mk_injective h).symm
      simp only [hne, if_false]
  · rw [if_neg hx, randomOrderPMF, PMF.map_apply]
    apply ENNReal.tsum_eq_zero.mpr
    intro y
    by_cases hy : x = ⟨∑ i, c i, y⟩
    · have hhist : markHistogram y ≠ c := by
        intro h
        apply hx
        rw [hy]
        exact h
      simp [hy, PMF.uniformOfFinset_apply, hhist]
    · simp [hy]

/-- Pointwise Poisson/multinomial factorization in probability-mass form. -/
theorem finitePoissonPMF_factorization (b : ℝ≥0) (p : ι → ℝ≥0)
    (hp : ∑ i, p i = 1) (c : ι → ℕ) :
    finitePoissonPMF (fun i => b * p i) c =
      poissonPMF b (∑ i, c i) * multinomialMass p c := by
  rw [← poisson_multinomial_split b p hp, PMF.bind_apply,
    tsum_eq_single (∑ i, c i)]
  · simp
  · intro n hn
    simp [Ne.symm hn]

omit [DecidableEq ι] in
/-- Exact probability of a finite-alphabet Poissonized ordered sample. -/
theorem finite_marked_sample_apply (b : ℝ≥0) (p : ι → ℝ≥0)
    (hp : ∑ i, p i = 1) (x : PoissonMarkedSample ι) :
    poissonMarkedSamplePMF b p hp x = poissonPMF b x.1 * ∏ k, (p (x.2 k) : ℝ≥0∞) := by
  classical
  rcases x with ⟨n, x⟩
  rw [poissonMarkedSamplePMF, PMF.bind_apply, tsum_eq_single n]
  · congr 1
    rw [PMF.map_apply, tsum_eq_single x]
    · simp [iidMarkPMF_apply]
    · intro y hy
      have hne : (⟨n, x⟩ : PoissonMarkedSample ι) ≠ ⟨n, y⟩ := by
        intro h
        exact hy (sigma_mk_injective h).symm
      simp [hne]
  · intro m hm
    have hne (y : Fin m → ι) : (⟨n, x⟩ : PoissonMarkedSample ι) ≠ ⟨m, y⟩ := by
      intro h
      exact hm (congrArg Sigma.fst h).symm
    simp only [PMF.map_apply, hne, if_false, tsum_zero, mul_zero]

/-- Independently sampled Poisson counts, uniformly ordered by a kernel that
knows only the count vector, recover exactly a Poisson number of iid labels. -/
theorem poisson_counts_uniform_ordering (b : ℝ≥0) (p : ι → ℝ≥0)
    (hp : ∑ i, p i = 1) :
    (finitePoissonPMF (fun i => b * p i)).bind randomOrderPMF =
      poissonMarkedSamplePMF b p hp := by
  classical
  ext x
  rw [PMF.bind_apply, tsum_eq_single (markHistogram x.2)]
  · rw [randomOrderPMF_apply, if_pos rfl, finitePoissonPMF_factorization b p hp,
      sum_markHistogram, finite_marked_sample_apply,
      product_eq_histogram_power (fun i => (p i : ℝ≥0∞)) x.2]
    unfold multinomialMass
    have hnonzero : (Nat.multinomial Finset.univ (markHistogram x.2) : ℝ≥0∞) ≠ 0 := by
      exact_mod_cast ne_of_gt (Nat.multinomial_pos Finset.univ (markHistogram x.2))
    calc
      _ = poissonPMF b x.1 *
          ((Nat.multinomial Finset.univ (markHistogram x.2) : ℝ≥0∞) *
            (Nat.multinomial Finset.univ (markHistogram x.2) : ℝ≥0∞)⁻¹) *
          ∏ i, (p i : ℝ≥0∞) ^ markHistogram x.2 i := by ring
      _ = _ := by rw [ENNReal.mul_inv_cancel hnonzero (ENNReal.natCast_ne_top _), mul_one]
  · intro c hc
    rw [randomOrderPMF_apply, if_neg (Ne.symm hc), mul_zero]


/-- Normalize arbitrary nonnegative weights with positive total mass. -/
def normalizedWeights (w : ι → ℝ≥0) (_hw : 0 < ∑ i, w i) : ι → ℝ≥0 :=
  fun i => w i / ∑ j, w j

omit [DecidableEq ι] in
theorem normalizedWeights_sum (w : ι → ℝ≥0) (hw : 0 < ∑ i, w i) :
    ∑ i, normalizedWeights w hw i = 1 := by
  unfold normalizedWeights
  rw [← Finset.sum_div, div_self (ne_of_gt hw)]

/-- For arbitrary fixed weights, the common ordering kernel gives a Poisson
number of iid observations from the normalized weights. -/
theorem weighted_poisson_counts_uniform_ordering (θ : ℝ≥0) (w : ι → ℝ≥0)
    (hw : 0 < ∑ i, w i) :
    (finitePoissonPMF (fun i => θ * w i)).bind randomOrderPMF =
      poissonMarkedSamplePMF (θ * ∑ i, w i) (normalizedWeights w hw)
        (normalizedWeights_sum w hw) := by
  have hrate : (fun i => θ * w i) =
      fun i => (θ * ∑ j, w j) * normalizedWeights w hw i := by
    funext i
    unfold normalizedWeights
    field_simp
  rw [hrate]
  exact poisson_counts_uniform_ordering _ _ _

/-- Push a count vector forward under an injection, padding unobserved labels by zero. -/
def pushCounts {κ : Type*} (e : ι ↪ κ) (c : ι → ℕ) (j : κ) : ℕ := by
  classical
  exact ∑ i, if e i = j then c i else 0

@[simp] theorem pushCounts_at {κ : Type*} (e : ι ↪ κ) (c : ι → ℕ) (i : ι) :
    pushCounts e c (e i) = c i := by
  classical
  simp [pushCounts, e.injective.eq_iff]

omit [DecidableEq ι] in
theorem pushCounts_off {κ : Type*} (e : ι ↪ κ) (c : ι → ℕ) {j : κ}
    (hj : ¬ ∃ i, e i = j) : pushCounts e c j = 0 := by
  classical
  simp only [pushCounts]
  apply Finset.sum_eq_zero
  intro i _
  exact if_neg (fun h => hj ⟨i, h⟩)

omit [DecidableEq ι] in
theorem pushCounts_sum {κ : Type*} [Fintype κ] (e : ι ↪ κ) (c : ι → ℕ) :
    ∑ j, pushCounts e c j = ∑ i, c i := by
  classical
  unfold pushCounts
  rw [Finset.sum_comm]
  simp

omit [DecidableEq ι] in
theorem pushCounts_comp {κ ν : Type*} [Fintype κ]
    (e : ι ↪ κ) (f : κ ↪ ν) (c : ι → ℕ) :
    pushCounts f (pushCounts e c) = pushCounts (e.trans f) c := by
  classical
  funext j
  by_cases hj : ∃ a, f a = j
  · obtain ⟨a, rfl⟩ := hj
    rw [pushCounts_at]
    simp [pushCounts, Function.Embedding.trans_apply, f.injective.eq_iff]
  · rw [pushCounts_off f _ hj]
    symm
    apply pushCounts_off
    rintro ⟨i, hi⟩
    exact hj ⟨e i, hi⟩

/-- Deleting zero-count coordinates and subsequently padding them recovers the
original vector exactly. This hypothesis only describes deterministic support. -/
theorem pushCounts_restrict {κ : Type*} [Fintype κ] (s : ι ↪ κ) (c : κ → ℕ)
    (hs : ∀ j, c j ≠ 0 → ∃ i, s i = j) :
    pushCounts s (fun i => c (s i)) = c := by
  funext j
  by_cases hj : ∃ i, s i = j
  · obtain ⟨i, rfl⟩ := hj
    exact pushCounts_at _ _ _
  · rw [pushCounts_off s _ hj]
    exact (not_not.mp (fun h => hj (hs j h))).symm

/-- A uniform labeling followed by any kernel depending on the labeled counts
can be computed using only the observed nonzero coordinates. -/
theorem uniform_label_restriction {r Q k : ℕ} {Y : Type*}
    (hQk : Q ≤ k) (s : Fin r ↪ Fin Q) (c : Fin Q → ℕ)
    (hs : ∀ j, c j ≠ 0 → ∃ i, s i = j)
    (K : (Fin k → ℕ) → PMF Y) :
    (uniformInjection Q k hQk).bind (fun e => K (pushCounts e c)) =
      (uniformInjection r k
        ((show r ≤ Q from by simpa using Fintype.card_le_of_embedding s).trans hQk)).bind
        (fun e => K (pushCounts e (fun i => c (s i)))) := by
  rw [← uniformInjection_restriction hQk s, PMF.bind_map]
  congr 1
  funext e
  congr 1
  rw [← pushCounts_comp, pushCounts_restrict s c hs]


/-- Push a finite probability vector forward along a label map. -/
def pushProbability {κ : Type*} (f : ι → κ) (p : ι → ℝ≥0) (j : κ) : ℝ≥0 := by
  classical
  exact ∑ i, if f i = j then p i else 0

omit [DecidableEq ι] in
theorem pushProbability_sum {κ : Type*} [Fintype κ] (f : ι → κ)
    (p : ι → ℝ≥0) (hp : ∑ i, p i = 1) : ∑ j, pushProbability f p j = 1 := by
  classical
  unfold pushProbability
  rw [Finset.sum_comm]
  simpa using hp

omit [DecidableEq ι] in
/-- Relabeling each draw pushes forward the finite iid law. -/
theorem iidMarkPMF_map_finite {κ : Type*} [Fintype κ]
    (p : ι → ℝ≥0) (hp : ∑ i, p i = 1) (f : ι → κ) (n : ℕ) :
    (iidMarkPMF p hp n).map (fun x k => f (x k)) =
      iidMarkPMF (pushProbability f p) (pushProbability_sum f p hp) n := by
  classical
  letI : MeasurableSpace ι := ⊤
  letI : MeasurableSpace κ := ⊤
  let q : PMF ι := PMF.ofFintype (fun i => (p i : ℝ≥0∞)) (by
    rw [← ENNReal.coe_finset_sum, hp]; rfl)
  have hq (i : ι) : q i = (p i : ℝ≥0∞) := rfl
  have hmap (j : κ) : (q.map f) j = (pushProbability f p j : ℝ≥0∞) := by
    rw [PMF.map_apply, tsum_fintype]
    unfold pushProbability
    rw [ENNReal.coe_finset_sum]
    apply Finset.sum_congr rfl
    intro i _
    by_cases hi : f i = j
    · simp [hi, hq]
    · simp [hi, Ne.symm hi]
  have hiid : iidCountablePMF q n = iidMarkPMF p hp n := by
    ext x
    simp only [iidCountablePMF_apply, iidMarkPMF_apply, hq]
  have hiid' : iidCountablePMF (q.map f) n =
      iidMarkPMF (pushProbability f p) (pushProbability_sum f p hp) n := by
    ext x
    simp only [iidCountablePMF_apply, iidMarkPMF_apply, hmap]
  rw [← hiid, iidCountablePMF_map, hiid']

omit [DecidableEq ι] in
/-- Relabeling a Poisson-length iid record preserves its sampling law. -/
theorem poissonMarkedSample_map_finite {κ : Type*} [Fintype κ]
    (b : ℝ≥0) (p : ι → ℝ≥0) (hp : ∑ i, p i = 1) (f : ι → κ) :
    (poissonMarkedSamplePMF b p hp).map (mapPoissonMarks f) =
      poissonMarkedSamplePMF b (pushProbability f p) (pushProbability_sum f p hp) := by
  unfold poissonMarkedSamplePMF
  rw [PMF.map_bind]
  congr 1
  funext n
  rw [PMF.map_comp, ← iidMarkPMF_map_finite p hp f n, PMF.map_comp]
  rfl

/-- Relabeling a record pushes its count vector forward. -/
theorem histogram_map_embedding {κ : Type*} [Fintype κ] [DecidableEq κ]
    (e : ι ↪ κ) {n : ℕ} (x : Fin n → ι) :
    markHistogram (fun k => e (x k)) = pushCounts e (markHistogram x) := by
  classical
  funext j
  unfold markHistogram pushCounts
  have hif (i : ι) : (if e i = j then ∑ k, if x k = i then 1 else 0 else 0) =
      ∑ k, if e i = j then (if x k = i then 1 else 0) else 0 := by
    split_ifs <;> simp
  simp_rw [hif]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro k _
  have hterm (i : ι) : (if e i = j then (if x k = i then 1 else 0) else 0) =
      if i = x k then (if e (x k) = j then 1 else 0) else 0 := by
    by_cases hi : i = x k
    · subst i; simp
    · simp [hi, Ne.symm hi]
  simp only [hterm, Finset.sum_ite_eq', Finset.mem_univ, ite_true]

/-- Padding a finite independent Poisson count vector under an injection gives
independent Poisson counts at the pushed-forward probabilities. -/
theorem finitePoissonPMF_map_injection {κ : Type*} [Fintype κ] [DecidableEq κ]
    (b : ℝ≥0) (p : ι → ℝ≥0) (hp : ∑ i, p i = 1) (e : ι ↪ κ) :
    (finitePoissonPMF (fun i => b * p i)).map (pushCounts e) =
      finitePoissonPMF (fun j => b * pushProbability e p j) := by
  rw [← poissonMarkedSample_histogram b p hp, PMF.map_comp]
  have hmap : (fun x : PoissonMarkedSample ι => pushCounts e (markHistogram x.2)) =
      (fun x : PoissonMarkedSample κ => markHistogram x.2) ∘ mapPoissonMarks e := by
    funext x
    exact (histogram_map_embedding e x.2).symm
  change (poissonMarkedSamplePMF b p hp).map
    (fun x => pushCounts e (markHistogram x.2)) = _
  rw [hmap, ← PMF.map_comp, poissonMarkedSample_map_finite,
    poissonMarkedSample_histogram]


/-- Keep the requested prefix when enough observations are available. -/
def prefixOr {k : ℕ} (n : ℕ) (fallback : Sample k n)
    (x : PoissonMarkedSample (Fin k)) : Sample k n :=
  if h : n ≤ x.1 then fun i => x.2 (Fin.castLE h i) else fallback

/-- The actual prefix kernel yields iid observations on every available length.
The only exceptional branch is the observable event that the length is too small. -/
theorem poisson_prefix_law {k : ℕ} (b : ℝ≥0) (p : Fin k → ℝ≥0)
    (hp : ∑ i, p i = 1) (n : ℕ) (fallback : Sample k n) :
    (poissonMarkedSamplePMF b p hp).map (prefixOr n fallback) =
      (poissonPMF b).bind (fun q =>
        if n ≤ q then iidMarkPMF p hp n else PMF.pure fallback) := by
  unfold poissonMarkedSamplePMF
  rw [PMF.map_bind]
  congr 1
  funext q
  rw [PMF.map_comp]
  by_cases hq : n ≤ q
  · simp only [if_pos hq]
    have hf : prefixOr n fallback ∘ (fun x : Fin q → Fin k =>
        (⟨q, x⟩ : PoissonMarkedSample (Fin k))) =
        fun x i => x (Fin.castLE hq i) := by
      funext x i
      simp only [Function.comp_apply, prefixOr, dif_pos hq]
    rw [hf]
    exact iidMarkPMF_prefix p hp hq
  · simp only [if_neg hq]
    have hf : prefixOr n fallback ∘ (fun x : Fin q → Fin k =>
        (⟨q, x⟩ : PoissonMarkedSample (Fin k))) =
        Function.const (Fin q → Fin k) fallback := by
      funext x
      simp only [Function.comp_apply, prefixOr, dif_neg hq, Function.const_apply]
    rw [hf, PMF.map_const]

/-- The precise upper Poisson tail used for the support-overflow event. -/
theorem poisson_support_overflow (b : ℝ≥0) (k : ℕ)
    (hk : 2 * (b : ℝ) ≤ k) :
    (poissonPMF b).toMeasure.real {q : ℕ | k < q} ≤
      (Real.exp 1 / 4) ^ (b : ℝ) := by
  have ht : 0 ≤ Real.log (2 : ℝ) := by positivity
  apply (poisson_tail_exponential b k ht).trans
  rw [Real.rpow_def_of_pos (by positivity : (0 : ℝ) < Real.exp 1 / 4)]
  apply Real.exp_le_exp.mpr
  rw [Real.exp_log (by norm_num : (0 : ℝ) < 2),
    Real.log_div (Real.exp_ne_zero _) (by norm_num : (4 : ℝ) ≠ 0), Real.log_exp]
  have hlog : Real.log (4 : ℝ) = 2 * Real.log 2 := by
    convert Real.log_pow (2 : ℝ) 2 using 1; norm_num
  rw [hlog]
  have h := mul_le_mul_of_nonneg_left hk ht
  nlinarith

/-- The probability that a Poisson record is shorter than a prescribed prefix. -/
theorem poisson_prefix_shortfall (lam : ℝ≥0) (n : ℕ)
    (hn : (n : ℝ) ≤ (lam : ℝ) / 2) :
    (poissonPMF lam).toMeasure.real {q : ℕ | q < n} ≤ Real.exp (-(lam : ℝ) / 8) := by
  classical
  apply le_trans _ (poissonLowerMass_half lam hn)
  rw [← (pmf_event_real_hasSum (poissonPMF lam) {q : ℕ | q < n}).tsum_eq]
  unfold poissonLowerMass
  apply (pmf_event_real_hasSum (poissonPMF lam) {q : ℕ | q < n}).summable.tsum_le_tsum
    _ (poissonLowerMass_summable lam n)
  intro q
  by_cases hq : q < n
  · have hqr : (q : ℝ) ≤ n := by exact_mod_cast hq.le
    simp only [Set.indicator_of_mem (show q ∈ {q : ℕ | q < n} from hq),
      mul_one, if_pos hqr]
    change (ENNReal.ofReal (poissonPMFReal lam q)).toReal ≤ poissonPMFReal lam q
    rw [ENNReal.toReal_ofReal poissonPMFReal_nonneg]
  · simp only [Set.indicator_of_notMem (show q ∉ {q : ℕ | q < n} from hq), mul_zero]
    split_ifs
    · exact poissonPMFReal_nonneg
    · exact le_rfl

/-- On the manuscript's normalization event the requested iid prefix is available
except with the stated `exp(-θ b / 16)` probability. -/
theorem normalized_poisson_availability (theta b S : ℝ≥0) (n : ℕ)
    (hS : (3 : ℝ) / 4 ≤ S) (hn : (n : ℝ) ≤ (theta : ℝ) * b / 4) :
    (poissonPMF (theta * b * S)).toMeasure.real {q : ℕ | q < n} ≤
      Real.exp (-(theta : ℝ) * b / 16) := by
  have htb : 0 ≤ (theta : ℝ) * b := mul_nonneg theta.coe_nonneg b.coe_nonneg
  have hmass : (theta : ℝ) * b * (3 / 4) ≤ (theta : ℝ) * b * S :=
    mul_le_mul_of_nonneg_left hS htb
  apply (poisson_prefix_shortfall (theta * b * S) n (by
    simp only [NNReal.coe_mul]
    nlinarith)).trans
  apply Real.exp_le_exp.mpr
  simp only [NNReal.coe_mul]
  nlinarith


/-- Pushing normalized weights to distinct labels gives the actual padded simplex
used in the statistical model. -/
theorem push_normalizedWeights_simplex {Q k : ℕ} (e : Fin Q ↪ Fin k)
    (w : Fin Q → ℝ≥0) (hw : 0 < ∑ i, w i) :
    pushProbability e (normalizedWeights w hw) =
      simplexNN (paddedSimplex e (fun i => (w i : ℝ)) (fun i => (w i).coe_nonneg)
        (by
          have h : (0 : ℝ) < ((∑ i, w i : ℝ≥0) : ℝ) := by exact_mod_cast hw
          simpa only [NNReal.coe_sum] using h)) := by
  classical
  funext j
  apply NNReal.coe_injective
  simp only [pushProbability, normalizedWeights, simplexNN, paddedSimplex, paddedWeight,
    NNReal.coe_sum]
  apply Finset.sum_congr rfl
  intro i _
  split_ifs <;> simp

/-- Conditional on any fixed nonnegative weight vector, independent Poisson
counts followed by labeling and the common ordering kernel produce the actual
Poissonized iid law of its padded normalized simplex. -/
theorem labeled_weighted_counts_ordering {Q k : ℕ} (e : Fin Q ↪ Fin k)
    (theta : ℝ≥0) (w : Fin Q → ℝ≥0) (hw : 0 < ∑ i, w i) :
    (finitePoissonPMF (fun i => theta * w i)).bind
      (fun c => randomOrderPMF (pushCounts e c)) =
    poissonMarkedSamplePMF (theta * ∑ i, w i)
      (simplexNN (paddedSimplex e (fun i => (w i : ℝ)) (fun i => (w i).coe_nonneg)
        (by
          have h : (0 : ℝ) < ((∑ i, w i : ℝ≥0) : ℝ) := by exact_mod_cast hw
          simpa only [NNReal.coe_sum] using h))) (simplexNN_sum _) := by
  have hrate : (fun i => theta * w i) =
      fun i => (theta * ∑ j, w j) * normalizedWeights w hw i := by
    funext i
    unfold normalizedWeights
    field_simp
  change (finitePoissonPMF (fun i => theta * w i)).bind
    (randomOrderPMF ∘ pushCounts e) = _
  rw [← PMF.bind_map, hrate, finitePoissonPMF_map_injection
    (theta * ∑ i, w i) (normalizedWeights w hw) (normalizedWeights_sum w hw) e,
    poisson_counts_uniform_ordering _ _ (pushProbability_sum e _ (normalizedWeights_sum w hw))]
  simp only [push_normalizedWeights_simplex e w hw]

/-- The kernel used after assigning labels to counts: uniformly order all
observations, then retain the prescribed prefix if it is available. -/
def orderedCountPrefix {k : ℕ} (n : ℕ) (fallback : Sample k n)
    (c : Fin k → ℕ) : PMF (Sample k n) :=
  (randomOrderPMF c).map (prefixOr n fallback)

/-- Complete fixed-weight conditional sampling law, including the explicit
unavailable-prefix branch. -/
theorem labeled_weighted_counts_prefix {Q k : ℕ} (e : Fin Q ↪ Fin k)
    (theta : ℝ≥0) (w : Fin Q → ℝ≥0) (hw : 0 < ∑ i, w i)
    (n : ℕ) (fallback : Sample k n) :
    (finitePoissonPMF (fun i => theta * w i)).bind
      (fun c => orderedCountPrefix n fallback (pushCounts e c)) =
    (poissonPMF (theta * ∑ i, w i)).bind (fun q => if n ≤ q then
      iidMarkPMF
        (simplexNN (paddedSimplex e (fun i => (w i : ℝ)) (fun i => (w i).coe_nonneg)
          (by
          have h : (0 : ℝ) < ((∑ i, w i : ℝ≥0) : ℝ) := by exact_mod_cast hw
          simpa only [NNReal.coe_sum] using h))) (simplexNN_sum _) n else PMF.pure fallback) := by
  unfold orderedCountPrefix
  rw [← PMF.map_bind, labeled_weighted_counts_ordering e theta w hw, poisson_prefix_law]

/-- The observable sample-reconstruction kernel. The input contains only the
positive observed counts, encoded by their predecessors; it never uses latent
atom weights or the unobserved zero-count symbols. -/
def observedSampleKernel {k : ℕ} (n : ℕ) (fallback : Sample k n)
    (x : PoissonMarkedSample ℕ) : PMF (Sample k n) :=
  if hx : x.1 ≤ k then
    (uniformInjection x.1 k hx).bind
      (fun e => orderedCountPrefix n fallback (pushCounts e (fun i => x.2 i + 1)))
  else PMF.pure fallback

/-- Full-label construction used solely to analyze the observable kernel. -/
def fullSampleKernel {k : ℕ} (n : ℕ) (fallback : Sample k n)
    (x : PoissonMarkedSample ℕ) : PMF (Sample k n) :=
  if hx : x.1 ≤ k then
    (uniformInjection x.1 k hx).bind
      (fun e => orderedCountPrefix n fallback (pushCounts e x.2))
  else PMF.pure fallback

/-- On the no-overflow event, deleting all unobserved symbols has no effect on
reconstructed observations. The equality is valid for every enumeration of the
retained coordinates, so it also covers randomized retained orderings. -/
theorem observed_full_sample_kernel_eq {k : ℕ} (n : ℕ) (fallback : Sample k n)
    (x y : PoissonMarkedSample ℕ) (s : Fin y.1 ↪ Fin x.1)
    (hxy : ∀ i, x.2 (s i) = y.2 i + 1)
    (hs : ∀ j, x.2 j ≠ 0 → ∃ i, s i = j) (hxk : x.1 ≤ k) :
    fullSampleKernel n fallback x = observedSampleKernel n fallback y := by
  have hyk : y.1 ≤ k :=
    (show y.1 ≤ x.1 from by simpa using Fintype.card_le_of_embedding s).trans hxk
  simp only [fullSampleKernel, observedSampleKernel, dif_pos hxk, dif_pos hyk]
  rw [uniform_label_restriction hxk s x.2 hs]
  congr 1
  funext e
  congr 2
  funext i
  exact hxy i


/-- A point mass has the stated deterministic test expectation. -/
@[simp] theorem pmfExpectation_pure {Y : Type*} (y : Y) (t : Y → ℝ) :
    pmfExpectation (PMF.pure y) t = t y := by
  classical
  simp only [pmfExpectation, PMF.pure_apply]
  simp only [apply_ite (fun x : ℝ≥0∞ => x.toReal), ENNReal.toReal_one,
    ENNReal.toReal_zero, ite_mul, one_mul, zero_mul]
  rw [tsum_eq_single y]
  · simp
  · intro x hxy
    simp [hxy]

/-- Expectations commute with deterministic reported statistics. -/
theorem pmfExpectation_map {Ω Y : Type*} (p : PMF Ω) (f : Ω → Y)
    (t : Y → ℝ) (ht0 : ∀ y, 0 ≤ t y) (ht1 : ∀ y, t y ≤ 1) :
    pmfExpectation (p.map f) t = pmfExpectation p (fun x => t (f x)) := by
  change pmfExpectation (p.bind (PMF.pure ∘ f)) t = _
  rw [pmfExpectation_bind p _ t ht0 ht1]
  simp only [Function.comp_apply, pmfExpectation_pure]

/-- Missing observations cost at most the Poisson shortfall probability for
any bounded randomized decision made from the reconstructed prefix. -/
theorem poisson_prefix_expectation_le {k : ℕ} (b : ℝ≥0) (p : Fin k → ℝ≥0)
    (hp : ∑ i, p i = 1) (n : ℕ) (fallback : Sample k n)
    (t : Sample k n → ℝ) (ht0 : ∀ x, 0 ≤ t x) (ht1 : ∀ x, t x ≤ 1) :
    pmfExpectation ((poissonMarkedSamplePMF b p hp).map (prefixOr n fallback)) t ≤
      pmfExpectation (iidMarkPMF p hp n) t +
        (poissonPMF b).toMeasure.real {q : ℕ | q < n} := by
  rw [poisson_prefix_law, pmfExpectation_bind _ _ t ht0 ht1]
  apply pmfExpectation_le_of_good (poissonPMF b) _ {q : ℕ | q < n}
    (pmfExpectation_nonneg _ _ ht0)
  · intro q
    exact pmfExpectation_nonneg _ _ ht0
  · intro q
    exact pmfExpectation_le_one _ _ ht0 ht1
  · intro q hq
    have hq' : n ≤ q := Nat.le_of_not_gt hq
    simp only [if_pos hq']
    exact le_rfl

/-- Test expectation under the finite iid PMF equals the model's finite sum. -/
theorem iidMarkPMF_test_expectation {k n : ℕ} (p : Simplex k)
    (t : Sample k n → ℝ) :
    pmfExpectation (iidMarkPMF (simplexNN p) (simplexNN_sum p) n) t =
      ∑ x, iidMass p n x * t x := by
  unfold pmfExpectation
  rw [tsum_fintype]
  apply Finset.sum_congr rfl
  intro x _
  simp [iidMarkPMF_apply, ENNReal.toReal_prod, simplexNN, iidMass]

/-- The source lower-center test is correct whenever the assumed entropy
estimator succeeds, expressed for the actual iid sample PMF. -/
theorem iid_center_test_left {k n : ℕ} (p : Simplex k) (est : Estimator k n)
    (alpha eps tau c0 c1 : ℝ) (hgap : 2 * (eps + tau) < c1 - c0)
    (hcenter : |entropy p alpha - c0| ≤ tau) :
    pmfExpectation (iidMarkPMF (simplexNN p) (simplexNN_sum p) n)
      (fun x => (est x (Set.Ioi ((c0 + c1) / 2)) : ℝ)) ≤
      errorProbability p alpha eps est := by
  rw [iidMarkPMF_test_expectation]
  exact center_test_error_left p est alpha eps tau c0 c1 hgap hcenter

/-- Corresponding actual iid test error at the upper center. -/
theorem iid_center_test_right {k n : ℕ} (p : Simplex k) (est : Estimator k n)
    (alpha eps tau c0 c1 : ℝ) (hgap : 2 * (eps + tau) < c1 - c0)
    (hcenter : |entropy p alpha - c1| ≤ tau) :
    pmfExpectation (iidMarkPMF (simplexNN p) (simplexNN_sum p) n)
      (fun x => 1 - (est x (Set.Ioi ((c0 + c1) / 2)) : ℝ)) ≤
      errorProbability p alpha eps est := by
  rw [iidMarkPMF_test_expectation]
  exact center_test_error_right p est alpha eps tau c0 c1 hgap hcenter

/-- Conditional risk for the explicit labeled-count kernel, with the full
unavailable-prefix probability paid once. -/
theorem labeled_weighted_counts_test_le {Q k : ℕ} (e : Fin Q ↪ Fin k)
    (theta : ℝ≥0) (w : Fin Q → ℝ≥0) (hw : 0 < ∑ i, w i)
    (n : ℕ) (fallback : Sample k n) (t : Sample k n → ℝ)
    (ht0 : ∀ x, 0 ≤ t x) (ht1 : ∀ x, t x ≤ 1) :
    pmfExpectation ((finitePoissonPMF (fun i => theta * w i)).bind
      (fun c => orderedCountPrefix n fallback (pushCounts e c))) t ≤
      pmfExpectation
        (iidMarkPMF
          (simplexNN (paddedSimplex e (fun i => (w i : ℝ)) (fun i => (w i).coe_nonneg)
            (by
              have h : (0 : ℝ) < ((∑ i, w i : ℝ≥0) : ℝ) := by exact_mod_cast hw
              simpa only [NNReal.coe_sum] using h))) (simplexNN_sum _) n) t +
        (poissonPMF (theta * ∑ i, w i)).toMeasure.real {q : ℕ | q < n} := by
  rw [labeled_weighted_counts_prefix e theta w hw n fallback,
    ← poisson_prefix_law]
  exact poisson_prefix_expectation_le _ _ _ _ _ t ht0 ht1

end Renyi
