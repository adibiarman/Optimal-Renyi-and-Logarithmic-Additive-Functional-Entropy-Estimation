import Renyi.ActualCountProfile
import Renyi.ConditionalCountChoices

/-! Full source parameter calibration of the actual conditional count certificate. -/
set_option maxHeartbeats 2000000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- All count constants are fixed before the order, alphabet, and final sample multiplier.
The polynomial, cutoffs, root, baseline, and count degree are the actual source choices. -/
theorem actual_upper_conditional_count_variance_uniform_experiments
    {eps Ch cb lambda CL cp Bpilot Mprof cw fL f u0 eta cLbound : ℝ}
    (heps : 0 < eps) (hCh : 0 ≤ Ch) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hlambda4 : lambda ≤ 4) (hCL : 1 ≤ CL) (hcbCL : 1 ≤ cb * CL)
    (hcp : 0 < cp) (hcpDegree : 80 / cb ≤ cp) (hBpilot : 0 < Bpilot)
    (hMprof : 0 ≤ Mprof) (hcw : 0 < cw) (hfL : 0 ≤ fL) (hfL1 : fL < 1)
    (hf : 0 ≤ f) (hf1 : f ≤ 1) (hu0 : 0 < u0) (heta : 0 < eta) (hcLbound : 0 < cLbound) :
    ∃ cL C0 : ℝ, 0 < cL ∧ cL ≤ cLbound ∧ 1 ≤ C0 ∧ coupledLowCoefficientConstant ≤ C0 ∧
      ∀ db : ℝ, 0 < db → db ≤ 1 →
      ∃ D0 : ℝ, 1 ≤ D0 ∧ ∀ (k : ℕ) (alpha D : ℝ),
        0 < k → 3 / 2 ≤ alpha → 0 < fractionalPart alpha → fractionalPart alpha < 1 → D0 ≤ D →
        ∀ {Ω Ξ : Type*} [MeasurableSpace Ω] [MeasurableSpace Ξ] (μ : Measure Ω) (ν : Measure Ξ),
        ∀ (p : Simplex k) (Counts : Fin k → Ω → ℕ) (Pilot : Fin k → Ξ → ℕ) (lam : Fin k → ℝ≥0),
        (∀ i, MeasurePreserving (Counts i) μ (poissonMeasure (lam i))) →
        Pairwise (fun i j => IndepFun (Counts i) (Counts j) μ) →
        (∀ i, MeasurePreserving (Pilot i) ν
          (poissonMeasure ⟨cp * lam i, mul_nonneg hcp.le (lam i).coe_nonneg⟩)) →
        (∀ i, (lam i : ℝ) = upperSample k alpha eps D * p.mass i) →
        pilotAveragedCountVariance Counts Pilot (cp * Bpilot * alpha)
          (upperCountDegree k alpha eps CL cL)
          (actualUpperPolynomial k alpha eps Ch D cb lambda CL cL fL f Mprof cw).coeff
          (upperSample k alpha eps D) μ ν ≤
        eta * (upperActualBaseline k alpha C0 db (upperA k alpha eps Ch D cb lambda CL cL) *
            (k : ℝ) ^ (1 - alpha) +
          upperKappa alpha eps * upperU k alpha eps u0 * powerSum p alpha +
          min (alpha - 1) 1 * upperKappa alpha eps * conditionalCountBonus p.mass alpha (upperSample k alpha eps D)
            (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)) ^ 2 := by
  let Cd : ℝ := 20
  let M : ℝ := 20 / cb
  let Ct := 2 * coupledCoefficientExponentialConstant + 80
  let Cmed := coupledHighMediumConstant cp Bpilot M Cd
  have hCd : 0 ≤ Cd := by norm_num [Cd]
  have hM : 0 ≤ M := by dsimp [M]; positivity
  have hCt : 0 ≤ Ct := by have hh := coupledCoefficientExponentialConstant_pos; dsimp [Ct]; linarith
  have hCmed : 0 ≤ Cmed := by
    have hh := coupledCoefficientExponentialConstant_pos
    dsimp [Cmed, coupledHighMediumConstant]
    positivity
  obtain ⟨cLraw, hcLraw, hsmallraw⟩ := exists_count_logarithmic_degree_coefficient hCL hCmed hCt
  let cL := min cLraw cLbound
  have hcL : 0 < cL := lt_min hcLraw hcLbound
  have hfactor : 0 ≤ Cmed + Ct + 1 / (CL + 1) := by positivity
  have hsmall := (mul_le_mul_of_nonneg_right (min_le_left cLraw cLbound) hfactor).trans hsmallraw
  obtain ⟨rminus, rplus, hrminus, hrplus, hcut⟩ := upper_actual_cutoff heps hCh hcb hlambda hCL hcL
  let rhoMinus := rminus / 3
  have hrhoMinus : 0 < rhoMinus := by dsimp [rhoMinus]; positivity
  obtain ⟨R, Cbase, hR, hCbase, hRscaleBase, hRlow, hRtiny, hRmedium⟩ :=
    exists_count_reference_constants rplus rhoMinus (pilotConstant Bpilot cp) (1 / cb)
      CL Cmed Ct cb (2 * eps) hrhoMinus
  let C0 := max Cbase coupledLowCoefficientConstant
  have hC0 : 1 ≤ C0 := hCbase.trans (le_max_left _ _)
  have hRscale : R ≤ C0 * rhoMinus := hRscaleBase.trans
    (mul_le_mul_of_nonneg_right (le_max_left _ _) hrhoMinus.le)
  refine ⟨cL, C0, hcL, min_le_right _ _, hC0, le_max_right _ _, ?_⟩
  intro db hdb hdb1
  let uref := min (1 / 3 : ℝ) u0
  have huref : 0 < uref := lt_min (by norm_num) hu0
  have hustar := upperUStar_pos heps hu0
  let Dbase := rhoMinus * C0 ^ 2 * Real.exp (2 * eps)
  let Dnoise := conditionalCountRateConstant (db / 2) uref * (1 + 1 / upperUStar eps u0) ^ 2 / (eta / 4)
  let D0 := max 1 (max Dbase Dnoise)
  refine ⟨D0, le_max_left _ _, ?_⟩
  intro k alpha D hk halpha hg hg1 hD Ω Ξ instΩ instΞ μ ν p Counts Pilot lam hLaw hpair hPilot hlam
  have hD1 : 1 ≤ D := (le_max_left _ _).trans hD
  have hDpos : 0 < D := zero_lt_one.trans_le hD1
  have hDb : Dbase ≤ D := (le_max_left _ _).trans ((le_max_right _ _).trans hD)
  have hDn : Dnoise ≤ D := (le_max_right _ _).trans ((le_max_right _ _).trans hD)
  have ha1 : 1 < alpha := by linarith
  have hX := one_le_rootMultiplier (k := k) (ε := eps) ha1 hg hg1
  have hsplit : (upperOrderFloor alpha : ℝ) + fractionalPart alpha = alpha := by
    rw [fractionalPart_eq_upperOrderFloor ha1]
    ring
  have hm := upperOrderFloor_one_le ha1
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hkcard : (0 : ℝ) < Fintype.card (Fin k) := by simpa only [Fintype.card_fin] using hkR
  have hgeometry := upper_actual_count_geometry hk halpha hg hg1 heps hCh hDpos hcb hlambda hlambda4 hCL hcL hcbCL
  rcases hgeometry with ⟨ha, hab, hb, hell, hN2, _hellm, hdegree, hellL, hlocal, hnb, hH, hcountScale, hrd, hdegreeL, hdegreeH⟩
  have hN : 0 < upperDegree alpha CL cL (rootMultiplier k alpha eps) := by omega
  have hNpos : (0 : ℝ) < upperDegree alpha CL cL (rootMultiplier k alpha eps) := by exact_mod_cast hN
  have hprofile := upper_actual_count_profile_ranges (k := k) ha1 hg hg1 heps hCh hMprof hcw hfL1
  rcases hprofile with ⟨hcProfile, hA, hA1, hB, hB1, hw, hw1⟩
  have hcuts := hcut k alpha D hk ha1 hg hg1 hDpos
  have hka := upper_cutoff_scaled_upper hk ha1 hg hg1 hrplus hDpos hcuts.2
  have hbase := upper_baseline_transfer_of_cutoff halpha hg hg1 heps hu0 hC0 hdb.le hdb1
    hrhoMinus ha.le hDb (fun hwzero => upper_cutoff_zero_slack hk halpha hrminus hDpos hcuts.1 hwzero)
  have hchi : 1 / 2 ≤ min (alpha - 1) 1 := le_min (by linarith) (by norm_num)
  have ham : alpha - 1 ≤ (upperOrderFloor alpha : ℝ) := by
    have hh := Nat.lt_floor_add_one alpha
    change alpha < (upperOrderFloor alpha : ℝ) + 1 at hh
    linarith
  have hEref := source_baseline_dominates_low_count_reference ha1.le ham hC0 hrhoMinus hDpos hR hRscale hchi hdb
  have hurefLower := upperU_root_width_lower halpha hg hg1 hu0 (k := k) (eps := eps)
  have hkappa : Real.exp (-(2 * eps) * alpha) ≤ upperKappa alpha eps := by
    unfold upperKappa
    exact Real.exp_le_exp.mpr (by nlinarith only [heps])
  have hCount : pilotAveragedCountVariance Counts Pilot (cp * Bpilot * ((upperOrderFloor alpha : ℝ) + fractionalPart alpha))
      (upperCountDegree k alpha eps CL cL)
      (actualUpperPolynomial k alpha eps Ch D cb lambda CL cL fL f Mprof cw).coeff
      (upperSample k alpha eps D) μ ν ≤
      (eta / 4) * (upperActualBaseline k alpha C0 db (upperA k alpha eps Ch D cb lambda CL cL) *
          (Fintype.card (Fin k) : ℝ) ^ (1 - ((upperOrderFloor alpha : ℝ) + fractionalPart alpha)) +
        upperKappa alpha eps * upperU k alpha eps u0 *
          (∑ i, p.mass i ^ ((upperOrderFloor alpha : ℝ) + fractionalPart alpha)) +
        upperKappa alpha eps * conditionalCountBonus p.mass
          ((upperOrderFloor alpha : ℝ) + fractionalPart alpha) (upperSample k alpha eps D)
          (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)) ^ 2 := by
    apply completed_conditional_count_variance_actual
      (p := p.mass) (Counts := Counts) (lam := lam) (Pilot := Pilot)
      (hell := hell) (hNk := hN) (hmDegree := hm) (hdegree := hdegree)
      (hgamma := hg) (hgamma1 := hg1) (halpha := by simpa only [hsplit] using halpha)
      (haCut := ha) (hab := hab) (hb := hb) (hcProfile := hcProfile)
      (hfL := hfL) (hfL1 := hfL1) (hf := hf) (hf1 := hf1)
      (hA := hA) (hA1 := hA1) (hB := hB) (hB1 := hB1) (hw := hw) (hw1 := hw1)
      (hlocal := hlocal) (hLactual := by rw [hsplit]) (hCL := hCL) (hcL := hcL)
      (hellL := hellL) (hNkL := le_refl _) (hscale := (by positivity : 0 < 1 / cb))
      (hcountScale := hcountScale) (hH := hH) (hrd := hrd) (hCd := hCd) (hdegreeL := hdegreeL)
      (hCt := by dsimp [Ct, Cd]; linarith) (hCt2 := by have hh := coupledCoefficientExponentialConstant_pos; dsimp [Ct]; linarith)
      (hcp := hcp) (hBpilot := hBpilot.le) (hM := hM) (hdegreeH := hdegreeH)
      (hcpM := by convert hcpDegree using 1; dsimp [M]; ring)
      (hD := hD1) (hX := hX) (hE0 := (by positivity : 0 < db / 2)) (hu0 := huref) (hc := (by positivity : 0 ≤ 2 * eps))
      (hsmall := hsmall) (hRtiny := hRtiny)
      (hRmedium := by simpa only [hnb, mul_div_cancel_right₀ _ hNpos.ne'] using hRmedium)
      (hE := by simpa only [hsplit, upperNominalBaseline] using hEref)
      (hkappa := by simpa only [hsplit] using hkappa) (hu := by simpa only [hsplit] using hurefLower)
      (hp := p.nonneg) (hk := hkcard)
      (hnsize := by simp only [hsplit, Fintype.card_fin, upperSample])
      (hLaw := hLaw) (hpair := hpair) (hPilot := hPilot) (hlam := hlam)
      hrplus hRlow (by simpa only [Fintype.card_fin] using hka) hBpilot
      (upperActualBaseline_nonneg ha1.le (zero_lt_one.trans_le hC0).le hdb.le ha.le)
      hustar (by positivity : 0 < eta / 4) (by simpa only [upperNominalBaseline] using hbase)
      (by simpa only [hsplit, Fintype.card_fin, powerSum] using simplex_powerSum_uniform_lower hk p ha1.le)
      hDn
  simp only [hsplit, Fintype.card_fin] at hCount
  have hEa : 0 ≤ upperActualBaseline k alpha C0 db (upperA k alpha eps Ch D cb lambda CL cL) *
      (k : ℝ) ^ (1 - alpha) := mul_nonneg
    (upperActualBaseline_nonneg ha1.le (zero_lt_one.trans_le hC0).le hdb.le ha.le)
    (Real.rpow_nonneg hkR.le _)
  have hreg : 0 ≤ upperKappa alpha eps * upperU k alpha eps u0 * powerSum p alpha := by
    have hU := upperU_pos (k := k) (eps := eps) ha1 hg hg1 hu0
    have hP : 0 ≤ powerSum p alpha := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (p.nonneg i) _)
    unfold upperKappa
    positivity
  have hn := upperSample_pos hk ha1 hg hg1 hDpos (ε := eps)
  have hbonus := conditionalCountBonus_nonneg p.mass p.nonneg hn.le hNpos.le (alpha := alpha)
  have hb0 : 0 ≤ upperKappa alpha eps * conditionalCountBonus p.mass alpha (upperSample k alpha eps D)
      (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) :=
    mul_nonneg (Real.exp_pos _).le hbonus
  have hchiB := mul_le_mul_of_nonneg_right hchi hb0
  let Eterm := upperActualBaseline k alpha C0 db (upperA k alpha eps Ch D cb lambda CL cL) *
    (k : ℝ) ^ (1 - alpha)
  let Rterm := upperKappa alpha eps * upperU k alpha eps u0 * powerSum p alpha
  let Bterm := upperKappa alpha eps * conditionalCountBonus p.mass alpha (upperSample k alpha eps D)
    (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)
  let chi := min (alpha - 1) 1
  have hcompare : Eterm + Rterm + Bterm ≤ 2 * (Eterm + Rterm + chi * Bterm) := by
    dsimp [Eterm, Rterm, Bterm, chi]
    nlinarith only [hEa, hreg, hchiB]
  have hpos : 0 ≤ Eterm + Rterm + Bterm := add_nonneg (add_nonneg hEa hreg) hb0
  have hsquare := pow_le_pow_left₀ hpos hcompare 2
  have hmul := mul_le_mul_of_nonneg_left hsquare (show 0 ≤ eta / 4 by positivity)
  change _ ≤ (eta / 4) * (Eterm + Rterm + Bterm) ^ 2 at hCount
  have hresult := hCount.trans hmul
  convert hresult using 1
  dsimp [Eterm, Rterm, Bterm, chi]
  ring

end Renyi
