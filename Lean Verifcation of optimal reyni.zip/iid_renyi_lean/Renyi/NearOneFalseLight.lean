import Renyi.NearOneBias
import Renyi.FalseClassification

/-! Beta-preserving false-light mean bounds near order one. -/
noncomputable section
namespace Renyi

theorem affine_power_gap {t p beta omega Cw : ℝ} (ht : 0<t) (hp : t≤p)
    (hb : 0≤beta) (hw : |omega-1|≤Cw*beta) :
    |t^beta*p-omega*p^(1+beta)|≤p^(1+beta)*beta*(Cw+Real.log (p/t)) := by
  have hp0 : 0<p := ht.trans_le hp
  have hu : 0<t/p := div_pos ht hp0
  have hu1 : t/p≤1 := (div_le_one hp0).mpr hp
  have hpow1 : (t/p)^beta≤1 := Real.rpow_le_one hu.le hu1 hb
  have he := Real.add_one_le_exp (beta*Real.log (t/p))
  rw [mul_comm beta,← Real.rpow_def_of_pos hu] at he
  have hlog : Real.log (t/p)=-Real.log (p/t) := by
    rw [Real.log_div ht.ne' hp0.ne',Real.log_div hp0.ne' ht.ne']
    ring
  have hdiff : |(t/p)^beta-1|≤beta*Real.log (p/t) := by
    rw [abs_of_nonpos (sub_nonpos.mpr hpow1)]
    rw [hlog] at he
    nlinarith
  have heq : t^beta*p-omega*p^(1+beta)=p^(1+beta)*((t/p)^beta-omega) := by
    rw [Real.div_rpow ht.le hp0.le,Real.rpow_add hp0,Real.rpow_one]
    have hne := (Real.rpow_pos_of_pos hp0 beta).ne'
    field_simp
  rw [heq,abs_mul,abs_of_nonneg (Real.rpow_nonneg hp0.le _)]
  have ha := abs_sub_le ((t/p)^beta) 1 omega
  rw [abs_sub_comm 1 omega] at ha
  have h := mul_le_mul_of_nonneg_left (show |(t/p)^beta-omega|≤beta*(Cw+Real.log (p/t)) by linarith)
    (Real.rpow_nonneg hp0.le (1+beta))
  nlinarith only [h]

theorem exp_damped_linear_uniform {D x : ℝ} (hD : 1≤D) (hx : 1≤x) :
    Real.exp (-D*x)*x≤Real.exp (1-D) := by
  have hxexp : x≤Real.exp x := (by linarith : x≤x+1).trans (Real.add_one_le_exp x)
  calc
    _ ≤ Real.exp (-D*x)*Real.exp x := mul_le_mul_of_nonneg_left hxexp (Real.exp_pos _).le
    _ = Real.exp ((1-D)*x) := by rw [← Real.exp_add]; congr 1; ring
    _ ≤ _ := Real.exp_le_exp.mpr (by nlinarith)

theorem near_one_affine_tail_damping {beta omega Cw D L N CN w : ℝ}
    (hb : 0≤beta) (hCw : 0≤Cw) (hw : |omega-1|≤Cw*beta)
    (hD : 1≤D) (hL : 1≤L) (hN : 1≤N) (hCN : 0≤CN)
    (hNL : N≤CN*L) (hw1 : 1≤w) :
    Real.exp (-D*L*w)*|(1/(N^2))^beta*w-omega*w^(1+beta)|≤
      (Cw+1+2*CN)*Real.exp (1-D)*beta*w^(1+beta) := by
  have hN0 : 0<N := zero_lt_one.trans_le hN
  have hN2 : 0<N^2 := sq_pos_of_pos hN0
  have ht : 0<1/(N^2) := one_div_pos.mpr hN2
  have ht1 : 1/(N^2)≤1 := (one_div_le_one_div_of_le (by norm_num : (0:ℝ)<1)
    (by nlinarith : 1≤N^2)).trans_eq (by norm_num)
  have hw0 : 0<w := zero_lt_one.trans_le hw1
  have hgap := affine_power_gap ht (ht1.trans hw1) hb hw
  have hlog : Real.log (w/(1/N^2))=Real.log w+2*Real.log N := by
    rw [show w/(1/N^2)=w*N^2 by field_simp,Real.log_mul hw0.ne' hN2.ne',Real.log_pow]
    norm_num
  rw [hlog,←add_assoc Cw (Real.log w) (2*Real.log N)] at hgap
  have hlw : Real.log w≤w := (Real.log_le_sub_one_of_pos hw0).trans (by linarith)
  have hln : Real.log N≤N := (Real.log_le_sub_one_of_pos hN0).trans (by linarith)
  have hx : 1≤L*w := by nlinarith [mul_nonneg (sub_nonneg.mpr hL) (sub_nonneg.mpr hw1)]
  have hCw' := mul_le_mul_of_nonneg_left hx hCw
  have hwL := mul_le_mul_of_nonneg_right hL hw0.le
  have hCNw := mul_le_mul_of_nonneg_left hw1 (by positivity : 0≤CN*L)
  have hsum : Cw+Real.log w+2*Real.log N≤(Cw+1+2*CN)*(L*w) := by
    nlinarith only [hCw',hwL,hCNw,hlw,hln,hNL]
  have hsum' := mul_le_mul_of_nonneg_left hsum
    (mul_nonneg (Real.rpow_nonneg hw0.le (1+beta)) hb)
  have hfirst := mul_le_mul_of_nonneg_left (hgap.trans hsum') (Real.exp_pos (-D*L*w)).le
  have hsecond := mul_le_mul_of_nonneg_left (exp_damped_linear_uniform hD hx)
    (by positivity : 0≤(Cw+1+2*CN)*beta*w^(1+beta))
  have hid : -D*L*w=-D*(L*w) := by ring
  rw [← hid] at hsecond
  nlinarith only [hfirst,hsecond]

end Renyi
