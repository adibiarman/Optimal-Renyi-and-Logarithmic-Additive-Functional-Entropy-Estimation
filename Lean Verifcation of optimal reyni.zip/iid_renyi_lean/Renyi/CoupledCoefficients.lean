import Renyi.CoupledPolynomial

/-! Coefficient bounds for the actual single coupled polynomial. -/
noncomputable section
open scoped BigOperators
open Polynomial
namespace Renyi

lemma coefficientMass_C_mul_X (c : ℝ) : coefficientMass (C c*X) = |c| := by
  simp [coefficientMass_C_mul]

lemma reverseScaledPolynomial_comp_coefficientMass (P : ℝ[X]) {m : ℕ} (hm : P.natDegree ≤ m)
    {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) :
    coefficientMass ((reverseScaledPolynomial P m a).comp (C b*X)) ≤ coefficientMass P*b^m := by
  have hb := ha.trans hab
  unfold reverseScaledPolynomial
  rw [sum_comp]
  calc
    _ ≤ ∑ j ∈ P.support, coefficientMass ((monomial (m-j) (P.coeff j*a^j)).comp (C b*X)) :=
      coefficientMass_sum_le _ _
    _ ≤ ∑ j ∈ P.support, |P.coeff j| * b^m := by
      apply Finset.sum_le_sum
      intro j hj
      have hjm := (le_natDegree_of_mem_supp j hj).trans hm
      rw [monomial_comp, coefficientMass_C_mul, abs_mul, abs_of_nonneg (pow_nonneg ha j)]
      have hp := coefficientMass_pow_le (C b*X) (m-j)
      rw [coefficientMass_C_mul_X, abs_of_nonneg hb] at hp
      have hm1 := mul_le_mul_of_nonneg_left hp (show 0 ≤ |P.coeff j| * a^j by positivity)
      have hm2 := mul_le_mul_of_nonneg_right (pow_le_pow_left₀ ha hab j) (pow_nonneg hb (m-j))
      rw [←pow_add, Nat.add_sub_of_le hjm] at hm2
      have hm3 := mul_le_mul_of_nonneg_left hm2 (abs_nonneg (P.coeff j))
      exact hm1.trans (by nlinarith)
    _ = coefficientMass P*b^m := by simp [coefficientMass, Polynomial.sum_def, Finset.sum_mul]

lemma inverse_scale_comp {b : ℝ} (hb : b ≠ 0) :
    (C b⁻¹*X : ℝ[X]).comp (C b*X) = X := by
  simp only [mul_comp, C_comp, X_comp]
  rw [←mul_assoc, ←C_mul, inv_mul_cancel₀ hb, C_1, one_mul]

lemma coefficientMass_scaled_power {b : ℝ} (hb : 0 ≤ b) (m : ℕ) :
    coefficientMass ((C b*X : ℝ[X])^m) ≤ b^m := by
  have h := coefficientMass_pow_le (C b*X) m
  rw [coefficientMass_C_mul, coefficientMass_X, mul_one, abs_of_nonneg hb] at h
  exact h

/-- Scaling by `b` gives the actual coefficient array used in the count estimator. -/
theorem coupledQPolynomial_scaled_coefficientMass {ℓ N m : ℕ}
    (hdegree : 4*(ℓ-1) ≤ m) {γ a b fL f A B ω : ℝ}
    (ha : 0 ≤ a) (hab : a ≤ b) (hb : 0 < b)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) :
    coefficientMass ((coupledQPolynomial ℓ N m γ a b fL f A B ω).comp (C b*X)) ≤
      A*a^γ*b^m*coefficientMass (lowProfilePolynomial ℓ γ fL)*
        (1+coefficientMass (endpointProfilePolynomial N 6 1)) +
      (B/b^(1-γ))*b^(m+1)*coefficientMass (highProfilePolynomial N (1-γ) f ω) +
      (ω*(1-B)/b^(1-γ))*b^(m+1)*coefficientMass (endpointProfilePolynomial N 6 (1-γ)) := by
  have hbpow := Real.rpow_pos_of_pos hb (1-γ)
  have hrev := reverseScaledPolynomial_comp_coefficientMass (lowProfilePolynomial ℓ γ fL)
    ((lowProfilePolynomial_natDegree ℓ γ fL).trans hdegree) ha hab
  have hcut : coefficientMass (1-X*endpointProfilePolynomial N 6 1) ≤
      1+coefficientMass (endpointProfilePolynomial N 6 1) := by
    have hm := coefficientMass_mul_le X (endpointProfilePolynomial N 6 1)
    simp only [coefficientMass_X, one_mul] at hm
    exact (coefficientMass_sub_le _ _).trans (by simpa using add_le_add_left hm 1)
  have hlow := (coefficientMass_mul_le
    (C (A*a^γ)*(reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a).comp (C b*X))
    (1-X*endpointProfilePolynomial N 6 1)).trans
    (mul_le_mul (show coefficientMass (C (A*a^γ)*(reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a).comp (C b*X)) ≤
      A*a^γ*(coefficientMass (lowProfilePolynomial ℓ γ fL)*b^m) by
      rw [coefficientMass_C_mul, abs_of_nonneg (mul_nonneg hA (Real.rpow_nonneg ha γ))]
      exact mul_le_mul_of_nonneg_left hrev (mul_nonneg hA (Real.rpow_nonneg ha γ))) hcut
      (coefficientMass_nonneg _)
      (mul_nonneg (mul_nonneg hA (Real.rpow_nonneg ha γ))
        (mul_nonneg (coefficientMass_nonneg _) (pow_nonneg hb.le m))))
  have hpow := coefficientMass_scaled_power hb.le (m+1)
  have hhigh := (coefficientMass_mul_le
    (C (B/b^(1-γ))*(C b*X)^(m+1)) (highProfilePolynomial N (1-γ) f ω)).trans
    (mul_le_mul_of_nonneg_right (show coefficientMass (C (B/b^(1-γ))*(C b*X)^(m+1)) ≤
      (B/b^(1-γ))*b^(m+1) by
      rw [coefficientMass_C_mul, abs_of_nonneg (div_nonneg hB hbpow.le)]
      exact mul_le_mul_of_nonneg_left hpow (div_nonneg hB hbpow.le)) (coefficientMass_nonneg _))
  have hrest := (coefficientMass_mul_le
    (C (ω*(1-B)/b^(1-γ))*(C b*X)^(m+1)) (endpointProfilePolynomial N 6 (1-γ))).trans
    (mul_le_mul_of_nonneg_right (show coefficientMass (C (ω*(1-B)/b^(1-γ))*(C b*X)^(m+1)) ≤
      (ω*(1-B)/b^(1-γ))*b^(m+1) by
      rw [coefficientMass_C_mul, abs_of_nonneg (div_nonneg (mul_nonneg hω (sub_nonneg.mpr hB1)) hbpow.le)]
      exact mul_le_mul_of_nonneg_left hpow (div_nonneg (mul_nonneg hω (sub_nonneg.mpr hB1)) hbpow.le))
      (coefficientMass_nonneg _))
  unfold coupledQPolynomial
  simp only [add_comp, mul_comp, C_comp, pow_comp, X_comp, sub_comp, one_comp,
    comp_assoc, inverse_scale_comp hb.ne', comp_X]
  have hs1 := coefficientMass_add_le
    (C (A*a^γ)*(reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a).comp (C b*X)*(1-X*endpointProfilePolynomial N 6 1))
    (C (B/b^(1-γ))*(C b*X)^(m+1)*highProfilePolynomial N (1-γ) f ω)
  have hs2 := coefficientMass_add_le
    (C (A*a^γ)*(reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a).comp (C b*X)*(1-X*endpointProfilePolynomial N 6 1) +
      C (B/b^(1-γ))*(C b*X)^(m+1)*highProfilePolynomial N (1-γ) f ω)
    (C (ω*(1-B)/b^(1-γ))*(C b*X)^(m+1)*endpointProfilePolynomial N 6 (1-γ))
  nlinarith

theorem coupledQPolynomial_scaled_mass_factored {ℓ N m : ℕ}
    (hdegree : 4*(ℓ-1) ≤ m) {γ a b fL f A B ω : ℝ}
    (ha : 0 ≤ a) (hab : a ≤ b) (hb : 0 < b)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) :
    coefficientMass ((coupledQPolynomial ℓ N m γ a b fL f A B ω).comp (C b*X)) ≤
      b^((m:ℝ)+γ) *
        (A*(a/b)^γ*coefficientMass (lowProfilePolynomial ℓ γ fL)*
          (1+coefficientMass (endpointProfilePolynomial N 6 1)) +
        B*coefficientMass (highProfilePolynomial N (1-γ) f ω) +
        ω*(1-B)*coefficientMass (endpointProfilePolynomial N 6 (1-γ))) := by
  have h := coupledQPolynomial_scaled_coefficientMass (N:=N) (γ:=γ) (fL:=fL) (f:=f) hdegree ha hab hb hA hB hB1 hω
  have hr := reverse_fractional_identity m γ ha hb
  have hf : b^((m:ℝ)+γ)=b^(m+1)/b^(1-γ) := by
    simpa [hb.ne'] using forward_fractional_identity m γ hb hb
  apply h.trans_eq
  have hl : A*a^γ*b^m*coefficientMass (lowProfilePolynomial ℓ γ fL)*
      (1+coefficientMass (endpointProfilePolynomial N 6 1)) =
      b^((m:ℝ)+γ)*(A*(a/b)^γ*coefficientMass (lowProfilePolynomial ℓ γ fL)*
        (1+coefficientMass (endpointProfilePolynomial N 6 1))) := by
    calc
      _ = (a^γ*b^m)*(A*coefficientMass (lowProfilePolynomial ℓ γ fL)*
        (1+coefficientMass (endpointProfilePolynomial N 6 1))) := by ring
      _ = _ := by rw [←hr]; ring
  rw [hl]
  rw [hf]
  ring

/-- Explicit degree-scale budget, uniform in both fractional exponents. -/
def coupledCoefficientBudget (ℓ N : ℕ) (γ a b A B ω : ℝ) : ℝ :=
  A*(a/b)^γ*(96*(ℓ:ℝ)^2*(9:ℝ)^(4*(ℓ-1)))*
      (1+24*(N:ℝ)^2*(9:ℝ)^((N-1)*6)) +
  B*(288*(N:ℝ)^2*(9:ℝ)^(18*(N-1))) +
  ω*(1-B)*(24*(N:ℝ)^2*(9:ℝ)^((N-1)*6))

/-- Coefficients of the actual coupled Q, with every analytic block instantiated. -/
theorem coupledQPolynomial_coefficient_bound {ℓ N m : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    (hdegree : 4*(ℓ-1) ≤ m) {γ a b fL f A B ω : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 ≤ a) (hab : a ≤ b) (hb : 0 < b)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1) (j : ℕ) :
    |(coupledQPolynomial ℓ N m γ a b fL f A B ω).coeff j| * b^j ≤
      b^((m:ℝ)+γ)*coupledCoefficientBudget ℓ N γ a b A B ω := by
  have hmass := coupledQPolynomial_scaled_mass_factored (N:=N) (γ:=γ) (fL:=fL) (f:=f) hdegree ha hab hb hA hB hB1 hω
  have hl := lowProfilePolynomial_coefficientMass hℓ hγ hγ1.le hfL hfL1
  have hv := highProfilePolynomial_coefficientMass hN (by linarith : 0<1-γ)
    (by linarith : 1-γ≤1) hf hf1 hω hω1
  have hj1 := endpointProfilePolynomial_coefficientMass hN (by norm_num : 6≤6)
    (by norm_num : (0:ℝ)<1) (by norm_num : (1:ℝ)≤1)
  have hjδ := endpointProfilePolynomial_coefficientMass hN (by norm_num : 6≤6)
    (by linarith : 0<1-γ) (by linarith : 1-γ≤1)
  have hl' := mul_le_mul
    (mul_le_mul_of_nonneg_left hl (mul_nonneg hA (Real.rpow_nonneg (div_nonneg ha hb.le) γ)))
    (add_le_add_left hj1 1)
    (show 0 ≤ 1+coefficientMass (endpointProfilePolynomial N 6 1) by linarith [coefficientMass_nonneg (endpointProfilePolynomial N 6 1)])
    (show 0 ≤ A*(a/b)^γ*(96*(ℓ:ℝ)^2*(9:ℝ)^(4*(ℓ-1))) by positivity)
  have hv' := mul_le_mul_of_nonneg_left hv hB
  have hj' := mul_le_mul_of_nonneg_left hjδ (mul_nonneg hω (sub_nonneg.mpr hB1))
  have hbgt : A*(a/b)^γ*coefficientMass (lowProfilePolynomial ℓ γ fL)*
      (1+coefficientMass (endpointProfilePolynomial N 6 1)) +
      B*coefficientMass (highProfilePolynomial N (1-γ) f ω) +
      ω*(1-B)*coefficientMass (endpointProfilePolynomial N 6 (1-γ)) ≤
      coupledCoefficientBudget ℓ N γ a b A B ω := by
    unfold coupledCoefficientBudget
    nlinarith
  have hc := abs_coeff_le_coefficientMass
    ((coupledQPolynomial ℓ N m γ a b fL f A B ω).comp (C b*X)) j
  rw [comp_C_mul_X_coeff, abs_mul, abs_of_nonneg (pow_nonneg hb.le j)] at hc
  exact hc.trans (hmass.trans (mul_le_mul_of_nonneg_left hbgt (Real.rpow_nonneg hb.le _)))

end Renyi
