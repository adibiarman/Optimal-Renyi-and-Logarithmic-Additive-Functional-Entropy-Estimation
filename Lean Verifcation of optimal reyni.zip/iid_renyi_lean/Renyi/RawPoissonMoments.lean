import Renyi.PoissonCentralMoments
import Renyi.AnalyticNoise

/-! Uniform raw real moments of the actual Poisson count and Gamma statistic. -/
noncomputable section
open scoped NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

theorem poisson_exp_shift_hasSum (lam : ℝ≥0) (t q : ℝ) :
    HasSum (fun j : ℕ => Real.exp (t * j - q) * poissonPMFReal lam j)
      (Real.exp ((lam : ℝ) * (Real.exp t - 1) - q)) := by
  have h := (poisson_exp_hasSum lam t).mul_left (Real.exp (-q))
  convert h using 1
  · funext j
    rw [sub_eq_add_neg, Real.exp_add]
    ring
  · rw [sub_eq_add_neg, Real.exp_add]
    ring

theorem poisson_raw_rpow_integrable (lam : ℝ≥0) {q : ℝ} (hq : 0 < q) :
    Integrable (fun j : ℕ => (j : ℝ) ^ q) (poissonMeasure lam) := by
  have hsum := (poisson_exp_shift_hasSum lam 1 q).mul_left (q ^ q)
  apply poisson_integrable_of_summable
  apply Summable.of_nonneg_of_le (fun j => mul_nonneg (norm_nonneg _) poissonPMFReal_nonneg) _ hsum.summable
  intro j
  rw [Real.norm_of_nonneg (Real.rpow_nonneg (Nat.cast_nonneg _) _)]
  have h := mul_le_mul_of_nonneg_right
    (rpow_le_scaled_exponential (Nat.cast_nonneg j) hq (by norm_num : (0 : ℝ) < 1))
    (poissonPMFReal_nonneg (r := lam) (n := j))
  simpa only [div_one, one_mul, mul_assoc] using h

/-- Explicit real-order Poisson moment bound at every nonnegative intensity. -/
theorem poisson_raw_rpow_integral_le (lam : ℝ≥0) {q : ℝ} (hq : 0 < q) :
    (∫ j : ℕ, (j : ℝ) ^ q ∂poissonMeasure lam) ≤
      Real.exp (2 * q) * ((lam : ℝ) + q) ^ q := by
  let t := q / ((lam : ℝ) + q)
  have hsumpos : 0 < (lam : ℝ) + q := by positivity
  have ht : 0 < t := div_pos hq hsumpos
  have ht1 : t ≤ 1 := (div_le_one hsumpos).2 (by linarith [lam.coe_nonneg])
  have hscale : (lam : ℝ) * t ≤ q := by
    dsimp [t]
    rw [← mul_div_assoc]
    apply (div_le_iff₀ hsumpos).2
    nlinarith [sq_nonneg q]
  have htail : (lam : ℝ) * (Real.exp t - 1) - q ≤ 2 * q := by
    have hrem := (abs_le.mp (Real.abs_exp_sub_one_sub_id_le (by rw [abs_of_pos ht]; exact ht1))).2
    have ht2 : t ^ 2 ≤ t := by nlinarith
    have hm := mul_le_mul_of_nonneg_left (show Real.exp t - 1 ≤ 2 * t by linarith) lam.coe_nonneg
    linarith
  have hid : q / t = (lam : ℝ) + q := by dsimp [t]; field_simp
  have hsum := (poisson_exp_shift_hasSum lam t q).mul_left ((q / t) ^ q)
  have hint := poisson_raw_rpow_integrable lam hq
  rw [poisson_integral_eq_tsum lam _ hint]
  have hpoint (j : ℕ) : (j : ℝ) ^ q * poissonPMFReal lam j ≤
      (q / t) ^ q * (Real.exp (t * j - q) * poissonPMFReal lam j) := by
    have h := mul_le_mul_of_nonneg_right
      (rpow_le_scaled_exponential (Nat.cast_nonneg j) hq ht)
      (poissonPMFReal_nonneg (r := lam) (n := j))
    simpa only [mul_assoc] using h
  have hs : Summable (fun j : ℕ => (j : ℝ) ^ q * poissonPMFReal lam j) :=
    Summable.of_nonneg_of_le (fun j => mul_nonneg (Real.rpow_nonneg (Nat.cast_nonneg _) _) poissonPMFReal_nonneg)
      hpoint hsum.summable
  have h := hs.tsum_le_tsum hpoint hsum.summable
  rw [hsum.tsum_eq, hid] at h
  exact h.trans (by
    have hh := mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr htail)
      (Real.rpow_nonneg hsumpos.le q)
    simpa only [mul_comm] using hh)

theorem analyticCount_abs_le_low_add_power {a : ℝ} (ha : 1 ≤ a) (j : ℕ) :
    |analyticCount a j| ≤ a ^ a + (j : ℝ) ^ a := by
  by_cases hj : (j : ℝ) < a
  · exact (analyticCount_abs_below_order ha j hj).trans (le_add_of_nonneg_right (Real.rpow_nonneg (Nat.cast_nonneg _) _))
  · have hjge : a ≤ (j : ℝ) := le_of_not_gt hj
    have hp : positiveCount a j = analyticCount a j := by simp [positiveCount, hjge]
    rw [← hp, abs_of_nonneg (positiveCount_nonneg _ _)]
    exact (positiveCount_le_power ha j).trans (le_add_of_nonneg_left (Real.rpow_nonneg (by linarith : 0 ≤ a) _))

theorem analyticCount_abs_integral_le (lam : ℝ≥0) {a : ℝ} (ha : 1 ≤ a) :
    (∫ j, |analyticCount a j| ∂poissonMeasure lam) ≤
      a ^ a + Real.exp (2 * a) * ((lam : ℝ) + a) ^ a := by
  have hint := ((analyticCount_memLp lam a).integrable one_le_two).abs
  have hg : Integrable (fun j : ℕ => a ^ a + (j : ℝ) ^ a) (poissonMeasure lam) :=
    (integrable_const _).add (poisson_raw_rpow_integrable lam (by linarith : 0 < a))
  have h := integral_mono hint hg (analyticCount_abs_le_low_add_power ha)
  rw [integral_add (integrable_const _) (poisson_raw_rpow_integrable lam (by linarith : 0 < a))] at h
  simp only [integral_const, measureReal_univ_eq_one, smul_eq_mul, one_mul] at h
  linarith [poisson_raw_rpow_integral_le lam (by linarith : 0 < a)]

theorem analyticCount_sq_le_low_add_power {a : ℝ} (ha : 1 ≤ a) (j : ℕ) :
    analyticCount a j ^ 2 ≤ 2 * (a ^ a) ^ (2 : ℕ) + 2 * (j : ℝ) ^ (2 * a) := by
  have ha0 : 0 ≤ a := by linarith
  have hpow : ((j : ℝ) ^ a) ^ (2 : ℕ) = (j : ℝ) ^ (2 * a) := by
    rw [← Real.rpow_mul_natCast (Nat.cast_nonneg j)]
    congr 1
    ring
  have hab := analyticCount_abs_le_low_add_power ha j
  have hsq := mul_le_mul hab hab (abs_nonneg _)
    (add_nonneg (Real.rpow_nonneg ha0 _) (Real.rpow_nonneg (Nat.cast_nonneg _) _))
  simp only [← pow_two, sq_abs] at hsq
  nlinarith [sq_nonneg (a ^ a - (j : ℝ) ^ a)]

theorem analyticCount_sq_integral_le (lam : ℝ≥0) {a : ℝ} (ha : 1 ≤ a) :
    (∫ j, analyticCount a j ^ 2 ∂poissonMeasure lam) ≤
      2 * (a ^ a) ^ (2 : ℕ) + 2 * Real.exp (4 * a) * ((lam : ℝ) + 2 * a) ^ (2 * a) := by
  have hint := (analyticCount_memLp lam a).integrable_sq
  have hq : 0 < 2 * a := by linarith
  have hg : Integrable (fun j : ℕ => 2 * (a ^ a) ^ (2 : ℕ) + 2 * (j : ℝ) ^ (2 * a))
      (poissonMeasure lam) := (integrable_const _).add ((poisson_raw_rpow_integrable lam hq).const_mul 2)
  have h := integral_mono hint hg (analyticCount_sq_le_low_add_power ha)
  rw [integral_add (integrable_const _) ((poisson_raw_rpow_integrable lam hq).const_mul 2)] at h
  simp only [integral_const_mul] at h
  simp only [integral_const, measureReal_univ_eq_one, smul_eq_mul, one_mul] at h
  have hp := poisson_raw_rpow_integral_le lam hq
  rw [show 2 * (2 * a) = 4 * a by ring] at hp
  linarith

end Renyi
