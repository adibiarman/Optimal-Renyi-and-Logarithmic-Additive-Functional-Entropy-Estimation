import Renyi.NearOneExpectation
import Renyi.HighCountCalibration

/-! Actual random-pilot boundary errors for the noninteger upper estimator. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi
set_option maxHeartbeats 500000

lemma poissonUpperMass_eq_one_sub (lam : ℝ≥0) (T : ℝ) :
    poissonUpperMass lam T=1-poissonLowerMass lam T := by
  have hh := (poissonUpperMass_summable lam T).hasSum.add (poissonLowerMass_summable lam T).hasSum
  have heq : (fun j : ℕ => (if T<(j:ℝ) then poissonPMFReal lam j else 0)+
      (if (j:ℝ)≤T then poissonPMFReal lam j else 0))=poissonPMFReal lam := by
    funext j
    by_cases h : (j:ℝ)≤T
    · simp only [if_pos h,if_neg (not_lt.mpr h),zero_add]
    · simp only [if_neg h,if_pos (lt_of_not_ge h),add_zero]
  rw [heq] at hh
  have hsum := hh.unique (poissonPMFRealSum lam)
  change poissonUpperMass lam T+poissonLowerMass lam T=1 at hsum
  linarith only [hsum]

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}

/-- Upper-pilot selection factors exactly under the actual independent pair law. -/
theorem poisson_upper_selected_mean (Y N : Ω→ℕ) (pilotLam lam : ℝ≥0)
    (hY : MeasurePreserving Y μ (poissonMeasure pilotLam))
    (hN : MeasurePreserving N μ (poissonMeasure lam)) (hind : IndepFun Y N μ)
    (T : ℝ) (f : ℕ→ℝ) (hf : Integrable f (poissonMeasure lam)) :
    Integrable (fun w => if T<(Y w:ℝ) then f (N w) else 0) μ ∧
      (∫ w, (if T<(Y w:ℝ) then f (N w) else 0) ∂μ)=
        poissonUpperMass pilotLam T*(∫ j,f j ∂poissonMeasure lam) := by
  have hlo := poisson_selected_mean Y N pilotLam lam hY hN hind T f hf
  have hfull : Integrable (fun w => f (N w)) μ := hN.integrable_comp_of_integrable hf
  have heq : (fun w => if T<(Y w:ℝ) then f (N w) else 0)=
      fun w => f (N w)-(if (Y w:ℝ)≤T then f (N w) else 0) := by
    funext w
    by_cases h : (Y w:ℝ)≤T
    · simp only [if_pos h,if_neg (not_lt.mpr h),sub_self]
    · simp only [if_neg h,if_pos (lt_of_not_ge h),sub_zero]
  rw [heq]
  refine ⟨hfull.sub hlo.1,?_⟩
  rw [integral_sub hfull hlo.1,hlo.2,poissonUpperMass_eq_one_sub]
  have he := hN.hasLaw.integral_comp (measurable_of_countable f).aestronglyMeasurable
  change (∫ w,f (N w) ∂μ)=(∫ j,f j ∂poissonMeasure lam) at he
  rw [he]
  ring

/-- False-heavy probability retains a small-mean factor, uniformly in order. -/
theorem false_heavy_pilot_min {cp B alpha : ℝ} (hcp : 1≤cp) (hB : 16≤B)
    (ha : 1≤alpha) (lam : ℝ≥0) (hlam : (lam:ℝ)≤B*alpha/2) :
    poissonUpperMass ⟨cp*lam,mul_nonneg (by linarith only [hcp]) lam.coe_nonneg⟩ (cp*B*alpha)≤
      Real.exp (-cp*alpha)*min (lam:ℝ) 1 := by
  have hcp0 : 0<cp := by linarith only [hcp]
  have ha0 : 0<alpha := by linarith only [ha]
  by_cases hlarge : 1≤(lam:ℝ)
  · rw [min_eq_right hlarge,mul_one]
    exact false_heavy_pilot_large hcp0 hB ha0 lam hlam
  · have hlam1 : (lam:ℝ)≤1 := le_of_not_ge hlarge
    rw [min_eq_left hlam1]
    rcases eq_or_lt_of_le lam.coe_nonneg with hz | hl
    · have hzero : lam=0 := by ext; exact hz.symm
      have hmu : (⟨cp*lam,mul_nonneg hcp0.le lam.coe_nonneg⟩:ℝ≥0)=0 := by ext;simp [hzero]
      rw [hmu,poissonUpperMass_zero (by positivity),hzero]
      simp only [NNReal.coe_zero,mul_zero,le_refl]
    · have hsmall : (lam:ℝ)≤alpha := hlam1.trans ha
      have htail := false_heavy_pilot_small hcp0 hB ha0 lam hl hsmall
      have hratio0 : 0≤(lam:ℝ)/alpha := div_nonneg lam.coe_nonneg ha0.le
      have hratio1 : (lam:ℝ)/alpha≤1 := (div_le_one ha0).mpr hsmall
      have hpower1 : 1≤cp*B*alpha := by
        have hB0 : 0≤B := by linarith only [hB]
        have hh := mul_le_mul hcp hB (by norm_num : (0:ℝ)≤16) hcp0.le
        have hh' := mul_le_mul_of_nonneg_right hh ha0.le
        nlinarith only [hh',ha]
      have hp := (Real.rpow_le_self_of_le_one hratio0 hratio1 hpower1).trans (div_le_self lam.coe_nonneg ha)
      have he : Real.exp (-12*cp*alpha)≤Real.exp (-cp*alpha) :=
        Real.exp_le_exp.mpr (by nlinarith only [mul_pos hcp0 ha0])
      exact htail.trans (mul_le_mul he hp (Real.rpow_nonneg hratio0 _) (Real.exp_pos _).le)

/-- The signed Gamma arm's actual false-heavy absolute expectation, in probability units. -/
theorem false_heavy_gamma_coordinate {B alpha cp cstar n p omega : ℝ}
    (hB : 16≤B) (ha : 3/2≤alpha) (hcstar : 0≤cstar)
    (hcp : 2*B+cstar+11≤cp) (hn : 0<n) (hp : 0≤p)
    (hw : 0≤omega) (hw1 : omega≤1)
    (Y N : Ω→ℕ) (lam : ℝ≥0) (hlam : (lam:ℝ)=n*p)
    (hY : MeasurePreserving Y μ (poissonMeasure ⟨cp*lam,mul_nonneg (by linarith only [hcp,hB,hcstar]) lam.coe_nonneg⟩))
    (hN : MeasurePreserving N μ (poissonMeasure lam)) (hind : IndepFun Y N μ)
    (hsmall : n*p≤B*alpha/2) :
    Integrable (fun w => if cp*B*alpha<(Y w:ℝ) then |omega*analyticCount alpha (N w)/n^alpha| else 0) μ ∧
      (∫ w, (if cp*B*alpha<(Y w:ℝ) then |omega*analyticCount alpha (N w)/n^alpha| else 0) ∂μ)≤
        Real.exp (-cstar*alpha)*p^alpha*min (n*p) 1 := by
  let nu : ℝ≥0 := ⟨cp*lam,mul_nonneg (by linarith only [hcp,hB,hcstar]) lam.coe_nonneg⟩
  have hnPow : 0<n^alpha := Real.rpow_pos_of_pos hn _
  have hf := ((analyticCount_memLp lam alpha).integrable one_le_two).abs
  have hfscaled : Integrable (fun j => |omega*analyticCount alpha j/n^alpha|) (poissonMeasure lam) := by
    simpa only [abs_div,abs_mul,abs_of_nonneg hw,abs_of_pos hnPow] using (hf.const_mul omega).div_const (n^alpha)
  have hsel := poisson_upper_selected_mean Y N nu lam hY hN hind (cp*B*alpha) _ hfscaled
  refine ⟨hsel.1,?_⟩
  rw [hsel.2]
  have hgamma := (false_heavy_joint_moments hB ha hcstar hcp lam (by rwa [hlam])).1
  rw [(poissonUpperSelected_hasSum lam nu (cp*B*alpha) (fun j => |analyticCount alpha j|)
    (fun j => abs_nonneg _) hf).tsum_eq] at hgamma
  have heq : (∫ j,|omega*analyticCount alpha j/n^alpha| ∂poissonMeasure lam)=
      omega/n^alpha*(∫ j,|analyticCount alpha j| ∂poissonMeasure lam) := by
    simp only [abs_div,abs_mul,abs_of_nonneg hw,abs_of_pos hnPow]
    rw [integral_div,integral_const_mul]
    ring
  rw [heq]
  have hscale := mul_le_mul_of_nonneg_left hgamma (div_nonneg hw hnPow.le)
  have hid : omega/n^alpha*(Real.exp (-cstar*alpha)*(lam:ℝ)^alpha*min (lam:ℝ) 1)=
      omega*(Real.exp (-cstar*alpha)*p^alpha*min (n*p) 1) := by
    rw [hlam,Real.mul_rpow hn.le hp]
    field_simp
  rw [hid] at hscale
  have hnon : 0≤Real.exp (-cstar*alpha)*p^alpha*min (n*p) 1 := by positivity
  calc
    _=(omega/n^alpha)*(poissonUpperMass nu (cp*B*alpha)*(∫ j,|analyticCount alpha j| ∂poissonMeasure lam)) := by ring
    _≤omega*(Real.exp (-cstar*alpha)*p^alpha*min (n*p) 1) := hscale
    _≤_ := mul_le_of_le_one_left hnon hw1

end Renyi
