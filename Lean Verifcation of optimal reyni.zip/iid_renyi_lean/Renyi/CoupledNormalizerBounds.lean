import Renyi.CoupledProfiles
import Mathlib.Analysis.MeanInequalities

/-! Sharp upper bounds for the actual endpoint-profile normalizing suprema. -/
noncomputable section
open Set
namespace Renyi

lemma kernel_fraction_amgm {q f : ℝ} (hq : 0 ≤ q) (hf : 0 ≤ f) (hf1 : f < 1) :
    q/(1-f+f*q) ≤ q^(1-f) := by
  have hρ : 0 < 1-f := by linarith
  have hden : 0 < 1-f+f*q := by positivity
  rcases hq.eq_or_lt with rfl | hq
  · simp [Real.zero_rpow hρ.ne']
  have ham := Real.geom_mean_le_arith_mean2_weighted hf hρ.le hq.le
    (by norm_num : (0:ℝ)≤1) (show f+(1-f)=1 by ring)
  simp only [Real.one_rpow,mul_one] at ham
  have hqm := mul_le_mul_of_nonneg_left ham (Real.rpow_pos_of_pos hq (1-f)).le
  have hid : q^(1-f)*q^f=q := by
    rw [←Real.rpow_add hq]
    simp
  rw [hid] at hqm
  apply (div_le_iff₀ hden).mpr
  nlinarith only [hqm]

/-- A bound retaining the correct exponent when s is below the denominator reserve. -/
lemma endpointKernel_fraction_sharp_small {N d : ℕ} (hN : 2 ≤ N) (hd : 2 ≤ d)
    {s f x : ℝ} (hs : 0 < s) (hf : 0 ≤ f) (hf1 : f < 1)
    (hsρ : s ≤ 1-f) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    (N:ℝ)^(2*s)*(x^s*endpointKernel N d x/(1-f+f*endpointKernel N d x)) ≤
      (32*(s/(1-f)))^s := by
  let ρ : ℝ := 1-f
  have hρ : 0 < ρ := by dsimp [ρ];linarith
  have ht : 0 < s/ρ := div_pos hs hρ
  have ht1 : s/ρ ≤ 1 := (div_le_one hρ).mpr hsρ
  have hk := endpointKernel_nonneg N d x
  have hq := kernel_fraction_amgm hk hf hf1
  have hraw := endpointKernel_sharp_weight_upper hN hd ht ht1 hx hx1
  have hraise := Real.rpow_le_rpow (show 0 ≤ (N:ℝ)^(2*(s/ρ))*(x^(s/ρ)*endpointKernel N d x) by positivity)
    hraw hρ.le
  have hleft : ((N:ℝ)^(2*(s/ρ))*(x^(s/ρ)*endpointKernel N d x))^ρ =
      (N:ℝ)^(2*s)*(x^s*(endpointKernel N d x)^ρ) := by
    rw [Real.mul_rpow (by positivity) (by positivity),Real.mul_rpow (by positivity) hk,
      ←Real.rpow_mul (by positivity : 0≤(N:ℝ)),←Real.rpow_mul hx]
    have hid : (s/ρ)*ρ=s := by field_simp
    have hid2 : (2*(s/ρ))*ρ=2*s := by field_simp
    rw [hid,hid2]
  have hright : ((32*(s/ρ))^(s/ρ))^ρ=(32*(s/ρ))^s := by
    rw [←Real.rpow_mul (by positivity)]
    congr 1
    field_simp
  rw [hleft,hright] at hraise
  have hm := mul_le_mul_of_nonneg_left hq (show 0≤(N:ℝ)^(2*s)*x^s by positivity)
  have heq : (N:ℝ)^(2*s)*(x^s*endpointKernel N d x/(1-f+f*endpointKernel N d x)) =
      ((N:ℝ)^(2*s)*x^s)*(endpointKernel N d x/(1-f+f*endpointKernel N d x)) := by ring
  rw [heq]
  exact hm.trans (by convert hraise using 1; dsimp [ρ]; ring)

def endpointReserveConstant (f : ℝ) : ℝ := 32*(1-f)^(-1/(1-f))

lemma endpointReserveConstant_pos {f : ℝ} (hf1 : f < 1) : 0 < endpointReserveConstant f := by
  unfold endpointReserveConstant
  exact mul_pos (by norm_num) (Real.rpow_pos_of_pos (by linarith : 0<1-f) _)

lemma endpointKernel_fraction_sharp_large {N d : ℕ} (hN : 2 ≤ N) (hd : 2 ≤ d)
    {s f x : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f < 1)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    (N:ℝ)^(2*s)*(x^s*endpointKernel N d x/(1-f+f*endpointKernel N d x)) ≤
      (32*s)^s/(1-f) := by
  have hK := endpointKernel_nonneg N d x
  have hρ : 0<1-f := by linarith
  have hden : 0<1-f+f*endpointKernel N d x := by positivity
  have hdenle : 1-f ≤ 1-f+f*endpointKernel N d x := by linarith [mul_nonneg hf hK]
  have hq := div_le_div_of_nonneg_left (show 0≤x^s*endpointKernel N d x by positivity) hρ hdenle
  have hm := mul_le_mul_of_nonneg_left hq (show 0≤(N:ℝ)^(2*s) by positivity)
  have hraw := endpointKernel_sharp_weight_upper hN hd hs hs1 hx hx1
  have hdv := div_le_div_of_nonneg_right hraw hρ.le
  have heq : (N:ℝ)^(2*s)*(x^s*endpointKernel N d x/(1-f)) =
      ((N:ℝ)^(2*s)*(x^s*endpointKernel N d x))/(1-f) := by ring
  rw [heq] at hm
  exact hm.trans hdv

/-- Sharp fraction bound with one f-dependent constant, uniform for 0<s<=1. -/
theorem endpointKernel_fraction_sharp_upper {N d : ℕ} (hN : 2 ≤ N) (hd : 2 ≤ d)
    {s f x : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f < 1)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    (N:ℝ)^(2*s)*(x^s*endpointKernel N d x/(1-f+f*endpointKernel N d x)) ≤
      (endpointReserveConstant f*s)^s := by
  have hρ : 0<1-f := by linarith
  have hρ1 : 1-f ≤ 1 := by linarith
  by_cases hcase : s ≤ 1-f
  · have hsmall := endpointKernel_fraction_sharp_small hN hd hs hf hf1 hcase hx hx1
    have hinv : (1-f)⁻¹ ≤ (1-f)^(-1/(1-f)) := by
      have hneg : -1/(1-f) ≤ -1 := by
        apply (div_le_iff₀ hρ).mpr
        linarith only [hρ1]
      have h := Real.rpow_le_rpow_of_exponent_ge hρ hρ1 hneg
      rw [Real.rpow_neg_one] at h
      exact h
    have hbase : 32*(s/(1-f)) ≤ endpointReserveConstant f*s := by
      unfold endpointReserveConstant
      have hm := mul_le_mul_of_nonneg_left hinv (show 0≤32*s by positivity)
      calc
        _ = (32*s)*(1-f)⁻¹ := by ring
        _ ≤ (32*s)*(1-f)^(-1/(1-f)) := hm
        _ = _ := by ring
    exact hsmall.trans (Real.rpow_le_rpow (by positivity) hbase hs.le)
  · have hlarge := endpointKernel_fraction_sharp_large hN hd hs hs1 hf hf1 hx hx1
    have hneg : (-1/(1-f))*s ≤ -1 := by
      rw [show (-1/(1-f))*s=(-s)/(1-f) by ring]
      apply (div_le_iff₀ hρ).mpr
      linarith only [hcase]
    have hinv := Real.rpow_le_rpow_of_exponent_ge hρ hρ1 hneg
    rw [Real.rpow_neg_one] at hinv
    have hm := mul_le_mul_of_nonneg_left hinv (Real.rpow_pos_of_pos (by positivity : 0<32*s) s).le
    have heq : (endpointReserveConstant f*s)^s = (32*s)^s*(1-f)^((-1/(1-f))*s) := by
      unfold endpointReserveConstant
      rw [show 32*(1-f)^(-1/(1-f))*s=(32*s)*(1-f)^(-1/(1-f)) by ring,
        Real.mul_rpow (by positivity) (Real.rpow_nonneg hρ.le _),←Real.rpow_mul hρ.le]
    rw [heq]
    exact hlarge.trans (by simpa only [div_eq_mul_inv] using hm)

lemma endpointNormalizer_sharp_upper {N d : ℕ} (hN : 2 ≤ N) (hd : 2 ≤ d)
    {s f : ℝ} {H : ℝ → ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f < 1)
    (hH : ∀ x ∈ Icc (0:ℝ) 1, H x ≤ f*(1-endpointKernel N d x)) :
    (N:ℝ)^(2*s)*coupledNormalizer s (endpointKernel N d) H ≤
      (endpointReserveConstant f*s)^s := by
  have hNp : 0<(N:ℝ)^(2*s) := Real.rpow_pos_of_pos (by exact_mod_cast (show 0<N by omega)) _
  have hsup : coupledNormalizer s (endpointKernel N d) H ≤
      (endpointReserveConstant f*s)^s/(N:ℝ)^(2*s) := by
    unfold coupledNormalizer
    apply csSup_le (Set.image_nonempty.mpr (show (Icc (0:ℝ) 1).Nonempty from ⟨0,⟨le_rfl,zero_le_one⟩⟩))
    rintro z ⟨x,hx,rfl⟩
    have hK := endpointKernel_nonneg N d x
    have hρ : 0<1-f := by linarith
    have hden : 0<1-f+f*endpointKernel N d x := by positivity
    have hdenle : 1-f+f*endpointKernel N d x ≤ 1-H x := by nlinarith only [hH x hx]
    have hq := div_le_div_of_nonneg_left (mul_nonneg (Real.rpow_nonneg hx.1 s) hK) hden hdenle
    have hm := mul_le_mul_of_nonneg_left hq hNp.le
    have hraw := endpointKernel_fraction_sharp_upper hN hd hs hs1 hf hf1 hx.1 hx.2
    apply (le_div_iff₀ hNp).mpr
    nlinarith only [hm,hraw]
  have hm := (le_div_iff₀ hNp).mp hsup
  nlinarith only [hm]

lemma lowShoulder_kernel_bound {N : ℕ} (hN : 0<N) {s f x : ℝ}
    (hs : 0<s) (hf : 0≤f) (hx : 0≤x) (hx1 : x≤1) :
    lowShoulder N s f x ≤ f*(1-endpointKernel N 2 x) := by
  have hJ := (endpointProfile_range hN (by norm_num : 2≤6) hs hx hx1).2
  have hK := endpointKernel_le_one hN 2 hx hx1
  have hmul := mul_le_mul_of_nonneg_right (mul_le_of_le_one_right hf hJ) (sub_nonneg.mpr hK)
  exact hmul

lemma highShoulder_kernel_bound {N : ℕ} (hN : 0<N) {s f ω x : ℝ}
    (hs : 0<s) (hf : 0≤f) (hf1 : f≤1) (hω : 0≤ω) (hx : 0≤x) (hx1 : x≤1) :
    highShoulder N s f ω x ≤ ω*(1-endpointKernel N 6 x) := by
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hs hx hx1
  have hK := endpointKernel_le_one hN 6 hx hx1
  have hW := (highShoulderWeight_range hN hf hf1 hx hx1).2
  have hbase : 0≤ω*endpointProfile N 6 s x*(1-endpointKernel N 6 x) :=
    mul_nonneg (mul_nonneg hω hJ.1) (sub_nonneg.mpr hK)
  have hmul := mul_le_mul_of_nonneg_right (mul_le_of_le_one_right hω hJ.2) (sub_nonneg.mpr hK)
  unfold highShoulder
  exact (mul_le_of_le_one_right hbase hW).trans hmul

/-- Sharp upper bound for the actual low-profile normalizing supremum. -/
theorem lowNormalizer_sharp_upper {N : ℕ} (hN : 2≤N) {s f : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) :
    (N:ℝ)^(2*s)*lowNormalizer N s f ≤ (endpointReserveConstant f*s)^s := by
  exact endpointNormalizer_sharp_upper hN (by norm_num : 2≤2) hs hs1 hf hf1
    (fun _x hx => lowShoulder_kernel_bound (by omega) hs hf hx.1 hx.2)

/-- Sharp upper bound for the actual high-profile normalizing supremum. -/
theorem highNormalizer_sharp_upper_reserve {N : ℕ} (hN : 2≤N) {s f ω : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f≤1) (hω : 0≤ω) (hω1 : ω<1) :
    (N:ℝ)^(2*s)*highNormalizer N s f ω ≤ (endpointReserveConstant ω*s)^s := by
  exact endpointNormalizer_sharp_upper hN (by norm_num : 2≤6) hs hs1 hω hω1
    (fun _x hx => highShoulder_kernel_bound (by omega) hs hf hf1 hω hx.1 hx.2)

lemma endpointKernel_six_eq_three_sq (N : ℕ) (x : ℝ) :
    endpointKernel N 6 x=(endpointKernel N 3 x)^2 := by
  unfold endpointKernel
  rw [←pow_mul]

/-- The raised high shoulder supplies a fixed reserve even as omega tends to one. -/
lemma highShoulder_three_reserve {N : ℕ} (hN : 0<N) {s f ω x : ℝ}
    (hs : 0<s) (hf : 0≤f) (hf1 : f≤1) (hω : 0≤ω) (hω1 : ω≤1)
    (hx : 0≤x) (hx1 : x≤1) :
    endpointKernel N 3 x*(1-f+f*endpointKernel N 3 x) ≤ 1-highShoulder N s f ω x := by
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hs hx hx1
  have hR0 := endpointKernel_nonneg N 3 x
  have hR1 := endpointKernel_le_one hN 3 hx hx1
  have hW := highShoulderWeight_range hN hf hf1 hx hx1
  have hK1 := endpointKernel_le_one hN 6 hx hx1
  have hbase : 0≤(1-endpointKernel N 6 x)*highShoulderWeight N f x :=
    mul_nonneg (sub_nonneg.mpr hK1) hW.1
  have hωJ : ω*endpointProfile N 6 s x ≤ 1 :=
    (mul_le_of_le_one_right hω hJ.2).trans hω1
  have hH : highShoulder N s f ω x ≤
      (1-endpointKernel N 6 x)*highShoulderWeight N f x := by
    have hm := mul_le_mul_of_nonneg_right hωJ hbase
    unfold highShoulder
    nlinarith only [hm]
  have hcore : 0 ≤ 1+endpointKernel N 3 x-(endpointKernel N 3 x)^2 := by
    nlinarith only [hR0,hR1]
  have hp := mul_nonneg (mul_nonneg (mul_nonneg (sub_nonneg.mpr hf1) hR0)
    (sub_nonneg.mpr hR1)) hcore
  rw [endpointKernel_six_eq_three_sq] at hH
  unfold highShoulderWeight at hH
  nlinarith only [hH,hp]

lemma highShoulder_fraction_bound {N : ℕ} (hN : 0<N) {s f ω x : ℝ}
    (hs : 0<s) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) :
    x^s*endpointKernel N 6 x/(1-highShoulder N s f ω x) ≤
      x^s*endpointKernel N 3 x/(1-f+f*endpointKernel N 3 x) := by
  have hR0 := endpointKernel_nonneg N 3 x
  have hρ : 0<1-f := by linarith
  have hD0 : 0<1-f+f*endpointKernel N 3 x := by positivity
  have hH := (highShoulder_range hN hs hf hf1.le hω hx hx1).2
  have hD1 : 0<1-highShoulder N s f ω x := by linarith only [hH,hω1]
  have hres := highShoulder_three_reserve hN hs hf hf1.le hω hω1.le hx hx1
  apply (div_le_div_iff₀ hD1 hD0).mpr
  rw [endpointKernel_six_eq_three_sq]
  have hm := mul_le_mul_of_nonneg_left hres (mul_nonneg (Real.rpow_nonneg hx s) hR0)
  nlinarith only [hm]

/-- Sharp high normalizer upper bound is uniform in omega up to one. -/
theorem highNormalizer_sharp_upper {N : ℕ} (hN : 2≤N) {s f ω : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1) :
    (N:ℝ)^(2*s)*highNormalizer N s f ω ≤ (endpointReserveConstant f*s)^s := by
  have hNp : 0<(N:ℝ)^(2*s) := Real.rpow_pos_of_pos (by exact_mod_cast (show 0<N by omega)) _
  have hsup : highNormalizer N s f ω ≤ (endpointReserveConstant f*s)^s/(N:ℝ)^(2*s) := by
    unfold highNormalizer coupledNormalizer
    apply csSup_le (Set.image_nonempty.mpr (show (Icc (0:ℝ) 1).Nonempty from ⟨0,⟨le_rfl,zero_le_one⟩⟩))
    rintro z ⟨x,hx,rfl⟩
    have hq := highShoulder_fraction_bound (by omega : 0<N) hs hf hf1 hω hω1 hx.1 hx.2
    have hm := mul_le_mul_of_nonneg_left hq hNp.le
    have hraw := endpointKernel_fraction_sharp_upper (d:=3) hN (by norm_num) hs hs1 hf hf1 hx.1 hx.2
    apply (le_div_iff₀ hNp).mpr
    nlinarith only [hm,hraw]
  have hm := (le_div_iff₀ hNp).mp hsup
  nlinarith only [hm]

end Renyi
