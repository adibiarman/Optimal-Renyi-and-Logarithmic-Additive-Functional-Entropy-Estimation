import Renyi.TwoPoint
import Mathlib.MeasureTheory.Integral.Bochner.Set

/-!
# Testing with priors on i.i.d. probability vectors

The latent space may be arbitrary, so this includes continuous and countably
supported priors. Mixture probabilities are actual integrals of the i.i.d.
sample likelihood. No conclusion about the calibrated priors is assumed.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory
namespace Renyi

theorem simplex_mass_le_one {k : ℕ} (p : Simplex k) (i : Fin k) :
    p.mass i ≤ 1 := by
  have h := Finset.single_le_sum (s := Finset.univ) (f := p.mass)
    (fun j _ => p.nonneg j) (Finset.mem_univ i)
  simpa only [p.normalized] using h

theorem iidMass_le_one {k n : ℕ} (p : Simplex k) (x : Sample k n) :
    iidMass p n x ≤ 1 := by
  apply Finset.prod_le_one
  · intro j _
    exact p.nonneg (x j)
  · intro j _
    exact simplex_mass_le_one p (x j)

/-- Coordinatewise measurability suffices for integrability of all likelihoods. -/
theorem iidMass_integrable {Ω : Type*} [MeasurableSpace Ω] {k n : ℕ}
    (μ : Measure Ω) [IsProbabilityMeasure μ] (p : Ω → Simplex k)
    (hp : ∀ i, Measurable (fun ω => (p ω).mass i)) (x : Sample k n) :
    Integrable (fun ω => iidMass (p ω) n x) μ := by
  have hm : Measurable (fun ω => iidMass (p ω) n x) := by
    unfold iidMass
    fun_prop
  apply (integrable_const (1 : ℝ)).mono' hm.aestronglyMeasurable
  filter_upwards [] with ω
  rw [Real.norm_eq_abs, abs_of_nonneg (iidMass_nonneg (p ω) x)]
  exact iidMass_le_one (p ω) x

theorem entropy_measurable {Ω : Type*} [MeasurableSpace Ω] {k : ℕ}
    (p : Ω → Simplex k) (α : ℝ)
    (hp : ∀ i, Measurable (fun ω => (p ω).mass i)) :
    Measurable (fun ω => entropy (p ω) α) := by
  unfold entropy entropyFromPower powerSum
  fun_prop

def mixtureMass {Ω : Type*} [MeasurableSpace Ω] {k : ℕ}
    (μ : Measure Ω) (p : Ω → Simplex k) (n : ℕ) (x : Sample k n) : ℝ :=
  ∫ ω, iidMass (p ω) n x ∂μ

theorem mixtureMass_nonneg {Ω : Type*} [MeasurableSpace Ω] {k n : ℕ}
    (μ : Measure Ω) (p : Ω → Simplex k) (x : Sample k n) :
    0 ≤ mixtureMass μ p n x := integral_nonneg (fun ω => iidMass_nonneg (p ω) x)

theorem mixtureMass_sum {Ω : Type*} [MeasurableSpace Ω] {k n : ℕ}
    (μ : Measure Ω) [IsProbabilityMeasure μ] (p : Ω → Simplex k)
    (hp : ∀ x : Sample k n, Integrable (fun ω => iidMass (p ω) n x) μ) :
    ∑ x, mixtureMass μ p n x = 1 := by
  unfold mixtureMass
  rw [← integral_finset_sum _ (fun x _ => hp x)]
  simp only [iidMass_sum]
  simp

/-- An exceptional set in the prior costs at most its probability in test error. -/
theorem mixture_test_error_bound {Ω : Type*} [MeasurableSpace Ω] {k n : ℕ}
    (μ : Measure Ω) [IsProbabilityMeasure μ] (p : Ω → Simplex k)
    (hp : ∀ x : Sample k n, Integrable (fun ω => iidMass (p ω) n x) μ)
    (t : Sample k n → ℝ) (ht1 : ∀ x, t x ≤ 1)
    (bad : Set Ω) (hbad : MeasurableSet bad) {δ : ℝ} (hδ : 0 ≤ δ)
    (hgood : ∀ ω, ω ∉ bad → ∑ x, iidMass (p ω) n x * t x ≤ δ) :
    ∑ x, mixtureMass μ p n x * t x ≤ δ + μ.real bad := by
  have hf : Integrable (fun ω => ∑ x, iidMass (p ω) n x * t x) μ :=
    integrable_finset_sum _ (fun x _ => (hp x).mul_const (t x))
  have hg : Integrable (fun ω => δ + bad.indicator (fun _ => (1 : ℝ)) ω) μ :=
    (integrable_const δ).add ((integrable_const 1).indicator hbad)
  have hpoint : ∀ ω, (∑ x, iidMass (p ω) n x * t x) ≤
      δ + bad.indicator (fun _ => (1 : ℝ)) ω := by
    intro ω
    by_cases hω : ω ∈ bad
    · have hsum : (∑ x, iidMass (p ω) n x * t x) ≤ 1 := by
        calc
          (∑ x, iidMass (p ω) n x * t x) ≤ ∑ x, iidMass (p ω) n x * 1 :=
            Finset.sum_le_sum (fun x _ => mul_le_mul_of_nonneg_left (ht1 x)
              (iidMass_nonneg (p ω) x))
          _ = 1 := by simpa using iidMass_sum (p ω) n
      simp only [Set.indicator_of_mem hω]
      linarith
    · simpa only [Set.indicator_of_notMem hω, add_zero] using hgood ω hω
  have hint := integral_mono hf hg hpoint
  rw [integral_add (integrable_const δ) ((integrable_const 1).indicator hbad),
    integral_indicator_const (1 : ℝ) hbad] at hint
  simp only [integral_const, smul_eq_mul, mul_one] at hint
  have huniv : μ.real Set.univ = 1 := by simp [Measure.real]
  rw [huniv, one_mul] at hint
  rw [integral_finset_sum _ (fun x _ => (hp x).mul_const (t x))] at hint
  simpa only [integral_mul_const, mixtureMass] using hint

/-- Correct-center concentration makes the upper-half decision a correct test
whenever the entropy estimator succeeds under the lower hypothesis. -/
theorem center_test_error_left {k n : ℕ} (p : Simplex k) (est : Estimator k n)
    (α ε τ c₀ c₁ : ℝ) (hgap : 2 * (ε + τ) < c₁ - c₀)
    (hcenter : |entropy p α - c₀| ≤ τ) :
    (∑ x, iidMass p n x * (est x (Set.Ioi ((c₀ + c₁) / 2)) : ℝ)) ≤
      errorProbability p α ε est := by
  have hsub : Set.Ioi ((c₀ + c₁) / 2) ⊆ {z : ℝ | ε < |z - entropy p α|} := by
    intro z hz
    by_contra h
    have haccurate : |z - entropy p α| ≤ ε := le_of_not_gt h
    have hzerr := (abs_le.mp haccurate).2
    have hc := (abs_le.mp hcenter).2
    change (c₀ + c₁) / 2 < z at hz
    linarith
  apply Finset.sum_le_sum
  intro x _
  apply mul_le_mul_of_nonneg_left _ (iidMass_nonneg p x)
  exact_mod_cast (est x).apply_mono hsub

/-- Corresponding test-error bound under the upper hypothesis. -/
theorem center_test_error_right {k n : ℕ} (p : Simplex k) (est : Estimator k n)
    (α ε τ c₀ c₁ : ℝ) (hgap : 2 * (ε + τ) < c₁ - c₀)
    (hcenter : |entropy p α - c₁| ≤ τ) :
    (∑ x, iidMass p n x * (1 - (est x (Set.Ioi ((c₀ + c₁) / 2)) : ℝ))) ≤
      errorProbability p α ε est := by
  let upper := Set.Ioi ((c₀ + c₁) / 2)
  have hsub : upperᶜ ⊆ {z : ℝ | ε < |z - entropy p α|} := by
    intro z hz
    by_contra h
    have haccurate : |z - entropy p α| ≤ ε := le_of_not_gt h
    have hzerr := (abs_le.mp haccurate).1
    have hc := (abs_le.mp hcenter).1
    change ¬ (c₀ + c₁) / 2 < z at hz
    have hzle := le_of_not_gt hz
    linarith
  apply Finset.sum_le_sum
  intro x _
  apply mul_le_mul_of_nonneg_left _ (iidMass_nonneg p x)
  have hcomp : (est x upper : ℝ) + (est x upperᶜ : ℝ) = 1 := by
    simpa only [ProbabilityMeasure.measureReal_eq_coe_coeFn,
      ProbabilityMeasure.coeFn_univ, NNReal.coe_one] using
      (measureReal_add_measureReal_compl (μ := (est x : Measure ℝ)) measurableSet_Ioi)
  have hmono : (est x upperᶜ : ℝ) ≤
      (est x {z : ℝ | ε < |z - entropy p α|} : ℝ) := by
    exact_mod_cast (est x).apply_mono hsub
  change 1 - (est x upper : ℝ) ≤ _
  linarith

/-- The full separated-centers testing lower bound, for arbitrary latent priors.
Integrability of finite likelihood coordinates and measurable exceptional sets
are explicit technical hypotheses. No finite-support assumption is imposed. -/
theorem prior_testing_lower_bound
    {Ω₀ Ω₁ : Type*} [MeasurableSpace Ω₀] [MeasurableSpace Ω₁] {k n : ℕ}
    (μ₀ : Measure Ω₀) (μ₁ : Measure Ω₁)
    [IsProbabilityMeasure μ₀] [IsProbabilityMeasure μ₁]
    (p₀ : Ω₀ → Simplex k) (p₁ : Ω₁ → Simplex k)
    (hp₀ : ∀ x : Sample k n, Integrable (fun ω => iidMass (p₀ ω) n x) μ₀)
    (hp₁ : ∀ x : Sample k n, Integrable (fun ω => iidMass (p₁ ω) n x) μ₁)
    (est : Estimator k n) (α ε τ c₀ c₁ d η₀ η₁ δ : ℝ)
    (hδ : 0 ≤ δ)
    (hest : ∀ p : Simplex k, errorProbability p α ε est ≤ δ)
    (hgap : 2 * (ε + τ) < c₁ - c₀)
    (hTV : finiteTV (mixtureMass μ₀ p₀ n) (mixtureMass μ₁ p₁ n) ≤ d)
    (hm₀ : MeasurableSet {ω | τ < |entropy (p₀ ω) α - c₀|})
    (hm₁ : MeasurableSet {ω | τ < |entropy (p₁ ω) α - c₁|})
    (hη₀ : μ₀.real {ω | τ < |entropy (p₀ ω) α - c₀|} ≤ η₀)
    (hη₁ : μ₁.real {ω | τ < |entropy (p₁ ω) α - c₁|} ≤ η₁) :
    (1 - d) / 2 - (η₀ + η₁) / 2 ≤ δ := by
  let t : Sample k n → ℝ := fun x => (est x (Set.Ioi ((c₀ + c₁) / 2)) : ℝ)
  have ht0 : ∀ x, 0 ≤ t x := fun _ => NNReal.coe_nonneg _
  have ht1 : ∀ x, t x ≤ 1 := by
    intro x
    exact_mod_cast (est x).apply_le_one (Set.Ioi ((c₀ + c₁) / 2))
  have hlower := finite_testing_lower_bound (mixtureMass μ₀ p₀ n)
    (mixtureMass μ₁ p₁ n) t (mixtureMass_sum μ₀ p₀ hp₀)
    (mixtureMass_sum μ₁ p₁ hp₁) ht0 ht1
  have hleft := mixture_test_error_bound μ₀ p₀ hp₀ t ht1
    {ω | τ < |entropy (p₀ ω) α - c₀|} hm₀ hδ (by
      intro ω hω
      exact (center_test_error_left (p₀ ω) est α ε τ c₀ c₁ hgap
        (le_of_not_gt hω)).trans (hest (p₀ ω)))
  have hright := mixture_test_error_bound μ₁ p₁ hp₁ (fun x => 1 - t x)
    (fun x => by linarith [ht0 x])
    {ω | τ < |entropy (p₁ ω) α - c₁|} hm₁ hδ (by
      intro ω hω
      exact (center_test_error_right (p₁ ω) est α ε τ c₀ c₁ hgap
        (le_of_not_gt hω)).trans (hest (p₁ ω)))
  rw [Finset.sum_add_distrib] at hlower
  linarith

/-- The source lemma with its symmetric separation condition. -/
theorem prior_testing_lower_bound_abs
    {Ω₀ Ω₁ : Type*} [MeasurableSpace Ω₀] [MeasurableSpace Ω₁] {k n : ℕ}
    (μ₀ : Measure Ω₀) (μ₁ : Measure Ω₁)
    [IsProbabilityMeasure μ₀] [IsProbabilityMeasure μ₁]
    (p₀ : Ω₀ → Simplex k) (p₁ : Ω₁ → Simplex k)
    (hp₀ : ∀ i, Measurable (fun ω => (p₀ ω).mass i))
    (hp₁ : ∀ i, Measurable (fun ω => (p₁ ω).mass i))
    (est : Estimator k n) (α ε τ c₀ c₁ d η₀ η₁ δ : ℝ)
    (hδ : 0 ≤ δ)
    (hest : ∀ p : Simplex k, errorProbability p α ε est ≤ δ)
    (hgap : 2 * (ε + τ) < |c₁ - c₀|)
    (hTV : finiteTV (mixtureMass μ₀ p₀ n) (mixtureMass μ₁ p₁ n) ≤ d)
    (hη₀ : μ₀.real {ω | τ < |entropy (p₀ ω) α - c₀|} ≤ η₀)
    (hη₁ : μ₁.real {ω | τ < |entropy (p₁ ω) α - c₁|} ≤ η₁) :
    (1 - d) / 2 - (η₀ + η₁) / 2 ≤ δ := by
  have hm₀ : MeasurableSet {ω | τ < |entropy (p₀ ω) α - c₀|} :=
    measurableSet_lt measurable_const
      (continuous_abs.measurable.comp ((entropy_measurable p₀ α hp₀).sub_const c₀))
  have hm₁ : MeasurableSet {ω | τ < |entropy (p₁ ω) α - c₁|} :=
    measurableSet_lt measurable_const
      (continuous_abs.measurable.comp ((entropy_measurable p₁ α hp₁).sub_const c₁))
  by_cases horder : c₀ ≤ c₁
  · rw [abs_of_nonneg (sub_nonneg.mpr horder)] at hgap
    exact prior_testing_lower_bound μ₀ μ₁ p₀ p₁
      (iidMass_integrable μ₀ p₀ hp₀) (iidMass_integrable μ₁ p₁ hp₁)
      est α ε τ c₀ c₁ d η₀ η₁ δ hδ hest hgap hTV hm₀ hm₁ hη₀ hη₁
  · rw [abs_of_nonpos (by linarith : c₁ - c₀ ≤ 0)] at hgap
    have hTVswap : finiteTV (mixtureMass μ₁ p₁ n) (mixtureMass μ₀ p₀ n) ≤ d := by
      simpa only [finiteTV, abs_sub_comm] using hTV
    have h := prior_testing_lower_bound μ₁ μ₀ p₁ p₀
      (iidMass_integrable μ₁ p₁ hp₁) (iidMass_integrable μ₀ p₀ hp₀)
      est α ε τ c₁ c₀ d η₁ η₀ δ hδ hest (by linarith) hTVswap hm₁ hm₀ hη₁ hη₀
    linarith

end Renyi
