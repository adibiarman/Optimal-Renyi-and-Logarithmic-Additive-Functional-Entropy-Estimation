import Renyi.NearOneVarianceExponential
import Renyi.NearOneSourceGeometry

/-! Source-rate calibration of the actual near-one variance budget.
The logarithmic slope is chosen before the final exposure multiplier D. -/
set_option maxHeartbeats 150000
noncomputable section
open scoped BigOperators NNReal
namespace Renyi

theorem near_one_variance_budget_source_calibrated {eps CL K cp B eta : ℝ}
    (heps : 0<eps) (hCL : 1≤CL) (hK : 0<K) (hcp : 0≤cp) (hB : 0≤B) (heta : 0<eta) :
    ∃ cL : ℝ, 0<cL ∧ cL≤1 ∧ ∀ D : ℝ, 0<D → ∃ k0 : ℕ,
      ∀ k : ℕ, k0≤k → ∀ alpha : ℝ, 1<alpha → alpha≤3/2 → ∀ p : Simplex k,
      let n := upperSample k alpha eps D
      let LN := upperDegree alpha CL cL (rootMultiplier k alpha eps)
      let L := (LN : ℝ)
      let b := upperB k alpha eps D 1 CL cL
      let t := b/L^2
      nearOneHybridVarianceBudget (simplexPoissonMeans n p) n t b (alpha-1)
        (K*Real.exp (K*L)) eps K (cp*B*alpha) 20 (20*LN) ≤
          eta*(alpha-1)^2*(powerSum p alpha)^2 := by
  let E := nearOneVarianceExponent K
  have hE : 0<E := by dsimp [E,nearOneVarianceExponent]; linarith
  let cL := min 1 (1/(72*E))
  have hcL : 0<cL := lt_min (by norm_num) (by positivity)
  have hcL1 : cL≤1 := min_le_left _ _
  have hcLsmall : (3/2:ℝ)*(8*E)*cL≤(1/6:ℝ) := by
    have hh := mul_le_mul_of_nonneg_left (min_le_right (1:ℝ) (1/(72*E))) (by positivity : 0≤(3/2:ℝ)*(8*E))
    dsimp [cL]
    convert hh using 1; field_simp; ring
  refine ⟨cL,hcL,hcL1,?_⟩
  intro D hD
  obtain ⟨G,hG,kgeom,hgeom⟩ := near_one_source_geometry (eps := eps) (CL := CL) (D := D) heps hCL hD
  let T0 := cp*B*(3/2:ℝ)
  let Lo := (6:ℝ)^6*Real.exp (Real.exp 1-1)*gammaResidualPilotConstant eps^2
  let Se := (6:ℝ)^6*Real.exp T0*gammaResidualPilotConstant eps^2
  let CG := nearOneGammaAggregateConstant eps
  let C := 1+G+K^2+CG+Lo+Se+K^2*Real.exp T0
  have hG0 : 0≤G := by linarith
  have hCG0 : 0≤CG := by dsimp [CG,nearOneGammaAggregateConstant,orderOneNoiseConstant]; positivity
  have hLo : 0≤Lo := by dsimp [Lo]; positivity
  have hSe : 0≤Se := by dsimp [Se]; positivity
  have hKA0 : 0≤K^2*Real.exp T0 := by positivity
  have hC : 1≤C := by dsimp [C]; linarith only [hG0,hCG0,hLo,hSe,sq_nonneg K,hKA0]
  have hGC : G≤C := by dsimp [C]; nlinarith only [hCG0,hLo,hSe,sq_nonneg K,hKA0]
  have hKC : K^2≤C := by dsimp [C]; nlinarith only [hG0,hCG0,hLo,hSe,sq_nonneg K,hKA0]
  have hCGC : nearOneGammaAggregateConstant eps≤C := by change CG≤C; dsimp [C]; nlinarith only [hG0,hLo,hSe,sq_nonneg K,hKA0]
  have hLoC : Lo≤C := by dsimp [C]; nlinarith only [hG0,hCG0,hSe,sq_nonneg K,hKA0]
  have hSeC : Se≤C := by dsimp [C]; nlinarith only [hG0,hCG0,hLo,sq_nonneg K,hKA0]
  have hAC : K^2*Real.exp T0≤C := by dsimp [C]; nlinarith only [hG0,hCG0,hLo,hSe,sq_nonneg K]
  clear_value C
  let CE := Real.exp ((8*E)*(3/2:ℝ)*(CL+1+Real.log 3))
  have hCE : 0<CE := Real.exp_pos _
  obtain ⟨kdecay,hdecay⟩ := near_one_log_power_decay 16
    (C := 100*C^8*CE) (r := (1/2:ℝ)) (eta := eta) (by positivity) (by norm_num) heta
  refine ⟨max kgeom kdecay,?_⟩
  intro k hk alpha ha ha1 p
  have hgg := hgeom cL hcL hcL1 k ((le_max_left _ _).trans hk) alpha ha ha1
  dsimp only at hgg ⊢
  rcases hgg with ⟨hkpos,hn1,hL1,hkn,hkb,hd,hlognt,hlogt⟩
  let n := upperSample k alpha eps D
  let LN := upperDegree alpha CL cL (rootMultiplier k alpha eps)
  let L := (LN:ℝ)
  let b := upperB k alpha eps D 1 CL cL
  let t := b/L^2
  have hn : 0<n := by linarith only [hn1]
  have hL : 0<L := by linarith only [hL1]
  have hg := (near_one_order ha ha1).2
  have hg0 : 0<fractionalPart alpha := by rw [hg]; linarith
  have hg1 : fractionalPart alpha<1 := by rw [hg]; linarith
  have hb : 0<b := upperB_pos hkpos ha hg0 hg1 hD (by norm_num) hCL hcL
  have ht : 0<t := div_pos hb (sq_pos_of_pos hL)
  have htb : t≤b := by
    apply (div_le_iff₀ (sq_pos_of_pos hL)).2
    have hs : (1:ℝ)≤L^2 := by nlinarith only [hL1]
    nlinarith only [mul_le_mul_of_nonneg_left hs hb.le]
  have hnb : n*b=L := by
    change n*(1*L/n)=L
    field_simp
  have hnt : n*t≤1 := by
    have heq : n*t=1/L := by dsimp [t]; rw [← mul_div_assoc,hnb]; field_simp
    rw [heq]
    exact (div_le_one hL).2 hL1
  have hbudget := near_one_budget_exponential_envelope (k := k) (l := LN) (a := alpha) (n := n) (b := b) (t := t) (K := K) (Cw := eps) (cp := cp) (B := B) (C := C) (G := G) hkpos p ha ha1 hn hb ht htb hnt hK hcp hB hL1 hC
    ⟨hkn,hkb,hd,hlognt,hlogt⟩ hGC hKC hCGC hLoC hSeC hAC
  have hexp := near_one_exp_degree_bound (k := k) (alpha := alpha) (eps := eps) (CL := CL) (cL := cL) (C := 8*E) (r := (1/6:ℝ)) hkpos ha ha1 heps hCL hcL hcL1
    (show 0≤8*E by positivity) hcLsmall
  have hk0 : (0:ℝ)<k := by exact_mod_cast hkpos
  have hkpow : (k:ℝ)^(1/6:ℝ)/(k:ℝ)^(2/3:ℝ)=1/(k:ℝ)^(1/2:ℝ) := by
    rw [← Real.rpow_sub hk0]
    norm_num
    rw [Real.rpow_neg hk0.le,one_div]
  have hh := mul_le_mul_of_nonneg_left hexp
    (by positivity : 0≤100*(alpha-1)^2*(powerSum p alpha)^2*C^8*nearOneLogWeight k^16/(k:ℝ)^(2/3:ℝ))
  have hbudget' : nearOneHybridVarianceBudget (simplexPoissonMeans n p) n t b (alpha-1)
      (K*Real.exp (K*L)) eps K (cp*B*alpha) 20 (20*LN) ≤
      (alpha-1)^2*(powerSum p alpha)^2 * (100*C^8*CE*nearOneLogWeight k^16/(k:ℝ)^(1/2:ℝ)) := by
    refine hbudget.trans ?_
    calc
      _ ≤ (100*(alpha-1)^2*(powerSum p alpha)^2*C^8*nearOneLogWeight k^16/(k:ℝ)^(2/3:ℝ)) *
        (CE*(k:ℝ)^(1/6:ℝ)) := by convert hh using 1; ring
      _ = _ := by
        have heq : (100*(alpha-1)^2*(powerSum p alpha)^2*C^8*nearOneLogWeight k^16/(k:ℝ)^(2/3:ℝ)) *
            (CE*(k:ℝ)^(1/6:ℝ)) = (alpha-1)^2*(powerSum p alpha)^2*(100*C^8*CE*nearOneLogWeight k^16)*
              ((k:ℝ)^(1/6:ℝ)/(k:ℝ)^(2/3:ℝ)) := by ring
        rw [heq,hkpow]
        ring
  have hsmall := hdecay k ((le_max_right _ _).trans hk)
  have hlast := mul_le_mul_of_nonneg_left hsmall (by positivity : 0≤(alpha-1)^2*(powerSum p alpha)^2)
  exact hbudget'.trans (by nlinarith only [hlast])

end Renyi
