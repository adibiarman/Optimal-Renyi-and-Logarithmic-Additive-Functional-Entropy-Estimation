import Renyi.CoupledRaisedFloors
import Renyi.EndpointDefectProduct

/-! Complete raised q floors for the actual low and high endpoint profiles. -/
noncomputable section
open Set
namespace Renyi

def raisedFloorOrder (f q : ℝ) : ℝ := (f-q)/(2*endpointDefectConstant)
def raisedFloorTailScale (f q : ℝ) : ℝ := max 1 (endpointTailDefectConstant/(f-q))
def raisedFloorScale (f q : ℝ) : ℝ :=
  max (endpointReserveConstant f) (raisedFloorTailScale f q/raisedFloorOrder f q)

lemma raisedFloorOrder_pos {f q : ℝ} (hqf : q<f) : 0<raisedFloorOrder f q := by
  exact div_pos (sub_pos.mpr hqf) (mul_pos (by norm_num) endpointDefectConstant_pos)

lemma raisedFloorScale_pos {f q : ℝ} (hf1 : f<1) : 0<raisedFloorScale f q :=
  (endpointReserveConstant_pos hf1).trans_le (le_max_left _ _)

lemma raisedFloor_large_scale {s f q y : ℝ} (hqf : q<f)
    (hs : raisedFloorOrder f q≤s) (hy : raisedFloorScale f q*s≤y) :
    raisedFloorTailScale f q≤y := by
  have hs0 := raisedFloorOrder_pos hqf
  have hT : 0<raisedFloorTailScale f q := zero_lt_one.trans_le (le_max_left _ _)
  have hspos : 0≤s := hs0.le.trans hs
  have h1 := mul_le_mul_of_nonneg_right
    (show raisedFloorTailScale f q/raisedFloorOrder f q≤raisedFloorScale f q from le_max_right _ _) hspos
  have h2 := mul_le_mul_of_nonneg_left hs (div_pos hT hs0).le
  have hid : raisedFloorTailScale f q/raisedFloorOrder f q*raisedFloorOrder f q=raisedFloorTailScale f q := by field_simp
  rw [hid] at h2
  linarith only [h1,h2,hy]

lemma raisedFloor_small_budget {s f q : ℝ} (hqf : q<f) (hs : s≤raisedFloorOrder f q) :
    q≤f-endpointDefectConstant*s := by
  have hm := mul_le_mul_of_nonneg_left hs endpointDefectConstant_pos.le
  have hid : endpointDefectConstant*raisedFloorOrder f q=(f-q)/2 := by
    unfold raisedFloorOrder
    field_simp [endpointDefectConstant_pos.ne']
  rw [hid] at hm
  linarith only [hm,hqf]

lemma raisedFloor_tail_budget {f q y : ℝ} (hqf : q<f) (hy : raisedFloorTailScale f q≤y) :
    1≤y ∧ q≤f-endpointTailDefectConstant/y := by
  have hy1 : 1≤y := (le_max_left _ _).trans hy
  have hy0 : 0<y := zero_lt_one.trans_le hy1
  have hgap : 0<f-q := sub_pos.mpr hqf
  have hfrac : endpointTailDefectConstant/(f-q)≤y := (le_max_right _ _).trans hy
  have hm := (div_le_iff₀ hgap).mp hfrac
  have hbudget : endpointTailDefectConstant/y≤f-q := by
    apply (div_le_iff₀ hy0).mpr
    nlinarith only [hm]
  exact ⟨hy1,by linarith only [hbudget]⟩

/-- Complete fixed-q floor for the actual raised low profile. -/
theorem lowProfile_raised_floor {N : ℕ} (hN : 2≤N) {s f q x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hqf : q<f)
    (hx : 0≤x) (hx1 : x≤1) (hy : raisedFloorScale f q*s≤(N:ℝ)^2*x) :
    q≤lowProfile N s f x := by
  have hN0 : 0<N := by omega
  have hcf : endpointReserveConstant f*s≤(N:ℝ)^2*x :=
    (mul_le_mul_of_nonneg_right (le_max_left _ _) hs.le).trans hy
  by_cases hsmall : s≤raisedFloorOrder f q
  · have hred := lowProfile_floor_reduction hN hs hs1 hf hf1 hx hx1 hcf
    have hdef := endpointProfile_kernel_defect_product hN0 (by norm_num : 2≤2) (by norm_num : 2≤6) hs hs1 hx hx1
    have hb := raisedFloor_small_budget hqf hsmall
    linarith only [hred,hdef,hb]
  · have hY := raisedFloor_large_scale hqf (le_of_lt (lt_of_not_ge hsmall)) hy
    have hbudget := raisedFloor_tail_budget hqf hY
    have hxpos : 0<x := by
      by_contra hxnot
      have hp := mul_nonpos_of_nonneg_of_nonpos (sq_nonneg (N:ℝ)) (le_of_not_gt hxnot)
      nlinarith only [hp,hbudget.1]
    exact hbudget.2.trans (lowProfile_tail_lower hN0 hs hs1 hf hf1 hxpos hx1 hbudget.1)

/-- Complete high-profile q*omega floor, uniform in omega. -/
theorem highProfile_raised_floor {N : ℕ} (hN : 2≤N) {s f q ω x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hqf : q<f) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : raisedFloorScale f q*s≤(N:ℝ)^2*x) :
    q*ω≤highProfile N s f ω x := by
  have hN0 : 0<N := by omega
  have hcf : endpointReserveConstant f*s≤(N:ℝ)^2*x :=
    (mul_le_mul_of_nonneg_right (le_max_left _ _) hs.le).trans hy
  by_cases hsmall : s≤raisedFloorOrder f q
  · have hred := highProfile_floor_reduction hN hs hs1 hf hf1 hω hω1 hx hx1 hcf
    have hdef := endpointProfile_kernel_defect_product hN0 (by norm_num : 2≤6) (by norm_num : 6≤6) hs hs1 hx hx1
    have hb := raisedFloor_small_budget hqf hsmall
    have hωb := mul_le_mul_of_nonneg_left hb hω
    have hωd := mul_le_mul_of_nonneg_left hdef hω
    nlinarith only [hred,hωb,hωd]
  · have hY := raisedFloor_large_scale hqf (le_of_lt (lt_of_not_ge hsmall)) hy
    have hbudget := raisedFloor_tail_budget hqf hY
    have hxpos : 0<x := by
      by_contra hxnot
      have hp := mul_nonpos_of_nonneg_of_nonpos (sq_nonneg (N:ℝ)) (le_of_not_gt hxnot)
      nlinarith only [hp,hbudget.1]
    have hωb := mul_le_mul_of_nonneg_left hbudget.2 hω
    have htail := highProfile_tail_lower hN0 hs hs1 hf hf1 hω hω1 hxpos hx1 hbudget.1
    nlinarith only [hωb,htail]

end Renyi
