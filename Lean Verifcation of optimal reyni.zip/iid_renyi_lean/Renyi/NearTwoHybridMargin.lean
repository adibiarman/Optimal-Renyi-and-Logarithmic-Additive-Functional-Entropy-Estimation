import Renyi.ActualNearTwoEndpointMargin

/-! The actual near-two endpoint reserve survives arbitrary light/heavy assignments. -/
noncomputable section
open scoped BigOperators
namespace Renyi

lemma two_arm_margin_le_strict_margin {a theta h ell p : ℝ}
    (ha : 0 ≤ a) (htheta : 0 ≤ theta) (hh : 0 ≤ h) (hell : 1 ≤ ell)
    (hp : 0 ≤ p) :
    min (a / p + theta * p) 1 ≤
      min (h + theta * p + min (ell ^ 2 * (a / p)) 1) 1 := by
  have hratio : 0 ≤ a / p := div_nonneg ha hp
  have hellsq : 1 ≤ ell ^ 2 := by nlinarith only [hell]
  have hlow := mul_le_mul_of_nonneg_right hellsq hratio
  simp only [one_mul] at hlow
  by_cases hs : 1 ≤ ell ^ 2 * (a / p)
  · rw [min_eq_right hs]
    have hrhs : min (h + theta * p + 1) 1 = 1 :=
      min_eq_right (by nlinarith [mul_nonneg htheta hp])
    rw [hrhs]
    exact min_le_right _ _
  · rw [min_eq_left (le_of_lt (lt_of_not_ge hs))]
    exact min_le_min (by nlinarith only [hlow, hh]) (le_refl _)

lemma hybrid_endpoint_margin_dominates_two_arm {k : ℕ} (p : Simplex k)
    (light : Fin k → Bool) {alpha a theta h ell c w : ℝ}
    (ha : 0 ≤ a) (htheta : 0 ≤ theta) (hh : 0 ≤ h) (hell : 1 ≤ ell)
    (hc : 0 ≤ c) (hw : 0 ≤ w) :
    min c w * (∑ i, if a ≤ p.mass i then
      p.mass i ^ alpha * min (a / p.mass i + theta * p.mass i) 1 else 0) ≤
      c * (∑ i, if light i then if a ≤ p.mass i then
        p.mass i ^ alpha * min (h + theta * p.mass i + min (ell ^ 2 * (a / p.mass i)) 1) 1
          else 0 else 0) + w * (∑ i, if light i then 0 else p.mass i ^ alpha) := by
  have hcw : 0 ≤ min c w := le_min hc hw
  have hpoint (i : Fin k) :
      min c w * (if a ≤ p.mass i then
        p.mass i ^ alpha * min (a / p.mass i + theta * p.mass i) 1 else 0) ≤
      c * (if light i then if a ≤ p.mass i then
        p.mass i ^ alpha * min (h + theta * p.mass i + min (ell ^ 2 * (a / p.mass i)) 1) 1
          else 0 else 0) + w * (if light i then 0 else p.mass i ^ alpha) := by
    have hpα := Real.rpow_nonneg (p.nonneg i) alpha
    have hbase : 0 ≤ min (a / p.mass i + theta * p.mass i) 1 :=
      le_min (add_nonneg (div_nonneg ha (p.nonneg i)) (mul_nonneg htheta (p.nonneg i))) zero_le_one
    by_cases hl : light i = true
    · by_cases hi : a ≤ p.mass i
      · simp only [hl, hi, ite_true, mul_zero, add_zero]
        exact mul_le_mul (min_le_left c w)
          (mul_le_mul_of_nonneg_left (two_arm_margin_le_strict_margin ha htheta hh hell (p.nonneg i)) hpα)
          (mul_nonneg hpα hbase) hc
      · simp only [hl, hi, ite_true, ite_false, mul_zero, add_zero, le_refl]
    · have hl' : light i = false := Bool.eq_false_iff.mpr hl
      simp only [hl', Bool.false_eq_true, ite_false, mul_zero, zero_add]
      split
      · exact (mul_le_mul_of_nonneg_left
          (mul_le_of_le_one_right hpα (min_le_right _ _)) hcw).trans
          (mul_le_mul_of_nonneg_right (min_le_right c w) hpα)
      · simpa only [mul_zero] using mul_nonneg hw hpα
  have hs := Finset.sum_le_sum (fun i (_hi : i ∈ Finset.univ) => hpoint i)
  simpa only [Finset.sum_add_distrib, Finset.mul_sum] using hs

/-- The actual source cutoffs provide a summed strict reserve, for every assignment. -/
theorem upper_actual_hybrid_endpoint_margin_near_two {eps Ch cb lambda CL cL : ℝ}
    (heps : 0 < eps) (hCh : 0 ≤ Ch) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) :
    ∃ D0 : ℝ, 1 ≤ D0 ∧ ∀ (k : ℕ) (alpha D ell c w : ℝ),
      0 < k → 3 / 2 ≤ alpha → alpha < 2 → D0 ≤ D → 1 ≤ ell → 0 ≤ c → 0 ≤ w →
      ∀ (p : Simplex k) (light : Fin k → Bool),
      let a := upperA k alpha eps Ch D cb lambda CL cL
      let b := upperB k alpha eps D cb CL cL
      let N := upperDegree alpha CL cL (rootMultiplier k alpha eps)
      min c w * (nearTwoEndpointConstant eps lambda / 2) * a ^ (alpha - 1) ≤
        c * (∑ i, if light i then if a ≤ p.mass i then p.mass i ^ alpha *
          min ((alpha - 1) * (1 - (alpha - 1)) + ((N : ℝ) ^ 2 / b) * p.mass i +
            min (ell ^ 2 * (a / p.mass i)) 1) 1 else 0 else 0) +
        w * (∑ i, if light i then 0 else p.mass i ^ alpha) := by
  obtain ⟨D0, hD0, hsource⟩ := upper_actual_endpoint_margin_near_two heps hCh hcb hlambda hCL hcL
  refine ⟨D0, hD0, ?_⟩
  intro k alpha D ell c w hk halpha halpha2 hD hell hc hw p light
  dsimp only
  have ha1 : 1 < alpha := by linarith
  have hm := upperOrderFloor_eq_one_near_two ha1 halpha2
  have hgamma : fractionalPart alpha = alpha - 1 := by
    rw [fractionalPart_eq_upperOrderFloor ha1, hm]; norm_num
  have hg : 0 < fractionalPart alpha := by rw [hgamma]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [hgamma]; linarith
  have hDpos : 0 < D := zero_lt_one.trans_le (hD0.trans hD)
  have hb := upperB_pos hk ha1 hg hg1 hDpos hcb hCL hcL (ε := eps)
  have hdelta : 0 ≤ 1 - fractionalPart alpha := by linarith
  have ha : 0 ≤ upperA k alpha eps Ch D cb lambda CL cL := by
    unfold upperA upperOverlapZ
    positivity
  have hsource' := mul_le_mul_of_nonneg_left (hsource k alpha D hk halpha halpha2 hD p)
    (le_min hc hw)
  have hhybrid := hybrid_endpoint_margin_dominates_two_arm p light
    (alpha := alpha) (theta := (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ^ 2 /
      upperB k alpha eps D cb CL cL) ha (by positivity)
    (mul_nonneg (by linarith : 0 ≤ alpha - 1) (by linarith : 0 ≤ 1 - (alpha - 1))) hell hc hw
  simpa only [mul_assoc] using hsource'.trans hhybrid

end Renyi
