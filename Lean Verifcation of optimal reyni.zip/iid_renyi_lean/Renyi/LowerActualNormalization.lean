import Renyi.LowerPositiveNormalization
import Renyi.LowerActualSecondMoments

/-! Uniform normalization cutoff for priors at the actual root/intensity rule. -/
noncomputable section
open scoped BigOperators NNReal
namespace Renyi
set_option maxHeartbeats 1500000

/-- A single accuracy-dependent alphabet/root cutoff bounds normalization
failure for every actual positive-degree prior with its refined moment. -/
theorem lower_actual_prior_normalization {eps : ℝ} (he : 0<eps) :
    ∃ k₀ : ℕ, ∃ X₀ : ℝ, lowerPriorRootCutoff eps≤X₀ ∧ ∀ k : ℕ, k₀≤k →
      ∀ alpha s : ℝ, 3/2≤alpha → 0<s → s≤1/2 →
      (s=fractionalPart alpha ∨ s=1-fractionalPart alpha) →
      X₀≤rootMultiplier k alpha eps →
      let x := rootMultiplier k alpha eps
      let L : ℝ := Nat.ceil (10*alpha*(1+Real.log x))
      let theta := lowerPriorIntensityConstant eps*alpha*(k:ℝ)^(-1/alpha)*x
      let B := (1/100)*L/theta
      let E := 2*eps*(alpha-1)
      let v := (alpha-1)/alpha*x^(-alpha)
      let w := s*(1-s)+v
      let zeta := lowerPriorCoefficient eps*w/(1-Real.exp (-E))
      ∀ (ι : Type) [Fintype ι] (P : FiniteAtomicPrior ι) (b : ℝ≥0),
      (b:ℝ)=(k:ℝ)/2 →
      (∀ i, P.value i=0 ∨ (1≤P.value i ∧ P.value i≤B)) →
      priorMoment P 1=1 →
      priorMoment P (2*alpha)/(priorMoment P alpha)^2≤lowerPriorSecondConstant eps*zeta^2*B^alpha →
      priorNormalizationMomentBudget b P alpha w≤1/64 := by
  let cn := lowerPriorIntensityConstant eps
  have hcn : 0<cn := Real.exp_pos _
  have hC : 0≤lowerPriorSecondConstant eps := (lowerPriorSecondConstant_pos eps).le
  obtain ⟨K,X,hX,huniform⟩ := prior_normalization_positive_uniform he hC (by norm_num : (0:ℝ)≤1/16)
  let Y := max (lowerPriorRootCutoff eps) (max X ((4*(11*(1/100:ℝ)/cn))^4))
  refine ⟨max 1 K,Y,le_max_left _ _,?_⟩
  intro k hk alpha s ha hs hs1 hnearest hx
  let x := rootMultiplier k alpha eps
  let L : ℝ := Nat.ceil (10*alpha*(1+Real.log x))
  let theta := cn*alpha*(k:ℝ)^(-1/alpha)*x
  let B := (1/100)*L/theta
  let E := 2*eps*(alpha-1)
  let v := (alpha-1)/alpha*x^(-alpha)
  let w := s*(1-s)+v
  let zeta := lowerPriorCoefficient eps*w/(1-Real.exp (-E))
  dsimp only
  intro ι inst P b hb hsupp hmean hsecond
  have hk1 : 1≤k := (le_max_left _ _).trans hk
  have hk0 : 0<k := by omega
  have hkR : (0:ℝ)<k := by exact_mod_cast hk0
  have ha1 : 1<alpha := by linarith
  have ha0 : 0<alpha := by linarith
  have hb0 : 0<alpha-1 := by linarith
  have hroot : lowerPriorRootCutoff eps≤x := (le_max_left _ _).trans hx
  have hx4 : 4≤x := (le_max_left _ _).trans hroot
  have hx1 : 1<x := by linarith
  have hx0 : 0<x := by linarith
  have hL : 0<L := (show 0<10*alpha*(1+Real.log x) by have hh := Real.log_pos hx1; positivity).trans_le (Nat.le_ceil _)
  have htheta : 0<theta := by dsimp [theta]; positivity
  have hB0 : 0<B := by dsimp [B]; positivity
  have hB : 1≤B := by
    have hv (i) : P.value i≤B := (hsupp i).elim (fun h => by rw [h]; exact hB0.le) (fun h => h.2)
    have hh : priorMoment P 1≤B := by
      calc
        _ = ∑ i, P.mass i*P.value i := by simp only [priorMoment,Real.rpow_one]
        _ ≤ ∑ i, P.mass i*B := Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left (hv i) (P.mass_nonneg i))
        _ = B := by rw [←Finset.sum_mul,P.mass_sum,one_mul]
    rwa [hmean] at hh
  have hE : eps≤E := by dsimp [E]; nlinarith
  have hv0 : 0≤v := by dsimp [v]; positivity
  have hw0 : 0<w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv0
  have hzeta0 : 0≤zeta := by
    dsimp [zeta]
    exact div_nonneg (mul_nonneg (lowerPriorCoefficient_bounds he).1.le hw0.le)
      (sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))).le
  have hzeta : zeta≤(1/16)*w := by
    have hh := lower_target_margin_upper he hE hw0.le
    change zeta≤w/16 at hh
    nlinarith only [hh]
  have hgamma : 0<fractionalPart alpha ∧ fractionalPart alpha<1 := by
    rcases hnearest with h | h
    · rw [←h]; constructor <;> linarith
    · have heq : fractionalPart alpha=1-s := by linarith
      rw [heq]; constructor <;> linarith
  have hx2 : 2/eps≤x := (le_trans (le_max_left _ _) (le_max_right _ _)).trans hroot
  have hvelocity := lower_positive_velocity_margin ha he hx1.le hx2
  have hmargin := lower_root_normalization_margin hk0 ha he hs hs1 hgamma.1 hgamma.2 hnearest hx1 hvelocity
  have hcut : (4*(11*(1/100:ℝ)/cn))^4≤x :=
    (le_trans (le_max_right _ _) (le_max_right _ _)).trans hx
  have hpower := lower_support_power_decay ha1.le hx1.le hcn (by norm_num : (0:ℝ)<1/100) hcut
  have hidentity := lower_support_power_identity hkR ha0 hx0 hcn (by norm_num : (0:ℝ)<1/100) hL
  change B^alpha/(k:ℝ)=_ at hidentity
  have hpowerB : B^alpha/(k:ℝ)≤x^(-alpha/2) := hidentity.trans_le hpower
  have hXroot : X≤x := (le_trans (le_max_left _ _) (le_max_right _ _)).trans hx
  exact huniform k ((le_max_right _ _).trans hk) hk1 x alpha B w zeta hXroot ha hB hw0 hzeta0 hmargin hzeta hpowerB ι P b hb hsupp hmean hsecond

end Renyi
