import Renyi.ActualProfileGeometry

/-! The concrete source polynomial with its actual root, cutoffs, resolutions and overlap coefficients. -/
noncomputable section
namespace Renyi

/-- The polynomial before the final common scalar rescaling. -/
def actualCoupledPolynomial (k : ℕ) (alpha eps Ch D cb lambda CL cL fL f M : ℝ) : Polynomial ℝ :=
  let gamma := fractionalPart alpha
  let E := upperE0 k alpha eps Ch
  let z := upperOverlapZ gamma E
  completedCoupledPolynomial (upperLowResolution alpha)
    (upperDegree alpha CL cL (rootMultiplier k alpha eps)) (upperOrderFloor alpha) gamma
    (upperA k alpha eps Ch D cb lambda CL cL) (upperB k alpha eps D cb CL cL)
    (DegreeOneCompletion.coefficient gamma fL) fL f
    (overlapA gamma z*Real.exp (-M*gamma))
    (overlapB gamma z*Real.exp (-M*(1-gamma))) (Real.exp (-E/8))

theorem actualCoupledPolynomial_natDegree {k : ℕ} {alpha eps Ch D cb lambda CL cL fL f M : ℝ}
    (halpha : 1<alpha) :
    (actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).natDegree≤
      upperCountDegree k alpha eps CL cL := by
  exact completedCoupledPolynomial_natDegree (upperOrderFloor_one_le halpha) _ _ _ _ _ _ _ _ _ _ _

/-- The actual source polynomial has the strict deterministic upper margin without a capacity premise. -/
theorem actualCoupledPolynomial_strict_upper {eps fL f : ℝ}
    (heps : 0<eps) (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) :
    ∃ M0 c : ℝ, 1≤M0 ∧ 0<c ∧ ∀ (M : ℝ), M0≤M →
      ∀ (k : ℕ) (alpha Ch D cb lambda CL cL p : ℝ),
        0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 →
        0≤Ch → 0<D → 0<cb → 0<lambda → lambda≤Real.exp (-2*coupledProfileConstant) →
        1≤CL → 0<cL → 1≤cb*CL →
        upperA k alpha eps Ch D cb lambda CL cL≤p → p≤upperB k alpha eps D cb CL cL →
        (actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).eval p≤
          p^alpha*(1-c*min (fractionalPart alpha*(1-fractionalPart alpha)+
            (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2*(p/upperB k alpha eps D cb CL cL)+
              min ((upperLowResolution alpha:ℝ)^2*(upperA k alpha eps Ch D cb lambda CL cL/p)) 1) 1) := by
  obtain ⟨M0,c,hM0,hc,hupper⟩ := completedCoupledPolynomial_strict_upper hfL hfL1 hf hf1 (show 0<eps/2 by positivity)
  refine ⟨M0,c,hM0,hc,?_⟩
  intro M hM k alpha Ch D cb lambda CL cL p hk ha hg hg1 hCh hD hcb hlambda hlambdaC hCL hcL hcbCL hap hpb
  have ha1 : 1<alpha := by linarith only [ha]
  have hlam1 := coupled_capacity_lambda_le_one hlambdaC
  have hgeom := upper_actual_count_geometry hk ha hg hg1 heps hCh hD hcb hlambda
    (by linarith only [hlam1] : lambda≤4) hCL hcL hcbCL
  dsimp only at hgeom
  have hp := hgeom.1.trans_le hap
  have hEmin : eps/2≤upperE0 k alpha eps Ch := by
    have hlow := (upper_reserved_interval (k:=k) ha1 hg hg1 heps hCh).1
    nlinarith only [hlow,mul_nonneg heps.le (show 0≤alpha-3/2 by linarith only [ha])]
  have hE : 0<upperE0 k alpha eps Ch := (show 0<eps/2 by positivity).trans_le hEmin
  have hz := upperOverlapZ_spec hg hg1 hE
  have hzE : upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)≤Real.exp (-(eps/2)) := by
    have hh := overlapG_ge_parameter hg hg1 hz.1.1 hz.1.2
    rw [hz.2] at hh
    exact hh.trans (Real.exp_le_exp.mpr (neg_le_neg hEmin))
  have homega : Real.exp (-upperE0 k alpha eps Ch/8)≤Real.exp (-(eps/2)/8) :=
    Real.exp_le_exp.mpr (by linarith only [hEmin])
  have hcap := upper_actual_profile_capacity_at hk ha1 hg hg1 heps hCh hD hcb hlambda hlambdaC hCL hcL hp
  dsimp only at hcap
  have hh := hupper M hM (upperLowResolution alpha)
    (upperDegree alpha CL cL (rootMultiplier k alpha eps)) (upperOrderFloor alpha)
    (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))
    (Real.exp (-upperE0 k alpha eps Ch/8))
    (upperA k alpha eps Ch D cb lambda CL cL) (upperB k alpha eps D cb CL cL) p
    hgeom.2.2.2.1 hgeom.2.2.2.2.1 (upperOrderFloor_one_le ha1) hgeom.2.2.2.2.2.2.1
    hg hg1 hz.1.1 hzE (Real.exp_pos _).le homega hgeom.1 hap hpb hcap.2
  have halpha : (upperOrderFloor alpha:ℝ)+fractionalPart alpha=alpha := by
    rw [fractionalPart_eq_upperOrderFloor ha1]
    ring
  simpa only [halpha] using hh

/-- The actual source polynomial has the global lower baseline and gain, with all geometry discharged. -/
theorem actualCoupledPolynomial_global_lower {eps fL f qL qH M lambda : ℝ}
    (heps : 0<eps) (hfL : 0<fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hM : 1≤M) (hlambda : 0<lambda) (hlambdaC : lambda≤Real.exp (-2*coupledProfileConstant))
    (hqL : Real.exp (-(eps/2))<qL) (hqLf : qL<fL)
    (hqH : Real.exp (-7*(eps/2)/8)<qH) (hqHf : qH<f) :
    ∃ C c : ℝ, 0≤C ∧ 0<c ∧ ∀ (k : ℕ) (alpha Ch D cb CL cL p : ℝ),
      0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 →
      0≤Ch → 0<D → 0<cb → 1≤CL → 0<cL → 1≤cb*CL →
      upperA k alpha eps Ch D cb lambda CL cL≤p → p≤upperB k alpha eps D cb CL cL →
      p^alpha*(Real.exp (-upperE0 k alpha eps Ch)*Real.exp (-C*(fractionalPart alpha*(1-fractionalPart alpha)))+
        c*Real.exp (-upperE0 k alpha eps Ch)*
          min ((upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2*(p/upperB k alpha eps D cb CL cL)) 1)≤
        (actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).eval p := by
  have hlam1 := coupled_capacity_lambda_le_one hlambdaC
  obtain ⟨C,c,hC,hc,hlower⟩ := completedCoupledPolynomial_global_lower
    hfL hfL1 hf hf1 (show 0<eps/2 by positivity) heps hM (show 0<lambda/16 by positivity)
    (show lambda/16≤1 by linarith only [hlam1]) hqL hqLf hqH hqHf
  refine ⟨C,c,hC,hc,?_⟩
  intro k alpha Ch D cb CL cL p hk ha hg hg1 hCh hD hcb hCL hcL hcbCL hap hpb
  have ha1 : 1<alpha := by linarith only [ha]
  have hgeom := upper_actual_count_geometry hk ha hg hg1 heps hCh hD hcb hlambda
    (by linarith only [hlam1] : lambda≤4) hCL hcL hcbCL
  dsimp only at hgeom
  have hp := hgeom.1.trans_le hap
  have hEmin : eps/2≤upperE0 k alpha eps Ch := by
    have hlow := (upper_reserved_interval (k:=k) ha1 hg hg1 heps hCh).1
    nlinarith only [hlow,mul_nonneg heps.le (show 0≤alpha-3/2 by linarith only [ha])]
  have hE : 0<upperE0 k alpha eps Ch := (show 0<eps/2 by positivity).trans_le hEmin
  have hz := upperOverlapZ_spec hg hg1 hE
  have henergy := upperLowResolution_energy (k:=k) ha hg hg1 heps hCh
  have hcap := upper_actual_profile_capacity_at hk ha1 hg hg1 heps hCh hD hcb hlambda hlambdaC hCL hcL hp
  dsimp only at hcap
  have hh := hlower (upperLowResolution alpha)
    (upperDegree alpha CL cL (rootMultiplier k alpha eps)) (upperOrderFloor alpha)
    (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))
    (upperE0 k alpha eps Ch) (upperA k alpha eps Ch D cb lambda CL cL) (upperB k alpha eps D cb CL cL) p
    hgeom.2.2.2.1 hgeom.2.2.2.2.1 (upperOrderFloor_one_le ha1) hgeom.2.2.2.2.2.2.1
    hg hg1 hz.1.1 hz.1.2 hEmin hz.2 henergy hgeom.1 hap hpb hcap.1 hcap.2
  have halpha : (upperOrderFloor alpha:ℝ)+fractionalPart alpha=alpha := by
    rw [fractionalPart_eq_upperOrderFloor ha1]
    ring
  simpa only [halpha] using hh

end Renyi
