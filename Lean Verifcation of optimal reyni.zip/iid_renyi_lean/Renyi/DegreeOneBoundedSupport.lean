import Renyi.DegreeOneBoundedEnergyBase
import Renyi.DegreeOneCentralCertificate
import Renyi.CoupledBoundedSupport

/-! Actual canonical degree-one lower certificate. -/
noncomputable section
namespace Renyi.DegreeOneCompletion

lemma coupledProfiles_reserved_cutoff_linear {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z E M fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hE : 0≤E) (hzE : z≤Real.exp (-E)) (hM : 1≤M) (hfL : 0≤fL) (hfL1 : fL<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0<y) (hy1 : y≤1)
    (hcap : (x)*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledReservedBase ℓ N γ z M fL f (Real.exp (-E/8)) x y-
      Real.exp (Real.log 12+1)*Real.exp (-E)*(γ*(1-γ))≤
      coupledDampedExpression ℓ N γ z M (Real.exp (-E/8)) fL f x y-
        coupledHighReserve N γ z M f (Real.exp (-E/8)) y := by
  have hcut := coupledProfiles_cutoff_lower (ℓ:=ℓ) (fL:=fL) (f:=f) (x:=x) hN
    hγ hγ1 hz hz1 hE hM hzE hy.le hy1
  dsimp only at hcut
  change (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ fL x+
    (overlapB γ z*Real.exp (-M*(1-γ)))*highProfile N (1-γ) f (Real.exp (-E/8)) y-
    max ((overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ fL x-1+overlapB γ z) 0*endpointProfile N 6 1 y≤
    coupledDampedExpression ℓ N γ z M (Real.exp (-E/8)) fL f x y at hcut
  have hloss := coupledProfiles_cutoff_loss hℓ hN hγ hγ1 hz hz1 hzE (show 0≤M by linarith only [hM]) hfL hfL1 hx hx1 hy hy1 hcap
  unfold coupledReservedBase coupledHighReserve
  nlinarith only [hcut,hloss]

lemma coupledProfiles_reserved_high_lower {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z M ω fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hM : 0≤M) (hω : 0≤ω) (_hω1 : ω<1)
    (hfL : 0≤fL) (hfL1 : fL<1) (_hf : 0≤f) (_hf1 : f≤1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1) :
    (overlapB γ z*Real.exp (-(M+1)*(1-γ)))*highProfile N (1-γ) f ω y≤
      coupledDampedExpression ℓ N γ z M ω fL f x y-coupledHighReserve N γ z M f ω y := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := (lowProfile_range hℓ hγ hfL hfL1 hx hx1).1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hy hy1
  have hb1 : overlapB γ z*Real.exp (-M*(1-γ))≤1 :=
    (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hd]))
  have hl0 := mul_nonneg (mul_nonneg (mul_nonneg hc.1.le (Real.exp_pos (-M*γ)).le) hu) (sub_nonneg.mpr hH.2)
  have hj0 := mul_nonneg (mul_nonneg hω (sub_nonneg.mpr hb1)) hJ.1
  unfold coupledDampedExpression coupledHighReserve
  nlinarith only [hl0,hj0]


end Renyi.DegreeOneCompletion
