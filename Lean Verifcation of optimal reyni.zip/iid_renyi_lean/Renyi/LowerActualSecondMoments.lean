import Renyi.LowerActualCounts
import Renyi.ActualTensorSecondShape
import Renyi.LowerActualMassFloor

/-! Refined second moments on the same priors from the actual root rule. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 1800000

def lowerPriorSecondConstant (eps : ℝ) : ℝ :=
  48*(1+Real.exp 2)/(Real.exp (lowerLogSampleConstant eps (lowerPriorCoefficient eps)/2-4)/4)^2

theorem lowerPriorSecondConstant_pos (eps : ℝ) : 0<lowerPriorSecondConstant eps := by
  unfold lowerPriorSecondConstant
  positivity

/-- Every prior carrying the exact actual positive tensor moments has the
refined normalized second moment, with one constant depending only on accuracy. -/
theorem lower_actual_positive_second_moments {τ : Type*} [Fintype τ]
    (p₀ p₁ : FiniteAtomicPrior τ) {k r : ℕ} {s ε : ℝ}
    (hk : 0<k) (hr : 2≤r) (hs : 0<s) (hs1 : s≤1/2) (hε : 0<ε)
    (hx : lowerPriorRootCutoff ε≤rootMultiplier k ((r:ℝ)+s) ε) :
    let α := (r:ℝ)+s
    let x := rootMultiplier k α ε
    let L := Nat.ceil (10*α*(1+Real.log x))
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let ds : ℝ := ((r-1:ℕ):ℝ)+1
    let dc : ℝ := ((L-r:ℕ):ℝ)+1
    let bs := (ζ/8)/ds^2
    let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
    let a := θ/((1/100)*(L:ℝ)*ac)
    let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
    let us := chebyshevNode (r-1) bs
    let uc := chebyshevNode (L-r) ((1-s)/dc^2)
    let l := normalizedInterpolation us a ρ s
    let t := normalizedInterpolation uc ac 0 (1-s)
    let U := interpolationNodes us a
    let V := interpolationNodes uc ac
    let B := (a*ac)⁻¹
    let Z := tensorNormalizer l t U V a α
    (∀ j:ℝ, 0<j → priorMoment p₀ j=B^(j-1)/Z*(∑ ij, tensorNegative l t ij*tensorAtom U V a ij^(j-α))) →
    (∀ j:ℝ, 0<j → priorMoment p₁ j=B^(j-1)/Z*(∑ ij, tensorPositive l t ij*tensorAtom U V a ij^(j-α))) →
    priorMoment p₀ (2*α)/(priorMoment p₀ α)^2≤lowerPriorSecondConstant ε*ζ^2*B^α ∧
    priorMoment p₁ (2*α)/(priorMoment p₁ α)^2≤lowerPriorSecondConstant ε*ζ^2*B^α := by
  let α := (r : ℝ)+s
  let x := rootMultiplier k α ε
  let L := Nat.ceil (10*α*(1+Real.log x))
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ds : ℝ := ((r-1 : ℕ) : ℝ)+1
  let dc : ℝ := ((L-r : ℕ) : ℝ)+1
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*(L : ℝ)*ac)
  have hrR : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hα : 3/2 ≤ α := by dsimp [α]; linarith
  have hα1 : 1 < α := by linarith
  have hα0 : 0 < α := by linarith
  have hγ : fractionalPart α = s := fractionalPart_nat_add_small r hs.le (by linarith)
  have hγ₀ : 0 < fractionalPart α := by rwa [hγ]
  have hγ₁ : fractionalPart α < 1 := by rw [hγ]; linarith
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hx0 : 0 < x := by linarith
  have hlog : 0 ≤ Real.log x := Real.log_nonneg (by linarith)
  have hLlo : 10*α*(1+Real.log x) ≤ (L : ℝ) := Nat.le_ceil _
  have _hLr : r ≤ L := by
    have : (r : ℝ) ≤ L := by dsimp [α] at *; nlinarith
    exact_mod_cast this
  have hds : 0 < ds := by dsimp [ds]; positivity
  have hdc : 0 < dc := by dsimp [dc]; positivity
  have hds_eq : ds = (r : ℝ) := by
    dsimp [ds]
    rw [Nat.cast_sub (by omega : 1 ≤ r)]
    push_cast
    ring
  have hdchi : dc ≤ (L : ℝ)+1 := by
    dsimp [dc]
    exact add_le_add_right (by exact_mod_cast (Nat.sub_le L r)) 1
  have hdim : ds*dc ≤ α*((L : ℝ)+1) := by
    have h1 := mul_le_mul_of_nonneg_left hdchi (by positivity : 0 ≤ ds)
    rw [hds_eq] at h1
    have h2 := mul_le_mul_of_nonneg_right (show (r : ℝ) ≤ α by dsimp [α]; linarith)
      (show 0 ≤ (L : ℝ)+1 by positivity)
    rw [hds_eq]
    exact h1.trans h2
  have _hc := lowerPriorCoefficient_bounds hε
  have hβ0 : 0 < α-1 := sub_pos.mpr hα1
  have hE : 0 < E := by dsimp [E]; positivity
  have hv : 0 ≤ v := by dsimp [v]; positivity
  have hw : 0 < w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv
  have hcon := lower_actual_principal_constraints_with_perturbation hk hα hε hs hs1 hγ₀ hγ₁
    (Or.inl hγ.symm) hx hds hdc hdim
  dsimp only at hcon
  let bs := (ζ/8)/ds^2
  let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
  change 0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 ∧ ρ ≤ 1 at hcon
  have hmul : 4*ζ*((ds-1)/ds) = 4*ζ*((r-1 : ℕ) : ℝ)/(((r-1 : ℕ) : ℝ)+1) := by
    dsimp [ds]
    ring
  have hpert : max (((a/bs)^s/κ)*
      Real.exp (4*ζ*((r-1 : ℕ) : ℝ)/(((r-1 : ℕ) : ℝ)+1))-1) 0 * a / bs ≤ ζ := by
    rw [← hmul]
    exact hcon.2.2.2.1
  let us := chebyshevNode (r-1) bs
  let uc := chebyshevNode (L-r) ((1-s)/dc^2)
  let l := normalizedInterpolation us a ρ s
  let t := normalizedInterpolation uc ac 0 (1-s)
  let U := interpolationNodes us a
  let V := interpolationNodes uc ac
  dsimp only
  intro hmom₀ hmom₁
  have hns : 0<r-1 := by omega
  have hκ0 : 0<κ := Real.exp_pos _
  have hκ1 : κ≤1 := Real.exp_le_one_iff.mpr (by linarith)
  have hζ0 : 0<ζ := hcon.2.2.2.2.1
  have hζsmall : ζ≤3/5 := by linarith [hcon.2.2.2.2.2.1]
  have hbs0 : 0<bs := by dsimp [bs]; positivity
  have hbs1 : bs<1 := by
    apply (div_lt_one (by positivity : (0:ℝ)<ds^2)).mpr
    have hds1 : 1≤ds := by dsimp [ds]; exact le_add_of_nonneg_left (Nat.cast_nonneg _)
    nlinarith [hcon.2.2.2.2.2.1]
  have hactive := active_interpolation_mass_bound (r-1) ζ a s κ hns hζ0 hζsmall hcon.1 hcon.2.1 hs.le hκ0 hκ1 hpert
  dsimp only at hactive
  rw [←hmul] at hactive
  change (∑ i, negativeCoeff (l i))≤κ ∧ 1/2≤l none at hactive
  have hLα : 10*α≤L := by nlinarith
  have hdimlo : α*(L:ℝ)/4≤ds*dc := by
    rw [hds_eq]
    exact lower_nat_dimension_product_lower (by omega : 1≤r)
      (show (r:ℝ)≤α by dsimp [α]; linarith)
      (show α≤(r:ℝ)+1 by dsimp [α]; linarith) hLα
  let δ := Real.exp (lowerLogSampleConstant ε c/2-4)
  have hδ0 : 0<δ := Real.exp_pos _
  have hratio := lower_actual_active_ratio_floor hk hα hε hs hs1 hγ₀ hγ₁ (Or.inl hγ.symm) hx hds hdc hdim hdimlo
  change δ≤(a/bs)^s/κ at hratio
  have hfloor : δ*κ≤(a/bs)^s := (le_div_iff₀ hκ0).mp hratio
  have hshape := active_factor_moment_shape (r-1) ζ a ρ s (α-1) κ δ hns hζ0 hζsmall hcon.1 hcon.2.2.1 hcon.2.2.2.2.2.2 hs.le hκ0 hcon.2.1 hcon.2.2.2.1
    (by dsimp [α]; linarith) hactive.2 hactive.1 hfloor
  have hδ1 : δ≤4 := by
    have hh := hshape.1.trans hactive.1
    nlinarith
  have hau (i) : a<us i := by
    have hab : a<bs := by linarith [hcon.2.1]
    exact hab.trans_le (chebyshevNode_bounds (r-1) bs hbs1.le i).1
  have hcancel := low_integer_factor_zero us (chebyshevNode_injective (r-1) bs hbs1)
    (ρ:=ρ) (γ:=s) hcon.1 hau 1 (by norm_num) (by omega) (Or.inl (by omega))
  simp only [Nat.cast_one] at hcancel
  have hh := positive_actual_tensor_second_shape p₀ p₁ (r-1) (L-r) ζ a ρ s α κ δ hns hζ0 hζsmall hcon.1 hcon.2.2.1 hcon.2.2.2.2.2.2 hs hs1 hκ0 hκ1 hδ0 hδ1
    (by dsimp [α]; linarith) hcon.2.1 hcon.2.2.2.1 hactive.2 hactive.1 hfloor hcancel hmom₀ hmom₁
  exact hh

end Renyi
