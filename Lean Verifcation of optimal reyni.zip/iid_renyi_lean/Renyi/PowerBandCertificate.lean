import Renyi.NormalizationProbability
import Renyi.NearOneMargins

/-! Chebyshev certificates for the asymmetric entropy power-sum band. -/
noncomputable section
open MeasureTheory ProbabilityTheory
namespace Renyi
variable {Ω:Type*} [MeasurableSpace Ω] {μ:Measure Ω} [IsProbabilityMeasure μ]

/-- Interior mean margins and the actual variance imply a power-sum band. -/
theorem asymmetric_power_band_of_mean_variance {Z:Ω→ℝ} (hZ:MemLp Z 2 μ)
    {lo hi r delta:ℝ} (hr:0<r)
    (hlo:lo+r≤∫x,Z x ∂μ) (hhi:(∫x,Z x ∂μ)+r≤hi)
    (hvar:variance Z μ≤delta*r^2) :
    μ.real {x | Z x<lo ∨ hi<Z x}≤delta := by
  have hsubset:{x | Z x<lo ∨ hi<Z x}⊆{x | r < |Z x-∫w,Z w ∂μ|} := by
    intro x hx
    rcases hx with hx|hx
    · have hlow:Z x-(∫w,Z w ∂μ) < -r := by linarith
      exact (show r < -(Z x-(∫w,Z w ∂μ)) by linarith).trans_le (neg_le_abs _)
    · have hhigh:r<Z x-(∫w,Z w ∂μ) := by linarith
      exact hhigh.trans_le (le_abs_self _)
  have hratio:variance Z μ/r^2≤delta := (div_le_iff₀ (sq_pos_of_pos hr)).mpr hvar
  exact (measureReal_mono (μ:=μ) hsubset).trans ((real_chebyshev_gt hZ hr).trans hratio)

/-- A biased target inside the band leaves half of each margin for noise. -/
theorem asymmetric_power_band_of_target_variance {Z:Ω→ℝ} (hZ:MemLp Z 2 μ)
    {kappa omega margin P delta:ℝ} (hm:0<margin) (hP:0<P)
    (hgaplo:margin≤omega-kappa) (hgaphi:margin≤1-omega)
    (hbias:|(∫x,Z x ∂μ)-omega*P|≤margin*P/2)
    (hvar:variance Z μ≤delta*(margin*P/2)^2) :
    μ.real {x | Z x<kappa*P ∨ P<Z x}≤delta := by
  have hlo:=mul_le_mul_of_nonneg_right hgaplo hP.le
  have hhi:=mul_le_mul_of_nonneg_right hgaphi hP.le
  rcases abs_le.mp hbias with ⟨hblo,hbhi⟩
  exact asymmetric_power_band_of_mean_variance hZ (by positivity : 0<margin*P/2)
    (by nlinarith only [hlo,hblo]) (by nlinarith only [hhi,hbhi]) hvar

/-- The actual reserved-width overlap target near order one has explicit
margins, so no statistical accuracy certificate is assumed. -/
theorem near_one_power_band_of_mean_variance {Z:Ω→ℝ} (hZ:MemLp Z 2 μ)
    {k:ℕ} {alpha eps Ch cw P delta:ℝ}
    (ha:1<alpha) (ha1:alpha≤3/2) (heps:0<eps) (hCh:0≤Ch)
    (hcw:0<cw) (hcw1:cw<1) (hP:0<P)
    (hbias:|(∫x,Z x ∂μ)-upperOmega k alpha eps Ch cw*P|≤
      nearOneMarginConstant eps cw*(alpha-1)*P/2)
    (hvar:variance Z μ≤delta*(nearOneMarginConstant eps cw*(alpha-1)*P/2)^2) :
    μ.real {x | Z x<Real.exp (-2*eps*(alpha-1))*P ∨ P<Z x}≤delta := by
  have hfloor:⌊alpha⌋=(1:ℤ) := Int.floor_eq_iff.mpr (by norm_num; constructor <;> linarith)
  have hfract:fractionalPart alpha=alpha-1 := by simp only [fractionalPart,hfloor,Int.cast_one]
  have hg:0<fractionalPart alpha := by rw [hfract]; linarith
  have hg1:fractionalPart alpha<1 := by rw [hfract]; linarith
  have hmargin:=upperOmega_near_one_margins (k:=k) ha ha1 hg hg1 heps hCh hcw hcw1
  apply asymmetric_power_band_of_target_variance hZ
    (mul_pos (nearOneMarginConstant_pos heps hcw hcw1) (sub_pos.mpr ha)) hP
    (hmargin.1.trans (min_le_right _ _)) (hmargin.1.trans (min_le_left _ _)) hbias hvar

end Renyi
