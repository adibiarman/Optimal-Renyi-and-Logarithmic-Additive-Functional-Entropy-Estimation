import Renyi.LowerRootCalibration

/-! Quantitative lower bounds for the active interpolation mass. -/
noncomputable section
namespace Renyi

/-- Both sign conventions retain a fixed fraction of the product of the
order and degree in their two interpolation dimensions. -/
theorem lower_nat_dimension_product_lower {r L : ℕ} {α : ℝ}
    (hr : 1≤r) (hαlo : (r:ℝ)≤α) (hαhi : α≤(r:ℝ)+1)
    (hL : 10*α≤L) :
    α*(L:ℝ)/4≤(r:ℝ)*(((L-r:ℕ):ℝ)+1) := by
  have hr0 : (0:ℝ)≤r := Nat.cast_nonneg _
  have hr1 : (1:ℝ)≤r := by exact_mod_cast hr
  have hrL : r≤L := by
    have hh : (r:ℝ)≤L := by nlinarith
    exact_mod_cast hh
  rw [Nat.cast_sub hrL]
  have hα2 : α≤2*(r:ℝ) := by linarith
  have hlong : (L:ℝ)/2≤(L:ℝ)-(r:ℝ)+1 := by nlinarith
  have hh := mul_le_mul_of_nonneg_left hlong hr0
  have hh' := mul_le_mul_of_nonneg_right hα2 (show 0≤(L:ℝ) by positivity)
  nlinarith

/-- The actual logarithmic geometry has a uniform lower bound as well as
an upper bound. This prevents degeneration of the active negative mass. -/
theorem lower_ceiling_log_geometry_lower {α x ds dc : ℝ}
    (hα : 1≤α) (hx : 1≤x) (_hds : 0<ds) (_hdc : 0<dc)
    (hdim : α*(Nat.ceil (10*α*(1+Real.log x)):ℝ)/4≤ds*dc) :
    let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
    0≤4-Real.log ((1/100:ℝ)/8)+Real.log ((ds*dc)^2/(L*α^3*(1+Real.log x))) := by
  let t := 1+Real.log x
  let L : ℝ := Nat.ceil (10*α*t)
  have hα0 : 0<α := by linarith
  have ht : 1≤t := by dsimp [t]; linarith [Real.log_nonneg hx]
  have ht0 : 0<t := by linarith
  have hLlo : 10*α*t≤L := Nat.le_ceil _
  have hL : 0<L := (show 0<10*α*t by positivity).trans_le hLlo
  have hsquare : (α*L/4)^2≤(ds*dc)^2 := pow_le_pow_left₀ (by positivity) hdim 2
  have hh := mul_le_mul_of_nonneg_left hLlo (show 0≤α^2*L by positivity)
  have hratio : 1/2≤(ds*dc)^2/(L*α^3*t) := by
    apply (le_div_iff₀ (by positivity : 0<L*α^3*t)).mpr
    nlinarith only [hsquare,hh]
  have hlog := Real.log_le_log (by norm_num : (0:ℝ)<1/2) hratio
  have hlo : -1≤Real.log (1/2:ℝ) := by
    have hh := Real.one_sub_inv_le_log_of_pos (by norm_num : (0:ℝ)<1/2)
    norm_num at hh ⊢
    exact hh
  have hlogconst : Real.log ((1/100:ℝ)/8)≤0 := Real.log_nonpos (by norm_num) (by norm_num)
  change 0≤4-Real.log ((1/100:ℝ)/8)+Real.log ((ds*dc)^2/(L*α^3*t))
  linarith



/-- The active ratio has a uniform positive lower bound. The cancellation
of singular logarithms is quantified before taking the exponential. -/
theorem lower_active_ratio_bound {s E v ζ β logcn G : ℝ}
    (hs : 0<s) (hs1 : s≤1/2) (hv : 0≤v)
    (hζ : 0<ζ) (hζ1 : ζ≤1) (hβ : 0<β) (hG : 0≤G) :
    Real.exp (s*logcn-4)≤
      (Real.exp (lowerPrincipalLog s E v ζ β logcn G))^s /
        Real.exp (-E-4*(s*(1-s)+v)) := by
  let ξ := 1-s
  let w := s*ξ+v
  let z := lowerPrincipalLog s E v ζ β logcn G
  have hξ : 1/2≤ξ := by dsimp [ξ]; linarith
  have hξ0 : 0<ξ := by linarith
  have hξ1 : ξ≤1 := by dsimp [ξ]; linarith
  have hw : 0≤w := by dsimp [w]; positivity
  have hcoeff : 0≤1+1/ξ ∧ 1+1/ξ≤3 := by
    have hh : 1/ξ≤2 := (div_le_iff₀ hξ0).mpr (by linarith)
    constructor
    · positivity
    · linarith
  have hlogs : -ζ≤s*Real.log (s/ζ) := by
    have hh := mul_le_mul_of_nonneg_left (Real.one_sub_inv_le_log_of_pos (div_pos hs hζ)) hs.le
    have heq : s*(1-(s/ζ)⁻¹)=s-ζ := by field_simp
    rw [heq] at hh
    linarith
  have hterm : -3*ζ≤s*(1+1/ξ)*Real.log (s/ζ) := by
    have hh := mul_le_mul_of_nonneg_left hlogs hcoeff.1
    have hc := mul_le_mul_of_nonneg_left hcoeff.2 hζ.le
    nlinarith only [hh,hc]
  have hlξ : -1≤Real.log ξ := by
    have hh := Real.one_sub_inv_le_log_of_pos hξ0
    have hc : ξ⁻¹≤2 := by rw [←one_div]; exact (div_le_iff₀ hξ0).mpr (by linarith)
    linarith
  have hlogβ : 0≤Real.log ((β+1)/β) := Real.log_nonneg ((le_div_iff₀ hβ).mpr (by linarith))
  have hid : s*z+E+4*w=(v+4*w)/ξ+s*(1+1/ξ)*Real.log (s/ζ)+Real.log ξ+
      s*logcn+2*s*Real.log ((β+1)/β)+s*G := by
    change s*(logcn-E/s+v/(s*ξ)+4*w/ξ+(1+1/ξ)*Real.log (s/ζ)+
      Real.log ξ/s+2*Real.log ((β+1)/β)+G)+E+4*w=_
    field_simp [hs.ne',hξ0.ne']
    dsimp [ξ]
    ring
  have hbound : s*logcn-4≤s*z+E+4*w := by
    rw [hid]
    have hp : 0≤(v+4*w)/ξ := by positivity
    have hpg : 0≤s*G := mul_nonneg hs.le hG
    have hpb : 0≤2*s*Real.log ((β+1)/β) := by positivity
    linarith
  change Real.exp (s*logcn-4)≤(Real.exp z)^s/Real.exp (-E-4*w)
  rw [←Real.exp_mul,←Real.exp_sub]
  apply Real.exp_le_exp.mpr
  nlinarith only [hbound]

/-- When the sample constant is at most one, the active ratio floor is
independent of the distance to the nearest integer. -/
theorem lower_active_ratio_uniform {s E v ζ β logcn G : ℝ}
    (hs : 0<s) (hs1 : s≤1/2) (hv : 0≤v)
    (hζ : 0<ζ) (hζ1 : ζ≤1) (hβ : 0<β) (hG : 0≤G) (hcn : logcn≤0) :
    Real.exp (logcn/2-4)≤
      (Real.exp (lowerPrincipalLog s E v ζ β logcn G))^s /
        Real.exp (-E-4*(s*(1-s)+v)) := by
  apply le_trans _ (lower_active_ratio_bound hs hs1 hv hζ hζ1 hβ hG)
  apply Real.exp_le_exp.mpr
  nlinarith




end Renyi
