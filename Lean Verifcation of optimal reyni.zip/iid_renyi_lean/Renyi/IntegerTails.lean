import Renyi.IntegerScalar
import Renyi.NormalizationProbability
import Mathlib.Probability.HasLaw

/-!
# Probability tails for the integer collision argument

The upper and rare-count bounds apply Chebyshev to the exact first and
second moments. The frequent-count concentration theorem derives its
moments from the laws of independent Poisson counts.
-/

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

/-- The actual upper-tail event at the exponentially widening tolerance. -/
theorem integer_upper_tail_probability {eps P : ℝ} {r : ℕ} {X : Ω → ℝ}
    (heps : 0 < eps) (hepshalf : eps ≤ 1 / 2) (hr : 2 ≤ r) (hP : 0 < P)
    (hX : MemLp X 2 μ) (hmean : ∫ ω, X ω ∂μ = P)
    (hvar : variance X μ / P ^ 2 ≤
      Real.exp ((r : ℝ) / integerSampleConstant eps) - 1) :
    μ.real {ω | Real.exp (eps * ((r : ℝ) - 1)) * P < X ω} ≤ 1 / 100 := by
  have hr2 : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hy : 0 < eps * ((r : ℝ) - 1) := mul_pos heps (by linarith)
  have hgap : 0 < Real.exp (eps * ((r : ℝ) - 1)) - 1 :=
    sub_pos.mpr (Real.one_lt_exp_iff.mpr hy)
  have hcheb := real_chebyshev_gt hX (mul_pos hgap hP)
  rw [hmean] at hcheb
  have hsub : {ω | Real.exp (eps * ((r : ℝ) - 1)) * P < X ω} ⊆
      {ω | (Real.exp (eps * ((r : ℝ) - 1)) - 1) * P < |X ω - P|} := by
    intro ω hω
    have hab := le_abs_self (X ω - P)
    dsimp only [Set.mem_setOf_eq] at hω ⊢
    nlinarith
  apply (measureReal_mono (μ := μ) hsub).trans (hcheb.trans _)
  have hid : variance X μ / ((Real.exp (eps * ((r : ℝ) - 1)) - 1) * P) ^ 2 =
      (variance X μ / P ^ 2) / (Real.exp (eps * ((r : ℝ) - 1)) - 1) ^ 2 := by rw [mul_pow, div_div, mul_comm (P ^ 2)]
  rw [hid]
  exact (div_le_div_of_nonneg_right hvar (sq_nonneg _)).trans
    (integer_upper_tail_budget heps hepshalf hr)

/-- The actual rare-count lower-tail event, with the displayed sample constant. -/
theorem integer_rare_tail_probability {eps P L : ℝ} {r : ℕ} {F : Ω → ℝ}
    (heps : 0 < eps) (hepshalf : eps ≤ 1 / 2) (hr : 2 ≤ r) (hP : 0 < P)
    (hF : MemLp F 2 μ) (hmean : ∫ ω, F ω ∂μ = L)
    (hvar : variance F μ / P ^ 2 ≤ integerRareBase eps ^ r) :
    μ.real {ω | F ω < L - integerRareGap eps r * P} ≤ 4 / 10000 := by
  have hd := integerRareGap_pos heps hr
  have hcheb := real_chebyshev_gt hF (mul_pos hd hP)
  rw [hmean] at hcheb
  have hsub : {ω | F ω < L - integerRareGap eps r * P} ⊆
      {ω | integerRareGap eps r * P < |F ω - L|} := by
    intro ω hω
    have hab := neg_le_abs (F ω - L)
    dsimp only [Set.mem_setOf_eq] at hω ⊢
    nlinarith
  apply (measureReal_mono (μ := μ) hsub).trans (hcheb.trans _)
  have hid : variance F μ / (integerRareGap eps r * P) ^ 2 =
      (variance F μ / P ^ 2) / integerRareGap eps r ^ 2 := by rw [mul_pow, div_div, mul_comm (P ^ 2)]
  rw [hid]
  exact (div_le_div_of_nonneg_right hvar (sq_nonneg _)).trans
    (integer_rare_tail_budget heps hepshalf hr)

variable {ι : Type*} [Fintype ι]

def poissonWeightedMean (N : ι → Ω → ℕ) (lam : ι → ℝ≥0) (w : ι → ℝ) : Ω → ℝ :=
  fun ω => ∑ i, (w i / (lam i : ℝ)) * (N i ω : ℝ)

omit [IsProbabilityMeasure μ] in
theorem poissonWeightedMean_memLp (N : ι → Ω → ℕ) (lam : ι → ℝ≥0) (w : ι → ℝ)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i))) :
    MemLp (poissonWeightedMean N lam w) 2 μ := by
  have hmem (i : ι) : MemLp (fun ω => (w i / (lam i : ℝ)) * (N i ω : ℝ)) 2 μ :=
    ((poisson_nat_memLp (lam i)).comp_measurePreserving (hLaw i)).const_mul _
  exact memLp_finset_sum (s := Finset.univ) (fun i _ => hmem i)

/-- The weighted frequent statistic has mean one, directly from its Poisson laws. -/
theorem poissonWeightedMean_mean (N : ι → Ω → ℕ) (lam : ι → ℝ≥0) (w : ι → ℝ)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hlam : ∀ i, 0 < (lam i : ℝ)) (hsum : ∑ i, w i = 1) :
    (∫ ω, poissonWeightedMean N lam w ω ∂μ) = 1 := by
  have hmem (i : ι) : MemLp (fun ω => (N i ω : ℝ)) 2 μ :=
    (poisson_nat_memLp (lam i)).comp_measurePreserving (hLaw i)
  have hmean (i : ι) : (∫ ω, (N i ω : ℝ) ∂μ) = (lam i : ℝ) := by
    have h := (hLaw i).hasLaw.integral_comp
      (measurable_of_countable (fun n : ℕ => (n : ℝ))).aestronglyMeasurable
    change (∫ ω, ((fun n : ℕ => (n : ℝ)) ∘ N i) ω ∂μ) = _
    rw [h, poisson_nat_mean]
  unfold poissonWeightedMean
  rw [integral_finset_sum]
  · simp_rw [integral_const_mul, hmean, div_mul_cancel₀ _ (ne_of_gt (hlam _))]
    exact hsum
  · intro i _
    exact ((hmem i).integrable one_le_two).const_mul _

omit [IsProbabilityMeasure μ] in
/-- Independence yields the exact variance of the weighted frequent statistic. -/
theorem poissonWeightedMean_variance (N : ι → Ω → ℕ) (lam : ι → ℝ≥0) (w : ι → ℝ)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ)) :
    variance (poissonWeightedMean N lam w) μ = ∑ i, w i ^ 2 / (lam i : ℝ) := by
  let F : ι → Ω → ℝ := fun i ω => (w i / (lam i : ℝ)) * (N i ω : ℝ)
  have hF : ∀ i, MemLp (F i) 2 μ := fun i =>
    ((poisson_nat_memLp (lam i)).comp_measurePreserving (hLaw i)).const_mul _
  have hpairF : Pairwise (fun i j => IndepFun (F i) (F j) μ) := by
    intro i j hij
    exact (hpair hij).comp
      (measurable_of_countable (fun n : ℕ => (w i / (lam i : ℝ)) * n))
      (measurable_of_countable (fun n : ℕ => (w j / (lam j : ℝ)) * n))
  have hadd : variance (poissonWeightedMean N lam w) μ = ∑ i, variance (F i) μ := by
    convert (IndepFun.variance_sum (s := Finset.univ) (X := F)
      (fun i _ => hF i) (fun i _ j _ hij => hpairF hij)) using 1
    congr 1
    funext ω
    simp [poissonWeightedMean, F]
  rw [hadd]
  apply Finset.sum_congr rfl
  intro i _
  unfold F
  rw [variance_mul]
  have hvar : variance (fun ω => (N i ω : ℝ)) μ = (lam i : ℝ) := by
    rw [(hLaw i).variance_fun_comp
      (measurable_of_countable (fun n : ℕ => (n : ℝ))).aemeasurable]
    exact poisson_nat_variance (lam i)
  rw [hvar]
  field_simp

omit [IsProbabilityMeasure μ] in
theorem poissonWeightedMean_variance_le (N : ι → Ω → ℕ) (lam : ι → ℝ≥0) (w : ι → ℝ)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (hw : ∀ i, 0 ≤ w i) (hsum : ∑ i, w i = 1)
    {T : ℝ} (hT : 0 < T) (hlam : ∀ i, T ≤ (lam i : ℝ)) :
    variance (poissonWeightedMean N lam w) μ ≤ 1 / T := by
  rw [poissonWeightedMean_variance N lam w hLaw hpair]
  have hwi (i : ι) : w i ≤ 1 := by
    rw [← hsum]
    exact Finset.single_le_sum (fun j _ => hw j) (Finset.mem_univ i)
  have hsq : ∑ i, w i ^ 2 ≤ 1 := by
    rw [← hsum]
    apply Finset.sum_le_sum
    intro i _
    nlinarith [hw i, hwi i]
  calc
    _ ≤ ∑ i, w i ^ 2 / T := by
      apply Finset.sum_le_sum
      intro i _
      exact div_le_div_of_nonneg_left (sq_nonneg _) hT (hlam i)
    _ = (∑ i, w i ^ 2) / T := by rw [Finset.sum_div]
    _ ≤ 1 / T := (div_le_div_iff_of_pos_right hT).mpr hsq

/-- Step 5's probability bound follows from the actual independent Poisson laws. -/
theorem integer_frequent_mean_tail_probability
    (N : ι → Ω → ℕ) (lam : ι → ℝ≥0) (w : ι → ℝ)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (hw : ∀ i, 0 ≤ w i) (hsum : ∑ i, w i = 1)
    {eps : ℝ} (heps : 0 < eps) {r : ℕ} (hr : 2 ≤ r)
    (hlam : ∀ i, integerThreshold eps r ≤ (lam i : ℝ)) :
    μ.real {ω | poissonWeightedMean N lam w ω < 1 - eps / 16} ≤ 1 / 32 := by
  have hT := integerThreshold_pos heps hr
  have hpos : ∀ i, 0 < (lam i : ℝ) := fun i => lt_of_lt_of_le hT (hlam i)
  have hm := poissonWeightedMean_mean N lam w hLaw hpos hsum
  have hv := poissonWeightedMean_variance_le N lam w hLaw hpair hw hsum hT hlam
  have hc := real_chebyshev_gt (poissonWeightedMean_memLp N lam w hLaw)
    (by positivity : 0 < eps / 16)
  rw [hm] at hc
  have hsub : {ω | poissonWeightedMean N lam w ω < 1 - eps / 16} ⊆
      {ω | eps / 16 < |poissonWeightedMean N lam w ω - 1|} := by
    intro ω hω
    have hab := neg_le_abs (poissonWeightedMean N lam w ω - 1)
    dsimp only [Set.mem_setOf_eq] at hω ⊢
    linarith
  apply (measureReal_mono (μ := μ) hsub).trans (hc.trans _)
  apply (div_le_div_of_nonneg_right hv (sq_nonneg _)).trans
  have hid : (1 / integerThreshold eps r) / (eps / 16) ^ 2 =
      256 / (eps ^ 2 * integerThreshold eps r) := by ring
  rw [hid]
  exact integer_frequent_tail_budget heps hr

end Renyi
