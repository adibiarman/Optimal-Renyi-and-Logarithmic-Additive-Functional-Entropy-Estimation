import Renyi.GammaResidualPilot

/-! Moment transport for actual independent Poisson pilot/main pairs. -/
noncomputable section
open scoped BigOperators NNReal ENNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def poissonPairMeasure (mu lam : ℝ≥0) : Measure (ℕ × ℕ) :=
  (poissonMeasure mu).prod (poissonMeasure lam)

instance (mu lam : ℝ≥0) : IsProbabilityMeasure (poissonPairMeasure mu lam) := by
  unfold poissonPairMeasure
  infer_instance

theorem poissonPairMeasure_singleton (mu lam : ℝ≥0) (z : ℕ × ℕ) :
    poissonPairMeasure mu lam {z} =
      ENNReal.ofReal (poissonPMFReal lam z.2 * poissonPMFReal mu z.1) := by
  change (poissonMeasure mu).prod (poissonMeasure lam) {(z.1, z.2)} = _
  rw [← Set.singleton_prod_singleton, Measure.prod_prod]
  rw [show poissonMeasure mu {z.1} = ENNReal.ofReal (poissonPMFReal mu z.1) from
    PMF.toMeasure_apply_singleton _ _ (MeasurableSet.singleton _)]
  rw [show poissonMeasure lam {z.2} = ENNReal.ofReal (poissonPMFReal lam z.2) from
    PMF.toMeasure_apply_singleton _ _ (MeasurableSet.singleton _)]
  rw [← ENNReal.ofReal_mul poissonPMFReal_nonneg, mul_comm]

theorem poisson_pair_integrable_of_summable (mu lam : ℝ≥0) (f : ℕ × ℕ → ℝ)
    (hs : Summable (fun z => ‖f z‖ *
      (poissonPMFReal lam z.2 * poissonPMFReal mu z.1))) :
    Integrable f (poissonPairMeasure mu lam) := by
  refine ⟨(measurable_of_countable f).aestronglyMeasurable, ?_⟩
  rw [hasFiniteIntegral_iff_norm, lintegral_countable']
  simp_rw [poissonPairMeasure_singleton, ← ENNReal.ofReal_mul (norm_nonneg _)]
  rw [← ENNReal.ofReal_tsum_of_nonneg
    (fun z => mul_nonneg (norm_nonneg (f z))
      (mul_nonneg poissonPMFReal_nonneg poissonPMFReal_nonneg)) hs]
  exact ENNReal.ofReal_lt_top

theorem poisson_pair_integral_eq_tsum (mu lam : ℝ≥0) (f : ℕ × ℕ → ℝ)
    (hf : Integrable f (poissonPairMeasure mu lam)) :
    (∫ z, f z ∂poissonPairMeasure mu lam) =
      ∑' z, f z * (poissonPMFReal lam z.2 * poissonPMFReal mu z.1) := by
  rw [integral_countable' hf]
  apply tsum_congr
  intro z
  rw [measureReal_def, poissonPairMeasure_singleton,
    ENNReal.toReal_ofReal (mul_nonneg poissonPMFReal_nonneg poissonPMFReal_nonneg)]
  simp only [smul_eq_mul]
  ring

theorem poisson_pair_memLp_of_squared_summable (mu lam : ℝ≥0) (f : ℕ × ℕ → ℝ)
    (hs : Summable (fun z => f z ^ 2 *
      (poissonPMFReal lam z.2 * poissonPMFReal mu z.1))) :
    MemLp f 2 (poissonPairMeasure mu lam) := by
  apply (memLp_two_iff_integrable_sq (measurable_of_countable f).aestronglyMeasurable).2
  apply poisson_pair_integrable_of_summable
  simpa only [Real.norm_of_nonneg (sq_nonneg _)] using hs

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

theorem poisson_pair_measurePreserving
    (Y N : Ω → ℕ) (mu lam : ℝ≥0)
    (hY : MeasurePreserving Y μ (poissonMeasure mu))
    (hN : MeasurePreserving N μ (poissonMeasure lam)) (hind : IndepFun Y N μ) :
    MeasurePreserving (fun w => (Y w, N w)) μ (poissonPairMeasure mu lam) := by
  refine ⟨hY.measurable.prodMk hN.measurable, ?_⟩
  have h := (indepFun_iff_map_prod_eq_prod_map_map hY.aemeasurable hN.aemeasurable).1 hind
  simpa only [hY.map_eq, hN.map_eq, poissonPairMeasure] using h

/-- Two arbitrary square-integrable errors need no independence for this
variance triangle bound. -/
theorem variance_fun_add_le_two {X Y : Ω → ℝ} (hX : MemLp X 2 μ) (hY : MemLp Y 2 μ) :
    variance (fun w => X w + Y w) μ ≤ 2 * variance X μ + 2 * variance Y μ := by
  have hnon := variance_nonneg (fun w => X w - Y w) μ
  rw [variance_fun_sub hX hY] at hnon
  rw [variance_fun_add hX hY]
  linarith

theorem variance_fun_sub_le_two {X Y : Ω → ℝ} (hX : MemLp X 2 μ) (hY : MemLp Y 2 μ) :
    variance (fun w => X w - Y w) μ ≤ 2 * variance X μ + 2 * variance Y μ := by
  have h := variance_fun_add_le_two hX hY.neg
  simpa only [Pi.neg_apply, ← sub_eq_add_neg, variance_neg] using h

omit [IsProbabilityMeasure μ] in
/-- A convergent selected joint second moment gives its full random-variable
variance bound under any realization of the actual pair law. -/
theorem poisson_pair_variance_of_second_sum
    (Z : Ω → ℕ × ℕ) (mu lam : ℝ≥0)
    (hLaw : MeasurePreserving Z μ (poissonPairMeasure mu lam)) (f : ℕ × ℕ → ℝ)
    (hs : Summable (fun z => f z ^ 2 *
      (poissonPMFReal lam z.2 * poissonPMFReal mu z.1))) :
    MemLp (fun w => f (Z w)) 2 μ ∧
      variance (fun w => f (Z w)) μ ≤
        ∑' z, f z ^ 2 * (poissonPMFReal lam z.2 * poissonPMFReal mu z.1) := by
  have hf := poisson_pair_memLp_of_squared_summable mu lam f hs
  refine ⟨hf.comp_measurePreserving hLaw, ?_⟩
  rw [hLaw.variance_fun_comp (measurable_of_countable f).aemeasurable]
  have hbound := variance_le_expectation_sq hf.aestronglyMeasurable
  rw [show (f ^ 2) = fun z => f z ^ 2 by rfl,
    poisson_pair_integral_eq_tsum mu lam _ hf.integrable_sq] at hbound
  exact hbound

end Renyi
