import Renyi.LowerPriorTransfer

/-! Uniform normalization calibration of the constructed finite priors. -/
noncomputable section
open scoped BigOperators NNReal
namespace Renyi

/-- The crude normalized power second moment suffices at order one. -/
theorem finite_prior_power_second_crude {ι : Type*} [Fintype ι]
    (P : FiniteAtomicPrior ι) {alpha B : ℝ} (ha : 1 < alpha) (hB : 1 ≤ B)
    (hsupp : ∀ i, P.value i = 0 ∨ (1 ≤ P.value i ∧ P.value i ≤ B))
    (hmean : priorMoment P 1 = 1) :
    priorMoment P (2*alpha)/(priorMoment P alpha)^2 ≤ B^alpha := by
  have hA := finite_prior_power_bounds P alpha B ha hB hsupp hmean
  have hApos : 0 < priorMoment P alpha := by linarith
  have hB0 : 0 ≤ B := by linarith
  have hsum : priorMoment P (2*alpha) ≤ B^alpha * priorMoment P alpha := by
    calc
      _ ≤ ∑ i, P.mass i * (B^alpha * P.value i^alpha) := by
        apply Finset.sum_le_sum
        intro i _
        have hv : 0 ≤ P.value i ∧ P.value i ≤ B := by
          rcases hsupp i with hi | hi
          · rw [hi]; constructor <;> linarith
          · constructor <;> linarith
        have hpow := Real.rpow_le_rpow hv.1 hv.2 (by linarith : 0 ≤ alpha)
        have hp0 : 0 ≤ P.value i^alpha := Real.rpow_nonneg hv.1 _
        apply mul_le_mul_of_nonneg_left _ (P.mass_nonneg i)
        rw [show 2*alpha = alpha*(2 : ℝ) by ring, Real.rpow_mul hv.1, Real.rpow_two]
        nlinarith [mul_le_mul_of_nonneg_right hpow hp0]
      _ = B^alpha * priorMoment P alpha := by
        unfold priorMoment
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro i _
        ring
  apply (div_le_iff₀ (sq_pos_of_pos hApos)).mpr
  have hApow : priorMoment P alpha ≤ (priorMoment P alpha)^2 := by nlinarith
  exact hsum.trans (mul_le_mul_of_nonneg_left hApow (Real.rpow_nonneg hB0 _))

/-- Near order one the normalization reserve `m ≥ (alpha-1)/2` removes every
singular power of `alpha-1` from the full explicit failure budget. -/
theorem prior_normalization_near_one_bound {ι : Type*} [Fintype ι]
    (b : ℝ≥0) (hb : 0 < (b : ℝ)) (P : FiniteAtomicPrior ι)
    {alpha B m : ℝ} (ha : 1 < alpha) (hB : 1 ≤ B)
    (hsupp : ∀ i, P.value i = 0 ∨ (1 ≤ P.value i ∧ P.value i ≤ B))
    (hmean : priorMoment P 1 = 1) (hm : (alpha-1)/2 ≤ m) :
    priorNormalizationMomentBudget b P alpha m ≤
      (1024/(b : ℝ))*(B+(Real.log B)^2*(B^alpha+B)) := by
  let A := priorMoment P alpha
  let d := min 1 ((alpha-1)*Real.log B)
  let t := min (1/4 : ℝ) (m/(16*(alpha-1)))
  have hbeta : 0 < alpha-1 := sub_pos.mpr ha
  have hm0 : 0 < m := lt_of_lt_of_le (by positivity : (0 : ℝ) < (alpha-1)/2) hm
  have hA := finite_prior_power_bounds P alpha B ha hB hsupp hmean
  have hA0 : 0 < A := by dsimp [A]; linarith
  have hlog : 0 ≤ Real.log B := Real.log_nonneg hB
  have hd0 : 0 ≤ d := le_min zero_le_one (mul_nonneg hbeta.le hlog)
  have hdq : d/m ≤ 2*Real.log B := by
    apply (div_le_iff₀ hm0).mpr
    have hd : d ≤ (alpha-1)*Real.log B := min_le_right _ _
    have hh := mul_le_mul_of_nonneg_right hm hlog
    nlinarith
  have hdq0 : 0 ≤ d/m := div_nonneg hd0 hm0.le
  have hd2 : d^2/m^2 ≤ 4*(Real.log B)^2 := by
    have h := (sq_le_sq₀ hdq0 (by positivity : 0 ≤ 2*Real.log B)).mpr hdq
    norm_num only [div_pow, mul_pow, show (2 : ℝ)^2 = 4 by norm_num] at h
    exact h
  have ht : (1/32 : ℝ) ≤ t := by
    apply le_min (by norm_num)
    apply (le_div_iff₀ (by positivity : 0 < 16*(alpha-1))).mpr
    nlinarith
  have ht0 : 0 < t := lt_of_lt_of_le (by norm_num) ht
  have hsupp' : ∀ i, 0 ≤ P.value i ∧ P.value i ≤ B := by
    intro i
    rcases hsupp i with h | h
    · rw [h]; constructor <;> linarith
    · constructor <;> linarith
  have hsecond := finite_prior_second_moment_le P B hsupp' hmean
  have hsecond0 : 0 ≤ priorMoment P 2 :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (P.mass_nonneg i) (Real.rpow_nonneg (hsupp' i).1 _))
  have hfirst : priorMoment P 2/((b : ℝ)*t^2) ≤ 1024*B/b := by
    have hden : (b : ℝ)*(1/32 : ℝ)^2 ≤ (b : ℝ)*t^2 := by nlinarith [sq_le_sq₀ (by norm_num : (0 : ℝ) ≤ 1/32) ht0.le |>.mpr ht]
    have h := (div_le_div_of_nonneg_left hsecond0 (by positivity : (0 : ℝ) < (b : ℝ)*(1/32 : ℝ)^2) hden).trans
      (div_le_div_of_nonneg_right hsecond (by positivity : (0 : ℝ) ≤ (b : ℝ)*(1/32 : ℝ)^2))
    convert h using 1; field_simp; ring
  have hres := finite_prior_residual_noise_bound P alpha B ha hB hsupp hmean
  have hM := finite_prior_power_second_crude P ha hB hsupp hmean
  have hres' : priorResidualSecondMoment P alpha/A^2 ≤ d^2*(B^alpha+B) :=
    hres.trans (mul_le_mul_of_nonneg_left (add_le_add_right hM B) (sq_nonneg d))
  have hnorm : priorResidualSecondMoment P alpha/(A^2*m^2) ≤
      4*(Real.log B)^2*(B^alpha+B) := by
    calc
      _ = (priorResidualSecondMoment P alpha/A^2)/m^2 := by field_simp
      _ ≤ (d^2*(B^alpha+B))/m^2 := div_le_div_of_nonneg_right hres' (sq_nonneg m)
      _ = (d^2/m^2)*(B^alpha+B) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_right hd2 (by positivity : 0 ≤ B^alpha+B)
  have hfull := add_le_add hfirst (mul_le_mul_of_nonneg_left hnorm (show 0 ≤ 256/(b : ℝ) by positivity))
  convert hfull using 1
  · unfold priorNormalizationMomentBudget
    dsimp only [A, t] at *
    congr 1
    field_simp
    norm_num
  · ring

/-- The normalization envelope for a quadratic logarithmic support bound. -/
def nearOneNormalizationEnvelope (C : ℝ) : ℝ :=
  2048*(C+(Real.log C+2)^2*(C^2+C))

theorem nearOneNormalizationEnvelope_pos {C : ℝ} (hC : 1 ≤ C) :
    0 < nearOneNormalizationEnvelope C := by
  unfold nearOneNormalizationEnvelope
  positivity

/-- The complete near-one normalization budget is uniformly polylogarithmic
when the explicit prior support is quadratic in the logarithm of the alphabet. -/
theorem prior_normalization_near_one_polylog {ι : Type*} [Fintype ι]
    {k : ℕ} (hk : 1 ≤ k) (b : ℝ≥0) (hb : (b : ℝ) = (k : ℝ)/2)
    (P : FiniteAtomicPrior ι) {alpha B m C : ℝ}
    (ha : 1 < alpha) (ha1 : alpha ≤ 3/2) (hB : 1 ≤ B) (hC : 1 ≤ C)
    (hBupper : B ≤ C*(1+Real.log k)^2)
    (hsupp : ∀ i, P.value i = 0 ∨ (1 ≤ P.value i ∧ P.value i ≤ B))
    (hmean : priorMoment P 1 = 1) (hm : (alpha-1)/2 ≤ m) :
    priorNormalizationMomentBudget b P alpha m ≤
      nearOneNormalizationEnvelope C*(1+Real.log k)^5/(k : ℝ) := by
  let H := 1+Real.log k
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hk0 : (0 : ℝ) < k := zero_lt_one.trans_le hk1
  have hb0 : 0 < (b : ℝ) := by rw [hb]; positivity
  have hH : 1 ≤ H := by dsimp [H]; linarith [Real.log_nonneg hk1]
  have hH0 : 0 < H := zero_lt_one.trans_le hH
  have hC0 : 0 < C := zero_lt_one.trans_le hC
  have hB0 : 0 < B := zero_lt_one.trans_le hB
  have ha0 : 0 ≤ alpha := by linarith
  have hpow : B^alpha ≤ C^2*H^3 := by
    have hh := Real.rpow_le_rpow hB0.le hBupper ha0
    rw [Real.mul_rpow hC0.le (sq_nonneg H), ← Real.rpow_natCast_mul hH0.le] at hh
    have hCpow : C^alpha ≤ C^2 := by
      simpa only [Real.rpow_two] using Real.rpow_le_rpow_of_exponent_le hC (show alpha ≤ (2 : ℝ) by linarith)
    have hHpow : H^(2*alpha) ≤ H^3 := by
      calc
        _ ≤ H^(3 : ℝ) := Real.rpow_le_rpow_of_exponent_le hH (by linarith)
        _ = H^3 := by norm_num
    exact hh.trans (mul_le_mul hCpow hHpow (Real.rpow_nonneg hH0.le _) (sq_nonneg C))
  have hH23 : H^2 ≤ H^3 := by nlinarith [mul_nonneg (sq_nonneg H) (sub_nonneg.mpr hH)]
  have hH25 : H^2 ≤ H^5 := by
    have hH3 : 1 ≤ H^3 := one_le_pow₀ hH
    have hh := mul_le_mul_of_nonneg_left hH3 (sq_nonneg H)
    nlinarith
  have hB3 : B ≤ C*H^3 := hBupper.trans (mul_le_mul_of_nonneg_left hH23 hC0.le)
  have hlogC : 0 ≤ Real.log C := Real.log_nonneg hC
  have hlogB : 0 ≤ Real.log B := Real.log_nonneg hB
  have hlog : Real.log B ≤ (Real.log C+2)*H := by
    have hl := Real.log_le_log hB0 hBupper
    rw [Real.log_mul hC0.ne' (pow_ne_zero 2 hH0.ne'), Real.log_pow] at hl
    norm_num only [Nat.cast_ofNat] at hl
    have hln := Real.log_le_sub_one_of_pos hH0
    have hCmul := mul_le_mul_of_nonneg_left hH hlogC
    nlinarith
  have hlog2 : (Real.log B)^2 ≤ (Real.log C+2)^2*H^2 := by
    have hh := (sq_le_sq₀ hlogB (by positivity : 0 ≤ (Real.log C+2)*H)).mpr hlog
    simpa only [mul_pow] using hh
  have hpair : B^alpha+B ≤ (C^2+C)*H^3 := by nlinarith [hpow,hB3]
  have hprod := mul_le_mul hlog2 hpair (by positivity : 0 ≤ B^alpha+B)
    (by positivity : 0 ≤ (Real.log C+2)^2*H^2)
  have hB5 : B ≤ C*H^5 := hBupper.trans (mul_le_mul_of_nonneg_left hH25 hC0.le)
  have henvelope : B+(Real.log B)^2*(B^alpha+B) ≤
      (C+(Real.log C+2)^2*(C^2+C))*H^5 := by nlinarith [hprod,hB5]
  have h := (prior_normalization_near_one_bound b hb0 P ha hB hsupp hmean hm).trans
    (mul_le_mul_of_nonneg_left henvelope (show 0 ≤ 1024/(b : ℝ) by positivity))
  rw [hb] at h
  convert h using 1
  unfold nearOneNormalizationEnvelope
  dsimp only [H]
  field_simp
  norm_num

end Renyi
