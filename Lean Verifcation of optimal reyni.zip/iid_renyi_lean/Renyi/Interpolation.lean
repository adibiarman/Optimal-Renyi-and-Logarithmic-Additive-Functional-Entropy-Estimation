import Renyi.Foundations
import Mathlib.LinearAlgebra.Lagrange

/-!
# Exact moment cancellations from actual interpolation weights

The weights are constructed using Mathlib's Lagrange polynomials. Polynomial
reproduction is proved, rather than supplied as a moment-matching assumption.
The quantitative bounds on positive and negative masses are not proved here.
-/

noncomputable section
open scoped BigOperators
open Polynomial
namespace Renyi

def lagrangeWeight {n : ℕ} (u : Fin (n + 1) → ℝ) (a : ℝ) (i : Fin (n + 1)) : ℝ :=
  (Lagrange.basis Finset.univ u i).eval a

/-- Interpolation reproduces every monomial through degree n. -/
theorem lagrange_monomial {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) (a : ℝ) (j : ℕ) (hj : j ≤ n) :
    ∑ i, lagrangeWeight u a i * u i ^ j = a ^ j := by
  have hinj : Set.InjOn u (Finset.univ : Finset (Fin (n + 1))) :=
    fun _ _ _ _ h => hu h
  have hdeg : (X ^ j : ℝ[X]).degree <
      (Finset.univ : Finset (Fin (n + 1))).card := by
    simp only [degree_X_pow, Finset.card_univ, Fintype.card_fin]
    exact_mod_cast (Nat.lt_succ_of_le hj)
  have h := congrArg (Polynomial.eval a) (Lagrange.eq_interpolate hinj hdeg)
  simpa [Lagrange.interpolate_apply, Polynomial.eval_finset_sum,
    lagrangeWeight, mul_comm] using h.symm

/-- The finite signed functional associated with the paper's perturbed measure. -/
def perturbedMoment {n : ℕ} (u : Fin (n + 1) → ℝ) (a ρ : ℝ) (j : ℕ) : ℝ :=
  (1 + ρ) * a ^ j -
    ∑ i, lagrangeWeight u a i * (1 + ρ * a / u i) * u i ^ j

/-- The perturbation preserves every integer moment from 1 through n. -/
theorem perturbed_moment_cancellation {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) (hu0 : ∀ i, u i ≠ 0)
    (a ρ : ℝ) (j : ℕ) (hj0 : 1 ≤ j) (hjn : j ≤ n) :
    perturbedMoment u a ρ j = 0 := by
  have hprev : j - 1 ≤ n := by omega
  have hp (x : ℝ) : x ^ j = x ^ (j - 1) * x := by
    rw [← pow_succ]
    congr 1
    omega
  have hterms :
      (∑ i, lagrangeWeight u a i * (1 + ρ * a / u i) * u i ^ j) =
      ∑ i, (lagrangeWeight u a i * u i ^ j +
        (ρ * a) * (lagrangeWeight u a i * u i ^ (j - 1))) := by
    apply Finset.sum_congr rfl
    intro i _
    rw [hp (u i)]
    field_simp [hu0 i]
  unfold perturbedMoment
  rw [hterms, Finset.sum_add_distrib, ← Finset.mul_sum,
    lagrange_monomial u hu a j hjn, lagrange_monomial u hu a (j - 1) hprev,
    hp a]
  ring

/-- At zero perturbation, the mass (degree zero) also vanishes. -/
theorem unperturbed_moment_cancellation {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) (a : ℝ) (j : ℕ) (hj : j ≤ n) :
    perturbedMoment u a 0 j = 0 := by
  simp only [perturbedMoment, zero_mul, zero_div, add_zero, one_mul, mul_one]
  rw [lagrange_monomial u hu a j hj]
  ring

end Renyi
