import Renyi.Model
import Mathlib.Analysis.MeanInequalities
import Mathlib.Analysis.MeanInequalitiesPow

/-! Deterministic norm and logarithm control for the empirical high-order estimator. -/
noncomputable section
open scoped BigOperators
namespace Renyi

def finiteLNorm {k : ℕ} (α : ℝ) (v : Fin k → ℝ) : ℝ :=
  (∑ i, |v i| ^ α) ^ (1 / α)

theorem finiteLNorm_nonneg {k : ℕ} (α : ℝ) (v : Fin k → ℝ) : 0 ≤ finiteLNorm α v :=
  Real.rpow_nonneg (Finset.sum_nonneg (fun _ _ => Real.rpow_nonneg (abs_nonneg _) _)) _

theorem finiteLNorm_add_le {k : ℕ} {α : ℝ} (hα : 1 ≤ α) (v w : Fin k → ℝ) :
    finiteLNorm α (fun i => v i + w i) ≤ finiteLNorm α v + finiteLNorm α w :=
  Real.Lp_add_le Finset.univ v w hα

theorem finiteLNorm_mono {k : ℕ} {α : ℝ} (hα : 0 < α) (v w : Fin k → ℝ)
    (hvw : ∀ i, |v i| ≤ |w i|) : finiteLNorm α v ≤ finiteLNorm α w := by
  apply Real.rpow_le_rpow
  · exact Finset.sum_nonneg (fun _ _ => Real.rpow_nonneg (abs_nonneg _) _)
  · exact Finset.sum_le_sum (fun i _ => Real.rpow_le_rpow (abs_nonneg _) (hvw i) hα.le)
  · positivity

theorem finiteLNorm_smul {k : ℕ} {α c : ℝ} (hα : 0 < α) (hc : 0 ≤ c)
    (v : Fin k → ℝ) : finiteLNorm α (fun i => c * v i) = c * finiteLNorm α v := by
  unfold finiteLNorm
  simp_rw [abs_mul, abs_of_nonneg hc, Real.mul_rpow hc (abs_nonneg _)]
  rw [← Finset.mul_sum, Real.mul_rpow (Real.rpow_nonneg hc _)
    (Finset.sum_nonneg (fun _ _ => Real.rpow_nonneg (abs_nonneg _) _)),
    ← Real.rpow_mul hc, mul_one_div_cancel hα.ne', Real.rpow_one]

theorem finiteLNorm_sub_symm {k : ℕ} (α : ℝ) (v w : Fin k → ℝ) :
    finiteLNorm α (fun i => v i - w i) = finiteLNorm α (fun i => w i - v i) := by
  unfold finiteLNorm
  simp_rw [abs_sub_comm]

theorem finiteLNorm_reverse_triangle {k : ℕ} {α : ℝ} (hα : 1 ≤ α)
    (v w : Fin k → ℝ) :
    |finiteLNorm α v - finiteLNorm α w| ≤ finiteLNorm α (fun i => v i - w i) := by
  have hv := finiteLNorm_add_le hα w (fun i => v i - w i)
  have hw := finiteLNorm_add_le hα v (fun i => w i - v i)
  have hev : (fun i => w i + (v i - w i)) = v := by funext i; ring
  have hew : (fun i => v i + (w i - v i)) = w := by funext i; ring
  rw [hev] at hv
  rw [hew] at hw
  rw [← finiteLNorm_sub_symm α v w] at hw
  exact abs_le.mpr ⟨by linarith, by linarith⟩

theorem simplex_powerSum_pos {k : ℕ} (p : Simplex k) (α : ℝ) : 0 < powerSum p α := by
  have hex : ∃ i, 0 < p.mass i := by
    by_contra! h
    have hz : ∑ i, p.mass i = 0 := Finset.sum_eq_zero (fun i _ => le_antisymm (h i) (p.nonneg i))
    linarith [p.normalized]
  obtain ⟨i, hi⟩ := hex
  exact (Real.rpow_pos_of_pos hi α).trans_le
    (Finset.single_le_sum (fun j _ => Real.rpow_nonneg (p.nonneg j) α) (Finset.mem_univ i))

theorem finiteLNorm_simplex_pos {k : ℕ} (p : Simplex k) (α : ℝ) :
    0 < finiteLNorm α p.mass := by
  have he : (∑ i, |p.mass i| ^ α) = powerSum p α := by
    simp [powerSum, abs_of_nonneg, p.nonneg]
  unfold finiteLNorm
  rw [he]
  exact Real.rpow_pos_of_pos (simplex_powerSum_pos p α) _

/-- The uniform vector minimizes every norm of order at least one on the simplex. -/
theorem finiteLNorm_uniform_le {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {α : ℝ} (hα : 1 ≤ α) :
    finiteLNorm α (fun _ : Fin k => 1 / (k : ℝ)) ≤ finiteLNorm α p.mass := by
  have hkR : 0 < (k : ℝ) := by exact_mod_cast hk
  have hw : (∑ _i : Fin k, (1 : ℝ) / k) = 1 := by simp [hkR.ne']
  have h := Real.rpow_arith_mean_le_arith_mean_rpow Finset.univ
    (fun _ : Fin k => (1 : ℝ) / k) p.mass (fun _ _ => by positivity) hw
    (fun i _ => p.nonneg i) hα
  rw [← Finset.mul_sum, p.normalized, mul_one, ← Finset.mul_sum] at h
  have hm := mul_le_mul_of_nonneg_left h hkR.le
  have hright : (k : ℝ) * ((1 / (k : ℝ)) * ∑ i, p.mass i ^ α) = ∑ i, p.mass i ^ α := by
    field_simp
  rw [hright] at hm
  unfold finiteLNorm
  apply Real.rpow_le_rpow
  · positivity
  · simpa only [abs_of_nonneg (by positivity : 0 ≤ (1 : ℝ) / k),
      abs_of_nonneg (p.nonneg _), Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] using hm
  · positivity

/-- The additive `1/k` tolerance only doubles the relative norm error. -/
theorem finiteLNorm_empirical_error {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {α η : ℝ} (hα : 1 ≤ α) (hη : 0 ≤ η) (v : Fin k → ℝ)
    (hclose : ∀ i, |v i - p.mass i| ≤ η * (p.mass i + 1 / (k : ℝ))) :
    |finiteLNorm α v - finiteLNorm α p.mass| ≤ 2 * η * finiteLNorm α p.mass := by
  have hα0 : 0 < α := by linarith
  have hm := finiteLNorm_mono hα0 (fun i => v i - p.mass i)
    (fun i => η * (p.mass i + 1 / (k : ℝ))) (fun i => by
      rw [abs_of_nonneg (mul_nonneg hη (add_nonneg (p.nonneg i) (by positivity)))]
      exact hclose i)
  rw [finiteLNorm_smul hα0 hη] at hm
  have htri := finiteLNorm_add_le hα p.mass (fun _ => (1 : ℝ) / k)
  have huni := finiteLNorm_uniform_le hk p hα
  have he := finiteLNorm_reverse_triangle hα v p.mass
  nlinarith [mul_le_mul_of_nonneg_left htri hη, mul_le_mul_of_nonneg_left huni hη]

def empiricalNormEntropy {k : ℕ} (α : ℝ) (v : Fin k → ℝ) : ℝ :=
  -(α / (α - 1)) * Real.log (finiteLNorm α v)

theorem entropy_eq_norm_entropy {k : ℕ} (p : Simplex k) {α : ℝ} (hα : 0 < α) :
    entropy p α = empiricalNormEntropy α p.mass := by
  have he : (∑ i, |p.mass i| ^ α) = powerSum p α := by
    simp [powerSum, abs_of_nonneg, p.nonneg]
  unfold entropy entropyFromPower empiricalNormEntropy finiteLNorm
  rw [he, Real.log_rpow (simplex_powerSum_pos p α)]
  field_simp

private theorem logarithm_relative_error {V P r : ℝ} (hP : 0 < P)
    (hr : 0 ≤ r) (hr1 : r ≤ 1 / 4) (hVP : |V - P| ≤ r * P) :
    |Real.log V - Real.log P| ≤ (4 / 3) * r := by
  have hV : 0 < V := by
    have h := (abs_le.mp hVP).1
    nlinarith
  have hid : V / P - 1 = (V - P) / P := by field_simp
  have hratio : |V / P - 1| ≤ r := by
    rw [hid, abs_div, abs_of_pos hP]
    exact (div_le_iff₀ hP).2 hVP
  have h := abs_log_quarter hr hr1 hratio
  rwa [Real.log_div hV.ne' hP.ne'] at h

/-- Coordinate concentration implies the requested Rényi entropy error,
uniformly over every real order at least two. -/
theorem empirical_norm_entropy_error {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {α η : ℝ} (hα : 2 ≤ α) (hη : 0 ≤ η) (hη8 : η ≤ 1 / 8) (v : Fin k → ℝ)
    (hclose : ∀ i, |v i - p.mass i| ≤ η * (p.mass i + 1 / (k : ℝ))) :
    |empiricalNormEntropy α v - entropy p α| ≤ 8 * η := by
  have hα0 : 0 < α := by linarith
  have hα1 : 1 ≤ α := by linarith
  have herr := finiteLNorm_empirical_error hk p hα1 hη v hclose
  have hl := logarithm_relative_error (finiteLNorm_simplex_pos p α)
    (by positivity : 0 ≤ 2 * η) (by linarith : 2 * η ≤ 1 / 4) (by nlinarith :
      |finiteLNorm α v - finiteLNorm α p.mass| ≤ (2 * η) * finiteLNorm α p.mass)
  have hf0 : 0 ≤ α / (α - 1) := div_nonneg hα0.le (by linarith)
  have hf2 : α / (α - 1) ≤ 2 := (div_le_iff₀ (by linarith)).2 (by linarith)
  rw [entropy_eq_norm_entropy p hα0]
  unfold empiricalNormEntropy
  rw [← mul_sub, abs_mul, abs_neg, abs_of_nonneg hf0]
  have h := mul_le_mul hf2 hl (abs_nonneg _) (by norm_num : (0 : ℝ) ≤ 2)
  nlinarith

/-- For nonnegative empirical coordinates the norm estimator is exactly the
ordinary logarithm of the empirical power sum, including the all-zero fallback. -/
theorem empiricalNormEntropy_eq_power {k : ℕ} {α : ℝ} (hα : 0 < α)
    (v : Fin k → ℝ) (hv : ∀ i, 0 ≤ v i) :
    empiricalNormEntropy α v = entropyFromPower (α - 1) (∑ i, v i ^ α) := by
  have he : (∑ i, |v i| ^ α) = ∑ i, v i ^ α := by simp [abs_of_nonneg, hv]
  unfold empiricalNormEntropy finiteLNorm entropyFromPower
  rw [he]
  by_cases hs : (∑ i, v i ^ α) = 0
  · rw [hs, Real.zero_rpow (one_div_ne_zero hα.ne'), Real.log_zero]
    simp
  · have hp : 0 < ∑ i, v i ^ α := lt_of_le_of_ne
      (Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (hv i) α)) (Ne.symm hs)
    rw [Real.log_rpow hp]
    field_simp

def empiricalMaxEntropy {k : ℕ} (v : Fin k → ℝ) : ℝ :=
  -Real.log (sSup (Set.range v))

/-- The largest simplex coordinate is at least `1/k`. -/
theorem simplex_max_ge_uniform {k : ℕ} (hk : 0 < k) (p : Simplex k) :
    1 / (k : ℝ) ≤ sSup (Set.range p.mass) := by
  have hkR : 0 < (k : ℝ) := by exact_mod_cast hk
  have hb := (Set.finite_range p.mass).bddAbove
  have hsum : (∑ i, p.mass i) ≤ ∑ _i : Fin k, sSup (Set.range p.mass) :=
    Finset.sum_le_sum (fun i _ => le_csSup hb ⟨i, rfl⟩)
  rw [p.normalized] at hsum
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at hsum
  exact (div_le_iff₀ hkR).2 (by nlinarith)

theorem empirical_max_error {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {η : ℝ} (hη : 0 ≤ η) (v : Fin k → ℝ)
    (hclose : ∀ i, |v i - p.mass i| ≤ η * (p.mass i + 1 / (k : ℝ))) :
    |sSup (Set.range v) - sSup (Set.range p.mass)| ≤
      2 * η * sSup (Set.range p.mass) := by
  letI : Nonempty (Fin k) := ⟨⟨0, hk⟩⟩
  let V := sSup (Set.range v)
  let P := sSup (Set.range p.mass)
  have hp (i : Fin k) : p.mass i ≤ P := le_csSup (Set.finite_range p.mass).bddAbove ⟨i, rfl⟩
  have hv (i : Fin k) : v i ≤ V := le_csSup (Set.finite_range v).bddAbove ⟨i, rfl⟩
  have hu : 1 / (k : ℝ) ≤ P := simplex_max_ge_uniform hk p
  have hupper : V ≤ P + 2 * η * P := by
    apply csSup_le (Set.range_nonempty v)
    rintro y ⟨i, rfl⟩
    have h := (abs_le.mp (hclose i)).2
    nlinarith [hp i, mul_nonneg hη (sub_nonneg.mpr (hp i)), mul_nonneg hη (sub_nonneg.mpr hu)]
  have hlower : P ≤ V + 2 * η * P := by
    apply csSup_le (Set.range_nonempty p.mass)
    rintro y ⟨i, rfl⟩
    have h := (abs_le.mp (hclose i)).1
    nlinarith [hv i, mul_nonneg hη (sub_nonneg.mpr (hp i)), mul_nonneg hη (sub_nonneg.mpr hu)]
  exact abs_le.mpr ⟨by linarith, by linarith⟩

/-- The same coordinate event estimates min-entropy, without a finite-order limit. -/
theorem empirical_max_entropy_error {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {η : ℝ} (hη : 0 ≤ η) (hη8 : η ≤ 1 / 8) (v : Fin k → ℝ)
    (hclose : ∀ i, |v i - p.mass i| ≤ η * (p.mass i + 1 / (k : ℝ))) :
    |empiricalMaxEntropy v - minEntropy p| ≤ 8 * η := by
  have hkR : 0 < (k : ℝ) := by exact_mod_cast hk
  have hP : 0 < sSup (Set.range p.mass) :=
    (one_div_pos.mpr hkR).trans_le (simplex_max_ge_uniform hk p)
  have he := empirical_max_error hk p hη v hclose
  have hl := logarithm_relative_error hP (by positivity : 0 ≤ 2 * η)
    (by linarith : 2 * η ≤ 1 / 4) he
  unfold empiricalMaxEntropy minEntropy
  rw [show -Real.log (sSup (Set.range v)) - -Real.log (sSup (Set.range p.mass)) =
    -(Real.log (sSup (Set.range v)) - Real.log (sSup (Set.range p.mass))) by ring, abs_neg]
  linarith

end Renyi
