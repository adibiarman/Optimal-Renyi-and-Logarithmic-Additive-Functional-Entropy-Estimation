import Renyi.EndpointLocalCoefficients
import Renyi.CoupledLocalization
import Renyi.CoupledCoefficients

/-! Leading coefficients of the actual coupled polynomial, at the endpoint scale. -/
noncomputable section
open scoped BigOperators
open Set Polynomial
namespace Renyi

lemma endpointIntegral_inverse_weight_sharp {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) :
    (s * endpointIntegral N d s)⁻¹ ≤
      Real.exp (Real.log 12 + 1) * (N : ℝ) ^ (2 * s) := by
  have hi := endpointIntegral_pos hN hd hs
  have hl := endpointIntegral_normalized_lower hN hd hs
  have he := mul_le_mul_of_nonneg_left hl (Real.exp_pos ((Real.log 12 + 1) * s)).le
  have hid : Real.exp ((Real.log 12 + 1) * s) * Real.exp (-(Real.log 12 + 1) * s) = 1 := by
    rw [← Real.exp_add]
    have hz : (Real.log 12 + 1) * s + (-(Real.log 12 + 1)) * s = 0 := by ring
    rw [hz, Real.exp_zero]
  rw [hid] at he
  have hbound : (s * endpointIntegral N d s)⁻¹ ≤
      Real.exp ((Real.log 12 + 1) * s) * (N : ℝ) ^ (2 * s) := by
    rw [inv_eq_one_div]
    apply (div_le_iff₀ (mul_pos hs hi)).mpr
    nlinarith only [he]
  apply hbound.trans
  apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg (by positivity) _)
  apply Real.exp_le_exp.mpr
  have hc : 0 ≤ Real.log 12 + 1 := by have := Real.log_nonneg (by norm_num : (1 : ℝ) ≤ 12); linarith
  nlinarith

lemma coupledNormalizer_inverse_sharp {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s b : ℝ} {H : ℝ → ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hb : b < 1)
    (hH : ∀ x ∈ Icc (0 : ℝ) 1, 0 ≤ H x ∧ H x ≤ b) :
    (coupledNormalizer s (endpointKernel N d) H)⁻¹ ≤
      coupledLocalizationConstant * (N : ℝ) ^ (2 * s) := by
  have h := coupled_unweighted_bump_upper hN hd hs hs1 hb hH (by norm_num : (0 : ℝ) ≤ 1)
  have hp : ((N : ℝ) ^ 2) ^ s = (N : ℝ) ^ (2 * s) := by
    simpa using (Real.rpow_natCast_mul (by positivity : (0 : ℝ) ≤ N) 2 s).symm
  simpa [hp] using h

/-- The integral-polynomial coefficient norm retains the fractional endpoint power. -/
theorem endpointProfilePolynomial_local_mass_sharp {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hx : 0 ≤ x) :
    coefficientMass ((endpointProfilePolynomial N d s).comp (C x * X)) ≤
      Real.exp (Real.log 12 + 1) * (N : ℝ) ^ (2 * s) *
        Real.exp (2 * (d : ℝ) * (N : ℝ) * Real.sqrt x) := by
  have hi := endpointIntegral_pos hN hd hs
  have hw := weightedPrimitivePolynomial_coefficientMass ((endpointKernelPolynomial N d).comp (C x * X)) hs
  have hk := endpointKernelPolynomial_local_mass hx hN d
  have hi' := endpointIntegral_inverse_weight_sharp hN hd hs hs1
  unfold endpointProfilePolynomial
  rw [mul_comp, C_comp, weightedPrimitivePolynomial_comp_scale,
    coefficientMass_C_mul, abs_of_pos (inv_pos.mpr hi)]
  calc
    _ ≤ (endpointIntegral N d s)⁻¹ *
        (coefficientMass ((endpointKernelPolynomial N d).comp (C x * X)) / s) :=
      mul_le_mul_of_nonneg_left hw (inv_nonneg.mpr hi.le)
    _ = (s * endpointIntegral N d s)⁻¹ *
        coefficientMass ((endpointKernelPolynomial N d).comp (C x * X)) := by field_simp
    _ ≤ _ := mul_le_mul hi' hk (coefficientMass_nonneg _) (by positivity)

lemma endpointKernelPolynomial_coeff_zero {N : ℕ} (hN : 0 < N) (d : ℕ) :
    (endpointKernelPolynomial N d).coeff 0 = 1 := by
  rw [coeff_zero_eq_eval_zero, endpointKernelPolynomial_eval hN d (by norm_num : (0 : ℝ) ≤ 1), endpointKernel_zero hN]

lemma endpointProfilePolynomial_coeff_zero {N : ℕ} (hN : 0 < N) (d : ℕ) (s : ℝ) :
    (endpointProfilePolynomial N d s).coeff 0 = (s * endpointIntegral N d s)⁻¹ := by
  rw [endpointProfilePolynomial, coeff_C_mul, weightedPrimitivePolynomial_coeff,
    endpointKernelPolynomial_coeff_zero hN]
  simp

lemma highProfilePolynomial_coeff_zero {N : ℕ} (hN : 0 < N) (s f ω : ℝ) :
    (highProfilePolynomial N s f ω).coeff 0 = (highNormalizer N s f ω)⁻¹ := by
  simp [highProfilePolynomial, mul_coeff_zero, endpointKernelPolynomial_coeff_zero hN]

/-- The actual high arm starts with a coefficient of order N^(2s), uniformly as s tends to zero. -/
theorem highProfilePolynomial_leading_bound {N : ℕ} (hN : 0 < N) {s f ω : ℝ}
    (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hω : 0 ≤ ω) (hω1 : ω < 1) :
    |(highProfilePolynomial N s f ω).coeff 0| ≤
      coupledLocalizationConstant * (N : ℝ) ^ (2 * s) := by
  rw [highProfilePolynomial_coeff_zero hN,
    abs_of_pos (inv_pos.mpr (highNormalizer_pos hN hs hf hf1 hω hω1))]
  exact coupledNormalizer_inverse_sharp hN (by norm_num : 6 ≤ 6) hs hs1 hω1
    (fun _x hx => highShoulder_range hN hs hf hf1 hω hx.1 hx.2)

def lowProfileLocalConstant (Z : ℝ) : ℝ :=
  (coupledLocalizationConstant + Real.exp (Real.log 12 + 1) *
    (1 + Real.exp (4 * Real.sqrt Z))) * Real.exp (4 * Real.sqrt Z)

lemma lowProfileLocalConstant_pos (Z : ℝ) : 0 < lowProfileLocalConstant Z := by
  have hc : 0 < coupledLocalizationConstant := Real.exp_pos _
  unfold lowProfileLocalConstant
  positivity

/-- The actual low profile's local coefficient norm has only the fractional N power. -/
theorem lowProfilePolynomial_local_mass_sharp {N : ℕ} (hN : 0 < N) {s f x Z : ℝ}
    (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f < 1) (hx : 0 ≤ x)
    (hZ : (N : ℝ) ^ 2 * x ≤ Z) :
    coefficientMass ((lowProfilePolynomial N s f).comp (C x * X)) ≤
      lowProfileLocalConstant Z * (N : ℝ) ^ (2 * s) := by
  let R := Real.exp (4 * Real.sqrt Z)
  let E := Real.exp (Real.log 12 + 1)
  have hR : 0 < R := Real.exp_pos _
  have hc0 : 0 ≤ coupledLocalizationConstant := (Real.exp_pos _).le
  have hP : 0 ≤ (N : ℝ) ^ (2 * s) := Real.rpow_nonneg (by positivity) _
  have hk : coefficientMass ((endpointKernelPolynomial N 2).comp (C x * X)) ≤ R := by
    have h := endpointKernelPolynomial_local_mass_uniform hx hN 2 hZ
    norm_num at h
    exact h
  have hj : coefficientMass ((endpointProfilePolynomial N 2 s).comp (C x * X)) ≤
      E * (N : ℝ) ^ (2 * s) * R := by
    have h := endpointProfilePolynomial_local_mass_sharp hN (by norm_num : 2 ≤ 6) hs hs1 hx
    norm_num at h
    have hZ0 : 0 ≤ Z := (by positivity : 0 ≤ (N : ℝ) ^ 2 * x).trans hZ
    have hroot : (N : ℝ) * Real.sqrt x ≤ Real.sqrt Z := by
      have hxr := Real.sq_sqrt hx
      have hZr := Real.sq_sqrt hZ0
      have hn : 0 ≤ (N : ℝ) * Real.sqrt x := by positivity
      nlinarith [Real.sqrt_nonneg Z]
    apply h.trans
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    apply Real.exp_le_exp.mpr
    nlinarith
  have ha : (lowNormalizer N s f)⁻¹ ≤ coupledLocalizationConstant * (N : ℝ) ^ (2 * s) :=
    coupledNormalizer_inverse_sharp hN (by norm_num : 2 ≤ 6) hs hs1 hf1
      (fun _y hy => lowShoulder_range hN hs hf hy.1 hy.2)
  have hap := lowNormalizer_pos hN hs hf hf1
  have hleft : coefficientMass ((C (lowNormalizer N s f)⁻¹ * endpointKernelPolynomial N 2).comp (C x * X)) ≤
      coupledLocalizationConstant * (N : ℝ) ^ (2 * s) * R := by
    rw [mul_comp, C_comp, coefficientMass_C_mul, abs_of_pos (inv_pos.mpr hap)]
    exact mul_le_mul ha hk (coefficientMass_nonneg _) (by positivity)
  have hsub : coefficientMass ((1 - endpointKernelPolynomial N 2).comp (C x * X)) ≤ 1 + R := by
    rw [sub_comp, one_comp]
    exact (coefficientMass_sub_le _ _).trans (by simpa using add_le_add_left hk 1)
  have hscaled : coefficientMass ((C f * endpointProfilePolynomial N 2 s).comp (C x * X)) ≤
      E * (N : ℝ) ^ (2 * s) * R := by
    rw [mul_comp, C_comp, coefficientMass_C_mul, abs_of_nonneg hf]
    exact (mul_le_of_le_one_left (coefficientMass_nonneg _) hf1.le).trans hj
  have hright := (coefficientMass_mul_le
    ((C f * endpointProfilePolynomial N 2 s).comp (C x * X))
    ((1 - endpointKernelPolynomial N 2).comp (C x * X))).trans
      (mul_le_mul hscaled hsub (coefficientMass_nonneg _) (by positivity))
  unfold lowProfilePolynomial
  rw [add_comp, mul_comp (C f * endpointProfilePolynomial N 2 s)]
  apply (coefficientMass_add_le _ _).trans
  apply (add_le_add hleft hright).trans_eq
  unfold lowProfileLocalConstant R E
  ring

/-- Reversal pairs the first coefficient above m with a local coefficient norm. -/
theorem reverseScaledPolynomial_leading_cross_bound (P J : ℝ[X]) {m : ℕ}
    (hm : P.natDegree ≤ m) {a b R K : ℝ} (ha : 0 ≤ a) (hb : 0 < b)
    (hR : 0 ≤ R) (_hK : 0 ≤ K)
    (hJ : ∀ t : ℕ, |J.coeff (t + 1)| ≤ K * R ^ (t + 1)) :
    |(reverseScaledPolynomial P m a * J.comp (C b⁻¹ * X)).coeff (m + 1)| ≤
      K * R / b * coefficientMass (P.comp (C (a * R / b) * X)) := by
  unfold reverseScaledPolynomial
  rw [Finset.sum_mul, finset_sum_coeff]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  rw [coefficientMass_comp_scale_sum, Polynomial.sum_def, Finset.mul_sum]
  apply Finset.sum_le_sum
  intro t ht
  have htm := (le_natDegree_of_mem_supp t ht).trans hm
  have heq : m + 1 = (t + 1) + (m - t) := by omega
  rw [heq, coeff_monomial_mul, comp_C_mul_X_coeff]
  calc
    _ = |P.coeff t| * a ^ t * |J.coeff (t + 1)| * (b⁻¹) ^ (t + 1) := by
      rw [abs_mul, abs_mul, abs_mul, abs_of_nonneg (pow_nonneg ha t),
        abs_of_nonneg (pow_nonneg (inv_nonneg.mpr hb.le) _)]
      ring
    _ ≤ |P.coeff t| * a ^ t * (K * R ^ (t + 1)) * (b⁻¹) ^ (t + 1) := by
      exact mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left (hJ t) (by positivity)) (by positivity)
    _ = _ := by
      rw [abs_mul, abs_of_nonneg (pow_nonneg (div_nonneg (mul_nonneg ha hR) hb.le) t),
        div_pow, mul_pow, pow_succ R t, pow_succ b⁻¹ t]
      rw [inv_pow]
      field_simp

/-- Geometric coefficient control for the actual cutoff at its endpoint scale. -/
theorem endpointCutoffPolynomial_geometric_coeff {N : ℕ} (hN : 0 < N) (t : ℕ) :
    |(X * endpointProfilePolynomial N 6 1).coeff (t + 1)| ≤
      (24 * Real.exp 12) * ((N : ℝ) ^ 2) ^ (t + 1) := by
  have hN0 : 0 < (N : ℝ) := by exact_mod_cast hN
  have hN2 : 0 < (N : ℝ) ^ 2 := sq_pos_of_pos hN0
  let x : ℝ := ((N : ℝ) ^ 2)⁻¹
  have hx : 0 < x := inv_pos.mpr hN2
  have hscale : (N : ℝ) ^ 2 * x = 1 := mul_inv_cancel₀ hN2.ne'
  have hmass := endpointCutoffPolynomial_local_mass_uniform hN (by norm_num : 6 ≤ 6)
    hx.le (le_of_eq hscale)
  norm_num at hmass
  have hc := abs_coeff_le_coefficientMass
    ((X * endpointProfilePolynomial N 6 1).comp (C x * X)) (t + 1)
  rw [comp_C_mul_X_coeff, abs_mul, abs_of_pos (pow_pos hx _)] at hc
  have hbound := hc.trans (by simpa only [mul_comp, X_comp] using hmass)
  have hmul := mul_le_mul_of_nonneg_right hbound (pow_nonneg hN2.le (t + 1))
  have hcancel : x ^ (t + 1) * ((N : ℝ) ^ 2) ^ (t + 1) = 1 := by
    rw [← mul_pow]
    dsimp [x]
    rw [inv_mul_cancel₀ hN2.ne', one_pow]
  rwa [mul_assoc, hcancel, mul_one] at hmul

lemma shiftedPolynomial_leading_coeff (P : ℝ[X]) (c z : ℝ) (m : ℕ) :
    (C c * X ^ (m + 1) * P.comp (C z * X)).coeff (m + 1) = c * P.coeff 0 := by
  rw [mul_assoc, coeff_C_mul]
  have h := coeff_X_pow_mul (P.comp (C z * X)) (m + 1) 0
  simpa only [zero_add, comp_C_mul_X_coeff, pow_zero, mul_one] using congrArg (c * ·) h

/-- Concrete leading coefficient bound for the actual coupled polynomial. -/
theorem coupledQPolynomial_leading_bound {ℓ N m : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    (hdegree : 4 * (ℓ - 1) ≤ m) {γ a b fL f A B ω Z : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 < a) (hb : 0 < b)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1)
    (hZ : (ℓ : ℝ) ^ 2 * (a * (N : ℝ) ^ 2 / b) ≤ Z) :
    |(coupledQPolynomial ℓ N m γ a b fL f A B ω).coeff (m + 1)| ≤
      A * a ^ γ * ((24 * Real.exp 12) * (N : ℝ) ^ 2 / b *
        (lowProfileLocalConstant Z * (ℓ : ℝ) ^ (2 * γ))) +
      B / b ^ (1 - γ) * (coupledLocalizationConstant * (N : ℝ) ^ (2 * (1 - γ))) +
      (ω * (1 - B) / b ^ (1 - γ)) *
        (Real.exp (Real.log 12 + 1) * (N : ℝ) ^ (2 * (1 - γ))) := by
  let P := lowProfilePolynomial ℓ γ fL
  let R := reverseScaledPolynomial P m a
  let J := X * endpointProfilePolynomial N 6 1
  let z := C b⁻¹ * X
  have hpdeg : P.natDegree ≤ m := (lowProfilePolynomial_natDegree ℓ γ fL).trans hdegree
  have hRzero : R.coeff (m + 1) = 0 :=
    coeff_eq_zero_of_natDegree_lt ((reverseScaledPolynomial_natDegree P m a).trans_lt (Nat.lt_succ_self m))
  have hcross := reverseScaledPolynomial_leading_cross_bound P J hpdeg ha.le hb
    (sq_nonneg (N : ℝ)) (by positivity : 0 ≤ 24 * Real.exp 12)
    (endpointCutoffPolynomial_geometric_coeff hN)
  have hlocal := lowProfilePolynomial_local_mass_sharp hℓ hγ hγ1.le hfL hfL1
    (by positivity : 0 ≤ a * (N : ℝ) ^ 2 / b) hZ
  have hcross' : |(R * J.comp z).coeff (m + 1)| ≤
      (24 * Real.exp 12) * (N : ℝ) ^ 2 / b *
        (lowProfileLocalConstant Z * (ℓ : ℝ) ^ (2 * γ)) :=
    hcross.trans (mul_le_mul_of_nonneg_left hlocal (by positivity))
  have hlow : (C (A * a ^ γ) * R * (1 - J.comp z)).coeff (m + 1) =
      -(A * a ^ γ) * (R * J.comp z).coeff (m + 1) := by
    rw [mul_assoc, coeff_C_mul, mul_sub, mul_one, coeff_sub, hRzero]
    ring
  have hlowabs : |(C (A * a ^ γ) * R * (1 - J.comp z)).coeff (m + 1)| ≤
      A * a ^ γ * ((24 * Real.exp 12) * (N : ℝ) ^ 2 / b *
        (lowProfileLocalConstant Z * (ℓ : ℝ) ^ (2 * γ))) := by
    rw [hlow, abs_mul, abs_neg, abs_of_nonneg (mul_nonneg hA (Real.rpow_nonneg ha.le γ))]
    exact mul_le_mul_of_nonneg_left hcross' (by positivity)
  have hhigh := highProfilePolynomial_leading_bound hN (by linarith : 0 < 1 - γ)
    (by linarith : 1 - γ ≤ 1) hf hf1 hω hω1
  have hintegral : |(endpointProfilePolynomial N 6 (1 - γ)).coeff 0| ≤
      Real.exp (Real.log 12 + 1) * (N : ℝ) ^ (2 * (1 - γ)) := by
    rw [endpointProfilePolynomial_coeff_zero hN,
      abs_of_pos (inv_pos.mpr (mul_pos (by linarith) (endpointIntegral_pos hN (by norm_num) (by linarith))))]
    exact endpointIntegral_inverse_weight_sharp hN (by norm_num) (by linarith) (by linarith)
  have hhighabs : |(C (B / b ^ (1 - γ)) * X ^ (m + 1) *
      (highProfilePolynomial N (1 - γ) f ω).comp z).coeff (m + 1)| ≤
        B / b ^ (1 - γ) * (coupledLocalizationConstant * (N : ℝ) ^ (2 * (1 - γ))) := by
    rw [shiftedPolynomial_leading_coeff, abs_mul,
      abs_of_nonneg (div_nonneg hB (Real.rpow_nonneg hb.le _))]
    exact mul_le_mul_of_nonneg_left hhigh (by positivity)
  have hrestabs : |(C (ω * (1 - B) / b ^ (1 - γ)) * X ^ (m + 1) *
      (endpointProfilePolynomial N 6 (1 - γ)).comp z).coeff (m + 1)| ≤
        (ω * (1 - B) / b ^ (1 - γ)) *
          (Real.exp (Real.log 12 + 1) * (N : ℝ) ^ (2 * (1 - γ))) := by
    rw [shiftedPolynomial_leading_coeff, abs_mul,
      abs_of_nonneg (div_nonneg (mul_nonneg hω (sub_nonneg.mpr hB1)) (Real.rpow_nonneg hb.le _))]
    exact mul_le_mul_of_nonneg_left hintegral
      (div_nonneg (mul_nonneg hω (sub_nonneg.mpr hB1)) (Real.rpow_nonneg hb.le _))
  change |((C (A * a ^ γ) * R * (1 - z * (endpointProfilePolynomial N 6 1).comp z) +
    C (B / b ^ (1 - γ)) * X ^ (m + 1) * (highProfilePolynomial N (1 - γ) f ω).comp z) +
    C (ω * (1 - B) / b ^ (1 - γ)) * X ^ (m + 1) * (endpointProfilePolynomial N 6 (1 - γ)).comp z).coeff (m + 1)| ≤ _
  have hJ : J.comp z = z * (endpointProfilePolynomial N 6 1).comp z := by dsimp [J]; rw [mul_comp, X_comp]
  rw [← hJ, coeff_add, coeff_add]
  exact ((abs_add_le _ _).trans (add_le_add_right (abs_add_le _ _) _)).trans
    (add_le_add (add_le_add hlowabs hhighabs) hrestabs)

lemma fractional_endpoint_leading_identity {U R a b n γ : ℝ}
    (hU : 0 < U) (hR : 0 < R) (ha : 0 < a) (hb : 0 < b) (hn : 0 < n) :
    n ^ (-(1 - γ)) * a ^ γ * (R / b) * U ^ γ =
      (R / (n * b)) ^ (1 - γ) * (U * R * a / b) ^ γ := by
  have hRB : R / b = Real.exp (Real.log R - Real.log b) := by
    rw [Real.exp_sub, Real.exp_log hR, Real.exp_log hb]
  rw [Real.rpow_def_of_pos hn, Real.rpow_def_of_pos ha, hRB,
    Real.rpow_def_of_pos hU, Real.rpow_def_of_pos (div_pos hR (mul_pos hn hb)),
    Real.rpow_def_of_pos (div_pos (mul_pos (mul_pos hU hR) ha) hb),
    Real.log_div hR.ne' (mul_pos hn hb).ne', Real.log_mul hn.ne' hb.ne',
    Real.log_div (mul_pos (mul_pos hU hR) ha).ne' hb.ne',
    Real.log_mul (mul_pos hU hR).ne' ha.ne', Real.log_mul hU.ne' hR.ne']
  rw [← Real.exp_add, ← Real.exp_add, ← Real.exp_add, ← Real.exp_add]
  congr 1
  ring

lemma endpoint_leading_count_factor {N : ℕ} (hN : 0 < N) {b n δ : ℝ}
    (hb : 0 < b) (hn : 0 < n) :
    n ^ (-δ) * ((N : ℝ) ^ (2 * δ) / b ^ δ) =
      ((N : ℝ) ^ 2 / (n * b)) ^ δ := by
  have hN0 : 0 < (N : ℝ) := by exact_mod_cast hN
  have hp : (N : ℝ) ^ (2 * δ) = ((N : ℝ) ^ 2) ^ δ := by
    simpa using Real.rpow_natCast_mul hN0.le 2 δ
  rw [hp, Real.div_rpow (sq_nonneg _) (mul_pos hn hb).le, Real.mul_rpow hn.le hb.le,
    Real.rpow_neg hn.le δ]
  ring

/-- The source's first high coefficient, in count units, with an explicit local budget. -/
theorem coupledQPolynomial_leading_count_bound {ℓ N m : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    (hdegree : 4 * (ℓ - 1) ≤ m) {γ a b n fL f A B ω Z : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 < a) (hb : 0 < b) (hn : 0 < n)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1)
    (hZ : (ℓ : ℝ) ^ 2 * (a * (N : ℝ) ^ 2 / b) ≤ Z) :
    |n ^ (-(1 - γ)) * (coupledQPolynomial ℓ N m γ a b fL f A B ω).coeff (m + 1)| ≤
      ((24 * Real.exp 12) * A * lowProfileLocalConstant Z * Z ^ γ +
        B * coupledLocalizationConstant + ω * (1 - B) * Real.exp (Real.log 12 + 1)) *
          ((N : ℝ) ^ 2 / (n * b)) ^ (1 - γ) := by
  let F := ((N : ℝ) ^ 2 / (n * b)) ^ (1 - γ)
  let T := (ℓ : ℝ) ^ 2 * (a * (N : ℝ) ^ 2 / b)
  have hN0 : 0 < (N : ℝ) := by exact_mod_cast hN
  have hℓ0 : 0 < (ℓ : ℝ) := by exact_mod_cast hℓ
  have hT : 0 < T := by dsimp [T]; positivity
  have hF : 0 ≤ F := by dsimp [F]; positivity
  have hnPow : 0 < n ^ (-(1 - γ)) := Real.rpow_pos_of_pos hn _
  have hbase := coupledQPolynomial_leading_bound hℓ hN hdegree hγ hγ1 ha hb hfL hfL1
    hf hf1 hA hB hB1 hω hω1 hZ
  have hcross : n ^ (-(1 - γ)) *
      (A * a ^ γ * ((24 * Real.exp 12) * (N : ℝ) ^ 2 / b *
        (lowProfileLocalConstant Z * (ℓ : ℝ) ^ (2 * γ)))) =
      (24 * Real.exp 12) * A * lowProfileLocalConstant Z * F * T ^ γ := by
    have hp : (ℓ : ℝ) ^ (2 * γ) = ((ℓ : ℝ) ^ 2) ^ γ := by
      simpa using Real.rpow_natCast_mul hℓ0.le 2 γ
    have h := fractional_endpoint_leading_identity (sq_pos_of_pos hℓ0) (sq_pos_of_pos hN0) ha hb hn (γ := γ)
    rw [hp]
    have hT' : (ℓ : ℝ) ^ 2 * (N : ℝ) ^ 2 * a / b = T := by dsimp [T]; ring
    rw [hT'] at h
    convert congrArg (fun v : ℝ => ((24 * Real.exp 12) * A * lowProfileLocalConstant Z) * v) h using 1 <;> ring
  have hhigh : n ^ (-(1 - γ)) *
      (B / b ^ (1 - γ) * (coupledLocalizationConstant * (N : ℝ) ^ (2 * (1 - γ)))) =
        B * coupledLocalizationConstant * F := by
    have h := endpoint_leading_count_factor hN hb hn (δ := 1 - γ)
    convert congrArg (fun v : ℝ => (B * coupledLocalizationConstant) * v) h using 1
    ring
  have hrest : n ^ (-(1 - γ)) *
      ((ω * (1 - B) / b ^ (1 - γ)) *
        (Real.exp (Real.log 12 + 1) * (N : ℝ) ^ (2 * (1 - γ)))) =
        (ω * (1 - B) * Real.exp (Real.log 12 + 1)) * F := by
    have h := endpoint_leading_count_factor hN hb hn (δ := 1 - γ)
    convert congrArg (fun v : ℝ => (ω * (1 - B) * Real.exp (Real.log 12 + 1)) * v) h using 1
    ring
  rw [abs_mul, abs_of_pos hnPow]
  apply (mul_le_mul_of_nonneg_left hbase hnPow.le).trans
  rw [mul_add, mul_add, hcross, hhigh, hrest]
  have hpow : T ^ γ ≤ Z ^ γ := Real.rpow_le_rpow hT.le hZ hγ.le
  have hnonneg : 0 ≤ (24 * Real.exp 12) * A * lowProfileLocalConstant Z * F := by
    have hc := (lowProfileLocalConstant_pos Z).le
    positivity
  have hm := mul_le_mul_of_nonneg_left hpow hnonneg
  calc
    _ ≤ (24 * Real.exp 12) * A * lowProfileLocalConstant Z * F * Z ^ γ +
        B * coupledLocalizationConstant * F + (ω * (1 - B) * Real.exp (Real.log 12 + 1)) * F := by linarith
    _ = _ := by dsimp [F]; ring

def coupledLeadingCoefficientConstant : ℝ :=
  (24 * Real.exp 12) * lowProfileLocalConstant 1 + coupledLocalizationConstant + Real.exp (Real.log 12 + 1)

lemma coupledLeadingCoefficientConstant_pos : 0 < coupledLeadingCoefficientConstant := by
  have h1 := lowProfileLocalConstant_pos 1
  have h2 : 0 < coupledLocalizationConstant := Real.exp_pos _
  unfold coupledLeadingCoefficientConstant
  positivity

/-- Uniform CC7 for the actual coefficient, under the dimensionless endpoint constraint. -/
theorem coupledQPolynomial_leading_count_uniform {ℓ N m : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    (hdegree : 4 * (ℓ - 1) ≤ m) {γ a b n fL f A B ω L Cscale : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 < a) (hb : 0 < b) (hn : 0 < n)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1)
    (hZ : (ℓ : ℝ) ^ 2 * (a * (N : ℝ) ^ 2 / b) ≤ 1)
    (hL : 0 < L) (hC : 0 < Cscale) (hscale : (N : ℝ) ^ 2 / (n * b) ≤ Cscale * L) :
    |n ^ (-(1 - γ)) * (coupledQPolynomial ℓ N m γ a b fL f A B ω).coeff (m + 1)| ≤
      (coupledLeadingCoefficientConstant * max 1 Cscale) * (L / (1 - γ)) ^ (1 - γ) := by
  have hδ : 0 < 1 - γ := by linarith
  have hδ1 : 1 - γ ≤ 1 := by linarith
  have hmain := coupledQPolynomial_leading_count_bound hℓ hN hdegree hγ hγ1 ha hb hn
    hfL hfL1 hf hf1 hA hB hB1 hω hω1 hZ
  rw [Real.one_rpow, mul_one] at hmain
  have hbudget : (24 * Real.exp 12) * A * lowProfileLocalConstant 1 +
      B * coupledLocalizationConstant + ω * (1 - B) * Real.exp (Real.log 12 + 1) ≤
        coupledLeadingCoefficientConstant := by
    have hleft := mul_le_mul_of_nonneg_left hA1
      (show 0 ≤ (24 * Real.exp 12) * lowProfileLocalConstant 1 by
        have := (lowProfileLocalConstant_pos 1).le; positivity)
    have hmiddle := mul_le_mul_of_nonneg_right hB1
      (show 0 ≤ coupledLocalizationConstant from (Real.exp_pos _).le)
    have hrest : ω * (1 - B) ≤ 1 :=
      (mul_le_of_le_one_right hω (by linarith : 1 - B ≤ 1)).trans hω1.le
    have hlast := mul_le_mul_of_nonneg_right hrest (Real.exp_pos (Real.log 12 + 1)).le
    unfold coupledLeadingCoefficientConstant
    nlinarith only [hleft, hmiddle, hlast]
  have hcpow : Cscale ^ (1 - γ) ≤ max 1 Cscale := by
    by_cases hc1 : Cscale ≤ 1
    · exact (Real.rpow_le_one hC.le hc1 hδ.le).trans (le_max_left _ _)
    · have hc1' : 1 ≤ Cscale := by linarith
      have h := Real.rpow_le_rpow_of_exponent_le hc1' hδ1
      rw [Real.rpow_one] at h
      exact h.trans (le_max_right _ _)
  have hLdiv : L ≤ L / (1 - γ) := by
    apply (le_div_iff₀ hδ).mpr
    nlinarith
  have hpower : ((N : ℝ) ^ 2 / (n * b)) ^ (1 - γ) ≤
      max 1 Cscale * (L / (1 - γ)) ^ (1 - γ) := by
    apply (Real.rpow_le_rpow (by positivity) hscale hδ.le).trans
    rw [Real.mul_rpow hC.le hL.le]
    exact mul_le_mul hcpow (Real.rpow_le_rpow hL.le hLdiv hδ.le) (by positivity) (by positivity)
  apply hmain.trans
  apply (mul_le_mul hbudget hpower (by positivity) coupledLeadingCoefficientConstant_pos.le).trans_eq
  ring

end Renyi
