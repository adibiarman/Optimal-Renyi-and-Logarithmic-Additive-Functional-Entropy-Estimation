import Renyi.PilotHistogramToIID
import Renyi.UpperParameters

/-! Fixed iid implementation and rate budget for noninteger histogram estimators. -/
noncomputable section
open scoped BigOperators NNReal
namespace Renyi

def nonintegerPoissonMean (k:ℕ) (alpha eps D:ℝ) : ℝ≥0 :=
  Real.toNNReal (upperSample k alpha eps D)

theorem nonintegerPoissonMean_coe {k:ℕ} {alpha eps D:ℝ} (hk:0<k)
    (ha:1<alpha) (hg:0<fractionalPart alpha) (hg1:fractionalPart alpha<1) (hD:0<D) :
    (nonintegerPoissonMean k alpha eps D:ℝ)=upperSample k alpha eps D := by
  exact Real.coe_toNNReal _ (upperSample_pos hk ha hg hg1 hD).le

theorem upperSample_ge_D {k:ℕ} {alpha eps D:ℝ} (hk:0<k)
    (ha:1<alpha) (hg:0<fractionalPart alpha) (hg1:fractionalPart alpha<1) (hD:0≤D) :
    D≤upperSample k alpha eps D := by
  have hk1:(1:ℝ)≤k := by exact_mod_cast hk
  have ha0:0<alpha := by linarith
  have hpow:1≤(k:ℝ)^(1-1/alpha) :=
    Real.one_le_rpow hk1 (by have := (div_le_one ha0).mpr ha.le; linarith)
  have hx:=one_le_rootMultiplier (k:=k) (ε:=eps) ha hg hg1
  have h1:=mul_le_mul_of_nonneg_left ha.le hD
  have h2:=mul_le_mul_of_nonneg_left hpow (mul_nonneg hD ha0.le)
  have h3:=mul_le_mul_of_nonneg_left hx
    (show 0≤D*alpha*(k:ℝ)^(1-1/alpha) by positivity)
  unfold upperSample
  simpa only [mul_one] using h1.trans (by simpa only [mul_one] using h2.trans (by simpa only [mul_one] using h3))

/-- An explicit independent main/pilot estimator with the source asymmetric band
is achievable by an actual fixed iid estimator at the claimed noninteger scale. -/
theorem noninteger_iid_upper_of_histogram_band {k:ℕ} {alpha eps D:ℝ}
    (hk:0<k) (ha:1<alpha) (hg:0<fractionalPart alpha) (hg1:fractionalPart alpha<1)
    (hD:1≤D) (hDtail:3*Real.log 12≤D) (cp:ℝ≥0) (F:PilotHistogram k→ℝ)
    (hband:∀p:Simplex k,(pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure.real
      {h | F h<Real.exp (-2*eps*(alpha-1))*powerSum p alpha ∨ powerSum p alpha<F h}≤1/4) :
    ∃m:ℕ,(m:ℝ)≤(3*(1+(cp:ℝ))*D)*
      (alpha*(k:ℝ)^(1-1/alpha)*rootMultiplier k alpha eps) ∧ Achievable k m alpha eps := by
  have hD0:0<D:=lt_of_lt_of_le zero_lt_one hD
  have hn:=upperSample_ge_D (eps:=eps) hk ha hg hg1 hD0.le
  have hncoe:=nonintegerPoissonMean_coe (eps:=eps) hk ha hg hg1 hD0
  have hbudget:upperSample k alpha eps D≤
      (((1+cp)*nonintegerPoissonMean k alpha eps D:ℝ≥0):ℝ) := by
    simp only [NNReal.coe_mul,NNReal.coe_add,NNReal.coe_one,hncoe]
    have hp:=mul_nonneg cp.coe_nonneg (upperSample_pos hk ha hg hg1 hD0 (ε:=eps)).le
    nlinarith only [hp]
  obtain ⟨m,hm,hach⟩ := iid_upper_of_pilotHistogram_band
    (nonintegerPoissonMean k alpha eps D) cp ha eps F hband
    (hDtail.trans (hn.trans hbudget)) (hD.trans (hn.trans hbudget))
  refine ⟨m,?_,hach⟩
  rw [hncoe] at hm
  unfold upperSample at hm
  nlinarith only [hm]

/-- On the noninteger unsaturated branch this is the public model rate. -/
theorem noninteger_iid_rate_upper_of_histogram_band {k:ℕ} {alpha eps D:ℝ}
    (hk:0<k) (ha:1<alpha) (hg:0<fractionalPart alpha) (hg1:fractionalPart alpha<1)
    (horder:alpha<Real.log k) (hnotint:¬∃r:ℕ,alpha=(r:ℝ))
    (hD:1≤D) (hDtail:3*Real.log 12≤D) (cp:ℝ≥0) (F:PilotHistogram k→ℝ)
    (hband:∀p:Simplex k,(pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure.real
      {h | F h<Real.exp (-2*eps*(alpha-1))*powerSum p alpha ∨ powerSum p alpha<F h}≤1/4) :
    ∃m:ℕ,(m:ℝ)≤(3*(1+(cp:ℝ))*D)*rate k alpha eps ∧ Achievable k m alpha eps := by
  have hrate:rate k alpha eps=alpha*(k:ℝ)^(1-1/alpha)*rootMultiplier k alpha eps := by
    simp only [rate,extendedMultiplier,if_neg (not_le.mpr horder),if_neg hnotint]
  rw [hrate]
  exact noninteger_iid_upper_of_histogram_band hk ha hg hg1 hD hDtail cp F hband

end Renyi
