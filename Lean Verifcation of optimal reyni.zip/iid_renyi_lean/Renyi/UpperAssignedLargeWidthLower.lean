import Renyi.ActualAssignedMean
import Renyi.AssignedLowerTransfer
import Renyi.UpperLargeWidthLower

/-! The complete actual lower transfer accepts a realized heavy aggregate. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 700000

/-- A fixed lower heavy gap and the actual source light polynomial imply the
full corrected lower margin. The margin constant is selected before every
count/noise calibration parameter; only the final D threshold depends on those. -/
theorem upper_actual_assigned_large_width_bias_lower {eps fL f qL qH M lambda : ℝ}
    (heps : 0<eps) (hfL : 0<fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hM : 1≤M) (hlambda : 0<lambda) (hlambdaC : lambda≤Real.exp (-2*coupledProfileConstant))
    (hqL : Real.exp (-(eps/2))<qL) (hqLf : qL<fL)
    (hqH : Real.exp (-7*(eps/2)/8)<qH) (hqHf : qH<f) :
    ∃ C : ℝ, 0≤C ∧ ∀ (Ch cu u0 cH : ℝ),
      2*C+2≤Ch → 0≤cu → 0<u0 → cu≤min 1 (eps/4)/2 → 0<cH → cu*u0<cH →
      ∃ c : ℝ, 0<c ∧ ∀ (C0 d cb CL cL : ℝ),
        100≤C0 → 0<d → 0<cb → 1≤CL → 0<cL → 1≤cb*CL →
        ∃ D0 : ℝ, 1≤D0 ∧ ∀ (k : ℕ) (alpha D heavy : ℝ),
          0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → D0≤D →
          4*C*(fractionalPart alpha*(1-fractionalPart alpha))≤2*eps*(alpha-1) →
          ∀ (p : Simplex k) (light : Fin k→Bool),
            (∀ i, light i=true → p.mass i≤upperB k alpha eps D cb CL cL) →
            upperKappa alpha eps*(1+cH)*assignedHeavyPower p light alpha≤heavy →
          upperKappa alpha eps*powerSum p alpha+
            c*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d u0≤
          actualAssignedOracleMean p light heavy alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d := by
  obtain ⟨C,cg,hC,hcg,hmean⟩ := actualCoupledPolynomial_light_sum_lower
    heps hfL hfL1 hf hf1 hM hlambda hlambdaC hqL hqLf hqH hqHf
  refine ⟨C,hC,?_⟩
  intro Ch cu u0 cH hCh hcu hu0 hcua hcH hhead
  have hCh0 : 0≤Ch := by linarith only [hCh,hC]
  obtain ⟨cbas,hcbas,hbase⟩ := upper_rescaling_damped_baseline heps hC hCh hcu hu0 hcua
  let r0 := (1+cu*u0)⁻¹
  let sH := r0*(1+cH)-1
  have hden0 : 0<1+cu*u0 := by positivity
  have hr0 : 0<r0 := inv_pos.mpr hden0
  have hsH : 0<sH := by
    have hid : sH=(cH-cu*u0)/(1+cu*u0) := by dsimp [sH,r0];field_simp;ring
    rw [hid]
    exact div_pos (sub_pos.mpr hhead) hden0
  let c := min (1/2:ℝ) (min cbas (min (r0*cg) (sH/(1+u0))))
  have hc : 0<c := lt_min (by norm_num) (lt_min hcbas (lt_min (mul_pos hr0 hcg) (by positivity)))
  refine ⟨c,hc,?_⟩
  intro C0 d cb CL cL hC0 hd hcb hCL hcL hcbCL
  obtain ⟨D0,hD0,hpaid⟩ := upper_actual_cutoff_error_paid heps hCh0 hcb hlambda hCL hcL hC0 hd
  refine ⟨D0,hD0,?_⟩
  intro k alpha D heavy hk ha hg hg1 hD hlarge p light hlight hheavy
  have ha1 : 1<alpha := by linarith only [ha]
  have hDpos : 0<D := zero_lt_one.trans_le (hD0.trans hD)
  let a := upperA k alpha eps Ch D cb lambda CL cL
  let b := upperB k alpha eps D cb CL cL
  let N := upperDegree alpha CL cL (rootMultiplier k alpha eps)
  let Bt := ∑ i, if light i then if a≤p.mass i then (p.mass i)^alpha*min ((N:ℝ)^2*(p.mass i/b)) 1 else 0 else 0
  let err := (k:ℝ)*100^(upperOrderFloor alpha+1)*a^alpha
  have hb : 0<b := upperB_pos hk ha1 hg hg1 hDpos hcb hCL hcL (ε:=eps)
  have ha0 : 0≤a := (upper_actual_count_geometry hk ha hg hg1 heps hCh0 hDpos hcb hlambda
    (by linarith only [coupled_capacity_lambda_le_one hlambdaC] : lambda≤4) hCL hcL hcbCL).1.le
  have herr : 0≤err := by dsimp [err]; positivity
  have hPL : 0≤assignedLightPower p light alpha := by
    apply Finset.sum_nonneg
    intro i _
    split_ifs
    · exact Real.rpow_nonneg (p.nonneg i) _
    · exact le_refl _
  have hPH : 0≤assignedHeavyPower p light alpha := by
    apply Finset.sum_nonneg
    intro i _
    split_ifs
    · exact le_refl _
    · exact Real.rpow_nonneg (p.nonneg i) _
  have hB0 : 0≤actualForwardBonus p alpha eps D cb CL cL := by
    apply Finset.sum_nonneg
    intro i _
    exact mul_nonneg (Real.rpow_nonneg (p.nonneg i) _)
      (le_min (mul_nonneg (sq_nonneg _) (div_nonneg (p.nonneg i) hb.le)) (by norm_num))
  have hBt : 0≤Bt := by
    apply Finset.sum_nonneg
    intro i _
    split_ifs
    · exact mul_nonneg (Real.rpow_nonneg (p.nonneg i) _)
        (le_min (mul_nonneg (sq_nonneg _) (div_nonneg (p.nonneg i) hb.le)) (by norm_num))
    · exact le_refl _
    · exact le_refl _
  have hbonus := assigned_forward_bonus_cutoff_loss (N:=N) (b:=b) ha0 (by linarith only [ha] : 0≤alpha) p light
  have hpow : (1:ℝ)≤100^(upperOrderFloor alpha+1) := one_le_pow₀ (by norm_num : (1:ℝ)≤100)
  have hlowerr : (k:ℝ)*a^alpha≤err := by
    have hh := mul_le_mul_of_nonneg_right hpow (mul_nonneg (Nat.cast_nonneg k) (Real.rpow_nonneg ha0 alpha))
    dsimp only [err]
    nlinarith only [hh]
  have hB : actualForwardBonus p alpha eps D cb CL cL≤Bt+assignedHeavyPower p light alpha+err := by
    exact hbonus.trans (add_le_add_left hlowerr (Bt+assignedHeavyPower p light alpha))
  have hκ : 0≤upperKappa alpha eps := (Real.exp_pos _).le
  have hκ1 : upperKappa alpha eps≤1 := Real.exp_le_one_iff.mpr (by nlinarith only [heps,ha1])
  have hk0 : upperKappa alpha eps≤Real.exp (-upperE0 k alpha eps Ch) := by
    have hh := (upper_reserved_interval (k:=k) ha1 hg hg1 heps hCh0).2
    apply Real.exp_le_exp.mpr
    linarith only [hh]
  have hu := (upperU_pos (k:=k) (eps:=eps) ha1 hg hg1 hu0).le
  have huU : upperU k alpha eps u0≤u0 := min_le_right _ _
  have hrange := upperRescaling_range (k:=k) (eps:=eps) ha1 hg hg1 hcu hu0
  have hden : 0<1+cu*upperU k alpha eps u0 := by positivity
  have hr : r0≤upperRescaling k alpha eps cu u0 := by
    have hh := add_le_add_left (mul_le_mul_of_nonneg_left huU hcu) 1
    simpa only [r0,upperRescaling,one_div] using one_div_le_one_div_of_le hden hh
  have hheavy' : upperKappa alpha eps*assignedHeavyPower p light alpha+
      sH*upperKappa alpha eps*assignedHeavyPower p light alpha≤upperRescaling k alpha eps cu u0*heavy := by
    have h1 := mul_le_mul_of_nonneg_right hr
      (mul_nonneg (mul_nonneg hκ (show 0≤1+cH by positivity)) hPH)
    have h2 := mul_le_mul_of_nonneg_left hheavy hrange.1.le
    dsimp only [sH] at *
    nlinarith only [h1,h2]
  have hchi : 0≤min (alpha-1) 1 := le_min (by linarith only [ha1]) (by norm_num)
  have hbm := hbase k alpha ha1 hg hg1 hlarge
  have hmean' := hmean k alpha Ch D cb CL cL hk ha hg hg1 hCh0 hDpos hcb hCL hcL hcbCL p light hlight
  change Real.exp (-upperE0 k alpha eps Ch)*Real.exp (-C*(fractionalPart alpha*(1-fractionalPart alpha)))*assignedLightPower p light alpha+
    cg*Real.exp (-upperE0 k alpha eps Ch)*Bt≤actualLightPolynomialMean p light alpha eps Ch D cb lambda CL cL fL f M+err at hmean'
  have hpaid' := hpaid k alpha D hk ha hg hg1 hD
  change err≤actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d at hpaid'
  have hh := assigned_corrected_lower_margin_transfer (assigned_power_partition p light alpha) hPL hPH hB0 hBt
    herr hpaid' hκ hκ1 hk0 hu huU hr0 hr hrange.2 hcbas hcg hsH hchi (min_le_right _ _)
    (by simpa only [mul_assoc] using hbm) hmean' hheavy' hB
  simpa only [actualBiasBudget,actualAssignedOracleMean,c,r0,sH] using hh

end Renyi
