import Renyi.Pilot
import Renyi.PositiveCounts
import Renyi.PolynomialCoefficientMass
import Renyi.RawPoissonMoments

/-! Sampling contributions caused by incorrect pilot classification. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Polynomial
namespace Renyi

theorem polynomial_abs_eval_large {P : ℝ[X]} {z : ℝ} (hz : 1 ≤ z) :
    |P.eval z| ≤ coefficientMass P * z ^ P.natDegree := by
  rw [Polynomial.eval_eq_sum, Polynomial.sum_def]
  calc
    _ ≤ ∑ j ∈ P.support, |P.coeff j * z ^ j| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ j ∈ P.support, |P.coeff j| * z ^ P.natDegree := by
      apply Finset.sum_le_sum
      intro j hj
      rw [abs_mul, abs_of_nonneg (pow_nonneg (by linarith : 0 ≤ z) j)]
      exact mul_le_mul_of_nonneg_left (pow_le_pow_right₀ hz (P.le_natDegree_of_mem_supp j hj)) (abs_nonneg _)
    _ = _ := by rw [← Finset.sum_mul]; rfl

/-- Exponential pilot damping controls the actual polynomial, uniformly for
all inputs outside its approximation interval. -/
theorem false_light_polynomial_damping {P : ℝ[X]} {L C Cd cstar cp cb z : ℝ}
    (hL : 0 ≤ L) (hC : 0 ≤ C) (hCd : 0 ≤ Cd) (hcstar : 0 ≤ cstar)
    (hz : 1 ≤ z) (hdegree : (P.natDegree : ℝ) ≤ Cd * L)
    (hcoef : coefficientMass P ≤ Real.exp (C * L))
    (hcp : 8 * (C + Cd + cstar) ≤ cp * cb) :
    Real.exp (-(cp * cb * L * z) / 8) * |P.eval z| ≤ Real.exp (-cstar * L) := by
  have hzpos : 0 < z := lt_of_lt_of_le zero_lt_one hz
  have hlog0 : 0 ≤ Real.log z := Real.log_nonneg hz
  have hlog1 : Real.log z ≤ z := (Real.log_le_sub_one_of_pos hzpos).trans (by linarith)
  have heval : |P.eval z| ≤ Real.exp (C * L) * z ^ P.natDegree :=
    (polynomial_abs_eval_large hz).trans
      (mul_le_mul_of_nonneg_right hcoef (pow_nonneg hzpos.le _))
  have hdlog : (P.natDegree : ℝ) * Real.log z ≤ Cd * L * z := by
    exact (mul_le_mul_of_nonneg_right hdegree hlog0).trans
      (mul_le_mul_of_nonneg_left hlog1 (mul_nonneg hCd hL))
  have hparam := mul_le_mul_of_nonneg_right hcp (mul_nonneg hL hzpos.le)
  have hCz := mul_le_mul_of_nonneg_left hz (mul_nonneg (add_nonneg hC hcstar) hL)
  have hexponent : C * L + (P.natDegree : ℝ) * Real.log z - cp * cb * L * z / 8 ≤ -cstar * L := by
    nlinarith
  calc
    _ ≤ Real.exp (-(cp * cb * L * z) / 8) * (Real.exp (C * L) * z ^ P.natDegree) :=
      mul_le_mul_of_nonneg_left heval (Real.exp_pos _).le
    _ = Real.exp (C * L + (P.natDegree : ℝ) * Real.log z - cp * cb * L * z / 8) := by
      rw [← Real.rpow_natCast, Real.rpow_def_of_pos hzpos, ← Real.exp_add, ← Real.exp_add]
      congr 1
      ring
    _ ≤ _ := Real.exp_le_exp.mpr hexponent

/-- The complete false-light mean bound under the actual Poisson pilot law.
`P` is the polynomial in the rescaled argument; its coefficient bound is
therefore precisely the rescaled coefficient sum from the source lemma. -/
theorem false_light_mean_bound {P : ℝ[X]} {n b p L C Cd cstar cp cb B a : ℝ}
    (hn : 0 < n) (hb : 0 < b) (hp : b ≤ p) (hL : 0 ≤ L)
    (hC : 0 ≤ C) (hCd : 0 ≤ Cd) (hcstar : 0 ≤ cstar)
    (hcp0 : 0 < cp) (ha : 0 ≤ a) (hnb : n * b = cb * L)
    (hcutoff : 2 * B * a ≤ n * b)
    (hdegree : (P.natDegree : ℝ) ≤ Cd * L)
    (hcoef : coefficientMass P ≤ Real.exp (C * L))
    (hcp : 8 * (C + Cd + cstar) ≤ cp * cb) :
    poissonLowerMass ⟨cp * n * p, mul_nonneg (mul_nonneg hcp0.le hn.le) (hb.le.trans hp)⟩ (cp * B * a) *
      |b ^ a * P.eval (p / b)| ≤ Real.exp (-cstar * L) * p ^ a := by
  have hp0 : 0 < p := hb.trans_le hp
  have hz : 1 ≤ p / b := (one_le_div hb).2 hp
  have hthreshold : cp * B * a ≤ (cp * n * p) / 2 := by
    have hnp := mul_le_mul_of_nonneg_left hp hn.le
    nlinarith
  have htail := poissonLowerMass_half (⟨cp * n * p, by positivity⟩ : ℝ≥0) hthreshold
  have hmean : cp * n * p = cp * cb * L * (p / b) := by
    calc
      _ = cp * (n * b) * (p / b) := by field_simp
      _ = _ := by rw [hnb]; ring
  have hdamp := false_light_polynomial_damping hL hC hCd hcstar hz hdegree hcoef hcp
  have habs : |b ^ a * P.eval (p / b)| = b ^ a * |P.eval (p / b)| := by
    rw [abs_mul, abs_of_nonneg (Real.rpow_nonneg hb.le _)]
  rw [habs]
  calc
    _ ≤ Real.exp (-(cp * n * p) / 8) * (b ^ a * |P.eval (p / b)|) :=
      mul_le_mul_of_nonneg_right htail (by positivity)
    _ = b ^ a * (Real.exp (-(cp * cb * L * (p / b)) / 8) * |P.eval (p / b)|) := by
      rw [hmean]
      ring
    _ ≤ b ^ a * Real.exp (-cstar * L) :=
      mul_le_mul_of_nonneg_left hdamp (Real.rpow_nonneg hb.le _)
    _ ≤ Real.exp (-cstar * L) * p ^ a := by
      have hpow := Real.rpow_le_rpow hb.le hp ha
      nlinarith [mul_le_mul_of_nonneg_right hpow (Real.exp_pos (-cstar * L)).le]

def poissonUpperMass (lam : ℝ≥0) (T : ℝ) : ℝ :=
  ∑' y : ℕ, if T < (y : ℝ) then poissonPMFReal lam y else 0

theorem poissonUpperMass_summable (lam : ℝ≥0) (T : ℝ) :
    Summable (fun y : ℕ => if T < (y : ℝ) then poissonPMFReal lam y else 0) := by
  apply (poissonPMFRealSum lam).summable.of_nonneg_of_le
  · intro y
    split_ifs <;> simp [poissonPMFReal_nonneg]
  · intro y
    split_ifs <;> simp [poissonPMFReal_nonneg]

theorem poissonUpperMass_nonneg (lam : ℝ≥0) (T : ℝ) : 0 ≤ poissonUpperMass lam T := by
  apply tsum_nonneg
  intro y
  split_ifs <;> simp [poissonPMFReal_nonneg]

theorem poissonUpperMass_exp_bound (lam : ℝ≥0) (T : ℝ) {t : ℝ} (ht : 0 ≤ t) :
    poissonUpperMass lam T ≤ Real.exp (-t * T + (lam : ℝ) * (Real.exp t - 1)) := by
  have hg := (poisson_exp_hasSum lam t).mul_left (Real.exp (-t * T))
  have hbound (y : ℕ) :
      (if T < (y : ℝ) then poissonPMFReal lam y else 0) ≤
        Real.exp (-t * T) * (Real.exp (t * y) * poissonPMFReal lam y) := by
    split_ifs with hy
    · have he : 1 ≤ Real.exp (t * ((y : ℝ) - T)) :=
        Real.one_le_exp_iff.mpr (mul_nonneg ht (sub_pos.mpr hy).le)
      have h := mul_le_mul_of_nonneg_right he (poissonPMFReal_nonneg (r := lam) (n := y))
      rw [← mul_assoc, ← Real.exp_add]
      convert h using 1 <;> congr 2 <;> ring
    · exact mul_nonneg (Real.exp_pos _).le (mul_nonneg (Real.exp_pos _).le poissonPMFReal_nonneg)
  have h := (poissonUpperMass_summable lam T).tsum_le_tsum hbound hg.summable
  rw [hg.tsum_eq, ← Real.exp_add] at h
  exact h

theorem poissonUpperMass_zero {T : ℝ} (hT : 0 ≤ T) : poissonUpperMass 0 T = 0 := by
  have hterm (y : ℕ) : (if T < (y : ℝ) then poissonPMFReal 0 y else 0) = 0 := by
    split_ifs with hy
    · have hy0 : y ≠ 0 := by intro hz; subst y; norm_num at hy; linarith
      simp [poissonPMFReal, hy0]
    · rfl
  unfold poissonUpperMass
  simp_rw [hterm]
  simp

private theorem exp_one_le_four : Real.exp (1 : ℝ) ≤ 4 := by
  have h := Real.exp_bound_div_one_sub_of_interval (by norm_num : (0 : ℝ) ≤ 1 / 2)
    (by norm_num : (1 / 2 : ℝ) < 1)
  norm_num at h
  have heq : Real.exp (1 : ℝ) = Real.exp (1 / 2) * Real.exp (1 / 2) := by
    rw [← Real.exp_add]
    norm_num
  rw [heq]
  nlinarith [Real.exp_pos (1 / 2)]

/-- Uniform upper-tail damping throughout the false-heavy mean range. -/
theorem false_heavy_pilot_large {cp B a : ℝ} (hcp : 0 < cp) (hB : 16 ≤ B)
    (ha : 0 < a) (lam : ℝ≥0) (hlam : (lam : ℝ) ≤ B * a / 2) :
    poissonUpperMass ⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ (cp * B * a) ≤
      Real.exp (-cp * a) := by
  have h := poissonUpperMass_exp_bound
    (⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ : ℝ≥0) (cp * B * a)
    (by norm_num : (0 : ℝ) ≤ 1 / 4)
  have he := Real.exp_bound_div_one_sub_of_interval (by norm_num : (0 : ℝ) ≤ 1 / 4)
    (by norm_num : (1 / 4 : ℝ) < 1)
  norm_num at he
  apply h.trans
  apply Real.exp_le_exp.mpr
  simp only [NNReal.coe_mk]
  have hm := mul_le_mul_of_nonneg_left he (mul_nonneg hcp.le lam.coe_nonneg)
  have hl := mul_le_mul_of_nonneg_left hlam hcp.le
  have hBa := mul_le_mul_of_nonneg_right hB (mul_nonneg hcp.le ha.le)
  nlinarith

/-- The small-mean tail includes arbitrarily many powers of lambda/a. -/
theorem false_heavy_pilot_small {cp B a : ℝ} (hcp : 0 < cp) (hB : 16 ≤ B)
    (ha : 0 < a) (lam : ℝ≥0) (hlam0 : 0 < (lam : ℝ)) (hlam : (lam : ℝ) ≤ a) :
    poissonUpperMass ⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ (cp * B * a) ≤
      Real.exp (-12 * cp * a) * ((lam : ℝ) / a) ^ (cp * B * a) := by
  let r := (lam : ℝ) / a
  have hr0 : 0 < r := div_pos hlam0 ha
  have hr1 : r ≤ 1 := (div_le_one ha).2 hlam
  have hlog : Real.log r ≤ 0 := Real.log_nonpos hr0.le hr1
  let t := 1 - Real.log r
  have ht : 0 ≤ t := by dsimp [t]; linarith
  have h := poissonUpperMass_exp_bound
    (⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ : ℝ≥0) (cp * B * a) ht
  have hexp : Real.exp t = Real.exp 1 / r := by
    dsimp [t]
    rw [Real.exp_sub, Real.exp_log hr0]
  have hratio : (lam : ℝ) / r = a := by dsimp [r]; field_simp
  have hterm : cp * (lam : ℝ) * (Real.exp t - 1) ≤ 4 * cp * a := by
    rw [hexp]
    have hm := mul_le_mul_of_nonneg_left exp_one_le_four (div_nonneg (mul_nonneg hcp.le hlam0.le) hr0.le)
    have hid : cp * (lam : ℝ) / r = cp * a := by rw [mul_div_assoc, hratio]
    have hlamnon : 0 ≤ cp * (lam : ℝ) := by positivity
    rw [hid] at hm
    have hexpand : cp * (lam : ℝ) * (Real.exp 1 / r - 1) =
        cp * a * Real.exp 1 - cp * (lam : ℝ) := by
      calc
        _ = (cp * (lam : ℝ) / r) * Real.exp 1 - cp * (lam : ℝ) := by ring
        _ = _ := by rw [hid]
    rw [hexpand]
    linarith
  have hb := mul_le_mul_of_nonneg_right hB (mul_nonneg hcp.le ha.le)
  have heq : Real.exp (-12 * cp * a) * r ^ (cp * B * a) =
      Real.exp (-12 * cp * a + cp * B * a * Real.log r) := by
    rw [Real.rpow_def_of_pos hr0, ← Real.exp_add]
    congr 1
    ring
  rw [heq]
  apply h.trans
  apply Real.exp_le_exp.mpr
  simp only [NNReal.coe_mk]
  dsimp [t]
  nlinarith

private theorem scaled_power_exponential_bound {x B a q : ℝ}
    (hx : 0 ≤ x) (hB : 16 ≤ B) (ha : 0 < a) (hq : 0 ≤ q)
    (hscale : x ≤ (B + 2) * a) :
    x ^ q ≤ Real.exp ((B + 1) * q) * a ^ q := by
  have hBpos : 0 < B + 2 := by linarith
  have hp := Real.rpow_le_rpow hx hscale hq
  rw [Real.mul_rpow hBpos.le ha.le] at hp
  have hlog := Real.log_le_sub_one_of_pos hBpos
  have he := Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_right hlog hq)
  rw [← Real.rpow_def_of_pos hBpos, show B + 2 - 1 = B + 1 by ring] at he
  exact hp.trans (mul_le_mul_of_nonneg_right he (Real.rpow_nonneg ha.le q))

private theorem analytic_moment_exponential_budget {B a : ℝ} (hB : 16 ≤ B) (ha : 1 ≤ a) :
    2 + 2 * Real.exp ((2 * B + 6) * a) ≤ Real.exp ((2 * B + 10) * a) := by
  have he : 2 ≤ Real.exp a := by linarith [Real.add_one_le_exp a]
  have he2 : 4 ≤ Real.exp (2 * a) := by
    rw [show 2 * a = a + a by ring, Real.exp_add]
    nlinarith
  have hf : 1 ≤ Real.exp ((2 * B + 6) * a) := Real.one_le_exp (by nlinarith)
  have hprod := mul_le_mul_of_nonneg_left he2 (Real.exp_pos ((2 * B + 6) * a)).le
  have hex : Real.exp ((2 * B + 6) * a) * Real.exp (2 * a) =
      Real.exp ((2 * B + 8) * a) := by rw [← Real.exp_add]; congr 1; ring
  rw [hex] at hprod
  have hfirst : 2 + 2 * Real.exp ((2 * B + 6) * a) ≤ Real.exp ((2 * B + 8) * a) := by nlinarith
  exact hfirst.trans (Real.exp_le_exp.mpr (by nlinarith))

/-- Uniform first and second moment bounds for the actual signed analytic
count throughout the complete small-mean range. -/
theorem false_heavy_analytic_moments {B a : ℝ} (hB : 16 ≤ B) (ha : 1 ≤ a)
    (lam : ℝ≥0) (hlam : (lam : ℝ) ≤ B * a / 2) :
    (∫ j, |analyticCount a j| ∂poissonMeasure lam) ≤
      Real.exp ((2 * B + 10) * a) * a ^ a ∧
    (∫ j, analyticCount a j ^ 2 ∂poissonMeasure lam) ≤
      Real.exp ((2 * B + 10) * a) * (a ^ a) ^ (2 : ℕ) := by
  have ha0 : 0 < a := by linarith
  have hscale₁ : (lam : ℝ) + a ≤ (B + 2) * a := by nlinarith
  have hscale₂ : (lam : ℝ) + 2 * a ≤ (B + 2) * a := by nlinarith
  have hp₁ := scaled_power_exponential_bound (by positivity : 0 ≤ (lam : ℝ) + a)
    hB ha0 ha0.le hscale₁
  have hp₂ := scaled_power_exponential_bound (by positivity : 0 ≤ (lam : ℝ) + 2 * a)
    hB ha0 (by positivity : 0 ≤ 2 * a) hscale₂
  have hApow : a ^ (2 * a) = (a ^ a) ^ (2 : ℕ) := by
    rw [show 2 * a = a * (2 : ℕ) by push_cast; ring, Real.rpow_mul_natCast ha0.le]
  rw [hApow] at hp₂
  have hF₁ : Real.exp (2 * a) * Real.exp ((B + 1) * a) ≤ Real.exp ((2 * B + 6) * a) := by
    rw [← Real.exp_add]
    apply Real.exp_le_exp.mpr
    nlinarith
  have hF₂ : Real.exp (4 * a) * Real.exp ((B + 1) * (2 * a)) =
      Real.exp ((2 * B + 6) * a) := by rw [← Real.exp_add]; congr 1; ring
  have hbudget := analytic_moment_exponential_budget hB ha
  have hA : 0 ≤ a ^ a := Real.rpow_nonneg ha0.le _
  constructor
  · have hraw := analyticCount_abs_integral_le lam ha
    have hm := mul_le_mul_of_nonneg_left hp₁ (Real.exp_pos (2 * a)).le
    have hf := mul_le_mul_of_nonneg_right hF₁ hA
    have hb := mul_le_mul_of_nonneg_right hbudget hA
    nlinarith [Real.exp_pos ((2 * B + 6) * a)]
  · have hraw := analyticCount_sq_integral_le lam ha
    have hm := mul_le_mul_of_nonneg_left hp₂ (Real.exp_pos (4 * a)).le
    have hid : Real.exp (4 * a) * (Real.exp ((B + 1) * (2 * a)) * (a ^ a) ^ (2 : ℕ)) =
        Real.exp ((2 * B + 6) * a) * (a ^ a) ^ (2 : ℕ) := by rw [← mul_assoc, hF₂]
    rw [hid] at hm
    have hb := mul_le_mul_of_nonneg_right hbudget (sq_nonneg (a ^ a))
    nlinarith

/-- Scalar calibration for either nonnegative main-count moment. The moment
hypothesis is quantitative and is proved for both Gamma moments above. -/
theorem false_heavy_scaled_moment {B a cp cstar E M : ℝ}
    (hB : 16 ≤ B) (ha : 1 ≤ a) (hcstar : 0 ≤ cstar)
    (hcp : 2 * B + cstar + 11 ≤ cp) (hE0 : 0 ≤ E) (hM : 0 ≤ M)
    (lam : ℝ≥0) (hlam0 : 0 < (lam : ℝ)) (hlam : (lam : ℝ) ≤ B * a / 2)
    (hmoment : E ≤ Real.exp ((2 * B + 10) * a) * a ^ a * M) :
    poissonUpperMass ⟨cp * lam, mul_nonneg (by linarith : 0 ≤ cp) lam.coe_nonneg⟩ (cp * B * a) * E ≤
      Real.exp (-cstar * a) * (lam : ℝ) ^ a * min (lam : ℝ) 1 * M := by
  have ha0 : 0 < a := by linarith
  have hcp0 : 0 < cp := by linarith
  let F := poissonUpperMass (⟨cp * lam, by positivity⟩ : ℝ≥0) (cp * B * a)
  have hF0 : 0 ≤ F := poissonUpperMass_nonneg _ _
  have hA : 0 ≤ a ^ a := Real.rpow_nonneg ha0.le _
  by_cases hlarge : a ≤ (lam : ℝ)
  · have htail := false_heavy_pilot_large hcp0 hB ha0 lam hlam
    have hpow := Real.rpow_le_rpow ha0.le hlarge ha0.le
    have hmin : min (lam : ℝ) 1 = 1 := min_eq_right (ha.trans hlarge)
    rw [hmin, mul_one]
    have hprod := mul_le_mul htail hmoment hE0 (Real.exp_pos _).le
    have hexp : Real.exp (-cp * a) * Real.exp ((2 * B + 10) * a) ≤ Real.exp (-cstar * a) := by
      rw [← Real.exp_add]
      apply Real.exp_le_exp.mpr
      nlinarith
    calc
      _ ≤ Real.exp (-cp * a) * (Real.exp ((2 * B + 10) * a) * a ^ a * M) := hprod
      _ = (Real.exp (-cp * a) * Real.exp ((2 * B + 10) * a)) * a ^ a * M := by ring
      _ ≤ Real.exp (-cstar * a) * a ^ a * M :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hexp hA) hM
      _ ≤ _ := mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left hpow (Real.exp_pos _).le) hM
  · have hsmall : (lam : ℝ) ≤ a := (lt_of_not_ge hlarge).le
    let r := (lam : ℝ) / a
    have hr0 : 0 < r := div_pos hlam0 ha0
    have hr1 : r ≤ 1 := (div_le_one ha0).2 hsmall
    have hq : 1 ≤ (cp * B - 1) * a := by
      have hcp1 : 1 ≤ cp := by linarith
      have hmul := mul_le_mul_of_nonneg_right hcp1 (by linarith : 0 ≤ B)
      nlinarith
    have hpowerSmall : r ^ ((cp * B - 1) * a) ≤ min (lam : ℝ) 1 := by
      apply le_min
      · exact (Real.rpow_le_self_of_le_one hr0.le hr1 hq).trans (div_le_self hlam0.le ha)
      · exact Real.rpow_le_one hr0.le hr1 (by linarith)
    have htail := false_heavy_pilot_small hcp0 hB ha0 lam hlam0 hsmall
    have hprod := mul_le_mul htail hmoment hE0 (by positivity : 0 ≤ Real.exp (-12 * cp * a) * r ^ (cp * B * a))
    have hsplit : a ^ a * r ^ (cp * B * a) =
        (lam : ℝ) ^ a * r ^ ((cp * B - 1) * a) := by
      have hcancel : a * r = (lam : ℝ) := by dsimp [r]; field_simp
      rw [show cp * B * a = a + (cp * B - 1) * a by ring, Real.rpow_add hr0]
      rw [← mul_assoc, ← Real.mul_rpow ha0.le hr0.le, hcancel]
    have hexp : Real.exp (-12 * cp * a) * Real.exp ((2 * B + 10) * a) ≤ Real.exp (-cstar * a) := by
      rw [← Real.exp_add]
      apply Real.exp_le_exp.mpr
      nlinarith
    calc
      _ ≤ (Real.exp (-12 * cp * a) * r ^ (cp * B * a)) *
          (Real.exp ((2 * B + 10) * a) * a ^ a * M) := hprod
      _ = (Real.exp (-12 * cp * a) * Real.exp ((2 * B + 10) * a)) *
          (a ^ a * r ^ (cp * B * a)) * M := by ring
      _ = (Real.exp (-12 * cp * a) * Real.exp ((2 * B + 10) * a)) *
          ((lam : ℝ) ^ a * r ^ ((cp * B - 1) * a)) * M := by rw [hsplit]
      _ ≤ Real.exp (-cstar * a) * ((lam : ℝ) ^ a * r ^ ((cp * B - 1) * a)) * M :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hexp (by positivity)) hM
      _ ≤ _ := by
        have h := mul_le_mul_of_nonneg_left hpowerSmall
          (mul_nonneg (Real.exp_pos (-cstar * a)).le (Real.rpow_nonneg hlam0.le a))
        convert mul_le_mul_of_nonneg_right h hM using 1
        ring

/-- The selected main-count expectation under the actual product law of the
independent Poisson pilot and main count. Absolute convergence is included. -/
theorem poissonUpperSelected_hasSum (lam mu : ℝ≥0) (T : ℝ) (f : ℕ → ℝ)
    (hf0 : ∀ j, 0 ≤ f j) (hf : Integrable f (poissonMeasure lam)) :
    HasSum (fun z : ℕ × ℕ =>
      (if T < (z.1 : ℝ) then f z.2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1))
      (poissonUpperMass mu T * ∫ j, f j ∂poissonMeasure lam) := by
  let g : ℕ → ℝ := fun y => if T < (y : ℝ) then poissonPMFReal mu y else 0
  let h : ℕ → ℝ := fun j => f j * poissonPMFReal lam j
  have hg := poissonUpperMass_summable mu T
  have hh := poisson_integrable_summable lam f hf
  have hg0 : 0 ≤ g := by intro j; dsimp [g]; split_ifs <;> simp [poissonPMFReal_nonneg]
  have hh0 : 0 ≤ h := fun j => mul_nonneg (hf0 j) poissonPMFReal_nonneg
  have hprod := hg.mul_of_nonneg hh hg0 hh0
  have hs := hg.hasSum.mul hh.hasSum hprod
  have heq (z : ℕ × ℕ) : g z.1 * h z.2 =
      (if T < (z.1 : ℝ) then f z.2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1) := by
    dsimp [g, h]
    split_ifs <;> ring
  rw [poisson_integral_eq_tsum lam f hf]
  convert hs using 1
  funext z
  exact (heq z).symm

/-- Both false-heavy moment bounds for the actual independent Poisson counts,
with constants uniform over the real order and intensity. -/
theorem false_heavy_joint_moments {B a cp cstar : ℝ}
    (hB : 16 ≤ B) (ha : 3 / 2 ≤ a) (hcstar : 0 ≤ cstar)
    (hcp : 2 * B + cstar + 11 ≤ cp) (lam : ℝ≥0)
    (hlam : (lam : ℝ) ≤ B * a / 2) :
    let mu : ℝ≥0 := ⟨cp * lam, mul_nonneg (by linarith : 0 ≤ cp) lam.coe_nonneg⟩
    (∑' z : ℕ × ℕ,
      (if cp * B * a < (z.1 : ℝ) then |analyticCount a z.2| else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1)) ≤
      Real.exp (-cstar * a) * (lam : ℝ) ^ a * min (lam : ℝ) 1 ∧
    (∑' z : ℕ × ℕ,
      (if cp * B * a < (z.1 : ℝ) then analyticCount a z.2 ^ 2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1)) ≤
      Real.exp (-cstar * a) * a ^ a * (lam : ℝ) ^ a * min (lam : ℝ) 1 := by
  dsimp only
  have ha1 : 1 ≤ a := by linarith
  have ha0 : 0 < a := by linarith
  have hcp0 : 0 < cp := by linarith
  let mu : ℝ≥0 := ⟨cp * lam, by positivity⟩
  have hf := ((analyticCount_memLp lam a).integrable one_le_two).abs
  have hg := (analyticCount_memLp lam a).integrable_sq
  rw [(poissonUpperSelected_hasSum lam mu (cp * B * a) (fun j => |analyticCount a j|)
    (fun j => abs_nonneg _) hf).tsum_eq,
    (poissonUpperSelected_hasSum lam mu (cp * B * a) (fun j => analyticCount a j ^ 2)
      (fun j => sq_nonneg _) hg).tsum_eq]
  have hE0 : 0 ≤ ∫ j, |analyticCount a j| ∂poissonMeasure lam := integral_nonneg (fun j => abs_nonneg _)
  have hF0 : 0 ≤ ∫ j, analyticCount a j ^ 2 ∂poissonMeasure lam := integral_nonneg (fun j => sq_nonneg _)
  rcases eq_or_lt_of_le lam.coe_nonneg with hz | hl0
  · have hlamzero : lam = 0 := by ext; exact hz.symm
    have hmu : mu = 0 := by ext; simp [mu, hlamzero]
    have hT : 0 ≤ cp * B * a := by positivity
    rw [hmu, poissonUpperMass_zero hT]
    simp only [zero_mul]
    exact ⟨by positivity, by positivity⟩
  · obtain ⟨hfirst, hsecond⟩ := false_heavy_analytic_moments hB ha1 lam hlam
    constructor
    · have h := false_heavy_scaled_moment hB ha1 hcstar hcp hE0 (by norm_num : (0 : ℝ) ≤ 1)
        lam hl0 hlam (by simpa only [mul_one] using hfirst)
      simpa only [mul_one] using h
    · have hA : 0 ≤ a ^ a := Real.rpow_nonneg ha0.le _
      have h := false_heavy_scaled_moment hB ha1 hcstar hcp hF0 hA lam hl0 hlam
        (by nlinarith [hsecond])
      convert h using 1
      ring

/-- The existential constant choice of the manuscript false-heavy lemma. -/
theorem false_heavy_joint_moments_uniform {cstar : ℝ} (hcstar : 0 < cstar) :
    ∃ B cp : ℝ, ∃ (_hB : 0 < B) (hcp0 : 0 < cp), ∀ a : ℝ, 3 / 2 ≤ a → ∀ lam : ℝ≥0,
      (lam : ℝ) ≤ B * a / 2 →
      let mu : ℝ≥0 := ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩
      (∑' z : ℕ × ℕ,
        (if cp * B * a < (z.1 : ℝ) then |analyticCount a z.2| else 0) *
          (poissonPMFReal lam z.2 * poissonPMFReal mu z.1)) ≤
        Real.exp (-cstar * a) * (lam : ℝ) ^ a * min (lam : ℝ) 1 ∧
      (∑' z : ℕ × ℕ,
        (if cp * B * a < (z.1 : ℝ) then analyticCount a z.2 ^ 2 else 0) *
          (poissonPMFReal lam z.2 * poissonPMFReal mu z.1)) ≤
        Real.exp (-cstar * a) * a ^ a * (lam : ℝ) ^ a * min (lam : ℝ) 1 := by
  refine ⟨16, 43 + cstar, by norm_num, by linarith, ?_⟩
  intro a ha lam hlam
  exact false_heavy_joint_moments (by norm_num) ha hcstar.le (by linarith) lam hlam

end Renyi
