import Renyi.EndpointIntegral

/-! Uniform joint deficit bound for the actual normalized endpoint integral and kernel. -/
noncomputable section
namespace Renyi

def endpointDefectConstant : ℝ := 12*(Real.log 12+3)+Real.exp (Real.log 12+1)

lemma endpointDefectConstant_pos : 0 < endpointDefectConstant := by
  have hl := Real.log_nonneg (by norm_num : (1:ℝ)≤12)
  have he := Real.exp_pos (Real.log 12+1)
  unfold endpointDefectConstant
  positivity

lemma endpoint_log_weight_bound {y : ℝ} (hy : 0 < y) (hy1 : y ≤ 1) :
    y*(Real.log 12+2-Real.log y) ≤ Real.log 12+3 := by
  have hl := Real.one_sub_inv_le_log_of_pos hy
  have hm := mul_le_mul_of_nonneg_left hl hy.le
  have hi : y*y⁻¹=1 := mul_inv_cancel₀ hy.ne'
  have hC : 0 ≤ Real.log 12+2 := by
    have hlog := Real.log_nonneg (by norm_num : (1:ℝ)≤12)
    linarith
  have hlin := mul_le_of_le_one_left hC hy1
  nlinarith

/-- Both deficits can be large separately, but their product is uniformly O(s). -/
theorem endpointProfile_kernel_defect_product {N d : ℕ} (hN : 0 < N)
    (hd0 : 2 ≤ d) (hd1 : d ≤ 6) {s x : ℝ} (hs : 0 < s) (hs1 : s ≤ 1)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    (1-endpointProfile N d s x)*(1-endpointKernel N d x) ≤ endpointDefectConstant*s := by
  have hD := endpointDefectConstant_pos
  rcases hx.eq_or_lt with rfl | hx
  · rw [endpointKernel_zero hN d]
    simp only [sub_self, mul_zero]
    positivity
  have hy : 0 < (N:ℝ)^2*x := by positivity
  have hJ := endpointProfile_range hN hd1 hs hx.le hx1
  have hK := endpointKernel_le_one hN d hx.le hx1
  have hK0 := endpointKernel_nonneg N d x
  by_cases hy1 : (N:ℝ)^2*x ≤ 1
  · have hlower := endpointProfile_lower_power hN hd0 hd1 hs hs1 hx hx1 hy1
    have hpow : Real.exp (-(Real.log 12+2)*s)*((N:ℝ)^2*x)^s =
        Real.exp (-s*(Real.log 12+2-Real.log ((N:ℝ)^2*x))) := by
      rw [Real.rpow_def_of_pos hy, ←Real.exp_add]
      congr 1
      ring
    rw [hpow] at hlower
    have he := Real.add_one_le_exp (-s*(Real.log 12+2-Real.log ((N:ℝ)^2*x)))
    have hdef : 1-endpointProfile N d s x ≤
        s*(Real.log 12+2-Real.log ((N:ℝ)^2*x)) := by linarith only [he,hlower]
    have hl := Real.log_nonpos hy.le hy1
    have hC : 0 ≤ Real.log 12+2-Real.log ((N:ℝ)^2*x) := by
      have hlog := Real.log_nonneg (by norm_num : (1:ℝ)≤12)
      linarith
    have hkdef : 1-endpointKernel N d x ≤ 12*((N:ℝ)^2*x) := by
      have hk := endpointKernel_linear_deficit hN hd1 hx.le hx1
      nlinarith only [hk]
    have hm := mul_le_mul hdef hkdef (sub_nonneg.mpr hK) (mul_nonneg hs.le hC)
    have hlog := endpoint_log_weight_bound hy hy1
    have hm2 := mul_le_mul_of_nonneg_left hlog (show 0 ≤ 12*s by positivity)
    have hfinal : 12*(Real.log 12+3)*s ≤ endpointDefectConstant*s := by
      unfold endpointDefectConstant
      nlinarith [Real.exp_pos (Real.log 12+1)]
    apply le_trans hm
    apply le_trans _ hfinal
    nlinarith only [hm2]
  · have hy1 : 1 ≤ (N:ℝ)^2*x := (lt_of_not_ge hy1).le
    have ht := endpointProfile_tail hN hd0 hd1 hs hs1 hx hx1
    have hdR : (2:ℝ) ≤ d := by exact_mod_cast hd0
    have hp : ((N:ℝ)^2*x)^(s-(d:ℝ)) ≤ 1 :=
      Real.rpow_le_one_of_one_le_of_nonpos hy1 (by linarith)
    have ht' : 1-endpointProfile N d s x ≤ Real.exp (Real.log 12+1)*s :=
      ht.trans (mul_le_of_le_one_right (by positivity) hp)
    have hm : (1-endpointProfile N d s x)*(1-endpointKernel N d x) ≤
        1-endpointProfile N d s x :=
      mul_le_of_le_one_right (sub_nonneg.mpr hJ.2) (by linarith only [hK0])
    apply hm.trans (ht'.trans _)
    unfold endpointDefectConstant
    have hlog := Real.log_nonneg (by norm_num : (1:ℝ)≤12)
    nlinarith

end Renyi
