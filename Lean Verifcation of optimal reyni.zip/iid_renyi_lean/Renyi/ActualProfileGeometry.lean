import Renyi.ActualCountGeometry
import Renyi.CompletedGlobalLower
import Renyi.CompletedStrictUpper

/-! Canonical source resolutions satisfy the actual deterministic capacity and energy conditions. -/
noncomputable section
namespace Renyi

theorem upperLowResolution_lower (alpha : ℝ) :
    (upperOrderFloor alpha:ℝ)/4≤upperLowResolution alpha := by
  have hh : upperOrderFloor alpha≤4*upperLowResolution alpha := by
    unfold upperLowResolution
    omega
  have hreal : (upperOrderFloor alpha:ℝ)≤4*(upperLowResolution alpha:ℝ) := by exact_mod_cast hh
  linarith only [hreal]

theorem upperLowResolution_energy {k : ℕ} {alpha eps Ch : ℝ}
    (ha : 3/2≤alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (heps : 0<eps) (hCh : 0≤Ch) :
    eps*((upperLowResolution alpha:ℝ)-1)≤upperE0 k alpha eps Ch := by
  have ha1 : 1<alpha := by linarith only [ha]
  have hg := (upperLowResolution_geometry ha1).2.2
  have hell : 1≤upperLowResolution alpha := by have hh := (upperLowResolution_geometry ha1).1;omega
  have hreal : 4*((upperLowResolution alpha:ℝ)-1)≤(upperOrderFloor alpha:ℝ) := by
    exact_mod_cast (show 4*(upperLowResolution alpha-1)≤upperOrderFloor alpha from hg)
  have hbound : (upperLowResolution alpha:ℝ)-1≤alpha-1 := by
    have hm := upperOrderFloor_le ha1
    linarith only [hreal,hm,ha]
  exact (mul_le_mul_of_nonneg_left hbound heps.le).trans
    (upper_reserved_interval (k:=k) ha1 (by assumption) hg1 heps hCh).1

lemma coupled_capacity_lambda_le_one {lambda : ℝ}
    (hlambda : lambda≤Real.exp (-2*coupledProfileConstant)) : lambda≤1 := by
  apply hlambda.trans
  apply Real.exp_le_one_iff.mpr
  have hl := Real.log_nonneg (by norm_num : (1:ℝ)≤24)
  unfold coupledProfileConstant
  linarith only [hl]

/-- Exact canonical resolutions retain a fixed fraction of the source convolution capacity. -/
theorem upper_actual_profile_capacity {k : ℕ} {alpha eps Ch D cb lambda CL cL : ℝ}
    (hk : 0<k) (halpha : 1<alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (heps : 0<eps) (hCh : 0≤Ch) (hD : 0<D) (hcb : 0<cb) (hlambda : 0<lambda)
    (hlambdaC : lambda≤Real.exp (-2*coupledProfileConstant)) (hCL : 1≤CL) (hcL : 0<cL) :
    let a := upperA k alpha eps Ch D cb lambda CL cL
    let b := upperB k alpha eps D cb CL cL
    let N := upperDegree alpha CL cL (rootMultiplier k alpha eps)
    let ell := upperLowResolution alpha
    let gamma := fractionalPart alpha
    let z := upperOverlapZ gamma (upperE0 k alpha eps Ch)
    (lambda/16)*(gamma*(1-gamma))*z^(1/(gamma*(1-gamma)))≤(ell:ℝ)^2*(a*(N:ℝ)^2/b) ∧
      (ell:ℝ)^2*(a*(N:ℝ)^2/b)≤Real.exp (-2*coupledProfileConstant)*(gamma*(1-gamma))*z^(1/(gamma*(1-gamma))) := by
  dsimp only
  let F := upperA k alpha eps Ch D cb lambda CL cL*
    (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2/upperB k alpha eps D cb CL cL
  let H := (fractionalPart alpha*(1-fractionalPart alpha))*
    upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)^(1/(fractionalPart alpha*(1-fractionalPart alpha)))
  have hF : 0≤F := by
    have hb := upperB_pos hk halpha hg hg1 hD hcb hCL hcL (ε:=eps)
    have hh : 0<fractionalPart alpha*(1-fractionalPart alpha) := mul_pos hg (sub_pos.mpr hg1)
    dsimp [F,upperA,upperOverlapZ]
    positivity
  have hH : 0≤H := mul_nonneg (mul_nonneg hg.le (sub_nonneg.mpr hg1.le)) (Real.rpow_nonneg (Real.exp_pos _).le _)
  have hc := (upper_convolution hk halpha hg hg1 heps hCh hD hcb hlambda hCL hcL).1
  have hid : (upperOrderFloor alpha:ℝ)^2*F=lambda*H := by
    convert hc using 1 <;> dsimp [F,H] <;> ring
  have hl := upperLowResolution_lower alpha
  have hu : (upperLowResolution alpha:ℝ)≤upperOrderFloor alpha := by
    exact_mod_cast (upperLowResolution_geometry halpha).2.1
  have hm : 0≤(upperOrderFloor alpha:ℝ) := Nat.cast_nonneg _
  have hell : 0≤(upperLowResolution alpha:ℝ) := Nat.cast_nonneg _
  have hsqlo : (upperOrderFloor alpha:ℝ)^2≤16*(upperLowResolution alpha:ℝ)^2 := by
    nlinarith only [mul_nonneg (show 0≤4*(upperLowResolution alpha:ℝ)-(upperOrderFloor alpha:ℝ) by linarith only [hl])
      (show 0≤4*(upperLowResolution alpha:ℝ)+(upperOrderFloor alpha:ℝ) by positivity)]
  have hsqhi := pow_le_pow_left₀ hell hu 2
  have hlow := mul_le_mul_of_nonneg_right hsqlo hF
  have hhigh := mul_le_mul_of_nonneg_right hsqhi hF
  have hlam := mul_le_mul_of_nonneg_right hlambdaC hH
  constructor
  · have hh : lambda/16*H≤(upperLowResolution alpha:ℝ)^2*F := by nlinarith only [hlow,hid]
    simpa only [H,mul_assoc] using hh
  · have hh : (upperLowResolution alpha:ℝ)^2*F≤Real.exp (-2*coupledProfileConstant)*H := by nlinarith only [hhigh,hid,hlam]
    simpa only [H,mul_assoc] using hh

lemma profile_scale_product_identity {ell N : ℕ} {a b p : ℝ} (hp : p≠0) :
    ((ell:ℝ)^2*(a/p))*((N:ℝ)^2*(p/b))=(ell:ℝ)^2*(a*(N:ℝ)^2/b) := by
  field_simp

/-- Canonical two-sided capacity in the exact reciprocal profile coordinates. -/
theorem upper_actual_profile_capacity_at {k : ℕ} {alpha eps Ch D cb lambda CL cL p : ℝ}
    (hk : 0<k) (halpha : 1<alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (heps : 0<eps) (hCh : 0≤Ch) (hD : 0<D) (hcb : 0<cb) (hlambda : 0<lambda)
    (hlambdaC : lambda≤Real.exp (-2*coupledProfileConstant)) (hCL : 1≤CL) (hcL : 0<cL) (hp : 0<p) :
    let a := upperA k alpha eps Ch D cb lambda CL cL
    let b := upperB k alpha eps D cb CL cL
    let N := upperDegree alpha CL cL (rootMultiplier k alpha eps)
    let ell := upperLowResolution alpha
    let gamma := fractionalPart alpha
    let z := upperOverlapZ gamma (upperE0 k alpha eps Ch)
    (lambda/16)*(gamma*(1-gamma))*z^(1/(gamma*(1-gamma)))≤((ell:ℝ)^2*(a/p))*((N:ℝ)^2*(p/b)) ∧
      ((ell:ℝ)^2*(a/p))*((N:ℝ)^2*(p/b))≤Real.exp (-2*coupledProfileConstant)*(gamma*(1-gamma))*z^(1/(gamma*(1-gamma))) := by
  dsimp only
  rw [profile_scale_product_identity hp.ne']
  exact upper_actual_profile_capacity hk halpha hg hg1 heps hCh hD hcb hlambda hlambdaC hCL hcL

end Renyi
