import Renyi.ActualAssignedMean
import Renyi.HighOrderCorrectionAbsorption
import Renyi.NearTwoCorrectionAbsorption

/-! The actual cutoff correction is paid by fixed light and realized-heavy gaps. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 700000

theorem upper_actual_high_order_fixed_heavy_correction_absorbed {eps Ch cb lambda CL cL C0 c w:ℝ}
    (heps:0<eps) (hCh:0≤Ch) (hcb:0<cb) (hlambda:0<lambda)
    (hCL:1≤CL) (hcL:0<cL) (hC0:100≤C0) (hc:0<c) (hw:0<w) :
    ∃d0 D0:ℝ,0<d0 ∧ d0≤1 ∧ 1≤D0 ∧
      ∀(k:ℕ) (alpha D d ell:ℝ),0<k → 2≤alpha →
        0<fractionalPart alpha → fractionalPart alpha<1 →
        D0≤D → 0≤d → d≤d0 → 1≤ell → ∀(p:Simplex k) (light:Fin k→Bool),
      let a:=upperA k alpha eps Ch D cb lambda CL cL
      let b:=upperB k alpha eps D cb CL cL
      let N:=upperDegree alpha CL cL (rootMultiplier k alpha eps)
      4*(upperActualBaseline k alpha C0 d a*(k:ℝ)^(1-alpha))+
        (k:ℝ)*(100:ℝ)^(upperOrderFloor alpha+1)*a^alpha≤
      (1/2:ℝ)*(c*(∑i,if light i then if a≤p.mass i then p.mass i^alpha*
        min (fractionalPart alpha*(1-fractionalPart alpha)+((N:ℝ)^2/b)*p.mass i+
          min (ell^2*(a/p.mass i)) 1) 1 else 0 else 0)+
        w*(∑i,if light i then 0 else p.mass i^alpha)) := by
  let K:=min c w
  have hK:0<K:=lt_min hc hw
  have hCpos:0<C0:=by linarith only [hC0]
  let d0:=min 1 (K/(128*C0^2))
  let ca:=min (1/(4*C0)) (K/(32*(100:ℝ)^3))
  have hca:0<ca:=lt_min (by positivity) (by positivity)
  obtain ⟨D0,hD0,hcut⟩:=upper_cutoff_eventually_small heps hCh hcb hlambda hCL hcL hca
  obtain ⟨rm,rp,hrm,_hrp,hcutBoth⟩:=upper_actual_cutoff heps hCh hcb hlambda hCL hcL
  refine ⟨d0,D0,by dsimp [d0];positivity,min_le_left _ _,hD0,?_⟩
  intro k alpha D d ell hk ha hg hg1 hD0D hd hd0 hell p light
  dsimp only
  have ha1:1<alpha:=by linarith only [ha]
  have hD:0<D:=zero_lt_one.trans_le (hD0.trans hD0D)
  have hkR:(0:ℝ)<k:=by exact_mod_cast hk
  let a:=upperA k alpha eps Ch D cb lambda CL cL
  let b:=upperB k alpha eps D cb CL cL
  let N:=upperDegree alpha CL cL (rootMultiplier k alpha eps)
  let S:=∑i,if a≤p.mass i then p.mass i^alpha*min (a/p.mass i) 1 else 0
  have hden:0<(alpha-1)/(alpha*k):=div_pos (sub_pos.mpr ha1) (mul_pos (by linarith only [ha]) hkR)
  have haPos:0<a:=by
    have hh:rm/D*Real.exp (-upperW k alpha eps)≤a/((alpha-1)/(alpha*k)):=
      (hcutBoth k alpha D hk ha1 hg hg1 hD).1
    exact (mul_pos (mul_pos (div_pos hrm hD) (Real.exp_pos _)) hden).trans_le
      ((le_div_iff₀ hden).mp hh)
  have hb:0<b:=upperB_pos hk ha1 hg hg1 hD hcb hCL hcL
  have hka:(k:ℝ)*a≤ca:=by
    have hh:=mul_le_mul_of_nonneg_left (hcut k alpha D hk ha1 hg hg1 hD0D) hkR.le
    have hid:(k:ℝ)*(ca*((alpha-1)/(alpha*k)))=ca*((alpha-1)/alpha):=by field_simp
    rw [hid] at hh
    have hratio:(alpha-1)/alpha≤1:=(div_le_one (by linarith only [ha] : 0<alpha)).mpr (by linarith)
    exact hh.trans (mul_le_of_le_one_right hca.le hratio)
  have hsmall:(k:ℝ)*a≤1/(4*C0):=hka.trans (min_le_left _ _)
  have hsmall100:(k:ℝ)*a≤1/(4*100):=by
    have hh:((k:ℝ)*a)*(4*C0)≤1:=(le_div_iff₀ (by positivity : 0<4*C0)).mp hsmall
    have hh':400*((k:ℝ)*a)≤4*C0*((k:ℝ)*a):=by
      have hm:=mul_le_mul_of_nonneg_right hC0 (mul_pos hkR haPos).le
      nlinarith only [hm]
    norm_num only at ⊢
    nlinarith only [hh,hh']
  have hm:2≤upperOrderFloor alpha:=by
    exact (Nat.le_floor_iff (by linarith only [ha] : 0≤alpha)).mpr (by norm_num; exact ha)
  have hma:(upperOrderFloor alpha:ℝ)≤alpha:=upperOrderFloor_le ha1
  have ham:alpha≤(upperOrderFloor alpha:ℝ)+1:=(Nat.lt_floor_add_one alpha).le
  have hbase:=high_order_baseline_le_endpoint_reserve hk p hm hma ham haPos
    (by linarith only [hC0] : 1≤C0) hd hsmall
  have hbelow:=high_order_below_le_endpoint_reserve hk p hm hma ham haPos hsmall100
  have hS:0≤S:=Finset.sum_nonneg (fun i _=>by
    split_ifs
    · exact mul_nonneg (Real.rpow_nonneg (p.nonneg i) alpha)
        (le_min (div_nonneg haPos.le (p.nonneg i)) zero_le_one)
    · exact le_refl 0)
  have hdK:32*d*C0^2≤K/4:=by
    have hh:=hd0.trans (min_le_right 1 (K/(128*C0^2)))
    have hh':d*(128*C0^2)≤K:=(le_div_iff₀ (by positivity : 0<128*C0^2)).mp hh
    nlinarith only [hh']
  have hrK:8*(100:ℝ)^3*((k:ℝ)*a)≤K/4:=by
    have hh:=hka.trans (min_le_right (1/(4*C0)) (K/(32*(100:ℝ)^3)))
    have hh':((k:ℝ)*a)*(32*(100:ℝ)^3)≤K:=(le_div_iff₀ (by norm_num : 0<32*(100:ℝ)^3)).mp hh
    nlinarith only [hh']
  have htheta:0≤(N:ℝ)^2/b:=div_nonneg (sq_nonneg _) hb.le
  have hgamma:0≤fractionalPart alpha*(1-fractionalPart alpha):=mul_nonneg hg.le (by linarith only [hg1])
  have hmix:=hybrid_endpoint_margin_dominates_endpoint (alpha:=alpha) p light haPos.le htheta hgamma hell hc.le hw.le
  have hreserve:K*S≤c*(∑i,if light i then if a≤p.mass i then p.mass i^alpha*
      min (fractionalPart alpha*(1-fractionalPart alpha)+((N:ℝ)^2/b)*p.mass i+
        min (ell^2*(a/p.mass i)) 1) 1 else 0 else 0)+
      w*(∑i,if light i then 0 else p.mass i^alpha):=hmix
  have hbaseId:upperActualBaseline k alpha C0 d a*(k:ℝ)^(1-alpha)=
      d*C0^upperOrderFloor alpha*((k:ℝ)*a)^(alpha-1)*(k:ℝ)^(1-alpha):=by
    unfold upperActualBaseline
    rw [min_eq_right (by linarith only [ha] : 1≤alpha-1)]
    ring
  rw [hbaseId]
  have hdS:=mul_le_mul_of_nonneg_right hdK hS
  have hrS:=mul_le_mul_of_nonneg_right hrK hS
  change _≤(8*d*C0^2)*S at hbase
  change _≤(8*(100:ℝ)^3*((k:ℝ)*a))*S at hbelow
  nlinarith only [hbase,hbelow,hdS,hrS,hreserve]


theorem upper_actual_near_two_fixed_heavy_correction_absorbed {eps Ch cb lambda CL cL C0 c w : ℝ}
    (heps : 0 < eps) (hCh : 0 ≤ Ch) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hC0 : 0 < C0) (hc : 0 < c) (hw : 0 < w) :
    ∃ d0 D0 : ℝ, 0 < d0 ∧ d0 ≤ 1 ∧ 1 ≤ D0 ∧
      ∀ (k : ℕ) (alpha D d ell : ℝ), 0 < k → 3 / 2 ≤ alpha → alpha < 2 →
        D0 ≤ D → 0 ≤ d → d ≤ d0 → 1 ≤ ell → ∀ (p : Simplex k) (light : Fin k → Bool),
      let a := upperA k alpha eps Ch D cb lambda CL cL
      let b := upperB k alpha eps D cb CL cL
      let N := upperDegree alpha CL cL (rootMultiplier k alpha eps)
      4 * (upperActualBaseline k alpha C0 d a * (k : ℝ) ^ (1 - alpha)) +
        (k : ℝ) * 100 ^ (2 : ℕ) * a ^ alpha ≤
      (1 / 2 : ℝ) * (c * (∑ i, if light i then if a ≤ p.mass i then p.mass i ^ alpha *
        min ((alpha - 1) * (1 - (alpha - 1)) + ((N : ℝ) ^ 2 / b) * p.mass i +
          min (ell ^ 2 * (a / p.mass i)) 1) 1 else 0 else 0) +
        w * (∑ i, if light i then 0 else p.mass i ^ alpha)) := by
  let K := min c w * (nearTwoEndpointConstant eps lambda / 2)
  have hK : 0 < K := mul_pos (lt_min hc hw) (div_pos (nearTwoEndpointConstant_pos (eps:=eps) hlambda) (by norm_num))
  obtain ⟨Dm, hDm, hmargin⟩ := upper_actual_hybrid_endpoint_margin_near_two
    heps hCh hcb hlambda hCL hcL
  obtain ⟨Da, hDa, hcut⟩ := upper_cutoff_eventually_small heps hCh hcb hlambda hCL hcL
    (by positivity : (0 : ℝ) < K / 40000)
  let d0 := min 1 (K / (32 * C0))
  refine ⟨d0, max Dm Da, by dsimp [d0]; positivity, min_le_left _ _,
    hDm.trans (le_max_left _ _), ?_⟩
  intro k alpha D d ell hk halpha halpha2 hD hd hd0 hell p light
  dsimp only
  have ha1 : 1 < alpha := by linarith
  have hm := upperOrderFloor_eq_one_near_two ha1 halpha2
  have hgamma : fractionalPart alpha = alpha - 1 := by
    rw [fractionalPart_eq_upperOrderFloor ha1, hm]; norm_num
  have hg : 0 < fractionalPart alpha := by rw [hgamma]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [hgamma]; linarith
  have hDmD : Dm ≤ D := (le_max_left _ _).trans hD
  have hDaD : Da ≤ D := (le_max_right _ _).trans hD
  have hDpos : 0 < D := zero_lt_one.trans_le (hDm.trans hDmD)
  have hb := upperB_pos hk ha1 hg hg1 hDpos hcb hCL hcL (ε := eps)
  have hdelta : 0 ≤ 1 - fractionalPart alpha := by linarith
  have ha : 0 ≤ upperA k alpha eps Ch D cb lambda CL cL := by unfold upperA upperOverlapZ; positivity
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hka : (k : ℝ) * upperA k alpha eps Ch D cb lambda CL cL ≤ K / 40000 := by
    have hh := mul_le_mul_of_nonneg_left (hcut k alpha D hk ha1 hg hg1 hDaD) hkR.le
    have hid : (k : ℝ) * (K / 40000 * ((alpha - 1) / (alpha * k))) =
        K / 40000 * ((alpha - 1) / alpha) := by field_simp
    rw [hid] at hh
    have hratio : (alpha - 1) / alpha ≤ 1 := (div_le_one (by linarith : 0 < alpha)).mpr (by linarith)
    exact hh.trans (mul_le_of_le_one_right (by positivity) hratio)
  have hdK : d * C0 ≤ K / 32 := by
    have hdd := hd0.trans (min_le_right 1 (K / (32 * C0)))
    have hmul := (le_div_iff₀ (by positivity : 0 < 32 * C0)).mp hdd
    linarith
  have hbeta : 0 ≤ alpha - 1 := by linarith
  have hbeta1 : alpha - 1 ≤ 1 := by linarith
  have hbase := upperActualBaseline_near_two_exact hk halpha halpha2 ha
    (C0 := C0) (d := d)
  have hbaseB : upperActualBaseline k alpha C0 d (upperA k alpha eps Ch D cb lambda CL cL) *
      (k : ℝ) ^ (1 - alpha) ≤ K / 32 *
        upperA k alpha eps Ch D cb lambda CL cL ^ (alpha - 1) := by
    rw [hbase]
    have hbC : (alpha - 1) * d * C0 ≤ K / 32 := by
      have hh := mul_le_mul_of_nonneg_right hbeta1 (mul_nonneg hd hC0.le)
      nlinarith only [hh, hdK]
    exact mul_le_mul_of_nonneg_right hbC (Real.rpow_nonneg ha _)
  have herr : (k : ℝ) * 100 ^ (2 : ℕ) * upperA k alpha eps Ch D cb lambda CL cL ^ alpha ≤
      K / 4 * upperA k alpha eps Ch D cb lambda CL cL ^ (alpha - 1) := by
    have hpowa : upperA k alpha eps Ch D cb lambda CL cL ^ alpha =
        upperA k alpha eps Ch D cb lambda CL cL * upperA k alpha eps Ch D cb lambda CL cL ^ (alpha - 1) := by
      have heq : 1 + (alpha - 1) = alpha := by ring
      have hh := Real.rpow_add_of_nonneg ha (by norm_num : (0 : ℝ) ≤ 1) hbeta
      simpa only [heq, Real.rpow_one] using hh
    rw [hpowa]
    have hmul := mul_le_mul_of_nonneg_right hka
      (show 0 ≤ (100 : ℝ) ^ (2 : ℕ) * upperA k alpha eps Ch D cb lambda CL cL ^ (alpha - 1) by positivity)
    nlinarith only [hmul]
  have hreserve := hmargin k alpha D ell c w hk halpha halpha2 hDmD hell hc.le hw.le p light
  change K*upperA k alpha eps Ch D cb lambda CL cL^(alpha-1)≤_ at hreserve
  nlinarith only [hbaseB, herr, hreserve, Real.rpow_nonneg ha (alpha - 1), hK]


/-- One final source correction bound for every order at least three halves,
with the realized heavy gap rather than a nominal omega reserve. -/
theorem upper_actual_fixed_heavy_correction_absorbed {eps Ch cb lambda CL cL C0 c cH : ℝ}
    (heps : 0<eps) (hCh : 0≤Ch) (hcb : 0<cb) (hlambda : 0<lambda)
    (hCL : 1≤CL) (hcL : 0<cL) (hC0 : 100≤C0) (hc : 0<c) (hcH : 0<cH) :
    ∃ d0 D0 : ℝ, 0<d0 ∧ d0≤1 ∧ 1≤D0 ∧ ∀ (k : ℕ) (alpha D d : ℝ),
      0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 →
      D0≤D → 0≤d → d≤d0 → ∀ (p : Simplex k) (light : Fin k→Bool),
      4*actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d+
        (k:ℝ)*100^(upperOrderFloor alpha+1)*(upperA k alpha eps Ch D cb lambda CL cL)^alpha≤
      (1/2:ℝ)*(c*actualLightSpatialMargin p light alpha eps Ch D cb lambda CL cL+
        cH*assignedHeavyPower p light alpha) := by
  obtain ⟨dH,DH,hdH,hdH1,hDH,hH⟩ := upper_actual_high_order_fixed_heavy_correction_absorbed
    heps hCh hcb hlambda hCL hcL hC0 hc hcH
  obtain ⟨dL,DL,hdL,hdL1,hDL,hL⟩ := upper_actual_near_two_fixed_heavy_correction_absorbed
    heps hCh hcb hlambda hCL hcL (by linarith only [hC0] : 0<C0) hc hcH
  refine ⟨min dH dL,max DH DL,lt_min hdH hdL,(min_le_left _ _).trans hdH1,
    hDH.trans (le_max_left _ _),?_⟩
  intro k alpha D d hk ha hg hg1 hD hd hdd p light
  have ha1 : 1<alpha := by linarith only [ha]
  have hell : (1:ℝ)≤upperLowResolution alpha := by
    exact_mod_cast (Nat.succ_le_iff.mpr (upperLowResolution_geometry ha1).1)
  by_cases ha2 : 2≤alpha
  · have hh := hH k alpha D d (upperLowResolution alpha) hk ha2 hg hg1
      ((le_max_left _ _).trans hD) hd (hdd.trans (min_le_left _ _)) hell p light
    simpa only [actualCutoffBudget,actualLightSpatialMargin,assignedHeavyPower,
      div_mul_eq_mul_div,mul_div_assoc] using hh
  · have ha2' : alpha<2 := lt_of_not_ge ha2
    have hm := upperOrderFloor_eq_one_near_two ha1 ha2'
    have hγ : fractionalPart alpha=alpha-1 := by
      rw [fractionalPart_eq_upperOrderFloor ha1,hm]
      norm_num
    have hh := hL k alpha D d (upperLowResolution alpha) hk ha ha2'
      ((le_max_right _ _).trans hD) hd (hdd.trans (min_le_right _ _)) hell p light
    simpa only [actualCutoffBudget,actualLightSpatialMargin,assignedHeavyPower,hm,hγ,
      div_mul_eq_mul_div,mul_div_assoc] using hh

end Renyi
