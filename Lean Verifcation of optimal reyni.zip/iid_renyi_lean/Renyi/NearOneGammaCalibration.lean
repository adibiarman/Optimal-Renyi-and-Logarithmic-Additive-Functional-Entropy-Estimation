import Renyi.NearOneGammaAggregate
import Renyi.NearOnePowerSums

/-! Probability-unit and relative power-sum calibration of the Gamma noise. -/
set_option maxHeartbeats 600000
noncomputable section
open scoped BigOperators NNReal
namespace Renyi

theorem near_one_gamma_scaled_envelope {k : ℕ} (p : Simplex k) (lam : Fin k → ℝ≥0)
    {n t beta Cw : ℝ} (hn : 0 < n) (ht : 0 < t) (hnt : n * t ≤ 1)
    (hlam : ∀ i, (lam i : ℝ) = n * p.mass i) :
    beta ^ 2 / n ^ (2 * (1 + beta)) *
        (∑ i, nearOneGammaVarianceEnvelope beta (n * t) Cw (lam i)) ≤
      beta ^ 2 * ((k : ℝ) * nearOneGammaLowBudget Cw (n * t) / n ^ (2 * (1 + beta)) +
        nearOneGammaAggregateConstant Cw * (1 + (Real.log (1 / t)) ^ 2) / n *
          (powerSum p (1 + 2 * beta) + t ^ (2 * beta))) := by
  have hsum : ∑ i, (lam i : ℝ) = n := by simp only [hlam, ← Finset.mul_sum, p.normalized, mul_one]
  have h := mul_le_mul_of_nonneg_left (near_one_gamma_envelope_sum (beta := beta) (Cw := Cw) hn ht hnt lam hsum)
    (by positivity : 0 ≤ beta ^ 2 / n ^ (2 * (1 + beta)))
  have hpower : (∑ i, (lam i : ℝ) ^ (1 + 2 * beta)) =
      n ^ (1 + 2 * beta) * powerSum p (1 + 2 * beta) := by
    simp only [hlam, Real.mul_rpow hn.le, p.nonneg, powerSum, Finset.mul_sum]
  have hp : n ^ (-2 * (1 + beta)) * n ^ (1 + 2 * beta) = 1 / n := by
    rw [← Real.rpow_add hn, show -2 * (1 + beta) + (1 + 2 * beta) = -1 by ring,
      Real.rpow_neg_one, one_div]
  have hs : (n ^ (2 * (1 + beta)))⁻¹ = n ^ (-2 * (1 + beta)) := by
    rw [show -2 * (1 + beta) = -(2 * (1 + beta)) by ring, Real.rpow_neg hn.le]
  have hlow := near_one_gamma_scale_identity (beta := beta) hn ht
  rw [hpower] at h
  simp only [Fintype.card_fin] at h
  have heq : beta ^ 2 / n ^ (2 * (1 + beta)) *
      ((k : ℝ) * nearOneGammaLowBudget Cw (n * t) +
        nearOneGammaAggregateConstant Cw * (1 + (Real.log (1 / t)) ^ 2) *
          (n ^ (1 + 2 * beta) * powerSum p (1 + 2 * beta) + (n * t) ^ (2 * beta) * n)) =
      beta ^ 2 * ((k : ℝ) * nearOneGammaLowBudget Cw (n * t) / n ^ (2 * (1 + beta)) +
        nearOneGammaAggregateConstant Cw * (1 + (Real.log (1 / t)) ^ 2) / n *
          (powerSum p (1 + 2 * beta) + t ^ (2 * beta))) := by
    simp only [div_eq_mul_inv, hs]
    calc
      _ = beta ^ 2 * ((k : ℝ) * nearOneGammaLowBudget Cw (n * t) * n ^ (-2 * (1 + beta)) +
        nearOneGammaAggregateConstant Cw * (1 + (Real.log (1 / t)) ^ 2) *
          ((n ^ (-2 * (1 + beta)) * n ^ (1 + 2 * beta)) * powerSum p (1 + 2 * beta) +
            n ^ (-2 * (1 + beta)) * ((n * t) ^ (2 * beta) * n))) := by ring
      _ = _ := by rw [hp, hlow]; ring
  exact h.trans_eq heq

end Renyi
