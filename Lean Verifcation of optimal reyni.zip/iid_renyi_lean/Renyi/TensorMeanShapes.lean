import Renyi.LowerJordanMeans

/-! Explicit power-mean shapes of the actual short interpolation factors. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- The uniform active-ratio floor combines with the actual target power
floor without losing a singular factor as the order approaches an integer. -/
theorem active_principal_power_floor {s z c d a kappa delta : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hc : 0<c) (hc1 : c≤1)
    (hz : c*s≤z) (hd : 1≤d) (ha : 0<a) (_hk : 0<kappa) (_hdelta : 0<delta)
    (hfloor : delta*kappa≤(a/((z/8)/d^2))^s) :
    delta*kappa*c*Real.exp (-1)/(8*d^2)≤a^s := by
  have hz0 : 0<z := (mul_pos hc hs).trans_le hz
  have hd0 : 0<d := zero_lt_one.trans_le hd
  have hb0 : 0<(z/8)/d^2 := by positivity
  have hnode := active_node_power_floor hs hs1 hc hc1 hz hd
  have hh := mul_le_mul hfloor hnode (by positivity : 0≤c*Real.exp (-1)/(8*d^2)) (Real.rpow_nonneg (div_nonneg ha.le hb0.le) _)
  have hid : (a/((z/8)/d^2))^s*((z/8)/d^2)^s=a^s := by
    rw [Real.div_rpow ha.le hb0.le]
    field_simp
  rw [hid] at hh
  convert hh using 1; ring

/-- The short active Jordan moment has a uniform target-mass floor with
only a fourth-power dimensional loss. -/
theorem active_jordan_uniform_lower (n : ℕ) (zeta a rho s beta kappa delta c : ℝ)
    (hn : 0<n) (hz0 : 0<zeta) (hz1 : zeta≤3/5)
    (ha : 0<a) (hrho : 0≤rho) (hrho1 : rho≤1)
    (hs : 0<s) (hs1 : s≤1) (hk : 0<kappa) (hdelta : 0<delta)
    (hc : 0<c) (hc1 : c≤1) (hzc : c*s≤zeta)
    (haB : a≤((zeta/8)/((n:ℝ)+1)^2)/2)
    (hpert : rho*a/((zeta/8)/((n:ℝ)+1)^2)≤zeta)
    (hbeta : s+1≤beta)
    (hprincipal : 1/2≤normalizedInterpolation (chebyshevNode n ((zeta/8)/((n:ℝ)+1)^2)) a rho s none)
    (hcancel : ∑ i, normalizedInterpolation (chebyshevNode n ((zeta/8)/((n:ℝ)+1)^2)) a rho s i *
      interpolationNodes (chebyshevNode n ((zeta/8)/((n:ℝ)+1)^2)) a i^beta=0)
    (hfloor : delta*kappa≤(a/((zeta/8)/((n:ℝ)+1)^2))^s) :
    let b := (zeta/8)/((n:ℝ)+1)^2
    let u := chebyshevNode n b
    delta*kappa*c*Real.exp (-1)*zeta/(1024*((n:ℝ)+1)^4)≤
      ∑ i, positiveCoeff (normalizedInterpolation u a rho s i)*interpolationNodes u a i^beta := by
  have hpower := active_principal_power_floor hs hs1 hc hc1 hzc
    (show (1:ℝ)≤(n:ℝ)+1 by have hn0 : (0:ℝ)≤n := Nat.cast_nonneg n; linarith) ha hk hdelta hfloor
  have hJ := (active_jordan_bounds n zeta a rho s beta hn hz0 hz1 ha hrho hrho1 haB hpert hbeta hprincipal hcancel).1
  have hh := mul_le_mul_of_nonneg_left hpower hz0.le
  have hh' := div_le_div_of_nonneg_right hh
    (show 0≤128*((n:ℝ)+1)^2 by positivity)
  apply le_trans ?_ hJ
  convert hh' using 1
  field_simp
  ring

end Renyi
