import Renyi.NearOneNormalizedBudget
import Renyi.NearOneLogDecay

/-! Exponential degree costs in the normalized near-one variance. -/
set_option maxHeartbeats 800000
noncomputable section
open scoped BigOperators NNReal
namespace Renyi

def nearOneVarianceExponent (K : ℝ) : ℝ := 2*K+400

theorem near_one_budget_exponential_envelope {k l : ℕ} (hk : 0<k) (p : Simplex k)
    {a n b t K Cw cp B C G : ℝ}
    (ha : 1<a) (ha1 : a≤3/2) (hn : 0<n) (hb : 0<b) (ht : 0<t)
    (htb : t≤b) (hnt : n*t≤1) (hK : 0<K) (hcp : 0≤cp) (hB : 0≤B)
    (hL : (1:ℝ)≤l) (hC : 1≤C)
    (hgeom : (k:ℝ)/n≤G*nearOneLogWeight k^2 ∧
      (k:ℝ)*b≤G*nearOneLogWeight k^2 ∧
      20*(l:ℝ)+1≤G*nearOneLogWeight k^2 ∧
      1+|Real.log (n*t)|≤G*nearOneLogWeight k^2 ∧
      |Real.log (1/t)|≤G*nearOneLogWeight k^2)
    (hGC : G≤C) (hKC : K^2≤C)
    (hCG : nearOneGammaAggregateConstant Cw≤C)
    (hLow : (6:ℝ)^6*Real.exp (Real.exp 1-1)*gammaResidualPilotConstant Cw^2≤C)
    (hSel : (6:ℝ)^6*Real.exp (cp*B*(3/2))*gammaResidualPilotConstant Cw^2≤C)
    (hA : K^2*Real.exp (cp*B*(3/2))≤C) :
    nearOneHybridVarianceBudget (simplexPoissonMeans n p) n t b (a-1)
      (K*Real.exp (K*l)) Cw K (cp*B*a) 20 (20*l) ≤
      100*(a-1)^2*(powerSum p a)^2*C^8*nearOneLogWeight k^16*
        Real.exp (8*nearOneVarianceExponent K*l)/(k:ℝ)^(2/3:ℝ) := by
  let W := nearOneLogWeight k
  let E := nearOneVarianceExponent K
  let H := C*W^2*Real.exp (E*l)
  have hk1 : (1:ℝ)≤k := by exact_mod_cast hk
  have hW : 1≤W := by
    dsimp [W,nearOneLogWeight]
    linarith [Real.log_nonneg (show (1:ℝ)≤3 by norm_num),Real.log_nonneg hk1]
  have hW0 : 0≤W := by linarith
  have hWsq : 1≤W^2 := by nlinarith only [hW]
  have hE : 0≤E := by dsimp [E,nearOneVarianceExponent]; linarith
  have he : 1≤Real.exp (E*l) := Real.one_le_exp_iff.mpr (mul_nonneg hE (by linarith : (0:ℝ)≤l))
  have hH0 : 1≤H := by dsimp [H]; nlinarith only [mul_le_mul hC hWsq (by norm_num : (0:ℝ)≤1) (by linarith : 0≤C),he]
  have hCH : C≤H := by
    have hh := mul_le_mul_of_nonneg_left hWsq (show 0≤C by linarith)
    have hh' := mul_le_mul_of_nonneg_left he (show 0≤C*W^2 by positivity)
    dsimp [H]; nlinarith only [hh,hh']
  have hGWH : G*W^2≤H := by
    have hh := mul_le_mul_of_nonneg_right hGC (sq_nonneg W)
    have hh' := mul_le_mul_of_nonneg_left he (show 0≤C*W^2 by positivity)
    dsimp [H]; nlinarith only [hh,hh']
  have hT : cp*B*a≤cp*B*(3/2) := mul_le_mul_of_nonneg_left ha1 (mul_nonneg hcp hB)
  have hSel' : (6:ℝ)^6*Real.exp (cp*B*a)*gammaResidualPilotConstant Cw^2≤H := by
    have hh := mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr hT) (by positivity : 0≤(6:ℝ)^6*gammaResidualPilotConstant Cw^2)
    exact (show (6:ℝ)^6*Real.exp (cp*B*a)*gammaResidualPilotConstant Cw^2≤(6:ℝ)^6*Real.exp (cp*B*(3/2))*gammaResidualPilotConstant Cw^2 by nlinarith only [hh]).trans (hSel.trans hCH)
  have hA' : (K*Real.exp (K*l))^2*Real.exp (cp*B*a+20*((20*l:ℕ):ℝ))≤H := by
    have heq : (K*Real.exp (K*l))^2*Real.exp (cp*B*a+20*((20*l:ℕ):ℝ)) =
        K^2*Real.exp (cp*B*a)*Real.exp (E*l) := by
      push_cast
      rw [mul_pow, ← Real.exp_nat_mul]
      calc
        _ = K^2*(Real.exp (2*(K*(l:ℝ)))*Real.exp (cp*B*a+20*(20*(l:ℝ)))) := by ring
        _ = K^2*Real.exp (2*(K*(l:ℝ))+(cp*B*a+20*(20*(l:ℝ)))) := by rw [← Real.exp_add]
        _ = K^2*Real.exp (cp*B*a+E*l) := by congr 1; congr 1; dsimp [E,nearOneVarianceExponent]; ring
        _ = _ := by rw [Real.exp_add]; ring
    rw [heq]
    have hh := mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr hT) (sq_nonneg K)
    have hh' := mul_le_mul_of_nonneg_right (hh.trans hA) (Real.exp_pos (E*l)).le
    have hh'' := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hWsq (show 0≤C by linarith)) (Real.exp_pos (E*l)).le
    exact hh'.trans (by simpa only [mul_one] using hh'')
  have hh := near_one_variance_budget_normalized hk p (simplexPoissonMeans n p) ha ha1 hn ht hb htb hnt hH0
    (fun i => Real.coe_toNNReal _ (mul_nonneg hn.le (p.nonneg i)))
    (hgeom.1.trans hGWH) (hgeom.2.1.trans hGWH)
    (show ((20*l:ℕ):ℝ)+1≤H by push_cast; exact hgeom.2.2.1.trans hGWH)
    (hgeom.2.2.2.1.trans hGWH) (hgeom.2.2.2.2.trans hGWH)
    (hKC.trans hCH) (hCG.trans hCH) (hLow.trans hCH) hSel' hA'
  refine hh.trans_eq ?_
  dsimp [H,W,E]
  rw [mul_pow,mul_pow,← Real.exp_nat_mul]
  ring

end Renyi
