import Renyi.FactorialEnergyProbability
import Renyi.Pilot
import Renyi.IntegerTails
import Mathlib.Analysis.MeanInequalitiesPow

/-!
# Moments and sample scale of the raw integer collision estimator

These are the first, third, and fourth steps of the manuscript's integer-order
upper bound. All moment inequalities are derived from independent Poisson laws.
The exact collision variance is reduced to the factorial derivative-energy
identity. The rare-count bound uses the independently proved factorial second
moment envelope. Finally, Jensen's inequality supplies the simplex norm bound
needed at the sample scale `D * r * k^(1 - 1/r)`.
-/

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def collisionCoefficients (r j : ℕ) : ℝ := if j = r then 1 else 0

theorem collision_polynomial (r : ℕ) :
    polynomialOfCoefficients r (collisionCoefficients r) = Polynomial.X ^ r := by
  simp [polynomialOfCoefficients, collisionCoefficients, ite_mul]

variable {ι Ω : Type*} [Fintype ι] [MeasurableSpace Ω] {μ : Measure Ω}

def powerSumNat (p : ι → ℝ) (r : ℕ) : ℝ := ∑ i, p i ^ r

def rawCollision (N : ι → Ω → ℕ) (r : ℕ) (n : ℝ) : Ω → ℝ :=
  fun ω => ∑ i, (N i ω |>.descFactorial r : ℝ) / n ^ r

omit [MeasurableSpace Ω] in
theorem rawCollision_eq_countPolynomial (N : ι → Ω → ℕ) (r : ℕ) (n : ℝ) :
    rawCollision N r n = countPolynomialEstimator N r (collisionCoefficients r) n := by
  funext ω
  unfold rawCollision countPolynomialEstimator
  apply Finset.sum_congr rfl
  intro i _
  simp [factorialStatistic, collisionCoefficients, div_eq_mul_inv, mul_comm]

omit [MeasurableSpace Ω] in
theorem rawCollision_nonneg (N : ι → Ω → ℕ) (r : ℕ) {n : ℝ} (hn : 0 ≤ n) (ω : Ω) :
    0 ≤ rawCollision N r n ω := by
  unfold rawCollision
  apply Finset.sum_nonneg
  intro i _
  positivity

variable [IsProbabilityMeasure μ]

omit [IsProbabilityMeasure μ] in
theorem rawCollision_memLp (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (r : ℕ) (n : ℝ) : MemLp (rawCollision N r n) 2 μ := by
  rw [rawCollision_eq_countPolynomial]
  exact memLp_finset_sum _ (fun i _ =>
    countPolynomial_coordinate_memLp N lam hLaw r (collisionCoefficients r) n i)

theorem rawCollision_mean (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (r : ℕ) (n : ℝ) (p : ι → ℝ) (hn : n ≠ 0)
    (hlam : ∀ i, (lam i : ℝ) = n * p i) :
    (∫ ω, rawCollision N r n ω ∂μ) = powerSumNat p r := by
  rw [rawCollision_eq_countPolynomial,
    countPolynomialEstimator_mean N lam hLaw r (collisionCoefficients r) n p hn hlam]
  simp only [collision_polynomial, Polynomial.eval_pow, Polynomial.eval_X, powerSumNat]

omit [IsProbabilityMeasure μ] in
theorem rawCollision_variance (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (r : ℕ) (n : ℝ) (p : ι → ℝ) (hn : n ≠ 0)
    (hlam : ∀ i, (lam i : ℝ) = n * p i) :
    variance (rawCollision N r n) μ =
      ∑ j ∈ Finset.range r,
        (r.descFactorial (j + 1) : ℝ) ^ 2 /
          (((j + 1).factorial : ℝ) * n ^ (j + 1)) * powerSumNat p (2 * r - (j + 1)) := by
  rw [rawCollision_eq_countPolynomial,
    countPolynomialEstimator_variance N lam hLaw hpair r (collisionCoefficients r) n p hn hlam]
  simp only [collision_polynomial, Polynomial.iterate_derivative_X_pow_eq_C_mul,
    Polynomial.eval_mul, Polynomial.eval_C, Polynomial.eval_pow, Polynomial.eval_X]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  have hjr : j + 1 ≤ r := by have := Finset.mem_range.mp hj; omega
  unfold powerSumNat
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  have hexp : 2 * r - (j + 1) = (j + 1) + 2 * (r - (j + 1)) := by omega
  rw [hexp, pow_add (p i) (j + 1), mul_comm 2 (r - (j + 1)), pow_mul, mul_pow]
  ring

omit [MeasurableSpace Ω] [IsProbabilityMeasure μ] in
theorem powerSumNat_nonneg (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) (r : ℕ) :
    0 ≤ powerSumNat p r := Finset.sum_nonneg (fun i _ => pow_nonneg (hp i) r)

omit [MeasurableSpace Ω] [IsProbabilityMeasure μ] in
theorem coordinate_le_powerSum_root (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    (r : ℕ) (hr : 0 < r) (M : ℝ) (hM : 0 ≤ M) (hP : powerSumNat p r = M ^ r) :
    ∀ i, p i ≤ M := by
  intro i
  apply (pow_le_pow_iff_left₀ (hp i) hM (ne_of_gt hr)).mp
  rw [← hP]
  exact Finset.single_le_sum (fun a _ => pow_nonneg (hp a) r) (Finset.mem_univ i)

omit [MeasurableSpace Ω] [IsProbabilityMeasure μ] in
theorem powerSumNat_high (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    (r q : ℕ) (hr : 0 < r) (hrq : r ≤ q)
    (M : ℝ) (hM : 0 ≤ M) (hP : powerSumNat p r = M ^ r) :
    powerSumNat p q ≤ M ^ q := by
  have hcoord := coordinate_le_powerSum_root p hp r hr M hM hP
  calc
    powerSumNat p q ≤ ∑ i, p i ^ r * M ^ (q - r) := by
      apply Finset.sum_le_sum
      intro i _
      rw [show q = r + (q - r) by omega, pow_add]
      simpa only [Nat.add_sub_cancel_left] using
        mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (hp i) (hcoord i) (q - r))
          (pow_nonneg (hp i) r)
    _ = powerSumNat p r * M ^ (q - r) := (Finset.sum_mul _ _ _).symm
    _ = M ^ q := by rw [hP, ← pow_add, Nat.add_sub_of_le hrq]

omit [Fintype ι] [MeasurableSpace Ω] [IsProbabilityMeasure μ] in
theorem collision_monomial_ratio (a n M : ℝ) (r j : ℕ)
    (hn : n ≠ 0) (hM : M ≠ 0) (hj : j ≤ 2 * r) :
    (a ^ j) ^ 2 / ((j.factorial : ℝ) * n ^ j) * M ^ (2 * r - j) / (M ^ r) ^ 2 =
      (a ^ 2 / (n * M)) ^ j / (j.factorial : ℝ) := by
  have hfac : (j.factorial : ℝ) ≠ 0 := by positivity
  have hpow : M ^ (2 * r - j) * M ^ j = (M ^ r) ^ 2 := by
    rw [← pow_add, Nat.sub_add_cancel hj, mul_comm 2 r, pow_mul]
  rw [div_pow, mul_pow]
  field_simp
  rw [show (a ^ j) ^ 2 = (a ^ 2) ^ j by rw [← pow_mul, ← pow_mul]; congr 1; omega]
  linear_combination (a ^ 2) ^ j * hpow

omit [MeasurableSpace Ω] [IsProbabilityMeasure μ] in
theorem collision_variance_term_bound (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    (r j : ℕ) (hr : 0 < r) (hj : j ≤ r)
    (n M : ℝ) (hn : 0 < n) (hM : 0 < M) (hP : powerSumNat p r = M ^ r) :
    ((r.descFactorial j : ℝ) ^ 2 / ((j.factorial : ℝ) * n ^ j) *
      powerSumNat p (2 * r - j)) / (M ^ r) ^ 2 ≤
      ((r : ℝ) ^ 2 / (n * M)) ^ j / (j.factorial : ℝ) := by
  have hdesc : (r.descFactorial j : ℝ) ≤ (r : ℝ) ^ j := by
    exact_mod_cast Nat.descFactorial_le_pow r j
  have hpower := powerSumNat_high p hp r (2 * r - j) hr (by omega) M hM.le hP
  calc
    _ ≤ ((r : ℝ) ^ j) ^ 2 / ((j.factorial : ℝ) * n ^ j) *
        M ^ (2 * r - j) / (M ^ r) ^ 2 := by
      apply div_le_div_of_nonneg_right _ (sq_nonneg _)
      exact mul_le_mul
        (div_le_div_of_nonneg_right (pow_le_pow_left₀ (by positivity) hdesc 2) (by positivity))
        hpower (powerSumNat_nonneg p hp _) (by positivity)
    _ = _ := collision_monomial_ratio (r : ℝ) n M r j hn.ne' hM.ne' (by omega)

omit [IsProbabilityMeasure μ] in
theorem rawCollision_relative_variance (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (r : ℕ) (hr : 0 < r) (n : ℝ) (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    (hn : 0 < n) (hlam : ∀ i, (lam i : ℝ) = n * p i)
    (M : ℝ) (hM : 0 < M) (hP : powerSumNat p r = M ^ r) :
    variance (rawCollision N r n) μ / (powerSumNat p r) ^ 2 ≤
      Real.exp ((r : ℝ) ^ 2 / (n * M)) - 1 := by
  rw [rawCollision_variance N lam hLaw hpair r n p hn.ne' hlam, hP, Finset.sum_div]
  apply (Finset.sum_le_sum (fun j hj => collision_variance_term_bound p hp r (j + 1)
    hr (by have := Finset.mem_range.mp hj; omega) n M hn hM hP)).trans
  have he := Real.sum_le_exp_of_nonneg
    (by positivity : 0 ≤ (r : ℝ) ^ 2 / (n * M)) (r + 1)
  rw [Finset.sum_range_succ'] at he
  simp only [pow_zero, Nat.factorial_zero, Nat.cast_one, div_one] at he
  linarith

omit [IsProbabilityMeasure μ] in
theorem rawCollision_integer_relative_variance (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (r : ℕ) (hr : 0 < r) (n : ℝ) (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    (hn : 0 < n) (hlam : ∀ i, (lam i : ℝ) = n * p i)
    (M : ℝ) (hM : 0 < M) (hP : powerSumNat p r = M ^ r)
    (D : ℝ) (hD : 0 < D) (hscale : D * r ≤ n * M) :
    variance (rawCollision N r n) μ / (powerSumNat p r) ^ 2 ≤
      Real.exp ((r : ℝ) / D) - 1 := by
  apply (rawCollision_relative_variance N lam hLaw hpair r hr n p hp hn hlam M hM hP).trans
  apply sub_le_sub_right (Real.exp_le_exp.mpr _) 1
  apply (div_le_iff₀ (mul_pos hn hM)).mpr
  have hrR : (0 : ℝ) < r := by exact_mod_cast hr
  calc
    (r : ℝ) ^ 2 = ((r : ℝ) / D) * (D * r) := by field_simp
    _ ≤ ((r : ℝ) / D) * (n * M) := mul_le_mul_of_nonneg_left hscale (by positivity)

omit [Fintype ι] [MeasurableSpace Ω] [IsProbabilityMeasure μ] in
theorem poisson_factorial_memLp (lam : ℝ≥0) (r : ℕ) :
    MemLp (fun q : ℕ => (q.descFactorial r : ℝ)) 2 (poissonMeasure lam) :=
  poisson_memLp_of_squared_hasSum lam _ (poissonFactorialSecond lam r)
    (poissonFactorialSecond_summable lam r).hasSum

omit [Fintype ι] [MeasurableSpace Ω] [IsProbabilityMeasure μ] in
theorem poisson_factorial_variance_le (lam : ℝ≥0) (r : ℕ) :
    variance (fun q : ℕ => (q.descFactorial r : ℝ)) (poissonMeasure lam) ≤
      (lam : ℝ) ^ r * ((lam : ℝ) + r) ^ r := by
  apply (variance_le_expectation_sq (poisson_factorial_memLp lam r).1).trans
  simp only [Pi.pow_apply]
  rw [poisson_integral_eq_tsum lam _ (poisson_factorial_memLp lam r).integrable_sq]
  exact poissonFactorialSecond_le lam r

omit [IsProbabilityMeasure μ] in
theorem rawCollision_rare_variance (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (r : ℕ) (n : ℝ) (p : ι → ℝ) (_hp : ∀ i, 0 ≤ p i)
    (hn : 0 < n) (hlam : ∀ i, (lam i : ℝ) = n * p i)
    (T : ℝ) (_hT : 0 ≤ T) (hrare : ∀ i, (lam i : ℝ) ≤ T) :
    variance (rawCollision N r n) μ ≤ powerSumNat p r * ((T + r) / n) ^ r := by
  let F : ι → Ω → ℝ := fun i ω => (n ^ r)⁻¹ * (N i ω |>.descFactorial r : ℝ)
  have hF : ∀ i, MemLp (F i) 2 μ := fun i =>
    ((poisson_factorial_memLp (lam i) r).comp_measurePreserving (hLaw i)).const_mul _
  have hpairF : Pairwise (fun i j => IndepFun (F i) (F j) μ) := by
    intro i j hij
    exact (hpair hij).comp
      (measurable_of_countable (fun q : ℕ => (n ^ r)⁻¹ * (q.descFactorial r : ℝ)))
      (measurable_of_countable (fun q : ℕ => (n ^ r)⁻¹ * (q.descFactorial r : ℝ)))
  have hadd : variance (rawCollision N r n) μ = ∑ i, variance (F i) μ := by
    convert (IndepFun.variance_sum (s := Finset.univ) (X := F)
      (fun i _ => hF i) (fun i _ j _ hij => hpairF hij)) using 1
    congr 1
    funext ω
    simp [rawCollision, F, div_eq_mul_inv, mul_comm]
  rw [hadd, powerSumNat, Finset.sum_mul]
  apply Finset.sum_le_sum
  intro i _
  unfold F
  rw [variance_mul]
  have hmap : variance (fun ω => (N i ω |>.descFactorial r : ℝ)) μ =
      variance (fun q : ℕ => (q.descFactorial r : ℝ)) (poissonMeasure (lam i)) :=
    (hLaw i).variance_fun_comp (measurable_of_countable (fun q : ℕ => (q.descFactorial r : ℝ))).aemeasurable
  rw [hmap]
  calc
    _ ≤ ((n ^ r)⁻¹) ^ 2 * ((lam i : ℝ) ^ r * ((lam i : ℝ) + r) ^ r) :=
      mul_le_mul_of_nonneg_left (poisson_factorial_variance_le (lam i) r) (sq_nonneg _)
    _ ≤ ((n ^ r)⁻¹) ^ 2 * ((lam i : ℝ) ^ r * (T + r) ^ r) := by
      gcongr
      exact hrare i
    _ = p i ^ r * ((T + r) / n) ^ r := by
      rw [hlam, mul_pow, div_pow]
      field_simp

omit [MeasurableSpace Ω] [IsProbabilityMeasure μ] in
theorem powerSumNat_pos (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    (hsum : ∑ i, p i = 1) (r : ℕ) : 0 < powerSumNat p r := by
  have hex : ∃ i, 0 < p i := by
    by_contra! h
    have hzero : ∑ i, p i = 0 := Finset.sum_eq_zero (fun i _ => le_antisymm (h i) (hp i))
    linarith
  obtain ⟨i, hi⟩ := hex
  exact lt_of_lt_of_le (pow_pos hi r)
    (Finset.single_le_sum (fun j _ => pow_nonneg (hp j) r) (Finset.mem_univ i))

omit [MeasurableSpace Ω] [IsProbabilityMeasure μ] in
theorem powerSumNat_card_root (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    (hsum : ∑ i, p i = 1) (r : ℕ) (hr : 0 < r)
    (M : ℝ) (hM : 0 ≤ M) (hP : powerSumNat p r = M ^ r) :
    1 ≤ (Fintype.card ι : ℝ) ^ (1 - 1 / (r : ℝ)) * M := by
  have hrR : (0 : ℝ) < r := by exact_mod_cast hr
  have hJ := Real.rpow_sum_le_const_mul_sum_rpow_of_nonneg
    (s := Finset.univ) (f := p) (p := (r : ℝ)) (by exact_mod_cast hr) (fun i _ => hp i)
  simp only [hsum, Finset.card_univ, Real.rpow_natCast, one_pow] at hJ
  apply (pow_le_pow_iff_left₀ (by norm_num : (0 : ℝ) ≤ 1)
    (mul_nonneg (Real.rpow_nonneg (Nat.cast_nonneg _) _) hM) hr.ne').mp
  rw [one_pow, mul_pow, ← Real.rpow_mul_natCast (Nat.cast_nonneg _)]
  have hexp : (1 - 1 / (r : ℝ)) * r = (r : ℝ) - 1 := by field_simp
  rw [hexp, ← hP]
  exact hJ

omit [MeasurableSpace Ω] [IsProbabilityMeasure μ] in
theorem integer_sample_scale (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    (hsum : ∑ i, p i = 1) (r : ℕ) (hr : 0 < r)
    (M : ℝ) (hM : 0 ≤ M) (hP : powerSumNat p r = M ^ r)
    (D : ℝ) (hD : 0 ≤ D) (n : ℝ)
    (hn : D * r * (Fintype.card ι : ℝ) ^ (1 - 1 / (r : ℝ)) ≤ n) :
    D * r ≤ n * M := by
  have h := powerSumNat_card_root p hp hsum r hr M hM hP
  calc
    D * r = (D * r) * 1 := by ring
    _ ≤ (D * r) * ((Fintype.card ι : ℝ) ^ (1 - 1 / (r : ℝ)) * M) :=
      mul_le_mul_of_nonneg_left h (by positivity)
    _ = (D * r * (Fintype.card ι : ℝ) ^ (1 - 1 / (r : ℝ))) * M := by ring
    _ ≤ n * M := mul_le_mul_of_nonneg_right hn hM

omit [IsProbabilityMeasure μ] in
theorem rawCollision_rare_relative_variance (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (r : ℕ) (hr : 0 < r) (n : ℝ) (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i)
    (hn : 0 < n) (hlam : ∀ i, (lam i : ℝ) = n * p i)
    (T : ℝ) (hT : 0 ≤ T) (hrare : ∀ i, (lam i : ℝ) ≤ T)
    (P M D : ℝ) (hM : 0 < M) (hP : P = M ^ r) (hsub : powerSumNat p r ≤ P)
    (hD : 0 < D) (hscale : D * r ≤ n * M) :
    variance (rawCollision N r n) μ / P ^ 2 ≤ ((T + r) / (D * r)) ^ r := by
  have hrR : (0 : ℝ) < r := by exact_mod_cast hr
  have hvar := rawCollision_rare_variance N lam hLaw hpair r n p hp hn hlam T hT hrare
  have hfirst : variance (rawCollision N r n) μ ≤ P * ((T + r) / n) ^ r :=
    hvar.trans (mul_le_mul_of_nonneg_right hsub (by positivity))
  calc
    _ ≤ (P * ((T + r) / n) ^ r) / P ^ 2 :=
      div_le_div_of_nonneg_right hfirst (sq_nonneg _)
    _ = ((T + r) / (n * M)) ^ r := by
      rw [hP, div_pow, div_pow, mul_pow]
      field_simp
    _ ≤ ((T + r) / (D * r)) ^ r := by
      apply pow_le_pow_left₀ (by positivity)
      exact div_le_div_of_nonneg_left (by positivity) (mul_pos hD hrR) hscale

end Renyi
