import Renyi.Foundations
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv

/-!
# Explicit scalar budgets for the integer collision estimator

These estimates prove the numerical and exponential inequalities in Steps
2, 4 and 5 of `tutorial:integer-raw`, including its stated epsilon-dependent
sample constant. None of the tail budgets is assumed as a certificate.
-/

noncomputable section
open scoped BigOperators
namespace Renyi

def integerSampleConstant (eps : ℝ) : ℝ :=
  100 * Real.exp (2 * eps) / eps * (4096 / eps ^ 2 + 1)

def integerRareBase (eps : ℝ) : ℝ :=
  (4096 / eps ^ 2 + 1) / integerSampleConstant eps

def integerThreshold (eps : ℝ) (r : ℕ) : ℝ := 4096 * r / eps ^ 2

def integerEta (eps : ℝ) (r : ℕ) : ℝ := eps * (r - 1) / 2

def integerRareGap (eps : ℝ) (r : ℕ) : ℝ :=
  Real.exp (-integerEta eps r) * (1 - Real.exp (-integerEta eps r))

theorem integerSampleConstant_pos {eps : ℝ} (heps : 0 < eps) :
    0 < integerSampleConstant eps := by unfold integerSampleConstant; positivity

theorem integerSampleConstant_ge_two_div {eps : ℝ} (heps : 0 < eps) :
    2 / eps ≤ integerSampleConstant eps := by
  have he : 1 ≤ Real.exp (2 * eps) := Real.one_le_exp_iff.mpr (by positivity)
  have hq : 0 ≤ 4096 / eps ^ 2 := by positivity
  have hp := mul_le_mul_of_nonneg_left (by linarith : (1 : ℝ) ≤ 4096 / eps ^ 2 + 1)
    (by positivity : 0 ≤ 100 * Real.exp (2 * eps) / eps)
  unfold integerSampleConstant
  have h100 : 2 / eps ≤ 100 * Real.exp (2 * eps) / eps := by
    apply (div_le_div_iff_of_pos_right heps).mpr
    linarith
  nlinarith

theorem integerSampleConstant_eps_sq_ge {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) : 200 ≤ integerSampleConstant eps * eps ^ 2 := by
  have he : 1 ≤ Real.exp (2 * eps) := Real.one_le_exp_iff.mpr (by positivity)
  have hid : integerSampleConstant eps * eps ^ 3 =
      100 * Real.exp (2 * eps) * (4096 + eps ^ 2) := by
    unfold integerSampleConstant
    field_simp
  have hl : 200 * eps ≤ integerSampleConstant eps * eps ^ 3 := by
    rw [hid]
    nlinarith [sq_nonneg eps, mul_nonneg (sub_nonneg.mpr he) (sq_nonneg eps)]
  apply (mul_le_mul_iff_left₀ heps).mp
  nlinarith [hl]

/-- The numerator estimate used in exponential-tolerance Chebyshev. -/
theorem exp_sub_one_le_self_mul_exp (x : ℝ) :
    Real.exp x - 1 ≤ x * Real.exp x := by
  have h := mul_le_mul_of_nonneg_right (Real.add_one_le_exp (-x)) (Real.exp_pos x).le
  have hid : Real.exp (-x) * Real.exp x = 1 := by rw [← Real.exp_add]; simp
  rw [hid] at h
  nlinarith

/-- The denominator gains an exponential factor as the tolerance grows. -/
theorem self_mul_exp_half_le_exp_sub_one {y : ℝ} (hy : 0 ≤ y) :
    y * Real.exp (y / 2) ≤ Real.exp y - 1 := by
  have h := Real.self_le_sinh_iff.mpr (by positivity : 0 ≤ y / 2)
  rw [Real.sinh_eq] at h
  have hm := mul_le_mul_of_nonneg_right h (Real.exp_pos (y / 2)).le
  have hsame : Real.exp (y / 2) * Real.exp (y / 2) = Real.exp y := by
    rw [← Real.exp_add]
    congr 1
    ring
  have hopp : Real.exp (-(y / 2)) * Real.exp (y / 2) = 1 := by
    rw [← Real.exp_add]
    simp
  nlinarith

theorem exponential_tolerance_ratio_le {u y : ℝ} (hu : 0 ≤ u) (hy : 0 < y)
    (huy : u ≤ y) :
    (Real.exp u - 1) / (Real.exp y - 1) ^ 2 ≤ u / y ^ 2 := by
  have hgap : 0 < Real.exp y - 1 := sub_pos.mpr (Real.one_lt_exp_iff.mpr hy)
  have hnum : Real.exp u - 1 ≤ u * Real.exp y :=
    (exp_sub_one_le_self_mul_exp u).trans
      (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr huy) hu)
  have hden0 := self_mul_exp_half_le_exp_sub_one hy.le
  have hden := pow_le_pow_left₀ (mul_nonneg hy.le (Real.exp_pos _).le) hden0 2
  have hpow : Real.exp (y / 2) ^ 2 = Real.exp y := by
    rw [← Real.exp_nat_mul]
    congr 1
    ring
  rw [mul_pow, hpow] at hden
  apply (div_le_iff₀ (sq_pos_of_pos hgap)).mpr
  have hmul := mul_le_mul_of_nonneg_left hden (div_nonneg hu (sq_nonneg y))
  have hid : u / y ^ 2 * (y ^ 2 * Real.exp y) = u * Real.exp y := by field_simp
  rw [hid] at hmul
  exact hnum.trans hmul

/-- Step 2, with the displayed sample constant and no unresolved scalar assumptions. -/
theorem integer_upper_tail_budget {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) {r : ℕ} (hr : 2 ≤ r) :
    (Real.exp ((r : ℝ) / integerSampleConstant eps) - 1) /
      (Real.exp (eps * ((r : ℝ) - 1)) - 1) ^ 2 ≤ 1 / 100 := by
  have hr2 : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hr1 : 0 < (r : ℝ) - 1 := by linarith
  have hD := integerSampleConstant_pos heps
  have hDs := integerSampleConstant_ge_two_div heps
  have hDb := integerSampleConstant_eps_sq_ge heps hepshalf
  have hDe : 2 ≤ integerSampleConstant eps * eps := (div_le_iff₀ heps).mp hDs
  have hrle : (r : ℝ) ≤ 2 * ((r : ℝ) - 1) := by linarith
  have hru : (r : ℝ) / integerSampleConstant eps ≤ eps * ((r : ℝ) - 1) := by
    apply (div_le_iff₀ hD).mpr
    nlinarith [mul_le_mul_of_nonneg_right hDe (by linarith : 0 ≤ (r : ℝ) - 1)]
  have hratio := exponential_tolerance_ratio_le
    (by positivity : 0 ≤ (r : ℝ) / integerSampleConstant eps)
    (by positivity : 0 < eps * ((r : ℝ) - 1)) hru
  have hrquad : (r : ℝ) ≤ 2 * ((r : ℝ) - 1) ^ 2 := by nlinarith
  have hmid : ((r : ℝ) / integerSampleConstant eps) /
      (eps * ((r : ℝ) - 1)) ^ 2 ≤ 2 / (integerSampleConstant eps * eps ^ 2) := by
    apply (div_le_iff₀ (by positivity : 0 < (eps * ((r : ℝ) - 1)) ^ 2)).mpr
    apply (div_le_iff₀ hD).mpr
    have hid : 2 / (integerSampleConstant eps * eps ^ 2) *
        (eps * ((r : ℝ) - 1)) ^ 2 * integerSampleConstant eps =
        2 * ((r : ℝ) - 1) ^ 2 := by field_simp
    rw [hid]
    exact hrquad
  apply hratio.trans (hmid.trans _)
  apply (div_le_iff₀ (by positivity : 0 < integerSampleConstant eps * eps ^ 2)).mpr
  nlinarith

theorem integerRareBase_pos {eps : ℝ} (heps : 0 < eps) :
    0 < integerRareBase eps := by
  unfold integerRareBase
  exact div_pos (by positivity) (integerSampleConstant_pos heps)

theorem integerRareBase_exp {eps : ℝ} (heps : 0 < eps) :
    integerRareBase eps * Real.exp (2 * eps) = eps / 100 := by
  have hp : 0 < 4096 / eps ^ 2 + 1 := by positivity
  unfold integerRareBase integerSampleConstant
  field_simp

theorem integerEta_pos {eps : ℝ} (heps : 0 < eps) {r : ℕ} (hr : 2 ≤ r) :
    0 < integerEta eps r := by
  have hr2 : (2 : ℝ) ≤ r := by exact_mod_cast hr
  unfold integerEta
  exact div_pos (mul_pos heps (by linarith)) (by norm_num)

theorem integerRareGap_pos {eps : ℝ} (heps : 0 < eps) {r : ℕ} (hr : 2 ≤ r) :
    0 < integerRareGap eps r := by
  unfold integerRareGap
  exact mul_pos (Real.exp_pos _)
    (sub_pos.mpr (Real.exp_lt_one_iff.mpr (neg_neg_of_pos (integerEta_pos heps hr))))

theorem one_sub_exp_neg_lower (x : ℝ) :
    x * Real.exp (-x) ≤ 1 - Real.exp (-x) := by
  have h := mul_le_mul_of_nonneg_right (Real.add_one_le_exp x) (Real.exp_pos (-x)).le
  have hid : Real.exp x * Real.exp (-x) = 1 := by rw [← Real.exp_add]; simp
  rw [hid] at h
  nlinarith

theorem integerRareGap_sq_lower {eps : ℝ} (heps : 0 < eps) {r : ℕ} (hr : 2 ≤ r) :
    eps ^ 2 / 4 * Real.exp (-2 * eps * r) ≤ integerRareGap eps r ^ 2 := by
  have hr2 : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have heta := integerEta_pos heps hr
  have hh := mul_le_mul_of_nonneg_left (one_sub_exp_neg_lower (integerEta eps r))
    (Real.exp_pos (-integerEta eps r)).le
  have hid : Real.exp (-integerEta eps r) *
      (integerEta eps r * Real.exp (-integerEta eps r)) =
      integerEta eps r * Real.exp (-2 * integerEta eps r) := by
    rw [mul_left_comm, ← Real.exp_add]
    congr 2
    ring
  rw [hid] at hh
  have hsq := pow_le_pow_left₀ (mul_nonneg heta.le (Real.exp_pos _).le) hh 2
  change (integerEta eps r * Real.exp (-2 * integerEta eps r)) ^ 2 ≤
    integerRareGap eps r ^ 2 at hsq
  have hexpid : Real.exp (-2 * integerEta eps r) ^ 2 =
      Real.exp (-4 * integerEta eps r) := by
    rw [← Real.exp_nat_mul]
    congr 1
    ring
  rw [mul_pow, hexpid] at hsq
  have hetal : eps / 2 ≤ integerEta eps r := by unfold integerEta; nlinarith
  have hetasq : eps ^ 2 / 4 ≤ integerEta eps r ^ 2 := by nlinarith
  have hexple : Real.exp (-2 * eps * r) ≤ Real.exp (-4 * integerEta eps r) := by
    apply Real.exp_le_exp.mpr
    unfold integerEta
    nlinarith
  exact (mul_le_mul hetasq hexple (Real.exp_pos _).le (sq_nonneg _)).trans hsq

/-- Step 4: the light-count Chebyshev budget for the exact displayed D_epsilon. -/
theorem integer_rare_tail_budget {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) {r : ℕ} (hr : 2 ≤ r) :
    integerRareBase eps ^ r / integerRareGap eps r ^ 2 ≤ 4 / 10000 := by
  have hA := integerRareBase_pos heps
  have hd := integerRareGap_pos heps hr
  have hsmall : eps / 100 ≤ (1 : ℝ) := by linarith
  have hpow : (eps / 100) ^ r ≤ (eps / 100) ^ 2 :=
    pow_le_pow_of_le_one (by positivity) hsmall hr
  rw [← integerRareBase_exp heps, mul_pow, ← Real.exp_nat_mul] at hpow
  have hexppos := Real.exp_pos (-2 * eps * (r : ℝ))
  have hh := mul_le_mul_of_nonneg_right hpow hexppos.le
  have hcancel : Real.exp ((r : ℝ) * (2 * eps)) * Real.exp (-2 * eps * r) = 1 := by
    rw [← Real.exp_add]
    convert Real.exp_zero using 2
    ring
  have hleft : integerRareBase eps ^ r * Real.exp ((r : ℝ) * (2 * eps)) *
      Real.exp (-2 * eps * r) = integerRareBase eps ^ r := by
    rw [mul_assoc, hcancel, mul_one]
  rw [hleft, integerRareBase_exp heps] at hh
  have hden := integerRareGap_sq_lower heps hr
  apply (div_le_iff₀ (sq_pos_of_pos hd)).mpr
  nlinarith

theorem integerThreshold_pos {eps : ℝ} (heps : 0 < eps) {r : ℕ} (hr : 2 ≤ r) :
    0 < integerThreshold eps r := by
  have hrpos : 0 < r := by omega
  unfold integerThreshold
  positivity

/-- Step 5: the factorial correction is at most epsilon/16. -/
theorem integer_frequent_shift_budget {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) {r : ℕ} (hr : 2 ≤ r) :
    (r : ℝ) / integerThreshold eps r ≤ eps / 16 := by
  have hrpos : (0 : ℝ) < r := by exact_mod_cast (by omega : 0 < r)
  have hid : (r : ℝ) / integerThreshold eps r = eps ^ 2 / 4096 := by
    unfold integerThreshold
    field_simp
  rw [hid]
  nlinarith

/-- Step 5: the concentration probability of the weighted heavy average. -/
theorem integer_frequent_tail_budget {eps : ℝ} (heps : 0 < eps)
    {r : ℕ} (hr : 2 ≤ r) :
    256 / (eps ^ 2 * integerThreshold eps r) ≤ 1 / 32 := by
  have hr2 : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hrpos : (0 : ℝ) < r := by linarith
  have hid : 256 / (eps ^ 2 * integerThreshold eps r) = 1 / (16 * r) := by
    unfold integerThreshold
    field_simp
    norm_num
  rw [hid]
  apply (div_le_iff₀ (by positivity : (0 : ℝ) < 16 * r)).mpr
  nlinarith

theorem integer_log_frequent_base {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) :
    -eps / 4 ≤ Real.log (1 - eps / 8) := by
  have hb : 0 < 1 - eps / 8 := by linarith
  have hinv : (1 - eps / 8)⁻¹ ≤ 1 + eps / 4 := by
    apply (inv_le_iff_one_le_mul₀ hb).mpr
    nlinarith
  exact (by linarith : -eps / 4 ≤ 1 - (1 - eps / 8)⁻¹).trans
    (Real.one_sub_inv_le_log_of_pos hb)

/-- Step 5: the weighted-average lower bound reaches the needed entropy tolerance. -/
theorem integer_frequent_power_budget {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) {r : ℕ} (hr : 2 ≤ r) :
    Real.exp (-integerEta eps r) ≤ (1 - eps / 8) ^ r := by
  have hr2 : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hb : 0 < 1 - eps / 8 := by linarith
  have hexp : Real.exp (-eps / 4) ≤ 1 - eps / 8 :=
    (Real.le_log_iff_exp_le hb).mp (integer_log_frequent_base heps hepshalf)
  have hp := pow_le_pow_left₀ (Real.exp_pos _).le hexp r
  rw [← Real.exp_nat_mul] at hp
  apply le_trans _ hp
  apply Real.exp_le_exp.mpr
  unfold integerEta
  nlinarith

/-- The shift and mean-deviation budgets together produce the frequent-count base. -/
theorem integer_frequent_base_budget {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) {r : ℕ} (hr : 2 ≤ r) :
    1 - eps / 8 ≤ (1 - eps / 16) - (r : ℝ) / integerThreshold eps r := by
  linarith [integer_frequent_shift_budget heps hepshalf hr]

/-- The three exceptional probabilities fit within the manuscript's 1/12 budget. -/
theorem integer_total_tail_budget :
    (1 : ℝ) / 100 + 4 / 10000 + 1 / 32 < 1 / 12 := by norm_num

/-- Step 6: the two one-sided lower bounds combine into the exact entropy band. -/
theorem integer_lower_band_combine {eps : ℝ} (heps : 0 < eps)
    {r : ℕ} (hr : 2 ≤ r) {L H P F J : ℝ} (hL : 0 ≤ L)
    (hP : P = L + H) (hF : L - integerRareGap eps r * P ≤ F)
    (hJ : Real.exp (-integerEta eps r) * H ≤ J) :
    Real.exp (-eps * ((r : ℝ) - 1)) * P ≤ F + J := by
  have heta := integerEta_pos heps hr
  have he : Real.exp (-integerEta eps r) ≤ 1 :=
    Real.exp_le_one_iff.mpr (by linarith)
  have hL' := mul_le_mul_of_nonneg_right he hL
  have hid : Real.exp (-integerEta eps r) - integerRareGap eps r =
      Real.exp (-eps * ((r : ℝ) - 1)) := by
    unfold integerRareGap
    have hh : Real.exp (-integerEta eps r) * Real.exp (-integerEta eps r) =
        Real.exp (-eps * ((r : ℝ) - 1)) := by
      rw [← Real.exp_add]
      congr 1
      unfold integerEta
      ring
    nlinarith
  rw [← hid]
  nlinarith

/-- The displayed constant also makes the de-Poissonization tail budget explicit. -/
theorem integer_fixed_sample_scalar_budget {eps n : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) {r : ℕ} (hr : 2 ≤ r)
    (hn : integerSampleConstant eps * r ≤ n) :
    Real.exp (-n / 3) < 1 / 12 := by
  have hD := integerSampleConstant_pos heps
  have hDs := integerSampleConstant_eps_sq_ge heps hepshalf
  have hs : eps ^ 2 ≤ 1 := by nlinarith
  have hDb : 6 ≤ integerSampleConstant eps := by
    nlinarith [mul_le_mul_of_nonneg_left hs hD.le]
  have hr2 : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hn12 : 12 ≤ n := by nlinarith
  have he := Real.sum_le_exp_of_nonneg (by norm_num : (0 : ℝ) ≤ 4) 3
  norm_num [Finset.sum_range_succ] at he
  have hinv : Real.exp (-4 : ℝ) < 1 / 12 := by
    rw [Real.exp_neg, inv_lt_iff_one_lt_mul₀ (Real.exp_pos 4)]
    nlinarith
  apply lt_of_le_of_lt _ hinv
  apply Real.exp_le_exp.mpr
  linarith

end Renyi
