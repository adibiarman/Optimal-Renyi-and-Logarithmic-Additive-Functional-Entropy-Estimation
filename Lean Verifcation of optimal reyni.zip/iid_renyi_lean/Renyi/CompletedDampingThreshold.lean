import Renyi.DegreeOneStrictUpper

/-! A common sufficiently large damping works for both exact low branches. -/
noncomputable section
namespace Renyi

theorem coupledProfiles_strict_upper_damping_uniform {fL f E : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) (hE : 0<E) :
    ∃ M0 c : ℝ, 1≤M0 ∧ 0<c ∧
      ∀ (M : ℝ), M0≤M → ∀ (ℓ N : ℕ) (γ z ω x y : ℝ), 2≤ℓ → 2≤N → 0<γ → γ<1 →
        0<z → z≤Real.exp (-E) → 0≤ω → ω≤Real.exp (-E/8) →
        0≤x → x≤1 → 0≤y → y≤1 →
        ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y)≤
          Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) →
        coupledDampedExpression ℓ N γ z M ω fL f x y≤1-c*
          min (γ*(1-γ)+(N:ℝ)^2*y+min ((ℓ:ℝ)^2*x) 1) 1 := by
  let ρ := 1-Real.exp (-E/8)
  have hρ : 0<ρ := by dsimp [ρ];linarith only [Real.exp_lt_one_iff.mpr (show -E/8<0 by linarith only [hE])]
  have hρ1 : ρ≤1 := by dsimp [ρ];linarith only [Real.exp_pos (-E/8)]
  have hEρ : Real.exp (-E/2)≤1-ρ := by
    dsimp [ρ]
    have he : Real.exp (-E/2)≤Real.exp (-E/8) := Real.exp_le_exp.mpr (by linarith only [hE])
    linarith only [he]
  obtain ⟨σ,hσ,hσhalf,hσorder,hσroot,hσerror,hσlog,hσforward⟩ :=
    exists_fraction_margin_threshold (f:=f) hfL.le hfL1 hρ hE
  obtain ⟨τ,hτ,hτhalf,hτorder,hτroot,hτlog⟩ := exists_complement_margin_threshold hρ hρ1 hE
  let θ := min σ τ
  have hθ : 0<θ := lt_min hσ hτ
  let c := min (fractionMarginConstant fL ρ E) (min (complementMarginConstant fL ρ) (ρ/4))
  have hc : 0<c := lt_min (fractionMarginConstant_pos hfL1 hρ hE)
    (lt_min (complementMarginConstant_pos hfL hρ) (by positivity))
  refine ⟨max 1 (max (8/ρ) (4/(ρ*θ))),c,le_max_left _ _,hc,?_⟩
  intro M hM0M
  have hM : 1≤M := (le_max_left _ _).trans hM0M
  have hM0 : 0≤M := by linarith only [hM]
  have hMρ0 : 8/ρ≤M := ((le_max_left _ _).trans (le_max_right _ _)).trans hM0M
  have hMθ0 : 4/(ρ*θ)≤M := ((le_max_right _ _).trans (le_max_right _ _)).trans hM0M
  have hMρ : Real.exp (-M/2)≤ρ/4 := by
    have hm := (div_le_iff₀ hρ).mp hMρ0
    have hscale : 1/(ρ/4)≤M/2 := by
      apply (div_le_iff₀ (show 0<ρ/4 by positivity)).mpr
      nlinarith only [hm]
    simpa only [neg_div] using exp_neg_le_of_large (by positivity : 0<ρ/4) hscale
  have hMθ : Real.exp (-M*θ)≤ρ/4 := by
    have hm := (div_le_iff₀ (mul_pos hρ hθ)).mp hMθ0
    have hscale : 1/(ρ/4)≤M*θ := by
      apply (div_le_iff₀ (show 0<ρ/4 by positivity)).mpr
      nlinarith only [hm]
    simpa only [neg_mul] using exp_neg_le_of_large (by positivity : 0<ρ/4) hscale
  intro ℓ N γ z ω x y hℓ hN hγ hγ1 hz hzE hω hωE hx hx1 hy hy1 hcap
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hωρ : ω≤1-ρ := by dsimp [ρ];linarith only [hωE]
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  let R := min (γ*(1-γ)+(N:ℝ)^2*y+min ((ℓ:ℝ)^2*x) 1) 1
  have hR0 : 0≤R := le_min (add_nonneg (add_nonneg (mul_nonneg hγ.le hd.le) (by positivity))
    (le_min (by positivity) (by norm_num))) (by norm_num)
  have hR1 : R≤1 := min_le_right _ _
  have hRs := coupled_spatial_min_le_sum hγ.le hγ1.le (show 0≤(N:ℝ)^2*y by positivity)
    (show 0≤(ℓ:ℝ)^2*x by positivity)
  by_cases hγσ : γ≤σ
  · have hroot : 16*Real.sqrt γ≤E := (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hγσ) (by norm_num : (0:ℝ)≤16)).trans hσroot
    have herror := (mul_le_mul_of_nonneg_left hγσ (show 0≤40*Real.exp (Real.log 12+1) by positivity)).trans hσerror
    have hlog := (mul_le_mul_of_nonneg_left hγσ (show 0≤8*(-Real.log (1/(8*(1+highProfileIntegralConstant f)))) by
      have hK := highProfileIntegralConstant_pos f
      have hq : 1/(8*(1+highProfileIntegralConstant f))≤1 := (div_le_one (by positivity)).mpr (by linarith only [hK])
      exact mul_nonneg (by norm_num) (neg_nonneg.mpr (Real.log_nonpos (by positivity) hq))))
    have hlog' : 8*γ*(-Real.log (1/(8*(1+highProfileIntegralConstant f))))≤E := by nlinarith only [hlog,hσlog]
    have hforward := (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hγσ)
      (show 0≤(1+highProfileIntegralConstant f)*Real.exp (coupledProfileConstant+1) by
        have hK := highProfileIntegralConstant_pos f;positivity)).trans hσforward
    have hgap := coupledProfiles_fraction_spatial_gap hℓ hN hγ (hγσ.trans hσhalf) hM hρ hω hωρ
      hMρ hEρ hroot herror hlog' hforward hfL.le hfL1 hf hf1 hx hx1 hy hy1 hz hzE (hγσ.trans hσorder) hcap
    exact strict_margin_weaken hc.le (min_le_left _ _) hR0 hRs.1 hgap
  by_cases hδτ : 1-γ≤τ
  · have hγhalf : (1:ℝ)/2≤γ := by linarith only [hδτ,hτhalf]
    by_cases hMd : M*(1-γ)≤1
    · have hroot : 8*Real.sqrt (1-γ)≤E := (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hδτ) (by norm_num : (0:ℝ)≤8)).trans hτroot
      have hlog := mul_le_mul_of_nonneg_left hδτ (show 0≤4*(-Real.log (ρ/4)) by
        exact mul_nonneg (by norm_num) (neg_nonneg.mpr (Real.log_nonpos (by positivity) (by linarith only [hρ1] : ρ/4≤1))))
      have hlog' : 4*(1-γ)*(-Real.log (ρ/4))≤E := by nlinarith only [hlog,hτlog]
      have hgap := coupledProfiles_complement_spatial_gap hℓ hN hγhalf hγ1 hM hMd hρ hρ1
        (hMρ.trans (by linarith only [hρ] : ρ/4≤ρ/2)) hEρ hroot hlog'
        hfL hfL1 hf hf1.le hω hωρ hx hx1 hy hy1 hz hzE (hδτ.trans hτorder) hcap
      exact strict_margin_weaken hc.le ((min_le_right _ _).trans (min_le_left _ _)) hR0 hRs.2 hgap
    · have hgap := coupledProfiles_complement_large_damping_gap (by omega : 0<ℓ) (by omega : 0<N)
        hγhalf hγ1 hM0 (le_of_lt (lt_of_not_ge hMd)) hρ hMρ hfL.le hfL1 hf hf1.le hω hωρ hx hx1 hy hy1 hz hz1
      exact strict_margin_weaken hc.le ((min_le_right _ _).trans (min_le_right _ _)) hR0 hR1 (by simpa only [mul_one] using hgap)
  · have hσγ : θ≤γ := (min_le_left _ _).trans (le_of_lt (lt_of_not_ge hγσ))
    have hτδ : θ≤1-γ := (min_le_right _ _).trans (le_of_lt (lt_of_not_ge hδτ))
    have hgap := coupledProfiles_interior_upper_gap (by omega : 0<ℓ) (by omega : 0<N)
      hγ hγ1 hM0 hσγ hτδ hρ hω hωρ hMθ hfL.le hfL1 hf hf1.le hx hx1 hy hy1 hz hz1
    have hcoef : c≤ρ/2 := ((min_le_right _ _).trans (min_le_right _ _)).trans (by linarith only [hρ] : ρ/4≤ρ/2)
    exact strict_margin_weaken hc.le hcoef hR0 hR1 (by simpa only [mul_one] using hgap)

namespace DegreeOneCompletion

theorem coupledProfiles_strict_upper_damping_uniform {fL f E : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) (hE : 0<E) :
    ∃ M0 c : ℝ, 1≤M0 ∧ 0<c ∧
      ∀ (M : ℝ), M0≤M → ∀ (ℓ N : ℕ) (γ z ω x y : ℝ), 2≤ℓ → 2≤N → 0<γ → γ<1 →
        0<z → z≤Real.exp (-E) → 0≤ω → ω≤Real.exp (-E/8) →
        0≤x → x≤1 → 0≤y → y≤1 →
        x*((N:ℝ)^2*y)≤
          Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) →
        coupledDampedExpression ℓ N γ z M ω fL f x y≤1-c*
          min (γ*(1-γ)+(N:ℝ)^2*y+min x 1) 1 := by
  let ρ := 1-Real.exp (-E/8)
  have hρ : 0<ρ := by dsimp [ρ];linarith only [Real.exp_lt_one_iff.mpr (show -E/8<0 by linarith only [hE])]
  have hρ1 : ρ≤1 := by dsimp [ρ];linarith only [Real.exp_pos (-E/8)]
  have hEρ : Real.exp (-E/2)≤1-ρ := by
    dsimp [ρ]
    have he : Real.exp (-E/2)≤Real.exp (-E/8) := Real.exp_le_exp.mpr (by linarith only [hE])
    linarith only [he]
  obtain ⟨σ,hσ,hσhalf,hσorder,hσroot,hσerror,hσlog,hσforward⟩ :=
    exists_fraction_margin_threshold (f:=f) hfL.le hfL1 hρ hE
  obtain ⟨τ,hτ,hτhalf,hτorder,hτroot,hτlog⟩ := exists_complement_margin_threshold hρ hρ1 hE
  let θ := min σ τ
  have hθ : 0<θ := lt_min hσ hτ
  let c := min (fractionMarginConstant fL ρ E) (min (complementMarginConstant fL ρ) (ρ/4))
  have hc : 0<c := lt_min (fractionMarginConstant_pos hfL1 hρ hE)
    (lt_min (complementMarginConstant_pos hfL hρ) (by positivity))
  refine ⟨max 1 (max (8/ρ) (4/(ρ*θ))),c,le_max_left _ _,hc,?_⟩
  intro M hM0M
  have hM : 1≤M := (le_max_left _ _).trans hM0M
  have hM0 : 0≤M := by linarith only [hM]
  have hMρ0 : 8/ρ≤M := ((le_max_left _ _).trans (le_max_right _ _)).trans hM0M
  have hMθ0 : 4/(ρ*θ)≤M := ((le_max_right _ _).trans (le_max_right _ _)).trans hM0M
  have hMρ : Real.exp (-M/2)≤ρ/4 := by
    have hm := (div_le_iff₀ hρ).mp hMρ0
    have hscale : 1/(ρ/4)≤M/2 := by
      apply (div_le_iff₀ (show 0<ρ/4 by positivity)).mpr
      nlinarith only [hm]
    simpa only [neg_div] using exp_neg_le_of_large (by positivity : 0<ρ/4) hscale
  have hMθ : Real.exp (-M*θ)≤ρ/4 := by
    have hm := (div_le_iff₀ (mul_pos hρ hθ)).mp hMθ0
    have hscale : 1/(ρ/4)≤M*θ := by
      apply (div_le_iff₀ (show 0<ρ/4 by positivity)).mpr
      nlinarith only [hm]
    simpa only [neg_mul] using exp_neg_le_of_large (by positivity : 0<ρ/4) hscale
  intro ℓ N γ z ω x y hℓ hN hγ hγ1 hz hzE hω hωE hx hx1 hy hy1 hcap
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hωρ : ω≤1-ρ := by dsimp [ρ];linarith only [hωE]
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  let R := min (γ*(1-γ)+(N:ℝ)^2*y+min x 1) 1
  have hR0 : 0≤R := le_min (add_nonneg (add_nonneg (mul_nonneg hγ.le hd.le) (by positivity))
    (le_min (by positivity) (by norm_num))) (by norm_num)
  have hR1 : R≤1 := min_le_right _ _
  have hRs := coupled_spatial_min_le_sum hγ.le hγ1.le (show 0≤(N:ℝ)^2*y by positivity)
    (show 0≤x by positivity)
  by_cases hγσ : γ≤σ
  · have hroot : 16*Real.sqrt γ≤E := (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hγσ) (by norm_num : (0:ℝ)≤16)).trans hσroot
    have herror := (mul_le_mul_of_nonneg_left hγσ (show 0≤40*Real.exp (Real.log 12+1) by positivity)).trans hσerror
    have hlog := (mul_le_mul_of_nonneg_left hγσ (show 0≤8*(-Real.log (1/(8*(1+highProfileIntegralConstant f)))) by
      have hK := highProfileIntegralConstant_pos f
      have hq : 1/(8*(1+highProfileIntegralConstant f))≤1 := (div_le_one (by positivity)).mpr (by linarith only [hK])
      exact mul_nonneg (by norm_num) (neg_nonneg.mpr (Real.log_nonpos (by positivity) hq))))
    have hlog' : 8*γ*(-Real.log (1/(8*(1+highProfileIntegralConstant f))))≤E := by nlinarith only [hlog,hσlog]
    have hforward := (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hγσ)
      (show 0≤(1+highProfileIntegralConstant f)*Real.exp (coupledProfileConstant+1) by
        have hK := highProfileIntegralConstant_pos f;positivity)).trans hσforward
    have hgap := coupledProfiles_fraction_spatial_gap hℓ hN hγ (hγσ.trans hσhalf) hM hρ hω hωρ
      hMρ hEρ hroot herror hlog' hforward hfL.le hfL1 hf hf1 hx hx1 hy hy1 hz hzE (hγσ.trans hσorder) hcap
    exact strict_margin_weaken hc.le (min_le_left _ _) hR0 hRs.1 hgap
  by_cases hδτ : 1-γ≤τ
  · have hγhalf : (1:ℝ)/2≤γ := by linarith only [hδτ,hτhalf]
    by_cases hMd : M*(1-γ)≤1
    · have hroot : 8*Real.sqrt (1-γ)≤E := (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hδτ) (by norm_num : (0:ℝ)≤8)).trans hτroot
      have hlog := mul_le_mul_of_nonneg_left hδτ (show 0≤4*(-Real.log (ρ/4)) by
        exact mul_nonneg (by norm_num) (neg_nonneg.mpr (Real.log_nonpos (by positivity) (by linarith only [hρ1] : ρ/4≤1))))
      have hlog' : 4*(1-γ)*(-Real.log (ρ/4))≤E := by nlinarith only [hlog,hτlog]
      have hgap := coupledProfiles_complement_spatial_gap hℓ hN hγhalf hγ1 hM hMd hρ hρ1
        (hMρ.trans (by linarith only [hρ] : ρ/4≤ρ/2)) hEρ hroot hlog'
        hfL hfL1 hf hf1.le hω hωρ hx hx1 hy hy1 hz hzE (hδτ.trans hτorder) hcap
      exact strict_margin_weaken hc.le ((min_le_right _ _).trans (min_le_left _ _)) hR0 hRs.2 hgap
    · have hgap := coupledProfiles_complement_large_damping_gap (by omega : 0<ℓ) (by omega : 0<N)
        hγhalf hγ1 hM0 (le_of_lt (lt_of_not_ge hMd)) hρ hMρ hfL.le hfL1 hf hf1.le hω hωρ hx hx1 hy hy1 hz hz1
      exact strict_margin_weaken hc.le ((min_le_right _ _).trans (min_le_right _ _)) hR0 hR1 (by simpa only [mul_one] using hgap)
  · have hσγ : θ≤γ := (min_le_left _ _).trans (le_of_lt (lt_of_not_ge hγσ))
    have hτδ : θ≤1-γ := (min_le_right _ _).trans (le_of_lt (lt_of_not_ge hδτ))
    have hgap := coupledProfiles_interior_upper_gap (by omega : 0<ℓ) (by omega : 0<N)
      hγ hγ1 hM0 hσγ hτδ hρ hω hωρ hMθ hfL.le hfL1 hf hf1.le hx hx1 hy hy1 hz hz1
    have hcoef : c≤ρ/2 := ((min_le_right _ _).trans (min_le_right _ _)).trans (by linarith only [hρ] : ρ/4≤ρ/2)
    exact strict_margin_weaken hc.le hcoef hR0 hR1 (by simpa only [mul_one] using hgap)


end DegreeOneCompletion
end Renyi
