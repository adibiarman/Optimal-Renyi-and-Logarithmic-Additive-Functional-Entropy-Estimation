import Renyi.Testing
import Mathlib.Analysis.Calculus.Taylor
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Data.Nat.Choose.Cast
import Mathlib.Data.Nat.Choose.Sum

/-!
# Poisson-mixture Taylor estimates for the one-unmatched-moment argument

The theorem statements below record their exact scope. No count-distance
certificate is assumed as an axiom.
-/

noncomputable section
open scoped BigOperators NNReal
open ProbabilityTheory Set
namespace Renyi

/-- Taylor's remainder for exp(-z), with no small-z hypothesis. -/
theorem exp_neg_taylor_remainder (n : ℕ) {z : ℝ} (hz : 0 ≤ z) :
    |Real.exp (-z) - ∑ l ∈ Finset.range (n + 1), (-z) ^ l / (l.factorial : ℝ)| ≤
      z ^ (n + 1) / ((n + 1).factorial : ℝ) := by
  by_cases hz0 : z = 0
  · subst z
    simp [Finset.sum_range_succ']
  have hzp : 0 < z := lt_of_le_of_ne hz (Ne.symm hz0)
  have hf (m : ℕ) : ContDiff ℝ m (fun t : ℝ => Real.exp ((-1) * t)) := by
    fun_prop
  obtain ⟨y, hy, hrem⟩ := taylor_mean_remainder_lagrange_iteratedDeriv
    (f := fun t : ℝ => Real.exp ((-1) * t)) (n := n) hzp (hf (n + 1)).contDiffOn
  have hcoeff (l : ℕ) :
      iteratedDerivWithin l (fun t : ℝ => Real.exp ((-1) * t)) (Icc 0 z) 0 = (-1 : ℝ) ^ l := by
    rw [iteratedDerivWithin_eq_iteratedDeriv (uniqueDiffOn_Icc hzp)
      (hf l).contDiffAt ⟨le_rfl, hz⟩, iteratedDeriv_exp_const_mul]
    simp
  have hpoly : taylorWithinEval (fun t : ℝ => Real.exp ((-1) * t)) n (Icc 0 z) 0 z =
      ∑ l ∈ Finset.range (n + 1), (-z) ^ l / (l.factorial : ℝ) := by
    rw [taylor_within_apply]
    apply Finset.sum_congr rfl
    intro l _
    rw [hcoeff]
    simp only [sub_zero, smul_eq_mul]
    rw [show (-z) ^ l = (-1 : ℝ) ^ l * z ^ l by rw [← mul_pow]; congr 1; ring]
    ring
  rw [hpoly, iteratedDeriv_exp_const_mul] at hrem
  simp only [neg_one_mul, sub_zero] at hrem
  rw [hrem, abs_div, abs_mul, abs_mul, abs_pow, abs_neg, abs_one, one_pow,
    one_mul, abs_of_pos (Real.exp_pos _), abs_of_nonneg (pow_nonneg hz _),
    Nat.abs_cast]
  apply div_le_div_of_nonneg_right _ (by positivity)
  have he : Real.exp (-y) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith [hy.1])
  simpa only [one_mul] using mul_le_mul_of_nonneg_right he (pow_nonneg hz _)

/-- The corresponding Taylor remainder for one Poisson count probability. -/
theorem poisson_scalar_taylor_remainder (j n : ℕ) {z : ℝ} (hz : 0 ≤ z) :
    |Real.exp (-z) * z ^ j / (j.factorial : ℝ) -
      ∑ l ∈ Finset.range (n + 1),
        (-1 : ℝ) ^ l * z ^ (j + l) / ((j.factorial : ℝ) * l.factorial)| ≤
      z ^ (j + (n + 1)) / ((j.factorial : ℝ) * (n + 1).factorial) := by
  have hpoly :
      (∑ l ∈ Finset.range (n + 1),
        (-1 : ℝ) ^ l * z ^ (j + l) / ((j.factorial : ℝ) * l.factorial)) =
      (z ^ j / (j.factorial : ℝ)) *
        ∑ l ∈ Finset.range (n + 1), (-z) ^ l / (l.factorial : ℝ) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro l _
    rw [pow_add, show (-z) ^ l = (-1 : ℝ) ^ l * z ^ l by
      rw [← mul_pow]; congr 1; ring]
    ring
  rw [hpoly, show Real.exp (-z) * z ^ j / (j.factorial : ℝ) =
    (z ^ j / (j.factorial : ℝ)) * Real.exp (-z) by ring, ← mul_sub,
    abs_mul, abs_of_nonneg (by positivity : 0 ≤ z ^ j / (j.factorial : ℝ))]
  have h := mul_le_mul_of_nonneg_left (exp_neg_taylor_remainder n hz)
    (show 0 ≤ z ^ j / (j.factorial : ℝ) by positivity)
  convert h using 1
  rw [pow_add]
  ring

/-- Finite atomic moments. Normalization is unnecessary for the Taylor bound. -/
def atomicMoment {ι : Type*} [Fintype ι] (mass value : ι → ℝ) (j : ℕ) : ℝ :=
  ∑ i, mass i * value i ^ j

def poissonMixture {ι : Type*} [Fintype ι] (mass value : ι → ℝ) (θ : ℝ) (j : ℕ) : ℝ :=
  ∑ i, mass i * (Real.exp (-(θ * value i)) * (θ * value i) ^ j / (j.factorial : ℝ))

/-- The finite mixed-count polynomial written in terms of actual moments. -/
def poissonMixtureTaylor {ι : Type*} [Fintype ι] (mass value : ι → ℝ)
    (θ : ℝ) (j n : ℕ) : ℝ :=
  ∑ l ∈ Finset.range (n + 1),
    (-1 : ℝ) ^ l * θ ^ (j + l) * atomicMoment mass value (j + l) /
      ((j.factorial : ℝ) * l.factorial)

theorem poissonMixtureTaylor_eq {ι : Type*} [Fintype ι] (mass value : ι → ℝ)
    (θ : ℝ) (j n : ℕ) :
    poissonMixtureTaylor mass value θ j n =
      ∑ i, mass i * (∑ l ∈ Finset.range (n + 1),
        (-1 : ℝ) ^ l * (θ * value i) ^ (j + l) /
          ((j.factorial : ℝ) * l.factorial)) := by
  unfold poissonMixtureTaylor atomicMoment
  simp_rw [Finset.mul_sum, Finset.sum_div]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro l _
  rw [mul_pow]
  ring

/-- A quantitative remainder for an actual finite atomic Poisson mixture. -/
theorem poissonMixture_taylor_remainder {ι : Type*} [Fintype ι]
    (mass value : ι → ℝ) (θ : ℝ) (j n : ℕ)
    (hmass : ∀ i, 0 ≤ mass i) (hvalue : ∀ i, 0 ≤ value i) (hθ : 0 ≤ θ) :
    |poissonMixture mass value θ j - poissonMixtureTaylor mass value θ j n| ≤
      θ ^ (j + (n + 1)) * atomicMoment mass value (j + (n + 1)) /
        ((j.factorial : ℝ) * (n + 1).factorial) := by
  rw [poissonMixtureTaylor_eq]
  unfold poissonMixture
  rw [← Finset.sum_sub_distrib]
  calc
    |∑ i, (mass i * (Real.exp (-(θ * value i)) * (θ * value i) ^ j / (j.factorial : ℝ)) -
        mass i * ∑ l ∈ Finset.range (n + 1),
          (-1 : ℝ) ^ l * (θ * value i) ^ (j + l) / ((j.factorial : ℝ) * l.factorial))| ≤
        ∑ i, |mass i * (Real.exp (-(θ * value i)) * (θ * value i) ^ j / (j.factorial : ℝ)) -
          mass i * ∑ l ∈ Finset.range (n + 1),
            (-1 : ℝ) ^ l * (θ * value i) ^ (j + l) / ((j.factorial : ℝ) * l.factorial)| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i, mass i * ((θ * value i) ^ (j + (n + 1)) /
        ((j.factorial : ℝ) * (n + 1).factorial)) := by
      apply Finset.sum_le_sum
      intro i _
      rw [← mul_sub, abs_mul, abs_of_nonneg (hmass i)]
      exact mul_le_mul_of_nonneg_left
        (poisson_scalar_taylor_remainder j n (mul_nonneg hθ (hvalue i))) (hmass i)
    _ = θ ^ (j + (n + 1)) * atomicMoment mass value (j + (n + 1)) /
        ((j.factorial : ℝ) * (n + 1).factorial) := by
      unfold atomicMoment
      simp_rw [mul_pow]
      rw [Finset.mul_sum, Finset.sum_div]
      apply Finset.sum_congr rfl
      intro i _
      ring

/-- Matching moments remove all low-degree terms except the selected degree. -/
theorem poissonMixtureTaylor_one_defect {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    (mass₀ value₀ : ι₀ → ℝ) (mass₁ value₁ : ι₁ → ℝ)
    (θ : ℝ) (j n r : ℕ) (hjr : j ≤ r) (hr : r ≤ j + n)
    (hmatch : ∀ m : ℕ, j ≤ m → m ≤ j + n → m ≠ r →
      atomicMoment mass₁ value₁ m = atomicMoment mass₀ value₀ m) :
    poissonMixtureTaylor mass₁ value₁ θ j n - poissonMixtureTaylor mass₀ value₀ θ j n =
      (-1 : ℝ) ^ (r - j) * θ ^ r *
        (atomicMoment mass₁ value₁ r - atomicMoment mass₀ value₀ r) /
          ((j.factorial : ℝ) * (r - j).factorial) := by
  unfold poissonMixtureTaylor
  rw [← Finset.sum_sub_distrib]
  rw [Finset.sum_eq_single (r - j)]
  · rw [Nat.add_sub_of_le hjr]
    ring
  · intro l hl hlne
    have hm : j + l ≠ r := by omega
    rw [hmatch (j + l) (by omega) (by have := Finset.mem_range.mp hl; omega) hm]
    ring
  · intro hnot
    exfalso
    exact hnot (Finset.mem_range.mpr (by omega))

theorem poissonMixtureTaylor_all_match {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    (mass₀ value₀ : ι₀ → ℝ) (mass₁ value₁ : ι₁ → ℝ)
    (θ : ℝ) (j n : ℕ)
    (hmatch : ∀ m : ℕ, j ≤ m → m ≤ j + n →
      atomicMoment mass₁ value₁ m = atomicMoment mass₀ value₀ m) :
    poissonMixtureTaylor mass₁ value₁ θ j n = poissonMixtureTaylor mass₀ value₀ θ j n := by
  unfold poissonMixtureTaylor
  apply Finset.sum_congr rfl
  intro l hl
  rw [hmatch (j + l) (by omega) (by have := Finset.mem_range.mp hl; omega)]

/-- Subtracting two actual mixture expansions preserves the exact moment defect. -/
theorem poissonMixture_one_defect_remainder {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    (mass₀ value₀ : ι₀ → ℝ) (mass₁ value₁ : ι₁ → ℝ)
    (θ : ℝ) (j n r : ℕ)
    (hm₀ : ∀ i, 0 ≤ mass₀ i) (hv₀ : ∀ i, 0 ≤ value₀ i)
    (hm₁ : ∀ i, 0 ≤ mass₁ i) (hv₁ : ∀ i, 0 ≤ value₁ i) (hθ : 0 ≤ θ)
    (hjr : j ≤ r) (hr : r ≤ j + n)
    (hmatch : ∀ m : ℕ, j ≤ m → m ≤ j + n → m ≠ r →
      atomicMoment mass₁ value₁ m = atomicMoment mass₀ value₀ m) :
    |(poissonMixture mass₁ value₁ θ j - poissonMixture mass₀ value₀ θ j) -
      (-1 : ℝ) ^ (r - j) * θ ^ r *
        (atomicMoment mass₁ value₁ r - atomicMoment mass₀ value₀ r) /
          ((j.factorial : ℝ) * (r - j).factorial)| ≤
      θ ^ (j + (n + 1)) *
        (atomicMoment mass₁ value₁ (j + (n + 1)) + atomicMoment mass₀ value₀ (j + (n + 1))) /
          ((j.factorial : ℝ) * (n + 1).factorial) := by
  rw [← poissonMixtureTaylor_one_defect mass₀ value₀ mass₁ value₁ θ j n r hjr hr hmatch]
  have h₀ := poissonMixture_taylor_remainder mass₀ value₀ θ j n hm₀ hv₀ hθ
  have h₁ := poissonMixture_taylor_remainder mass₁ value₁ θ j n hm₁ hv₁ hθ
  have htriangle := abs_sub
    (poissonMixture mass₁ value₁ θ j - poissonMixtureTaylor mass₁ value₁ θ j n)
    (poissonMixture mass₀ value₀ θ j - poissonMixtureTaylor mass₀ value₀ θ j n)
  have hid : (poissonMixture mass₁ value₁ θ j - poissonMixture mass₀ value₀ θ j) -
      (poissonMixtureTaylor mass₁ value₁ θ j n - poissonMixtureTaylor mass₀ value₀ θ j n) =
      (poissonMixture mass₁ value₁ θ j - poissonMixtureTaylor mass₁ value₁ θ j n) -
      (poissonMixture mass₀ value₀ θ j - poissonMixtureTaylor mass₀ value₀ θ j n) := by ring
  rw [hid]
  calc
    _ ≤ _ := htriangle
    _ ≤ _ := add_le_add h₁ h₀
    _ = _ := by ring

/-- All mixed count probabilities are nonnegative. -/
theorem poissonMixture_nonneg {ι : Type*} [Fintype ι]
    (mass value : ι → ℝ) (θ : ℝ) (j : ℕ)
    (hmass : ∀ i, 0 ≤ mass i) (hvalue : ∀ i, 0 ≤ value i) (hθ : 0 ≤ θ) :
    0 ≤ poissonMixture mass value θ j := by
  unfold poissonMixture
  apply Finset.sum_nonneg
  intro i _
  exact mul_nonneg (hmass i) (div_nonneg
    (mul_nonneg (Real.exp_pos _).le (pow_nonneg (mul_nonneg hθ (hvalue i)) _)) (by positivity))

/-- Summability of the actual finite mixed-count sequence. -/
theorem poissonMixture_hasSum {ι : Type*} [Fintype ι]
    (mass value : ι → ℝ) (θ : ℝ)
    (hvalue : ∀ i, 0 ≤ value i) (hθ : 0 ≤ θ) :
    HasSum (poissonMixture mass value θ) (∑ i, mass i) := by
  have h (i : ι) := (poissonPMFRealSum (⟨θ * value i, mul_nonneg hθ (hvalue i)⟩ : ℝ≥0)).mul_left (mass i)
  have hs := hasSum_sum (s := (Finset.univ : Finset ι)) (fun i _ => h i)
  simpa [poissonMixture, poissonPMFReal] using hs

/-- Factorial moments of an actual mixed-count law. -/
theorem poissonMixture_factorial_hasSum {ι : Type*} [Fintype ι]
    (mass value : ι → ℝ) (θ : ℝ) (M : ℕ)
    (hvalue : ∀ i, 0 ≤ value i) (hθ : 0 ≤ θ) :
    HasSum (fun j => (j.descFactorial M : ℝ) * poissonMixture mass value θ j)
      (θ ^ M * atomicMoment mass value M) := by
  have h (i : ι) :=
    (poisson_factorial_hasSum (⟨θ * value i, mul_nonneg hθ (hvalue i)⟩ : ℝ≥0) M).mul_left (mass i)
  have hs := hasSum_sum (s := (Finset.univ : Finset ι)) (fun i _ => h i)
  simpa [poissonMixture, poissonPMFReal, atomicMoment, Finset.mul_sum,
    mul_pow, mul_assoc, mul_comm, mul_left_comm] using hs

/-- Factorial Markov bound for the entire upper tail, not just individual counts. -/
theorem poissonMixture_tail_bound {ι : Type*} [Fintype ι]
    (mass value : ι → ℝ) (θ : ℝ) (M : ℕ)
    (hmass : ∀ i, 0 ≤ mass i) (hvalue : ∀ i, 0 ≤ value i) (hθ : 0 ≤ θ) :
    (∑' j : ℕ, poissonMixture mass value θ (j + M)) ≤
      θ ^ M * atomicMoment mass value M / (M.factorial : ℝ) := by
  have hM : 0 < (M.factorial : ℝ) := by positivity
  have hzero : ∑ j ∈ Finset.range M,
      (j.descFactorial M : ℝ) * poissonMixture mass value θ j = 0 := by
    apply Finset.sum_eq_zero
    intro j hj
    rw [Nat.descFactorial_eq_zero_iff_lt.mpr (Finset.mem_range.mp hj)]
    simp
  have hshift : HasSum
      (fun j => ((j + M).descFactorial M : ℝ) * poissonMixture mass value θ (j + M))
      (θ ^ M * atomicMoment mass value M) := by
    apply (hasSum_nat_add_iff (f := fun j : ℕ => (j.descFactorial M : ℝ) * poissonMixture mass value θ j) M).mpr
    simpa only [hzero, add_zero] using poissonMixture_factorial_hasSum mass value θ M hvalue hθ
  have hdiv := hshift.div_const (M.factorial : ℝ)
  have hqsummable := (summable_nat_add_iff M).mpr (poissonMixture_hasSum mass value θ hvalue hθ).summable
  have hpoint (j : ℕ) : poissonMixture mass value θ (j + M) ≤
      (((j + M).descFactorial M : ℝ) * poissonMixture mass value θ (j + M)) /
        (M.factorial : ℝ) := by
    have hdesc : (M.factorial : ℝ) ≤ ((j + M).descFactorial M : ℝ) := by
      exact_mod_cast (show M.factorial ≤ (j + M).descFactorial M by
        simpa only [Nat.descFactorial_self] using Nat.descFactorial_le M (show M ≤ j + M by omega))
    apply (le_div_iff₀ hM).2
    simpa only [mul_comm] using mul_le_mul_of_nonneg_right hdesc
      (poissonMixture_nonneg mass value θ (j + M) hmass hvalue hθ)
  exact (hqsummable.tsum_le_tsum hpoint hdiv.summable).trans_eq hdiv.tsum_eq

/-- Exact sum of the reciprocal factorial coefficients in the remainder. -/
theorem reciprocal_factorial_sum (M : ℕ) :
    (∑ j ∈ Finset.range (M + 1),
      1 / ((j.factorial : ℝ) * (M - j).factorial)) = (2 : ℝ) ^ M / M.factorial := by
  have hterm (j : ℕ) (hj : j ∈ Finset.range (M + 1)) :
      1 / ((j.factorial : ℝ) * (M - j).factorial) = (M.choose j : ℝ) / M.factorial := by
    rw [Nat.cast_choose ℝ (by have := Finset.mem_range.mp hj; omega)]
    field_simp
  calc
    _ = ∑ j ∈ Finset.range (M + 1), (M.choose j : ℝ) / M.factorial :=
      Finset.sum_congr rfl hterm
    _ = (∑ j ∈ Finset.range (M + 1), (M.choose j : ℝ)) / M.factorial :=
      (Finset.sum_div _ _ _).symm
    _ = (2 : ℝ) ^ M / M.factorial := by
      congr 1
      exact_mod_cast Nat.sum_range_choose M

/-- The squared-defect coefficients have the same exponential sum bound. -/
theorem reciprocal_factorial_square_sum (r : ℕ) :
    (∑ j ∈ Finset.range (r + 1),
      1 / ((j.factorial : ℝ) * ((r - j).factorial : ℝ) ^ 2)) ≤
        (2 : ℝ) ^ r / r.factorial := by
  rw [← reciprocal_factorial_sum r]
  apply Finset.sum_le_sum
  intro j _
  apply one_div_le_one_div_of_le (by positivity)
  have hf : (1 : ℝ) ≤ ((r - j).factorial : ℝ) := by exact_mod_cast (Nat.succ_le_of_lt (Nat.factorial_pos (r - j)))
  have hj : 0 ≤ (j.factorial : ℝ) := by positivity
  nlinarith [mul_nonneg hj (show 0 ≤ ((r - j).factorial : ℝ) ^ 2 - (r - j).factorial by nlinarith)]

/-- The only noncancelled Taylor coefficient. Its support is finite. -/
def poissonDefectTerm (θ Δ : ℝ) (r j : ℕ) : ℝ :=
  if j ≤ r then (-1 : ℝ) ^ (r - j) * θ ^ r * Δ /
    ((j.factorial : ℝ) * (r - j).factorial) else 0

theorem poissonDefectTerm_summable (θ Δ : ℝ) (r : ℕ) :
    Summable (poissonDefectTerm θ Δ r) := by
  apply summable_of_ne_finset_zero (s := Finset.range (r + 1))
  intro j hj
  have h : ¬ j ≤ r := by simpa only [Finset.mem_range, Nat.lt_succ_iff] using hj
  simp [poissonDefectTerm, h]

theorem poissonMixture_defect_remainder_lt {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    (mass₀ value₀ : ι₀ → ℝ) (mass₁ value₁ : ι₁ → ℝ)
    (θ : ℝ) (M r j : ℕ)
    (hm₀ : ∀ i, 0 ≤ mass₀ i) (hv₀ : ∀ i, 0 ≤ value₀ i)
    (hm₁ : ∀ i, 0 ≤ mass₁ i) (hv₁ : ∀ i, 0 ≤ value₁ i) (hθ : 0 ≤ θ)
    (hr : r < M) (hj : j < M)
    (hmatch : ∀ m : ℕ, m < M → m ≠ r →
      atomicMoment mass₁ value₁ m = atomicMoment mass₀ value₀ m) :
    |(poissonMixture mass₁ value₁ θ j - poissonMixture mass₀ value₀ θ j) -
      poissonDefectTerm θ (atomicMoment mass₁ value₁ r - atomicMoment mass₀ value₀ r) r j| ≤
      θ ^ M * (atomicMoment mass₁ value₁ M + atomicMoment mass₀ value₀ M) /
        ((j.factorial : ℝ) * (M - j).factorial) := by
  have hidx : j + ((M - 1 - j) + 1) = M := by omega
  have hidx' : (M - 1 - j) + 1 = M - j := by omega
  by_cases hjr : j ≤ r
  · have h := poissonMixture_one_defect_remainder mass₀ value₀ mass₁ value₁ θ j (M - 1 - j) r
      hm₀ hv₀ hm₁ hv₁ hθ hjr (by omega)
      (fun m _ hm hne => hmatch m (by omega) hne)
    rw [hidx, hidx'] at h
    simpa only [poissonDefectTerm, if_pos hjr] using h
  · have hp := poissonMixtureTaylor_all_match mass₀ value₀ mass₁ value₁ θ j (M - 1 - j)
      (fun m hm hm' => hmatch m (by omega) (by omega))
    have h₀ := poissonMixture_taylor_remainder mass₀ value₀ θ j (M - 1 - j) hm₀ hv₀ hθ
    have h₁ := poissonMixture_taylor_remainder mass₁ value₁ θ j (M - 1 - j) hm₁ hv₁ hθ
    rw [hp] at h₁
    rw [hidx, hidx'] at h₀ h₁
    simp only [poissonDefectTerm, if_neg hjr, sub_zero]
    have htri := abs_sub
      (poissonMixture mass₁ value₁ θ j - poissonMixtureTaylor mass₀ value₀ θ j (M - 1 - j))
      (poissonMixture mass₀ value₀ θ j - poissonMixtureTaylor mass₀ value₀ θ j (M - 1 - j))
    have hid : (poissonMixture mass₁ value₁ θ j - poissonMixtureTaylor mass₀ value₀ θ j (M - 1 - j)) -
        (poissonMixture mass₀ value₀ θ j - poissonMixtureTaylor mass₀ value₀ θ j (M - 1 - j)) =
        poissonMixture mass₁ value₁ θ j - poissonMixture mass₀ value₀ θ j := by ring
    rw [hid] at htri
    calc
      _ ≤ _ := htri
      _ ≤ _ := add_le_add h₁ h₀
      _ = _ := by ring

/-- The entire residual sequence is absolutely summable. -/
theorem poissonMixture_defect_remainder_summable {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    (mass₀ value₀ : ι₀ → ℝ) (mass₁ value₁ : ι₁ → ℝ) (θ : ℝ) (r : ℕ)
    (hv₀ : ∀ i, 0 ≤ value₀ i) (hv₁ : ∀ i, 0 ≤ value₁ i) (hθ : 0 ≤ θ) :
    Summable (fun j : ℕ => |(poissonMixture mass₁ value₁ θ j - poissonMixture mass₀ value₀ θ j) -
      poissonDefectTerm θ (atomicMoment mass₁ value₁ r - atomicMoment mass₀ value₀ r) r j|) :=
  (((poissonMixture_hasSum mass₁ value₁ θ hv₁ hθ).summable.sub
    (poissonMixture_hasSum mass₀ value₀ θ hv₀ hθ).summable).sub
      (poissonDefectTerm_summable _ _ r)).abs

theorem atomicMoment_nonneg {ι : Type*} [Fintype ι] (mass value : ι → ℝ) (M : ℕ)
    (hmass : ∀ i, 0 ≤ mass i) (hvalue : ∀ i, 0 ≤ value i) :
    0 ≤ atomicMoment mass value M :=
  Finset.sum_nonneg (fun i _ => mul_nonneg (hmass i) (pow_nonneg (hvalue i) M))

/-- Absolute sum of the actual residual, including the complete Poisson tail. -/
theorem poissonMixture_defect_residual_sum {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    (mass₀ value₀ : ι₀ → ℝ) (mass₁ value₁ : ι₁ → ℝ)
    (θ : ℝ) (M r : ℕ)
    (hm₀ : ∀ i, 0 ≤ mass₀ i) (hv₀ : ∀ i, 0 ≤ value₀ i)
    (hm₁ : ∀ i, 0 ≤ mass₁ i) (hv₁ : ∀ i, 0 ≤ value₁ i) (hθ : 0 ≤ θ)
    (hr : r < M)
    (hmatch : ∀ m : ℕ, m < M → m ≠ r →
      atomicMoment mass₁ value₁ m = atomicMoment mass₀ value₀ m) :
    (∑' j : ℕ, |(poissonMixture mass₁ value₁ θ j - poissonMixture mass₀ value₀ θ j) -
      poissonDefectTerm θ (atomicMoment mass₁ value₁ r - atomicMoment mass₀ value₀ r) r j|) ≤
      (2 * θ) ^ M * (atomicMoment mass₁ value₁ M + atomicMoment mass₀ value₀ M) /
        (M.factorial : ℝ) := by
  let R := fun j : ℕ => |(poissonMixture mass₁ value₁ θ j - poissonMixture mass₀ value₀ θ j) -
    poissonDefectTerm θ (atomicMoment mass₁ value₁ r - atomicMoment mass₀ value₀ r) r j|
  let H := θ ^ M * (atomicMoment mass₁ value₁ M + atomicMoment mass₀ value₀ M)
  have hR : Summable R := poissonMixture_defect_remainder_summable mass₀ value₀ mass₁ value₁ θ r hv₀ hv₁ hθ
  have hq₀ := (summable_nat_add_iff M).mpr (poissonMixture_hasSum mass₀ value₀ θ hv₀ hθ).summable
  have hq₁ := (summable_nat_add_iff M).mpr (poissonMixture_hasSum mass₁ value₁ θ hv₁ hθ).summable
  have htailpoint (j : ℕ) : R (j + M) ≤
      poissonMixture mass₁ value₁ θ (j + M) + poissonMixture mass₀ value₀ θ (j + M) := by
    have hnot : ¬ j + M ≤ r := by omega
    dsimp only [R]
    simp only [poissonDefectTerm, if_neg hnot, sub_zero]
    have h := abs_sub (poissonMixture mass₁ value₁ θ (j + M)) (poissonMixture mass₀ value₀ θ (j + M))
    simpa only [abs_of_nonneg (poissonMixture_nonneg mass₀ value₀ θ (j + M) hm₀ hv₀ hθ),
      abs_of_nonneg (poissonMixture_nonneg mass₁ value₁ θ (j + M) hm₁ hv₁ hθ)] using h
  have htail : (∑' j : ℕ, R (j + M)) ≤ H / (M.factorial : ℝ) := by
    have hle := ((summable_nat_add_iff M).mpr hR).tsum_le_tsum htailpoint (hq₁.add hq₀)
    rw [hq₁.tsum_add hq₀] at hle
    calc
      _ ≤ _ := hle
      _ ≤ θ ^ M * atomicMoment mass₁ value₁ M / (M.factorial : ℝ) +
          θ ^ M * atomicMoment mass₀ value₀ M / (M.factorial : ℝ) :=
        add_le_add (poissonMixture_tail_bound mass₁ value₁ θ M hm₁ hv₁ hθ)
          (poissonMixture_tail_bound mass₀ value₀ θ M hm₀ hv₀ hθ)
      _ = H / (M.factorial : ℝ) := by dsimp [H]; ring
  have hlow : (∑ j ∈ Finset.range M, R j) ≤
      H * ∑ j ∈ Finset.range M, 1 / ((j.factorial : ℝ) * (M - j).factorial) := by
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro j hj
    have h := poissonMixture_defect_remainder_lt mass₀ value₀ mass₁ value₁ θ M r j
      hm₀ hv₀ hm₁ hv₁ hθ hr (Finset.mem_range.mp hj) hmatch
    simpa only [R, H, mul_one_div] using h
  have hsumcoeff := reciprocal_factorial_sum M
  rw [Finset.sum_range_succ] at hsumcoeff
  simp only [Nat.sub_self, Nat.factorial_zero, Nat.cast_one, mul_one] at hsumcoeff
  change (∑' j : ℕ, R j) ≤ _
  rw [← hR.sum_add_tsum_nat_add M]
  calc
    _ ≤ H * (∑ j ∈ Finset.range M, 1 / ((j.factorial : ℝ) * (M - j).factorial)) +
        H / (M.factorial : ℝ) := add_le_add hlow htail
    _ = H * ((2 : ℝ) ^ M / (M.factorial : ℝ)) := by
      rw [← hsumcoeff]
      ring
    _ = _ := by dsimp [H]; rw [mul_pow]; ring

/-- The defect contribution after division by the actual count probability. -/
theorem poissonDefect_energy_bound {θ Δ ρ D c q : ℝ} {r j : ℕ}
    (hθ : 0 < θ) (_hρ : 0 ≤ ρ) (hD : 0 < D) (hc : 0 < c)
    (hjr : j ≤ r) (hΔ : |Δ| ≤ ρ * D)
    (hq : 2 * c * θ ^ r * D / (j.factorial : ℝ) ≤ q) :
    (poissonDefectTerm θ Δ r j) ^ 2 / q ≤
      (θ ^ r * ρ ^ 2 * D / (2 * c)) *
        (1 / ((j.factorial : ℝ) * ((r - j).factorial : ℝ) ^ 2)) := by
  have hqmin : 0 < 2 * c * θ ^ r * D / (j.factorial : ℝ) := by positivity
  have hΔsq : Δ ^ 2 ≤ ρ ^ 2 * D ^ 2 := by
    have habs : 0 ≤ |Δ| := abs_nonneg Δ
    nlinarith [sq_abs Δ]
  have hsign : ((-1 : ℝ) ^ (r - j)) ^ 2 = 1 := by
    rw [← sq_abs]
    simp [abs_pow]
  have hscale : 0 ≤ θ ^ r /
      (2 * c * D * (j.factorial : ℝ) * ((r - j).factorial : ℝ) ^ 2) := by positivity
  calc
    (poissonDefectTerm θ Δ r j) ^ 2 / q ≤
        (poissonDefectTerm θ Δ r j) ^ 2 /
          (2 * c * θ ^ r * D / (j.factorial : ℝ)) :=
      div_le_div_of_nonneg_left (sq_nonneg _) hqmin hq
    _ = (θ ^ r / (2 * c * D * (j.factorial : ℝ) * ((r - j).factorial : ℝ) ^ 2)) * Δ ^ 2 := by
      simp only [poissonDefectTerm, if_pos hjr, div_pow, mul_pow, hsign, one_mul]
      field_simp
    _ ≤ (θ ^ r / (2 * c * D * (j.factorial : ℝ) * ((r - j).factorial : ℝ) ^ 2)) *
        (ρ ^ 2 * D ^ 2) := mul_le_mul_of_nonneg_left hΔsq hscale
    _ = _ := by field_simp

def countDistanceTerm (q₀ q₁ : ℕ → ℝ) (j : ℕ) : ℝ :=
  if j = 0 then 0 else (q₁ j - q₀ j) ^ 2 / (q₁ j + q₀ j)

def countDistance (q₀ q₁ : ℕ → ℝ) : ℝ := ∑' j : ℕ, countDistanceTerm q₀ q₁ j

theorem countDistanceTerm_le_sum (q₀ q₁ : ℕ → ℝ) (j : ℕ)
    (h₀ : 0 ≤ q₀ j) (h₁ : 0 ≤ q₁ j) :
    countDistanceTerm q₀ q₁ j ≤ q₁ j + q₀ j := by
  unfold countDistanceTerm
  split_ifs
  · positivity
  · by_cases hq : q₁ j + q₀ j = 0
    · simp [hq]
    · apply (div_le_iff₀ (lt_of_le_of_ne (add_nonneg h₁ h₀) (Ne.symm hq))).2
      nlinarith [mul_nonneg h₀ h₁]

theorem countDistanceTerm_summable (q₀ q₁ : ℕ → ℝ)
    (hs₀ : Summable q₀) (hs₁ : Summable q₁)
    (h₀ : ∀ j, 0 ≤ q₀ j) (h₁ : ∀ j, 0 ≤ q₁ j) :
    Summable (countDistanceTerm q₀ q₁) := by
  apply Summable.of_nonneg_of_le _ (fun j => countDistanceTerm_le_sum q₀ q₁ j (h₀ j) (h₁ j)) (hs₁.add hs₀)
  intro j
  unfold countDistanceTerm
  split_ifs
  · exact le_rfl
  · exact div_nonneg (sq_nonneg _) (add_nonneg (h₁ j) (h₀ j))

/-- A general distance decomposition with an absolutely summable residual. -/
theorem countDistance_le_defect_residual (q₀ q₁ a : ℕ → ℝ)
    (hs₀ : Summable q₀) (hs₁ : Summable q₁)
    (h₀ : ∀ j, 0 ≤ q₀ j) (h₁ : ∀ j, 0 ≤ q₁ j)
    (ha : Summable (fun j => if j = 0 then 0 else a j ^ 2 / (q₁ j + q₀ j)))
    (hR : Summable (fun j => |q₁ j - q₀ j - a j|)) :
    countDistance q₀ q₁ ≤
      2 * (∑' j, if j = 0 then 0 else a j ^ 2 / (q₁ j + q₀ j)) +
      2 * (∑' j, |q₁ j - q₀ j - a j|) := by
  let E := fun j => if j = 0 then 0 else a j ^ 2 / (q₁ j + q₀ j)
  have hp (j : ℕ) : countDistanceTerm q₀ q₁ j ≤ 2 * E j + 2 * |q₁ j - q₀ j - a j| := by
    by_cases hj : j = 0
    · simp [countDistanceTerm, E, hj]
    · simp only [countDistanceTerm, E, if_neg hj]
      by_cases hq : q₁ j + q₀ j = 0
      · simp [hq]
      · have hqpos : 0 < q₁ j + q₀ j := lt_of_le_of_ne (add_nonneg (h₁ j) (h₀ j)) (Ne.symm hq)
        have habs : |a j + (q₁ j - q₀ j - a j)| ≤ q₁ j + q₀ j := by
          have hh := abs_sub (q₁ j) (q₀ j)
          simp only [abs_of_nonneg (h₁ j), abs_of_nonneg (h₀ j)] at hh
          convert hh using 1
          congr 1
          ring
        have hh := squared_remainder_bound hqpos habs
        convert hh using 1 <;> ring
  have hh := (countDistanceTerm_summable q₀ q₁ hs₀ hs₁ h₀ h₁).tsum_le_tsum hp
    ((ha.mul_left 2).add (hR.mul_left 2))
  simpa only [countDistance, E, (ha.mul_left 2).tsum_add (hR.mul_left 2),
    tsum_mul_left] using hh

/-- The one-defect count-distance bound for arbitrary finite atomic nonnegative
measures. No normalization is needed. The bound is obtained from actual Poisson
mixtures; the only statistical assumption is the stated positive-count lower bound. -/
theorem poissonMixture_one_defect_distance {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    (mass₀ value₀ : ι₀ → ℝ) (mass₁ value₁ : ι₁ → ℝ)
    (θ ρ D c : ℝ) (M r : ℕ)
    (hm₀ : ∀ i, 0 ≤ mass₀ i) (hv₀ : ∀ i, 0 ≤ value₀ i)
    (hm₁ : ∀ i, 0 ≤ mass₁ i) (hv₁ : ∀ i, 0 ≤ value₁ i)
    (hθ : 0 < θ) (hρ : 0 ≤ ρ) (hD : 0 < D) (hc : 0 < c)
    (hr : r < M)
    (hmatch : ∀ m : ℕ, m < M → m ≠ r →
      atomicMoment mass₁ value₁ m = atomicMoment mass₀ value₀ m)
    (hdefect : |atomicMoment mass₁ value₁ r - atomicMoment mass₀ value₀ r| ≤ ρ * D)
    (hden₀ : ∀ j : ℕ, 1 ≤ j → j ≤ r →
      c * θ ^ r * D / (j.factorial : ℝ) ≤ poissonMixture mass₀ value₀ θ j)
    (hden₁ : ∀ j : ℕ, 1 ≤ j → j ≤ r →
      c * θ ^ r * D / (j.factorial : ℝ) ≤ poissonMixture mass₁ value₁ θ j) :
    countDistance (poissonMixture mass₀ value₀ θ) (poissonMixture mass₁ value₁ θ) ≤
      ((2 : ℝ) ^ r / (c * r.factorial)) * θ ^ r * ρ ^ 2 * D +
      2 * (2 * θ) ^ M * (atomicMoment mass₁ value₁ M + atomicMoment mass₀ value₀ M) /
        (M.factorial : ℝ) := by
  let q₀ := poissonMixture mass₀ value₀ θ
  let q₁ := poissonMixture mass₁ value₁ θ
  let a := poissonDefectTerm θ (atomicMoment mass₁ value₁ r - atomicMoment mass₀ value₀ r) r
  let E := fun j : ℕ => if j = 0 then 0 else (a j) ^ 2 / (q₁ j + q₀ j)
  let C := θ ^ r * ρ ^ 2 * D / (2 * c)
  have hEzero (j : ℕ) (hj : j ∉ Finset.range (r + 1)) : E j = 0 := by
    have hjr : ¬j ≤ r := by simpa only [Finset.mem_range, Nat.lt_succ_iff] using hj
    simp [E, a, poissonDefectTerm, hjr]
  have hE : Summable E := summable_of_ne_finset_zero hEzero
  have hEp (j : ℕ) (hj : j ∈ Finset.range (r + 1)) :
      E j ≤ C * (1 / ((j.factorial : ℝ) * ((r - j).factorial : ℝ) ^ 2)) := by
    have hjr : j ≤ r := by simpa only [Finset.mem_range, Nat.lt_succ_iff] using hj
    by_cases hj0 : j = 0
    · simp only [E, if_pos hj0]
      dsimp [C]
      positivity
    · have hjpos : 1 ≤ j := by omega
      have hd : 2 * c * θ ^ r * D / (j.factorial : ℝ) ≤ q₁ j + q₀ j := by
        have hh := add_le_add (hden₁ j hjpos hjr) (hden₀ j hjpos hjr)
        dsimp [q₀, q₁]
        convert hh using 1
        ring
      simpa only [E, if_neg hj0, a, C] using
        poissonDefect_energy_bound hθ hρ hD hc hjr hdefect hd
  have hEsum : (∑' j, E j) ≤ C * ((2 : ℝ) ^ r / r.factorial) := by
    rw [tsum_eq_sum hEzero]
    calc
      _ ≤ ∑ j ∈ Finset.range (r + 1),
          C * (1 / ((j.factorial : ℝ) * ((r - j).factorial : ℝ) ^ 2)) := Finset.sum_le_sum hEp
      _ = C * (∑ j ∈ Finset.range (r + 1),
          1 / ((j.factorial : ℝ) * ((r - j).factorial : ℝ) ^ 2)) := (Finset.mul_sum _ _ _).symm
      _ ≤ C * ((2 : ℝ) ^ r / r.factorial) :=
        mul_le_mul_of_nonneg_left (reciprocal_factorial_square_sum r) (by dsimp [C]; positivity)
  have hdist := countDistance_le_defect_residual q₀ q₁ a
    (poissonMixture_hasSum mass₀ value₀ θ hv₀ hθ.le).summable
    (poissonMixture_hasSum mass₁ value₁ θ hv₁ hθ.le).summable
    (fun j => poissonMixture_nonneg mass₀ value₀ θ j hm₀ hv₀ hθ.le)
    (fun j => poissonMixture_nonneg mass₁ value₁ θ j hm₁ hv₁ hθ.le)
    hE (poissonMixture_defect_remainder_summable mass₀ value₀ mass₁ value₁ θ r hv₀ hv₁ hθ.le)
  have hres := poissonMixture_defect_residual_sum mass₀ value₀ mass₁ value₁ θ M r
    hm₀ hv₀ hm₁ hv₁ hθ.le hr hmatch
  change countDistance q₀ q₁ ≤ _
  calc
    _ ≤ 2 * (∑' j, E j) + 2 * (∑' j, |q₁ j - q₀ j - a j|) := hdist
    _ ≤ 2 * (C * ((2 : ℝ) ^ r / r.factorial)) +
        2 * ((2 * θ) ^ M * (atomicMoment mass₁ value₁ M + atomicMoment mass₀ value₀ M) /
          (M.factorial : ℝ)) := add_le_add (mul_le_mul_of_nonneg_left hEsum (by norm_num))
            (mul_le_mul_of_nonneg_left hres (by norm_num))
    _ = _ := by dsimp [C]; ring

/-- A finite atomic noninteger power moment. -/
def atomicPowerMoment {ι : Type*} [Fintype ι] (mass value : ι → ℝ) (α : ℝ) : ℝ :=
  ∑ i, mass i * (value i) ^ α

theorem atomicPowerMoment_nonneg {ι : Type*} [Fintype ι] (mass value : ι → ℝ) (α : ℝ)
    (hmass : ∀ i, 0 ≤ mass i) (hvalue : ∀ i, 0 ≤ value i) :
    0 ≤ atomicPowerMoment mass value α :=
  Finset.sum_nonneg (fun i _ => mul_nonneg (hmass i) (Real.rpow_nonneg (hvalue i) α))

/-- Bounded support converts the integer moment into the desired power moment. -/
theorem atomicMoment_le_powerMoment {ι : Type*} [Fintype ι]
    (mass value : ι → ℝ) (M : ℕ) (α B : ℝ)
    (hmass : ∀ i, 0 ≤ mass i) (hvalue : ∀ i, 0 ≤ value i)
    (hbound : ∀ i, value i ≤ B) (hα : 0 ≤ α) (hαM : α ≤ M) :
    atomicMoment mass value M ≤ B ^ ((M : ℝ) - α) * atomicPowerMoment mass value α := by
  unfold atomicMoment atomicPowerMoment
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i _
  have hv : (value i) ^ M = (value i) ^ α * (value i) ^ ((M : ℝ) - α) := by
    rw [← Real.rpow_add_of_nonneg (hvalue i) hα (sub_nonneg.mpr hαM)]
    simp only [add_sub_cancel, Real.rpow_natCast]
  rw [hv]
  have hp := mul_le_mul_of_nonneg_left
    (Real.rpow_le_rpow (hvalue i) (hbound i) (sub_nonneg.mpr hαM))
    (mul_nonneg (hmass i) (Real.rpow_nonneg (hvalue i) α))
  convert hp using 1 <;> ring

/-- The factorial bound needed in the source follows directly from the
nonnegative exponential series; a Stirling approximation is unnecessary. -/
theorem reciprocal_factorial_le_exp (M : ℕ) (hM : 0 < M) :
    1 / (M.factorial : ℝ) ≤ (Real.exp 1 / (M : ℝ)) ^ M := by
  have hcast : (0 : ℝ) < M := by exact_mod_cast hM
  have hfac : (0 : ℝ) < M.factorial := by positivity
  rw [div_pow]
  apply (div_le_div_iff₀ hfac (pow_pos hcast M)).2
  have h := (div_le_iff₀ hfac).mp (Real.pow_div_factorial_le_exp (M : ℝ) hcast.le M)
  simpa only [one_mul, ← Real.exp_nat_mul, mul_one] using h

/-- Exact source-shaped upper bound for the actual Taylor/tail remainder. -/
theorem poissonMixture_remainder_power_bound {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    (mass₀ value₀ : ι₀ → ℝ) (mass₁ value₁ : ι₁ → ℝ)
    (θ α B : ℝ) (M : ℕ)
    (hm₀ : ∀ i, 0 ≤ mass₀ i) (hv₀ : ∀ i, 0 ≤ value₀ i)
    (hm₁ : ∀ i, 0 ≤ mass₁ i) (hv₁ : ∀ i, 0 ≤ value₁ i)
    (hb₀ : ∀ i, value₀ i ≤ B) (hb₁ : ∀ i, value₁ i ≤ B)
    (hθ : 0 ≤ θ) (hα : 0 ≤ α) (hαM : α ≤ M) (hB : 0 < B) (hM : 0 < M) :
    (2 * θ) ^ M * (atomicMoment mass₁ value₁ M + atomicMoment mass₀ value₀ M) /
      (M.factorial : ℝ) ≤
    (atomicPowerMoment mass₁ value₁ α + atomicPowerMoment mass₀ value₀ α) *
      B ^ (-α) * (2 * Real.exp 1 * θ * B / (M : ℝ)) ^ M := by
  let A := atomicPowerMoment mass₁ value₁ α + atomicPowerMoment mass₀ value₀ α
  have hA : 0 ≤ A := add_nonneg
    (atomicPowerMoment_nonneg mass₁ value₁ α hm₁ hv₁)
    (atomicPowerMoment_nonneg mass₀ value₀ α hm₀ hv₀)
  have hmom : atomicMoment mass₁ value₁ M + atomicMoment mass₀ value₀ M ≤
      B ^ ((M : ℝ) - α) * A := by
    have hh := add_le_add
      (atomicMoment_le_powerMoment mass₁ value₁ M α B hm₁ hv₁ hb₁ hα hαM)
      (atomicMoment_le_powerMoment mass₀ value₀ M α B hm₀ hv₀ hb₀ hα hαM)
    simpa only [mul_add, A] using hh
  calc
    _ ≤ ((2 * θ) ^ M * (B ^ ((M : ℝ) - α) * A)) / (M.factorial : ℝ) :=
      div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hmom (by positivity)) (by positivity)
    _ = ((2 * θ) ^ M * (B ^ ((M : ℝ) - α) * A)) * (1 / (M.factorial : ℝ)) := by ring
    _ ≤ ((2 * θ) ^ M * (B ^ ((M : ℝ) - α) * A)) * (Real.exp 1 / (M : ℝ)) ^ M :=
      mul_le_mul_of_nonneg_left (reciprocal_factorial_le_exp M hM) (by positivity)
    _ = _ := by
      rw [Real.rpow_sub hB, Real.rpow_natCast, Real.rpow_neg hB.le]
      simp only [div_pow, mul_pow]
      dsimp [A]
      ring

/-- **Lemma `cal:lem:one-defect`, finite atomic form, with explicit constants.**
The coefficient of the defect term is 1 and the coefficient of the remainder
is 2. Taking `M = L + 2` gives the displayed manuscript bound with `C = 2`.
The finite atomic form applies directly to all interpolating priors in the proof. -/
theorem one_defect_calibration_finite {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    (mass₀ value₀ : ι₀ → ℝ) (mass₁ value₁ : ι₁ → ℝ)
    (θ ρ D c α B : ℝ) (M r : ℕ)
    (hm₀ : ∀ i, 0 ≤ mass₀ i) (hv₀ : ∀ i, 0 ≤ value₀ i)
    (hm₁ : ∀ i, 0 ≤ mass₁ i) (hv₁ : ∀ i, 0 ≤ value₁ i)
    (hb₀ : ∀ i, value₀ i ≤ B) (hb₁ : ∀ i, value₁ i ≤ B)
    (hθ : 0 < θ) (hρ : 0 ≤ ρ) (hD : 0 < D) (hc : 0 < c)
    (hα : 0 ≤ α) (hαM : α ≤ M) (hB : 0 < B) (hr : r < M)
    (hmatch : ∀ m : ℕ, m < M → m ≠ r →
      atomicMoment mass₁ value₁ m = atomicMoment mass₀ value₀ m)
    (hdefect : |atomicMoment mass₁ value₁ r - atomicMoment mass₀ value₀ r| ≤ ρ * D)
    (hden₀ : ∀ j : ℕ, 1 ≤ j → j ≤ r →
      c * θ ^ r * D / (j.factorial : ℝ) ≤ poissonMixture mass₀ value₀ θ j)
    (hden₁ : ∀ j : ℕ, 1 ≤ j → j ≤ r →
      c * θ ^ r * D / (j.factorial : ℝ) ≤ poissonMixture mass₁ value₁ θ j) :
    countDistance (poissonMixture mass₀ value₀ θ) (poissonMixture mass₁ value₁ θ) ≤
      ((2 : ℝ) ^ r / (c * r.factorial)) * θ ^ r * ρ ^ 2 * D +
      2 * (atomicPowerMoment mass₁ value₁ α + atomicPowerMoment mass₀ value₀ α) *
        B ^ (-α) * (2 * Real.exp 1 * θ * B / (M : ℝ)) ^ M := by
  have hd := poissonMixture_one_defect_distance mass₀ value₀ mass₁ value₁ θ ρ D c M r
    hm₀ hv₀ hm₁ hv₁ hθ hρ hD hc hr hmatch hdefect hden₀ hden₁
  have ht := poissonMixture_remainder_power_bound mass₀ value₀ mass₁ value₁ θ α B M
    hm₀ hv₀ hm₁ hv₁ hb₀ hb₁ hθ.le hα hαM hB (by omega)
  have hh := mul_le_mul_of_nonneg_left ht (show (0 : ℝ) ≤ 2 by norm_num)
  apply hd.trans
  apply add_le_add_left
  convert hh using 1 <;> ring

/-- Exact moment matching removes the defect term and all denominator
assumptions, as asserted in the last sentence of `cal:lem:one-defect`. -/
theorem exact_matching_calibration_finite {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    (mass₀ value₀ : ι₀ → ℝ) (mass₁ value₁ : ι₁ → ℝ)
    (θ α B : ℝ) (M : ℕ)
    (hm₀ : ∀ i, 0 ≤ mass₀ i) (hv₀ : ∀ i, 0 ≤ value₀ i)
    (hm₁ : ∀ i, 0 ≤ mass₁ i) (hv₁ : ∀ i, 0 ≤ value₁ i)
    (hb₀ : ∀ i, value₀ i ≤ B) (hb₁ : ∀ i, value₁ i ≤ B)
    (hθ : 0 < θ) (hα : 0 ≤ α) (hαM : α ≤ M) (hB : 0 < B) (hM : 0 < M)
    (hmatch : ∀ m : ℕ, m < M →
      atomicMoment mass₁ value₁ m = atomicMoment mass₀ value₀ m) :
    countDistance (poissonMixture mass₀ value₀ θ) (poissonMixture mass₁ value₁ θ) ≤
      2 * (atomicPowerMoment mass₁ value₁ α + atomicPowerMoment mass₀ value₀ α) *
        B ^ (-α) * (2 * Real.exp 1 * θ * B / (M : ℝ)) ^ M := by
  have hh := one_defect_calibration_finite mass₀ value₀ mass₁ value₁ θ 0 1 1 α B M 0
    hm₀ hv₀ hm₁ hv₁ hb₀ hb₁ hθ (by norm_num) (by norm_num) (by norm_num)
    hα hαM hB hM (fun m hm _ => hmatch m hm)
    (by rw [hmatch 0 hM]; simp)
    (fun j hj hj' => by omega) (fun j hj hj' => by omega)
  simpa only [zero_pow (by decide : 2 ≠ 0), mul_zero, zero_mul, zero_add] using hh

end Renyi
