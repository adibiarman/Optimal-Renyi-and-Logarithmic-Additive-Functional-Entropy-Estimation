import Renyi.ActualCoupledPolynomial

/-! Fixed scalar choices for the complete actual upper construction, before alphabet and order. -/
noncomputable section
namespace Renyi

/-- The already proved strict upper property, at one fixed damping choice. -/
def ActualUpperProfileBound (eps fL f M c : ℝ) : Prop  := 
  ∀ (k : ℕ) (alpha Ch D cb lambda CL cL p : ℝ),
        0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 →
        0≤Ch → 0<D → 0<cb → 0<lambda → lambda≤Real.exp (-2*coupledProfileConstant) →
        1≤CL → 0<cL → 1≤cb*CL →
        upperA k alpha eps Ch D cb lambda CL cL≤p → p≤upperB k alpha eps D cb CL cL →
        (actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).eval p≤
          p^alpha*(1-c*min (fractionalPart alpha*(1-fractionalPart alpha)+
            (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2*(p/upperB k alpha eps D cb CL cL)+
              min ((upperLowResolution alpha:ℝ)^2*(upperA k alpha eps Ch D cb lambda CL cL/p)) 1) 1)

/-- The already proved lower property, with constants independent of all later parameters. -/
def ActualLowerProfileBound (eps fL f lambda M C c : ℝ) : Prop  := 
  ∀ (k : ℕ) (alpha Ch D cb CL cL p : ℝ),
      0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 →
      0≤Ch → 0<D → 0<cb → 1≤CL → 0<cL → 1≤cb*CL →
      upperA k alpha eps Ch D cb lambda CL cL≤p → p≤upperB k alpha eps D cb CL cL →
      p^alpha*(Real.exp (-upperE0 k alpha eps Ch)*Real.exp (-C*(fractionalPart alpha*(1-fractionalPart alpha)))+
        c*Real.exp (-upperE0 k alpha eps Ch)*
          min ((upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2*(p/upperB k alpha eps D cb CL cL)) 1)≤
        (actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).eval p

/-- One consistent fixed design, including proved bounds for the actual polynomial. -/
structure UpperProfileDesign (eps : ℝ) where
  fL : ℝ
  f : ℝ
  qL : ℝ
  qH : ℝ
  lambda : ℝ
  M : ℝ
  upperMargin : ℝ
  lowerLoss : ℝ
  lowerGain : ℝ
  Ch : ℝ
  cu : ℝ
  u0 : ℝ
  fL_pos : 0<fL
  fL_lt_one : fL<1
  f_pos : 0<f
  f_lt_one : f<1
  qL_pos : 0<qL
  qL_lt_fL : qL<fL
  qL_floor : Real.exp (-(eps/2))<qL
  qH_pos : 0<qH
  qH_lt_f : qH<f
  qH_floor : Real.exp (-7*(eps/2)/8)<qH
  lambda_pos : 0<lambda
  lambda_bound : lambda≤Real.exp (-2*coupledProfileConstant)
  one_le_M : 1≤M
  upperMargin_pos : 0<upperMargin
  lowerLoss_nonneg : 0≤lowerLoss
  lowerGain_pos : 0<lowerGain
  reserve_bound : 2*lowerLoss+2≤Ch
  cu_pos : 0<cu
  cu_bound : cu≤min 1 (eps/4)/2
  u0_eq_one : u0=1
  upper_bound : ActualUpperProfileBound eps fL f M upperMargin
  lower_bound : ActualLowerProfileBound eps fL f lambda M lowerLoss lowerGain

/-- All scalar choices precede k, alpha, the sample multiplier, and the pilot/degree choices. -/
theorem upperProfileDesign_exists {eps : ℝ} (heps : 0<eps) : Nonempty (UpperProfileDesign eps)  :=  by
  let rL  :=  Real.exp (-(eps/2))
  let rH  :=  Real.exp (-7*(eps/2)/8)
  let qL  :=  (1+rL)/2
  let qH  :=  (1+rH)/2
  let fL  :=  (1+qL)/2
  let f  :=  (1+qH)/2
  let lambda  :=  Real.exp (-2*coupledProfileConstant)/2
  have hrL : 0<rL  :=  Real.exp_pos _
  have hrL1 : rL<1  :=  Real.exp_lt_one_iff.mpr (by linarith only [heps])
  have hrH : 0<rH  :=  Real.exp_pos _
  have hrH1 : rH<1  :=  Real.exp_lt_one_iff.mpr (by linarith only [heps])
  have hqL : rL<qL  :=  by dsimp [qL];linarith only [hrL1]
  have hqL1 : qL<1  :=  by dsimp [qL];linarith only [hrL1]
  have hqH : rH<qH  :=  by dsimp [qH];linarith only [hrH1]
  have hqH1 : qH<1  :=  by dsimp [qH];linarith only [hrH1]
  have hfL : 0<fL  :=  by dsimp [fL,qL];linarith only [hrL]
  have hfL1 : fL<1  :=  by dsimp [fL];linarith only [hqL1]
  have hqLf : qL<fL  :=  by dsimp [fL];linarith only [hqL1]
  have hf : 0<f  :=  by dsimp [f,qH];linarith only [hrH]
  have hf1 : f<1  :=  by dsimp [f];linarith only [hqH1]
  have hqHf : qH<f  :=  by dsimp [f];linarith only [hqH1]
  have hlam : 0<lambda  :=  by dsimp [lambda];positivity
  have hlamC : lambda≤Real.exp (-2*coupledProfileConstant)  :=  by
    dsimp [lambda]
    linarith only [Real.exp_pos (-2*coupledProfileConstant)]
  obtain ⟨M,cU,hM,hcU,hupper⟩  :=  actualCoupledPolynomial_strict_upper heps hfL hfL1 hf.le hf1
  obtain ⟨C,cL,hC,hcL,hlower⟩  :=  actualCoupledPolynomial_global_lower
    heps hfL hfL1 hf hf1 hM hlam hlamC hqL hqLf hqH hqHf
  refine ⟨{
    fL := fL, f := f, qL := qL, qH := qH, lambda := lambda, M := M,
    upperMargin := cU, lowerLoss := C, lowerGain := cL, Ch := 2*C+2,
    cu := min 1 (eps/4)/2, u0 := 1,
    fL_pos := hfL, fL_lt_one := hfL1, f_pos := hf, f_lt_one := hf1,
    qL_pos := hrL.trans hqL, qL_lt_fL := hqLf, qL_floor := hqL,
    qH_pos := hrH.trans hqH, qH_lt_f := hqHf, qH_floor := hqH,
    lambda_pos := hlam, lambda_bound := hlamC, one_le_M := hM,
    upperMargin_pos := hcU, lowerLoss_nonneg := hC, lowerGain_pos := hcL,
    reserve_bound := le_refl _, cu_pos := by positivity, cu_bound := le_refl _,
    u0_eq_one := rfl, upper_bound := hupper M (le_refl M), lower_bound := hlower }⟩


/-- Further decreasing the common rescaling coefficient preserves the fixed polynomial design. -/
def UpperProfileDesign.withCu {eps : ℝ} (design : UpperProfileDesign eps)
    (cu : ℝ) (hcu : 0<cu) (hbound : cu≤design.cu) : UpperProfileDesign eps :=
  { design with cu := cu, cu_pos := hcu, cu_bound := hbound.trans design.cu_bound }

@[simp] theorem UpperProfileDesign.withCu_cu {eps : ℝ} (design : UpperProfileDesign eps)
    (cu : ℝ) (hcu : 0<cu) (hbound : cu≤design.cu) :
    (design.withCu cu hcu hbound).cu=cu := rfl


theorem UpperProfileDesign.Ch_nonneg {eps : ℝ} (design : UpperProfileDesign eps) : 0≤design.Ch := by
  have hC := design.lowerLoss_nonneg
  have hCh := design.reserve_bound
  linarith only [hC,hCh]

theorem UpperProfileDesign.cu_le_one {eps : ℝ} (design : UpperProfileDesign eps) : design.cu≤1 := by
  have hh := design.cu_bound
  have hm : min 1 (eps/4)≤1 := min_le_left _ _
  linarith only [hh,hm]

/-- Compatibility with any prescribed positive heavy margin can be imposed before all model choices. -/
theorem upperProfileDesign_heavy_compatible {eps c : ℝ} (heps : 0<eps) (hc : 0<c) :
    ∃ design : UpperProfileDesign eps, design.cu*design.u0*(2+c)≤c := by
  obtain ⟨design⟩ := upperProfileDesign_exists heps
  let cu := min design.cu (c/(2+c))
  have hden : 0<2+c := by linarith only [hc]
  have hcu : 0<cu := lt_min design.cu_pos (div_pos hc hden)
  let design' := design.withCu cu hcu (min_le_left _ _)
  refine ⟨design',?_⟩
  change cu*design.u0*(2+c)≤c
  rw [design.u0_eq_one,mul_one]
  exact (le_div_iff₀ hden).mp (min_le_right _ _)


/-- A later, larger reserve choice preserves every fixed profile and polynomial bound. -/
def UpperProfileDesign.withCh {eps : ℝ} (design : UpperProfileDesign eps)
    (Ch : ℝ) (hbound : design.Ch≤Ch) : UpperProfileDesign eps :=
  { design with Ch := Ch, reserve_bound := design.reserve_bound.trans hbound }

@[simp] theorem UpperProfileDesign.withCh_Ch {eps : ℝ} (design : UpperProfileDesign eps)
    (Ch : ℝ) (hbound : design.Ch≤Ch) : (design.withCh Ch hbound).Ch=Ch := rfl

end Renyi
