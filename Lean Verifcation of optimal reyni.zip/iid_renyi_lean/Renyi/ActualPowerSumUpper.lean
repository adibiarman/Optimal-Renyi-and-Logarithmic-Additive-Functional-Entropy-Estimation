import Renyi.ActualBiasModel
import Renyi.CompletedBelowCutoff

/-! The actual source polynomial retains all summed upper margins for one common damping constant. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- The strict upper reserve for the actual arbitrary light/heavy assignment. -/
def actualUpperReserve {k : ℕ} (p : Simplex k) (light : Fin k→Bool)
    (alpha eps Ch D cb lambda CL cL c : ℝ) : ℝ :=
  c*(∑ i, if light i then if upperA k alpha eps Ch D cb lambda CL cL≤p.mass i then
    (p.mass i)^alpha*min (fractionalPart alpha*(1-fractionalPart alpha)+
      (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2*(p.mass i/upperB k alpha eps D cb CL cL)+
        min ((upperLowResolution alpha:ℝ)^2*(upperA k alpha eps Ch D cb lambda CL cL/p.mass i)) 1) 1 else 0 else 0)+
    (1-Real.exp (-upperE0 k alpha eps Ch/8))*(∑ i, if light i then 0 else (p.mass i)^alpha)

/-- The actual source polynomial's entire below-cutoff contribution has a fixed
exponential bound, including the prescribed degree-one completion. -/
theorem actualCoupledPolynomial_below_cutoff_exponential
    {k : ℕ} {alpha eps Ch D cb lambda CL cL fL f M p : ℝ}
    (hk : 0<k) (ha : 3/2≤alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (heps : 0<eps) (hCh : 0≤Ch) (hD : 0<D) (hcb : 0<cb) (hlambda : 0<lambda)
    (hlambdaC : lambda≤Real.exp (-2*coupledProfileConstant)) (hCL : 1≤CL) (hcL : 0<cL)
    (hcbCL : 1≤cb*CL) (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hM : 0≤M) (hp : 0≤p) (hpa : p≤upperA k alpha eps Ch D cb lambda CL cL) :
    |(actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).eval p|+p^alpha≤
      100^(upperOrderFloor alpha+1)*(upperA k alpha eps Ch D cb lambda CL cL)^alpha := by
  have ha1 : 1<alpha := by linarith only [ha]
  have hgeom := upper_actual_count_geometry hk ha hg hg1 heps hCh hD hcb hlambda
    (by linarith only [coupled_capacity_lambda_le_one hlambdaC] : lambda≤4) hCL hcL hcbCL
  dsimp only at hgeom
  have hE : 0<upperE0 k alpha eps Ch := (mul_pos heps (sub_pos.mpr ha1)).trans_le
    (upper_reserved_interval (k:=k) ha1 hg hg1 heps hCh).1
  have hz := upperOverlapZ_spec hg hg1 hE
  have hweights := overlap_coefficients_unit hg hg1 hz.1.1 hz.1.2
  let z := upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)
  let A := overlapA (fractionalPart alpha) z*Real.exp (-M*fractionalPart alpha)
  let B := overlapB (fractionalPart alpha) z*Real.exp (-M*(1-fractionalPart alpha))
  have hA : 0≤A := mul_nonneg hweights.1.le (Real.exp_pos _).le
  have hB : 0≤B := mul_nonneg hweights.2.2.1.le (Real.exp_pos _).le
  have hA1 : A≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hweights.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hg]))
  have hB1 : B≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hweights.2.2.2.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hg1]))
  have hh := completedCoupledPolynomial_below_cutoff_exponential hgeom.2.2.2.1
    (by omega : 0<upperDegree alpha CL cL (rootMultiplier k alpha eps))
    (upperOrderFloor_one_le ha1) hgeom.2.2.2.2.2.2.1 hg hg1 hgeom.1 hgeom.2.1 hp hpa
    (DegreeOneCompletion.coefficient_spec hg hfL1).1 hfL.le hfL1 hf hf1
    hA hA1 hB hB1 (Real.exp_pos _).le (Real.exp_lt_one_iff.mpr (by linarith only [hE] : -upperE0 k alpha eps Ch/8<0))
  have halpha : (upperOrderFloor alpha:ℝ)+fractionalPart alpha=alpha := by
    rw [fractionalPart_eq_upperOrderFloor ha1]
    ring
  simpa only [actualCoupledPolynomial,halpha,A,B,z] using hh

/-- One sufficiently large damping coefficient works for the actual finite sum
and keeps every light and heavy strict upper reserve. -/
theorem actualCoupledPolynomial_power_sum_upper {eps fL f : ℝ}
    (heps : 0<eps) (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) :
    ∃ M0 c : ℝ, 1≤M0 ∧ 0<c ∧ ∀ (M : ℝ), M0≤M →
      ∀ (k : ℕ) (alpha Ch D cb lambda CL cL : ℝ),
        0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 →
        0≤Ch → 0<D → 0<cb → 0<lambda → lambda≤Real.exp (-2*coupledProfileConstant) →
        1≤CL → 0<cL → 1≤cb*CL →
        ∀ (p : Simplex k) (light : Fin k→Bool),
          (∀ i, light i=true → p.mass i≤upperB k alpha eps D cb CL cL) →
        actualCoupledHybridMean p light alpha eps Ch D cb lambda CL cL fL f M+
          actualUpperReserve p light alpha eps Ch D cb lambda CL cL c≤powerSum p alpha+
            (k:ℝ)*100^(upperOrderFloor alpha+1)*(upperA k alpha eps Ch D cb lambda CL cL)^alpha := by
  obtain ⟨M0,c,hM0,hc,hupper⟩ := actualCoupledPolynomial_strict_upper heps hfL hfL1 hf hf1
  refine ⟨M0,c,hM0,hc,?_⟩
  intro M hM k alpha Ch D cb lambda CL cL hk ha hg hg1 hCh hD hcb hlambda hlambdaC hCL hcL hcbCL p light hlight
  let Q := actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M
  let err := 100^(upperOrderFloor alpha+1)*(upperA k alpha eps Ch D cb lambda CL cL)^alpha
  let a := upperA k alpha eps Ch D cb lambda CL cL
  let b := upperB k alpha eps D cb CL cL
  let N := upperDegree alpha CL cL (rootMultiplier k alpha eps)
  let ell := upperLowResolution alpha
  let gamma := fractionalPart alpha
  let omega := Real.exp (-upperE0 k alpha eps Ch/8)
  have ha0 : 0≤a := (upper_actual_count_geometry hk ha hg hg1 heps hCh hD hcb hlambda
    (by linarith only [coupled_capacity_lambda_le_one hlambdaC] : lambda≤4) hCL hcL hcbCL).1.le
  have herr : 0≤err := by dsimp [err]; positivity
  have hpoint (i : Fin k) :
      (if light i then Q.eval (p.mass i) else omega*(p.mass i)^alpha)+
        c*(if light i then if a≤p.mass i then (p.mass i)^alpha*
          min (gamma*(1-gamma)+(N:ℝ)^2*(p.mass i/b)+min ((ell:ℝ)^2*(a/p.mass i)) 1) 1 else 0 else 0)+
        (1-omega)*(if light i then 0 else (p.mass i)^alpha)≤(p.mass i)^alpha+err := by
    by_cases hl : light i=true
    · by_cases hpa : a≤p.mass i
      · have hi := hupper M hM k alpha Ch D cb lambda CL cL (p.mass i)
          hk ha hg hg1 hCh hD hcb hlambda hlambdaC hCL hcL hcbCL hpa (hlight i hl)
        change Q.eval (p.mass i)≤(p.mass i)^alpha*
          (1-c*min (gamma*(1-gamma)+(N:ℝ)^2*(p.mass i/b)+min ((ell:ℝ)^2*(a/p.mass i)) 1) 1) at hi
        simp only [hl,hpa,ite_true,mul_zero,add_zero]
        nlinarith only [hi,herr]
      · have hi := actualCoupledPolynomial_below_cutoff_exponential hk ha hg hg1 heps hCh hD hcb hlambda hlambdaC hCL hcL hcbCL
          hfL hfL1 hf hf1.le (by linarith only [hM0,hM] : 0≤M) (p.nonneg i) (le_of_lt (lt_of_not_ge hpa))
        change |Q.eval (p.mass i)|+(p.mass i)^alpha≤err at hi
        have habs := le_abs_self (Q.eval (p.mass i))
        have hpα := Real.rpow_nonneg (p.nonneg i) alpha
        simp only [hl,hpa,ite_true,ite_false,mul_zero,add_zero]
        linarith only [hi,habs,hpα]
    · have hl' : light i=false := Bool.eq_false_iff.mpr hl
      simp only [hl',Bool.false_eq_true,ite_false,mul_zero,add_zero]
      nlinarith only [herr]
  have hsum := Finset.sum_le_sum (fun (i:Fin k) (_hi:i∈Finset.univ) => hpoint i)
  simpa only [actualCoupledHybridMean,actualUpperReserve,powerSum,Finset.sum_add_distrib,
    Finset.mul_sum,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,
    Q,err,a,b,N,ell,gamma,omega,mul_assoc,add_assoc] using hsum

end Renyi
