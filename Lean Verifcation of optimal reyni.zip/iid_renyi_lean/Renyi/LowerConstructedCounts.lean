import Renyi.LowerPriorCounts

/-! Calibrated Chebyshev priors retaining their full count and moment data. -/
noncomputable section
open scoped BigOperators
namespace Renyi

def lowerPositiveCountConclusion (r L : ℕ) (s E w c a θ : ℝ) : Prop :=
    let ζ := c * w / (1 - Real.exp (-E))
    let κ := Real.exp (-E - 4 * w)
    let ξ := 1 - s
    let ns := r - 1
    let nc := L - r
    let bs := (ζ / 8) / ((ns : ℝ) + 1) ^ 2
    let bc := ξ / ((nc : ℝ) + 1) ^ 2
    let ac := Real.exp (-5) * bc * (ζ * κ) ^ (1 / ξ)
    let ρ := max (((a / bs) ^ s / κ) *
      Real.exp (4 * ζ * (ns : ℝ) / ((ns : ℝ) + 1)) - 1) 0
    let us := chebyshevNode ns bs
    let uc := chebyshevNode nc bc
    let α := (r:ℝ)+s
    let l := normalizedInterpolation us a ρ s
    let t := normalizedInterpolation uc ac 0 (1-s)
    let U := interpolationNodes us a
    let V := interpolationNodes uc ac
    let Rs := ∑ i, negativeCoeff (l i)
    let Rc := ∑ j, negativeCoeff (t j)
    let B := (a*ac)⁻¹
    let Z := tensorNormalizer l t U V a α
    let D := B^((r:ℝ)-1)/Z*(a^(-s)*ac⁻¹/(interpolationNormalizer us a ρ s*interpolationNormalizer uc ac 0 (1-s)))
    0<Z ∧ 0<D ∧ ∃ p₀ p₁ : FiniteAtomicPrior
      (Option ((Option (Fin ((r-1)+1))) × (Option (Fin ((L-r)+1))))),
      (∀ i, p₀.value i=0 ∨ (1≤p₀.value i ∧ p₀.value i≤B)) ∧
      (∀ i, p₁.value i=0 ∨ (1≤p₁.value i ∧ p₁.value i≤B)) ∧
      priorMoment p₀ 1=1 ∧ priorMoment p₁ 1=1 ∧
      (∀ j : ℕ, 1≤j → j≤L+1 → j≠r → priorMoment p₁ (j:ℝ)=priorMoment p₀ (j:ℝ)) ∧
      priorMoment p₁ α=B^(α-1)/Z*(1+Rs*Rc) ∧
      priorMoment p₀ α=B^(α-1)/Z*(Rs+Rc) ∧
      Real.log (priorMoment p₁ α/priorMoment p₀ α)=Real.log ((1+Rs*Rc)/(Rs+Rc)) ∧
      (∀ j : ℝ, 0<j → priorMoment p₀ j=B^(j-1)/Z*(∑ ij, tensorNegative l t ij*tensorAtom U V a ij^(j-α))) ∧
      (∀ j : ℝ, 0<j → priorMoment p₁ j=B^(j-1)/Z*(∑ ij, tensorPositive l t ij*tensorAtom U V a ij^(j-α))) ∧
      |priorMoment p₁ (r:ℝ)-priorMoment p₀ (r:ℝ)|≤ρ*D ∧
      (∀ j : ℕ, j≤r → Real.exp (-1)*θ^r*D/(j.factorial:ℝ)≤poissonMixture p₀.mass p₀.value θ j) ∧
      (∀ j : ℕ, j≤r → Real.exp (-1)*θ^r*D/(j.factorial:ℝ)≤poissonMixture p₁.mass p₁.value θ j) ∧
      E+w≤Real.log (priorMoment p₁ α/priorMoment p₀ α) ∧ Rs≤κ ∧ Rc≤ζ*κ

theorem positive_sign_constructed_count_priors (r L : ℕ) (s E w c a θ : ℝ)
    (hr : 2 ≤ r) (_hL : r ≤ L) (hs₀ : 0 < s) (hs₁ : s ≤ 1 / 2)
    (hE : 0 < E) (hw : 0 < w) (hc₀ : 0 < c) (hc₁ : c ≤ 1 / 2)
    (hζsmall : c * w / (1 - Real.exp (-E)) ≤ 1 / 8) (ha : 0 < a) (hθ : 0≤θ) :
    let ζ := c * w / (1 - Real.exp (-E))
    let κ := Real.exp (-E - 4 * w)
    let ns := r - 1
    let bs := (ζ / 8) / ((ns : ℝ) + 1) ^ 2
    let ρ := max (((a / bs) ^ s / κ) *
      Real.exp (4 * ζ * (ns : ℝ) / ((ns : ℝ) + 1)) - 1) 0
    a≤bs/2 → ρ*a/bs≤ζ → θ/a≤1 →
    lowerPositiveCountConclusion r L s E w c a θ := by
  dsimp only
  let ζ := c * w / (1 - Real.exp (-E))
  let κ := Real.exp (-E - 4 * w)
  let ξ := 1 - s
  let ns := r - 1
  let nc := L - r
  let bs := (ζ / 8) / ((ns : ℝ) + 1) ^ 2
  let bc := ξ / ((nc : ℝ) + 1) ^ 2
  let ac := Real.exp (-5) * bc * (ζ * κ) ^ (1 / ξ)
  let ρ := max (((a / bs) ^ s / κ) *
    Real.exp (4 * ζ * (ns : ℝ) / ((ns : ℝ) + 1)) - 1) 0
  intro ha_small hpert hsmall
  dsimp only [lowerPositiveCountConclusion]
  change a ≤ bs / 2 at ha_small
  change ρ * a / bs ≤ ζ at hpert
  have hζ₀ : 0 < ζ := by
    apply div_pos (mul_pos hc₀ hw)
    apply sub_pos.mpr
    exact Real.exp_lt_one_iff.mpr (by linarith)
  have hζ₁ : ζ ≤ 1 / 8 := hζsmall
  have hκ₀ : 0 < κ := Real.exp_pos _
  have hκ₁ : κ ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
  have hξ₀ : 1 / 2 ≤ ξ := by dsimp [ξ]; linarith
  have hξ₁ : ξ < 1 := by dsimp [ξ]; linarith
  have hξpos : 0 < ξ := by linarith
  have hz₀ : 0 < ζ * κ := mul_pos hζ₀ hκ₀
  have hz₁ : ζ * κ ≤ 1 := by
    have hh := mul_le_mul_of_nonneg_left hκ₁ hζ₀.le
    nlinarith
  have hns : 0 < ns := by dsimp [ns]; omega
  have hbs₀ : 0 < bs := by dsimp [bs]; positivity
  have hbs₁ : bs < 1 := by
    apply (div_lt_one (by positivity : (0 : ℝ) < ((ns : ℝ) + 1) ^ 2)).mpr
    have hh : (0 : ℝ) ≤ ns := Nat.cast_nonneg _
    nlinarith
  have hbc₀ : 0 < bc := by dsimp [bc]; positivity
  have hbc₁ : bc < 1 := by
    apply (div_lt_one (by positivity : (0 : ℝ) < ((nc : ℝ) + 1) ^ 2)).mpr
    have hh : (0 : ℝ) ≤ nc := Nat.cast_nonneg _
    nlinarith
  have hac₀ : 0 < ac := by dsimp [ac]; positivity
  have hacbc : ac < bc := by
    have hzpow : (ζ * κ) ^ (1 / ξ) ≤ 1 := Real.rpow_le_one hz₀.le hz₁ (by positivity)
    have hh := mul_le_mul_of_nonneg_left hzpow (mul_nonneg (Real.exp_nonneg (-5)) hbc₀.le)
    have he : Real.exp (-5) < 1 := Real.exp_lt_one_iff.mpr (by norm_num)
    dsimp only [ac]
    nlinarith
  have habs : a < bs := by linarith
  have ha₁ : a < 1 := habs.trans hbs₁
  have hac₁ : ac < 1 := hacbc.trans hbc₁
  have hρ : 0 ≤ ρ := le_max_right _ _
  let us := chebyshevNode ns bs
  let uc := chebyshevNode nc bc
  let l := normalizedInterpolation us a ρ s
  let t := normalizedInterpolation uc ac 0 ξ
  let U := interpolationNodes us a
  let V := interpolationNodes uc ac
  let Rs := ∑ i, negativeCoeff (l i)
  let Rc := ∑ i, negativeCoeff (t i)
  have has : ∀ i, a < us i := fun i => habs.trans_le (chebyshevNode_bounds ns bs hbs₁.le i).1
  have hac : ∀ i, ac < uc i := fun i => hacbc.trans_le (chebyshevNode_bounds nc bc hbc₁.le i).1
  have hus₁ : ∀ i, us i ≤ 1 := fun i => (chebyshevNode_bounds ns bs hbs₁.le i).2
  have huc₁ : ∀ i, uc i ≤ 1 := fun i => (chebyshevNode_bounds nc bc hbc₁.le i).2
  have hRs : Rs ≤ κ := (active_interpolation_mass_bound ns ζ a s κ hns hζ₀
    (by linarith) ha ha_small hs₀.le hκ₀ hκ₁ hpert).1
  have hRc : Rc ≤ ζ * κ := by
    have hh := (chebyshev_nodes_weighted nc ξ (ζ * κ) hξ₀ hξ₁ hz₀ hz₁).1
    have he : Real.exp (-ξ) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
    exact hh.trans (by simpa only [one_mul] using mul_le_mul_of_nonneg_right he hz₀.le)
  have hRs₀ : 0 ≤ Rs := Finset.sum_nonneg (fun i _ => le_max_right _ _)
  have hRc₀ : 0 ≤ Rc := Finset.sum_nonneg (fun i _ => le_max_right _ _)
  have hRcpos : 0 < Rc := normalizedInterpolation_negative_mass_pos uc
    (chebyshevNode_strictMono nc bc hbc₁) hac₀ hac (by norm_num)
  have hRpos : 0 < Rs + Rc := add_pos_of_nonneg_of_pos hRs₀ hRcpos
  have hgap := calibrated_parity_entropy_gap hE hw hc₀.le hc₁ hζsmall hRs₀ hRc₀ hRs hRc hRpos
  obtain ⟨hZ,hD,p₀,p₁,hp₀,hp₁,hm₀,hm₁,hmatch,hA₁,hA₀,hlog,hpow₀,hpow₁,hdef,hq₀,hq₁⟩ :=
    positive_tensor_priors_with_counts us uc (chebyshevNode_strictMono ns bs hbs₁)
      (chebyshevNode_strictMono nc bc hbc₁) hr _hL hs₀ (by linarith)
      ha ha₁ hac₀ hac₁ hρ has hus₁ hac huc₁ hθ hsmall
  refine ⟨hZ,hD,p₀,p₁,hp₀,hp₁,hm₀,hm₁,hmatch,hA₁,hA₀,hlog,hpow₀,hpow₁,hdef,hq₀,hq₁,?_,hRs,hRc⟩
  rw [hlog]
  exact hgap

def lowerNegativeCountConclusion (m L : ℕ) (s E w c a θ : ℝ) : Prop :=
    let ζ := c * w / (1 - Real.exp (-E))
    let κ := Real.exp (-E - 4 * w)
    let ξ := 1 - s
    let ns := L - m
    let nc := m - 1
    let bs := (ζ / 8) / ((ns : ℝ) + 1) ^ 2
    let bc := ξ / ((nc : ℝ) + 1) ^ 2
    let ac := Real.exp (-5) * bc * (ζ * κ) ^ (1 / ξ)
    let ρ := max (((a / bs) ^ s / κ) *
      Real.exp (4 * ζ * (ns : ℝ) / ((ns : ℝ) + 1)) - 1) 0
    let us := chebyshevNode ns bs
    let uc := chebyshevNode nc bc
    let α := (m:ℝ)+(1-s)
    let l := normalizedInterpolation uc ac 0 (1-s)
    let t := normalizedInterpolation us a ρ s
    let U := interpolationNodes uc ac
    let V := interpolationNodes us a
    let Rc := ∑ i, negativeCoeff (l i)
    let Rs := ∑ j, negativeCoeff (t j)
    let B := (ac*a)⁻¹
    let Z := tensorNormalizer l t U V ac α
    let D := B^(((m+1:ℕ):ℝ)-1)/Z*(ac^(s-1)/(interpolationNormalizer uc ac 0 (1-s)*interpolationNormalizer us a ρ s))
    0<Z ∧ 0<D ∧ ∃ p₀ p₁ : FiniteAtomicPrior
      (Option ((Option (Fin ((m-1)+1))) × (Option (Fin ((L-m)+1))))),
      (∀ i, p₀.value i=0 ∨ (1≤p₀.value i ∧ p₀.value i≤B)) ∧
      (∀ i, p₁.value i=0 ∨ (1≤p₁.value i ∧ p₁.value i≤B)) ∧
      priorMoment p₀ 1=1 ∧ priorMoment p₁ 1=1 ∧
      (∀ j : ℕ, 1≤j → j≤L+1 → j≠m+1 → priorMoment p₁ (j:ℝ)=priorMoment p₀ (j:ℝ)) ∧
      priorMoment p₁ α=B^(α-1)/Z*(1+Rc*Rs) ∧
      priorMoment p₀ α=B^(α-1)/Z*(Rc+Rs) ∧
      Real.log (priorMoment p₁ α/priorMoment p₀ α)=Real.log ((1+Rc*Rs)/(Rc+Rs)) ∧
      (∀ j : ℝ, 0<j → priorMoment p₀ j=B^(j-1)/Z*(∑ ij, tensorNegative l t ij*tensorAtom U V ac ij^(j-α))) ∧
      (∀ j : ℝ, 0<j → priorMoment p₁ j=B^(j-1)/Z*(∑ ij, tensorPositive l t ij*tensorAtom U V ac ij^(j-α))) ∧
      |priorMoment p₁ ((m+1:ℕ):ℝ)-priorMoment p₀ ((m+1:ℕ):ℝ)|≤ρ*D ∧
      (∀ j : ℕ, j≤m+1 → Real.exp (-1)*θ^(m+1)*D/(j.factorial:ℝ)≤poissonMixture p₀.mass p₀.value θ j) ∧
      (∀ j : ℕ, j≤m+1 → Real.exp (-1)*θ^(m+1)*D/(j.factorial:ℝ)≤poissonMixture p₁.mass p₁.value θ j) ∧
      E+w≤Real.log (priorMoment p₁ α/priorMoment p₀ α) ∧ Rs≤κ ∧ Rc≤ζ*κ

theorem negative_sign_constructed_count_priors (m L : ℕ) (s E w c a θ : ℝ)
    (hm : 1 ≤ m) (hL : m + 1 ≤ L) (hs₀ : 0 < s) (hs₁ : s ≤ 1 / 2)
    (hE : 0 < E) (hw : 0 < w) (hc₀ : 0 < c) (hc₁ : c ≤ 1 / 2)
    (hζsmall : c * w / (1 - Real.exp (-E)) ≤ 1 / 8) (ha : 0 < a) (hθ : 0≤θ) :
    let ζ := c * w / (1 - Real.exp (-E))
    let κ := Real.exp (-E - 4 * w)
    let ξ := 1 - s
    let ns := L - m
    let nc := m - 1
    let bs := (ζ / 8) / ((ns : ℝ) + 1) ^ 2
    let bc := ξ / ((nc : ℝ) + 1) ^ 2
    let ac := Real.exp (-5) * bc * (ζ * κ) ^ (1 / ξ)
    let ρ := max (((a / bs) ^ s / κ) *
      Real.exp (4 * ζ * (ns : ℝ) / ((ns : ℝ) + 1)) - 1) 0
    a≤bs/2 → ρ*a/bs≤ζ → θ*(ac*a)⁻¹*chebyshevNode ns bs 0≤1 →
    lowerNegativeCountConclusion m L s E w c a θ := by
  dsimp only
  let ζ := c * w / (1 - Real.exp (-E))
  let κ := Real.exp (-E - 4 * w)
  let ξ := 1 - s
  let ns := L - m
  let nc := m - 1
  let bs := (ζ / 8) / ((ns : ℝ) + 1) ^ 2
  let bc := ξ / ((nc : ℝ) + 1) ^ 2
  let ac := Real.exp (-5) * bc * (ζ * κ) ^ (1 / ξ)
  let ρ := max (((a / bs) ^ s / κ) *
    Real.exp (4 * ζ * (ns : ℝ) / ((ns : ℝ) + 1)) - 1) 0
  intro ha_small hpert hsmall
  dsimp only [lowerNegativeCountConclusion]
  change a ≤ bs / 2 at ha_small
  change ρ * a / bs ≤ ζ at hpert
  have hζ₀ : 0 < ζ := by
    apply div_pos (mul_pos hc₀ hw)
    apply sub_pos.mpr
    exact Real.exp_lt_one_iff.mpr (by linarith)
  have hζ₁ : ζ ≤ 1 / 8 := hζsmall
  have hκ₀ : 0 < κ := Real.exp_pos _
  have hκ₁ : κ ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
  have hξ₀ : 1 / 2 ≤ ξ := by dsimp [ξ]; linarith
  have hξ₁ : ξ < 1 := by dsimp [ξ]; linarith
  have hξpos : 0 < ξ := by linarith
  have hz₀ : 0 < ζ * κ := mul_pos hζ₀ hκ₀
  have hz₁ : ζ * κ ≤ 1 := by
    have hh := mul_le_mul_of_nonneg_left hκ₁ hζ₀.le
    nlinarith
  have hns : 0 < ns := by dsimp [ns]; omega
  have hbs₀ : 0 < bs := by dsimp [bs]; positivity
  have hbs₁ : bs < 1 := by
    apply (div_lt_one (by positivity : (0 : ℝ) < ((ns : ℝ) + 1) ^ 2)).mpr
    have hh : (0 : ℝ) ≤ ns := Nat.cast_nonneg _
    nlinarith
  have hbc₀ : 0 < bc := by dsimp [bc]; positivity
  have hbc₁ : bc < 1 := by
    apply (div_lt_one (by positivity : (0 : ℝ) < ((nc : ℝ) + 1) ^ 2)).mpr
    have hh : (0 : ℝ) ≤ nc := Nat.cast_nonneg _
    nlinarith
  have hac₀ : 0 < ac := by dsimp [ac]; positivity
  have hacbc : ac < bc := by
    have hzpow : (ζ * κ) ^ (1 / ξ) ≤ 1 := Real.rpow_le_one hz₀.le hz₁ (by positivity)
    have hh := mul_le_mul_of_nonneg_left hzpow (mul_nonneg (Real.exp_nonneg (-5)) hbc₀.le)
    have he : Real.exp (-5) < 1 := Real.exp_lt_one_iff.mpr (by norm_num)
    dsimp only [ac]
    nlinarith
  have habs : a < bs := by linarith
  have ha₁ : a < 1 := habs.trans hbs₁
  have hac₁ : ac < 1 := hacbc.trans hbc₁
  have hρ : 0 ≤ ρ := le_max_right _ _
  let us := chebyshevNode ns bs
  let uc := chebyshevNode nc bc
  let l := normalizedInterpolation uc ac 0 ξ
  let t := normalizedInterpolation us a ρ s
  let U := interpolationNodes uc ac
  let V := interpolationNodes us a
  let Rs := ∑ i, negativeCoeff (t i)
  let Rc := ∑ i, negativeCoeff (l i)
  have has : ∀ i, a < us i := fun i => habs.trans_le (chebyshevNode_bounds ns bs hbs₁.le i).1
  have hac : ∀ i, ac < uc i := fun i => hacbc.trans_le (chebyshevNode_bounds nc bc hbc₁.le i).1
  have hus₁ : ∀ i, us i ≤ 1 := fun i => (chebyshevNode_bounds ns bs hbs₁.le i).2
  have huc₁ : ∀ i, uc i ≤ 1 := fun i => (chebyshevNode_bounds nc bc hbc₁.le i).2
  have hRs : Rs ≤ κ := (active_interpolation_mass_bound ns ζ a s κ hns hζ₀
    (by linarith) ha ha_small hs₀.le hκ₀ hκ₁ hpert).1
  have hRc : Rc ≤ ζ * κ := by
    have hh := (chebyshev_nodes_weighted nc ξ (ζ * κ) hξ₀ hξ₁ hz₀ hz₁).1
    have he : Real.exp (-ξ) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
    exact hh.trans (by simpa only [one_mul] using mul_le_mul_of_nonneg_right he hz₀.le)
  have hRs₀ : 0 ≤ Rs := Finset.sum_nonneg (fun i _ => le_max_right _ _)
  have hRc₀ : 0 ≤ Rc := Finset.sum_nonneg (fun i _ => le_max_right _ _)
  have hRcpos : 0 < Rc := normalizedInterpolation_negative_mass_pos uc
    (chebyshevNode_strictMono nc bc hbc₁) hac₀ hac (by norm_num)
  have hRpos : 0 < Rs + Rc := add_pos_of_nonneg_of_pos hRs₀ hRcpos
  have hgap := calibrated_parity_entropy_gap hE hw hc₀.le hc₁ hζsmall hRs₀ hRc₀ hRs hRc hRpos
  obtain ⟨hZ,hD,p₀,p₁,hp₀,hp₁,hm₀,hm₁,hmatch,hA₁,hA₀,hlog,hpow₀,hpow₁,hdef,hq₀,hq₁⟩ :=
    negative_tensor_priors_with_counts uc us (chebyshevNode_strictMono nc bc hbc₁)
      (chebyshevNode_strictMono ns bs hbs₁) hm (by omega) hs₀ (by linarith)
      hac₀ hac₁ ha ha₁ hρ hac huc₁ has hus₁ hθ hsmall
  refine ⟨hZ,hD,p₀,p₁,hp₀,hp₁,hm₀,hm₁,hmatch,hA₁,hA₀,hlog,hpow₀,hpow₁,hdef,hq₀,hq₁,?_,hRs,hRc⟩
  rw [hlog]
  change E+w≤Real.log ((1+Rc*Rs)/(Rc+Rs))
  rw [mul_comm Rc Rs,add_comm Rc Rs]
  exact hgap

end Renyi
