import Renyi.CoupledNormalizerBounds

/-! Local lower bounds for the actual low and high coupled profiles. -/
noncomputable section
open Set
namespace Renyi

lemma coupledProfile_local_first_lower {N d : ℕ} (hN : 2≤N) (hd : d≤6)
    {s x C : ℝ} {H : ℝ → ℝ} (hs : 0<s) (hs1 : s≤1) (hC : 0<C)
    (hx : 0≤x) (hx1 : x≤1) (hy : (N:ℝ)^2*x≤s)
    (hH : 0≤H x) (ha : 0<coupledNormalizer s (endpointKernel N d) H)
    (hupper : (N:ℝ)^(2*s)*coupledNormalizer s (endpointKernel N d) H≤(C*s)^s) :
    (((N:ℝ)^2*x)/(C*s))^s*Real.exp (-288*s) ≤
      coupledProfile s (endpointKernel N d) H x := by
  have hNp : 0<(N:ℝ)^(2*s) := Real.rpow_pos_of_pos (by exact_mod_cast (show 0<N by omega)) _
  have hCs : 0<C*s := mul_pos hC hs
  have hy0 : 0≤(N:ℝ)^2*x := by positivity
  have hK := endpointKernel_profile_local_lower hN hd hs hs1 hx hx1 hy
  have hfactor : 0≤(((N:ℝ)^2*x)/(C*s))^s*Real.exp (-288*s) := by positivity
  have hprod : (((N:ℝ)^2*x)/(C*s))^s*(C*s)^s=((N:ℝ)^2*x)^s := by
    rw [Real.div_rpow hy0 hCs.le]
    field_simp
  have hnum : (((N:ℝ)^2*x)/(C*s))^s*Real.exp (-288*s)*
      coupledNormalizer s (endpointKernel N d) H ≤ x^s*endpointKernel N d x := by
    apply (mul_le_mul_iff_right₀ hNp).mp
    calc
      _ = ((((N:ℝ)^2*x)/(C*s))^s*Real.exp (-288*s))*
          ((N:ℝ)^(2*s)*coupledNormalizer s (endpointKernel N d) H) := by ring
      _ ≤ ((((N:ℝ)^2*x)/(C*s))^s*Real.exp (-288*s))*(C*s)^s :=
        mul_le_mul_of_nonneg_left hupper hfactor
      _ = ((N:ℝ)^2*x)^s*Real.exp (-288*s) := by rw [mul_right_comm _ _ ((C*s)^s),hprod]
      _ ≤ ((N:ℝ)^2*x)^s*endpointKernel N d x := mul_le_mul_of_nonneg_left hK (Real.rpow_nonneg hy0 s)
      _ = _ := by rw [←endpoint_scale_power (by omega : 0<N) hx];ring
  have hratio := (le_div_iff₀ ha).mpr hnum
  unfold coupledProfile
  linarith only [hratio,hH]

/-- The source local sharp lower bound for the actual raised-floor low profile. -/
theorem lowProfile_local_lower {N : ℕ} (hN : 2≤N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : (N:ℝ)^2*x≤s) :
    (((N:ℝ)^2*x)/(endpointReserveConstant f*s))^s*Real.exp (-288*s) ≤ lowProfile N s f x := by
  exact coupledProfile_local_first_lower hN (by norm_num : 2≤6) hs hs1
    (endpointReserveConstant_pos hf1) hx hx1 hy
    (lowShoulder_range (by omega) hs hf hx hx1).1
    (lowNormalizer_pos (by omega) hs hf hf1)
    (lowNormalizer_sharp_upper hN hs hs1 hf hf1)

/-- The high-profile local lower bound has constants independent of omega. -/
theorem highProfile_local_lower {N : ℕ} (hN : 2≤N) {s f ω x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : (N:ℝ)^2*x≤s) :
    (((N:ℝ)^2*x)/(endpointReserveConstant f*s))^s*Real.exp (-288*s) ≤ highProfile N s f ω x := by
  exact coupledProfile_local_first_lower hN (by norm_num : 6≤6) hs hs1
    (endpointReserveConstant_pos hf1) hx hx1 hy
    (highShoulder_range (by omega) hs hf hf1.le hω hx hx1).1
    (highNormalizer_pos (by omega) hs hf hf1.le hω hω1)
    (highNormalizer_sharp_upper hN hs hs1 hf hf1 hω hω1)

lemma coupledProfile_first_term_lower {N d : ℕ} (hN : 0<N)
    {s x C : ℝ} {H : ℝ → ℝ} (hs : 0<s) (hC : 0<C) (hx : 0≤x)
    (ha : 0<coupledNormalizer s (endpointKernel N d) H)
    (hupper : (N:ℝ)^(2*s)*coupledNormalizer s (endpointKernel N d) H≤(C*s)^s) :
    (((N:ℝ)^2*x)/(C*s))^s*endpointKernel N d x ≤
      x^s*endpointKernel N d x/coupledNormalizer s (endpointKernel N d) H := by
  have hNp : 0<(N:ℝ)^(2*s) := Real.rpow_pos_of_pos (by exact_mod_cast hN) _
  have hCs : 0<C*s := mul_pos hC hs
  have hy0 : 0≤(N:ℝ)^2*x := by positivity
  have hK := endpointKernel_nonneg N d x
  have hfactor : 0≤(((N:ℝ)^2*x)/(C*s))^s*endpointKernel N d x := by positivity
  have hprod : (((N:ℝ)^2*x)/(C*s))^s*(C*s)^s=((N:ℝ)^2*x)^s := by
    rw [Real.div_rpow hy0 hCs.le]
    field_simp
  apply (le_div_iff₀ ha).mpr
  apply (mul_le_mul_iff_right₀ hNp).mp
  calc
    _ = ((((N:ℝ)^2*x)/(C*s))^s*endpointKernel N d x)*
        ((N:ℝ)^(2*s)*coupledNormalizer s (endpointKernel N d) H) := by ring
    _ ≤ ((((N:ℝ)^2*x)/(C*s))^s*endpointKernel N d x)*(C*s)^s :=
      mul_le_mul_of_nonneg_left hupper hfactor
    _ = ((N:ℝ)^2*x)^s*endpointKernel N d x := by rw [mul_right_comm _ _ ((C*s)^s),hprod]
    _ = _ := by rw [←endpoint_scale_power hN hx];ring

lemma endpointReserveConstant_one_le {f : ℝ} (hf : 0≤f) (hf1 : f<1) :
    1≤endpointReserveConstant f := by
  have hρ : 0<1-f := by linarith
  have hρ1 : 1-f≤1 := by linarith
  have hlog := Real.log_nonpos hρ.le hρ1
  have he : 0≤Real.log (1-f)*(-1/(1-f)) := mul_nonneg_of_nonpos_of_nonpos hlog (div_nonpos_of_nonpos_of_nonneg (by norm_num) hρ.le)
  have hpow : 1≤(1-f)^(-1/(1-f)) := by
    rw [Real.rpow_def_of_pos hρ]
    exact Real.one_le_exp_iff.mpr he
  unfold endpointReserveConstant
  nlinarith only [hpow]

lemma profile_transition_power_lower {s y C : ℝ} (hs : 0<s) (hs1 : s≤1) (hC : 1≤C)
    (hy : s≤y) : C⁻¹≤(y/(C*s))^s := by
  have hCp : 0<C := by linarith
  have hbase : C⁻¹≤y/(C*s) := by
    apply (le_div_iff₀ (mul_pos hCp hs)).mpr
    have hid : C⁻¹*(C*s)=s := by field_simp
    rw [hid]
    exact hy
  have hinv0 : 0<C⁻¹ := inv_pos.mpr hCp
  have hinv1 : C⁻¹≤1 := (inv_le_one₀ hCp).mpr hC
  have hp := Real.rpow_le_rpow_of_exponent_ge hinv0 hinv1 hs1
  rw [Real.rpow_one] at hp
  exact hp.trans (Real.rpow_le_rpow hinv0.le hbase hs.le)

def coupledFloorConstant (f : ℝ) : ℝ :=
  min (endpointReserveConstant f)⁻¹ (f*Real.exp (-(Real.log 12+3)))

lemma coupledFloorConstant_pos {f : ℝ} (hf : 0<f) (hf1 : f<1) : 0<coupledFloorConstant f := by
  unfold coupledFloorConstant
  exact lt_min (inv_pos.mpr (endpointReserveConstant_pos hf1)) (mul_pos hf (Real.exp_pos _))

/-- Uniform positive floor of the actual low profile after its transition. -/
theorem lowProfile_transition_floor {N : ℕ} (hN : 2≤N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : s≤(N:ℝ)^2*x) :
    coupledFloorConstant f≤lowProfile N s f x := by
  have hN0 : 0<N := by omega
  have hK0 := endpointKernel_nonneg N 2 x
  have hK1 := endpointKernel_le_one hN0 2 hx hx1
  have hJ := endpointProfile_transition_floor hN0 (by norm_num : 2≤2) (by norm_num : 2≤6) hs hs1 hx hx1 hy
  have hfirst := coupledProfile_first_term_lower (d:=2) hN0 hs (endpointReserveConstant_pos hf1) hx
    (lowNormalizer_pos hN0 hs hf hf1) (lowNormalizer_sharp_upper hN hs hs1 hf hf1)
  have hpower := profile_transition_power_lower hs hs1 (endpointReserveConstant_one_le hf hf1) hy
  have hfirst' := (mul_le_mul_of_nonneg_right hpower hK0).trans hfirst
  have hshoulder := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hJ hf) (sub_nonneg.mpr hK1)
  have hm1 := mul_le_mul_of_nonneg_right (min_le_left (endpointReserveConstant f)⁻¹
    (f*Real.exp (-(Real.log 12+3)))) hK0
  have hm2 := mul_le_mul_of_nonneg_right (min_le_right (endpointReserveConstant f)⁻¹
    (f*Real.exp (-(Real.log 12+3)))) (sub_nonneg.mpr hK1)
  simp only [lowProfile,coupledProfile,lowShoulder,coupledFloorConstant] at *
  nlinarith only [hfirst',hshoulder,hm1,hm2]

/-- The actual high profile has a positive omega-scaled floor uniformly beyond y=s. -/
theorem highProfile_transition_floor {N : ℕ} (hN : 2≤N) {s f ω x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : s≤(N:ℝ)^2*x) :
    ω*coupledFloorConstant f≤highProfile N s f ω x := by
  have hN0 : 0<N := by omega
  have hK0 := endpointKernel_nonneg N 6 x
  have hK1 := endpointKernel_le_one hN0 6 hx hx1
  have hJ := endpointProfile_transition_floor hN0 (by norm_num : 2≤6) (by norm_num : 6≤6) hs hs1 hx hx1 hy
  have hJ0 := (endpointProfile_range hN0 (by norm_num : 6≤6) hs hx hx1).1
  have hfirst := coupledProfile_first_term_lower (d:=6) hN0 hs (endpointReserveConstant_pos hf1) hx
    (highNormalizer_pos hN0 hs hf hf1.le hω hω1) (highNormalizer_sharp_upper hN hs hs1 hf hf1 hω hω1)
  have hpower := profile_transition_power_lower hs hs1 (endpointReserveConstant_one_le hf hf1) hy
  have hfirst' := (mul_le_mul_of_nonneg_right hpower hK0).trans hfirst
  have hfirstω : ω*(endpointReserveConstant f)⁻¹*endpointKernel N 6 x ≤
      x^s*endpointKernel N 6 x/highNormalizer N s f ω := by
    have hm := mul_le_mul_of_nonneg_right hω1.le
      (mul_nonneg (inv_pos.mpr (endpointReserveConstant_pos hf1)).le hK0)
    change ω*(endpointReserveConstant f)⁻¹*endpointKernel N 6 x ≤
      x^s*endpointKernel N 6 x/coupledNormalizer s (endpointKernel N 6) (highShoulder N s f ω)
    nlinarith only [hm,hfirst']
  have hWf : f≤highShoulderWeight N f x := by
    unfold highShoulderWeight
    nlinarith only [mul_nonneg (sub_nonneg.mpr hf1.le) (sq_nonneg (1-endpointKernel N 3 x))]
  have hshoulder : ω*Real.exp (-(Real.log 12+3))*(1-endpointKernel N 6 x)*f ≤
      highShoulder N s f ω x := by
    have hJω := mul_le_mul_of_nonneg_left hJ hω
    have hJωK := mul_le_mul_of_nonneg_right hJω (sub_nonneg.mpr hK1)
    have hJωKf := mul_le_mul_of_nonneg_right hJωK hf
    have hWmul := mul_le_mul_of_nonneg_left hWf
      (mul_nonneg (mul_nonneg hω hJ0) (sub_nonneg.mpr hK1))
    unfold highShoulder
    nlinarith only [hJωKf,hWmul]
  have hm1 := mul_le_mul_of_nonneg_right (min_le_left (endpointReserveConstant f)⁻¹
    (f*Real.exp (-(Real.log 12+3)))) (mul_nonneg hω hK0)
  have hm2 := mul_le_mul_of_nonneg_right (min_le_right (endpointReserveConstant f)⁻¹
    (f*Real.exp (-(Real.log 12+3)))) (mul_nonneg hω (sub_nonneg.mpr hK1))
  simp only [highProfile,coupledProfile,highNormalizer,coupledFloorConstant] at *
  nlinarith only [hfirstω,hshoulder,hm1,hm2]

end Renyi
