import Renyi.CoupledCoefficients
import Renyi.EndpointLocalCoefficients

/-! Actual low coefficients of the coupled polynomial under the capacity scale. -/
noncomputable section
open Polynomial
namespace Renyi

lemma scale_comp_scale (a b : ℝ) :
    (C b⁻¹*X : ℝ[X]).comp (C a*X) = C (a/b)*X := by
  simp only [mul_comp, C_comp, X_comp]
  rw [←mul_assoc, ←C_mul]
  congr 2
  ring

/-- Up to degree m, only the low arm contributes to the actual coupled polynomial. -/
lemma coupledQPolynomial_low_coeff {ℓ N m j : ℕ} (hj : j ≤ m)
    (γ a b fL f A B ω : ℝ) :
    (coupledQPolynomial ℓ N m γ a b fL f A B ω).coeff j =
      (C (A*a^γ)*reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a *
        (1-(X*endpointProfilePolynomial N 6 1).comp (C b⁻¹*X))).coeff j := by
  have hj' : ¬m+1≤j := by omega
  unfold coupledQPolynomial
  simp only [coeff_add, mul_assoc, coeff_C_mul, coeff_X_pow_mul', if_neg hj', mul_zero,
    add_zero, mul_comp, X_comp]

/-- The actual low coefficient array has no high-degree cost when N²a/b is bounded. -/
theorem coupledQPolynomial_low_coefficient_bound {ℓ N m j : ℕ}
    (hℓ : 0 < ℓ) (hN : 0 < N) (hdegree : 4*(ℓ-1) ≤ m) (hj : j ≤ m)
    {γ a b fL f A B ω Z : ℝ} (hγ : 0 < γ) (hγ1 : γ ≤ 1)
    (ha : 0 < a) (hb : 0 < b) (hf : 0 ≤ fL) (hf1 : fL < 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hZ : (N:ℝ)^2*(a/b) ≤ Z) :
    |(coupledQPolynomial ℓ N m γ a b fL f A B ω).coeff j| * a^j ≤
      a^((m:ℝ)+γ)*(96*(ℓ:ℝ)^2*(9:ℝ)^(4*(ℓ-1)))*
        (1+24*Z*Real.exp (12*Real.sqrt Z)) := by
  let P := C (A*a^γ)*reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a *
    (1-(X*endpointProfilePolynomial N 6 1).comp (C b⁻¹*X))
  have hcoeff := abs_coeff_le_coefficientMass (P.comp (C a*X)) j
  rw [comp_C_mul_X_coeff, abs_mul, abs_of_nonneg (pow_nonneg ha.le j)] at hcoeff
  have hrev := reverseScaledPolynomial_comp_coefficientMass (lowProfilePolynomial ℓ γ fL)
    ((lowProfilePolynomial_natDegree ℓ γ fL).trans hdegree) ha.le (le_refl a)
  have hcut := endpointCutoffPolynomial_local_mass_uniform hN (by norm_num : 6≤6)
    (div_nonneg ha.le hb.le) hZ
  norm_num only [Nat.cast_ofNat, show (2:ℝ)*6=12 by norm_num] at hcut
  have hcut' : coefficientMass (1-(X*endpointProfilePolynomial N 6 1).comp (C (a/b)*X)) ≤
      1+24*Z*Real.exp (12*Real.sqrt Z) := by
    exact (coefficientMass_sub_le _ _).trans (by simpa using add_le_add_left hcut 1)
  have hlow := lowProfilePolynomial_coefficientMass hℓ hγ hγ1 hf hf1
  have hfirst : coefficientMass ((C (A*a^γ)*reverseScaledPolynomial
      (lowProfilePolynomial ℓ γ fL) m a).comp (C a*X)) ≤
      a^((m:ℝ)+γ)*(96*(ℓ:ℝ)^2*(9:ℝ)^(4*(ℓ-1))) := by
    rw [mul_comp, C_comp, coefficientMass_C_mul,
      abs_of_nonneg (mul_nonneg hA (Real.rpow_nonneg ha.le γ))]
    have hm := mul_le_mul_of_nonneg_left hrev (mul_nonneg hA (Real.rpow_nonneg ha.le γ))
    have hm2 := mul_le_mul_of_nonneg_left hlow (show 0 ≤ a^γ*a^m by positivity)
    have hA' := mul_le_of_le_one_left
      (show 0 ≤ a^γ*(coefficientMass (lowProfilePolynomial ℓ γ fL)*a^m) by
        exact mul_nonneg (Real.rpow_nonneg ha.le γ) (mul_nonneg (coefficientMass_nonneg _) (pow_nonneg ha.le m))) hA1
    have hid : a^γ*a^m=a^((m:ℝ)+γ) := by
      rw [←Real.rpow_natCast, ←Real.rpow_add ha]
      congr 1
      ring
    apply hm.trans
    calc
      _ = A*(a^γ*(coefficientMass (lowProfilePolynomial ℓ γ fL)*a^m)) := by ring
      _ ≤ a^γ*(coefficientMass (lowProfilePolynomial ℓ γ fL)*a^m) := hA'
      _ = (a^γ*a^m)*coefficientMass (lowProfilePolynomial ℓ γ fL) := by ring
      _ ≤ _ := by simpa only [hid] using hm2
  have hmass : coefficientMass (P.comp (C a*X)) ≤
      a^((m:ℝ)+γ)*(96*(ℓ:ℝ)^2*(9:ℝ)^(4*(ℓ-1)))*
        (1+24*Z*Real.exp (12*Real.sqrt Z)) := by
    dsimp only [P]
    rw [mul_comp, sub_comp, one_comp, comp_assoc, scale_comp_scale]
    exact (coefficientMass_mul_le _ _).trans
      (mul_le_mul hfirst hcut' (coefficientMass_nonneg _) (by positivity))
  rw [coupledQPolynomial_low_coeff hj]
  exact hcoeff.trans hmass


def coupledLowCoefficientConstant : ℝ := 100*(1+24*Real.exp 12)

/-- A fixed exponential budget suffices for the complete low-degree count block. -/
theorem coupledQPolynomial_low_coefficient_exponential {ℓ N m j : ℕ}
    (hℓ : 0 < ℓ) (hN : 0 < N) (hdegree : 4*(ℓ-1) ≤ m) (hj : j ≤ m)
    {γ a b fL f A B ω : ℝ} (hγ : 0 < γ) (hγ1 : γ ≤ 1)
    (ha : 0 < a) (hb : 0 < b) (hf : 0 ≤ fL) (hf1 : fL < 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hZ : (N:ℝ)^2*(a/b) ≤ 1) :
    |(coupledQPolynomial ℓ N m γ a b fL f A B ω).coeff j| ≤
      coupledLowCoefficientConstant^(m+1)*a^((m:ℝ)+γ-(j:ℝ)) := by
  have h := coupledQPolynomial_low_coefficient_bound (f:=f) (B:=B) (ω:=ω)
    hℓ hN hdegree hj hγ hγ1 ha hb hf hf1 hA hA1 hZ
  simp only [Real.sqrt_one, mul_one] at h
  have hlow := low_coefficient_constant_exponential hdegree
  have hlow' : 96*(ℓ:ℝ)^2*(9:ℝ)^(4*(ℓ-1)) ≤ (100:ℝ)^(m+1) := by linarith
  have hC1 : 1 ≤ 1+24*Real.exp 12 := by linarith [Real.exp_pos (12:ℝ)]
  have hCpow : 1+24*Real.exp 12 ≤ (1+24*Real.exp 12)^(m+1) :=
    le_self_pow₀ hC1 (by omega : m+1≠0)
  have hmass := mul_le_mul hlow' hCpow (by positivity : 0≤1+24*Real.exp 12)
    (by positivity : 0≤(100:ℝ)^(m+1))
  rw [←mul_pow] at hmass
  change _ ≤ coupledLowCoefficientConstant^(m+1) at hmass
  have h' : |(coupledQPolynomial ℓ N m γ a b fL f A B ω).coeff j| * a^j ≤
      a^((m:ℝ)+γ)*coupledLowCoefficientConstant^(m+1) := by
    apply h.trans
    have hm := mul_le_mul_of_nonneg_left hmass (Real.rpow_nonneg ha.le ((m:ℝ)+γ))
    nlinarith only [hm]
  apply (le_div_iff₀ (pow_pos ha j)).mpr at h'
  apply h'.trans_eq
  rw [Real.rpow_sub ha, Real.rpow_natCast]
  ring

end Renyi
