import Renyi.Model

/-!
# Completing a positive finite measure to a mean-one prior

This proves the reweighting and zero-atom completion used in the tensor-prior
argument. The interpolation nodes, tensor sign decomposition, and quantitative
mass bounds are separate, outstanding obligations.
-/

noncomputable section
open scoped BigOperators
namespace Renyi

/-- Positive masses at points at least one have mass at most their first moment. -/
theorem mass_le_first_moment {ι : Type*} [Fintype ι] (w v : ι → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hv : ∀ i, 1 ≤ v i) :
    ∑ i, w i ≤ ∑ i, w i * v i := by
  apply Finset.sum_le_sum
  intro i _
  simpa using mul_le_mul_of_nonneg_left (hv i) (hw i)

def completedMass {n : ℕ} (w : Fin n → ℝ) : Fin (n + 1) → ℝ :=
  Fin.cases (1 - ∑ i, w i) w

theorem completedMass_nonneg {n : ℕ} (w v : Fin n → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hv : ∀ i, 1 ≤ v i)
    (hmean : ∑ i, w i * v i = 1) : ∀ i, 0 ≤ completedMass w i := by
  have hmass : ∑ i, w i ≤ 1 := by
    simpa only [hmean] using mass_le_first_moment w v hw hv
  intro i
  refine Fin.cases ?_ (fun j => ?_) i
  · simpa [completedMass] using sub_nonneg.mpr hmass
  · simpa [completedMass] using hw j

theorem completedMass_sum {n : ℕ} (w : Fin n → ℝ) :
    ∑ i, completedMass w i = 1 := by
  simp [Fin.sum_univ_succ, completedMass]

/-- A genuine probability vector: index zero carries the added atom at zero. -/
def completedLaw {n : ℕ} (w v : Fin n → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hv : ∀ i, 1 ≤ v i)
    (hmean : ∑ i, w i * v i = 1) : Simplex (n + 1) where
  mass := completedMass w
  nonneg := completedMass_nonneg w v hw hv hmean
  normalized := completedMass_sum w

/-- Completion at zero does not alter the first moment. -/
theorem completedLaw_mean {n : ℕ} (w v : Fin n → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hv : ∀ i, 1 ≤ v i)
    (hmean : ∑ i, w i * v i = 1) :
    ∑ i, (completedLaw w v hw hv hmean).mass i * (Fin.cases 0 v i) = 1 := by
  simpa [Fin.sum_univ_succ, completedLaw, completedMass] using hmean

def reweightedMass {ι : Type*} (μ z : ι → ℝ) (B Z α : ℝ) (i : ι) : ℝ :=
  μ i / (B * Z) * z i ^ (-α)

/-- The power reweighting in the paper enforces the first moment exactly. -/
theorem reweighted_mean {ι : Type*} [Fintype ι] (μ z : ι → ℝ)
    (B Z α : ℝ) (hB : 0 < B) (hZ : 0 < Z) (hz : ∀ i, 0 < z i)
    (hZdef : Z = ∑ i, μ i * z i ^ (1 - α)) :
    ∑ i, reweightedMass μ z B Z α i * (B * z i) = 1 := by
  have hterm (i : ι) : reweightedMass μ z B Z α i * (B * z i) =
      (μ i * z i ^ (1 - α)) / Z := by
    have hp : z i ^ (-α) * z i = z i ^ (1 - α) := by
      calc
        z i ^ (-α) * z i = z i ^ (-α) * z i ^ (1 : ℝ) := by rw [Real.rpow_one]
        _ = z i ^ (-α + 1) := (Real.rpow_add (hz i) _ _).symm
        _ = z i ^ (1 - α) := by congr 1; ring
    unfold reweightedMass
    calc
      μ i / (B * Z) * z i ^ (-α) * (B * z i) =
          μ i * (z i ^ (-α) * z i) / Z := by
            field_simp
      _ = (μ i * z i ^ (1 - α)) / Z := by rw [hp]
  calc
    (∑ i, reweightedMass μ z B Z α i * (B * z i)) =
        ∑ i, (μ i * z i ^ (1 - α)) / Z := Finset.sum_congr rfl (fun i _ => hterm i)
    _ = (∑ i, μ i * z i ^ (1 - α)) / Z := (Finset.sum_div _ _ _).symm
    _ = 1 := by rw [← hZdef, div_self (ne_of_gt hZ)]

/-- All reweighted masses are nonnegative. -/
theorem reweighted_nonneg {ι : Type*} (μ z : ι → ℝ) (B Z α : ℝ)
    (hμ : ∀ i, 0 ≤ μ i) (hB : 0 < B) (hZ : 0 < Z) (hz : ∀ i, 0 < z i) :
    ∀ i, 0 ≤ reweightedMass μ z B Z α i := by
  intro i
  unfold reweightedMass
  exact mul_nonneg (div_nonneg (hμ i) (mul_pos hB hZ).le)
    (Real.rpow_pos_of_pos (hz i) _).le

end Renyi
