import Renyi.Foundations
import Mathlib.Analysis.MeanInequalities
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity

/-! The exact two-arm envelope, with the actual scalar coefficients. -/
noncomputable section
open Set
namespace Renyi

def overlapA (γ z : ℝ) : ℝ := (1 - z ^ (1 / γ)) / (1 - z ^ (1 / (γ * (1 - γ))))
def overlapB (γ z : ℝ) : ℝ := (1 - z ^ (1 / (1 - γ))) / (1 - z ^ (1 / (γ * (1 - γ))))
def overlapG (γ z : ℝ) : ℝ :=
  z * overlapA γ z ^ (1 - γ) * overlapB γ z ^ γ /
    ((1 - γ) ^ (1 - γ) * γ ^ γ)

private theorem unit_rpow {z p : ℝ} (hz : 0 < z) (hz1 : z < 1) (hp : 0 < p) :
    0 < z ^ p ∧ z ^ p < 1 := by
  exact ⟨Real.rpow_pos_of_pos hz _, by simpa using Real.rpow_lt_rpow hz.le hz1 hp⟩

/-- Both intercept identities hold exactly. -/
theorem overlap_endpoints {γ z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) :
    overlapA γ z * z ^ (1 / (1 - γ)) + overlapB γ z = 1 ∧
    overlapA γ z + overlapB γ z * z ^ (1 / γ) = 1 := by
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  have hden := (unit_rpow hz hz1 (one_div_pos.mpr (mul_pos hγ hd))).2
  have hexp : 1 / γ + 1 / (1 - γ) = 1 / (γ * (1 - γ)) := by
    field_simp
    ring
  have hprod : z ^ (1 / γ) * z ^ (1 / (1 - γ)) = z ^ (1 / (γ * (1 - γ))) := by
    rw [← Real.rpow_add hz, hexp]
  dsimp [overlapA, overlapB]
  have hne : 1 - z ^ (1 / (γ * (1 - γ))) ≠ 0 := (sub_pos.mpr hden).ne'
  constructor
  · rw [div_mul_eq_mul_div, ← add_div, div_eq_one_iff_eq hne]
    nlinarith [hprod]
  · rw [div_mul_eq_mul_div, ← add_div, div_eq_one_iff_eq hne]
    nlinarith [hprod]

/-- The coefficients strictly exceed their limiting weights. -/
theorem overlap_coefficients {γ z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) :
    1 - γ < overlapA γ z ∧ γ < overlapB γ z := by
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  let x := z ^ (1 / (γ * (1 - γ)))
  have hx := unit_rpow hz hz1 (one_div_pos.mpr (mul_pos hγ hd))
  have hxA : x ^ (1 - γ) = z ^ (1 / γ) := by
    dsimp [x]
    rw [← Real.rpow_mul hz.le]
    congr 1
    field_simp
  have hxB : x ^ γ = z ^ (1 / (1 - γ)) := by
    dsimp [x]
    rw [← Real.rpow_mul hz.le]
    congr 1
    field_simp
  have hA := rpow_one_add_lt_one_add_mul_self (s := x - 1) (by linarith : -1 ≤ x - 1)
    (by linarith : x - 1 ≠ 0) hd (by linarith : 1 - γ < 1)
  have hB := rpow_one_add_lt_one_add_mul_self (s := x - 1) (by linarith : -1 ≤ x - 1)
    (by linarith : x - 1 ≠ 0) hγ hγ1
  rw [show 1 + (x - 1) = x by ring, hxA] at hA
  rw [show 1 + (x - 1) = x by ring, hxB] at hB
  change 1 - γ < (1 - z ^ (1 / γ)) / (1 - x) ∧ γ < (1 - z ^ (1 / (1 - γ))) / (1 - x)
  constructor <;> apply (lt_div_iff₀ (sub_pos.mpr hx.2)).2 <;> nlinarith

private theorem chord_product_lower {δ γ x y z s : ℝ}
    (hδ : 0 ≤ δ) (hγ : 0 ≤ γ) (hx : 0 < x) (hy : 0 < y) (hz : 0 < z)
    (hs : 0 ≤ s) (hs1 : s ≤ 1) (hxz : x ^ δ = z) (hyz : y ^ γ = z) :
    z ≤ (s * x + (1 - s)) ^ δ * (s + (1 - s) * y) ^ γ := by
  have hu := Real.geom_mean_le_arith_mean2_weighted hs (by linarith : 0 ≤ 1 - s)
    hx.le (show (0 : ℝ) ≤ 1 by norm_num) (by ring : s + (1 - s) = 1)
  have hv := Real.geom_mean_le_arith_mean2_weighted hs (by linarith : 0 ≤ 1 - s)
    (show (0 : ℝ) ≤ 1 by norm_num) hy.le (by ring : s + (1 - s) = 1)
  simp only [Real.one_rpow, mul_one, one_mul] at hu hv
  have hp := mul_le_mul (Real.rpow_le_rpow (Real.rpow_nonneg hx.le _) hu hδ)
    (Real.rpow_le_rpow (Real.rpow_nonneg hy.le _) hv hγ)
    (Real.rpow_nonneg (Real.rpow_nonneg hy.le _) _)
    (Real.rpow_nonneg (by nlinarith [mul_nonneg hs hx.le]) _)
  convert hp using 1
  rw [← Real.rpow_mul hx.le, mul_comm s δ, Real.rpow_mul hx.le, hxz,
    ← Real.rpow_mul hy.le, mul_comm (1 - s) γ, Real.rpow_mul hy.le, hyz,
    ← Real.rpow_add hz, show s + (1 - s) = 1 by ring, Real.rpow_one]

private theorem linear_upper_of_product {A B δ γ x y z u v : ℝ}
    (hA : 0 < A) (hB : 0 < B) (hδ : 0 < δ) (hγ : 0 < γ)
    (hx : 0 < x) (hx1 : x < 1) (hy : 0 < y) (hz : 0 < z)
    (hleft : A * x + B = 1) (hright : A + B * y = 1)
    (hxz : x ^ δ = z) (hyz : y ^ γ = z)
    (_hu : 0 ≤ u) (hu1 : u ≤ 1) (_hv : 0 ≤ v) (hv1 : v ≤ 1)
    (hprod : u ^ δ * v ^ γ ≤ z) : A * u + B * v ≤ 1 := by
  by_contra hn
  have hobj : 1 < A * u + B * v := lt_of_not_ge hn
  have hxu : x < u := by nlinarith
  let s := (1 - u) / (1 - x)
  have hs : 0 ≤ s := div_nonneg (sub_nonneg.mpr hu1) (sub_nonneg.mpr hx1.le)
  have hs1 : s ≤ 1 := (div_le_one (sub_pos.mpr hx1)).2 (by linarith)
  have hrepr : s * x + (1 - s) = u := by dsimp [s]; field_simp [ne_of_gt (sub_pos.mpr hx1)]; ring
  let v₀ := s + (1 - s) * y
  have hv₀ : 0 < v₀ := by
    dsimp [v₀]
    by_cases hs0 : s = 0
    · simp [hs0, hy]
    · exact add_pos_of_pos_of_nonneg (lt_of_le_of_ne hs (Ne.symm hs0)) (mul_nonneg (by linarith) hy.le)
  have hline : A * u + B * v₀ = 1 := by
    have : A * (s * x + (1 - s)) + B * v₀ = s * (A*x+B)+(1-s)*(A+B*y) := by dsimp [v₀]; ring
    rw [hrepr, hleft, hright] at this
    nlinarith
  have hvlt : v₀ < v := by nlinarith
  have hlow := chord_product_lower hδ.le hγ.le hx hy hz hs hs1 hxz hyz
  rw [hrepr] at hlow
  have hstrict : u ^ δ * v₀ ^ γ < u ^ δ * v ^ γ :=
    mul_lt_mul_of_pos_left (Real.rpow_lt_rpow hv₀.le hvlt hγ)
      (Real.rpow_pos_of_pos (hx.trans hxu) _)
  exact (not_lt_of_ge hprod) (lt_of_le_of_lt hlow hstrict)

/-- The maximum is one, with the right intercept as an explicit maximizer. -/
theorem overlap_maximum {γ z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) :
    (∀ u ∈ Icc (0 : ℝ) 1, ∀ v ∈ Icc (0 : ℝ) 1,
      u ^ (1 - γ) * v ^ γ ≤ z → overlapA γ z * u + overlapB γ z * v ≤ 1) ∧
    ∃ u ∈ Icc (0 : ℝ) 1, ∃ v ∈ Icc (0 : ℝ) 1,
      u ^ (1 - γ) * v ^ γ = z ∧ overlapA γ z * u + overlapB γ z * v = 1 := by
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients hγ hγ1 hz hz1
  have he := overlap_endpoints hγ hγ1 hz hz1
  have hx := unit_rpow hz hz1 (one_div_pos.mpr hd)
  have hy := unit_rpow hz hz1 (one_div_pos.mpr hγ)
  have hxz : (z ^ (1 / (1 - γ))) ^ (1 - γ) = z := by
    rw [← Real.rpow_mul hz.le, div_mul_cancel₀ 1 hd.ne', Real.rpow_one]
  have hyz : (z ^ (1 / γ)) ^ γ = z := by
    rw [← Real.rpow_mul hz.le, div_mul_cancel₀ 1 hγ.ne', Real.rpow_one]
  constructor
  · intro u hu v hv hp
    exact linear_upper_of_product (hd.trans hc.1) (hγ.trans hc.2) hd hγ hx.1 hx.2 hy.1 hz
      he.1 he.2 hxz hyz hu.1 hu.2 hv.1 hv.2 hp
  · refine ⟨1, ⟨by norm_num, le_rfl⟩, z ^ (1/γ), ⟨hy.1.le, hy.2.le⟩, ?_, ?_⟩
    · simpa using hyz
    · simpa using he.2

theorem overlapG_factor {γ z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) :
    overlapG γ z = z * (overlapA γ z / (1-γ)) ^ (1-γ) * (overlapB γ z / γ) ^ γ := by
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients hγ hγ1 hz hz1
  rw [Real.div_rpow (hd.trans hc.1).le hd.le, Real.div_rpow (hγ.trans hc.2).le hγ.le]
  unfold overlapG
  ring

private theorem weighted_product_bound {δ γ A B u v : ℝ}
    (hδ : 0 < δ) (hγ : 0 < γ) (hweights : δ + γ = 1)
    (hA : 0 < A) (hB : 0 < B) (hu : 0 ≤ u) (hv : 0 ≤ v) :
    (u ^ δ * v ^ γ) * (A/δ) ^ δ * (B/γ) ^ γ ≤ A*u+B*v := by
  have h := Real.geom_mean_le_arith_mean2_weighted hδ.le hγ.le
    (mul_nonneg (div_nonneg hA.le hδ.le) hu)
    (mul_nonneg (div_nonneg hB.le hγ.le) hv) hweights
  rw [Real.mul_rpow (div_nonneg hA.le hδ.le) hu,
    Real.mul_rpow (div_nonneg hB.le hγ.le) hv] at h
  have heq : δ * (A/δ*u) + γ*(B/γ*v) = A*u+B*v := by field_simp
  rw [heq] at h
  convert h using 1; ring

/-- The lower envelope bounds every nonnegative feasible pair. -/
theorem overlap_lower_bound {γ z u v : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) (hu : 0 ≤ u) (hv : 0 ≤ v)
    (hp : z ≤ u ^ (1-γ) * v ^ γ) : overlapG γ z ≤ overlapA γ z*u+overlapB γ z*v := by
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients hγ hγ1 hz hz1
  rw [overlapG_factor hγ hγ1 hz hz1]
  calc
    _ ≤ (u ^ (1-γ)*v^γ)*(overlapA γ z/(1-γ))^(1-γ)*(overlapB γ z/γ)^γ := by
      exact mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right hp (Real.rpow_nonneg (div_nonneg (hd.trans hc.1).le hd.le) _))
        (Real.rpow_nonneg (div_nonneg (hγ.trans hc.2).le hγ.le) _)
    _ ≤ _ := weighted_product_bound hd hγ (by ring) (hd.trans hc.1) (hγ.trans hc.2) hu hv

private theorem strict_weighted_amgm {δ γ x y : ℝ} (hδ : 0 < δ) (hγ : 0 < γ)
    (hs : δ + γ = 1) (hx : 0 < x) (hy : 0 < y) (hne : x ≠ y) :
    x ^ δ * y ^ γ < δ*x+γ*y := by
  have h := strictConcaveOn_log_Ioi.2 hx hy hne hδ hγ hs
  simp only [smul_eq_mul] at h
  have hp : 0 < x^δ*y^γ := mul_pos (Real.rpow_pos_of_pos hx _) (Real.rpow_pos_of_pos hy _)
  apply (Real.log_lt_log_iff hp (by positivity)).mp
  rw [Real.log_mul (Real.rpow_pos_of_pos hx _).ne' (Real.rpow_pos_of_pos hy _).ne',
    Real.log_rpow hx, Real.log_rpow hy]
  exact h

/-- The actual scalar envelope takes values strictly between zero and one. -/
theorem overlapG_mem_Ioo {γ z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) : overlapG γ z ∈ Ioo (0 : ℝ) 1 := by
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients hγ hγ1 hz hz1
  have hA := hd.trans hc.1
  have hB := hγ.trans hc.2
  have hy := unit_rpow hz hz1 (one_div_pos.mpr hγ)
  have he := (overlap_endpoints hγ hγ1 hz hz1).2
  have hyz : (z ^ (1 / γ)) ^ γ = z := by
    rw [← Real.rpow_mul hz.le, div_mul_cancel₀ 1 hγ.ne', Real.rpow_one]
  have hne : overlapA γ z / (1-γ) ≠ overlapB γ z / γ * z ^ (1/γ) := by
    have ha : 1 < overlapA γ z / (1-γ) := (one_lt_div hd).2 hc.1
    have hb : overlapB γ z / γ * z ^ (1/γ) < 1 := by
      rw [div_mul_eq_mul_div, div_lt_one hγ]
      linarith [hc.1]
    linarith
  have h := strict_weighted_amgm hd hγ (by ring) (div_pos hA hd)
    (mul_pos (div_pos hB hγ) hy.1) hne
  rw [Real.mul_rpow (div_nonneg hB.le hγ.le) hy.1.le, hyz] at h
  have hh : (1-γ)*(overlapA γ z/(1-γ)) + γ*(overlapB γ z/γ*z^(1/γ)) = 1 := by
    convert he using 1; field_simp
  rw [hh] at h
  rw [overlapG_factor hγ hγ1 hz hz1]
  constructor
  · exact mul_pos (mul_pos hz (Real.rpow_pos_of_pos (div_pos hA hd) _))
      (Real.rpow_pos_of_pos (div_pos hB hγ) _)
  · convert h using 1; ring

/-- The lower bound is attained by the explicit interior critical point. -/
theorem overlap_minimum {γ z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) :
    (∀ u ∈ Icc (0 : ℝ) 1, ∀ v ∈ Icc (0 : ℝ) 1,
      z ≤ u ^ (1-γ) * v ^ γ → overlapG γ z ≤ overlapA γ z*u+overlapB γ z*v) ∧
    ∃ u ∈ Ioo (0 : ℝ) 1, ∃ v ∈ Ioo (0 : ℝ) 1,
      u ^ (1-γ) * v ^ γ = z ∧ overlapA γ z*u+overlapB γ z*v = overlapG γ z := by
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients hγ hγ1 hz hz1
  have hA := hd.trans hc.1
  have hB := hγ.trans hc.2
  have hG := overlapG_mem_Ioo hγ hγ1 hz hz1
  let a := overlapA γ z / (1-γ)
  let b := overlapB γ z / γ
  have ha : 1 < a := (one_lt_div hd).2 hc.1
  have hb : 1 < b := (one_lt_div hγ).2 hc.2
  have ha0 : 0 < a := zero_lt_one.trans ha
  have hb0 : 0 < b := zero_lt_one.trans hb
  have hfactor : overlapG γ z = z*a^(1-γ)*b^γ := overlapG_factor hγ hγ1 hz hz1
  constructor
  · intro u hu v hv hp
    exact overlap_lower_bound hγ hγ1 hz hz1 hu.1 hv.1 hp
  · refine ⟨overlapG γ z / a, ⟨div_pos hG.1 ha0, (div_lt_one ha0).2 (hG.2.trans ha)⟩,
      overlapG γ z / b, ⟨div_pos hG.1 hb0, (div_lt_one hb0).2 (hG.2.trans hb)⟩, ?_, ?_⟩
    · rw [Real.div_rpow hG.1.le ha0.le, Real.div_rpow hG.1.le hb0.le,
        div_mul_div_comm, ← Real.rpow_add hG.1, show 1-γ+γ = 1 by ring, Real.rpow_one, hfactor]
      field_simp
    · dsimp [a,b]
      field_simp
      ring

/-- Continuity on the open parameter interval. -/
theorem overlapG_continuousOn {γ : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    ContinuousOn (overlapG γ) (Ioo (0 : ℝ) 1) := by
  intro z hz
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients hγ hγ1 hz.1 hz.2
  have hden := (unit_rpow hz.1 hz.2 (one_div_pos.mpr (mul_pos hγ hd))).2
  have hpow (p : ℝ) : ContinuousAt (fun x : ℝ => x^p) z :=
    Real.continuousAt_rpow_const z p (.inl hz.1.ne')
  have hA : ContinuousAt (overlapA γ) z :=
    (continuousAt_const.sub (hpow _)).div (continuousAt_const.sub (hpow _)) (sub_pos.mpr hden).ne'
  have hB : ContinuousAt (overlapB γ) z :=
    (continuousAt_const.sub (hpow _)).div (continuousAt_const.sub (hpow _)) (sub_pos.mpr hden).ne'
  exact (((continuousAt_id.mul (hA.rpow_const (.inl (hd.trans hc.1).ne'))).mul
    (hB.rpow_const (.inl (hγ.trans hc.2).ne'))).div_const _).continuousWithinAt

end Renyi
