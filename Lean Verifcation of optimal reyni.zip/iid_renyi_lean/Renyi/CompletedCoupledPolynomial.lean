import Renyi.NearOnePolynomial

/-! The single coupled polynomial including the prescribed degree-one low arm. -/
noncomputable section
open Polynomial
namespace Renyi

/-- The degree-one completion at arbitrary integer order m≥1. -/
def degreeOneCoupledPolynomial (N m : ℕ) (γ τ b f ω A B : ℝ) : ℝ[X] :=
  X^(m-1)*nearOneCoupledPolynomial N γ τ b f ω A B

@[simp] theorem degreeOneCoupledPolynomial_one (N : ℕ) (γ τ b f ω A B : ℝ) :
    degreeOneCoupledPolynomial N 1 γ τ b f ω A B = nearOneCoupledPolynomial N γ τ b f ω A B := by
  simp [degreeOneCoupledPolynomial]

lemma order_power_completion {m : ℕ} (hm : 1≤m) {p γ : ℝ} (hp : 0<p) :
    p^(m-1)*p^(1+γ)=p^((m:ℝ)+γ) := by
  rw [←Real.rpow_natCast,←Real.rpow_add hp]
  congr 1
  rw [Nat.cast_sub hm,Nat.cast_one]
  ring

/-- Exact scalar identity for the completed low branch, at every positive p≤b. -/
theorem degreeOneCoupledPolynomial_eval {N m : ℕ} (hN : 0<N) (hm : 1≤m)
    {γ c a b p f ω A B : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hc : 0<c)
    (ha : 0≤a) (hp : 0<p) (hpb : p≤b) :
    (degreeOneCoupledPolynomial N m γ (c*a*(1+γ)/γ) b f ω A B).eval p =
      p^((m:ℝ)+γ)*(A*degreeOneProfile γ c (a/p)*(1-endpointProfile N 6 1 (p/b))+
        B*highProfile N (1-γ) f ω (p/b)+ω*(1-B)*endpointProfile N 6 (1-γ) (p/b)) := by
  have hb : 0<b := hp.trans_le hpb
  have hT := degreeOne_reverse_tangent hγ hc ha hp
  rw [nearOneTangentPolynomial_eval] at hT
  unfold degreeOneCoupledPolynomial
  rw [eval_mul,eval_pow,eval_X,nearOneCoupledPolynomial_eval hN hγ hγ1 hb hp.le hpb,←hT]
  calc
    _ = (p^(m-1)*p^(1+γ))*(A*degreeOneProfile γ c (a/p)*(1-endpointProfile N 6 1 (p/b))+
        B*highProfile N (1-γ) f ω (p/b)+ω*(1-B)*endpointProfile N 6 (1-γ) (p/b)) := by ring
    _ = _ := by rw [order_power_completion hm hp]

/-- The general completed arm obeys the same integer degree allowance. -/
theorem degreeOneCoupledPolynomial_natDegree {m : ℕ} (hm : 1≤m)
    (N : ℕ) (γ τ b f ω A B : ℝ) :
    (degreeOneCoupledPolynomial N m γ τ b f ω A B).natDegree≤m+1+18*(N-1) := by
  unfold degreeOneCoupledPolynomial
  have hh := natDegree_mul_le (p:=(X:ℝ[X])^(m-1))
    (q:=nearOneCoupledPolynomial N γ τ b f ω A B)
  rw [natDegree_X_pow] at hh
  have hd := nearOneCoupledPolynomial_natDegree N γ τ b f ω A B
  omega

/-- The source low profile selects the degree-one completion exactly when ℓ=1. -/
def completedLowProfile (ℓ : ℕ) (γ c f x : ℝ) : ℝ :=
  if ℓ=1 then degreeOneProfile γ c x else lowProfile ℓ γ f x

/-- Both low branches give an ordinary polynomial, with a shared high arm. -/
def completedCoupledPolynomial (ℓ N m : ℕ) (γ a b c fL f A B ω : ℝ) : ℝ[X] :=
  if ℓ=1 then degreeOneCoupledPolynomial N m γ (c*a*(1+γ)/γ) b f ω A B
  else coupledQPolynomial ℓ N m γ a b fL f A B ω

/-- Exact source polynomial evaluation for either prescribed low branch. -/
theorem completedCoupledPolynomial_eval {ℓ N m : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    (hm : 1≤m) (hdegree : 4*(ℓ-1)≤m) {γ a b c p fL f A B ω : ℝ}
    (hγ : 0<γ) (hγ1 : γ<1) (hc : 0<c) (ha : 0<a) (hap : a≤p) (hpb : p≤b) :
    (completedCoupledPolynomial ℓ N m γ a b c fL f A B ω).eval p =
      p^((m:ℝ)+γ)*(A*completedLowProfile ℓ γ c fL (a/p)*(1-endpointProfile N 6 1 (p/b))+
        B*highProfile N (1-γ) f ω (p/b)+ω*(1-B)*endpointProfile N 6 (1-γ) (p/b)) := by
  by_cases hℓ1 : ℓ=1
  · simp only [completedCoupledPolynomial,completedLowProfile,hℓ1,if_true]
    exact degreeOneCoupledPolynomial_eval hN hm hγ hγ1 hc ha.le (ha.trans_le hap) hpb
  · simp only [completedCoupledPolynomial,completedLowProfile,hℓ1,if_false]
    exact coupledQPolynomial_eval hℓ hN hdegree hγ hγ1 ha hap hpb

theorem completedCoupledPolynomial_natDegree {m : ℕ} (hm : 1≤m)
    (ℓ N : ℕ) (γ a b c fL f A B ω : ℝ) :
    (completedCoupledPolynomial ℓ N m γ a b c fL f A B ω).natDegree≤m+1+18*(N-1) := by
  unfold completedCoupledPolynomial
  split
  · exact degreeOneCoupledPolynomial_natDegree hm N γ (c*a*(1+γ)/γ) b f ω A B
  · exact coupledQPolynomial_natDegree ℓ N m γ a b fL f A B ω

end Renyi
