import Renyi.NearOneMean
import Renyi.NearOneVariance
import Renyi.CoupledCountVariance

/-! Exact mean identities for the actual random-pilot near-one estimator. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

omit [IsProbabilityMeasure μ] in
theorem poisson_selected_mean (Y N : Ω→ℕ) (pilotLam lam : ℝ≥0)
    (hY : MeasurePreserving Y μ (poissonMeasure pilotLam))
    (hN : MeasurePreserving N μ (poissonMeasure lam)) (hind : IndepFun Y N μ)
    (T : ℝ) (f : ℕ→ℝ) (hf : Integrable f (poissonMeasure lam)) :
    Integrable (fun w => if (Y w:ℝ)≤T then f (N w) else 0) μ ∧
      (∫ w, (if (Y w:ℝ)≤T then f (N w) else 0) ∂μ)=
        poissonLowerMass pilotLam T*(∫ j,f j ∂poissonMeasure lam) := by
  let I : ℕ→ℝ := fun j => if (j:ℝ)≤T then 1 else 0
  have hi : Integrable (I∘Y) μ := hY.integrable_comp_of_integrable
    (poisson_pilot_switch_integrable pilotLam T 1)
  have hfi : Integrable (f∘N) μ := hN.integrable_comp_of_integrable hf
  have hind' : IndepFun (I∘Y) (f∘N) μ :=
    hind.comp (measurable_of_countable I) (measurable_of_countable f)
  have heq : (fun w => if (Y w:ℝ)≤T then f (N w) else 0)=(I∘Y)*(f∘N) := by
    funext w
    dsimp [I]
    split_ifs <;> simp
  rw [heq]
  refine ⟨hind'.integrable_mul hi hfi,?_⟩
  rw [hind'.integral_mul_eq_mul_integral hi.aestronglyMeasurable hfi.aestronglyMeasurable,
    hY.hasLaw.integral_comp (measurable_of_countable I).aestronglyMeasurable,
    hN.hasLaw.integral_comp (measurable_of_countable f).aestronglyMeasurable]
  have hI := poisson_pilot_switch_integral pilotLam T 1
  change (∫ j,I j ∂poissonMeasure pilotLam)=poissonLowerMass pilotLam T*1 at hI
  rw [hI,mul_one]

theorem nearOneGammaResidual_mean {n t beta omega : ℝ} (hn : 0<n) (ht : 0<t)
    (lam : ℝ≥0) :
    (∫ j,nearOneGammaResidual n t beta omega j ∂poissonMeasure lam)=
      omega*analyticMean lam (1+beta)/n^(1+beta)-t^beta*(lam:ℝ)/n := by
  simp_rw [nearOneGammaResidual_probability_identity hn ht]
  have hG := ((analyticCount_memLp lam (1+beta)).integrable one_le_two).const_mul omega
  have hN := ((poisson_nat_memLp lam).integrable one_le_two).const_mul (t^beta)
  rw [integral_sub (hG.div_const _) (hN.div_const _),integral_div,integral_div,
    integral_const_mul,integral_const_mul,poisson_nat_mean]
  rfl

omit [IsProbabilityMeasure μ] in
theorem near_one_hybrid_coordinate_mean (Y N : Ω→ℕ) (pilotLam lam : ℝ≥0)
    (hY : MeasurePreserving Y μ (poissonMeasure pilotLam))
    (hN : MeasurePreserving N μ (poissonMeasure lam)) (hind : IndepFun Y N μ)
    {n t beta omega T p : ℝ} (hn : 0<n) (ht : 0<t) (hlam : (lam:ℝ)=n*p)
    (d : ℕ) (c : ℕ→ℝ) :
    Integrable (fun w => nearOneHybridResidual n t beta omega T d c (Y w,N w)) μ ∧
      (∫ w,nearOneHybridResidual n t beta omega T d c (Y w,N w) ∂μ)=
        poissonLowerMass pilotLam T*(polynomialOfCoefficients d c).eval p+
        (1-poissonLowerMass pilotLam T)*
          (omega*analyticMean lam (1+beta)/n^(1+beta)-t^beta*p) := by
  let F := factorialStatistic d (fun j => c j/n^j)
  let G := nearOneGammaResidual n t beta omega
  have hf : Integrable F (poissonMeasure lam) := (poisson_polynomial_memLp lam d _).integrable one_le_two
  have hg : Integrable G (poissonMeasure lam) := (nearOneGammaResidual_memLp lam n t beta omega).integrable one_le_two
  have hsf := poisson_selected_mean Y N pilotLam lam hY hN hind T F hf
  have hsg := poisson_selected_mean Y N pilotLam lam hY hN hind T G hg
  have hgN : Integrable (G∘N) μ := hN.integrable_comp_of_integrable hg
  have heq : (fun w => nearOneHybridResidual n t beta omega T d c (Y w,N w))=
      fun w => G (N w)+((if (Y w:ℝ)≤T then F (N w) else 0)-
        (if (Y w:ℝ)≤T then G (N w) else 0)) := by rfl
  rw [heq]
  refine ⟨hgN.add (hsf.1.sub hsg.1),?_⟩
  have hadd := integral_add (f:=fun w => G (N w))
    (g:=fun w => (if (Y w:ℝ)≤T then F (N w) else 0)-(if (Y w:ℝ)≤T then G (N w) else 0))
    hgN (hsf.1.sub hsg.1)
  rw [hadd]
  have hsub := integral_sub (f:=fun w => if (Y w:ℝ)≤T then F (N w) else 0)
    (g:=fun w => if (Y w:ℝ)≤T then G (N w) else 0) hsf.1 hsg.1
  rw [hsub,hsf.2,hsg.2]
  have hgi := hN.hasLaw.integral_comp (measurable_of_countable G).aestronglyMeasurable
  change (∫ w,G (N w) ∂μ)=(∫ j,G j ∂poissonMeasure lam) at hgi
  rw [hgi,poisson_scaled_polynomial_integral lam d c n p hn.ne' hlam]
  have hgmean := nearOneGammaResidual_mean hn ht lam (beta:=beta) (omega:=omega)
  change (∫ j,G j ∂poissonMeasure lam)=_ at hgmean
  rw [hgmean,hlam]
  field_simp
  ring


/-- Exact expectation of the actual hybrid and affine anchor. The residual
polynomial is converted back to its uncentered target inside the finite sum. -/
theorem near_one_hybrid_mean {ι : Type*} [Fintype ι]
    (Y N : ι→Ω→ℕ) (pilotLam lam : ι→ℝ≥0)
    (hY : ∀i,MeasurePreserving (Y i) μ (poissonMeasure (pilotLam i)))
    (hN : ∀i,MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hind : ∀i,IndepFun (Y i) (N i) μ)
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    {n t beta omega T q repair : ℝ} (hn : 0<n) (ht : 0<t)
    (p : ι→ℝ) (hp : ∑i,p i=1) (hlam : ∀i,(lam i:ℝ)=n*p i)
    (d : ℕ) (c : ℕ→ℝ) :
    Integrable (nearOneHybridStatistic N Y n t beta omega T q repair d c) μ ∧
      (∫ w,nearOneHybridStatistic N Y n t beta omega T q repair d c w ∂μ)=
        repair+∑i,(poissonLowerMass (pilotLam i) T*((polynomialOfCoefficients d c).eval (p i)+t^beta*p i)+
          (1-poissonLowerMass (pilotLam i) T)*omega*analyticMean (lam i) (1+beta)/n^(1+beta)) := by
  let H : ι→Ω→ℝ := fun i w => nearOneHybridResidual n t beta omega T d c (Y i w,N i w)
  have hcoord (i : ι) := near_one_hybrid_coordinate_mean (Y i) (N i) (pilotLam i) (lam i)
    (hY i) (hN i) (hind i) (beta:=beta) (omega:=omega) (T:=T) hn ht (hlam i) d c
  have hsum : ∑i,(lam i:ℝ)=n := by simp_rw [hlam]; rw [←Finset.mul_sum,hp,mul_one]
  have hanchor := common_affine_anchor_moments N lam hN hpair hn hsum (q-t^beta)
  have hH : Integrable (fun w => ∑i,H i w) μ := integrable_finset_sum _ (fun i _ => (hcoord i).1)
  have hInt : Integrable (nearOneHybridStatistic N Y n t beta omega T q repair d c) μ :=
    ((integrable_const (repair+t^beta)).add hH).add (hanchor.1.integrable one_le_two)
  refine ⟨hInt,?_⟩
  change (∫ w,(repair+t^beta)+(∑i,H i w)+poissonAffineAnchor N n (q-t^beta) w ∂μ)=_
  rw [integral_add (f:=fun w => (repair+t^beta)+∑i,H i w)
    (g:=fun w => poissonAffineAnchor N n (q-t^beta) w)
    ((integrable_const (repair+t^beta)).add hH) (hanchor.1.integrable one_le_two)]
  rw [hanchor.2.1,add_zero,integral_add (f:=fun _ => repair+t^beta) (g:=fun w => ∑i,H i w) (integrable_const (repair+t^beta)) hH,
    integral_const,integral_finset_sum Finset.univ (fun i _ => (hcoord i).1)]
  simp only [measureReal_univ_eq_one,one_smul]
  simp_rw [(hcoord _).2]
  have heq : (∑i,(poissonLowerMass (pilotLam i) T*(polynomialOfCoefficients d c).eval (p i)+
      (1-poissonLowerMass (pilotLam i) T)*(omega*analyticMean (lam i) (1+beta)/n^(1+beta)-t^beta*p i)))=
    (∑i,(poissonLowerMass (pilotLam i) T*((polynomialOfCoefficients d c).eval (p i)+t^beta*p i)+
      (1-poissonLowerMass (pilotLam i) T)*omega*analyticMean (lam i) (1+beta)/n^(1+beta)))-t^beta := by
    have hmass : t^beta = ∑i,t^beta*p i := by rw [←Finset.mul_sum,hp,mul_one]
    conv_rhs => arg 2; rw [hmass]
    rw [←Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i _
    ring
  rw [heq]
  ring

end Renyi
