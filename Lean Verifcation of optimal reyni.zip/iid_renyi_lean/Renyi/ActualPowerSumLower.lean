import Renyi.ActualCoupledPolynomial
import Renyi.CompletedPowerSumLower

/-! The actual source polynomial has a summed lower certificate with no geometry premises. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- Oracle mean before the one common scalar rescaling and deterministic correction. -/
def actualCoupledHybridMean {k : ℕ} (p : Simplex k) (light : Fin k→Bool)
    (alpha eps Ch D cb lambda CL cL fL f M : ℝ) : ℝ :=
  ∑ i, if light i then
    (actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).eval (p.mass i)
    else Real.exp (-upperE0 k alpha eps Ch/8)*(p.mass i)^alpha

/-- The complete forward bonus in the source deterministic margin. -/
def actualForwardBonus {k : ℕ} (p : Simplex k) (alpha eps D cb CL cL : ℝ) : ℝ :=
  ∑ i, (p.mass i)^alpha*min
    ((upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2*(p.mass i/upperB k alpha eps D cb CL cL)) 1

/-- The actual finite-sum mean retains a common lower baseline and forward gain.
All degree, capacity and degree-energy conditions follow from the source parameters. -/
theorem actualCoupledPolynomial_power_sum_lower {eps fL f qL qH M lambda : ℝ}
    (heps : 0<eps) (hfL : 0<fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hM : 1≤M) (hlambda : 0<lambda) (hlambdaC : lambda≤Real.exp (-2*coupledProfileConstant))
    (hqL : Real.exp (-(eps/2))<qL) (hqLf : qL<fL)
    (hqH : Real.exp (-7*(eps/2)/8)<qH) (hqHf : qH<f) :
    ∃ C c : ℝ, 0≤C ∧ 0<c ∧ ∀ (k : ℕ) (alpha Ch D cb CL cL : ℝ),
      0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 →
      0≤Ch → 0<D → 0<cb → 1≤CL → 0<cL → 1≤cb*CL →
      ∀ (p : Simplex k) (light : Fin k→Bool),
        (∀ i, light i=true → p.mass i≤upperB k alpha eps D cb CL cL) →
      Real.exp (-upperE0 k alpha eps Ch)*Real.exp (-C*(fractionalPart alpha*(1-fractionalPart alpha)))*powerSum p alpha+
        c*Real.exp (-upperE0 k alpha eps Ch)*(∑ i, if upperA k alpha eps Ch D cb lambda CL cL≤p.mass i then
          (p.mass i)^alpha*min
            ((upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)^2*(p.mass i/upperB k alpha eps D cb CL cL)) 1 else 0)≤
        actualCoupledHybridMean p light alpha eps Ch D cb lambda CL cL fL f M+
          (k:ℝ)*(100:ℝ)^(upperOrderFloor alpha+1)*(upperA k alpha eps Ch D cb lambda CL cL)^alpha := by
  have hlam1 := coupled_capacity_lambda_le_one hlambdaC
  obtain ⟨C,c,hC,hc,hbound⟩ := completedCoupledPolynomial_power_sum_lower
    hfL hfL1 hf hf1 (show 0<eps/2 by positivity) heps hM (show 0<lambda/16 by positivity)
    (show lambda/16≤1 by linarith only [hlam1]) hqL hqLf hqH hqHf
  refine ⟨C,c,hC,hc,?_⟩
  intro k alpha Ch D cb CL cL hk ha hg hg1 hCh hD hcb hCL hcL hcbCL p light hlight
  have ha1 : 1<alpha := by linarith only [ha]
  have hgeom := upper_actual_count_geometry hk ha hg hg1 heps hCh hD hcb hlambda
    (by linarith only [hlam1] : lambda≤4) hCL hcL hcbCL
  dsimp only at hgeom
  have hEmin : eps/2≤upperE0 k alpha eps Ch := by
    have hlow := (upper_reserved_interval (k:=k) ha1 hg hg1 heps hCh).1
    nlinarith only [hlow,mul_nonneg heps.le (show 0≤alpha-3/2 by linarith only [ha])]
  have hE : 0<upperE0 k alpha eps Ch := (show 0<eps/2 by positivity).trans_le hEmin
  have hz := upperOverlapZ_spec hg hg1 hE
  have henergy := upperLowResolution_energy (k:=k) ha hg hg1 heps hCh
  have hcap := upper_actual_profile_capacity hk ha1 hg hg1 heps hCh hD hcb hlambda hlambdaC hCL hcL
  dsimp only at hcap
  have hbound' := hbound k (upperLowResolution alpha)
    (upperDegree alpha CL cL (rootMultiplier k alpha eps)) (upperOrderFloor alpha)
    (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))
    (upperE0 k alpha eps Ch) (upperA k alpha eps Ch D cb lambda CL cL) (upperB k alpha eps D cb CL cL)
    p.mass light hgeom.2.2.2.1 hgeom.2.2.2.2.1 (upperOrderFloor_one_le ha1) hgeom.2.2.2.2.2.2.1
    hg hg1 hz.1.1 hz.1.2 hEmin hz.2 henergy hgeom.1 hgeom.2.1 p.nonneg hlight
    (by convert hcap.1 using 1; ring) (by convert hcap.2 using 1; ring)
  have halpha : (upperOrderFloor alpha:ℝ)+fractionalPart alpha=alpha := by
    rw [fractionalPart_eq_upperOrderFloor ha1]
    ring
  simpa only [halpha,actualCoupledHybridMean,actualCoupledPolynomial,powerSum] using hbound'

end Renyi
