import Renyi.NearOneHybridMean

/-! Mean calibration of the actual root-parameter near-one estimator. -/
noncomputable section
open scoped BigOperators NNReal
open Polynomial MeasureTheory ProbabilityTheory
namespace Renyi
set_option maxHeartbeats 700000

def actualNearOneExpectedMean {k : ℕ} (N : ℕ)
    (alpha eps Ch D cb lambda CL cL c M cw f cu u0 cp B repair : ℝ) (p : Simplex k) : ℝ :=
  let n := upperSample k alpha eps D
  let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
    (upperRescaling k alpha eps cu u0)
  let omega := upperOmega k alpha eps Ch cw
  repair+∑i,(poissonLowerMass (Real.toNNReal (cp*n*p.mass i)) (cp*B*alpha)*P.eval (p.mass i)+
    (1-poissonLowerMass (Real.toNNReal (cp*n*p.mass i)) (cp*B*alpha))*
      omega*analyticMean (Real.toNNReal (n*p.mass i)) alpha/n^alpha)

theorem actual_near_one_expected_mean_uniform
    {eps cb lambda CL cmin q Q M cw f cu u0 B eta : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hf : 0≤f) (hf1 : f≤1)
    (hcu : 0≤cu) (hu0 : 0<u0) (hB : 16≤B) (hCLB : 2*B≤cb*CL)
    (heta : 0<eta) (hlarge : Real.exp (-B/2)≤eta) :
    ∃ K cp0 : ℝ, 0<K ∧ 1≤cp0 ∧ ∀ cp : ℝ, cp0≤cp → ∀ cL : ℝ, 0<cL →
      ∀ (k N : ℕ) (alpha Ch D c repair : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) → ∀ p : Simplex k,
      |actualNearOneExpectedMean N alpha eps Ch D cb lambda CL cL c M cw f cu u0 cp B repair p-
        upperOmega k alpha eps Ch cw*(∑i,p.mass i^alpha)|≤
        |repair|+(k:ℝ)*K*(alpha-1)*(upperB k alpha eps D cb CL cL/(N:ℝ)^2)^alpha+
          (2*cu+3*eta)*(alpha-1)*(∑i,p.mass i^alpha) := by
  obtain ⟨K,cpP,hK,hcpP,hpoly⟩ := actual_near_one_polynomial_mean_uniform heps hcb hlambda hCL hcmin hq hQ hM hcw hcw1 hf hf1 hcu hu0 hCLB heta
  let cp0 := max cpP (max 1 (-Real.log eta))
  have hcp01 : 1≤cp0 := (le_max_left _ _).trans (le_max_right _ _)
  refine ⟨K,cp0,hK,hcp01,?_⟩
  intro cp hcp cL hcL k N alpha Ch D c repair hk ha ha1 hCh hD hc hc1 hNlo hNhi p
  let n := upperSample k alpha eps D
  let b := upperB k alpha eps D cb CL cL
  let t := b/(N:ℝ)^2
  let omega := upperOmega k alpha eps Ch cw
  let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
    (upperRescaling k alpha eps cu u0)
  let s : Fin k→ℝ := fun i => poissonLowerMass (Real.toNNReal (cp*n*p.mass i)) (cp*B*alpha)
  let G : Fin k→ℝ := fun i => omega*analyticMean (Real.toNNReal (n*p.mass i)) alpha/n^alpha
  let target : Fin k→ℝ := fun i => omega*p.mass i^alpha
  let weight : Fin k→ℝ := fun i => p.mass i^alpha
  have hbeta : 0<alpha-1 := sub_pos.mpr ha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order ha ha1).2];exact hbeta
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order ha ha1).2];linarith only [ha1]
  have hn : 0<n := upperSample_pos hk ha hg hg1 hD
  have hE := upper_reserved_interval (k:=k) ha hg hg1 heps hCh
  have hE0 : 0<upperE0 k alpha eps Ch := (mul_pos heps hbeta).trans_le hE.1
  have hw : 0≤omega := (Real.exp_pos _).le
  have hw1 : omega≤1 := Real.exp_le_one_iff.mpr (by nlinarith only [hcw,hE0])
  have hcp1 : 1≤cp := hcp01.trans hcp
  have hcpPoly : cpP≤cp := (le_max_left _ _).trans hcp
  have hsmall : Real.exp (-cp)≤eta := by
    rw [←Real.exp_log heta]
    apply Real.exp_le_exp.mpr
    have hh : -Real.log eta≤cp := ((le_max_right _ _).trans (le_max_right _ _)).trans hcp
    linarith only [hh]
  have hQbound (i) : s i*|P.eval (p.mass i)-target i|≤K*(alpha-1)*t^alpha+
      ((2*cu+eta)*(alpha-1))*weight i := by
    have hh := hpoly cp hcpPoly cL hcL k N alpha Ch D c (p.mass i) hk ha ha1 hCh hD hc hc1 hNlo hNhi (p.nonneg i)
    exact hh
  have hGbound (i) : (1-s i)*|G i-target i|≤(2*eta*(alpha-1))*weight i := by
    have hh := near_one_gamma_coordinate_mean_error hn (p.nonneg i) hbeta
      (by linarith only [ha1] : alpha-1≤1/2) hw hw1 hcp1 hB heta.le hlarge hsmall
    simpa only [show 1+(alpha-1)=alpha by ring] using hh
  have hmix := hybrid_mixture_mean_error s (fun i => P.eval (p.mass i)) G target weight
    (repair:=repair) (fun i => poissonLowerMass_nonneg _ _) (fun i => poissonLowerMass_le_one _ _)
    hQbound hGbound
  have htarget : (∑i,target i)=omega*(∑i,p.mass i^alpha) := by dsimp [target];rw [Finset.mul_sum]
  rw [htarget] at hmix
  convert hmix using 1
  · dsimp [actualNearOneExpectedMean,s,G,P,omega,n]
    congr 2
    congr 1
    apply Finset.sum_congr rfl
    intro i _
    ring
  · dsimp [t,b,weight]
    simp only [Fintype.card_fin]
    ring

end Renyi
