import Renyi.HeavyNorm

/-! Uniform interior margins for the actual omega-scaled heavy statistic. -/
set_option maxHeartbeats 800000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def omegaHeavyDistance (c0 : ℝ) : ℝ := min (c0 / 2) (1 - c0)
def omegaHeavyTolerance (eps c0 : ℝ) : ℝ := min (1 / 16) (omegaHeavyDistance c0 * eps / 12)
def omegaHeavyMargin (eps c0 : ℝ) : ℝ := 1 - Real.exp (-(omegaHeavyDistance c0 * eps / 2))

private theorem omegaHeavy_basic_bounds {eps c0 : ℝ}
    (heps : 0 < eps) (hc0 : 0 < c0) (hc01 : c0 < 1) :
    0 < omegaHeavyDistance c0 ∧ omegaHeavyDistance c0 ≤ c0 / 2 ∧
      omegaHeavyDistance c0 ≤ 1 - c0 ∧
      0 < omegaHeavyTolerance eps c0 ∧ omegaHeavyTolerance eps c0 < 1 / 8 ∧
      omegaHeavyTolerance eps c0 ≤ omegaHeavyDistance c0 * eps / 12 ∧
      0 < omegaHeavyMargin eps c0 := by
  have hd : 0 < omegaHeavyDistance c0 := lt_min (by positivity) (by linarith)
  have ht : 0 < omegaHeavyTolerance eps c0 := lt_min (by norm_num) (by positivity)
  have ht1 : omegaHeavyTolerance eps c0 < 1 / 8 :=
    (min_le_left _ _).trans_lt (by norm_num)
  have hc : 0 < omegaHeavyMargin eps c0 := by
    unfold omegaHeavyMargin
    apply sub_pos.mpr
    exact Real.exp_lt_one_iff.mpr (neg_neg_of_pos (div_pos (mul_pos hd heps) (by norm_num)))
  exact ⟨hd, min_le_left _ _, min_le_right _ _, ht, ht1, min_le_right _ _, hc⟩

private theorem log_one_sub_two_mul_lower {t : ℝ} (ht : 0 < t) (ht1 : t < 1 / 8) :
    -4 * t ≤ Real.log (1 - 2 * t) := by
  have hx : 0 < 1 - 2 * t := by linarith
  have h := Real.log_le_sub_one_of_pos (inv_pos.mpr hx)
  rw [Real.log_inv] at h
  have hi : (1 - 2 * t)⁻¹ - 1 ≤ 4 * t := by
    apply (sub_le_iff_le_add).2
    apply (inv_le_iff_one_le_mul₀ hx).2
    nlinarith
  linarith

/-- Scalar margins with the same constants for every a at least three halves. -/
theorem omega_heavy_scalar_margins {eps c0 a E0 : ℝ}
    (heps : 0 < eps) (hc0 : 0 < c0) (hc01 : c0 < 1) (ha : 3 / 2 ≤ a)
    (hE0low : eps * (a - 1) ≤ E0) (hE0high : E0 ≤ 2 * eps * (a - 1)) :
    let kappa := Real.exp (-(2 * eps * (a - 1)))
    let omega := Real.exp (-c0 * E0)
    let t := omegaHeavyTolerance eps c0
    let c := omegaHeavyMargin eps c0
    kappa + c * kappa ≤ omega * (1 - 2 * t) ^ a ∧
      omega * (1 + 2 * t) ^ a ≤ 1 - c * kappa := by
  dsimp only
  obtain ⟨hd, hdc, hd1, ht, ht1, htbound, hc⟩ := omegaHeavy_basic_bounds heps hc0 hc01
  let d := omegaHeavyDistance c0
  let t := omegaHeavyTolerance eps c0
  let E := 2 * eps * (a - 1)
  have hE : 0 < E := by dsimp [E]; exact mul_pos (by positivity) (by linarith)
  have hEeps : eps ≤ E := by dsimp [E]; nlinarith
  have herror : 4 * t * a ≤ d * E / 2 := by
    have haa : a ≤ 3 * (a - 1) := by linarith
    have hm := mul_le_mul_of_nonneg_left htbound (by nlinarith : 0 ≤ 12 * (a - 1))
    dsimp [E, d, t] at *
    nlinarith
  have hlo := log_one_sub_two_mul_lower ht ht1
  have hhi : Real.log (1 + 2 * t) ≤ 4 * t := by
    have h := Real.log_le_sub_one_of_pos (by positivity : 0 < 1 + 2 * t)
    linarith
  have hlowexp : -E + d * E / 2 ≤ -c0 * E0 + a * Real.log (1 - 2 * t) := by
    have hlog := mul_le_mul_of_nonneg_left hlo (by linarith : 0 ≤ a)
    have hmean := mul_le_mul_of_nonneg_left hE0high hc0.le
    have hdist := mul_le_mul_of_nonneg_right hd1 hE.le
    dsimp [E, d] at *
    nlinarith
  have hhighexp : -c0 * E0 + a * Real.log (1 + 2 * t) ≤ -d * E / 2 := by
    have hlog := mul_le_mul_of_nonneg_left hhi (by linarith : 0 ≤ a)
    have hmean := mul_le_mul_of_nonneg_left hE0low hc0.le
    have hdist := mul_le_mul_of_nonneg_right hdc hE.le
    dsimp [E, d] at *
    nlinarith
  have hcoeflow : Real.exp (-E) * Real.exp (d * E / 2) ≤
      Real.exp (-c0 * E0) * (1 - 2 * t) ^ a := by
    rw [Real.rpow_def_of_pos (by linarith : 0 < 1 - 2 * t), ← Real.exp_add, ← Real.exp_add]
    exact Real.exp_le_exp.mpr (by nlinarith [hlowexp])
  have hcoefhigh : Real.exp (-c0 * E0) * (1 + 2 * t) ^ a ≤ Real.exp (-d * E / 2) := by
    rw [Real.rpow_def_of_pos (by positivity : 0 < 1 + 2 * t), ← Real.exp_add]
    exact Real.exp_le_exp.mpr (by nlinarith [hhighexp])
  have hmargin : 1 + omegaHeavyMargin eps c0 ≤ Real.exp (d * E / 2) := by
    have hpair := Real.add_one_le_exp (d * eps / 2)
    have hpair' := Real.add_one_le_exp (-(d * eps / 2))
    have hmon : Real.exp (d * eps / 2) ≤ Real.exp (d * E / 2) :=
      Real.exp_le_exp.mpr (by nlinarith [mul_le_mul_of_nonneg_left hEeps hd.le])
    unfold omegaHeavyMargin
    dsimp [d] at *
    nlinarith
  have hupper : Real.exp (-d * E / 2) ≤ 1 - omegaHeavyMargin eps c0 := by
    unfold omegaHeavyMargin
    simp only [sub_sub_cancel]
    apply Real.exp_le_exp.mpr
    have hdist := mul_le_mul_of_nonneg_left hEeps hd.le
    dsimp [d] at *
    nlinarith
  have hkappa : Real.exp (-E) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
  constructor
  · change Real.exp (-E) + omegaHeavyMargin eps c0 * Real.exp (-E) ≤
      Real.exp (-c0 * E0) * (1 - 2 * t) ^ a
    calc
      _ = Real.exp (-E) * (1 + omegaHeavyMargin eps c0) := by ring
      _ ≤ Real.exp (-E) * Real.exp (d * E / 2) :=
        mul_le_mul_of_nonneg_left hmargin (Real.exp_pos (-E)).le
      _ ≤ _ := hcoeflow
  · change Real.exp (-c0 * E0) * (1 + 2 * t) ^ a ≤
      1 - omegaHeavyMargin eps c0 * Real.exp (-E)
    have hm := mul_le_mul_of_nonneg_left hkappa hc.le
    exact hcoefhigh.trans (hupper.trans (by linarith))

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

/-- Actual omega-heavy concentration with an accuracy-dependent uniform
interior margin, for the same Gamma-count statistic as in the manuscript. -/
theorem omega_heavy_concentration {eps c0 rho : ℝ}
    (heps : 0 < eps) (hc0 : 0 < c0) (hc01 : c0 < 1)
    (hrho : 0 < rho) (hrho1 : rho < 1) :
    ∃ c B : ℝ, 0 < c ∧ 1 ≤ B ∧ ∀ (k : ℕ) (a E0 : ℝ), 3 / 2 ≤ a →
      eps * (a - 1) ≤ E0 → E0 ≤ 2 * eps * (a - 1) →
      ∀ (N : Fin k → Ω → ℕ) (lam : Fin k → ℝ≥0),
        (∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i))) →
        (∀ i, B * a ≤ (lam i : ℝ)) →
        let kappa := Real.exp (-(2 * eps * (a - 1)))
        let omega := Real.exp (-c0 * E0)
        1 - rho ≤ μ.real {w | (kappa + c * kappa) * ∑ i, (lam i : ℝ) ^ a ≤
          omega * ∑ i, analyticCount a (N i w) ∧
          omega * (∑ i, analyticCount a (N i w)) ≤ (1 - c * kappa) * ∑ i, (lam i : ℝ) ^ a} := by
  obtain ⟨_, _, _, ht, ht1, _, hc⟩ := omegaHeavy_basic_bounds heps hc0 hc01
  obtain ⟨B, hB, hconc⟩ := high_mean_gamma_concentration (μ := μ) ht ht1 hrho hrho1
  refine ⟨omegaHeavyMargin eps c0, B, hc, hB, ?_⟩
  intro k a E0 ha hElow hEhigh N lam hLaw hmeans
  have h := hconc k a ha N lam hLaw hmeans
  have hscalar := omega_heavy_scalar_margins heps hc0 hc01 ha hElow hEhigh
  have hS : 0 ≤ ∑ i, (lam i : ℝ) ^ a := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (lam i).coe_nonneg _)
  apply h.trans
  refine measureReal_mono ?_ (by finiteness)
  intro w hw
  dsimp only at hw ⊢ hscalar
  constructor
  · have hleft := mul_le_mul_of_nonneg_right hscalar.1 hS
    have hmain := mul_le_mul_of_nonneg_left hw.1 (Real.exp_pos (-c0 * E0)).le
    nlinarith
  · have hright := mul_le_mul_of_nonneg_right hscalar.2 hS
    have hmain := mul_le_mul_of_nonneg_left hw.2 (Real.exp_pos (-c0 * E0)).le
    nlinarith

end Renyi
