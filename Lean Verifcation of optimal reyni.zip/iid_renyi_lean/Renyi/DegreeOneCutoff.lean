import Renyi.DegreeOneLowBounds
import Renyi.CoupledCutoff

/-! Actual cutoff cancellation for the degree-one low arm. -/
noncomputable section
namespace Renyi.DegreeOneCompletion

theorem coupledProfiles_cutoff_lower {ℓ N : ℕ} (hN : 0 < N)
    {γ z E M fL f x y : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) (hE : 0 ≤ E) (hM : 1 ≤ M)
    (hzE : z ≤ Real.exp (-E)) (hy : 0 ≤ y) (hy1 : y ≤ 1) :
    let A := overlapA γ z*Real.exp (-M*γ)
    let B := overlapB γ z*Real.exp (-M*(1-γ))
    let ω := Real.exp (-E/8)
    A*lowProfile ℓ γ fL x + B*highProfile N (1-γ) f ω y -
      max (A*lowProfile ℓ γ fL x-1+overlapB γ z) 0 * endpointProfile N 6 1 y ≤
    A*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y) +
      B*highProfile N (1-γ) f ω y + ω*(1-B)*endpointProfile N 6 (1-γ) y := by
  dsimp only
  apply cutoff_replacement_lower
    (endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1).1
    (endpointProfile_exponent_antitone hN (by norm_num) (by linarith) (by linarith) hy hy1)
    (overlap_coefficients_unit hγ hγ1 hz hz1).2.2.2.le
    (overlap_damped_complement_cancellation hγ hγ1 hz hz1 hE hM hzE)


theorem lowProfile_reverse_capacity {ℓ : ℕ} (hℓ : 0 < ℓ)
    {γ z M f x Y : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) (hM : 0 ≤ M) (hf : 0 ≤ f) (hf1 : f < 1)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) (hY : 0 < Y)
    (hcap : (x)*Y ≤ Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ f x ≤
      (1-overlapB γ z)*((1-γ)/Y)^γ := by
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := (lowProfile_upper_power hℓ hγ hγ1.le hf hf1 hx hx1).trans
    (reverse_capacity_power hγ hγ1 (by positivity) hY hz hcap)
  have hu0 := (lowProfile_range hℓ hγ hf hf1 hx hx1).1
  have hA := mul_le_of_le_one_right hc.1.le (Real.exp_le_one_iff.mpr (by nlinarith : -M*γ≤0))
  have hmul := mul_le_mul hA hu hu0 hc.1.le
  have he := (overlap_endpoints hγ hγ1 hz hz1).1
  calc
    _ ≤ overlapA γ z*(z^(1/(1-γ))*((1-γ)/Y)^γ) := hmul
    _ = (overlapA γ z*z^(1/(1-γ)))*((1-γ)/Y)^γ := by ring
    _ = _ := by rw [show overlapA γ z*z^(1/(1-γ))=1-overlapB γ z by linarith only [he]]


theorem coupledProfiles_cutoff_loss {ℓ N : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    {γ z E M f x y : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hz : 0 < z) (hz1 : z < 1) (hzE : z ≤ Real.exp (-E))
    (hM : 0 ≤ M) (hf : 0 ≤ f) (hf1 : f < 1)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) (hy : 0 < y) (hy1 : y ≤ 1)
    (hcap : (x)*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    max ((overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ f x-1+overlapB γ z) 0 *
      endpointProfile N 6 1 y ≤ Real.exp (Real.log 12+1)*Real.exp (-E)*(γ*(1-γ)) := by
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hr : 0 ≤ 1-overlapB γ z := sub_nonneg.mpr hc.2.2.2.le
  have hY : 0 < (N:ℝ)^2*y := by positivity
  have hu := lowProfile_reverse_capacity hℓ hγ hγ1 hz hz1 hM hf hf1 hx hx1 hY hcap
  have hH := endpointProfile_upper_power hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy.le hy1
  simp only [Real.rpow_one, mul_one] at hH
  have hloss := cutoff_power_loss hγ hγ1 hr (Real.exp_pos (Real.log 12+1)).le hY
    (endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy.le hy1).1 hH hu
  have hrex := (overlap_complement_le_parameter hγ hγ1 hz hz1).trans hzE
  have hupper := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left hrex (Real.exp_pos (Real.log 12+1)).le)
    (mul_nonneg hγ.le (by linarith : 0≤1-γ))
  have heq : (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ f x-(1-overlapB γ z) =
      (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ f x-1+overlapB γ z := by ring
  rw [heq] at hloss
  exact hloss.trans hupper


end Renyi.DegreeOneCompletion
