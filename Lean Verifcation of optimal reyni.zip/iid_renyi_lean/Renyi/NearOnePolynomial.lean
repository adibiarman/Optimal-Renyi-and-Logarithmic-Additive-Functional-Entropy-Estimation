import Renyi.CoupledPolynomial
import Renyi.DegreeOneProfile

/-! The exact degree-one completion of the single coupled polynomial. -/
noncomputable section
open Polynomial
namespace Renyi

/-- The reverse degree-one profile is the tangent polynomial at tau. -/
def nearOneTangentPolynomial (β τ : ℝ) : ℝ[X] :=
  C ((1+β)*τ^β)*X-C (β*τ^(1+β))

def nearOneCoupledPolynomial (N : ℕ) (β τ b f ω A B : ℝ) : ℝ[X] :=
  C A*nearOneTangentPolynomial β τ*(1-(X*endpointProfilePolynomial N 6 1).comp (C b⁻¹*X))+
  C (B/b^(1-β))*X^2*(highProfilePolynomial N (1-β) f ω).comp (C b⁻¹*X)+
  C (ω*(1-B)/b^(1-β))*X^2*(endpointProfilePolynomial N 6 (1-β)).comp (C b⁻¹*X)

lemma nearOneTangentPolynomial_eval (β τ p : ℝ) :
    (nearOneTangentPolynomial β τ).eval p=(1+β)*τ^β*p-β*τ^(1+β) := by
  simp [nearOneTangentPolynomial]


lemma tangent_normalization_identity {β c a : ℝ} (hβ : 0<β) (hc : 0<c) (ha : 0≤a) :
    a^β/degreeOneNormalizer β c=(1+β)*(c*a*(1+β)/β)^β := by
  have hp : 0<1+β := by linarith only [hβ]
  unfold degreeOneNormalizer
  rw [div_div_eq_mul_div]
  rw [Real.div_rpow (mul_nonneg (mul_nonneg hc.le ha) hp.le) hβ.le,
    Real.mul_rpow (mul_nonneg hc.le ha) hp.le,Real.mul_rpow hc.le ha,
    Real.rpow_add hp,Real.rpow_one]
  ring

/-- The degree-one completion and the actual tangent are exactly the same reverse arm. -/
theorem degreeOne_reverse_tangent {β c a p : ℝ} (hβ : 0<β) (hc : 0<c)
    (ha : 0≤a) (hp : 0<p) :
    p^(1+β)*degreeOneProfile β c (a/p)=
      (nearOneTangentPolynomial β (c*a*(1+β)/β)).eval p := by
  have hnorm := tangent_normalization_identity hβ hc ha
  have hfrac := reverse_fractional_identity 1 β ha hp
  simp only [Nat.cast_one,pow_one] at hfrac
  have hτ : 0≤c*a*(1+β)/β := by positivity
  have hτpow : (c*a*(1+β)/β)^(1+β)=(c*a*(1+β)/β)^β*(c*a*(1+β)/β) := by
    simpa only [add_comm β 1] using Real.rpow_add_one' hτ (by linarith : β+1≠0)
  unfold degreeOneProfile
  rw [nearOneTangentPolynomial_eval]
  calc
    _ = (p^(1+β)*(a/p)^β)*(1-c*(a/p))/degreeOneNormalizer β c := by ring
    _ = (a^β/degreeOneNormalizer β c)*(p-c*a) := by rw [hfrac];field_simp
    _ = _ := by rw [hnorm,hτpow];field_simp

/-- Exact polynomial identity on the complete interval, including below the lower cutoff. -/
theorem nearOneCoupledPolynomial_eval {N : ℕ} (hN : 0<N)
    {β τ b f ω A B p : ℝ} (hβ : 0<β) (hβ1 : β<1) (hb : 0<b)
    (hp : 0≤p) (hpb : p≤b) :
    (nearOneCoupledPolynomial N β τ b f ω A B).eval p =
      A*((1+β)*τ^β*p-β*τ^(1+β))*(1-endpointProfile N 6 1 (p/b))+
      p^(1+β)*(B*highProfile N (1-β) f ω (p/b)+ω*(1-B)*endpointProfile N 6 (1-β) (p/b)) := by
  have hx : 0≤p/b := div_nonneg hp hb.le
  have hx1 : p/b≤1 := (div_le_one hb).mpr hpb
  have hδ : 0<1-β := sub_pos.mpr hβ1
  have hj1 := endpointProfile_polynomial hN 6 (by norm_num : (0:ℝ)<1) hx hx1
  have hj := endpointProfile_polynomial hN 6 hδ hx hx1
  have hv := highProfile_polynomial hN hδ hx hx1 (f:=f) (ω:=ω)
  by_cases hp0 : p=0
  · subst p
    simp [nearOneCoupledPolynomial,nearOneTangentPolynomial,Real.zero_rpow (by linarith : (1:ℝ)+β≠0),endpointProfile_zero]
  have hp' : 0<p := lt_of_le_of_ne hp (Ne.symm hp0)
  have hpow : p^(1+β)*(p/b)^(1-β)=p^2/b^(1-β) := by
    simpa only [Nat.cast_one,Nat.reduceAdd] using forward_fractional_identity 1 β hb hp'
  unfold nearOneCoupledPolynomial
  simp only [eval_add,eval_mul,eval_C,eval_pow,eval_X,eval_sub,eval_one,eval_comp,
    nearOneTangentPolynomial_eval]
  rw [show b⁻¹*p=p/b by ring, hj1,hj,hv,Real.rpow_one]
  calc
    _ = A*((1+β)*τ^β*p-β*τ^(1+β))*(1-(p/b)*(endpointProfilePolynomial N 6 1).eval (p/b))+
        (p^2/b^(1-β))*(B*(highProfilePolynomial N (1-β) f ω).eval (p/b)+
        ω*(1-B)*(endpointProfilePolynomial N 6 (1-β)).eval (p/b)) := by ring
    _ = _ := by rw [←hpow]; ring

/-- The completed polynomial has the same O(N) degree budget. -/
theorem nearOneCoupledPolynomial_natDegree (N : ℕ) (β τ b f ω A B : ℝ) :
    (nearOneCoupledPolynomial N β τ b f ω A B).natDegree≤2+18*(N-1) := by
  have hT : (nearOneTangentPolynomial β τ).natDegree≤1 := by
    unfold nearOneTangentPolynomial
    apply (natDegree_sub_le _ _).trans
    apply max_le
    · exact (natDegree_mul_le).trans (by simp only [natDegree_C,natDegree_X,zero_add,le_refl])
    · simp only [natDegree_C,zero_le]
  have hscale : (C b⁻¹*X : ℝ[X]).natDegree≤1 := by
    exact (natDegree_mul_le).trans (by simp)
  have hJ := endpointProfilePolynomial_natDegree N 6 1
  have hV := highProfilePolynomial_natDegree N (1-β) f ω
  have hJδ := endpointProfilePolynomial_natDegree N 6 (1-β)
  have hcut : ((1:ℝ[X])-(X*endpointProfilePolynomial N 6 1).comp (C b⁻¹*X)).natDegree≤1+6*(N-1) := by
    apply (natDegree_sub_le _ _).trans
    apply max_le (by simp)
    exact (natDegree_comp_le).trans (by
      have hm := natDegree_mul_le (p:=X) (q:=endpointProfilePolynomial N 6 1)
      simp only [natDegree_X] at hm
      nlinarith [Nat.mul_le_mul ((hm.trans (Nat.add_le_add_left hJ 1))) hscale])
  have hl : (C A*nearOneTangentPolynomial β τ*(1-(X*endpointProfilePolynomial N 6 1).comp (C b⁻¹*X))).natDegree≤2+18*(N-1) := by
    have ht := natDegree_mul_le (p:=C A) (q:=nearOneTangentPolynomial β τ)
    simp only [natDegree_C,zero_add] at ht
    have hm := natDegree_mul_le (p:=C A*nearOneTangentPolynomial β τ) (q:=1-(X*endpointProfilePolynomial N 6 1).comp (C b⁻¹*X))
    omega
  have hforward (c : ℝ) (P : ℝ[X]) (hP : P.natDegree≤18*(N-1)) :
      (C c*X^2*P.comp (C b⁻¹*X)).natDegree≤2+18*(N-1) := by
    have hcomp := (natDegree_comp_le (p:=P) (q:=C b⁻¹*X)).trans
      (Nat.mul_le_mul hP hscale)
    simp only [mul_one] at hcomp
    have hfirst := natDegree_mul_le (p:=C c) (q:=X^2)
    simp only [natDegree_C,zero_add,natDegree_X_pow] at hfirst
    exact (natDegree_mul_le).trans (Nat.add_le_add hfirst hcomp)
  unfold nearOneCoupledPolynomial
  exact (natDegree_add_le _ _).trans (max_le
    ((natDegree_add_le _ _).trans (max_le hl (hforward _ _ hV)))
    (hforward _ _ (by omega)))

end Renyi
