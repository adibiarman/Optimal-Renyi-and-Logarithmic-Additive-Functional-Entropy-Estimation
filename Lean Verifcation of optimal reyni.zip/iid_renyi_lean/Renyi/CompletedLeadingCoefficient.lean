import Renyi.DegreeOneLeadingCoefficient
import Renyi.CompletedLowCoefficients

/-! Sharp leading coefficient for every branch of the completed coupled polynomial. -/
noncomputable section
open Polynomial
namespace Renyi

def completedLeadingCoefficientConstant : ℝ :=
  max coupledLeadingCoefficientConstant degreeOneLeadingCoefficientConstant

lemma completedLeadingCoefficientConstant_pos : 0 < completedLeadingCoefficientConstant :=
  coupledLeadingCoefficientConstant_pos.trans_le (le_max_left _ _)

/-- Full CC7, with the degree-one branch included. -/
theorem completedCoupledPolynomial_leading_count_uniform {ℓ N m : ℕ}
    (hℓ : 0 < ℓ) (hN : 0 < N) (hm : 1 ≤ m) (hdegree : 4 * (ℓ - 1) ≤ m)
    {γ c a b n fL f A B ω L Cscale : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 < a) (hb : 0 < b) (hn : 0 < n)
    (hc : c ∈ Set.Ioo (γ / (1 + γ)) 1) (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1)
    (hZ : (ℓ : ℝ) ^ 2 * (a * (N : ℝ) ^ 2 / b) ≤ 1)
    (hL : 0 < L) (hC : 0 < Cscale) (hscale : (N : ℝ) ^ 2 / (n * b) ≤ Cscale * L) :
    |n ^ (-(1 - γ)) * (completedCoupledPolynomial ℓ N m γ a b c fL f A B ω).coeff (m + 1)| ≤
      (completedLeadingCoefficientConstant * max 1 Cscale) * (L / (1 - γ)) ^ (1 - γ) := by
  have hZsmall : (N : ℝ) ^ 2 * (a / b) ≤ 1 := by
    have hℓ1 : 1 ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
    have hℓ2 : 1 ≤ (ℓ : ℝ) ^ 2 := by nlinarith
    have hx : 0 ≤ (N : ℝ) ^ 2 * (a / b) := by positivity
    have hm := mul_le_mul_of_nonneg_right hℓ2 hx
    have hl : (ℓ : ℝ) ^ 2 * ((N : ℝ) ^ 2 * (a / b)) ≤ 1 := by
      convert hZ using 1
      ring
    nlinarith
  have hscale0 : 0 ≤ max 1 Cscale := le_trans (by norm_num) (le_max_left _ _)
  have hpow0 : 0 ≤ (L / (1 - γ)) ^ (1 - γ) := Real.rpow_nonneg (div_nonneg hL.le (by linarith)) _
  unfold completedCoupledPolynomial
  split
  · have h := degreeOneCoupledPolynomial_leading_count_uniform hm hN hγ hγ1 ha hb hn hc hf hf1
      hA hA1 hB hB1 hω hω1 hZsmall hL hC hscale
    apply h.trans
    exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right (le_max_right _ _) hscale0) hpow0
  · have h := coupledQPolynomial_leading_count_uniform hℓ hN hdegree hγ hγ1 ha hb hn hfL hfL1 hf hf1
      hA hA1 hB hB1 hω hω1 hZ hL hC hscale
    apply h.trans
    exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right (le_max_left _ _) hscale0) hpow0

end Renyi
