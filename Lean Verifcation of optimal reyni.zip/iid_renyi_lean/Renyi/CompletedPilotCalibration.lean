import Renyi.CompletedPilotComparison

/-! Explicit, order-independent pilot constants and actual upper-root cutoff geometry. -/
noncomputable section
namespace Renyi
set_option maxHeartbeats 600000

def pilotSourceExponent (eps eta : ℝ) : ℝ := max 0 (2*eps+Real.log (12/eta))

def pilotSourceMultiplier (eps eta B cb : ℝ) : ℝ :=
  max 1 (max (2*B+pilotSourceExponent eps eta+11)
    (8*(coupledCoefficientExponentialConstant+20+pilotSourceExponent eps eta)/cb))

theorem pilot_source_constants {eps eta B cb : ℝ} (hcb : 0<cb) :
    0≤pilotSourceExponent eps eta ∧
    2*eps+Real.log (12/eta)≤pilotSourceExponent eps eta ∧
    1≤pilotSourceMultiplier eps eta B cb ∧
    2*B+pilotSourceExponent eps eta+11≤pilotSourceMultiplier eps eta B cb ∧
    8*(coupledCoefficientExponentialConstant+20+pilotSourceExponent eps eta)≤
      pilotSourceMultiplier eps eta B cb*cb := by
  refine ⟨le_max_left _ _,le_max_right _ _,le_max_left _ _,?_,?_⟩
  · exact (le_max_left _ _).trans (le_max_right _ _)
  · apply (div_le_iff₀ hcb).mp
    exact (le_max_right _ _).trans (le_max_right _ _)

/-- With fixed `cb * CL ≥ 2 B`, every actual regularized-root cutoff has the
three deterministic scale properties required by the proved pilot bounds. -/
theorem upper_pilot_cutoff_geometry {k : ℕ} {alpha eps D cb CL cL B : ℝ}
    (hk : 0<k) (ha : 3/2≤alpha) (hg : 0<fractionalPart alpha)
    (hg1 : fractionalPart alpha<1) (hD : 0<D) (hcb : 0<cb)
    (hCL : 1≤CL) (hcL : 0<cL) (hB : 16≤B) (hscale : 2*B≤cb*CL) :
    let n := upperSample k alpha eps D
    let b := upperB k alpha eps D cb CL cL
    let L := (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)
    0<n ∧ 0<b ∧ 1≤L ∧ alpha≤L ∧ n*b=cb*L ∧
      2*B*alpha≤n*b ∧ 1≤L*(n*b) := by
  have ha1 : 1<alpha := by linarith only [ha]
  have hn := upperSample_pos hk ha1 hg hg1 hD (ε:=eps)
  have hb := upperB_pos hk ha1 hg hg1 hD hcb hCL hcL (ε:=eps)
  have hX := one_le_rootMultiplier (k:=k) (ε:=eps) ha1 hg hg1
  have hdegree := (upperDegree_bounds ha1 hCL hcL hX).1
  let L := (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)
  have haL : alpha≤L := by
    have hh := mul_le_mul_of_nonneg_left hCL (by linarith only [ha] : 0≤alpha)
    dsimp [L]
    linarith only [hh,hdegree]
  have hL : 1≤L := by linarith only [haL,ha]
  have hnb : upperSample k alpha eps D*upperB k alpha eps D cb CL cL=cb*L := by
    unfold upperB
    dsimp [L]
    field_simp
  have hcut : 2*B*alpha≤upperSample k alpha eps D*upperB k alpha eps D cb CL cL := by
    rw [hnb]
    have h1 := mul_le_mul_of_nonneg_right hscale (by linarith only [ha] : 0≤alpha)
    have h2 := mul_le_mul_of_nonneg_left hdegree hcb.le
    dsimp [L]
    nlinarith only [h1,h2]
  refine ⟨hn,hb,hL,haL,hnb,hcut,?_⟩
  have hnb1 : 1≤upperSample k alpha eps D*upperB k alpha eps D cb CL cL := by
    have hBa := mul_le_mul hB ha (by norm_num : (0:ℝ)≤3/2) (by linarith only [hB])
    nlinarith only [hBa,hcut]
  simpa only [one_mul] using mul_le_mul hL hnb1 (by norm_num : (0:ℝ)≤1)
    (by linarith only [hL] : 0≤L)

end Renyi
