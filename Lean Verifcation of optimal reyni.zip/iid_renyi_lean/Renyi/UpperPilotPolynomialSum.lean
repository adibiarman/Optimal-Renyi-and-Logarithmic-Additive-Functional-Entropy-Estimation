import Renyi.UpperPilotErrors

/-! Finite-alphabet L1 control of actual polynomial pilot-classification errors. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Polynomial
namespace Renyi
set_option maxHeartbeats 800000

variable {ι Ω : Type*} [Fintype ι] [MeasurableSpace Ω] {μ : Measure Ω}

def pilotPolynomialBoundary (p Q : ι→ℝ) (Y : ι→Ω→ℕ)
    (n b alpha cp B omega : ℝ) : Ω→ℝ := fun w => ∑i,
  ((if b<p i then (if (Y i w:ℝ)≤cp*B*alpha then |Q i|+omega*p i^alpha else 0) else 0)+
  (if n*p i<B*alpha/2 then (if cp*B*alpha<(Y i w:ℝ) then |Q i| else 0) else 0))

lemma pilot_polynomial_boundary_integral (p Q : ι→ℝ) (Y : ι→Ω→ℕ)
    (nu : ι→ℝ≥0) (hY : ∀i,MeasurePreserving (Y i) μ (poissonMeasure (nu i)))
    (n b alpha cp B omega : ℝ) :
    Integrable (pilotPolynomialBoundary p Q Y n b alpha cp B omega) μ ∧
      (∫w,pilotPolynomialBoundary p Q Y n b alpha cp B omega w ∂μ)=∑i,
        ((if b<p i then poissonLowerMass (nu i) (cp*B*alpha)*(|Q i|+omega*p i^alpha) else 0)+
        (if n*p i<B*alpha/2 then poissonUpperMass (nu i) (cp*B*alpha)*|Q i| else 0)) := by
  let F : ι→Ω→ℝ := fun i w => if b<p i then
    (if (Y i w:ℝ)≤cp*B*alpha then |Q i|+omega*p i^alpha else 0) else 0
  let G : ι→Ω→ℝ := fun i w => if n*p i<B*alpha/2 then
    (if cp*B*alpha<(Y i w:ℝ) then |Q i| else 0) else 0
  have hF (i:ι) : Integrable (F i) μ := by
    dsimp [F]
    split_ifs
    · exact (hY i).integrable_comp_of_integrable (poisson_pilot_switch_integrable _ _ _)
    · exact integrable_zero _ _ _
  have hG (i:ι) : Integrable (G i) μ := by
    dsimp [G]
    split_ifs
    · exact (hY i).integrable_comp_of_integrable (poisson_upper_switch_integrable _ _ _)
    · exact integrable_zero _ _ _
  refine ⟨integrable_finset_sum _ (fun i _ => (hF i).add (hG i)),?_⟩
  change (∫w,∑i,(F i w+G i w) ∂μ)=_
  have hFG (i:ι) : Integrable (fun w => F i w+G i w) μ := (hF i).add (hG i)
  rw [integral_finset_sum Finset.univ (fun i _ => hFG i)]
  apply Finset.sum_congr rfl
  intro i _
  rw [integral_add (hF i) (hG i)]
  congr 1
  · dsimp [F]
    split_ifs
    · have hh := (hY i).hasLaw.integral_comp
        (measurable_of_countable (fun y:ℕ => if (y:ℝ)≤cp*B*alpha then |Q i|+omega*p i^alpha else 0)).aestronglyMeasurable
      change (∫w,(if (Y i w:ℝ)≤cp*B*alpha then |Q i|+omega*p i^alpha else 0) ∂μ)=_ at hh
      rw [hh,poisson_pilot_switch_integral]
    · exact integral_zero _ _
  · dsimp [G]
    split_ifs
    · have hh := (hY i).hasLaw.integral_comp
        (measurable_of_countable (fun y:ℕ => if cp*B*alpha<(y:ℝ) then |Q i| else 0)).aestronglyMeasurable
      change (∫w,(if cp*B*alpha<(Y i w:ℝ) then |Q i| else 0) ∂μ)=_ at hh
      rw [hh,poisson_upper_switch_integral]
    · exact integral_zero _ _

/-- The complete polynomial misclassification envelope, retaining both the
baseline below a and the actual power-sum bonus elsewhere. -/
theorem pilot_polynomial_boundary_bound {P : ℝ[X]}
    {n b a alpha cp B omega L C Cd cstar cb A0 : ℝ}
    (hn : 0<n) (hb : 0<b) (_ha : 0<a) (halpha : 3/2≤alpha)
    (hL : 1≤L) (hC : 0≤C) (hCd : 0≤Cd) (hcstar : 0≤cstar)
    (hcp0 : 1≤cp) (hB : 16≤B) (hnb : n*b=cb*L)
    (hcutoff : 2*B*alpha≤n*b) (hLn : 1≤L*(n*b))
    (hdegree : (P.natDegree:ℝ)≤Cd*L)
    (hcoef : coefficientMass P≤Real.exp (C*L))
    (hcp : 8*(C+Cd+cstar)≤cp*cb) (hw : 0≤omega) (hw1 : omega≤1)
    (hA0 : 0≤A0) (p Q : ι→ℝ) (hp : ∀i,0≤p i)
    (hQrepr : ∀i,Q i=b^alpha*P.eval (p i/b))
    (hQsmall : ∀i,p i<a → |Q i|≤A0)
    (hQgood : ∀i,a≤p i → p i≤b → |Q i|≤3*p i^alpha)
    (Y : ι→Ω→ℕ)
    (hY : ∀i,MeasurePreserving (Y i) μ
      (poissonMeasure ⟨cp*n*p i,mul_nonneg (mul_nonneg (by linarith only [hcp0]) hn.le) (hp i)⟩)) :
    Integrable (pilotPolynomialBoundary p Q Y n b alpha cp B omega) μ ∧
      (∫w,pilotPolynomialBoundary p Q Y n b alpha cp B omega w ∂μ)≤
        (Fintype.card ι:ℝ)*A0+
          (2*Real.exp (-cstar*L)+3*Real.exp (-cp*alpha))*conditionalCountBonus p alpha n L := by
  let nu : ι→ℝ≥0 := fun i => ⟨cp*n*p i,mul_nonneg (mul_nonneg (by linarith only [hcp0]) hn.le) (hp i)⟩
  have hint := pilot_polynomial_boundary_integral p Q Y nu hY n b alpha cp B omega
  refine ⟨hint.1,?_⟩
  rw [hint.2]
  let Bonus : ι→ℝ := fun i => p i^alpha*min (L*(n*p i)) 1
  have hBonus (i:ι) : 0≤Bonus i := by
    dsimp [Bonus]
    exact mul_nonneg (Real.rpow_nonneg (hp i) _) (le_min (mul_nonneg (by linarith only [hL]) (mul_nonneg hn.le (hp i))) (by norm_num))
  have hcpPos : 0<cp := by linarith only [hcp0]
  have hAlpha : 1≤alpha := by linarith only [halpha]
  have hL0 : 0≤L := by linarith only [hL]
  have hfar (i:ι) : (if b<p i then poissonLowerMass (nu i) (cp*B*alpha)*(|Q i|+omega*p i^alpha) else 0)≤
      2*Real.exp (-cstar*L)*Bonus i := by
    by_cases hpi : b<p i
    · rw [if_pos hpi,hQrepr i]
      have hmain := false_light_difference_mass hn hb hpi.le hL0 hC hCd hcstar hcpPos
        (by linarith only [halpha]) hnb hcutoff hdegree hcoef hcp hw hw1
      have hLp : 1≤L*(n*p i) := hLn.trans
        (mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hpi.le hn.le) hL0)
      simpa only [Bonus,min_eq_right hLp,mul_one] using hmain
    · rw [if_neg hpi]
      exact mul_nonneg (mul_nonneg (by norm_num) (Real.exp_pos _).le) (hBonus i)
  have hnear (i:ι) : (if n*p i<B*alpha/2 then poissonUpperMass (nu i) (cp*B*alpha)*|Q i| else 0)≤
      A0+3*Real.exp (-cp*alpha)*Bonus i := by
    have hterm0 : 0≤3*Real.exp (-cp*alpha)*Bonus i :=
      mul_nonneg (mul_nonneg (by norm_num) (Real.exp_pos _).le) (hBonus i)
    by_cases hlow : n*p i<B*alpha/2
    · rw [if_pos hlow]
      by_cases hbelow : p i<a
      · have hs : poissonUpperMass (nu i) (cp*B*alpha)≤1 := by
          rw [poissonUpperMass_eq_one_sub]
          linarith only [poissonLowerMass_nonneg (nu i) (cp*B*alpha)]
        have hh := mul_le_mul hs (hQsmall i hbelow) (abs_nonneg _) zero_le_one
        simpa only [one_mul] using hh.trans (le_add_of_nonneg_right hterm0)
      · have hap : a≤p i := le_of_not_gt hbelow
        have hpb : p i≤b := by
          apply (mul_le_mul_iff_right₀ hn).mp
          have hh : 0≤B*alpha := mul_nonneg (by linarith only [hB]) (by linarith only [halpha])
          nlinarith only [hcutoff,hlow,hh]
        let lam : ℝ≥0 := ⟨n*p i,mul_nonneg hn.le (hp i)⟩
        have hmain := false_heavy_polynomial_mass hcp0 hB hAlpha (by norm_num : (0:ℝ)≤3)
          (hp i) lam hlow.le (hQgood i hap hpb)
        have hnu : (⟨cp*lam,mul_nonneg hcpPos.le lam.coe_nonneg⟩:ℝ≥0)=nu i := by ext;dsimp [nu,lam];ring
        rw [hnu] at hmain
        have hmin : min (n*p i) 1≤min (L*(n*p i)) 1 :=
          min_le_min_right 1 (by have hh := mul_le_mul_of_nonneg_right hL (mul_nonneg hn.le (hp i));simpa only [one_mul] using hh)
        have hh := mul_le_mul_of_nonneg_left hmin
          (show 0≤3*Real.exp (-cp*alpha)*p i^alpha from mul_nonneg (mul_nonneg (by norm_num) (Real.exp_pos _).le) (Real.rpow_nonneg (hp i) _))
        have htotal : poissonUpperMass (nu i) (cp*B*alpha)*|Q i|≤3*Real.exp (-cp*alpha)*Bonus i := by
          change poissonUpperMass (nu i) (cp*B*alpha)*|Q i|≤3*Real.exp (-cp*alpha)*p i^alpha*min (n*p i) 1 at hmain
          dsimp [Bonus]
          nlinarith only [hmain,hh]
        exact htotal.trans (le_add_of_nonneg_left hA0)
    · rw [if_neg hlow]
      exact add_nonneg hA0 hterm0
  calc
    _≤∑i,(A0+(2*Real.exp (-cstar*L)+3*Real.exp (-cp*alpha))*Bonus i) := by
      apply Finset.sum_le_sum
      intro i _
      nlinarith only [hfar i,hnear i]
    _=_ := by
      rw [Finset.sum_add_distrib,Finset.sum_const,←Finset.mul_sum]
      simp only [Finset.card_univ,nsmul_eq_mul]
      unfold conditionalCountBonus
      simp only [Bonus]

end Renyi
