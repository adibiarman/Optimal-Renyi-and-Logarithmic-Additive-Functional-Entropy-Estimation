import Renyi.PoissonMarking
import Renyi.OneDefect

/-!
# Countably many Poisson marks

The finite splitting theorem is applied to every finite partition, retaining
one extra cell for all unlisted marks. This proves joint independence of all
countably many fingerprint counts in the original random-length iid experiment.
-/

noncomputable section
open scoped BigOperators ENNReal NNReal
open MeasureTheory ProbabilityTheory

namespace Renyi

variable {κ η : Type*} [Countable κ] [MeasurableSpace κ] [MeasurableSingletonClass κ]
    [Countable η] [MeasurableSpace η] [MeasurableSingletonClass η]

/-- A finite ordered iid sample from an arbitrary countable mark law. -/
def iidCountablePMF (q : PMF κ) (n : ℕ) : PMF (Fin n → κ) :=
  (Measure.pi (fun _ : Fin n => q.toMeasure)).toPMF

@[simp] theorem iidCountablePMF_apply (q : PMF κ) (n : ℕ) (x : Fin n → κ) :
    iidCountablePMF q n x = ∏ k, q (x k) := by
  rw [iidCountablePMF, Measure.toPMF_apply]
  have hset : ({x} : Set (Fin n → κ)) = Set.univ.pi (fun k => {x k}) := by
    ext y
    simp only [Set.mem_singleton_iff, Set.mem_univ_pi, Set.mem_singleton_iff]
    exact funext_iff
  rw [hset, Measure.pi_pi]
  apply Finset.prod_congr rfl
  intro i _
  exact PMF.toMeasure_apply_singleton _ _ (MeasurableSet.singleton _)

/-- Applying a mark transformation to independent draws transforms each marginal. -/
theorem iidCountablePMF_map (q : PMF κ) (n : ℕ) (f : κ → η) :
    (iidCountablePMF q n).map (fun x k => f (x k)) =
      iidCountablePMF (q.map f) n := by
  apply PMF.toMeasure_injective
  rw [← PMF.toMeasure_map _ _ (measurable_of_countable _)]
  simp only [iidCountablePMF, Measure.toPMF_toMeasure]
  rw [Measure.pi_map_pi (fun _ => (measurable_of_countable f).aemeasurable)]
  simp_rw [PMF.toMeasure_map _ _ (measurable_of_countable f)]

/-- Poisson sample size followed by actual ordered iid draws from `q`. -/
def poissonCountableSamplePMF (b : ℝ≥0) (q : PMF κ) : PMF (PoissonMarkedSample κ) :=
  (poissonPMF b).bind (fun n => (iidCountablePMF q n).map (fun x => ⟨n, x⟩))

/-- Transform the marks while retaining the random sample size. -/
def mapPoissonMarks (f : κ → η) (x : PoissonMarkedSample κ) : PoissonMarkedSample η :=
  ⟨x.1, fun k => f (x.2 k)⟩

/-- The mapping property for a Poisson number of ordered iid marks. -/
theorem poissonCountableSamplePMF_map (b : ℝ≥0) (q : PMF κ) (f : κ → η) :
    (poissonCountableSamplePMF b q).map (mapPoissonMarks f) =
      poissonCountableSamplePMF b (q.map f) := by
  rw [poissonCountableSamplePMF, PMF.map_bind]
  congr 1
  funext n
  rw [PMF.map_comp, ← iidCountablePMF_map q n f, PMF.map_comp]
  rfl

section Finite
variable {ι : Type*} [Fintype ι] [DecidableEq ι]
    [MeasurableSpace ι] [MeasurableSingletonClass ι]

omit [DecidableEq ι] [MeasurableSpace ι] [MeasurableSingletonClass ι] in
/-- The nonnegative-real probabilities of a finite mass function sum to one. -/
theorem pmf_toNNReal_sum (q : PMF ι) : ∑ i, (q i).toNNReal = 1 := by
  apply ENNReal.coe_injective
  simp only [ENNReal.coe_finset_sum, ENNReal.coe_toNNReal (PMF.apply_ne_top _ _), ENNReal.coe_one]
  exact (tsum_fintype (f := fun i => q i)).symm.trans q.tsum_coe

omit [DecidableEq ι] in
/-- Agreement between the countable-space product construction and the explicit
finite-space iid product used in the multinomial proof. -/
theorem iidCountablePMF_eq_finite (q : PMF ι) (n : ℕ) :
    iidCountablePMF q n = iidMarkPMF (fun i => (q i).toNNReal) (pmf_toNNReal_sum q) n := by
  ext x
  simp only [iidCountablePMF_apply, iidMarkPMF_apply,
    ENNReal.coe_toNNReal (PMF.apply_ne_top _ _)]

/-- The complete finite partition count-vector law. -/
theorem poissonCountableSamplePMF_histogram (b : ℝ≥0) (q : PMF ι) :
    (poissonCountableSamplePMF b q).map (fun x => markHistogram x.2) =
      finitePoissonPMF (fun i => b * (q i).toNNReal) := by
  have heq : poissonCountableSamplePMF b q =
      poissonMarkedSamplePMF b (fun i => (q i).toNNReal) (pmf_toNNReal_sum q) := by
    simp only [poissonCountableSamplePMF, iidCountablePMF_eq_finite, poissonMarkedSamplePMF]
  rw [heq, poissonMarkedSample_histogram]

/-- Exact splitting for any finite measurable partition of a countable mark space. -/
theorem poisson_partition_law (b : ℝ≥0) (q : PMF κ) (f : κ → ι) :
    (poissonCountableSamplePMF b q).map
      (fun x => markHistogram (fun k => f (x.2 k))) =
      finitePoissonPMF (fun i => b * ((q.map f) i).toNNReal) := by
  rw [← poissonCountableSamplePMF_histogram, ← poissonCountableSamplePMF_map b q f,
    PMF.map_comp]
  rfl

/-- Coordinates of an arbitrary finite mark partition are mutually independent. -/
theorem poisson_partition_independent (b : ℝ≥0) (q : PMF κ) (f : κ → ι) :
    iIndepFun (fun i (x : PoissonMarkedSample κ) =>
      markHistogram (fun k => f (x.2 k)) i) (poissonCountableSamplePMF b q).toMeasure := by
  let μ := (poissonCountableSamplePMF b q).toMeasure
  let r := fun i => b * ((q.map f) i).toNNReal
  let H := fun x : PoissonMarkedSample κ => markHistogram (fun k => f (x.2 k))
  have hmap : μ.map H = Measure.pi (fun i => poissonMeasure (r i)) := by
    rw [PMF.toMeasure_map _ _ (measurable_of_countable _), poisson_partition_law,
      finitePoissonPMF, Measure.toPMF_toMeasure]
  have hcoord (i : ι) : μ.map (fun x => H x i) = poissonMeasure (r i) := by
    change μ.map ((fun y => y i) ∘ H) = poissonMeasure (r i)
    rw [← Measure.map_map (measurable_pi_apply i) (measurable_of_countable H), hmap]
    exact (measurePreserving_eval (fun i => poissonMeasure (r i)) i).map_eq
  apply (iIndepFun_iff_map_fun_eq_pi_map
    (fun _ => (measurable_of_countable _).aemeasurable)).mpr
  change μ.map H = Measure.pi (fun i => μ.map (fun x => H x i))
  simp only [hcoord, hmap]

/-- Each finite partition count has the exact Poisson marginal. -/
theorem poisson_partition_coordinate_law (b : ℝ≥0) (q : PMF κ) (f : κ → ι) (i : ι) :
    (poissonCountableSamplePMF b q).toMeasure.map
      (fun x => markHistogram (fun k => f (x.2 k)) i) =
      poissonMeasure (b * ((q.map f) i).toNNReal) := by
  let H := fun x : PoissonMarkedSample κ => markHistogram (fun k => f (x.2 k))
  have hmap : (poissonCountableSamplePMF b q).toMeasure.map H =
      Measure.pi (fun i => poissonMeasure (b * ((q.map f) i).toNNReal)) := by
    rw [PMF.toMeasure_map _ _ (measurable_of_countable _), poisson_partition_law,
      finitePoissonPMF, Measure.toPMF_toMeasure]
  change (poissonCountableSamplePMF b q).toMeasure.map ((fun y => y i) ∘ H) = _
  rw [← Measure.map_map (measurable_pi_apply i) (measurable_of_countable H), hmap]
  exact (measurePreserving_eval
    (fun i => poissonMeasure (b * ((q.map f) i).toNNReal)) i).map_eq

end Finite

section CountableMarks
variable [DecidableEq κ]

/-- The number of observations with a specified mark. -/
def poissonMarkCount (j : κ) (x : PoissonMarkedSample κ) : ℕ :=
  ∑ k, if x.2 k = j then 1 else 0

/-- Keep each mark in a finite set and put all remaining marks in one tail cell. -/
def finiteMarkPartition (s : Finset κ) (j : κ) : Option s :=
  if h : j ∈ s then some ⟨j, h⟩ else none

omit [Countable κ] [MeasurableSpace κ] [MeasurableSingletonClass κ] in
@[simp] theorem finiteMarkPartition_eq_some_iff (s : Finset κ) (j : s) (k : κ) :
    finiteMarkPartition s k = some j ↔ k = (j : κ) := by
  by_cases hk : k ∈ s
  · simp [finiteMarkPartition, hk, Subtype.ext_iff]
  · have hne : k ≠ (j : κ) := fun h => hk (h.symm ▸ j.property)
    simp [finiteMarkPartition, hk, hne]

omit [Countable κ] [MeasurableSpace κ] [MeasurableSingletonClass κ] in
@[simp] theorem partition_histogram_some (s : Finset κ) (j : s)
    (x : PoissonMarkedSample κ) :
    markHistogram (fun k => finiteMarkPartition s (x.2 k)) (some j) =
      poissonMarkCount (j : κ) x := by
  simp only [markHistogram, poissonMarkCount, finiteMarkPartition_eq_some_iff]

omit [Countable κ] [MeasurableSpace κ] [MeasurableSingletonClass κ] in
/-- The mass of a retained singleton cell is its original mark probability. -/
theorem finiteMarkPartition_mass (q : PMF κ) (s : Finset κ) (j : s) :
    (q.map (finiteMarkPartition s)) (some j) = q j := by
  classical
  rw [PMF.map_apply]
  have h (k : κ) : some j = finiteMarkPartition s k ↔ k = (j : κ) := by
    rw [eq_comm, finiteMarkPartition_eq_some_iff]
  simp only [h]
  rw [tsum_eq_single (j : κ)]
  · simp
  · intro k hk
    simp [hk]

/-- All countably many mark counts are jointly independent. The tail cell in
finiteMarkPartition ensures that no mass is discarded in the proof. -/
theorem poisson_mark_counts_independent (b : ℝ≥0) (q : PMF κ) :
    iIndepFun poissonMarkCount (poissonCountableSamplePMF b q).toMeasure := by
  rw [iIndepFun_iff_finset]
  intro s
  letI : MeasurableSpace (Option s) := ⊤
  have h := (poisson_partition_independent b q (finiteMarkPartition s)).precomp
    (g := (some : s → Option s)) (Option.some_injective _)
  simpa only [partition_histogram_some] using h

/-- Each count in the countable fingerprint is Poisson with mean `b q_j`. -/
theorem poisson_mark_count_law (b : ℝ≥0) (q : PMF κ) (j : κ) :
    (poissonCountableSamplePMF b q).toMeasure.map (poissonMarkCount j) =
      poissonMeasure (b * (q j).toNNReal) := by
  let s := ({j} : Finset κ)
  let j' : s := ⟨j, Finset.mem_singleton_self j⟩
  letI : MeasurableSpace (Option s) := ⊤
  have h := poisson_partition_coordinate_law b q (finiteMarkPartition s) (some j')
  simpa only [partition_histogram_some, finiteMarkPartition_mass] using h

end CountableMarks

section TransformedMarks
variable [DecidableEq η]

omit [Countable η] [MeasurableSpace η] [MeasurableSingletonClass η] in
/-- Counts of any countable-valued transformation of the iid marks are jointly independent. -/
theorem poisson_transformed_counts_independent (b : ℝ≥0) (q : PMF κ) (f : κ → η) :
    iIndepFun (fun j x => poissonMarkCount j (mapPoissonMarks f x))
      (poissonCountableSamplePMF b q).toMeasure := by
  rw [iIndepFun_iff_finset]
  intro s
  letI : MeasurableSpace (Option s) := ⊤
  have h := (poisson_partition_independent b q (finiteMarkPartition s ∘ f)).precomp
    (g := (some : s → Option s)) (Option.some_injective _)
  simpa only [Function.comp_def, markHistogram, finiteMarkPartition_eq_some_iff,
    poissonMarkCount, mapPoissonMarks] using h

omit [Countable η] [MeasurableSpace η] [MeasurableSingletonClass η] in
/-- Each transformed-mark count has the Poisson mean given by its pushed-forward mark law. -/
theorem poisson_transformed_count_law (b : ℝ≥0) (q : PMF κ) (f : κ → η) (j : η) :
    (poissonCountableSamplePMF b q).toMeasure.map
      (fun x => poissonMarkCount j (mapPoissonMarks f x)) =
      poissonMeasure (b * ((q.map f) j).toNNReal) := by
  let s := ({j} : Finset η)
  let j' : s := ⟨j, Finset.mem_singleton_self j⟩
  letI : MeasurableSpace (Option s) := ⊤
  have h := poisson_partition_coordinate_law b q (finiteMarkPartition s ∘ f) (some j')
  rw [← PMF.map_comp, finiteMarkPartition_mass] at h
  simpa only [Function.comp_def, markHistogram, finiteMarkPartition_eq_some_iff,
    poissonMarkCount, mapPoissonMarks] using h

end TransformedMarks

section TwoStage
variable {ι : Type*} [Fintype ι] [DecidableEq ι]
    [MeasurableSpace ι] [MeasurableSingletonClass ι]

/-- A finite atomic prior with its actual probability masses. -/
def atomicMarkPMF (mass : ι → ℝ) (hmass : ∀ i, 0 ≤ mass i)
    (hprob : ∑ i, mass i = 1) : PMF ι :=
  PMF.ofFintype (fun i => ENNReal.ofReal (mass i)) (by
    change (∑ i, ENNReal.ofReal (mass i)) = 1
    rw [← ENNReal.ofReal_sum_of_nonneg (fun i _ => hmass i), hprob]
    simp)

/-- Draw the atom, then draw a Poisson observation conditional on that atom. -/
def atomicPoissonMarkPMF (mass value : ι → ℝ) (θ : ℝ)
    (hmass : ∀ i, 0 ≤ mass i) (hprob : ∑ i, mass i = 1)
    (hvalue : ∀ i, 0 ≤ value i) (hθ : 0 ≤ θ) : PMF (ι × ℕ) :=
  (atomicMarkPMF mass hmass hprob).bind (fun i =>
    (poissonPMF (⟨θ * value i, mul_nonneg hθ (hvalue i)⟩ : ℝ≥0)).map
      (fun j => (i, j)))

omit [DecidableEq ι] [MeasurableSpace ι] [MeasurableSingletonClass ι] in
/-- Integrating out the atom yields exactly the mixed-count probabilities in the proof. -/
theorem atomicPoissonMarkPMF_snd_apply (mass value : ι → ℝ) (θ : ℝ)
    (hmass : ∀ i, 0 ≤ mass i) (hprob : ∑ i, mass i = 1)
    (hvalue : ∀ i, 0 ≤ value i) (hθ : 0 ≤ θ) (j : ℕ) :
    ((atomicPoissonMarkPMF mass value θ hmass hprob hvalue hθ).map Prod.snd) j =
      ENNReal.ofReal (poissonMixture mass value θ j) := by
  rw [atomicPoissonMarkPMF, PMF.map_bind]
  simp only [PMF.map_comp, Function.comp_def]
  change ((atomicMarkPMF mass hmass hprob).bind (fun i =>
    (poissonPMF (⟨θ * value i, mul_nonneg hθ (hvalue i)⟩ : ℝ≥0)).map id)) j = _
  simp only [PMF.map_id]
  rw [PMF.bind_apply, tsum_fintype]
  rw [poissonMixture, ENNReal.ofReal_sum_of_nonneg]
  · apply Finset.sum_congr rfl
    intro i _
    change ENNReal.ofReal (mass i) * ENNReal.ofReal
      (poissonPMFReal (⟨θ * value i, mul_nonneg hθ (hvalue i)⟩ : ℝ≥0) j) = _
    rw [← ENNReal.ofReal_mul (hmass i)]
    rfl
  · intro i _
    exact mul_nonneg (hmass i) (poissonPMFReal_nonneg
      (r := (⟨θ * value i, mul_nonneg hθ (hvalue i)⟩ : ℝ≥0)))

omit [DecidableEq ι] in
/-- The source compound-Poisson fingerprint theorem, for every count `j`, including
zero. Each sampled atom first has law `mass`, and its observation is independently
Poisson with rate `theta * value`. -/
theorem atomic_poisson_fingerprint (b : ℝ≥0) (mass value : ι → ℝ) (θ : ℝ)
    (hmass : ∀ i, 0 ≤ mass i) (hprob : ∑ i, mass i = 1)
    (hvalue : ∀ i, 0 ≤ value i) (hθ : 0 ≤ θ) :
    let q := atomicPoissonMarkPMF mass value θ hmass hprob hvalue hθ
    let F := fun j (x : PoissonMarkedSample (ι × ℕ)) =>
      poissonMarkCount j (mapPoissonMarks Prod.snd x)
    iIndepFun F (poissonCountableSamplePMF b q).toMeasure ∧
      ∀ j, (poissonCountableSamplePMF b q).toMeasure.map (F j) =
        poissonMeasure (b * ⟨poissonMixture mass value θ j,
          poissonMixture_nonneg mass value θ j hmass hvalue hθ⟩) := by
  dsimp only
  refine ⟨poisson_transformed_counts_independent b _ Prod.snd, ?_⟩
  intro j
  rw [poisson_transformed_count_law, atomicPoissonMarkPMF_snd_apply]
  congr 2
  apply NNReal.eq
  change (ENNReal.ofReal (poissonMixture mass value θ j)).toReal = _
  exact ENNReal.toReal_ofReal (poissonMixture_nonneg mass value θ j hmass hvalue hθ)

end TwoStage

end Renyi


