import Renyi.CoupledCountVariance

/-! Deterministic scalar rescaling of the actual pilot-selected count variance. -/
noncomputable section
open scoped BigOperators
open MeasureTheory ProbabilityTheory
namespace Renyi

lemma factorialStatistic_scaled_coefficients (d : ℕ) (c : ℕ→ℝ) (s n : ℝ) (j : ℕ) :
    factorialStatistic d (fun r => s*c r/n^r) j=s*factorialStatistic d (fun r => c r/n^r) j := by
  unfold factorialStatistic
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r _
  ring

variable {ι Ω Ξ : Type*} [Fintype ι] [MeasurableSpace Ω] [MeasurableSpace Ξ]

omit [MeasurableSpace Ω] in
lemma pilotSelectedCountEstimator_scaled (Counts : ι→Ω→ℕ) (y : ι→ℕ)
    (T : ℝ) (d : ℕ) (c : ℕ→ℝ) (s n : ℝ) :
    pilotSelectedCountEstimator Counts y T d (fun r => s*c r) n=
      fun w => s*pilotSelectedCountEstimator Counts y T d c n w := by
  funext w
  unfold pilotSelectedCountEstimator
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  split_ifs <;> simp only [factorialStatistic_scaled_coefficients,mul_zero]

lemma pilotAveragedCountVariance_scaled (Counts : ι→Ω→ℕ) (Y : ι→Ξ→ℕ)
    (T : ℝ) (d : ℕ) (c : ℕ→ℝ) (s n : ℝ) (μ : Measure Ω) (ν : Measure Ξ) :
    pilotAveragedCountVariance Counts Y T d (fun r => s*c r) n μ ν=
      s^2*pilotAveragedCountVariance Counts Y T d c n μ ν := by
  unfold pilotAveragedCountVariance
  simp_rw [pilotSelectedCountEstimator_scaled,variance_mul]
  rw [integral_const_mul]

lemma pilotAveragedCountVariance_scaled_le (Counts : ι→Ω→ℕ) (Y : ι→Ξ→ℕ)
    (T : ℝ) (d : ℕ) (c : ℕ→ℝ) {s : ℝ} (hs : |s|≤1)
    (n : ℝ) (μ : Measure Ω) (ν : Measure Ξ) :
    pilotAveragedCountVariance Counts Y T d (fun r => s*c r) n μ ν≤
      pilotAveragedCountVariance Counts Y T d c n μ ν := by
  rw [pilotAveragedCountVariance_scaled]
  have hv : 0≤pilotAveragedCountVariance Counts Y T d c n μ ν := integral_nonneg (fun _ => variance_nonneg _ _)
  have hs2 : s^2≤1 := by nlinarith only [sq_abs s,abs_nonneg s,hs]
  exact mul_le_of_le_one_left hv hs2

end Renyi
