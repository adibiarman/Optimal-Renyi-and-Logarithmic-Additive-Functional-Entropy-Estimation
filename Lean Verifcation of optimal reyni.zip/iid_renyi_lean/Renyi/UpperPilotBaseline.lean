import Renyi.UpperPilotComparison
import Renyi.UpperBaseline

/-! The below-cutoff pilot error is paid by the source baseline with D chosen last. -/
noncomputable section
namespace Renyi
set_option maxHeartbeats 500000

lemma pilot_below_cutoff_baseline {K C C0 a alpha chi d D R : ℝ} {m : ℕ}
    (hK : 0≤K) (hC : 0≤C) (hC0 : C≤C0) (ha : 0<a)
    (hchi : 1/2≤chi) (hd : 0<d) (hD : 0<D) (hR : 0≤R)
    (hka : K*a≤R/D) :
    K*(C^(m+1)*a^alpha)≤(2*C*R/(d*D))*(chi*d*C0^m*a^(alpha-1)) := by
  have hC00 : 0≤C0 := hC.trans hC0
  have hpow := pow_le_pow_left₀ hC hC0 m
  have haPow : 0≤a^(alpha-1) := Real.rpow_nonneg ha.le _
  have hEq : a^alpha=a*a^(alpha-1) := by
    calc
      _=a^(1+(alpha-1)) := by congr 1;ring
      _=a^(1:ℝ)*a^(alpha-1) := Real.rpow_add ha _ _
      _=_ := by rw [Real.rpow_one]
  have hfirst : K*(C^(m+1)*a^alpha)≤C*C0^m*(R/D)*a^(alpha-1) := by
    rw [hEq,pow_succ]
    have hp := mul_le_mul hpow hka (mul_nonneg hK ha.le) (pow_nonneg hC00 m)
    have hh := mul_le_mul_of_nonneg_left hp (mul_nonneg hC haPow)
    nlinarith only [hh]
  have hnon : 0≤C*C0^m*(R/D)*a^(alpha-1) := by positivity
  have hh := mul_le_mul_of_nonneg_right hchi hnon
  have hid : (2*C*R/(d*D))*(chi*d*C0^m*a^(alpha-1))=
      2*chi*(C*C0^m*(R/D)*a^(alpha-1)) := by field_simp
  rw [hid]
  nlinarith only [hfirst,hh]

lemma upperActualBaseline_power_identity {k : ℕ} {alpha C0 d a : ℝ}
    (hk : 0<k) (ha : 0≤a) :
    upperActualBaseline k alpha C0 d a*(k:ℝ)^(1-alpha)=
      min (alpha-1) 1*d*C0^upperOrderFloor alpha*a^(alpha-1) := by
  have hkR : (0:ℝ)<k := by exact_mod_cast hk
  have hpow : (k:ℝ)^(alpha-1)*(k:ℝ)^(1-alpha)=1 := by
    rw [←Real.rpow_add hkR,show alpha-1+(1-alpha)=0 by ring,Real.rpow_zero]
  unfold upperActualBaseline
  rw [Real.mul_rpow hkR.le ha]
  calc
    _=(min (alpha-1) 1*d*C0^upperOrderFloor alpha*a^(alpha-1))*
      ((k:ℝ)^(alpha-1)*(k:ℝ)^(1-alpha)) := by ring
    _=_ := by rw [hpow,mul_one]

/-- Actual source baseline, including the uniform half-lower bound for chi. -/
theorem pilot_below_cutoff_actual_baseline {k : ℕ} {C C0 a alpha d D R eta : ℝ}
    (hk : 0<k) (hC : 0≤C) (hC0 : C≤C0) (ha : 0<a) (halpha : 3/2≤alpha)
    (hd : 0<d) (hD : 0<D) (hR : 0≤R) (heta : 0<eta)
    (hka : (k:ℝ)*a≤R/D) (hbudget : 2*C*R/(d*eta)≤D) :
    (k:ℝ)*(C^(upperOrderFloor alpha+1)*a^alpha)≤
      eta*(upperActualBaseline k alpha C0 d a*(k:ℝ)^(1-alpha)) := by
  rw [upperActualBaseline_power_identity hk ha.le]
  have hchi : (1/2:ℝ)≤min (alpha-1) 1 := le_min (by linarith only [halpha]) (by norm_num)
  have hbase := pilot_below_cutoff_baseline (K:=(k:ℝ)) (alpha:=alpha) (m:=upperOrderFloor alpha) (Nat.cast_nonneg _) hC hC0 ha hchi hd hD hR hka
  have hconst : 2*C*R/(d*D)≤eta := by
    apply (div_le_iff₀ (mul_pos hd hD)).mpr
    have hh := (div_le_iff₀ (mul_pos hd heta)).mp hbudget
    nlinarith only [hh]
  have hn : 0≤min (alpha-1) 1*d*C0^upperOrderFloor alpha*a^(alpha-1) := by
    have hc : 0≤C0 := hC.trans hC0
    have hchi0 : 0≤min (alpha-1) 1 := (by norm_num : (0:ℝ)≤1/2).trans hchi
    positivity
  exact hbase.trans (mul_le_mul_of_nonneg_right hconst hn)

end Renyi
