import Renyi.FactorialEnergy
import Renyi.NormalizationProbability
import Mathlib.Probability.HasLaw

/-!
# Factorial derivative energy for independent Poisson counts

This module connects the exact series identities to integrals and variances,
proves integrability from the Poisson law, and adds independent coordinates.
The final theorem is the complete mathematical assertion of the source
lemma `lem:factorial-energy-new`.
-/

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

theorem poisson_polynomial_memLp (lam : ℝ≥0) (L : ℕ) (c : ℕ → ℝ) :
    MemLp (factorialStatistic L c) 2 (poissonMeasure lam) :=
  poisson_memLp_of_squared_hasSum lam _ _ (poisson_polynomial_second_hasSum lam L c)

theorem poisson_polynomial_integral (lam : ℝ≥0) (L : ℕ) (c : ℕ → ℝ) :
    (∫ a, factorialStatistic L c a ∂poissonMeasure lam) =
      (polynomialOfCoefficients L c).eval (lam : ℝ) := by
  rw [poisson_integral_eq_tsum lam _ ((poisson_polynomial_memLp lam L c).integrable one_le_two)]
  have h := (poisson_polynomial_hasSum lam L c).tsum_eq
  simpa [factorialStatistic, polynomialOfCoefficients, Polynomial.eval_finset_sum] using h

theorem poisson_polynomial_variance_integral (lam : ℝ≥0) (L : ℕ) (c : ℕ → ℝ) :
    variance (factorialStatistic L c) (poissonMeasure lam) =
      ∑ j ∈ Finset.range L,
        (lam : ℝ) ^ (j + 1) / ((j + 1).factorial : ℝ) *
          (((Polynomial.derivative^[j + 1]) (polynomialOfCoefficients L c)).eval (lam : ℝ)) ^ 2 := by
  have hmem := poisson_polynomial_memLp lam L c
  rw [variance_eq_sub hmem]
  simp only [Pi.pow_apply]
  rw [poisson_integral_eq_tsum lam _ hmem.integrable_sq,
    poisson_integral_eq_tsum lam _ (hmem.integrable one_le_two)]
  exact poisson_polynomial_derivative_energy lam L c

theorem poisson_scaled_polynomial_integral (lam : ℝ≥0) (L : ℕ) (c : ℕ → ℝ)
    (n p : ℝ) (hn : n ≠ 0) (hlam : (lam : ℝ) = n * p) :
    (∫ a, factorialStatistic L (fun r => c r / n ^ r) a ∂poissonMeasure lam) =
      (polynomialOfCoefficients L c).eval p := by
  rw [poisson_polynomial_integral]
  have h := derivativeValue_rescale L c 0 n p hn
  simp only [derivativeValue_eq_iterate_derivative, Function.iterate_zero_apply,
    pow_zero, div_one] at h
  rw [hlam]
  exact h

theorem poisson_scaled_polynomial_variance_integral (lam : ℝ≥0)
    (L : ℕ) (c : ℕ → ℝ) (n p : ℝ) (hn : n ≠ 0) (hlam : (lam : ℝ) = n * p) :
    variance (factorialStatistic L (fun r => c r / n ^ r)) (poissonMeasure lam) =
      ∑ j ∈ Finset.range L,
        p ^ (j + 1) / (((j + 1).factorial : ℝ) * n ^ (j + 1)) *
          (((Polynomial.derivative^[j + 1]) (polynomialOfCoefficients L c)).eval p) ^ 2 := by
  have hmem := poisson_polynomial_memLp lam L (fun r => c r / n ^ r)
  rw [variance_eq_sub hmem]
  simp only [Pi.pow_apply]
  rw [poisson_integral_eq_tsum lam _ hmem.integrable_sq,
    poisson_integral_eq_tsum lam _ (hmem.integrable one_le_two)]
  exact poisson_scaled_polynomial_derivative_energy lam L c n p hn hlam

variable {Ω ι : Type*} [MeasurableSpace Ω] [Fintype ι]
variable {μ : Measure Ω}

def countPolynomialEstimator (N : ι → Ω → ℕ) (L : ℕ) (c : ℕ → ℝ) (n : ℝ) : Ω → ℝ :=
  fun ω => ∑ i, factorialStatistic L (fun r => c r / n ^ r) (N i ω)

omit [Fintype ι] in
theorem countPolynomial_coordinate_memLp (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (L : ℕ) (c : ℕ → ℝ) (n : ℝ) (i : ι) :
    MemLp (fun ω => factorialStatistic L (fun r => c r / n ^ r) (N i ω)) 2 μ :=
  (poisson_polynomial_memLp (lam i) L _).comp_measurePreserving (hLaw i)

variable [IsProbabilityMeasure μ]

/-- The complete mean statement needs no independence assumption. -/
theorem countPolynomialEstimator_mean (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (L : ℕ) (c : ℕ → ℝ) (n : ℝ) (p : ι → ℝ)
    (hn : n ≠ 0) (hlam : ∀ i, (lam i : ℝ) = n * p i) :
    (∫ ω, countPolynomialEstimator N L c n ω ∂μ) =
      ∑ i, (polynomialOfCoefficients L c).eval (p i) := by
  unfold countPolynomialEstimator
  rw [integral_finset_sum]
  · apply Finset.sum_congr rfl
    intro i _
    have hcomp := (hLaw i).hasLaw.integral_comp
      (measurable_of_countable (factorialStatistic L (fun r => c r / n ^ r))).aestronglyMeasurable
    change (∫ ω, (factorialStatistic L (fun r => c r / n ^ r) ∘ N i) ω ∂μ) = _
    rw [hcomp]
    exact poisson_scaled_polynomial_integral (lam i) L c n (p i) hn (hlam i)
  · intro i _
    exact (countPolynomial_coordinate_memLp N lam hLaw L c n i).integrable one_le_two

omit [IsProbabilityMeasure μ] in
/-- Independent counts add their exact derivative energies. -/
theorem countPolynomialEstimator_variance (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (L : ℕ) (c : ℕ → ℝ) (n : ℝ) (p : ι → ℝ)
    (hn : n ≠ 0) (hlam : ∀ i, (lam i : ℝ) = n * p i) :
    variance (countPolynomialEstimator N L c n) μ =
      ∑ i, ∑ j ∈ Finset.range L,
        (p i) ^ (j + 1) / (((j + 1).factorial : ℝ) * n ^ (j + 1)) *
          (((Polynomial.derivative^[j + 1]) (polynomialOfCoefficients L c)).eval (p i)) ^ 2 := by
  let F : ι → Ω → ℝ := fun i ω => factorialStatistic L (fun r => c r / n ^ r) (N i ω)
  have hF : ∀ i, MemLp (F i) 2 μ := fun i => countPolynomial_coordinate_memLp N lam hLaw L c n i
  have hpairF : Pairwise (fun i j => IndepFun (F i) (F j) μ) := by
    intro i j hij
    exact (hpair hij).comp
      (φ := factorialStatistic L (fun r => c r / n ^ r))
      (ψ := factorialStatistic L (fun r => c r / n ^ r))
      (measurable_of_countable _) (measurable_of_countable _)
  have hadd : variance (countPolynomialEstimator N L c n) μ = ∑ i, variance (F i) μ := by
    convert (IndepFun.variance_sum (s := Finset.univ) (X := F)
      (fun i _ => hF i) (fun i _ j _ hij => hpairF hij)) using 1
    congr 1
    funext ω
    simp [countPolynomialEstimator, F]
  rw [hadd]
  apply Finset.sum_congr rfl
  intro i _
  rw [(hLaw i).variance_fun_comp
    (measurable_of_countable (factorialStatistic L (fun r => c r / n ^ r))).aemeasurable]
  exact poisson_scaled_polynomial_variance_integral (lam i) L c n (p i) hn (hlam i)

/-- Full factorial derivative-energy lemma for finite independent Poisson counts.
The laws of the counts imply all required first- and second-moment conditions. -/
theorem factorial_derivative_energy (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (L : ℕ) (c : ℕ → ℝ) (n : ℝ) (p : ι → ℝ)
    (hn : 0 < n) (hlam : ∀ i, (lam i : ℝ) = n * p i) :
    ((∫ ω, countPolynomialEstimator N L c n ω ∂μ) =
      ∑ i, (polynomialOfCoefficients L c).eval (p i)) ∧
    (variance (countPolynomialEstimator N L c n) μ =
      ∑ i, ∑ j ∈ Finset.range L,
        (p i) ^ (j + 1) / (((j + 1).factorial : ℝ) * n ^ (j + 1)) *
          (((Polynomial.derivative^[j + 1]) (polynomialOfCoefficients L c)).eval (p i)) ^ 2) :=
  ⟨countPolynomialEstimator_mean N lam hLaw L c n p (ne_of_gt hn) hlam,
    countPolynomialEstimator_variance N lam hLaw hpair L c n p (ne_of_gt hn) hlam⟩

end Renyi
