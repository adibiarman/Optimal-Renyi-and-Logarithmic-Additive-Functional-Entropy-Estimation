import Renyi.EndpointLower

/-! The collision baseline closes the bounded-root noninteger regime. -/
noncomputable section
namespace Renyi

/-- Below the saturation threshold, collision testing retains the complete
order factor and covers any fixed bound on the root multiplier. -/
theorem lower_bounded_root_sample_lower {eps X : ℝ} (he : 0<eps) (hX : 1≤X) :
    ∃ c : ℝ, 0<c ∧ ∃ K : ℕ, 2≤K ∧ ∀ k : ℕ, K≤k → ∀ alpha : ℝ,
      3/2≤alpha → alpha<Real.log k → rootMultiplier k alpha eps≤X →
      ∀ n : ℕ, Achievable k n alpha eps →
      c*alpha*(k:ℝ)^(1-1/alpha)*rootMultiplier k alpha eps≤n := by
  obtain ⟨c,hc,K,hK,hCollision⟩ := collision_iid_lower_uniform he
  have hX0 : 0<X := zero_lt_one.trans_le hX
  refine ⟨c/X,div_pos hc hX0,K,hK,?_⟩
  intro k hk alpha ha hlow hroot n hach
  have hnecess : c*(alpha*(k:ℝ)^(1-1/alpha))≤n := by
    apply (lt_of_not_ge (fun hn => ?_)).le
    apply hCollision k hk alpha ha n ?_ hach
    simpa only [min_eq_left hlow.le,mul_assoc] using hn
  have hscale := mul_le_mul_of_nonneg_left hroot
    (show 0≤(c/X)*alpha*(k:ℝ)^(1-1/alpha) by positivity)
  have hid : (c/X)*alpha*(k:ℝ)^(1-1/alpha)*X=c*(alpha*(k:ℝ)^(1-1/alpha)) := by field_simp
  rw [hid] at hscale
  exact hscale.trans hnecess

/-- The bounded-root noninteger branch is a lower bound in the exact public
extended-rate notation, with no missing factor of the order. -/
theorem lower_bounded_noninteger_rate {eps X : ℝ} (he : 0<eps) (hX : 1≤X) :
    ∃ c : ℝ, 0<c ∧ ∃ K : ℕ, 2≤K ∧ ∀ k : ℕ, K≤k → ∀ alpha : ℝ,
      3/2≤alpha → alpha<Real.log k → (¬∃r:ℕ,alpha=(r:ℝ)) →
      rootMultiplier k alpha eps≤X →
      ∀ n : ℕ, Achievable k n alpha eps → c*rate k alpha eps≤n := by
  obtain ⟨c,hc,K,hK,hLower⟩ := lower_bounded_root_sample_lower he hX
  refine ⟨c,hc,K,hK,?_⟩
  intro k hk alpha ha hlow hnoninteger hroot n hach
  have hh := hLower k hk alpha ha hlow hroot n hach
  have hrepr : extendedMultiplier k alpha eps=rootMultiplier k alpha eps := by
    unfold extendedMultiplier
    rw [if_neg (not_le.mpr hlow),if_neg hnoninteger]
  unfold rate
  rw [hrepr]
  simpa only [mul_assoc] using hh

end Renyi
