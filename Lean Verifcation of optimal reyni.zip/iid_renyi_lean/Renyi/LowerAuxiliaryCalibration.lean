import Renyi.LowerExperimentTransfer
import Renyi.LowerCalibration
import Mathlib.Analysis.Complex.ExponentialBounds

/-! Uniform support and availability calibration for the lower experiments. -/
noncomputable section
open scoped BigOperators NNReal Topology
open Filter
namespace Renyi

/-- A fixed alphabet cutoff already controls the exact support-overflow expression. -/
theorem lower_support_budget {k : ℕ} (hk : 64 ≤ k) :
    (Real.exp 1 / 4) ^ ((k : ℝ) / 2) ≤ 1 / 128 := by
  have hbase : Real.exp 1 / 4 ≤ (3 : ℝ) / 4 := by
    linarith [Real.exp_one_lt_d9]
  have hkR : (64 : ℝ) ≤ k := by exact_mod_cast hk
  calc
    _ ≤ ((3 : ℝ) / 4) ^ ((k : ℝ) / 2) :=
      Real.rpow_le_rpow (by positivity) hbase (by positivity)
    _ ≤ ((3 : ℝ) / 4) ^ (32 : ℝ) :=
      Real.rpow_le_rpow_of_exponent_ge (by norm_num) (by norm_num) (by linarith)
    _ ≤ 1 / 128 := by norm_num

/-- For positive active degree, the sample exposure has a uniform cube-root
lower bound, independently of the order and the root multiplier. -/
theorem lower_positive_degree_exposure {k : ℕ} {alpha c X : ℝ}
    (hk : 1 ≤ k) (ha : 3 / 2 ≤ alpha) (hc : 0 < c) (hX : 1 ≤ X) :
    (3 * c / 4) * (k : ℝ) ^ (1 / 3 : ℝ) ≤
      (c * alpha * (k : ℝ) ^ (-1 / alpha) * X) * ((k : ℝ) / 2) := by
  have hkR : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hk0 : (0 : ℝ) < k := zero_lt_one.trans_le hkR
  have ha0 : 0 < alpha := by linarith
  have he : (1 / 3 : ℝ) ≤ 1 - 1 / alpha := by
    have h := (div_le_iff₀ ha0).mpr (show (1 : ℝ) ≤ (2/3)*alpha by linarith)
    linarith
  have hpow := Real.rpow_le_rpow_of_exponent_le hkR he
  have hscale : (3*c/4) ≤ c*alpha*X/2 := by
    have hx : 0 ≤ X-1 := by linarith
    have hprod := mul_nonneg (mul_pos hc ha0).le hx
    nlinarith
  have hp0 : 0 ≤ (k : ℝ) ^ (1 - 1 / alpha) := Real.rpow_nonneg hk0.le _
  have hpow0 : 0 ≤ (k : ℝ) ^ (1 / 3 : ℝ) := Real.rpow_nonneg hk0.le _
  have hfinal := mul_le_mul hscale hpow hpow0 (by positivity : 0 ≤ c*alpha*X/2)
  have hid : (k : ℝ) ^ (-1 / alpha) * k = (k : ℝ) ^ (1 - 1 / alpha) := by
    calc
      _ = (k : ℝ) ^ (-1 / alpha) * (k : ℝ) ^ (1 : ℝ) := by rw [Real.rpow_one]
      _ = _ := by
        rw [← Real.rpow_add hk0]
        congr 1
        ring
  calc
    _ ≤ c*alpha*X/2 * (k : ℝ) ^ (1 - 1 / alpha) := hfinal
    _ = _ := by rw [← hid]; ring

/-- A deterministic cube-root cutoff makes the availability budget uniform over
all orders at least three halves and all root multipliers at least one. -/
theorem lower_positive_degree_availability {k : ℕ} {alpha c X : ℝ}
    (hk : 1 ≤ k) (ha : 3 / 2 ≤ alpha) (hc : 0 < c) (hX : 1 ≤ X)
    (hcut : 16 * Real.log 128 ≤ (3*c/4)*(k : ℝ) ^ (1/3 : ℝ)) :
    Real.exp (-((c*alpha*(k : ℝ)^(-1/alpha)*X)*((k : ℝ)/2))/16) ≤ 1/128 := by
  have h := lower_positive_degree_exposure hk ha hc hX
  calc
    _ ≤ Real.exp (-Real.log 128) := Real.exp_le_exp.mpr (by linarith)
    _ = 1/128 := by rw [Real.exp_neg, Real.exp_log (by norm_num : (0 : ℝ) < 128)]; norm_num

/-- An explicit order-independent alphabet cutoff for the two exceptional
Poisson events at positive active degree. -/
theorem lower_positive_degree_exception_cutoff {c : ℝ} (hc : 0 < c) :
    ∃ k0 : ℕ, ∀ k : ℕ, k0 ≤ k → ∀ alpha X : ℝ, 3/2 ≤ alpha → 1 ≤ X →
      (Real.exp 1 / 4) ^ ((k : ℝ)/2) ≤ 1/128 ∧
      Real.exp (-((c*alpha*(k : ℝ)^(-1/alpha)*X)*((k : ℝ)/2))/16) ≤ 1/128 := by
  let T := 64 * Real.log 128 / (3*c)
  have hT : 0 < T := by dsimp [T]; positivity
  let k0 := max 64 (Nat.ceil (T^3))
  refine ⟨k0, ?_⟩
  intro k hk alpha X ha hX
  have hk64 : 64 ≤ k := (le_max_left _ _).trans hk
  have hk1 : 1 ≤ k := by omega
  have hceil : T^3 ≤ (k : ℝ) :=
    (Nat.le_ceil _).trans (by exact_mod_cast (le_max_right 64 (Nat.ceil (T^3))).trans hk)
  have hroot := Real.rpow_le_rpow (by positivity : (0 : ℝ) ≤ T^3) hceil
    (by norm_num : (0 : ℝ) ≤ 1/3)
  have hrootid : (T^3) ^ (1/3 : ℝ) = T := by
    rw [← Real.rpow_natCast_mul hT.le]
    norm_num
  rw [hrootid] at hroot
  have hcut : 16*Real.log 128 ≤ (3*c/4)*(k : ℝ)^(1/3 : ℝ) := by
    have h := mul_le_mul_of_nonneg_left hroot (show 0 ≤ 3*c/4 by positivity)
    have hid : (3*c/4)*T = 16*Real.log 128 := by dsimp [T]; field_simp; norm_num
    rwa [hid] at h
  exact ⟨lower_support_budget hk64, lower_positive_degree_availability hk1 ha hc hX hcut⟩

/-- Convert the explicit prior values used by the observation theorem into the
same finite-prior representation used by the interpolation construction. -/
def nonnegativeFinitePrior {L : ℕ} (p z : Fin L → ℝ≥0)
    (hp : ∑ i, p i = 1) : FiniteAtomicPrior (Fin L) where
  mass := fun i => p i
  value := fun i => z i
  mass_nonneg := fun i => (p i).coe_nonneg
  mass_sum := by
    have h := congrArg (fun r : ℝ≥0 => (r : ℝ)) hp
    simpa only [NNReal.coe_sum, NNReal.coe_one] using h

/-- The source normalization-failure budget follows from its refined power
second moment and exact support/mean assumptions. The near-one factor remains
explicit; it is not discarded in the residual variance. -/
theorem normalization_budget_from_power_second {L : ℕ}
    (b : ℝ≥0) (hb : 0 < (b : ℝ)) (p z : Fin L → ℝ≥0) (hp : ∑ i, p i = 1)
    {alpha A B m M : ℝ} (ha : 1 < alpha) (hB : 1 ≤ B) (hm : 0 < m)
    (hmean : ∑ i, (p i : ℝ) * z i = 1)
    (hpower : ∑ i, (p i : ℝ) * (z i : ℝ)^alpha = A)
    (hsupp : ∀ i, (z i : ℝ) = 0 ∨ (1 ≤ (z i : ℝ) ∧ (z i : ℝ) ≤ B))
    (hM : (∑ i, (p i : ℝ) * (z i : ℝ)^(2*alpha)) / A^2 ≤ M) :
    normalizationMomentBudget b p z alpha A m ≤
      B / ((b : ℝ)*(min (1/4) (m/(16*(alpha-1))))^2) +
      (min 1 ((alpha-1)*Real.log B))^2 * (M+B) / ((b : ℝ)*(m/16)^2) := by
  let P := nonnegativeFinitePrior p z hp
  have hmeanP : priorMoment P 1 = 1 := by simpa [P, nonnegativeFinitePrior, priorMoment] using hmean
  have hpowerP : priorMoment P alpha = A := hpower
  have hAB := finite_prior_power_bounds P alpha B ha hB hsupp hmeanP
  rw [hpowerP] at hAB
  have hA : 0 < A := by linarith
  have hres := finite_prior_residual_noise_bound P alpha B ha hB hsupp hmeanP
  unfold priorResidualSecondMoment at hres
  rw [hpowerP] at hres
  have hres' : (∑ i, (p i : ℝ)*((z i : ℝ)^alpha-A*z i)^2) / A^2 ≤
      (min 1 ((alpha-1)*Real.log B))^2*(M+B) := by
    change (∑ i, (p i : ℝ)*((z i : ℝ)^alpha-A*z i)^2) / A^2 ≤
      (min 1 ((alpha-1)*Real.log B))^2*(priorMoment P (2*alpha)/A^2+B) at hres
    exact hres.trans (mul_le_mul_of_nonneg_left (add_le_add_right hM B) (sq_nonneg _))
  have hsupp' : ∀ i, 0 ≤ P.value i ∧ P.value i ≤ B := by
    intro i
    rcases hsupp i with h | h
    · change 0 ≤ (z i : ℝ) ∧ (z i : ℝ) ≤ B
      rw [h]
      constructor <;> linarith
    · exact ⟨(z i).coe_nonneg, h.2⟩
  have hsecond := finite_prior_second_moment_le P B hsupp' hmeanP
  have hsecond' : (∑ i, (p i : ℝ)*(z i : ℝ)^2) ≤ B := by
    simpa only [P, nonnegativeFinitePrior, priorMoment, Real.rpow_two] using hsecond
  have hbeta : 0 < alpha-1 := sub_pos.mpr ha
  have ht : 0 < min (1/4 : ℝ) (m/(16*(alpha-1))) := lt_min (by norm_num) (by positivity)
  have hu : 0 < (b : ℝ)*(m/16)^2 := by positivity
  have h1 := div_le_div_of_nonneg_right hsecond' (by positivity : 0 ≤ (b : ℝ)*(min (1/4 : ℝ) (m/(16*(alpha-1))))^2)
  have h2 := div_le_div_of_nonneg_right hres' hu.le
  have heq : ((∑ i, (p i : ℝ)*((z i : ℝ)^alpha-A*z i)^2)/A^2) /
      ((b : ℝ)*(m/16)^2) = (∑ i, (p i : ℝ)*((z i : ℝ)^alpha-A*z i)^2) /
        ((b : ℝ)*A^2*(m/16)^2) := by field_simp
  rw [heq] at h2
  exact add_le_add h1 h2

/-- A single alphabet cutoff controls every polylogarithmic normalization
remainder and the sample availability at the near-one intensity scale. -/
theorem lower_near_one_exception_cutoff {c C : ℝ} (hc : 0 < c) (hC : 0 < C) :
    ∃ k0 : ℕ, ∀ k : ℕ, k0 ≤ k →
      C*(1+Real.log k)^5/(k : ℝ) ≤ 1/64 ∧
      (Real.exp 1/4)^((k : ℝ)/2) ≤ 1/128 ∧
      ∀ theta : ℝ, c/(1+Real.log k) ≤ theta →
        Real.exp (-(theta*((k : ℝ)/2))/16) ≤ 1/128 := by
  have hcast : Tendsto (fun k : ℕ => (k : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have h0 : Tendsto (fun k : ℕ => (1 : ℝ)/(k : ℝ)) atTop (𝓝 0) := by
    simpa only [pow_zero, one_mul, add_zero] using
      (Real.tendsto_pow_log_div_mul_add_atTop 1 0 0 one_ne_zero).comp hcast
  have h1 : Tendsto (fun k : ℕ => Real.log k/(k : ℝ)) atTop (𝓝 0) := by
    simpa only [pow_one, one_mul, add_zero] using
      (Real.tendsto_pow_log_div_mul_add_atTop 1 0 1 one_ne_zero).comp hcast
  have hratio : Tendsto (fun k : ℕ => (1+Real.log k)/(k : ℝ)) atTop (𝓝 0) := by
    simpa only [add_div, zero_add] using h0.add h1
  have h5 : Tendsto (fun k : ℕ => (32*C)*Real.log k^5/(k : ℝ)) atTop (𝓝 0) := by
    have h := (tendsto_const_nhds : Tendsto (fun _ : ℕ => 32*C) atTop (𝓝 (32*C))).mul
      ((Real.tendsto_pow_log_div_mul_add_atTop 1 0 5 one_ne_zero).comp hcast)
    simpa only [one_mul, add_zero, mul_zero, mul_div_assoc] using h
  have he : ∀ᶠ k : ℕ in atTop,
      1 ≤ Real.log k ∧ (32*C)*Real.log k^5/(k : ℝ) ≤ 1/64 ∧
        (1+Real.log k)/(k : ℝ) ≤ c/(32*Real.log 128) := by
    filter_upwards [(Real.tendsto_log_atTop.comp hcast).eventually_ge_atTop 1,
      h5.eventually_le_const (by norm_num : (0 : ℝ) < 1/64),
      hratio.eventually_le_const (show 0 < c/(32*Real.log 128) by positivity)] with k hk h5 hratio
    exact ⟨hk, h5, hratio⟩
  obtain ⟨K, hK⟩ := eventually_atTop.mp he
  refine ⟨max 64 K, ?_⟩
  intro k hk
  have hk64 : 64 ≤ k := (le_max_left _ _).trans hk
  have hk0 : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  obtain ⟨hlog, hnoise, hsmall⟩ := hK k ((le_max_right _ _).trans hk)
  have hden : 0 < 1+Real.log k := by linarith
  have hpow : (1+Real.log k)^5 ≤ 32*Real.log k^5 := by
    have h := pow_le_pow_left₀ (by linarith : 0 ≤ 1+Real.log k)
      (show 1+Real.log k ≤ 2*Real.log k by linarith) 5
    norm_num [mul_pow] at h ⊢
    exact h
  have hbudget : C*(1+Real.log k)^5/(k : ℝ) ≤ 1/64 := by
    have h := div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hpow hC.le) hk0.le
    have hscaled : C*(1+Real.log k)^5/(k : ℝ) ≤ (32*C)*Real.log k^5/(k : ℝ) := by
      convert h using 1; ring
    exact hscaled.trans hnoise
  refine ⟨hbudget, lower_support_budget hk64, ?_⟩
  intro theta htheta
  have hlog128 : 0 < Real.log (128 : ℝ) := by positivity
  have hratio' := (div_le_div_iff₀ hk0 (mul_pos (by norm_num) hlog128)).mp hsmall
  have htheta' := (div_le_iff₀ hden).mp htheta
  have hthetaK := mul_le_mul_of_nonneg_right htheta' hk0.le
  have hthetaExposure : 32*Real.log 128 ≤ theta*(k : ℝ) := by
    apply (mul_le_mul_iff_right₀ hden).mp
    nlinarith [hratio', hthetaK]
  calc
    _ ≤ Real.exp (-Real.log 128) := Real.exp_le_exp.mpr (by nlinarith)
    _ = 1/128 := by rw [Real.exp_neg, Real.exp_log (by norm_num : (0 : ℝ) < 128)]; norm_num

end Renyi
