import Renyi.CoupledCutoff

/-! Quantitative upper gaps for the actual damped and cutoff coupled expression. -/
noncomputable section
namespace Renyi

def coupledDampedExpression (ℓ N : ℕ) (γ z M ω fL f x y : ℝ) : ℝ :=
  (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+
  (overlapB γ z*Real.exp (-M*(1-γ)))*highProfile N (1-γ) f ω y+
  ω*(1-overlapB γ z*Real.exp (-M*(1-γ)))*endpointProfile N 6 (1-γ) y

lemma cutoff_convex_upper {a b u v ω H J r e : ℝ}
    (hH : 0≤H) (hH1 : H≤1) (hb : 0≤b) (hb1 : b≤1)
    (hv1 : v≤1) (hω : 0≤ω) (hS : a*u+b*v≤r) (hJH : J-H≤e) :
    a*u*(1-H)+b*v+ω*(1-b)*J ≤
      max r (ω+(1-ω)*b)+ω*(1-b)*e := by
  have hR : b*v+ω*(1-b)≤ω+(1-ω)*b := by
    have hm := mul_le_mul_of_nonneg_left hv1 hb
    nlinarith only [hm]
  have hm1 := mul_le_mul_of_nonneg_left (hS.trans (le_max_left r (ω+(1-ω)*b))) (sub_nonneg.mpr hH1)
  have hm2 := mul_le_mul_of_nonneg_left (hR.trans (le_max_right r (ω+(1-ω)*b))) hH
  have hm3 := mul_le_mul_of_nonneg_left hJH (mul_nonneg hω (sub_nonneg.mpr hb1))
  nlinarith only [hm1,hm2,hm3]

lemma damped_overlap_upper {A B u v γ M : ℝ} (_hγ : 0<γ) (_hγ1 : γ<1)
    (hM : 0≤M) (hA : 0≤A) (hB : 0≤B) (hu : 0≤u) (hv : 0≤v)
    (hlin : A*u+B*v≤1) :
    (A*Real.exp (-M*γ))*u+(B*Real.exp (-M*(1-γ)))*v ≤
      Real.exp (-M*min γ (1-γ)) := by
  have he1 := Real.exp_le_exp.mpr
    (neg_le_neg (mul_le_mul_of_nonneg_left (min_le_left γ (1-γ)) hM))
  have he2 := Real.exp_le_exp.mpr
    (neg_le_neg (mul_le_mul_of_nonneg_left (min_le_right γ (1-γ)) hM))
  simp only [←neg_mul] at he1 he2
  have hm1 := mul_le_mul_of_nonneg_right he1 (mul_nonneg hA hu)
  have hm2 := mul_le_mul_of_nonneg_right he2 (mul_nonneg hB hv)
  have hm3 := mul_le_mul_of_nonneg_left hlin (Real.exp_pos (-M*min γ (1-γ))).le
  nlinarith only [hm1,hm2,hm3]

/-- The only cutoff price in the actual upper envelope is the proven J_delta-J_1 difference. -/
theorem coupledProfiles_cutoff_upper {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z M ω fL f x y : ℝ} (hγ : 0<γ) (hγhalf : γ≤1/2) (hM : 0≤M)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hω1 : ω<1) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hz1 : z<1)
    (hcap : ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y ≤
      max (Real.exp (-M*γ)) (ω+(1-ω)*(overlapB γ z*Real.exp (-M*(1-γ))))+
      ω*(1-overlapB γ z*Real.exp (-M*(1-γ)))*(40*Real.exp (Real.log 12+1))*γ := by
  have hγ1 : γ<1 := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hlin := coupledProfiles_scalar_upper hℓ hN hγ hγ1 hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hz hz1 hcap
  have hdamp := damped_overlap_upper hγ hγ1 hM hc.1.le hc.2.2.1.le hu.1 hv.1 hlin
  rw [min_eq_left (by linarith only [hγhalf] : γ≤1-γ)] at hdamp
  have hb0 : 0≤overlapB γ z*Real.exp (-M*(1-γ)) := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have hb1 : overlapB γ z*Real.exp (-M*(1-γ))≤1 := by
    exact (mul_le_of_le_one_right hc.2.2.1.le (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hd]))).trans hc.2.2.2.le
  have hdiff := (endpointProfile_order_one_comparison hN (by norm_num : 2≤6) (by norm_num : 6≤6)
    (by linarith only [hγhalf] : (1:ℝ)/2≤1-γ) (by linarith only [hγ] : 1-γ≤1) hy hy1).2
  have hdiff' : endpointProfile N 6 (1-γ) y-endpointProfile N 6 1 y≤(40*Real.exp (Real.log 12+1))*γ := by
    convert hdiff using 1; ring
  have h := cutoff_convex_upper hH.1 hH.2 hb0 hb1 hv.2 hω hdamp hdiff'
  unfold coupledDampedExpression
  nlinarith only [h]

/-- An explicit strict linear gap for fractional parts close to zero. -/
theorem coupledProfiles_small_fraction_upper_gap {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z M ω ρ fL f x y : ℝ} (hγ : 0<γ) (hγhalf : γ≤1/2)
    (hM2 : 2≤M) (hMC : 4*(40*Real.exp (Real.log 12+1))≤M)
    (hρ : 0<ρ) (hρ1 : ρ≤1) (hscale : M*γ≤ρ)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωρ : ω≤1-ρ) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hz1 : z<1)
    (hcap : ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y ≤ 1-M*γ/4 := by
  have hM : 0≤M := by linarith only [hM2]
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hγ1 : γ<1 := by linarith only [hγhalf]
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := coupledProfiles_cutoff_upper hℓ hN hγ hγhalf hM hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hz hz1 hcap
  have hMγ : 0≤M*γ := mul_nonneg hM hγ.le
  have he1 : Real.exp (-M*γ)≤1-M*γ/2 := by
    simpa only [neg_mul] using exp_neg_le_linear_half hMγ (hscale.trans hρ1)
  have he2 : Real.exp (-M*(1-γ))≤(1:ℝ)/2 := by
    rw [show -M*(1-γ)=-(M*(1-γ)) by ring,Real.exp_neg]
    have hh : 2≤Real.exp (M*(1-γ)) := by
      have he := Real.add_one_le_exp (M*(1-γ))
      nlinarith only [he,mul_nonneg (by linarith only [hM2] : 0≤M-2) (by linarith only [hγhalf] : 0≤1-γ),hγhalf]
    simpa only [one_div] using one_div_le_one_div_of_le (by norm_num : (0:ℝ)<2) hh
  have hb : overlapB γ z*Real.exp (-M*(1-γ))≤(1:ℝ)/2 :=
    (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans he2
  have hb0 : 0≤overlapB γ z*Real.exp (-M*(1-γ)) := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have hr : ω+(1-ω)*(overlapB γ z*Real.exp (-M*(1-γ)))≤1-M*γ/2 := by
    have hm := mul_le_mul_of_nonneg_left hb (sub_nonneg.mpr hω1.le)
    nlinarith only [hm,hωρ,hscale]
  have hmax := max_le he1 hr
  have hecoef : ω*(1-overlapB γ z*Real.exp (-M*(1-γ)))≤1 := by
    have hm := mul_le_mul_of_nonneg_left (show 1-overlapB γ z*Real.exp (-M*(1-γ))≤1 by linarith only [hb0]) hω
    nlinarith only [hm,hω1]
  have herr := mul_le_mul_of_nonneg_right hecoef
    (show 0≤(40*Real.exp (Real.log 12+1))*γ by positivity)
  have hCM := mul_le_mul_of_nonneg_right hMC hγ.le
  nlinarith only [hu,hmax,herr,hCM]


lemma small_order_scaled_power_lower {δ c E : ℝ} (hδ : 0<δ) (hc : 0<c)
    (hroot : 8*Real.sqrt δ≤E) (hlog : 4*δ*(-Real.log c)≤E) :
    Real.exp (-E/2)≤(c*δ)^δ := by
  have hr := Real.sqrt_pos.mpr hδ
  have hh := Real.one_sub_inv_le_log_of_pos hr
  have hm := mul_le_mul_of_nonneg_left hh (show 0≤2*δ by positivity)
  have hid : δ*(Real.sqrt δ)⁻¹=Real.sqrt δ := by
    apply (mul_right_cancel₀ hr.ne')
    rw [mul_assoc,inv_mul_cancel₀ hr.ne',mul_one,←pow_two,Real.sq_sqrt hδ.le]
  rw [Real.log_sqrt hδ.le] at hm
  have hlogδ : -2*Real.sqrt δ≤δ*Real.log δ := by nlinarith only [hm,hid,hδ]
  rw [Real.rpow_def_of_pos (mul_pos hc hδ),Real.log_mul hc.ne' hδ.ne']
  apply Real.exp_le_exp.mpr
  nlinarith only [hlogδ,hroot,hlog]

lemma product_high_separation {u v γ z E c : ℝ}
    (_hγ : 0<γ) (hγ1 : γ<1) (hu : c≤u) (hc : 0<c)
    (hv : 0≤v) (hv1 : v≤1) (hpow : Real.exp (-E/2)≤c^(1-γ))
    (hprod : u^(1-γ)*v^γ≤z) (hz : z≤Real.exp (-E)) :
    v≤Real.exp (-E/2) := by
  have hd : 0≤1-γ := by linarith only [hγ1]
  have hp := hpow.trans (Real.rpow_le_rpow hc.le hu hd)
  have hm := (mul_le_mul_of_nonneg_right hp (Real.rpow_nonneg hv γ)).trans (hprod.trans hz)
  have hquot : v^γ≤Real.exp (-E/2) := by
    apply (mul_le_mul_iff_right₀ (Real.exp_pos (-E/2))).mp
    have heq : Real.exp (-E/2)*Real.exp (-E/2)=Real.exp (-E) := by
      rw [←Real.exp_add];congr 1;ring
    rw [heq]
    simpa only [mul_comm] using hm
  by_cases hv0 : v=0
  · rw [hv0];exact (Real.exp_pos _).le
  have hvp : 0<v := lt_of_le_of_ne hv (Ne.symm hv0)
  have hself := Real.rpow_le_rpow_of_exponent_ge hvp hv1 hγ1.le
  rw [Real.rpow_one] at hself
  exact hself.trans hquot

/-- A strict linear gap near fractional part one, with an explicit small-order threshold. -/
theorem coupledProfiles_small_complement_upper_gap {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z E M ω ρ fL f x y : ℝ} (hγhalf : (1:ℝ)/2≤γ) (hγ1 : γ<1)
    (hM : 1≤M) (hρ : 0<ρ) (_hρ1 : ρ≤1)
    (hMρ : Real.exp (-M/2)≤ρ/2) (hEρ : Real.exp (-E/2)≤1-ρ)
    (hroot : 8*Real.sqrt (1-γ)≤E) (hlog : 4*(1-γ)*(-Real.log (ρ/4))≤E)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωρ : ω≤1-ρ) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hzE : z≤Real.exp (-E))
    (hcap : ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y ≤1-ρ*(1-γ)/4 := by
  have hγ : 0<γ := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hM0 : 0≤M := by linarith only [hM]
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hE : 0<E := lt_of_lt_of_le (by positivity : 0<8*Real.sqrt (1-γ)) hroot
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hy hy1
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have hb1 : b≤1-(1-γ)/2 := by
    have he : Real.exp (-M*(1-γ))≤Real.exp (-(1-γ)) := Real.exp_le_exp.mpr (by nlinarith only [hM,hd])
    exact (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      (he.trans (exp_neg_le_linear_half hd.le hd1))
  have hb1' : b≤1 := by linarith only [hb1,hd]
  have ha1 : a≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM0,hγ]))
  have hT : coupledDampedExpression ℓ N γ z M ω fL f x y ≤
      a*lowProfile ℓ γ fL x+b*highProfile N (1-γ) f ω y+ω*(1-b) := by
    have hlow := mul_le_of_le_one_right (mul_nonneg ha0 hu.1) (by linarith only [hH.1] : 1-endpointProfile N 6 1 y≤1)
    have hlast := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hb1')) hJ.2
    unfold coupledDampedExpression
    change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+b*highProfile N (1-γ) f ω y+
      ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
    linarith only [hlow,hlast]
  by_cases hus : lowProfile ℓ γ fL x≤ρ*(1-γ)/4
  · have hlow := (mul_le_of_le_one_left hu.1 ha1).trans hus
    have hhigh := mul_le_mul_of_nonneg_left hv.2 hb0
    have hωb := mul_le_mul_of_nonneg_right hωρ (sub_nonneg.mpr hb1')
    have hgap := mul_le_mul_of_nonneg_left hb1 hρ.le
    nlinarith only [hT,hlow,hhigh,hωb,hgap]
  · have hp := small_order_scaled_power_lower hd (by positivity : 0<ρ/4) hroot hlog
    have hprod := coupledProfiles_product_le hℓ hN hγ hγ1 hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hz hcap
    have hcpos : 0<ρ*(1-γ)/4 := by positivity
    have hp' : Real.exp (-E/2)≤(ρ*(1-γ)/4)^(1-γ) := by convert hp using 1;congr 1;ring
    have hvsep := (product_high_separation hγ hγ1 (lt_of_not_ge hus).le hcpos hv.1 hv.2 hp' hprod hzE).trans hEρ
    have haρ : a≤ρ/2 := by
      apply (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
      apply le_trans _ hMρ
      apply Real.exp_le_exp.mpr
      nlinarith only [mul_le_mul_of_nonneg_left hγhalf hM0]
    have hlow := (mul_le_of_le_one_right ha0 hu.2).trans haρ
    have hhigh := mul_le_mul_of_nonneg_left hvsep hb0
    have hωb := mul_le_mul_of_nonneg_right hωρ (sub_nonneg.mpr hb1')
    have hrδ := mul_le_mul_of_nonneg_left hd1 hρ.le
    nlinarith only [hT,hlow,hhigh,hωb,hrδ,hρ]

end Renyi
