import Renyi.LowerDefectAtoms
import Renyi.TensorSecondMoment

/-! Endpoint control of the actual unmatched-moment scale. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- The endpoint coefficient supplies a lower bound on either canceled
Jordan moment, without losing the raw interpolation normalizer. -/
theorem normalized_jordan_endpoint_raw {n : ℕ} (u : Fin (n+1)→ℝ)
    {a ρ e β : ℝ} (ha : 0<a) (hρ : 0≤ρ) (hu : ∀ i,0<u i)
    (j : Fin (n+1)) (hj : u j=1)
    (hcancel : ∑ i, normalizedInterpolation u a ρ e i*interpolationNodes u a i^β=0) :
    |lagrangeWeight u a j|/(2*interpolationNormalizer u a ρ e) ≤
      ∑ i, positiveCoeff (normalizedInterpolation u a ρ e i)*interpolationNodes u a i^β := by
  let P := interpolationNormalizer u a ρ e
  have hP : 0<P := interpolationNormalizer_pos u (e:=e) ha hρ
  have hnodes (i : Option (Fin (n+1))) : 0 < interpolationNodes u a i := by
    cases i with | none => exact ha | some i => exact hu i
  have htwo := absolute_power_moment_eq_twice (normalizedInterpolation u a ρ e)
    (interpolationNodes u a) β hcancel
  have hh := Finset.single_le_sum
    (s := (Finset.univ : Finset (Option (Fin (n+1)))))
    (f := fun i => |normalizedInterpolation u a ρ e i| *interpolationNodes u a i^β)
    (fun i _ => mul_nonneg (abs_nonneg _) (Real.rpow_pos_of_pos (hnodes i) _).le)
    (Finset.mem_univ (some j))
  change |normalizedInterpolation u a ρ e (some j)| *(u j)^β≤_ at hh
  rw [hj,Real.one_rpow,mul_one,htwo] at hh
  have hatom : |normalizedInterpolation u a ρ e (some j)|=
      |lagrangeWeight u a j| *(1+ρ*a)/P := by
    simp only [normalizedInterpolation,weightedInterpolation,interpolationWeights,
      interpolationNodes,Option.elim_some,hj,Real.one_rpow,mul_one,div_one,
      abs_div,abs_neg,abs_mul,abs_of_nonneg (show 0≤1+ρ*a by positivity)]
    change |lagrangeWeight u a j| *(1+ρ*a)/|P|=_
    rw [abs_of_pos hP]
  rw [hatom] at hh
  have hlo : |lagrangeWeight u a j|/P≤|lagrangeWeight u a j| *(1+ρ*a)/P := by
    apply div_le_div_of_nonneg_right _ hP.le
    nlinarith [mul_nonneg (abs_nonneg (lagrangeWeight u a j)) (mul_nonneg hρ ha.le)]
  have hraw := hlo.trans hh
  change |lagrangeWeight u a j|/(2*P)≤_
  have he : |lagrangeWeight u a j|/(2*P)=(|lagrangeWeight u a j|/P)/2 := by ring
  rw [he]
  linarith

/-- The actual high principal atom bounds the scaled inverse moment. -/
theorem normalized_high_inverse_raw {n : ℕ} (u : Fin (n+1)→ℝ)
    {a ρ e β : ℝ} (ha : 0<a) (hρ : 0≤ρ) (hu : ∀ i,0<u i) :
    a^(-e)/interpolationNormalizer u a ρ e ≤
      ∑ i, |normalizedInterpolation u a ρ e i| *(a/interpolationNodes u a i)^β := by
  have hP := interpolationNormalizer_pos u (e:=e) ha hρ
  have hnodes (i : Option (Fin (n+1))) : 0 < interpolationNodes u a i := by
    cases i with | none => exact ha | some i => exact hu i
  have hh := Finset.single_le_sum
    (s := (Finset.univ : Finset (Option (Fin (n+1)))))
    (f := fun i => |normalizedInterpolation u a ρ e i| *(a/interpolationNodes u a i)^β)
    (fun i _ => mul_nonneg (abs_nonneg _) (Real.rpow_nonneg (div_nonneg ha.le (hnodes i).le) _))
    (Finset.mem_univ none)
  change |((1+ρ)*a^(-e))/interpolationNormalizer u a ρ e| *(a/a)^β≤_ at hh
  rw [div_self ha.ne',Real.one_rpow,mul_one,abs_of_nonneg (by positivity)] at hh
  apply le_trans _ hh
  apply div_le_div_of_nonneg_right _ hP.le
  nlinarith [mul_nonneg hρ (Real.rpow_nonneg ha.le (-e))]

/-- A low endpoint and high principal atom jointly bound the exact tensor
normalizer. Both raw normalizers are retained for cancellation with D. -/
theorem tensor_normalizer_endpoint_raw {n m : ℕ}
    (u : Fin (n+1)→ℝ) (w : Fin (m+1)→ℝ)
    {a b ρl ρh el eh α : ℝ} (ha : 0<a) (hb : 0<b)
    (hρl : 0≤ρl) (hρh : 0≤ρh) (hu : ∀ i,0<u i) (hw : ∀ j,0<w j)
    (j : Fin (n+1)) (hj : u j=1)
    (hcancel : ∑ i,normalizedInterpolation u a ρl el i*interpolationNodes u a i^(α-1)=0) :
    |lagrangeWeight u a j| *b^(-eh)/
        (2*interpolationNormalizer u a ρl el*interpolationNormalizer w b ρh eh) ≤
      tensorNormalizer (normalizedInterpolation u a ρl el) (normalizedInterpolation w b ρh eh)
        (interpolationNodes u a) (interpolationNodes w b) a α/((a*b)⁻¹)^(α-1) := by
  have hU (i : Option (Fin (n+1))) : 0 < interpolationNodes u a i := by
    cases i with | none => exact ha | some i => exact hu i
  have hW (i : Option (Fin (m+1))) : 0 < interpolationNodes w b i := by
    cases i with | none => exact hb | some i => exact hw i
  rw [tensorNormalizer_scaled_jordan _ _ _ _ ha hb hU hW hcancel]
  have hl := normalized_jordan_endpoint_raw u ha hρl hu j hj hcancel
  have hh := normalized_high_inverse_raw w (β:=α-1) (e:=eh) hb hρh hw
  have hP := interpolationNormalizer_pos u (e:=el) ha hρl
  have hQ := interpolationNormalizer_pos w (e:=eh) hb hρh
  have hmul := mul_le_mul hl hh (by positivity)
    (Finset.sum_nonneg (fun i _ => mul_nonneg (le_max_right _ _) (Real.rpow_pos_of_pos (hU i) _).le))
  convert hmul using 1
  ring

/-- Cancel the raw normalizers against their endpoint lower bound. -/
theorem defect_scale_of_normalizer_lower {B Z P Q W F b α r eh : ℝ}
    (hB : 0<B) (hZ : 0<Z) (hP : 0<P) (hQ : 0<Q) (hW : 0<W)
    (hF : 0≤F) (hb : 0<b)
    (hbound : W*b^(-eh)/(2*P*Q)≤Z/B^(α-1)) :
    B^(r-1)/Z*(F/(P*Q))≤2*B^(r-α)*F*b^eh/W := by
  have hbp : 0<B^(α-1) := Real.rpow_pos_of_pos hB _
  have hbneg : 0<b^(-eh) := Real.rpow_pos_of_pos hb _
  have hden : 0<P*Q*(Z/B^(α-1)) := by positivity
  have hdenlo : W*b^(-eh)/2≤P*Q*(Z/B^(α-1)) := by
    have hh := (div_le_iff₀ (show 0<2*P*Q by positivity)).mp hbound
    nlinarith only [hh]
  have hcomp := div_le_div_of_nonneg_left
    (show 0≤B^(r-α)*F by positivity) (show 0<W*b^(-eh)/2 by positivity) hdenlo
  have hpow : B^(r-1)=B^(r-α)*B^(α-1) := by
    rw [←Real.rpow_add hB]
    congr 1
    ring
  have hcancel : b^(-eh)*b^eh=1 := by rw [←Real.rpow_add hb]; simp
  calc
    _=(B^(r-α)*F)/(P*Q*(Z/B^(α-1))) := by rw [hpow]; field_simp
    _≤(B^(r-α)*F)/(W*b^(-eh)/2) := hcomp
    _=_ := by
      apply (div_eq_iff (show W*b^(-eh)/2≠0 by positivity)).mpr
      field_simp
      calc
        F=F*1 := by ring
        _=F*b^eh*b^(-eh) := by rw [←hcancel]; ring

/-- In the positive sign the principal powers cancel completely, leaving
only the reciprocal endpoint interpolation coefficient. -/
theorem positive_defect_scale_endpoint {a b Z P Q W s r : ℝ}
    (ha : 0<a) (hb : 0<b) (hZ : 0<Z) (hP : 0<P) (hQ : 0<Q) (hW : 0<W)
    (hbound : W*b^(-(1-s))/(2*P*Q)≤Z/((a*b)⁻¹)^(r+s-1)) :
    ((a*b)⁻¹)^(r-1)/Z*(a^(-s)*b⁻¹/(P*Q))≤2/W := by
  have hh := defect_scale_of_normalizer_lower (α:=r+s) (r:=r) (eh:=1-s) (F:=a^(-s)*b⁻¹)
    (inv_pos.mpr (mul_pos ha hb)) hZ hP hQ hW (by positivity) hb hbound
  apply hh.trans_eq
  have he : ((a*b)⁻¹)^(r-(r+s))*a^(-s)*b⁻¹*b^(1-s)=1 := by
    rw [show r-(r+s)= -s by ring,Real.inv_rpow (mul_pos ha hb).le,
      Real.rpow_neg (mul_pos ha hb).le,inv_inv,Real.mul_rpow ha.le hb.le,
      Real.rpow_neg ha.le,show 1-s=1+(-s) by ring,Real.rpow_add hb,
      Real.rpow_one,Real.rpow_neg hb.le]
    field_simp

  calc
    _=2*(((a*b)⁻¹)^(r-(r+s))*a^(-s)*b⁻¹*b^(1-s))/W := by ring
    _=2/W := by rw [he,mul_one]

/-- For the negative sign the only remaining principal factor is the
reciprocal complementary principal point. -/
theorem negative_defect_scale_endpoint {a b Z P Q W s r : ℝ}
    (ha : 0<a) (hb : 0<b) (hZ : 0<Z) (hP : 0<P) (hQ : 0<Q) (hW : 0<W)
    (hbound : W*b^(-s)/(2*P*Q)≤Z/((a*b)⁻¹)^(r-s-1)) :
    ((a*b)⁻¹)^(r-1)/Z*(a^(s-1)/(P*Q))≤2/(a*W) := by
  have hh := defect_scale_of_normalizer_lower (α:=r-s) (r:=r) (eh:=s) (F:=a^(s-1))
    (inv_pos.mpr (mul_pos ha hb)) hZ hP hQ hW (by positivity) hb hbound
  apply hh.trans_eq
  have he : ((a*b)⁻¹)^(r-(r-s))*a^(s-1)*b^s=a⁻¹ := by
    rw [show r-(r-s)=s by ring,Real.inv_rpow (mul_pos ha hb).le,
      Real.mul_rpow ha.le hb.le,show s-1=s+(-1:ℝ) by ring,
      Real.rpow_add ha,Real.rpow_neg_one]
    field_simp
  calc
    _=2*(((a*b)⁻¹)^(r-(r-s))*a^(s-1)*b^s)/W := by ring
    _=2/(a*W) := by rw [he]; ring

/-- The complementary endpoint estimate is uniformly exponential in the
selected degree, including arbitrarily small nearest-integer distance. -/
theorem complementary_defect_exponential {c s ζ E w d r : ℝ}
    (hc : 0<c) (hs : 0<s) (hs1 : s≤1/2) (hζ : c*s/2≤ζ)
    (hd : 0<d) (hdr : d≤r) (hr : 2≤r) (hE : E≤r) (hw : w≤1/2) :
    let ξ := 1-s
    let bc := ξ/d^2
    let κ := Real.exp (-E-4*w)
    4*Real.exp 5/bc^2*(ζ*κ)^(-1/ξ)≤Real.exp ((20+2/c)*r)/ζ := by
  let ξ := 1-s
  let bc := ξ/d^2
  let κ := Real.exp (-E-4*w)
  let D := 4*Real.exp 5/bc^2*(ζ*κ)^(-1/ξ)
  have hξ : 1/2≤ξ := by dsimp [ξ]; linarith
  have hξ0 : 0<ξ := by linarith
  have hζ0 : 0<ζ := lt_of_lt_of_le (by positivity) hζ
  have hbc : 0<bc := by dsimp [bc]; positivity
  have hκ : 0<κ := Real.exp_pos _
  have hD : 0<D := by dsimp [D]; positivity
  have hlogd : Real.log d≤r := (Real.log_le_sub_one_of_pos hd).trans (by linarith)
  have hlogξ : -1≤Real.log ξ := by
    have hh := Real.one_sub_inv_le_log_of_pos hξ0
    have hi : ξ⁻¹≤2 := by rw [←one_div]; exact (div_le_iff₀ hξ0).mpr (by linarith)
    linarith
  have hsdiv : s/ζ≤2/c := by
    apply (div_le_div_iff₀ hζ0 hc).mpr
    nlinarith only [hζ]
  have hlogζ : -s*Real.log ζ≤2/c := by
    have hh := mul_le_mul_of_nonneg_left (Real.one_sub_inv_le_log_of_pos hζ0) hs.le
    have he : s*(1-ζ⁻¹)=s-s/ζ := by ring
    rw [he] at hh
    linarith
  have hζterm : -(s/ξ)*Real.log ζ≤4/c := by
    have hmul : 2/c≤(4/c)*ξ := by
      have hh := mul_le_mul_of_nonneg_left hξ (show 0≤4/c by positivity)
      convert hh using 1
      ring
    have hh := (div_le_iff₀ hξ0).mpr (hlogζ.trans hmul)
    convert hh using 1
    ring
  have hEterm : (E+4*w)/ξ≤2*r+4 := by
    apply (div_le_iff₀ hξ0).mpr
    have hh := mul_le_mul_of_nonneg_left hξ (show 0≤2*r+4 by linarith)
    nlinarith only [hh,hE,hw]
  have hlog4 : Real.log (4:ℝ)≤3 := by
    have hh := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<4)
    norm_num at hh
    exact hh
  have hid : Real.log (D*ζ)=Real.log 4+5-2*Real.log ξ+4*Real.log d-
      (s/ξ)*Real.log ζ+(E+4*w)/ξ := by
    dsimp [D]
    rw [Real.log_mul hD.ne' hζ0.ne',
      Real.log_mul (div_pos (mul_pos (by norm_num) (Real.exp_pos 5)) (sq_pos_of_pos hbc)).ne'
        (Real.rpow_pos_of_pos (mul_pos hζ0 hκ) _).ne',
      Real.log_div (mul_pos (by norm_num) (Real.exp_pos 5)).ne' (sq_pos_of_pos hbc).ne',
      Real.log_mul (by norm_num : (4:ℝ)≠0) (Real.exp_pos 5).ne',Real.log_exp,
      Real.log_pow,Real.log_rpow (mul_pos hζ0 hκ),Real.log_mul hζ0.ne' hκ.ne']
    dsimp [bc,κ]
    rw [Real.log_div hξ0.ne' (sq_pos_of_pos hd).ne',Real.log_pow,Real.log_exp]
    field_simp [hξ0.ne']
    dsimp [ξ]
    ring
  change D≤Real.exp ((20+2/c)*r)/ζ
  apply (le_div_iff₀ hζ0).mpr
  apply (Real.log_le_iff_le_exp (mul_pos hD hζ0)).mp
  rw [hid]
  have hcr := mul_le_mul_of_nonneg_left hr (show 0≤2/c by positivity)
  rw [show 4/c=2*(2/c) by ring] at hζterm
  nlinarith only [hlog4,hlogξ,hlogd,hζterm,hEterm,hr,hcr]

/-- The actual short active Chebyshev endpoint gives the polynomial defect
scale used before exponential absorption. -/
theorem active_chebyshev_defect_bound {n m : ℕ} (w : Fin (m+1)→ℝ)
    {a b ρ s ζ r : ℝ} (hn : 0<n) (ha : 0<a) (hb : 0<b) (hρ : 0≤ρ)
    (hζ : 0<ζ) (hζ1 : ζ≤1/8)
    (haB : a≤((ζ/8)/((n:ℝ)+1)^2)/2) (hw : ∀ i,0<w i)
    (hcancel :
      let bs := (ζ/8)/((n:ℝ)+1)^2
      let u := chebyshevNode n bs
      ∑ i,normalizedInterpolation u a ρ s i*interpolationNodes u a i^(r+s-1)=0)
    (hZ :
      let bs := (ζ/8)/((n:ℝ)+1)^2
      let u := chebyshevNode n bs
      0 < tensorNormalizer (normalizedInterpolation u a ρ s) (normalizedInterpolation w b 0 (1-s))
        (interpolationNodes u a) (interpolationNodes w b) a (r+s)) :
    let bs := (ζ/8)/((n:ℝ)+1)^2
    let u := chebyshevNode n bs
    let Z := tensorNormalizer (normalizedInterpolation u a ρ s) (normalizedInterpolation w b 0 (1-s))
      (interpolationNodes u a) (interpolationNodes w b) a (r+s)
    ((a*b)⁻¹)^(r-1)/Z*(a^(-s)*b⁻¹/
      (interpolationNormalizer u a ρ s*interpolationNormalizer w b 0 (1-s)))≤32*((n:ℝ)+1)^2/ζ := by
  let bs := (ζ/8)/((n:ℝ)+1)^2
  let u := chebyshevNode n bs
  have hbs : 0<bs := by dsimp [bs]; positivity
  have hbs1 : bs<1 := by
    apply (div_lt_one (by positivity : (0:ℝ)<((n:ℝ)+1)^2)).mpr
    have hn0 : (0:ℝ)≤n := Nat.cast_nonneg _
    nlinarith
  have hu (i) : 0<u i := hbs.trans_le (chebyshevNode_bounds n bs hbs1.le i).1
  have hweight : bs/2≤|lagrangeWeight u a (Fin.last n)| :=
    chebyshev_last_weight_lower n bs a hn hbs.le hbs1 haB
  have hwp : 0 < |lagrangeWeight u a (Fin.last n)| := lt_of_lt_of_le (by positivity) hweight
  have hnorm := tensor_normalizer_endpoint_raw u w (eh:=1-s) ha hb hρ (by norm_num : (0:ℝ)≤0)
    hu hw (Fin.last n) (chebyshevNode_last n bs) hcancel
  have hPs := interpolationNormalizer_pos u (e:=s) ha hρ
  have hPc := interpolationNormalizer_pos w (e:=1-s) hb (by norm_num : (0:ℝ)≤0)
  have hh := positive_defect_scale_endpoint ha hb hZ hPs hPc hwp hnorm
  apply hh.trans
  have hwrecip := div_le_div_of_nonneg_left (by norm_num : (0:ℝ)≤2)
    (show 0<bs/2 by positivity) hweight
  calc
    _≤2/(bs/2) := hwrecip
    _=32*((n:ℝ)+1)^2/ζ := by dsimp [bs]; field_simp; norm_num

/-- The short complementary factor has the uniform defect envelope in the
negative orientation, including its degree-zero endpoint. -/
theorem complementary_chebyshev_defect_bound {n m : ℕ} (uHigh : Fin (m+1)→ℝ)
    {b ρ s ζ c E w r : ℝ}
    (hb : 0<b) (hρ : 0≤ρ) (hwHigh : ∀ i,0<uHigh i)
    (hc : 0<c) (hs : 0<s) (hs1 : s≤1/2) (hζlo : c*s/2≤ζ) (hζ1 : ζ≤1)
    (hE0 : 0≤E) (hE : E≤r) (hw0 : 0≤w) (hw : w≤1/2)
    (hr : 2≤r) (hd : (n:ℝ)+1≤r)
    (hcancel :
      let ξ := 1-s
      let bc := ξ/((n:ℝ)+1)^2
      let ac := Real.exp (-5)*bc*(ζ*Real.exp (-E-4*w))^(1/ξ)
      let u := chebyshevNode n bc
      ∑ i,normalizedInterpolation u ac 0 ξ i*interpolationNodes u ac i^(r-s-1)=0)
    (hZ :
      let ξ := 1-s
      let bc := ξ/((n:ℝ)+1)^2
      let ac := Real.exp (-5)*bc*(ζ*Real.exp (-E-4*w))^(1/ξ)
      let u := chebyshevNode n bc
      0 < tensorNormalizer (normalizedInterpolation u ac 0 ξ) (normalizedInterpolation uHigh b ρ s)
        (interpolationNodes u ac) (interpolationNodes uHigh b) ac (r-s)) :
    let ξ := 1-s
    let bc := ξ/((n:ℝ)+1)^2
    let ac := Real.exp (-5)*bc*(ζ*Real.exp (-E-4*w))^(1/ξ)
    let u := chebyshevNode n bc
    let Z := tensorNormalizer (normalizedInterpolation u ac 0 ξ) (normalizedInterpolation uHigh b ρ s)
      (interpolationNodes u ac) (interpolationNodes uHigh b) ac (r-s)
    ((ac*b)⁻¹)^(r-1)/Z*(ac^(s-1)/
      (interpolationNormalizer u ac 0 ξ*interpolationNormalizer uHigh b ρ s))≤Real.exp ((20+2/c)*r)/ζ := by
  let ξ := 1-s
  let bc := ξ/((n:ℝ)+1)^2
  let κ := Real.exp (-E-4*w)
  let ac := Real.exp (-5)*bc*(ζ*κ)^(1/ξ)
  let u := chebyshevNode n bc
  have hξ : 0<ξ := by dsimp [ξ]; linarith
  have hξ1 : ξ<1 := by dsimp [ξ]; linarith
  have hζ : 0<ζ := lt_of_lt_of_le (by positivity) hζlo
  have hbc : 0<bc := by dsimp [bc]; positivity
  have hbc1 : bc<1 := by
    apply (div_lt_one (by positivity : (0:ℝ)<((n:ℝ)+1)^2)).mpr
    have hn0 : (0:ℝ)≤n := Nat.cast_nonneg _
    nlinarith
  have hκ : 0<κ := Real.exp_pos _
  have hκ1 : κ≤1 := Real.exp_le_one_iff.mpr (by linarith)
  have hac : 0<ac := by dsimp [ac]; positivity
  have hacB : ac≤bc/2 := by
    have hz : ζ*κ≤1 := mul_le_one₀ hζ1 hκ.le hκ1
    have hp : (ζ*κ)^(1/ξ)≤1 := Real.rpow_le_one (by positivity) hz (by positivity)
    have he : Real.exp (-5)≤1/2 := by
      rw [Real.exp_neg]
      apply (inv_le_iff_one_le_mul₀ (Real.exp_pos 5)).mpr
      have hh := Real.add_one_le_exp (5:ℝ)
      nlinarith
    have hh := mul_le_mul_of_nonneg_left hp (show 0≤Real.exp (-5)*bc by positivity)
    change Real.exp (-5)*bc*(ζ*κ)^(1/ξ)≤bc/2
    nlinarith [mul_le_mul_of_nonneg_right he hbc.le]
  have hu (i) : 0<u i := hbc.trans_le (chebyshevNode_bounds n bc hbc1.le i).1
  have hweight : bc/2≤|lagrangeWeight u ac (Fin.last n)| := by
    by_cases hn : n=0
    · subst n
      have huniv : (Finset.univ : Finset (Fin (0+1)))={Fin.last 0} := by decide
      simp only [lagrangeWeight,Lagrange.basis,huniv,Finset.erase_singleton,
        Finset.prod_empty,Polynomial.eval_one,abs_one]
      linarith
    · exact chebyshev_last_weight_lower n bc ac (Nat.pos_of_ne_zero hn) hbc.le hbc1 hacB
  have hwp : 0 < |lagrangeWeight u ac (Fin.last n)| := lt_of_lt_of_le (by positivity) hweight
  have hnorm := tensor_normalizer_endpoint_raw u uHigh (eh:=s) hac hb (by norm_num : (0:ℝ)≤0)
    hρ hu hwHigh (Fin.last n) (chebyshevNode_last n bc) hcancel
  have hPs := interpolationNormalizer_pos u (e:=ξ) hac (by norm_num : (0:ℝ)≤0)
  have hPc := interpolationNormalizer_pos uHigh (e:=s) hb hρ
  have hh := negative_defect_scale_endpoint hac hb hZ hPs hPc hwp hnorm
  apply hh.trans
  have hden : ac*(bc/2)≤ac*|lagrangeWeight u ac (Fin.last n)| :=
    mul_le_mul_of_nonneg_left hweight hac.le
  have hrecip := div_le_div_of_nonneg_left (by norm_num : (0:ℝ)≤2) (by positivity) hden
  have hexp := complementary_defect_exponential hc hs hs1 hζlo
    (show 0<(n:ℝ)+1 by positivity) hd hr hE hw
  calc
    _≤2/(ac*(bc/2)) := hrecip
    _=4*Real.exp 5/bc^2*(ζ*κ)^(-1/ξ) := by
      dsimp [ac]
      rw [Real.exp_neg,show -1/ξ= -(1/ξ) by ring,Real.rpow_neg (by positivity : 0≤ζ*κ)]
      field_simp
      norm_num
    _≤Real.exp ((20+2/c)*r)/ζ := hexp

end Renyi
