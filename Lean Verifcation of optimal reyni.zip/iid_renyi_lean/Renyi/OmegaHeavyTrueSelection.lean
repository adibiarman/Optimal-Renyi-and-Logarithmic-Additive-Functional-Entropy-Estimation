import Renyi.OmegaHeavyNormalized
import Renyi.CompletedPilotComparison

/-! The random selected true-heavy bins appearing in the actual hybrid estimator. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

 def trueHeavyPilotSubset {k : ℕ} (p : Simplex k) (n alpha cp B : ℝ)
    (y : Fin k→ℕ) : Finset (Fin k) :=
  Finset.univ.filter (fun i => B*alpha/2≤n*p.mass i ∧ cp*B*alpha<(y i:ℝ))

theorem pilotTrueHeavyPower_subset_sum {k : ℕ} (p : Simplex k)
    (n alpha cp B omega : ℝ) (h : PilotHistogram k) :
    pilotTrueHeavyPower p.mass (fun i => pilotSelectionCount i)
      (fun i => pilotMainCount i) n alpha cp B omega h=
    ∑i∈trueHeavyPilotSubset p n alpha cp B (fun i => pilotSelectionCount i h),
      omega*analyticCount alpha (pilotMainCount i h)/n^alpha := by
  simp only [pilotTrueHeavyPower,trueHeavyPilotSubset,Finset.sum_filter]

/-- Unconditional heavy concentration for the exact selected-heavy term of the hybrid. -/
theorem omega_heavy_true_selection_concentration {eps c0 rho : ℝ}
    (heps : 0<eps) (hc0 : 0<c0) (hc01 : c0<1) (hrho : 0<rho) (hrho1 : rho<1)
    {k : ℕ} (n cp : ℝ≥0) (hn : 0<(n:ℝ)) (p : Simplex k) {a E0 sigma B : ℝ}
    (ha : 3/2≤a) (hElow : eps*(a-1)≤E0) (hEhigh : E0≤2*eps*(a-1))
    (hsigma : 0≤sigma) (hsigma1 : sigma≤1)
    (hheadroom : 1+omegaHeavyMargin eps c0/2≤sigma*(1+omegaHeavyMargin eps c0))
    (hB : 2*omegaHeavyScale eps c0 rho≤B) :
    1-rho≤(pilotHistogramPMF n cp p).toMeasure.real {h |
      (Real.exp (-(2*eps*(a-1)))+(omegaHeavyMargin eps c0/2)*Real.exp (-(2*eps*(a-1))))*
        (∑i∈trueHeavyPilotSubset p n a cp B (fun i => pilotSelectionCount i h),(p.mass i)^a)≤
          pilotTrueHeavyPower p.mass (fun i => pilotSelectionCount i) (fun i => pilotMainCount i)
            n a cp B (sigma*Real.exp (-c0*E0)) h ∧
      pilotTrueHeavyPower p.mass (fun i => pilotSelectionCount i) (fun i => pilotMainCount i)
        n a cp B (sigma*Real.exp (-c0*E0)) h≤
          (1-(omegaHeavyMargin eps c0/2)*Real.exp (-(2*eps*(a-1))))*
            (∑i∈trueHeavyPilotSubset p n a cp B (fun i => pilotSelectionCount i h),(p.mass i)^a)} := by
  have hmean : ∀y∈(Set.univ : Set (Fin k→ℕ)),∀i∈trueHeavyPilotSubset p n a cp B y,
      omegaHeavyScale eps c0 rho*a≤(n:ℝ)*p.mass i := by
    intro y _ i hi
    have hh := (Finset.mem_filter.mp hi).2.1
    have hmul := mul_le_mul_of_nonneg_right hB (show 0≤a by linarith only [ha])
    linarith only [hh,hmul]
  have hh := omega_heavy_pilot_normalized_concentration heps hc0 hc01 hrho hrho1
    n cp hn p ha hElow hEhigh hsigma hsigma1 hheadroom
    (trueHeavyPilotSubset p n a cp B) Set.univ hmean
  simpa only [measureReal_univ_eq_one,Set.mem_univ,true_and,
    omegaHeavyNormalizedSubsetEvent,Set.mem_setOf_eq,pilotTrueHeavyPower_subset_sum] using hh

end Renyi
