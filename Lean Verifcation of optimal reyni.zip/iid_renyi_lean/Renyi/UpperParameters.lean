import Renyi.RootCharacterization
import Renyi.OverlapCapacity
import Renyi.UpperDegree

/-! Actual regularized-root parameters and their uniform calibration. -/
noncomputable section
open Set
namespace Renyi

/-- The unique positive logarithmic coordinate of the prescribed overlap. -/
def upperOverlapTime (γ E : ℝ) : ℝ :=
  if h : 0 < γ ∧ γ < 1 ∧ 0 < E then
    Classical.choose (overlapF_existsUnique h.1 h.2.1 h.2.2) else 0

def upperOverlapZ (γ E : ℝ) : ℝ := Real.exp (-γ*(1-γ)*upperOverlapTime γ E)

theorem upperOverlapTime_spec {γ E : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) (hE : 0 < E) :
    0 < upperOverlapTime γ E ∧ overlapF γ (upperOverlapTime γ E) = E := by
  unfold upperOverlapTime
  rw [dif_pos ⟨hγ,hγ1,hE⟩]
  exact (Classical.choose_spec (overlapF_existsUnique hγ hγ1 hE)).1

theorem upperOverlapZ_spec {γ E : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) (hE : 0 < E) :
    upperOverlapZ γ E ∈ Ioo (0 : ℝ) 1 ∧ overlapG γ (upperOverlapZ γ E) = Real.exp (-E) := by
  have ht := upperOverlapTime_spec hγ hγ1 hE
  have hh : 0 < γ*(1-γ) := mul_pos hγ (sub_pos.mpr hγ1)
  have hz : upperOverlapZ γ E ∈ Ioo (0 : ℝ) 1 := by
    constructor
    · exact Real.exp_pos _
    · apply Real.exp_lt_one_iff.mpr
      nlinarith [mul_pos hh ht.1]
  refine ⟨hz, ?_⟩
  have hf := overlapF_eq_log hγ hγ1 ht.1
  change overlapF γ (upperOverlapTime γ E) = -Real.log (overlapG γ (upperOverlapZ γ E)) at hf
  rw [ht.2] at hf
  have hlog : Real.log (overlapG γ (upperOverlapZ γ E)) = -E := by linarith
  rw [← hlog, Real.exp_log (overlapG_mem_Ioo hγ hγ1 hz.1 hz.2).1]

theorem upperOverlapZ_unique {γ E z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) (hE : 0 < E)
    (hz : z ∈ Ioo (0 : ℝ) 1) (hG : overlapG γ z = Real.exp (-E)) : z = upperOverlapZ γ E :=
  (overlapG_strictMonoOn hγ hγ1).injOn hz (upperOverlapZ_spec hγ hγ1 hE).1
    (hG.trans (upperOverlapZ_spec hγ hγ1 hE).2.symm)

theorem upperOverlapZ_power {γ E : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    upperOverlapZ γ E ^ (1/(γ*(1-γ))) = Real.exp (-upperOverlapTime γ E) := by
  unfold upperOverlapZ
  rw [← Real.exp_mul]
  congr 1
  have hd : 1-γ ≠ 0 := (sub_pos.mpr hγ1).ne'
  field_simp

private theorem interval_accuracy_prefactor {ε β E : ℝ} (hε : 0 < ε) (hβ : 0 < β)
    (hlo : ε*β ≤ E) (hhi : E ≤ 2*ε*β) :
    (ε/(1+ε))*(β/(1+β)) ≤ E/(1+E) ∧
    E/(1+E) ≤ (1+2*ε)*(β/(1+β)) := by
  have hE : 0 < E := (mul_pos hε hβ).trans_le hlo
  have hp1 : (ε/(1+ε))*(β/(1+β)) ≤ ε*β/(1+ε*β) := by
    rw [div_mul_div_comm]
    exact div_le_div_of_nonneg_left (mul_pos hε hβ).le (by positivity) (by nlinarith)
  have hp2 : (2*ε*β)/(1+2*ε*β) ≤ (1+2*ε)*(β/(1+β)) := by
    rw [← mul_div_assoc]
    apply (div_le_div_iff₀ (by positivity : 0 < 1+2*ε*β) (by positivity : 0 < 1+β)).2
    nlinarith [sq_nonneg (2*ε*β)]
  constructor
  · apply hp1.trans
    apply (div_le_div_iff₀ (by positivity : 0 < 1+ε*β) (by positivity : 0 < 1+E)).2
    nlinarith
  · apply le_trans _ hp2
    apply (div_le_div_iff₀ (by positivity : 0 < 1+E) (by positivity : 0 < 1+2*ε*β)).2
    nlinarith

/-- Capacity is uniform over the entire reserved-accuracy interval. -/
theorem upper_overlap_capacity_interval {ε : ℝ} (hε : 0 < ε) :
    ∃ c₁ c₂ : ℝ, 0 < c₁ ∧ 0 < c₂ ∧ ∀ α γ E : ℝ,
      1 < α → 0 < γ → γ < 1 → γ ≤ α-1 → ε*(α-1) ≤ E → E ≤ 2*ε*(α-1) →
      c₁ * (α*overlapPsi γ/((α-1)*(γ*(1-γ))) * Real.exp (-E/(γ*(1-γ)))) ≤
        upperOverlapZ γ E ^ (1/(γ*(1-γ))) ∧
      upperOverlapZ γ E ^ (1/(γ*(1-γ))) ≤
        c₂ * (α*overlapPsi γ/((α-1)*(γ*(1-γ))) * Real.exp (-E/(γ*(1-γ)))) := by
  obtain ⟨C₁,C₂,hC₁,hC₂,hcap⟩ := overlap_capacity_uniform hε
  let A := C₁*(ε/(1+ε))
  let B := C₂*(1+2*ε)
  have hA : 0 < A := mul_pos hC₁ (div_pos hε (by positivity))
  have hB : 0 < B := mul_pos hC₂ (by positivity)
  refine ⟨1/B,1/A,one_div_pos.mpr hB,one_div_pos.mpr hA,?_⟩
  intro α γ E hα hγ hγ1 hγα hlo hhi
  have hα0 : 0 < α := by linarith
  have hβ : 0 < α-1 := sub_pos.mpr hα
  have hh : 0 < γ*(1-γ) := mul_pos hγ (sub_pos.mpr hγ1)
  have hE : 0 < E := (mul_pos hε hβ).trans_le hlo
  have ht := upperOverlapTime_spec hγ hγ1 hE
  have hratio : ε ≤ E/(γ*(1-γ)) := by
    apply (le_div_iff₀ hh).2
    have hhβ : γ*(1-γ) ≤ α-1 := by nlinarith [sq_nonneg γ]
    exact (mul_le_mul_of_nonneg_left hhβ hε.le).trans hlo
  have hc := hcap γ E (upperOverlapTime γ E) hγ hγ1 ht.1 ht.2 hratio
  rw [overlapCapacityScale_eq hγ hγ1] at hc
  have hp := interval_accuracy_prefactor hε hβ hlo hhi
  rw [show 1+(α-1)=α by ring] at hp
  let K := ((α-1)/α)*(γ*(1-γ)/overlapPsi γ)*Real.exp (E/(γ*(1-γ)))
  have hK : 0 < K := mul_pos (mul_pos (div_pos hβ hα0)
    (div_pos hh (overlapPsi_pos hγ hγ1))) (Real.exp_pos _)
  have hbounds : A*K ≤ Real.exp (upperOverlapTime γ E) ∧ Real.exp (upperOverlapTime γ E) ≤ B*K := by
    have hfac : 0 ≤ (γ*(1-γ)/overlapPsi γ)*Real.exp (E/(γ*(1-γ))) :=
      mul_nonneg (div_nonneg hh.le (overlapPsi_pos hγ hγ1).le) (Real.exp_pos _).le
    constructor
    · have h := (mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hp.1 hfac) hC₁.le)
      apply le_trans _ hc.1
      convert h using 1 <;> dsimp [A,K] <;> ring
    · have h := mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hp.2 hfac) hC₂.le
      apply hc.2.trans
      convert h using 1 <;> dsimp [B,K] <;> ring
  have hlow := one_div_le_one_div_of_le (Real.exp_pos (upperOverlapTime γ E)) hbounds.2
  have hupp := one_div_le_one_div_of_le (mul_pos hA hK) hbounds.1
  have hKinv : 1/K = α*overlapPsi γ/((α-1)*(γ*(1-γ))) * Real.exp (-E/(γ*(1-γ))) := by
    rw [neg_div, Real.exp_neg]
    dsimp [K]
    field_simp
  rw [upperOverlapZ_power hγ hγ1, Real.exp_neg]
  constructor
  · rw [show 1/(B*K) = (1/B)*(1/K) by ring, hKinv] at hlow
    simpa only [one_div] using hlow
  · rw [show 1/(A*K) = (1/A)*(1/K) by ring, hKinv] at hupp
    simpa only [one_div] using hupp

/-- The root's local width and reserved overlap exponent. -/
def upperV (k : ℕ) (α ε : ℝ) : ℝ := (α-1)/α * rootMultiplier k α ε ^ (-α)
def upperDelta (k : ℕ) (α ε Ch : ℝ) : ℝ :=
  min (upperV k α ε + Ch*(fractionalPart α*(1-fractionalPart α))) (ε*(α-1))
def upperE0 (k : ℕ) (α ε Ch : ℝ) : ℝ := 2*ε*(α-1)-upperDelta k α ε Ch

def upperSigma (k : ℕ) (α ε : ℝ) : ℝ :=
  1+Real.log (rootMultiplier k α ε*(1+Real.log (rootMultiplier k α ε))/rootQSquared k α ε) -
    upperV k α ε/(fractionalPart α*(1-fractionalPart α))
def upperW (k : ℕ) (α ε : ℝ) : ℝ := upperSigma k α ε +
  max (upperV k α ε-ε*(α-1)) 0/(fractionalPart α*(1-fractionalPart α))

theorem upper_root_slack {k : ℕ} {α ε : ℝ} (hα : 1 < α)
    (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1) :
    0 ≤ upperSigma k α ε ∧ (1 < rootMultiplier k α ε → upperSigma k α ε = 0) ∧
    rootQSquared k α ε/rootMultiplier k α ε = (1+Real.log (rootMultiplier k α ε))*
      Real.exp (1-upperV k α ε/(fractionalPart α*(1-fractionalPart α))-upperSigma k α ε) :=
  regularized_root_slack hα hγ hγ1

theorem upper_reserved_interval {k : ℕ} {α ε Ch : ℝ} (hα : 1 < α)
    (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1) (hε : 0 < ε) (hCh : 0 ≤ Ch) :
    ε*(α-1) ≤ upperE0 k α ε Ch ∧ upperE0 k α ε Ch ≤ 2*ε*(α-1) := by
  have hx : 0 < rootMultiplier k α ε := zero_lt_one.trans_le (one_le_rootMultiplier hα hγ hγ1)
  have hv : 0 < upperV k α ε := by
    unfold upperV
    exact mul_pos (div_pos (sub_pos.mpr hα) (by linarith)) (Real.rpow_pos_of_pos hx _)
  have hh : 0 < fractionalPart α*(1-fractionalPart α) := mul_pos hγ (sub_pos.mpr hγ1)
  have hDelta0 : 0 ≤ upperDelta k α ε Ch :=
    le_min (add_nonneg hv.le (mul_nonneg hCh hh.le)) (mul_nonneg hε.le (sub_pos.mpr hα).le)
  have hDeltaE : upperDelta k α ε Ch ≤ ε*(α-1) := min_le_right _ _
  unfold upperE0
  constructor <;> linarith

def upperU (k : ℕ) (α ε u0 : ℝ) : ℝ :=
  min (upperV k α ε + fractionalPart α*(1-fractionalPart α)) u0

def upperSample (k : ℕ) (α ε D : ℝ) : ℝ :=
  D*α*(k : ℝ)^(1-1/α)*rootMultiplier k α ε

def upperB (k : ℕ) (α ε D cb CL cL : ℝ) : ℝ :=
  cb*(upperDegree α CL cL (rootMultiplier k α ε) : ℝ)/upperSample k α ε D

def upperA (k : ℕ) (α ε Ch D cb lambda CL cL : ℝ) : ℝ :=
  lambda*upperB k α ε D cb CL cL*(fractionalPart α*(1-fractionalPart α))*
    upperOverlapZ (fractionalPart α) (upperE0 k α ε Ch) ^
      (1/(fractionalPart α*(1-fractionalPart α))) /
    ((upperOrderFloor α : ℝ)^2*(upperDegree α CL cL (rootMultiplier k α ε) : ℝ)^2)

/-- The reserved width differs from its positive-part slack by at most `Ch`. -/
theorem upper_width_bounds {k : ℕ} {α ε Ch : ℝ}
    (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1) (hCh : 0 ≤ Ch) :
    -upperW k α ε ≤ -upperSigma k α ε -
      (upperV k α ε-upperDelta k α ε Ch)/(fractionalPart α*(1-fractionalPart α)) ∧
    -upperSigma k α ε -
      (upperV k α ε-upperDelta k α ε Ch)/(fractionalPart α*(1-fractionalPart α)) ≤ Ch-upperW k α ε := by
  let h := fractionalPart α*(1-fractionalPart α)
  let x := upperV k α ε-ε*(α-1)
  have hh : 0 < h := mul_pos hγ (sub_pos.mpr hγ1)
  have hChh : 0 ≤ Ch*h := mul_nonneg hCh hh.le
  have hid : upperV k α ε-upperDelta k α ε Ch = max (-Ch*h) x := by
    unfold upperDelta
    by_cases hle : upperV k α ε + Ch*h ≤ ε*(α-1)
    · rw [min_eq_left hle, max_eq_left (by dsimp [x]; linarith)]
      dsimp [h]
      ring
    · rw [min_eq_right (le_of_not_ge hle), max_eq_right (by dsimp [x]; linarith)]
  have hmax0 : max (-Ch*h) x ≤ max x 0 := max_le
    (le_trans (by linarith) (le_max_right _ _)) (le_max_left _ _)
  have hmax1 : max x 0 ≤ max (-Ch*h) x + Ch*h := by
    apply max_le
    · have := le_max_right (-Ch*h) x; linarith
    · have := le_max_left (-Ch*h) x; linarith
  have hdiv0 := (div_le_div_iff_of_pos_right hh).2 hmax0
  have hdiv1 := (div_le_div_iff_of_pos_right hh).2 hmax1
  rw [add_div, mul_div_cancel_right₀ _ hh.ne'] at hdiv1
  unfold upperW
  rw [hid]
  change - (upperSigma k α ε + max x 0/h) ≤ -upperSigma k α ε-max (-Ch*h) x/h ∧
    -upperSigma k α ε-max (-Ch*h) x/h ≤ Ch-(upperSigma k α ε+max x 0/h)
  constructor <;> linarith

/-- Exact exponential root identity after reserving the overlap width. -/
theorem upper_root_shift_identity {k : ℕ} {α ε Ch : ℝ} (hk : 0 < k) (hα : 1 < α)
    (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1) :
    overlapPsi (fractionalPart α)*(k : ℝ)^(1/α)*
      Real.exp (-upperE0 k α ε Ch/(fractionalPart α*(1-fractionalPart α))) /
      rootMultiplier k α ε =
    α^2*(α-1)^2*(1+Real.log (rootMultiplier k α ε))*
      Real.exp (1-upperSigma k α ε-
        (upperV k α ε-upperDelta k α ε Ch)/(fractionalPart α*(1-fractionalPart α))) := by
  have hkR : 0 < (k : ℝ) := by exact_mod_cast hk
  have hα0 : 0 < α := by linarith
  have hβ : 0 < α-1 := sub_pos.mpr hα
  have hroot := (upper_root_slack hα hγ hγ1 (k := k) (ε := ε)).2.2
  let h := fractionalPart α*(1-fractionalPart α)
  have hh : 0 < h := mul_pos hγ (sub_pos.mpr hγ1)
  have hq : rootQSquared k α ε * Real.exp (upperDelta k α ε Ch/h) =
      overlapPsi (fractionalPart α)/(α^2*(α-1)^2)*(k : ℝ)^(1/α)*Real.exp (-upperE0 k α ε Ch/h) := by
    change overlapPsi (fractionalPart α)/(α^2*(α-1)^2)*
      Real.exp (Real.log k/α-(2*ε*(α-1))/h)*Real.exp (upperDelta k α ε Ch/h) = _
    rw [Real.rpow_def_of_pos hkR]
    simp only [mul_assoc, ← Real.exp_add]
    congr 2
    unfold upperE0
    ring
  have hshift := congrArg (fun q : ℝ => q*Real.exp (upperDelta k α ε Ch/h)) hroot
  have heq : Real.exp (1-upperV k α ε/h-upperSigma k α ε)*Real.exp (upperDelta k α ε Ch/h) =
      Real.exp (1-upperSigma k α ε-(upperV k α ε-upperDelta k α ε Ch)/h) := by
    rw [← Real.exp_add]
    congr 1
    ring
  change rootQSquared k α ε/rootMultiplier k α ε*Real.exp (upperDelta k α ε Ch/h) =
    (1+Real.log (rootMultiplier k α ε))*Real.exp (1-upperV k α ε/h-upperSigma k α ε)*
      Real.exp (upperDelta k α ε Ch/h) at hshift
  rw [mul_assoc, heq] at hshift
  have hleft : rootQSquared k α ε/rootMultiplier k α ε*Real.exp (upperDelta k α ε Ch/h) =
      (rootQSquared k α ε*Real.exp (upperDelta k α ε Ch/h))/rootMultiplier k α ε := by ring
  rw [hleft, hq] at hshift
  have hmul := congrArg (fun q : ℝ => α^2*(α-1)^2*q) hshift
  convert hmul using 1 <;> dsimp [h] <;> field_simp

def upperCutoffFactor (k : ℕ) (α ε D cb lambda CL cL : ℝ) : ℝ :=
  lambda*upperB k α ε D cb CL cL*(fractionalPart α*(1-fractionalPart α)) /
    ((upperOrderFloor α : ℝ)^2*(upperDegree α CL cL (rootMultiplier k α ε) : ℝ)^2) /
    ((α-1)/(α*k))

theorem upperA_ratio (k : ℕ) (α ε Ch D cb lambda CL cL : ℝ) :
    upperA k α ε Ch D cb lambda CL cL / ((α-1)/(α*k)) =
      upperCutoffFactor k α ε D cb lambda CL cL *
      upperOverlapZ (fractionalPart α) (upperE0 k α ε Ch)^
        (1/(fractionalPart α*(1-fractionalPart α))) := by
  unfold upperA upperCutoffFactor
  ring

theorem upperCutoffFactor_pos {k : ℕ} {α ε D cb lambda CL cL : ℝ}
    (hk : 0 < k) (hα : 1 < α) (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1)
    (hD : 0 < D) (hcb : 0 < cb) (hlambda : 0 < lambda) (hCL : 1 ≤ CL) (hcL : 0 < cL) :
    0 < upperCutoffFactor k α ε D cb lambda CL cL := by
  have hkR : 0 < (k : ℝ) := by exact_mod_cast hk
  have hα0 : 0 < α := by linarith
  have hβ : 0 < α-1 := sub_pos.mpr hα
  have hx := one_le_rootMultiplier hα hγ hγ1 (k := k) (ε := ε)
  have hx0 : 0 < rootMultiplier k α ε := zero_lt_one.trans_le hx
  have hm : 0 < (upperOrderFloor α : ℝ) := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one (upperOrderFloor_one_le hα))
  have hL := upperDegree_pos hα hCL hcL hx
  have hh : 0 < fractionalPart α*(1-fractionalPart α) := mul_pos hγ (sub_pos.mpr hγ1)
  unfold upperCutoffFactor upperB upperSample
  positivity

private theorem cutoff_field_identity {k K R α β D cb lambda X m L h Ψ Z : ℝ}
    (hk : k=K*R) (hK : K ≠ 0) (hR : R ≠ 0) (hα : α ≠ 0) (hβ : β ≠ 0)
    (hD : D ≠ 0) (hX : X ≠ 0) (hm : m ≠ 0) (hL : L ≠ 0) (hh : h ≠ 0) :
    (lambda*(cb*L/(D*α*K*X))*h/(m^2*L^2)/(β/(α*k))) * (α*Ψ/(β*h)*Z) =
      (lambda*cb/D)*(α/(m^2*L*β^2))*(Ψ*R*Z/X) := by
  rw [hk]
  field_simp

/-- Exact substitution of the root identity into the physical cutoff. -/
theorem upper_cutoff_arithmetic {k : ℕ} {α ε Ch D cb lambda CL cL : ℝ}
    (hk : 0 < k) (hα : 1 < α) (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1)
    (hD : 0 < D) (hCL : 1 ≤ CL) (hcL : 0 < cL) :
    upperCutoffFactor k α ε D cb lambda CL cL *
      (α*overlapPsi (fractionalPart α)/((α-1)*(fractionalPart α*(1-fractionalPart α))) *
        Real.exp (-upperE0 k α ε Ch/(fractionalPart α*(1-fractionalPart α)))) =
    (lambda*cb/D) * (α^3*(1+Real.log (rootMultiplier k α ε)) /
      ((upperOrderFloor α : ℝ)^2*(upperDegree α CL cL (rootMultiplier k α ε) : ℝ))) *
      Real.exp (1-upperSigma k α ε-
        (upperV k α ε-upperDelta k α ε Ch)/(fractionalPart α*(1-fractionalPart α))) := by
  have hkR : 0 < (k : ℝ) := by exact_mod_cast hk
  have hα0 : 0 < α := by linarith
  have hβ : 0 < α-1 := sub_pos.mpr hα
  have hx := one_le_rootMultiplier hα hγ hγ1 (k := k) (ε := ε)
  have hx0 : 0 < rootMultiplier k α ε := zero_lt_one.trans_le hx
  have hm : 0 < (upperOrderFloor α : ℝ) := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one (upperOrderFloor_one_le hα))
  have hL := upperDegree_pos hα hCL hcL hx
  have hh : 0 < fractionalPart α*(1-fractionalPart α) := mul_pos hγ (sub_pos.mpr hγ1)
  have hkpow : (k : ℝ) = (k : ℝ)^(1-1/α)*(k : ℝ)^(1/α) := by
    rw [← Real.rpow_add hkR, show 1-1/α+1/α = 1 by ring, Real.rpow_one]
  have hid := cutoff_field_identity (cb := cb) (lambda := lambda)
    (Ψ := overlapPsi (fractionalPart α))
    (Z := Real.exp (-upperE0 k α ε Ch/(fractionalPart α*(1-fractionalPart α))))
    hkpow (Real.rpow_pos_of_pos hkR _).ne' (Real.rpow_pos_of_pos hkR _).ne'
    hα0.ne' hβ.ne' hD.ne' hx0.ne' hm.ne' hL.ne' hh.ne'
  change upperCutoffFactor k α ε D cb lambda CL cL * _ = _ at hid
  rw [upper_root_shift_identity hk hα hγ hγ1] at hid
  rw [hid]
  field_simp

/-- Uniform comparison of the actual cutoff, including clipping slack.
The two constants are selected before the alphabet, order, and sample multiplier. -/
theorem upper_actual_cutoff {ε Ch cb lambda CL cL : ℝ}
    (hε : 0 < ε) (hCh : 0 ≤ Ch) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) :
    ∃ rminus rplus : ℝ, 0 < rminus ∧ 0 < rplus ∧ ∀ (k : ℕ) (α D : ℝ),
      0 < k → 1 < α → 0 < fractionalPart α → fractionalPart α < 1 → 0 < D →
      rminus/D*Real.exp (-upperW k α ε) ≤
        upperA k α ε Ch D cb lambda CL cL/((α-1)/(α*k)) ∧
      upperA k α ε Ch D cb lambda CL cL/((α-1)/(α*k)) ≤
        rplus/D*Real.exp (-upperW k α ε) := by
  obtain ⟨c₁,c₂,hc₁,hc₂,hcap⟩ := upper_overlap_capacity_interval hε
  have hU : 0 < max (CL+1) cL := lt_of_lt_of_le (by linarith) (le_max_left _ _)
  have hl : 0 < min CL cL := lt_min (by linarith) hcL
  refine ⟨c₁*lambda*cb*(1/max (CL+1) cL)*Real.exp 1,
    c₂*lambda*cb*(4/min CL cL)*Real.exp (1+Ch), by positivity, by positivity, ?_⟩
  intro k α D hk hα hγ hγ1 hD
  have hreserved := upper_reserved_interval hα hγ hγ1 hε hCh (k := k)
  have hcap' := hcap α (fractionalPart α) (upperE0 k α ε Ch) hα hγ hγ1
    (fractionalPart_le_order_gap hα) hreserved.1 hreserved.2
  have hfac := upperCutoffFactor_pos hk hα hγ hγ1 hD hcb hlambda hCL hcL (ε := ε)
  have hcalc := upper_cutoff_arithmetic hk hα hγ hγ1 hD hCL hcL (ε := ε) (Ch := Ch) (cb := cb) (lambda := lambda)
  let degree := α^3*(1+Real.log (rootMultiplier k α ε)) /
    ((upperOrderFloor α : ℝ)^2*(upperDegree α CL cL (rootMultiplier k α ε) : ℝ))
  let e := Real.exp (1-upperSigma k α ε-
    (upperV k α ε-upperDelta k α ε Ch)/(fractionalPart α*(1-fractionalPart α)))
  have harith : c₁*((lambda*cb/D)*degree*e) ≤
      upperA k α ε Ch D cb lambda CL cL/((α-1)/(α*k)) ∧
      upperA k α ε Ch D cb lambda CL cL/((α-1)/(α*k)) ≤ c₂*((lambda*cb/D)*degree*e) := by
    constructor
    · have hm := mul_le_mul_of_nonneg_left hcap'.1 hfac.le
      rw [upperA_ratio]
      calc
        _ = c₁*(upperCutoffFactor k α ε D cb lambda CL cL *
          (α*overlapPsi (fractionalPart α)/((α-1)*(fractionalPart α*(1-fractionalPart α))) *
            Real.exp (-upperE0 k α ε Ch/(fractionalPart α*(1-fractionalPart α))))) := by rw [hcalc]
        _ = _ := by ring
        _ ≤ _ := hm
    · have hm := mul_le_mul_of_nonneg_left hcap'.2 hfac.le
      rw [upperA_ratio]
      calc
        _ ≤ _ := hm
        _ = c₂*(upperCutoffFactor k α ε D cb lambda CL cL *
          (α*overlapPsi (fractionalPart α)/((α-1)*(fractionalPart α*(1-fractionalPart α))) *
            Real.exp (-upperE0 k α ε Ch/(fractionalPart α*(1-fractionalPart α))))) := by ring
        _ = _ := by rw [hcalc]
  have hdegree := upperDegree_factor_bounds hα hCL hcL (one_le_rootMultiplier hα hγ hγ1 (k := k) (ε := ε))
  change 1/max (CL+1) cL ≤ degree ∧ degree ≤ 4/min CL cL at hdegree
  have hdegree0 : 0 ≤ degree := (one_div_pos.mpr hU).le.trans hdegree.1
  have hw := upper_width_bounds hγ hγ1 hCh (k := k) (ε := ε)
  have helo : Real.exp 1*Real.exp (-upperW k α ε) ≤ e := by
    rw [← Real.exp_add]
    apply Real.exp_le_exp.mpr
    dsimp [e]
    linarith [hw.1]
  have hehi : e ≤ Real.exp (1+Ch)*Real.exp (-upperW k α ε) := by
    rw [← Real.exp_add]
    apply Real.exp_le_exp.mpr
    dsimp [e]
    linarith [hw.2]
  have hmullo := mul_le_mul hdegree.1 helo (by positivity) hdegree0
  have hmulhi := mul_le_mul hdegree.2 hehi (Real.exp_pos _).le (by positivity)
  constructor
  · apply le_trans _ harith.1
    have h := mul_le_mul_of_nonneg_left hmullo
      (by positivity : 0 ≤ c₁*(lambda*cb/D))
    convert h using 1 <;> ring
  · apply harith.2.trans
    have h := mul_le_mul_of_nonneg_left hmulhi
      (by positivity : 0 ≤ c₂*(lambda*cb/D))
    convert h using 1 <;> ring

def upperOmega (k : ℕ) (α ε Ch cω : ℝ) : ℝ := Real.exp (-cω*upperE0 k α ε Ch)

theorem upperSample_pos {k : ℕ} {α ε D : ℝ} (hk : 0 < k) (hα : 1 < α)
    (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1) (hD : 0 < D) :
    0 < upperSample k α ε D := by
  have hkR : 0 < (k : ℝ) := by exact_mod_cast hk
  have hα0 : 0 < α := by linarith
  have hx : 0 < rootMultiplier k α ε := zero_lt_one.trans_le (one_le_rootMultiplier hα hγ hγ1)
  unfold upperSample
  positivity

theorem upperB_pos {k : ℕ} {α ε D cb CL cL : ℝ} (hk : 0 < k) (hα : 1 < α)
    (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1) (hD : 0 < D)
    (hcb : 0 < cb) (hCL : 1 ≤ CL) (hcL : 0 < cL) : 0 < upperB k α ε D cb CL cL := by
  exact div_pos (mul_pos hcb (upperDegree_pos hα hCL hcL (one_le_rootMultiplier hα hγ hγ1)))
    (upperSample_pos hk hα hγ hγ1 hD)

/-- Exact convolution identity and the uniform one-quarter bound. -/
theorem upper_convolution {k : ℕ} {α ε Ch D cb lambda CL cL : ℝ}
    (hk : 0 < k) (hα : 1 < α) (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1)
    (hε : 0 < ε) (hCh : 0 ≤ Ch) (hD : 0 < D) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) :
    upperA k α ε Ch D cb lambda CL cL * (upperOrderFloor α : ℝ)^2 *
      (upperDegree α CL cL (rootMultiplier k α ε) : ℝ)^2 / upperB k α ε D cb CL cL =
      lambda*(fractionalPart α*(1-fractionalPart α)) *
        upperOverlapZ (fractionalPart α) (upperE0 k α ε Ch)^
          (1/(fractionalPart α*(1-fractionalPart α))) ∧
    lambda*(fractionalPart α*(1-fractionalPart α)) *
        upperOverlapZ (fractionalPart α) (upperE0 k α ε Ch)^
          (1/(fractionalPart α*(1-fractionalPart α))) ≤ lambda/4 := by
  have hb := upperB_pos hk hα hγ hγ1 hD hcb hCL hcL (ε := ε)
  have hm : 0 < (upperOrderFloor α : ℝ) := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one (upperOrderFloor_one_le hα))
  have hL := upperDegree_pos hα hCL hcL (one_le_rootMultiplier hα hγ hγ1 (k := k) (ε := ε))
  have hh : 0 < fractionalPart α*(1-fractionalPart α) := mul_pos hγ (sub_pos.mpr hγ1)
  have hhq : fractionalPart α*(1-fractionalPart α) ≤ 1/4 := by nlinarith [sq_nonneg (fractionalPart α-1/2)]
  have hE0 : 0 < upperE0 k α ε Ch := (mul_pos hε (sub_pos.mpr hα)).trans_le
    (upper_reserved_interval hα hγ hγ1 hε hCh).1
  have hz := (upperOverlapZ_spec hγ hγ1 hE0).1
  have hzpow : upperOverlapZ (fractionalPart α) (upperE0 k α ε Ch)^
      (1/(fractionalPart α*(1-fractionalPart α))) ≤ 1 := by
    simpa using Real.rpow_le_rpow hz.1.le hz.2.le (one_div_pos.mpr hh).le
  constructor
  · unfold upperA
    field_simp
  · calc
      _ ≤ lambda*(fractionalPart α*(1-fractionalPart α))*1 :=
        mul_le_mul_of_nonneg_left hzpow (mul_pos hlambda hh).le
      _ ≤ lambda/4 := by nlinarith

/-- The upper cutoff stays uniformly bounded even when the root grows. -/
theorem upperB_bound {k : ℕ} {α ε D cb CL cL : ℝ} (hk : 0 < k) (hα : 1 < α)
    (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1) (hD : 0 < D)
    (hcb : 0 < cb) (hCL : 1 ≤ CL) (hcL : 0 < cL) :
    upperB k α ε D cb CL cL ≤ cb/D*(CL+1+cL) := by
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hα0 : 0 < α := by linarith
  have hexp : 0 ≤ 1-1/α := sub_nonneg.mpr ((div_le_one hα0).2 hα.le)
  have hK : 1 ≤ (k : ℝ)^(1-1/α) := by
    simpa using Real.rpow_le_rpow (show (0 : ℝ) ≤ 1 by norm_num) hk1 hexp
  have hx := one_le_rootMultiplier hα hγ hγ1 (k := k) (ε := ε)
  have hx0 : 0 < rootMultiplier k α ε := zero_lt_one.trans_le hx
  have hL := upperDegree_pos hα hCL hcL hx
  have hnorm := upperDegree_over_alpha_X_le hα hCL hcL hx
  have hid : upperB k α ε D cb CL cL =
      (cb/D*((upperDegree α CL cL (rootMultiplier k α ε) : ℝ)/(α*rootMultiplier k α ε))) /
        (k : ℝ)^(1-1/α) := by unfold upperB upperSample; ring
  rw [hid]
  exact (div_le_self (by positivity) hK).trans (mul_le_mul_of_nonneg_left hnorm (div_pos hcb hD).le)

/-- The degree design and final sample multiplier enforce all remaining scales. -/
theorem upper_scale_restrictions {k : ℕ} {α ε Ch D cb lambda CL cL B : ℝ}
    (hk : 0 < k) (hα : 1 < α) (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1)
    (hε : 0 < ε) (hCh : 0 ≤ Ch) (hD : 0 < D) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hdesign : lambda ≤ 4*CL^2)
    (hpilot : 2*B ≤ cb*CL) (hDlarge : cb*(CL+1+cL) ≤ D) :
    upperA k α ε Ch D cb lambda CL cL ≤ upperB k α ε D cb CL cL ∧
    upperB k α ε D cb CL cL ≤ 1 ∧
    2*B*α ≤ upperSample k α ε D * upperB k α ε D cb CL cL := by
  have hα0 : 0 < α := by linarith
  have hb := upperB_pos hk hα hγ hγ1 hD hcb hCL hcL (ε := ε)
  have hn := upperSample_pos hk hα hγ hγ1 hD (ε := ε)
  have hx := one_le_rootMultiplier hα hγ hγ1 (k := k) (ε := ε)
  have hL := (upperDegree_bounds hα hCL hcL hx).1
  have hm1 : (1 : ℝ) ≤ upperOrderFloor α := by exact_mod_cast upperOrderFloor_one_le hα
  have hm0 : 0 < (upperOrderFloor α : ℝ) := by linarith
  have hLCL : CL ≤ (upperDegree α CL cL (rootMultiplier k α ε) : ℝ) := by nlinarith
  have hL0 := upperDegree_pos hα hCL hcL hx
  have hden : CL^2 ≤ (upperOrderFloor α : ℝ)^2*(upperDegree α CL cL (rootMultiplier k α ε) : ℝ)^2 := by
    have hsq := pow_le_pow_left₀ (by linarith : (0 : ℝ) ≤ CL) hLCL 2
    have hm2 : 1 ≤ (upperOrderFloor α : ℝ)^2 := by nlinarith
    nlinarith [mul_nonneg (sub_nonneg.mpr hm2) (sq_nonneg (upperDegree α CL cL (rootMultiplier k α ε) : ℝ))]
  have hc := upper_convolution hk hα hγ hγ1 hε hCh hD hcb hlambda hCL hcL
  have hquot : upperA k α ε Ch D cb lambda CL cL*(upperOrderFloor α : ℝ)^2*
      (upperDegree α CL cL (rootMultiplier k α ε) : ℝ)^2/upperB k α ε D cb CL cL ≤ lambda/4 := hc.1.trans_le hc.2
  have hquot' := (div_le_iff₀ hb).1 hquot
  have hbound : lambda/4 ≤ (upperOrderFloor α : ℝ)^2*(upperDegree α CL cL (rootMultiplier k α ε) : ℝ)^2 := by nlinarith
  have hmul := mul_le_mul_of_nonneg_right hbound hb.le
  have hdenpos : 0 < (upperOrderFloor α : ℝ)^2*(upperDegree α CL cL (rootMultiplier k α ε) : ℝ)^2 := by positivity
  refine ⟨?_, ?_, ?_⟩
  · apply (mul_le_mul_iff_right₀ hdenpos).1
    nlinarith
  · apply (upperB_bound hk hα hγ hγ1 hD hcb hCL hcL).trans
    rw [div_mul_eq_mul_div, div_le_one hD]
    exact hDlarge
  · have hid : upperSample k α ε D * upperB k α ε D cb CL cL =
        cb*(upperDegree α CL cL (rootMultiplier k α ε) : ℝ) := by unfold upperB; field_simp
    rw [hid]
    have hmul1 := mul_le_mul_of_nonneg_left hL hcb.le
    have hmul2 := mul_le_mul_of_nonneg_right hpilot hα0.le
    nlinarith

theorem upper_parameterW_nonneg {k : ℕ} {α ε : ℝ} (hα : 1 < α)
    (hγ : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1) : 0 ≤ upperW k α ε := by
  exact add_nonneg (upper_root_slack hα hγ hγ1).1
    (div_nonneg (le_max_right _ _) (mul_pos hγ (sub_pos.mpr hγ1)).le)

/-- Any prescribed fixed upper cutoff is enforced by one uniform sample multiplier. -/
theorem upper_cutoff_eventually_small {ε Ch cb lambda CL cL ca : ℝ}
    (hε : 0 < ε) (hCh : 0 ≤ Ch) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hca : 0 < ca) :
    ∃ D0 : ℝ, 1 ≤ D0 ∧ ∀ (k : ℕ) (α D : ℝ),
      0 < k → 1 < α → 0 < fractionalPart α → fractionalPart α < 1 → D0 ≤ D →
      upperA k α ε Ch D cb lambda CL cL ≤ ca*((α-1)/(α*k)) := by
  obtain ⟨rminus,rplus,_hrminus,hrplus,hcut⟩ := upper_actual_cutoff hε hCh hcb hlambda hCL hcL
  refine ⟨max 1 (rplus/ca), le_max_left _ _, ?_⟩
  intro k α D hk hα hγ hγ1 hD0
  have hD : 0 < D := zero_lt_one.trans_le ((le_max_left _ _).trans hD0)
  have hlarge : rplus/ca ≤ D := (le_max_right _ _).trans hD0
  have hratio : rplus/D ≤ ca := (div_le_iff₀ hD).2 (by
    have := (div_le_iff₀ hca).1 hlarge
    nlinarith)
  have he : Real.exp (-upperW k α ε) ≤ 1 := Real.exp_le_one_iff.mpr (neg_nonpos.mpr (upper_parameterW_nonneg hα hγ hγ1))
  have hcutoff := (hcut k α D hk hα hγ hγ1 hD).2
  have hquot : upperA k α ε Ch D cb lambda CL cL/((α-1)/(α*k)) ≤ ca :=
    hcutoff.trans ((mul_le_of_le_one_right (div_pos hrplus hD).le he).trans hratio)
  have hkR : 0 < (k : ℝ) := by exact_mod_cast hk
  exact (div_le_iff₀ (div_pos (sub_pos.mpr hα) (mul_pos (by linarith) hkR))).1 hquot

/-- The degree is fixed first and the sample multiplier second, uniformly in the order and alphabet. -/
theorem upper_scale_design {ε Ch cb lambda cL B : ℝ}
    (hε : 0 < ε) (hCh : 0 ≤ Ch) (hcb : 0 < cb) (hlambda : 0 < lambda) (hcL : 0 < cL) :
    ∃ CL0 : ℝ, 1 ≤ CL0 ∧ ∀ CL : ℝ, CL0 ≤ CL →
      ∃ D0 : ℝ, 1 ≤ D0 ∧ ∀ (k : ℕ) (α D : ℝ),
        0 < k → 1 < α → 0 < fractionalPart α → fractionalPart α < 1 → D0 ≤ D →
        upperA k α ε Ch D cb lambda CL cL ≤ upperB k α ε D cb CL cL ∧
        upperB k α ε D cb CL cL ≤ 1 ∧
        2*B*α ≤ upperSample k α ε D*upperB k α ε D cb CL cL := by
  refine ⟨max 1 (max lambda (2*B/cb)), le_max_left _ _, ?_⟩
  intro CL hCL0
  have hCL : 1 ≤ CL := (le_max_left _ _).trans hCL0
  have hlamCL : lambda ≤ CL := (le_max_left _ _).trans ((le_max_right _ _).trans hCL0)
  have hpilotCL : 2*B/cb ≤ CL := (le_max_right _ _).trans ((le_max_right _ _).trans hCL0)
  have hdesign : lambda ≤ 4*CL^2 := by nlinarith [sq_nonneg (CL-1)]
  have hpilot : 2*B ≤ cb*CL := by
    have := (div_le_iff₀ hcb).1 hpilotCL
    nlinarith
  refine ⟨max 1 (cb*(CL+1+cL)), le_max_left _ _, ?_⟩
  intro k α D hk hα hγ hγ1 hD0
  have hD : 0 < D := zero_lt_one.trans_le ((le_max_left _ _).trans hD0)
  exact upper_scale_restrictions hk hα hγ hγ1 hε hCh hD hcb hlambda hCL hcL hdesign hpilot
    ((le_max_right _ _).trans hD0)

end Renyi
