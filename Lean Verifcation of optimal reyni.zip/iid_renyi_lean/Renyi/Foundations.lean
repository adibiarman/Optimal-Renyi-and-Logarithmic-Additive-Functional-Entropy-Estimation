import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Probability.Distributions.Poisson
import Mathlib.Tactic

/-!
# Verified foundations for the i.i.d. Renyi entropy manuscript

This module proves preliminary results. It does NOT assert or prove the
manuscript's full minimax theorem. No approximation or sampling certificate
is introduced as an axiom.
-/

noncomputable section

open scoped BigOperators NNReal
open ProbabilityTheory

namespace Renyi

/-- Entropy as a function of a positive power sum. -/
def entropyFromPower (β P : ℝ) : ℝ := -Real.log P / β

/-- The asymmetric power-sum interval implies the exact requested accuracy.
Corresponds to equations (1.4)--(1.5) in the exposition. -/
theorem entropy_of_power_band {β ε P Z : ℝ}
    (hβ : 0 < β) (hP : 0 < P)
    (hlo : Real.exp (-2 * ε * β) * P ≤ Z) (hhi : Z ≤ P) :
    |(entropyFromPower β Z - ε) - entropyFromPower β P| ≤ ε := by
  have hZ : 0 < Z := lt_of_lt_of_le (mul_pos (Real.exp_pos _) hP) hlo
  have hloghi : Real.log Z ≤ Real.log P := Real.log_le_log hZ hhi
  have hloglo := Real.log_le_log (mul_pos (Real.exp_pos (-2 * ε * β)) hP) hlo
  rw [Real.log_mul (ne_of_gt (Real.exp_pos _)) (ne_of_gt hP), Real.log_exp] at hloglo
  unfold entropyFromPower
  simp only [neg_div]
  rw [abs_le]
  constructor
  · have h := (div_le_div_iff_of_pos_right hβ).2 hloghi
    linarith
  · have h : (Real.log P - Real.log Z) / β ≤ 2 * ε := by
      apply (div_le_iff₀ hβ).2
      linarith
    rw [sub_div] at h
    linarith

/-- Exact normalization identity after removing the known affine term.
Here `V` and `S` are the empirical power and first moments, and `W = V - A*S`.
This is the deterministic identity used by the lower-prior proof. -/
theorem normalization_identity {α b S A V : ℝ}
    (hα : 1 < α) (hb : 0 < b) (hS : 0 < S) (hA : 0 < A) (hV : 0 < V) :
    (α - 1) *
        (entropyFromPower (α - 1) (b ^ (1 - α) * V / S ^ α) -
          (Real.log b - Real.log A / (α - 1))) =
      (α - 1) * Real.log S - Real.log (1 + (V - A * S) / (A * S)) := by
  have hβ : α - 1 ≠ 0 := ne_of_gt (sub_pos.mpr hα)
  have hAS : A * S ≠ 0 := mul_ne_zero (ne_of_gt hA) (ne_of_gt hS)
  have hquot : 1 + (V - A * S) / (A * S) = V / (A * S) := by
    field_simp
    ring
  rw [hquot, Real.log_div (ne_of_gt hV) hAS,
    Real.log_mul (ne_of_gt hA) (ne_of_gt hS)]
  unfold entropyFromPower
  rw [Real.log_div (mul_ne_zero (ne_of_gt (Real.rpow_pos_of_pos hb _))
    (ne_of_gt hV)) (ne_of_gt (Real.rpow_pos_of_pos hS _)),
    Real.log_mul (ne_of_gt (Real.rpow_pos_of_pos hb _)) (ne_of_gt hV),
    Real.log_rpow hb, Real.log_rpow hS]
  field_simp
  ring

/-- Pointwise affine cancellation underlying the near-one variance analysis. -/
theorem affine_cancellation {β u A g gmean : ℝ}
    (hu : u ^ (1 + β) = u + β * g) (hA : A = 1 + β * gmean) :
    u ^ (1 + β) - A * u = β * (g - gmean * u) := by
  rw [hu, hA]
  ring

/-- The logarithmic normalization error budget has strict slack. -/
theorem normalization_budget {m : ℝ} (hm : 0 < m) :
    m / 12 + m / 11 < m / 4 := by
  linarith

/-- The final testing-error budget is strictly below the testing lower bound. -/
theorem testing_budget :
    (1 : ℝ) / 3 + 1 / 64 + 1 / 128 + 1 / 128 < 3 / 8 := by
  norm_num

/-- The positive and negative parity masses give the stated moment ratio. -/
theorem parity_ratio {B β Z Rminus Rplus : ℝ}
    (hB : 0 < B) (hZ : Z ≠ 0) (hR : Rminus + Rplus ≠ 0) :
    ((B ^ β / Z) * (1 + Rminus * Rplus)) /
        ((B ^ β / Z) * (Rminus + Rplus)) =
      (1 + Rminus * Rplus) / (Rminus + Rplus) := by
  have hpow : B ^ β ≠ 0 := ne_of_gt (Real.rpow_pos_of_pos hB β)
  field_simp

/-- The near-one residual vanishes at the known linear functional. -/
theorem affine_residual_zero (u : ℝ) : u - 1 * u = 0 := by ring

/-- A factorial-weighted Poisson mass is a shifted Poisson mass. -/
theorem poisson_factorial_shift (lam : ℝ≥0) (n j : ℕ) :
    ((n + j).descFactorial j : ℝ) * poissonPMFReal lam (n + j) =
      (lam : ℝ) ^ j * poissonPMFReal lam n := by
  have hf : (n.factorial : ℝ) * ((n + j).descFactorial j : ℝ) =
      ((n + j).factorial : ℝ) := by
    exact_mod_cast (show n.factorial * (n + j).descFactorial j = (n + j).factorial by
      simpa using Nat.factorial_mul_descFactorial (show j ≤ n + j by omega))
  have hn : (n.factorial : ℝ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero n
  have hnj : ((n + j).factorial : ℝ) ≠ 0 := by
    exact_mod_cast Nat.factorial_ne_zero (n + j)
  unfold poissonPMFReal
  rw [pow_add]
  field_simp
  rw [← hf]
  ring

/-- All Poisson factorial moments, with convergence proved as part of `HasSum`.
This is equation (4.1) of the manuscript, for every nonnegative intensity. -/
theorem poisson_factorial_hasSum (lam : ℝ≥0) (j : ℕ) :
    HasSum (fun n : ℕ => (n.descFactorial j : ℝ) * poissonPMFReal lam n)
      ((lam : ℝ) ^ j) := by
  have hs : HasSum
      (fun n : ℕ => ((n + j).descFactorial j : ℝ) * poissonPMFReal lam (n + j))
      ((lam : ℝ) ^ j) := by
    have heq :
        (fun n : ℕ => ((n + j).descFactorial j : ℝ) * poissonPMFReal lam (n + j)) =
        (fun n : ℕ => (lam : ℝ) ^ j * poissonPMFReal lam n) := by
      funext n
      exact poisson_factorial_shift lam n j
    rw [heq]
    simpa only [mul_one] using (poissonPMFRealSum lam).mul_left ((lam : ℝ) ^ j)
  have hz : ∑ n ∈ Finset.range j, (n.descFactorial j : ℝ) * poissonPMFReal lam n = 0 := by
    apply Finset.sum_eq_zero
    intro n hn
    rw [Nat.descFactorial_eq_zero_iff_lt.mpr (Finset.mem_range.mp hn)]
    simp
  have hfull := (hasSum_nat_add_iff
    (f := fun n : ℕ => (n.descFactorial j : ℝ) * poissonPMFReal lam n) j).mp hs
  simpa only [hz, add_zero] using hfull

/-- Unbiasedness written as an infinite sum against the Poisson pmf. -/
theorem poisson_factorial_moment (lam : ℝ≥0) (j : ℕ) :
    (∑' n : ℕ, (n.descFactorial j : ℝ) * poissonPMFReal lam n) = (lam : ℝ) ^ j :=
  (poisson_factorial_hasSum lam j).tsum_eq

/-- A polynomial in the mean gives an unbiased factorial statistic. -/
theorem poisson_polynomial_hasSum (lam : ℝ≥0) (L : ℕ) (c : ℕ → ℝ) :
    HasSum
      (fun n : ℕ => (∑ j ∈ Finset.range (L + 1), c j * (n.descFactorial j : ℝ)) *
        poissonPMFReal lam n)
      (∑ j ∈ Finset.range (L + 1), c j * (lam : ℝ) ^ j) := by
  have h := hasSum_sum (s := Finset.range (L + 1))
    (fun j _ => (poisson_factorial_hasSum lam j).mul_left (c j))
  simpa only [Finset.sum_mul, mul_assoc] using h

/-- The exact degree-two falling-factorial product identity. -/
theorem collision_product (n : ℕ) :
    (n.descFactorial 2 : ℝ) ^ 2 =
      (n.descFactorial 4 : ℝ) + 4 * (n.descFactorial 3 : ℝ) +
        2 * (n.descFactorial 2 : ℝ) := by
  by_cases hn : 4 ≤ n
  · simp only [Nat.descFactorial_succ, Nat.descFactorial_zero, Nat.cast_mul,
      mul_one]
    norm_num
    rw [Nat.cast_sub (by omega : 1 ≤ n), Nat.cast_sub (by omega : 2 ≤ n),
      Nat.cast_sub (by omega : 3 ≤ n)]
    push_cast
    ring
  · interval_cases n <;> norm_num [Nat.descFactorial_succ]

/-- The exact Poisson second moment of the degree-two collision statistic. -/
theorem poisson_collision_second_hasSum (lam : ℝ≥0) :
    HasSum (fun n : ℕ => (n.descFactorial 2 : ℝ) ^ 2 * poissonPMFReal lam n)
      ((lam : ℝ) ^ 4 + 4 * (lam : ℝ) ^ 3 + 2 * (lam : ℝ) ^ 2) := by
  have h := ((poisson_factorial_hasSum lam 4).add
    ((poisson_factorial_hasSum lam 3).mul_left 4)).add
    ((poisson_factorial_hasSum lam 2).mul_left 2)
  simpa only [collision_product, add_mul, mul_assoc] using h

/-- The resulting scalar variance, expressed directly in moments. -/
theorem poisson_collision_variance (lam : ℝ≥0) :
    (∑' n : ℕ, (n.descFactorial 2 : ℝ) ^ 2 * poissonPMFReal lam n) -
      (∑' n : ℕ, (n.descFactorial 2 : ℝ) * poissonPMFReal lam n) ^ 2 =
        4 * (lam : ℝ) ^ 3 + 2 * (lam : ℝ) ^ 2 := by
  rw [(poisson_collision_second_hasSum lam).tsum_eq, poisson_factorial_moment]
  ring

end Renyi
