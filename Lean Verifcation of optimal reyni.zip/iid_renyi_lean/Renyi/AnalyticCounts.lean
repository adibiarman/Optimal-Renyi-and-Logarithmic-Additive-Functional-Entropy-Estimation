import Renyi.FactorialEnergyProbability
import Renyi.Pilot
import Mathlib.Analysis.SpecialFunctions.Gamma.Basic

/-!
# Analytic Gamma-ratio count identities

The reciprocal-Gamma convention gives zero at every nonpositive integer.
The identities below therefore include the removable zeros without excluding
integer parameters or low count values.
-/

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- The signed analytic extension of falling factorial counts. -/
def analyticCount (a : ℝ) (j : ℕ) : ℝ :=
  (j.factorial : ℝ) / Real.Gamma ((j : ℝ) + 1 - a)

/-- Forward difference on a sequence indexed by natural counts. -/
def forwardDifference (v : ℕ → ℝ) : ℕ → ℝ := fun j => v (j + 1) - v j

/-- The real falling factorial coefficient `(a)_ell`. -/
def realFalling (a : ℝ) (ell : ℕ) : ℝ := ∏ k ∈ Finset.range ell, (a - k)

/-- Reciprocal-Gamma recurrence, including its zeros at the poles of Gamma. -/
theorem gamma_inv_recurrence (s : ℝ) :
    (Real.Gamma s)⁻¹ = s * (Real.Gamma (s + 1))⁻¹ := by
  by_cases hs : s = 0
  · simp [hs]
  · rw [Real.Gamma_add_one hs, mul_inv]
    field_simp

/-- Raising the order by one multiplies by the affine count factor. -/
theorem analyticCount_order_succ (a : ℝ) (j : ℕ) :
    analyticCount (a + 1) j = ((j : ℝ) - a) * analyticCount a j := by
  unfold analyticCount
  rw [div_eq_mul_inv, div_eq_mul_inv]
  rw [show (j : ℝ) + 1 - (a + 1) = (j : ℝ) - a by ring,
    gamma_inv_recurrence ((j : ℝ) - a)]
  rw [show (j : ℝ) - a + 1 = (j : ℝ) + 1 - a by ring]
  ring

/-- The exact first finite difference has no exceptional parameters. -/
theorem analyticCount_difference (a : ℝ) (j : ℕ) :
    forwardDifference (analyticCount a) j = a * analyticCount (a - 1) j := by
  unfold forwardDifference analyticCount
  simp only [Nat.factorial_succ, Nat.cast_mul, Nat.cast_add, Nat.cast_one, div_eq_mul_inv]
  rw [gamma_inv_recurrence ((j : ℝ) + 1 - a)]
  have h1 : (j : ℝ) + 1 + 1 - a = (j : ℝ) + 1 - (a - 1) := by ring
  have h2 : (j : ℝ) + 1 - a + 1 = (j : ℝ) + 1 - (a - 1) := by ring
  rw [h1, h2]
  ring

/-- Every iterated difference is another member of the same analytic family. -/
theorem analyticCount_iterated_difference (a : ℝ) (ell j : ℕ) :
    (forwardDifference^[ell]) (analyticCount a) j =
      realFalling a ell * analyticCount (a - ell) j := by
  induction ell generalizing j with
  | zero => simp [realFalling]
  | succ ell ih =>
      rw [Function.iterate_succ_apply']
      change (forwardDifference^[ell]) (analyticCount a) (j + 1) -
        (forwardDifference^[ell]) (analyticCount a) j = _
      rw [ih, ih, ← mul_sub]
      change realFalling a ell * forwardDifference (analyticCount (a - ell)) j = _
      rw [analyticCount_difference]
      simp only [realFalling, Finset.prod_range_succ, Nat.cast_add, Nat.cast_one]
      rw [show a - (ell : ℝ) - 1 = a - ((ell : ℝ) + 1) by ring]
      ring

/-- At integer orders the analytic family is exactly the ordinary falling factorial. -/
theorem analyticCount_nat (r j : ℕ) :
    analyticCount (r : ℝ) j = (j.descFactorial r : ℝ) := by
  induction r with
  | zero => simp [analyticCount, Real.Gamma_nat_eq_factorial, Nat.factorial_ne_zero]
  | succ r ih =>
      rw [Nat.cast_add, Nat.cast_one, analyticCount_order_succ, ih, Nat.descFactorial_succ]
      by_cases hr : r ≤ j
      · rw [Nat.cast_mul, Nat.cast_sub hr]
      · have hjr : j < r := Nat.lt_of_not_ge hr
        rw [Nat.descFactorial_eq_zero_iff_lt.mpr hjr]
        simp

/-- Counts above the parameter have a positive Gamma denominator. -/
theorem analyticCount_pos (a : ℝ) (j : ℕ) (hj : a < (j : ℝ) + 1) :
    0 < analyticCount a j := by
  exact div_pos (by positivity) (Real.Gamma_pos_of_pos (by linarith))

/-- In particular, every count at or above the floor of the order is positive. -/
theorem analyticCount_pos_of_floor_le (a : ℝ) (j : ℕ) (hj : ⌊a⌋ ≤ (j : ℤ)) :
    0 < analyticCount a j := by
  apply analyticCount_pos
  have hfloor : ((⌊a⌋ : ℤ) : ℝ) ≤ (j : ℝ) := by exact_mod_cast hj
  exact (Int.lt_floor_add_one a).trans_le (by linarith)

/-- Integer analytic counts are square integrable under every Poisson law. -/
theorem analyticCount_nat_memLp (lam : ℝ≥0) (r : ℕ) :
    MemLp (analyticCount (r : ℝ)) 2 (poissonMeasure lam) := by
  have heq : analyticCount (r : ℝ) = fun j => (j.descFactorial r : ℝ) :=
    funext (analyticCount_nat r)
  rw [heq]
  exact poisson_memLp_of_squared_hasSum lam _ _
    (poisson_factorial_cross_hasSum lam r r |>.congr_fun (by intro j; ring))

/-- The exact Poisson mean of each integer member is the corresponding power. -/
theorem analyticCount_nat_mean (lam : ℝ≥0) (r : ℕ) :
    (∫ j, analyticCount (r : ℝ) j ∂poissonMeasure lam) = (lam : ℝ) ^ r := by
  rw [poisson_integral_eq_tsum lam _ ((analyticCount_nat_memLp lam r).integrable one_le_two)]
  simp_rw [analyticCount_nat]
  exact poisson_factorial_moment lam r

/-- Nonpositive orders give positive decreasing, hence bounded, count sequences. -/
theorem analyticCount_bounded_nonpos (a : ℝ) (ha : a ≤ 0) (j : ℕ) :
    |analyticCount a j| ≤ analyticCount a 0 := by
  have hpos (q : ℕ) : 0 < analyticCount a q := analyticCount_pos a q (by have := Nat.cast_nonneg (α := ℝ) q; linarith)
  have hmono : Antitone (analyticCount a) := by
    apply antitone_nat_of_succ_le
    intro q
    have hd := analyticCount_difference a q
    have hsign : a * analyticCount (a - 1) q ≤ 0 :=
      mul_nonpos_of_nonpos_of_nonneg ha (analyticCount_pos (a - 1) q (by have := Nat.cast_nonneg (α := ℝ) q; linarith)).le
    unfold forwardDifference at hd
    linarith
  rw [abs_of_pos (hpos j)]
  exact hmono (Nat.zero_le j)

/-- Polynomial growth is obtained by raising a bounded nonpositive order finitely often. -/
theorem analyticCount_polynomial_growth_degree (m : ℕ) (a : ℝ) (ha : a ≤ m) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ j : ℕ, |analyticCount a j| ≤ C * ((j : ℝ) + 1) ^ m := by
  induction m generalizing a with
  | zero =>
      refine ⟨analyticCount a 0, (analyticCount_pos a 0 (by norm_num at ha ⊢; linarith)).le, ?_⟩
      intro j
      simpa using analyticCount_bounded_nonpos a (by simpa using ha) j
  | succ m ih =>
      have ham : a - 1 ≤ (m : ℝ) := by push_cast at ha; linarith
      obtain ⟨C, hC, hbound⟩ := ih (a - 1) ham
      refine ⟨(1 + |a - 1|) * C, by positivity, ?_⟩
      intro j
      have hid : analyticCount a j = ((j : ℝ) - (a - 1)) * analyticCount (a - 1) j := by
        simpa only [sub_add_cancel] using analyticCount_order_succ (a - 1) j
      have hcoef : |(j : ℝ) - (a - 1)| ≤ (1 + |a - 1|) * ((j : ℝ) + 1) := by
        have ht : |(j : ℝ) - (a - 1)| ≤ (j : ℝ) + |a - 1| := by
          simpa only [sub_eq_add_neg, abs_neg, Nat.abs_cast] using
            (abs_add_le (j : ℝ) (-(a - 1)))
        nlinarith [mul_nonneg (Nat.cast_nonneg j : (0 : ℝ) ≤ j) (abs_nonneg (a - 1))]
      rw [hid, abs_mul]
      apply (mul_le_mul hcoef (hbound j) (abs_nonneg _) (by positivity)).trans
      rw [pow_succ]
      exact le_of_eq (by ring)

/-- Every real order has an elementary global polynomial bound. -/
theorem analyticCount_polynomial_growth (a : ℝ) :
    ∃ m : ℕ, ∃ C : ℝ, 0 ≤ C ∧ ∀ j : ℕ, |analyticCount a j| ≤ C * ((j : ℝ) + 1) ^ m := by
  obtain ⟨m, hm⟩ := exists_nat_ge a
  exact ⟨m, analyticCount_polynomial_growth_degree m a hm⟩

theorem real_pow_le_factorial_mul_exp (x : ℝ) (hx : 0 ≤ x) (m : ℕ) :
    x ^ m ≤ (m.factorial : ℝ) * Real.exp x := by
  have hterm : x ^ m / (m.factorial : ℝ) ≤
      ∑ j ∈ Finset.range (m + 1), x ^ j / (j.factorial : ℝ) :=
    Finset.single_le_sum (s := Finset.range (m + 1))
      (f := fun j : ℕ => x ^ j / (j.factorial : ℝ))
      (fun j _ => by positivity) (Finset.mem_range.mpr (Nat.lt_succ_self m))
  have h := (div_le_iff₀ (by positivity : (0 : ℝ) < m.factorial)).mp
    (hterm.trans (Real.sum_le_exp_of_nonneg hx (m + 1)))
  simpa only [mul_comm] using h

theorem poisson_exp_memLp (lam : ℝ≥0) :
    MemLp (fun j : ℕ => Real.exp (j : ℝ)) 2 (poissonMeasure lam) := by
  apply poisson_memLp_of_squared_hasSum lam _ (Real.exp ((lam : ℝ) * (Real.exp 2 - 1)))
  have h := poisson_exp_hasSum lam 2
  convert h using 1
  funext j
  rw [← Real.exp_nat_mul]
  norm_num

/-- All natural powers of the count are square integrable, proved from the exponential moment. -/
theorem poisson_count_power_memLp (lam : ℝ≥0) (m : ℕ) :
    MemLp (fun j : ℕ => ((j : ℝ) + 1) ^ m) 2 (poissonMeasure lam) := by
  have h := (poisson_exp_memLp lam).const_mul ((m.factorial : ℝ) * Real.exp 1)
  apply h.of_le (measurable_of_countable _).aestronglyMeasurable
  filter_upwards [] with j
  simp only [Real.norm_eq_abs, abs_of_nonneg (by positivity : 0 ≤ ((j : ℝ) + 1) ^ m),
    abs_of_nonneg (by positivity : 0 ≤ ((m.factorial : ℝ) * Real.exp 1) * Real.exp (j : ℝ))]
  have hg := real_pow_le_factorial_mul_exp ((j : ℝ) + 1) (by positivity) m
  rw [Real.exp_add] at hg
  convert hg using 1
  ring

/-- The signed analytic count is square integrable for every real order. -/
theorem analyticCount_memLp (lam : ℝ≥0) (a : ℝ) :
    MemLp (analyticCount a) 2 (poissonMeasure lam) := by
  obtain ⟨m, C, hC, hbound⟩ := analyticCount_polynomial_growth a
  have h := (poisson_count_power_memLp lam m).const_mul C
  apply h.of_le (measurable_of_countable _).aestronglyMeasurable
  filter_upwards [] with j
  simp only [Real.norm_eq_abs, abs_of_nonneg (by positivity : 0 ≤ C * ((j : ℝ) + 1) ^ m)]
  exact hbound j

/-- The Poisson mean exists for every real order, including signed low counts. -/
def analyticMean (lam : ℝ≥0) (a : ℝ) : ℝ :=
  ∫ j, analyticCount a j ∂poissonMeasure lam

theorem analyticMean_eq_tsum (lam : ℝ≥0) (a : ℝ) :
    analyticMean lam a = ∑' j, analyticCount a j * poissonPMFReal lam j :=
  poisson_integral_eq_tsum lam _ ((analyticCount_memLp lam a).integrable one_le_two)

/-- Every iterated difference is also square integrable. -/
theorem analyticCount_difference_memLp (lam : ℝ≥0) (a : ℝ) (ell : ℕ) :
    MemLp ((forwardDifference^[ell]) (analyticCount a)) 2 (poissonMeasure lam) := by
  have heq : (forwardDifference^[ell]) (analyticCount a) =
      fun j => realFalling a ell * analyticCount (a - ell) j :=
    funext (analyticCount_iterated_difference a ell)
  rw [heq]
  exact (analyticCount_memLp lam (a - ell)).const_mul _

/-- Exact mean of every iterated finite difference. -/
theorem analyticCount_difference_mean (lam : ℝ≥0) (a : ℝ) (ell : ℕ) :
    (∫ j, (forwardDifference^[ell]) (analyticCount a) j ∂poissonMeasure lam) =
      realFalling a ell * analyticMean lam (a - ell) := by
  simp_rw [analyticCount_iterated_difference]
  exact integral_const_mul _ _

theorem analyticMean_zero (a : ℝ) :
    analyticMean 0 a = (Real.Gamma (1 - a))⁻¹ := by
  rw [analyticMean_eq_tsum, tsum_eq_single 0]
  · simp [analyticCount, poissonPMFReal]
  · intro j hj
    simp [poissonPMFReal, zero_pow hj]

/-- At integer orders the actual variance is a finite collision series. -/
theorem analyticCount_nat_variance (lam : ℝ≥0) (r : ℕ) :
    variance (analyticCount (r : ℝ)) (poissonMeasure lam) =
      ∑ j ∈ Finset.range r, (r.choose (j + 1) : ℝ) ^ 2 *
        ((j + 1).factorial : ℝ) * (lam : ℝ) ^ (2 * r - (j + 1)) := by
  rw [variance_eq_sub (analyticCount_nat_memLp lam r), analyticCount_nat_mean]
  simp only [Pi.pow_apply]
  rw [poisson_integral_eq_tsum lam _ (analyticCount_nat_memLp lam r).integrable_sq]
  simp_rw [analyticCount_nat, pow_two]
  rw [(poisson_factorial_cross_hasSum lam r r).tsum_eq, min_self, Finset.sum_range_succ']
  simp only [Nat.choose_zero_right, Nat.cast_one, Nat.factorial_zero, one_mul,
    Nat.sub_zero]
  rw [show r + r = 2 * r by omega, mul_comm 2 r, pow_mul]
  ring

end Renyi
