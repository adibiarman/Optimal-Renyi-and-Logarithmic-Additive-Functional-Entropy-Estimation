import Renyi.CompletedPilotComparison
import Renyi.OmegaHeavyTrueSelection

/-! Exact identification of the pilot ideal with the deterministic oracle and
its single true-heavy aggregate perturbation. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 700000
variable {ι Ω : Type*} [Fintype ι]

def pilotOracleLight (p : ι→ℝ) (Y : ι→Ω→ℕ) (n b alpha cp B : ℝ) (w : Ω) : ι→Bool :=
  fun i => decide (n*p i<B*alpha/2 ∨ (p i≤b ∧ (Y i w:ℝ)≤cp*B*alpha))

def pilotTrueHeavyMass (p : ι→ℝ) (Y : ι→Ω→ℕ) (n alpha cp B : ℝ) (w : Ω) : ℝ :=
  ∑i,if B*alpha/2≤n*p i ∧ cp*B*alpha<(Y i w:ℝ) then p i^alpha else 0

omit [Fintype ι] in
lemma pilotOracleLight_admissible (p : ι→ℝ) (Y : ι→Ω→ℕ)
    {n b alpha cp B : ℝ} (hn : 0<n) (hcut : B*alpha/2≤n*b) (w : Ω) :
    ∀i,pilotOracleLight p Y n b alpha cp B w i=true→p i≤b := by
  intro i hi
  have hi' : n*p i<B*alpha/2 ∨ (p i≤b ∧ (Y i w:ℝ)≤cp*B*alpha) := by
    simpa only [pilotOracleLight,decide_eq_true_eq] using hi
  rcases hi' with hs|hl
  · exact (mul_le_mul_iff_right₀ hn).mp (by nlinarith only [hs,hcut])
  · exact hl.1

/-- The oracle and the ideal share every false-light power arm; their sole
difference is the selected true-heavy Gamma aggregate. -/
theorem pilot_ideal_oracle_difference (p Q : ι→ℝ) (Y Counts : ι→Ω→ℕ)
    (n b alpha cp B omega : ℝ) (w : Ω) :
    pilotIdealPower p Q Y Counts n b alpha cp B omega w-
      (∑i,if pilotOracleLight p Y n b alpha cp B w i then Q i else omega*p i^alpha)=
      pilotTrueHeavyPower p Y Counts n alpha cp B omega w-
        omega*pilotTrueHeavyMass p Y n alpha cp B w := by
  unfold pilotIdealPower pilotTrueHeavyPower pilotTrueHeavyMass
  rw [←Finset.sum_sub_distrib,Finset.mul_sum,←Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro i _
  by_cases hs : n*p i<B*alpha/2 <;>
    by_cases hl : (Y i w:ℝ)≤cp*B*alpha <;>
      by_cases hb : p i≤b <;>
        simp [pilotOracleLight,pilotIdealCoordinate,hs,hl,hb,not_le.mpr,not_lt.mpr,not_le.mp,not_lt.mp]

lemma pilotTrueHeavyMass_le_powerSum {k : ℕ} (p : Simplex k) (Y : Fin k→Ω→ℕ)
    (n alpha cp B : ℝ) (w : Ω) : pilotTrueHeavyMass p.mass Y n alpha cp B w≤powerSum p alpha := by
  apply Finset.sum_le_sum
  intro i _
  split_ifs
  · exact le_rfl
  · exact Real.rpow_nonneg (p.nonneg i) _

lemma pilotTrueHeavyMass_subset_sum {k : ℕ} (p : Simplex k)
    (n alpha cp B : ℝ) (h : PilotHistogram k) :
    pilotTrueHeavyMass p.mass (fun i => pilotSelectionCount i) n alpha cp B h=
      ∑i∈trueHeavyPilotSubset p n alpha cp B (fun i => pilotSelectionCount i h),(p.mass i)^alpha := by
  simp only [pilotTrueHeavyMass,trueHeavyPilotSubset,Finset.sum_filter]

/-- The exact heavy closeness event transfers to a bound by the full P. -/
theorem pilot_ideal_oracle_error {k : ℕ} (p : Simplex k) (Q : Fin k→ℝ)
    (Y Counts : Fin k→Ω→ℕ) (n b alpha cp B omega : ℝ) {eta : ℝ} (heta : 0≤eta) (w : Ω)
    (hheavy : |pilotTrueHeavyPower p.mass Y Counts n alpha cp B omega w-
      omega*pilotTrueHeavyMass p.mass Y n alpha cp B w|≤eta*pilotTrueHeavyMass p.mass Y n alpha cp B w) :
    |pilotIdealPower p.mass Q Y Counts n b alpha cp B omega w-
      (∑i,if pilotOracleLight p.mass Y n b alpha cp B w i then Q i else omega*p.mass i^alpha)|≤
      eta*powerSum p alpha := by
  rw [pilot_ideal_oracle_difference]
  exact hheavy.trans (mul_le_mul_of_nonneg_left (pilotTrueHeavyMass_le_powerSum p Y n alpha cp B w) heta)
end Renyi
