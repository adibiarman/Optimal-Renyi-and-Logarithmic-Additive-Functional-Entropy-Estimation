import Renyi.CoupledHighVariance
import Renyi.CompletedLeadingCoefficient
import Renyi.CompletedGlobalCoefficients

/-! Actual high count noise for both branches of the completed coupled polynomial. -/
set_option maxHeartbeats 1000000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- CC16 in count units for the actual coupled polynomial. The leading bound
is instantiated from its actual reciprocal-Gamma/profile coefficient, rather
than assumed as a coefficient certificate. -/
theorem completed_high_count_variance {ell N m d : ℕ}
    (hell : 0 < ell) (hN : 0 < N) (hm : 1 ≤ m) (hdegree : 4 * (ell - 1) ≤ m)
    {gamma aCut b n cProfile fL f A B omega L Cscale Cb Cd Ct cp Bpilot M : ℝ}
    (hgamma : 0 < gamma) (hgamma1 : gamma < 1)
    (haCut : 0 < aCut) (hab : aCut ≤ b) (hb : 0 < b) (hn : 0 < n)
    (hcProfile : cProfile ∈ Set.Ioo (gamma / (1 + gamma)) 1)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hB : 0 ≤ B) (hB1 : B ≤ 1)
    (hw : 0 ≤ omega) (hw1 : omega < 1)
    (hlocal : (ell : ℝ) ^ 2 * (aCut * (N : ℝ) ^ 2 / b) ≤ 1)
    (hL : 0 < L) (hscale : 0 < Cscale) (hcountScale : (N : ℝ) ^ 2 / (n * b) ≤ Cscale * L)
    (hH : 1 ≤ n * b) (hrd : m + 1 ≤ d)
    (hCb : 0 ≤ Cb) (hCd : 0 ≤ Cd) (hdegreeL : (d : ℝ) ≤ Cd * L)
    (hCt : 2 * Cb + 4 * Cd ≤ Ct) (hCt2 : 2 ≤ Ct)
    (hbudget : coupledCoefficientBudget ell N gamma aCut b A B omega ≤ Real.exp (Cb * L))
    (hcp0 : 0 < cp) (hBpilot : 0 ≤ Bpilot) (hM : 0 ≤ M)
    (hdegreeH : (d : ℝ) ≤ M * (n * b)) (hcp : 4 * M ≤ cp) (lam : ℝ≥0) :
    let order : ℝ := (m : ℝ) + gamma
    let r := m + 1
    let Q := completedCoupledPolynomial ell N m gamma aCut b cProfile fL f A B omega
    let c : ℕ → ℝ := fun j => n ^ (order - j) * Q.coeff j
    let K := completedLeadingCoefficientConstant * max 1 Cscale
    let tiny := 2 * K ^ 2 * Real.exp 2 * (2 * (r : ℝ)) ^ r +
      2 * ((r + 1 : ℕ) : ℝ) ^ (r + 1)
    let medium := ((d : ℝ) + 1) ^ 2 * (coupledCoefficientBudget ell N gamma aCut b A B omega) ^ 2 *
      Real.exp (cp * Bpilot * order + M * d)
    poissonLowerMass ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp * Bpilot * order) *
      variance (factorialStatistic d (highCountCoefficients r c)) (poissonMeasure lam) ≤
        tiny * (lam : ℝ) ^ order +
          if Real.exp (-Ct * L) < (lam : ℝ) then medium * (n * b) ^ order * (lam : ℝ) ^ order else 0 := by
  let order : ℝ := (m : ℝ) + gamma
  let r := m + 1
  let Q := completedCoupledPolynomial ell N m gamma aCut b cProfile fL f A B omega
  let c : ℕ → ℝ := fun j => n ^ (order - j) * Q.coeff j
  let K := completedLeadingCoefficientConstant * max 1 Cscale
  let budget := coupledCoefficientBudget ell N gamma aCut b A B omega
  have horder : 0 < order := by dsimp [order]; have := Nat.cast_nonneg (α := ℝ) m; linarith
  have hgap : (r : ℝ) = order + (1 - gamma) := by dsimp [r, order]; push_cast; ring
  have hdelta : 0 < 1 - gamma := by linarith
  have har : order ≤ (r : ℝ) := by linarith
  have hbudget0 : 0 ≤ budget := by
    dsimp [budget, coupledCoefficientBudget]
    have := sub_nonneg.mpr hB1
    positivity
  have hK : 0 ≤ K := mul_nonneg completedLeadingCoefficientConstant_pos.le (by positivity)
  have hc (j : ℕ) : |c j| ≤ budget * (n * b) ^ (order - j) := by
    exact count_coefficient_scaled_bound hn hb j
      (completedCoupledPolynomial_coefficient_bound hell hN hm hdegree hgamma hgamma1 haCut.le hab hb hcProfile
        hfL hfL1 hf hf1 hA hB hB1 hw hw1 j)
  have hlead : |c r| ≤ K * (L / (1 - gamma)) ^ (1 - gamma) := by
    have h := completedCoupledPolynomial_leading_count_uniform hell hN hm hdegree hgamma hgamma1 haCut hb hn hcProfile
      hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1 hlocal hL hscale hcountScale
    have he : order - (r : ℝ) = -(1 - gamma) := by linarith
    change |n ^ (order - (r : ℝ)) * Q.coeff r| ≤ _
    rw [he]
    exact h
  have htail (j : ℕ) (hrj : r < j) (_hjd : j ≤ d) : |c j| ≤ budget := by
    have hexp : order - (j : ℝ) ≤ 0 := by
      have hj : (r : ℝ) < j := by exact_mod_cast hrj
      linarith
    have hp := Real.rpow_le_one_of_one_le_of_nonpos hH hexp
    exact (hc j).trans (by simpa only [mul_one] using mul_le_mul_of_nonneg_left hp hbudget0)
  have hall := high_count_selected_variance_all lam (lt_of_lt_of_le (by norm_num : (0 : ℝ) < 1) hH)
    horder har hbudget0 hcp0 hBpilot hM hdegreeH hcp c (fun j _ _ => hc j)
  dsimp only
  by_cases hsmall : (lam : ℝ) ≤ Real.exp (-Ct * L)
  · rw [if_neg (not_lt.mpr hsmall), add_zero]
    have htiny := high_count_variance_tiny lam horder hdelta hgap hrd hK hL hCb hCd hbudget0
      hbudget hdegreeL hCt hCt2 c hlead htail hsmall
    have hselected : poissonLowerMass ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp * Bpilot * order) *
        variance (factorialStatistic d (highCountCoefficients r c)) (poissonMeasure lam) ≤
        variance (factorialStatistic d (highCountCoefficients r c)) (poissonMeasure lam) :=
      mul_le_of_le_one_left (variance_nonneg _ _) (poissonLowerMass_le_one _ _)
    exact hselected.trans htiny
  · rw [if_pos (lt_of_not_ge hsmall)]
    exact hall.trans (le_add_of_nonneg_left (by positivity))


variable {iota Omega Xi : Type*} [Fintype iota] [MeasurableSpace Omega] [MeasurableSpace Xi]
variable {mu : Measure Omega} {nu : Measure Xi}

/-- The actual pilot-averaged high-block count variance, with the full tiny /
larger-mean split and the exact probability-unit scaling. -/
theorem completed_high_averaged_count_variance {ell N m d : ℕ}
    (hell : 0 < ell) (hN : 0 < N) (hm : 1 ≤ m) (hdegree : 4 * (ell - 1) ≤ m)
    {gamma aCut b n cProfile fL f A B omega L Cscale Cd Ct cp Bpilot M : ℝ}
    (hgamma : 0 < gamma) (hgamma1 : gamma < 1)
    (haCut : 0 < aCut) (hab : aCut ≤ b) (hb : 0 < b) (hn : 0 < n)
    (hcProfile : cProfile ∈ Set.Ioo (gamma / (1 + gamma)) 1)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hB : 0 ≤ B) (hB1 : B ≤ 1)
    (hw : 0 ≤ omega) (hw1 : omega < 1)
    (hlocal : (ell : ℝ) ^ 2 * (aCut * (N : ℝ) ^ 2 / b) ≤ 1)
    (hL : 1 ≤ L) (hellL : (ell : ℝ) ≤ L) (hNL : (N : ℝ) ≤ L)
    (hscale : 0 < Cscale) (hcountScale : (N : ℝ) ^ 2 / (n * b) ≤ Cscale * L)
    (hH : 1 ≤ n * b) (hrd : m + 1 ≤ d)
    (hCd : 0 ≤ Cd) (hdegreeL : (d : ℝ) ≤ Cd * L)
    (hCt : 2 * coupledCoefficientExponentialConstant + 4 * Cd ≤ Ct) (hCt2 : 2 ≤ Ct)
    (hcp0 : 0 < cp) (hBpilot : 0 ≤ Bpilot) (hM : 0 ≤ M)
    (hdegreeH : (d : ℝ) ≤ M * (n * b)) (hcp : 4 * M ≤ cp)
    (Counts : iota → Omega → ℕ) (lam : iota → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (Counts i) mu (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (Counts i) (Counts j) mu))
    (Pilot : iota → Xi → ℕ)
    (hPilot : ∀ i, MeasurePreserving (Pilot i) nu
      (poissonMeasure ⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩)) :
    let order : ℝ := (m : ℝ) + gamma
    let r := m + 1
    let Q := completedCoupledPolynomial ell N m gamma aCut b cProfile fL f A B omega
    let K := completedLeadingCoefficientConstant * max 1 Cscale
    let tiny := 2 * K ^ 2 * Real.exp 2 * (2 * (r : ℝ)) ^ r +
      2 * ((r + 1 : ℕ) : ℝ) ^ (r + 1)
    let medium := ((d : ℝ) + 1) ^ 2 * (coupledCoefficientBudget ell N gamma aCut b A B omega) ^ 2 *
      Real.exp (cp * Bpilot * order + M * d)
    pilotAveragedCountVariance Counts Pilot (cp * Bpilot * order) d
      (highCountCoefficients r Q.coeff) n mu nu ≤
        n ^ (-2 * order) * (tiny * (∑ i, (lam i : ℝ) ^ order) +
          medium * (n * b) ^ order *
            ∑ i, if Real.exp (-Ct * L) < (lam i : ℝ) then (lam i : ℝ) ^ order else 0) := by
  let order : ℝ := (m : ℝ) + gamma
  let r := m + 1
  let Q := completedCoupledPolynomial ell N m gamma aCut b cProfile fL f A B omega
  let c : ℕ → ℝ := fun j => n ^ (order - j) * Q.coeff j
  let K := completedLeadingCoefficientConstant * max 1 Cscale
  let tiny := 2 * K ^ 2 * Real.exp 2 * (2 * (r : ℝ)) ^ r + 2 * ((r + 1 : ℕ) : ℝ) ^ (r + 1)
  let medium := ((d : ℝ) + 1) ^ 2 * (coupledCoefficientBudget ell N gamma aCut b A B omega) ^ 2 *
    Real.exp (cp * Bpilot * order + M * d)
  have hLpos : 0 < L := lt_of_lt_of_le (by norm_num) hL
  have hbudget := coupledCoefficientBudget_exponential hgamma.le haCut.le hab hb hA hA1 hB hB1 hw hw1.le hL hellL hNL
  have hCb := coupledCoefficientExponentialConstant_pos.le
  have hscalar (i : iota) :
      poissonLowerMass ⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩ (cp * Bpilot * order) *
        variance (factorialStatistic d (highCountCoefficients r c)) (poissonMeasure (lam i)) ≤
          tiny * (lam i : ℝ) ^ order +
            if Real.exp (-Ct * L) < (lam i : ℝ) then medium * (n * b) ^ order * (lam i : ℝ) ^ order else 0 :=
    completed_high_count_variance hell hN hm hdegree hgamma hgamma1 haCut hab hb hn hcProfile hfL hfL1 hf hf1
      hA hA1 hB hB1 hw hw1 hlocal hLpos hscale hcountScale hH hrd hCb hCd hdegreeL hCt hCt2
        hbudget hcp0 hBpilot hM hdegreeH hcp (lam i)
  dsimp only
  rw [pilot_averaged_count_variance Counts lam hLaw hpair Pilot
    (fun i => (⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩ : ℝ≥0)) hPilot]
  have hterm (i : iota) :
      poissonLowerMass ⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩ (cp * Bpilot * order) *
        variance (factorialStatistic d (fun j => highCountCoefficients r Q.coeff j / n ^ j)) (poissonMeasure (lam i)) ≤
      n ^ (-2 * order) * (tiny * (lam i : ℝ) ^ order +
        medium * (n * b) ^ order * (if Real.exp (-Ct * L) < (lam i : ℝ) then (lam i : ℝ) ^ order else 0)) := by
    rw [high_count_variance_scaling (lam i) hn]
    have h := mul_le_mul_of_nonneg_left (hscalar i) (Real.rpow_nonneg hn.le (-2 * order))
    convert h using 1
    · ring
    · split_ifs <;> ring
  have hsum := Finset.sum_le_sum (s := Finset.univ) (fun i _ => hterm i)
  convert hsum using 1
  simp only [mul_add, Finset.sum_add_distrib, ← Finset.mul_sum]
  dsimp [order, r, K, tiny, medium]
  ring_nf

end Renyi
