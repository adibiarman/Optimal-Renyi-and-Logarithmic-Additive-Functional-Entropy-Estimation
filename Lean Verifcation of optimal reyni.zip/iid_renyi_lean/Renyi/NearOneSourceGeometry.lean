import Renyi.NearOneLogDecay

/-! Uniform elementary geometry for the actual near-one variance budget. -/
noncomputable section
namespace Renyi
set_option maxHeartbeats 700000

theorem near_one_source_geometry {eps CL D : ℝ}
    (heps : 0<eps) (hCL : 1≤CL) (hD : 0<D) :
    ∃ G : ℝ, 1≤G ∧ ∃ k0 : ℕ, ∀ cL : ℝ, 0<cL → cL≤1 → ∀ k : ℕ, k0≤k →
      ∀ alpha : ℝ, 1<alpha → alpha≤3/2 →
      let n := upperSample k alpha eps D
      let LN := upperDegree alpha CL cL (rootMultiplier k alpha eps)
      let L : ℝ := LN
      let b := upperB k alpha eps D 1 CL cL
      let t := b/L^2
      let W := nearOneLogWeight k
      0<k ∧ 1≤n ∧ 1≤L ∧ (k:ℝ)/n≤G*W^2 ∧ (k:ℝ)*b≤G*W^2 ∧
        20*L+1≤G*W^2 ∧ 1+|Real.log (n*t)|≤G*W^2 ∧ |Real.log (1/t)|≤G*W^2 := by
  let a := nearOneQConstant eps*D/Real.exp 1
  let Cdeg := (3/2:ℝ)*(CL+1+Real.log 3)
  let Cn := (9/2:ℝ)*D
  have ha : 0<a := by dsimp [a]; exact div_pos (mul_pos (nearOneQConstant_pos eps) hD) (Real.exp_pos _)
  have hlog3 : 0≤Real.log 3 := Real.log_nonneg (by norm_num)
  have hCdeg : 3/2≤Cdeg := by dsimp [Cdeg];linarith only [hCL,hlog3]
  have hCdeg0 : 0<Cdeg := by linarith only [hCdeg]
  have hCn : 0<Cn := by dsimp [Cn];positivity
  let G := 3+1/a+Cdeg/a+22*Cdeg+|Real.log Cn|
  have hG : 1≤G := by dsimp [G];nlinarith only [hCdeg0,abs_nonneg (Real.log Cn),div_pos (by norm_num : (0:ℝ)<1) ha,div_pos hCdeg0 ha]
  have hGa : 1/a≤G := by dsimp [G];nlinarith only [hCdeg0,abs_nonneg (Real.log Cn),div_pos (by norm_num : (0:ℝ)<1) ha,div_pos hCdeg0 ha]
  have hGd : Cdeg/a≤G := by dsimp [G];nlinarith only [hCdeg0,abs_nonneg (Real.log Cn),div_pos (by norm_num : (0:ℝ)<1) ha,div_pos hCdeg0 ha]
  have hG20 : 20*Cdeg+1≤G := by dsimp [G];nlinarith only [hCdeg0,abs_nonneg (Real.log Cn),div_pos (by norm_num : (0:ℝ)<1) ha,div_pos hCdeg0 ha]
  have hGlog : |Real.log Cn|+1+Cdeg≤G := by dsimp [G];nlinarith only [hCdeg0,div_pos (by norm_num : (0:ℝ)<1) ha,div_pos hCdeg0 ha]
  have hGcut : 1+Cdeg≤G := (by linarith only [abs_nonneg (Real.log Cn)] : 1+Cdeg≤|Real.log Cn|+1+Cdeg).trans hGlog
  obtain ⟨K,hdecay⟩ := near_one_log_power_decay 1 (C:=1/a) (r:=1) (eta:=1) (by positivity) (by norm_num) (by norm_num)
  refine ⟨G,hG,max 1 K,?_⟩
  intro cL hcL hcL1 k hk alpha halpha halpha1
  have hk1 : 1≤k := (le_max_left _ _).trans hk
  have hk0 : 0<k := by omega
  have hkR : (0:ℝ)<k := by exact_mod_cast hk0
  have hkR1 : (1:ℝ)≤k := by exact_mod_cast hk1
  have hlogk : 0≤Real.log k := Real.log_nonneg hkR1
  let n := upperSample k alpha eps D
  let L : ℝ := upperDegree alpha CL cL (rootMultiplier k alpha eps)
  let b := upperB k alpha eps D 1 CL cL
  let t := b/L^2
  let W := nearOneLogWeight k
  have hW1 : 1≤W := by dsimp [W,nearOneLogWeight];linarith only [hlog3,hlogk]
  have hW : 0<W := zero_lt_one.trans_le hW1
  have hW2 : W≤W^2 := by nlinarith only [hW1]
  have hlogkW : Real.log k≤W := by dsimp [W,nearOneLogWeight];linarith only [hlog3]
  have hbeta : 0<alpha-1 := sub_pos.mpr halpha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order halpha halpha1).2];exact hbeta
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order halpha halpha1).2];linarith only [halpha1]
  have hn : 0<n := upperSample_pos hk0 halpha hg hg1 hD
  have hLge : alpha*CL≤L := (upperDegree_bounds halpha hCL hcL (one_le_rootMultiplier (k:=k) (ε:=eps) halpha hg hg1)).1
  have hL1 : 1≤L := by nlinarith only [hLge,halpha,hCL]
  have hL : 0<L := zero_lt_one.trans_le hL1
  have hLbound : L≤Cdeg*W := by
    have hh := near_one_degree_log_bound hk0 halpha halpha1 heps hCL hcL
    have h3 := mul_le_mul_of_nonneg_right hcL1 hlog3
    have hkk := mul_le_mul_of_nonneg_right hcL1 hlogk
    have hcross := mul_le_mul_of_nonneg_right (show 3/2≤Cdeg from hCdeg) hlogk
    have hcross3 := mul_nonneg hCdeg0.le hlog3
    dsimp [Cdeg,W,nearOneLogWeight] at ⊢
    dsimp [L] at ⊢
    dsimp [Cdeg] at hcross hcross3
    nlinarith only [hh,h3,hkk,hcross,hcross3]
  have hnlow : a*k/W≤n := by
    have hh := near_one_sample_lower hk0 halpha halpha1 heps hD
    convert hh using 1
    dsimp [a,W,nearOneLogWeight]
    field_simp
  have hdec := hdecay k ((le_max_right _ _).trans hk)
  simp only [pow_one,Real.rpow_one] at hdec
  have hwa : W≤a*k := by
    have hh := (div_le_iff₀ hkR).mp hdec
    have hh' : W/a≤(k:ℝ) := by simpa only [one_mul,mul_one,one_div,div_eq_mul_inv,mul_comm] using hh
    have hh'' := (div_le_iff₀ ha).mp hh'
    nlinarith only [hh'']
  have hn1 : 1≤n := ((one_le_div hW).mpr hwa).trans hnlow
  have hkn : (k:ℝ)/n≤W/a := by
    apply (div_le_div_iff₀ hn ha).mpr
    have hh := (div_le_iff₀ hW).mp hnlow
    nlinarith only [hh]
  have hnb : n*b=L := by change n*(1*L/n)=L;field_simp
  have hb : b=L/n := by change 1*L/n=L/n;ring
  have hkb : (k:ℝ)*b≤(Cdeg/a)*W^2 := by
    rw [hb]
    have hh := mul_le_mul hkn hLbound hL.le (div_nonneg hW.le ha.le)
    convert hh using 1 <;> ring
  have hnt : n*t=1/L := by dsimp [t];rw [←mul_div_assoc,hnb];field_simp
  have hti : 1/t=n*L := by dsimp [t];rw [hb];field_simp
  have hlogL0 : 0≤Real.log L := Real.log_nonneg hL1
  have hlogL : Real.log L≤L := (Real.log_le_sub_one_of_pos hL).trans (by linarith)
  have hlognt : |Real.log (n*t)|=Real.log L := by
    rw [hnt,one_div,Real.log_inv,abs_neg,abs_of_nonneg hlogL0]
  have hntbound : 1+|Real.log (n*t)|≤(1+Cdeg)*W := by rw [hlognt];nlinarith only [hlogL,hLbound,hW1]
  have hnupper : n≤Cn*k := near_one_sample_upper hk0 halpha halpha1 heps hD
  have hlogn : Real.log n≤|Real.log Cn|+Real.log k := by
    have hh := Real.log_le_log hn hnupper
    rw [Real.log_mul hCn.ne' hkR.ne'] at hh
    exact hh.trans (add_le_add_right (le_abs_self _) _)
  have hlogn0 : 0≤Real.log n := Real.log_nonneg hn1
  have htlog : |Real.log (1/t)|≤(|Real.log Cn|+1+Cdeg)*W := by
    rw [hti,Real.log_mul hn.ne' hL.ne',abs_of_nonneg (add_nonneg hlogn0 hlogL0)]
    have hconst := mul_le_mul_of_nonneg_left hW1 (abs_nonneg (Real.log Cn))
    nlinarith only [hlogn,hlogL,hLbound,hlogkW,hconst]
  refine ⟨hk0,hn1,hL1,?_,?_,?_,?_,?_⟩
  · exact hkn.trans (by
      have hh := mul_le_mul_of_nonneg_right hGa hW.le
      have hh' := mul_le_mul_of_nonneg_left hW2 (show 0≤G by linarith only [hG])
      calc
        W/a=(1/a)*W := by ring
        _≤G*W := hh
        _≤G*W^2 := hh')
  · exact hkb.trans (mul_le_mul_of_nonneg_right hGd (sq_nonneg W))
  · have hh : 20*L+1≤(20*Cdeg+1)*W := by nlinarith only [hLbound,hW1]
    exact hh.trans ((mul_le_mul_of_nonneg_right hG20 hW.le).trans (mul_le_mul_of_nonneg_left hW2 (by linarith only [hG] : 0≤G)))
  · exact hntbound.trans ((mul_le_mul_of_nonneg_right hGcut hW.le).trans (mul_le_mul_of_nonneg_left hW2 (by linarith only [hG] : 0≤G)))
  · exact htlog.trans ((mul_le_mul_of_nonneg_right hGlog hW.le).trans (mul_le_mul_of_nonneg_left hW2 (by linarith only [hG] : 0≤G)))

end Renyi
