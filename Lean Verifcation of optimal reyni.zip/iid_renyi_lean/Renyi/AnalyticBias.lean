import Renyi.AnalyticMean

noncomputable section
open scoped NNReal
open MeasureTheory ProbabilityTheory Set
namespace Renyi

/-- Euler reflection gives the exact size of the reciprocal-Gamma coefficient. -/
theorem gamma_inv_reflection_abs (a : ℝ) (ha : 0 < a) :
    |(Real.Gamma (-a))⁻¹| =
      Real.Gamma (a + 1) * |Real.sin (Real.pi * a)| / Real.pi := by
  have hG : 0 < Real.Gamma (a + 1) := Real.Gamma_pos_of_pos (by linarith)
  have hr := congrArg (fun x : ℝ => x⁻¹) (Real.Gamma_mul_Gamma_one_sub (-a))
  dsimp only at hr
  rw [sub_neg_eq_add, show 1 + a = a + 1 by ring, mul_inv, inv_div,
    mul_neg, Real.sin_neg] at hr
  have hid : (Real.Gamma (-a))⁻¹ =
      -(Real.Gamma (a + 1) * Real.sin (Real.pi * a) / Real.pi) := by
    calc
      _ = ((Real.Gamma (-a))⁻¹ * (Real.Gamma (a + 1))⁻¹) * Real.Gamma (a + 1) := by
        field_simp
      _ = _ := by rw [hr]; ring
  rw [hid, abs_neg, abs_div, abs_mul, abs_of_pos hG, abs_of_pos Real.pi_pos]

/-- The tail integral is nonnegative. -/
theorem gammaTail_nonneg (a lam : ℝ) : 0 ≤ gammaTail a lam := by
  apply setIntegral_nonneg measurableSet_Ioi
  intro t ht
  exact mul_nonneg (Real.exp_pos _).le (Real.rpow_nonneg (le_of_lt (lt_trans zero_lt_one ht)) _)

/-- Bounding only the exponential factor gives the order-dependent tail bound. -/
theorem gammaTail_le_order (a : ℝ) (ha : 0 < a) {lam : ℝ} (hlam : 0 < lam) :
    gammaTail a lam ≤ Real.exp (-lam) / a := by
  have hp : -a - 1 < -1 := by linarith
  have hpow := integrableOn_Ioi_rpow_of_lt hp (by norm_num : (0 : ℝ) < 1)
  have h := setIntegral_mono_on (gammaTail_integrable a hlam)
    (hpow.const_mul (Real.exp (-lam))) measurableSet_Ioi (fun t ht => ?_)
  · simp only [integral_const_mul] at h
    rw [integral_Ioi_rpow_of_lt hp (by norm_num : (0 : ℝ) < 1)] at h
    simpa [Real.one_rpow, div_eq_mul_inv] using h
  · unfold gammaTailIntegrand
    apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg (le_of_lt (lt_trans zero_lt_one ht)) _)
    apply Real.exp_le_exp.mpr
    have hmul := mul_le_mul_of_nonneg_left (show (1 : ℝ) ≤ t from le_of_lt ht) hlam.le
    linarith

/-- Bounding only the power factor gives the intensity-dependent tail bound. -/
theorem gammaTail_le_intensity (a : ℝ) (ha : 0 < a) {lam : ℝ} (hlam : 0 < lam) :
    gammaTail a lam ≤ Real.exp (-lam) / lam := by
  have hexp := integrableOn_exp_mul_Ioi (neg_neg_of_pos hlam) (1 : ℝ)
  have h := setIntegral_mono_on (gammaTail_integrable a hlam) hexp measurableSet_Ioi
    (fun t ht => ?_)
  · rw [integral_exp_mul_Ioi (neg_neg_of_pos hlam) 1] at h
    simpa using h
  · unfold gammaTailIntegrand
    have hp : t ^ (-a - 1) ≤ 1 := Real.rpow_le_one_of_one_le_of_nonpos ht.le (by linarith)
    exact (mul_le_mul_of_nonneg_left hp (Real.exp_pos _).le).trans_eq (mul_one _)

/-- The two complementary integral bounds are valid simultaneously. -/
theorem gammaTail_le_min (a : ℝ) (ha : 0 < a) {lam : ℝ} (hlam : 0 < lam) :
    gammaTail a lam ≤ Real.exp (-lam) * min a⁻¹ lam⁻¹ := by
  rw [mul_min_of_nonneg _ _ (Real.exp_pos _).le]
  exact le_min (by simpa [div_eq_mul_inv] using gammaTail_le_order a ha hlam)
    (by simpa [div_eq_mul_inv] using gammaTail_le_intensity a ha hlam)

/-- The manuscript's reflection-factor bias bound, for the actual Poisson expectation. -/
theorem analyticMean_bias_bound (lam : ℝ≥0) (hlam : 0 < (lam : ℝ))
    (a : ℝ) (ha : 0 < a) :
    |analyticMean lam a - (lam : ℝ) ^ a| ≤
      Real.Gamma (a + 1) * |Real.sin (Real.pi * a)| / Real.pi *
        Real.exp (-(lam : ℝ)) * min a⁻¹ (lam : ℝ)⁻¹ := by
  rw [analyticMean_exact lam hlam, sub_sub_cancel_left, abs_neg, abs_mul,
    abs_of_nonneg (gammaTail_nonneg a lam)]
  have h := mul_le_mul_of_nonneg_left (gammaTail_le_min a ha hlam)
    (abs_nonneg ((Real.Gamma (-a))⁻¹))
  rw [gamma_inv_reflection_abs a ha] at h ⊢
  convert h using 1
  ring

end Renyi
