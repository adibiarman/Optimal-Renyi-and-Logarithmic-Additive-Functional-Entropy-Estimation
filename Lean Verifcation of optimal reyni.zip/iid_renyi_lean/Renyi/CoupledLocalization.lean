import Renyi.CoupledProfileBounds

/-! Spatial localization of the actual high coupled profile. -/
noncomputable section
open Set
namespace Renyi

def coupledLocalizationConstant : ℝ := Real.exp (Real.log 24+2)

lemma coupledLocalizationConstant_ge_three : 3 ≤ coupledLocalizationConstant := by
  have he := Real.exp_le_exp.mpr (by linarith : Real.log 24 ≤ Real.log 24+2)
  rw [Real.exp_log (by norm_num : (0:ℝ)<24)] at he
  exact (by norm_num : (3:ℝ)≤24).trans he

lemma fractional_sharp_factor_uniform {s : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) :
    Real.exp ((Real.log 24+1)*s)/s^s ≤ coupledLocalizationConstant := by
  have hlog := Real.one_sub_inv_le_log_of_pos hs
  have hmul := mul_le_mul_of_nonneg_left hlog hs.le
  have heq : s*(1-s⁻¹)=s-1 := by field_simp
  rw [heq] at hmul
  have hc : 0 ≤ Real.log 24+1 := by have := Real.log_nonneg (by norm_num : (1:ℝ)≤24); linarith
  rw [Real.rpow_def_of_pos hs, ←Real.exp_sub]
  apply Real.exp_le_exp.mpr
  nlinarith [mul_nonneg hc (sub_nonneg.mpr hs1)]

lemma coupled_unweighted_bump_upper {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s b x : ℝ} {H : ℝ → ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hb : b < 1)
    (hH : ∀ x ∈ Icc (0:ℝ) 1, 0 ≤ H x ∧ H x ≤ b) (hx : 0 ≤ x) :
    x^s/coupledNormalizer s (endpointKernel N d) H ≤
      coupledLocalizationConstant*((N:ℝ)^2*x)^s := by
  have hK := fun y (hy : y ∈ Icc (0:ℝ) 1) =>
    And.intro (endpointKernel_nonneg N d y) (endpointKernel_le_one hN d hy.1 hy.2)
  have ha := coupledNormalizer_pos hs.le hb hK (fun y hy => (hH y hy).2)
    (endpointKernel_positive_witness hN hd)
  have hl := coupledNormalizer_sharp_lower hN hd hs hs1 hb hH
  have hsharp : x^s/coupledNormalizer s (endpointKernel N d) H ≤
      Real.exp ((Real.log 24+1)*s)*((N:ℝ)^2*x/s)^s := by
    apply (div_le_iff₀ ha).mpr
    have hm := mul_le_mul_of_nonneg_left hl
      (show 0 ≤ Real.exp ((Real.log 24+1)*s)*((N:ℝ)^2*x/s)^s by positivity)
    rw [coupled_sharp_scale_identity hN hs hx] at hm
    exact hm
  have hfactor := fractional_sharp_factor_uniform hs hs1
  have hm := mul_le_mul_of_nonneg_right hfactor (Real.rpow_nonneg (by positivity : 0≤(N:ℝ)^2*x) s)
  apply hsharp.trans
  rw [Real.div_rpow (by positivity : 0≤(N:ℝ)^2*x) hs.le]
  convert hm using 1; ring

lemma high_bump_upper {N : ℕ} (hN : 0 < N) {s f ω x : ℝ}
    (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hω : 0 ≤ ω) (hω1 : ω < 1) (hx : 0 ≤ x) :
    x^s*endpointKernel N 6 x / highNormalizer N s f ω ≤
      coupledLocalizationConstant*((N:ℝ)^2*x)^s*endpointKernel N 6 x := by
  have h := coupled_unweighted_bump_upper hN (by norm_num : 6≤6) hs hs1 hω1
    (fun _y hy => highShoulder_range hN hs hf hf1 hω hy.1 hy.2) hx
  have hm := mul_le_mul_of_nonneg_right h (endpointKernel_nonneg N 6 x)
  change x^s/coupledNormalizer s (endpointKernel N 6) (highShoulder N s f ω)*endpointKernel N 6 x ≤ _ at hm
  unfold highNormalizer
  convert hm using 1; ring

lemma endpointKernel_six_eq_square_three (N : ℕ) (x : ℝ) :
    endpointKernel N 6 x = (endpointKernel N 3 x)^2 := by
  unfold endpointKernel
  ring

lemma highShoulder_le_amplitude_integral {N : ℕ} (hN : 0 < N) {s f ω x : ℝ}
    (hs : 0 < s) (hf : 0 ≤ f) (hf1 : f ≤ 1) (hω : 0 ≤ ω)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    highShoulder N s f ω x ≤ ω*endpointProfile N 6 s x := by
  have hj := (endpointProfile_range hN (by norm_num : 6≤6) hs hx hx1).1
  have hk0 := endpointKernel_nonneg N 6 x
  have hk1 := endpointKernel_le_one hN 6 hx hx1
  have hw := highShoulderWeight_range hN hf hf1 hx hx1
  unfold highShoulder
  calc
    _ ≤ ω*endpointProfile N 6 s x*(1-endpointKernel N 6 x) :=
      mul_le_of_le_one_right (mul_nonneg (mul_nonneg hω hj) (sub_nonneg.mpr hk1)) hw.2
    _ ≤ _ := mul_le_of_le_one_right (mul_nonneg hω hj) (by linarith)

/-- The shoulder approaches omega J at cubic scaled-tail speed. -/
lemma highShoulder_deficit_le_three_kernel {N : ℕ} (hN : 0 < N) {s f ω x : ℝ}
    (hs : 0 < s) (hf : 0 ≤ f) (hf1 : f ≤ 1) (hω : 0 ≤ ω) (hω1 : ω ≤ 1)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    ω*endpointProfile N 6 s x-highShoulder N s f ω x ≤ 3*endpointKernel N 3 x := by
  have hj := endpointProfile_range hN (by norm_num : 6≤6) hs hx hx1
  have hr0 := endpointKernel_nonneg N 3 x
  have hr1 := endpointKernel_le_one hN 3 hx hx1
  have hk0 := endpointKernel_nonneg N 6 x
  have hk1 := endpointKernel_le_one hN 6 hx hx1
  have hw := highShoulderWeight_range hN hf hf1 hx hx1
  have hkernel := endpointKernel_six_eq_square_three N x
  have hgap : 1-(1-endpointKernel N 6 x)*highShoulderWeight N f x ≤ 3*endpointKernel N 3 x := by
    have hweight : 1-highShoulderWeight N f x ≤ 2*endpointKernel N 3 x := by
      unfold highShoulderWeight
      nlinarith [mul_nonneg (sub_nonneg.mpr hf1) (sq_nonneg (endpointKernel N 3 x))]
    nlinarith [mul_nonneg hk0 (sub_nonneg.mpr hw.2),
      mul_nonneg hr0 (sub_nonneg.mpr hr1)]
  have hgap0 : 0 ≤ 1-(1-endpointKernel N 6 x)*highShoulderWeight N f x := by
    have hh := (mul_le_of_le_one_right (sub_nonneg.mpr hk1) hw.2).trans
      (show 1-endpointKernel N 6 x≤1 by linarith)
    linarith
  have hωJ : ω*endpointProfile N 6 s x ≤ 1 :=
    (mul_le_of_le_one_right hω hj.2).trans hω1
  have hh := (mul_le_of_le_one_left hgap0 hωJ).trans hgap
  unfold highShoulder
  nlinarith

lemma endpointProfile_uniform_power_upper {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s x : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    endpointProfile N d s x ≤ coupledLocalizationConstant*((N:ℝ)^2*x)^s := by
  have hc : 0 ≤ Real.log 12+1 := by have := Real.log_nonneg (by norm_num : (1:ℝ)≤12); linarith
  have hl : Real.log 12 ≤ Real.log 24 := Real.log_le_log (by norm_num) (by norm_num)
  have he : Real.exp ((Real.log 12+1)*s) ≤ coupledLocalizationConstant := by
    apply Real.exp_le_exp.mpr
    nlinarith [mul_nonneg hc (sub_nonneg.mpr hs1)]
  exact (endpointProfile_upper_power hN hd hs hx hx1).trans
    (mul_le_mul_of_nonneg_right he (Real.rpow_nonneg (by positivity) s))

/-- The actual profile differs from its limiting integral by at most C y^s. -/
theorem highProfile_localization_power {N : ℕ} (hN : 0 < N) {s f ω x : ℝ}
    (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hω : 0 ≤ ω) (hω1 : ω < 1) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    |highProfile N s f ω x - ω*endpointProfile N 6 s x| ≤
      coupledLocalizationConstant*((N:ℝ)^2*x)^s := by
  have ha := highNormalizer_pos hN hs hf hf1 hω hω1
  have hbase0 : 0 ≤ x^s*endpointKernel N 6 x/highNormalizer N s f ω :=
    div_nonneg (mul_nonneg (Real.rpow_nonneg hx s) (endpointKernel_nonneg N 6 x)) ha.le
  have hbase := (high_bump_upper hN hs hs1 hf hf1 hω hω1 hx).trans
    (mul_le_of_le_one_right (show 0 ≤ coupledLocalizationConstant*((N:ℝ)^2*x)^s by
      unfold coupledLocalizationConstant; positivity) (endpointKernel_le_one hN 6 hx hx1))
  have hH0 := (highShoulder_range hN hs hf hf1 hω hx hx1).1
  have hH := highShoulder_le_amplitude_integral hN hs hf hf1 hω hx hx1
  have hJ0 := (endpointProfile_range hN (by norm_num : 6≤6) hs hx hx1).1
  have hJ := (mul_le_of_le_one_left hJ0 hω1.le).trans
    (endpointProfile_uniform_power_upper hN (by norm_num) hs hs1 hx hx1)
  change |x^s*endpointKernel N 6 x/highNormalizer N s f ω + highShoulder N s f ω x -
    ω*endpointProfile N 6 s x| ≤ _
  exact abs_le.mpr ⟨by linarith, by linarith⟩

/-- The actual profile has cubic localization in the scaled outer region. -/
theorem highProfile_localization_tail {N : ℕ} (hN : 0 < N) {s f ω x : ℝ}
    (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hω : 0 ≤ ω) (hω1 : ω < 1) (hx : 0 ≤ x) (hx1 : x ≤ 1)
    (hy1 : 1 ≤ (N:ℝ)^2*x) :
    |highProfile N s f ω x - ω*endpointProfile N 6 s x| ≤
      coupledLocalizationConstant*((N:ℝ)^2*x)^(-3:ℝ) := by
  let y : ℝ := (N:ℝ)^2*x
  have hy : 0 < y := by dsimp [y]; linarith
  have hxp : 0 < x := by
    rcases hx.eq_or_lt with rfl | hx
    · norm_num at hy1
    · exact hx
  have hC : 0 ≤ coupledLocalizationConstant := (by norm_num : (0:ℝ)≤3).trans coupledLocalizationConstant_ge_three
  have hk := endpointKernel_le_inverse_power hN 6 hxp hx1
  have hr := endpointKernel_le_inverse_power hN 3 hxp hx1
  have hkinv : endpointKernel N 6 x ≤ y^(-6:ℝ) := by
    change endpointKernel N 6 x ≤ (y⁻¹)^6 at hk
    simpa only [Real.rpow_neg hy.le, Real.rpow_natCast, Real.rpow_ofNat, inv_pow] using hk
  have hrinv : endpointKernel N 3 x ≤ y^(-3:ℝ) := by
    change endpointKernel N 3 x ≤ (y⁻¹)^3 at hr
    simpa only [Real.rpow_neg hy.le, Real.rpow_natCast, Real.rpow_ofNat, inv_pow] using hr
  have hys : y^s*y^(-6:ℝ) ≤ y^(-3:ℝ) := by
    rw [←Real.rpow_add hy]
    exact Real.rpow_le_rpow_of_exponent_le hy1 (by linarith)
  have hbase := high_bump_upper hN hs hs1 hf hf1 hω hω1 hx
  have hbase' : x^s*endpointKernel N 6 x/highNormalizer N s f ω ≤ coupledLocalizationConstant*y^(-3:ℝ) := by
    apply hbase.trans
    calc
      _ ≤ coupledLocalizationConstant*y^s*y^(-6:ℝ) :=
        mul_le_mul_of_nonneg_left hkinv (mul_nonneg hC (Real.rpow_nonneg hy.le s))
      _ ≤ _ := by convert mul_le_mul_of_nonneg_left hys hC using 1; ring
  have hgap := (highShoulder_deficit_le_three_kernel hN hs hf hf1 hω hω1.le hx hx1).trans
    (mul_le_mul_of_nonneg_left hrinv (by norm_num : (0:ℝ)≤3))
  have hgap' := hgap.trans (mul_le_mul_of_nonneg_right coupledLocalizationConstant_ge_three (Real.rpow_nonneg hy.le (-3)))
  have hH := highShoulder_le_amplitude_integral hN hs hf hf1 hω hx hx1
  have ha := highNormalizer_pos hN hs hf hf1 hω hω1
  have hbase0 : 0 ≤ x^s*endpointKernel N 6 x/highNormalizer N s f ω :=
    div_nonneg (mul_nonneg (Real.rpow_nonneg hx s) (endpointKernel_nonneg N 6 x)) ha.le
  change |x^s*endpointKernel N 6 x/highNormalizer N s f ω + highShoulder N s f ω x -
    ω*endpointProfile N 6 s x| ≤ _
  exact abs_le.mpr ⟨by linarith, by linarith⟩

/-- The full source localization estimate, for the actual high profile. -/
theorem highProfile_localization {N : ℕ} (hN : 0 < N) {s f ω x : ℝ}
    (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hω : 0 ≤ ω) (hω1 : ω < 1) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    |highProfile N s f ω x - ω*endpointProfile N 6 s x| ≤
      coupledLocalizationConstant*min (((N:ℝ)^2*x)^s) (((N:ℝ)^2*x)^(-3:ℝ)) := by
  rcases hx.eq_or_lt with rfl | hx
  · norm_num [highProfile_zero N hs, Real.zero_rpow hs.ne']
  have hy : 0 < (N:ℝ)^2*x := by positivity
  by_cases hy1 : (N:ℝ)^2*x ≤ 1
  · rw [min_eq_left (Real.rpow_le_rpow_of_exponent_ge hy hy1 (by linarith : (-3:ℝ)≤s))]
    exact highProfile_localization_power hN hs hs1 hf hf1 hω hω1 hx.le hx1
  · have hy1' : 1 ≤ (N:ℝ)^2*x := le_of_not_ge hy1
    rw [min_eq_right (Real.rpow_le_rpow_of_exponent_le hy1' (by linarith : (-3:ℝ)≤s))]
    exact highProfile_localization_tail hN hs hs1 hf hf1 hω hω1 hx.le hx1 hy1'

end Renyi
