import Renyi.UpperRescaling

/-! Reserved root width pays the actual polynomial damping and scalar rescaling. -/
noncomputable section
namespace Renyi
set_option maxHeartbeats 500000

theorem upperU_order_gap_bound {k : ℕ} {alpha eps u0 : ℝ}
    (ha : 1<alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1) :
    upperU k alpha eps u0≤2*(alpha-1) := by
  have hb : 0<alpha-1 := sub_pos.mpr ha
  have hx := one_le_rootMultiplier (k:=k) (ε:=eps) ha hg hg1
  have hpow : rootMultiplier k alpha eps^(-alpha)≤1 :=
    Real.rpow_le_one_of_one_le_of_nonpos hx (by linarith only [ha])
  have hdiv : (alpha-1)/alpha≤alpha-1 := by
    apply (div_le_iff₀ (by linarith only [ha] : 0<alpha)).mpr
    nlinarith only [sq_nonneg (alpha-1)]
  have hv : upperV k alpha eps≤alpha-1 :=
    (mul_le_of_le_one_right (div_nonneg hb.le (by linarith only [ha] : 0≤alpha)) hpow).trans hdiv
  have hh : fractionalPart alpha*(1-fractionalPart alpha)≤alpha-1 := by
    have h1 := mul_le_of_le_one_right hg.le (show 1-fractionalPart alpha≤1 by linarith only [hg])
    exact h1.trans (fractionalPart_le_order_gap ha)
  exact (min_le_left (upperV k alpha eps+fractionalPart alpha*(1-fractionalPart alpha)) u0).trans (by linarith only [hv,hh])

/-- Outside the compact-width case the remaining root reserve is uniformly
linear in u, even after the full spatial damping cost. -/
theorem upper_delta_after_damping {k : ℕ} {alpha eps Ch C u0 : ℝ}
    (ha : 1<alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (heps : 0<eps) (hC : 0≤C) (hCh : 2*C+2≤Ch) (hu0 : 0<u0)
    (hlarge : 4*C*(fractionalPart alpha*(1-fractionalPart alpha))≤2*eps*(alpha-1)) :
    min 1 (eps/4)*upperU k alpha eps u0≤
      upperDelta k alpha eps Ch-C*(fractionalPart alpha*(1-fractionalPart alpha)) := by
  let u := upperU k alpha eps u0
  let h := fractionalPart alpha*(1-fractionalPart alpha)
  let a := min 1 (eps/4)
  have hu : 0≤u := (upperU_pos (k:=k) (eps:=eps) ha hg hg1 hu0).le
  have hh : 0≤h := mul_nonneg hg.le (sub_nonneg.mpr hg1.le)
  have hv : 0≤upperV k alpha eps := (upperV_pos (k:=k) (eps:=eps) ha hg hg1).le
  have huv : u≤upperV k alpha eps+h := min_le_left _ _
  have hub : u≤2*(alpha-1) := upperU_order_gap_bound ha hg hg1
  have ha1 : a≤1 := min_le_left _ _
  have hae : a≤eps/4 := min_le_right _ _
  have hfirst : a*u+C*h≤upperV k alpha eps+Ch*h := by
    have hmul := mul_le_mul_of_nonneg_right ha1 hu
    have hChh := mul_le_mul_of_nonneg_right hCh hh
    nlinarith only [hmul,huv,hChh,hC,hh]
  have hsecond : a*u+C*h≤eps*(alpha-1) := by
    have hmul := mul_le_mul_of_nonneg_right hae hu
    have hmul' := mul_le_mul_of_nonneg_left hub (show 0≤eps/4 by positivity)
    nlinarith only [hmul,hmul',hlarge]
  have hhmin := le_min hfirst hsecond
  change a*u≤min (upperV k alpha eps+Ch*h) (eps*(alpha-1))-C*h
  linarith only [hhmin]

lemma rescaled_exp_margin {u u0 a cu g : ℝ}
    (hu : 0≤u) (hu0 : u≤u0) (ha : 0<a) (hcu : 0≤cu) (hcua : cu≤a/2)
    (hgap : a*u≤g) :
    1+(a/(2*(1+cu*u0)))*u≤(1+cu*u)⁻¹*Real.exp g := by
  have hden : 0<1+cu*u := by positivity
  have hu00 : 0≤u0 := hu.trans hu0
  have hden0 : 0<1+cu*u0 := by positivity
  have hdenle : 1+cu*u≤1+cu*u0 := add_le_add_left (mul_le_mul_of_nonneg_left hu0 hcu) 1
  let q := a/(2*(1+cu*u0))
  have hq : 0≤q := by dsimp [q];positivity
  have hqden : q*(1+cu*u)≤a/2 := by
    have hh := mul_le_mul_of_nonneg_left hdenle hq
    have hid : q*(1+cu*u0)=a/2 := by dsimp [q];field_simp
    exact hh.trans_eq hid
  have hqdenU := mul_le_mul_of_nonneg_right hqden hu
  have hcuU := mul_le_mul_of_nonneg_right hcua hu
  have hex : 1+a*u≤Real.exp g := (add_le_add_left hgap 1).trans (by simpa only [add_comm] using Real.add_one_le_exp g)
  rw [inv_mul_eq_div]
  apply (le_div_iff₀ hden).mpr
  change (1+q*u)*(1+cu*u)≤Real.exp g
  nlinarith only [hqdenU,hcuU,hex]

/-- The source's actual scalar rescaling retains a fixed positive kappa*u
margin after damping, uniformly in k and the order. -/
theorem upper_rescaling_damped_baseline {eps Ch C cu u0 : ℝ}
    (heps : 0<eps) (hC : 0≤C) (hCh : 2*C+2≤Ch) (hcu : 0≤cu) (hu0 : 0<u0)
    (hcua : cu≤min 1 (eps/4)/2) :
    ∃ c : ℝ, 0<c ∧ ∀ (k : ℕ) (alpha : ℝ),
      1<alpha → 0<fractionalPart alpha → fractionalPart alpha<1 →
      4*C*(fractionalPart alpha*(1-fractionalPart alpha))≤2*eps*(alpha-1) →
      upperKappa alpha eps+c*upperKappa alpha eps*upperU k alpha eps u0≤
        upperRescaling k alpha eps cu u0*Real.exp (-upperE0 k alpha eps Ch)*
          Real.exp (-C*(fractionalPart alpha*(1-fractionalPart alpha))) := by
  let a := min 1 (eps/4)
  let c := a/(2*(1+cu*u0))
  have ha : 0<a := lt_min (by norm_num) (by positivity)
  have hc : 0<c := by dsimp [c];positivity
  refine ⟨c,hc,?_⟩
  intro k alpha halpha hg hg1 hlarge
  have hu := (upperU_pos (k:=k) (eps:=eps) halpha hg hg1 hu0).le
  have huU : upperU k alpha eps u0≤u0 := min_le_right _ _
  have hgap := upper_delta_after_damping (k:=k) halpha hg hg1 heps hC hCh hu0 hlarge
  have h := rescaled_exp_margin hu huU ha hcu hcua hgap
  have hκ : 0≤upperKappa alpha eps := (Real.exp_pos _).le
  have hh := mul_le_mul_of_nonneg_left h hκ
  have hid : upperKappa alpha eps*(upperRescaling k alpha eps cu u0*
      Real.exp (upperDelta k alpha eps Ch-C*(fractionalPart alpha*(1-fractionalPart alpha))))=
      upperRescaling k alpha eps cu u0*Real.exp (-upperE0 k alpha eps Ch)*
        Real.exp (-C*(fractionalPart alpha*(1-fractionalPart alpha))) := by
    dsimp [upperKappa,upperE0]
    rw [show upperDelta k alpha eps Ch-C*(fractionalPart alpha*(1-fractionalPart alpha))=
      upperDelta k alpha eps Ch+(-C*(fractionalPart alpha*(1-fractionalPart alpha))) by ring,
      show -(2*eps*(alpha-1)-upperDelta k alpha eps Ch)=
        -(2*eps*(alpha-1))+upperDelta k alpha eps Ch by ring,
      Real.exp_add,Real.exp_add]
    ring
  change upperKappa alpha eps*(1+c*upperU k alpha eps u0)≤
    upperKappa alpha eps*(upperRescaling k alpha eps cu u0*
      Real.exp (upperDelta k alpha eps Ch-C*(fractionalPart alpha*(1-fractionalPart alpha)))) at hh
  rw [hid] at hh
  nlinarith only [hh]

end Renyi
