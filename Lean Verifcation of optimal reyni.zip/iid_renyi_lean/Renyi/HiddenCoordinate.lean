import Renyi.PaddedSimplex
import Renyi.IIDOverlap

/-! A hidden enlarged coordinate and a shared, uniformly spread reservoir. -/
noncomputable section
open scoped BigOperators
namespace Renyi

def labeledReservoirMass {m k : ℕ} (e : Fin m ↪ Fin k) (d : Fin m → ℝ)
    (r : ℝ) (j : Fin k) : ℝ := r + paddedWeight e (fun i => d i - r) j

@[simp] theorem labeledReservoirMass_at {m k : ℕ} (e : Fin m ↪ Fin k)
    (d : Fin m → ℝ) (r : ℝ) (i : Fin m) : labeledReservoirMass e d r (e i) = d i := by
  simp [labeledReservoirMass]

theorem labeledReservoirMass_off {m k : ℕ} (e : Fin m ↪ Fin k)
    (d : Fin m → ℝ) (r : ℝ) {j : Fin k} (hj : ¬ ∃ i, e i = j) :
    labeledReservoirMass e d r j = r := by
  simp [labeledReservoirMass, paddedWeight_off e _ hj]

theorem labeledReservoirMass_sum {m k : ℕ} (e : Fin m ↪ Fin k)
    (d : Fin m → ℝ) (r : ℝ) :
    ∑ j, labeledReservoirMass e d r j = (∑ i, d i) + ((k : ℝ) - m) * r := by
  simp [labeledReservoirMass, Finset.sum_add_distrib, paddedWeight_sum,
    Finset.sum_sub_distrib]
  ring

theorem labeledReservoirMass_map {m k : ℕ} (e : Fin m ↪ Fin k)
    (d : Fin m → ℝ) (r : ℝ) (f : ℝ → ℝ) (j : Fin k) :
    f (labeledReservoirMass e d r j) = labeledReservoirMass e (fun i => f (d i)) (f r) j := by
  by_cases hj : ∃ i, e i = j
  · obtain ⟨i, rfl⟩ := hj
    simp
  · rw [labeledReservoirMass_off e d r hj, labeledReservoirMass_off e _ _ hj]

theorem labeledReservoirMass_sum_map {m k : ℕ} (e : Fin m ↪ Fin k)
    (d : Fin m → ℝ) (r : ℝ) (f : ℝ → ℝ) :
    ∑ j, f (labeledReservoirMass e d r j) = (∑ i, f (d i)) + ((k : ℝ) - m) * f r := by
  simp_rw [labeledReservoirMass_map]
  exact labeledReservoirMass_sum e _ _

theorem labeledReservoirMass_nonneg {m k : ℕ} (e : Fin m ↪ Fin k)
    (d : Fin m → ℝ) (r : ℝ) (hd : ∀ i, 0 ≤ d i) (hr : 0 ≤ r) (j : Fin k) :
    0 ≤ labeledReservoirMass e d r j := by
  by_cases hj : ∃ i, e i = j
  · obtain ⟨i, rfl⟩ := hj
    simpa using hd i
  · simpa [labeledReservoirMass_off e d r hj] using hr

def labeledReservoirSimplex {m k : ℕ} (e : Fin m ↪ Fin k)
    (d : Fin m → ℝ) (r : ℝ) (hd : ∀ i, 0 ≤ d i) (hr : 0 ≤ r)
    (hnorm : (∑ i, d i) + ((k : ℝ) - m) * r = 1) : Simplex k where
  mass := labeledReservoirMass e d r
  nonneg := labeledReservoirMass_nonneg e d r hd hr
  normalized := (labeledReservoirMass_sum e d r).trans hnorm

def hiddenNullReservoir (k m : ℕ) (q : ℝ) : ℝ := (1 - m * q) / ((k : ℝ) - m)
def hiddenAltReservoir (k m : ℕ) (q B : ℝ) : ℝ :=
  (1 - m * q - (B - 1) * q) / ((k : ℝ) - m)

def hiddenDistinguished {m : ℕ} (q B : ℝ) (s i : Fin m) : ℝ :=
  if i = s then B * q else q

theorem hiddenDistinguished_sum {m : ℕ} (q B : ℝ) (s : Fin m) :
    ∑ i, hiddenDistinguished q B s i = m * q + (B - 1) * q := by
  have hterm (i : Fin m) : hiddenDistinguished q B s i = q + if i = s then (B - 1) * q else 0 := by
    simp only [hiddenDistinguished]
    split_ifs <;> ring
  simp_rw [hterm]
  simp [Finset.sum_add_distrib]

def hiddenNull {m k : ℕ} (e : Fin m ↪ Fin k) (q : ℝ)
    (hmk : m < k) (hq : 0 ≤ q) (hmq : m * q ≤ 1) : Simplex k :=
  labeledReservoirSimplex e (fun _ => q) (hiddenNullReservoir k m q) (fun _ => hq)
    (div_nonneg (sub_nonneg.mpr hmq) (sub_nonneg.mpr (by exact_mod_cast le_of_lt hmk)))
    (by
      have hden : (k : ℝ) - m ≠ 0 := ne_of_gt (sub_pos.mpr (by exact_mod_cast hmk))
      simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul,
        hiddenNullReservoir]
      field_simp
      ring)

def hiddenAlternative {m k : ℕ} (e : Fin m ↪ Fin k) (q B : ℝ)
    (hmk : m < k) (hq : 0 ≤ q) (hB : 1 ≤ B) (hmq : m * q + (B - 1) * q ≤ 1)
    (s : Fin m) : Simplex k :=
  labeledReservoirSimplex e (hiddenDistinguished q B s) (hiddenAltReservoir k m q B)
    (fun i => by unfold hiddenDistinguished; split_ifs <;> positivity)
    (div_nonneg (by linarith) (sub_nonneg.mpr (by exact_mod_cast le_of_lt hmk)))
    (by
      have hden : (k : ℝ) - m ≠ 0 := ne_of_gt (sub_pos.mpr (by exact_mod_cast hmk))
      rw [hiddenDistinguished_sum]
      unfold hiddenAltReservoir
      field_simp
      ring)

theorem labeledReservoirMass_sum_map₃ {m k : ℕ} (e : Fin m ↪ Fin k)
    (d₁ d₂ d₃ : Fin m → ℝ) (r₁ r₂ r₃ : ℝ) (f : ℝ → ℝ → ℝ → ℝ) :
    (∑ j, f (labeledReservoirMass e d₁ r₁ j) (labeledReservoirMass e d₂ r₂ j)
      (labeledReservoirMass e d₃ r₃ j)) =
      (∑ i, f (d₁ i) (d₂ i) (d₃ i)) + ((k : ℝ) - m) * f r₁ r₂ r₃ := by
  have hterm (j : Fin k) :
      f (labeledReservoirMass e d₁ r₁ j) (labeledReservoirMass e d₂ r₂ j)
          (labeledReservoirMass e d₃ r₃ j) =
        labeledReservoirMass e (fun i => f (d₁ i) (d₂ i) (d₃ i)) (f r₁ r₂ r₃) j := by
    by_cases hj : ∃ i, e i = j
    · obtain ⟨i, rfl⟩ := hj
      simp
    · simp only [labeledReservoirMass_off e _ _ hj]
  simp_rw [hterm]
  exact labeledReservoirMass_sum e _ _

theorem hiddenNull_pos {m k : ℕ} (e : Fin m ↪ Fin k) (q : ℝ)
    (hmk : m < k) (hq : 0 < q) (hmq : m * q < 1) :
    ∀ j, 0 < (hiddenNull e q hmk hq.le hmq.le).mass j := by
  intro j
  change 0 < labeledReservoirMass e (fun _ => q) (hiddenNullReservoir k m q) j
  by_cases hj : ∃ i, e i = j
  · obtain ⟨i, rfl⟩ := hj
    simpa using hq
  · rw [labeledReservoirMass_off e _ _ hj]
    exact div_pos (sub_pos.mpr hmq) (sub_pos.mpr (by exact_mod_cast hmk))

/-- The shared reservoir contributes to every pairwise overlap. -/
theorem hidden_coordinate_energy {m k : ℕ} (e : Fin m ↪ Fin k) (q B : ℝ)
    (hmk : m < k) (hq : 0 < q) (hB : 1 ≤ B) (hmq : m * q < 1)
    (hvalid : m * q + (B - 1) * q ≤ 1) (s t : Fin m) :
    iidOverlapEnergy (hiddenNull e q hmk hq.le hmq.le)
      (hiddenAlternative e q B hmk hq.le hB hvalid s)
      (hiddenAlternative e q B hmk hq.le hB hvalid t) =
        (if s = t then (B - 1) ^ 2 * q else 0) +
          (B - 1) ^ 2 * q ^ 2 / (1 - m * q) := by
  change (∑ j, (labeledReservoirMass e (hiddenDistinguished q B s) (hiddenAltReservoir k m q B) j -
      labeledReservoirMass e (fun _ => q) (hiddenNullReservoir k m q) j) *
      (labeledReservoirMass e (hiddenDistinguished q B t) (hiddenAltReservoir k m q B) j -
      labeledReservoirMass e (fun _ => q) (hiddenNullReservoir k m q) j) /
      labeledReservoirMass e (fun _ => q) (hiddenNullReservoir k m q) j) = _
  rw [labeledReservoirMass_sum_map₃ e (hiddenDistinguished q B s)
    (hiddenDistinguished q B t) (fun _ => q) (hiddenAltReservoir k m q B)
    (hiddenAltReservoir k m q B) (hiddenNullReservoir k m q)
    (fun x y z => (x - z) * (y - z) / z)]
  have hnum (i : Fin m) :
      (hiddenDistinguished q B s i - q) * (hiddenDistinguished q B t i - q) / q =
      if i = s ∧ s = t then (B - 1) ^ 2 * q else 0 := by
    unfold hiddenDistinguished
    by_cases hs : i = s
    · subst s
      by_cases ht : i = t
      · subst t
        simp only [ite_true, and_self]
        field_simp [ne_of_gt hq]
      · simp [ht]
    · simp [hs]
  simp_rw [hnum]
  have hsum : (∑ i : Fin m, if i = s ∧ s = t then (B - 1) ^ 2 * q else 0) =
      if s = t then (B - 1) ^ 2 * q else 0 := by
    by_cases hst : s = t <;> simp [hst]
  rw [hsum]
  congr 1
  have hden : (k : ℝ) - m ≠ 0 := ne_of_gt (sub_pos.mpr (by exact_mod_cast hmk))
  have hres : 1 - (m : ℝ) * q ≠ 0 := ne_of_gt (sub_pos.mpr hmq)
  unfold hiddenAltReservoir hiddenNullReservoir
  field_simp
  ring

theorem hiddenNull_powerSum {m k : ℕ} (e : Fin m ↪ Fin k) (q : ℝ)
    (hmk : m < k) (hq : 0 ≤ q) (hmq : m * q ≤ 1) (a : ℝ) :
    powerSum (hiddenNull e q hmk hq hmq) a =
      m * q ^ a + ((k : ℝ) - m) * (hiddenNullReservoir k m q) ^ a := by
  change (∑ j, (labeledReservoirMass e (fun _ => q) (hiddenNullReservoir k m q) j) ^ a) = _
  rw [labeledReservoirMass_sum_map e (fun _ => q) (hiddenNullReservoir k m q) (fun x => x ^ a)]
  simp

theorem hiddenAlternative_powerSum_lower {m k : ℕ} (e : Fin m ↪ Fin k) (q B : ℝ)
    (hmk : m < k) (hq : 0 ≤ q) (hB : 1 ≤ B) (hmq : m * q + (B - 1) * q ≤ 1)
    (s : Fin m) (a : ℝ) :
    (B * q) ^ a ≤ powerSum (hiddenAlternative e q B hmk hq hB hmq s) a := by
  have h := Finset.single_le_sum (s := Finset.univ)
    (f := fun j => (hiddenAlternative e q B hmk hq hB hmq s).mass j ^ a)
    (fun j _ => Real.rpow_nonneg ((hiddenAlternative e q B hmk hq hB hmq s).nonneg j) a)
    (Finset.mem_univ (e s))
  simpa only [hiddenAlternative, labeledReservoirSimplex, labeledReservoirMass_at,
    hiddenDistinguished, ite_true, powerSum] using h

theorem hidden_coordinate_chisq_bound {m k n : ℕ} (e : Fin m ↪ Fin k) (q B : ℝ)
    (hm : 0 < m) (hmk : m < k) (hq : 0 < q) (hB : 1 ≤ B) (hmq : m * q < 1)
    (hvalid : m * q + (B - 1) * q ≤ 1) :
    iidMixtureChiSq (hiddenNull e q hmk hq.le hmq.le)
      (hiddenAlternative e q B hmk hq.le hB hvalid) n ≤
      Real.exp ((n : ℝ) * (B - 1) ^ 2 * q ^ 2 / (1 - m * q)) *
        (Real.exp ((n : ℝ) * (B - 1) ^ 2 * q) - 1) / m +
        Real.exp ((n : ℝ) * (B - 1) ^ 2 * q ^ 2 / (1 - m * q)) - 1 := by
  apply iidMixtureChiSq_common_bound _ _ (hiddenNull_pos e q hmk hq hmq) hm
  · intro s
    rw [hidden_coordinate_energy e q B hmk hq hB hmq hvalid s s, if_pos rfl]
    exact le_of_eq (by ring)
  · intro s t hst
    rw [hidden_coordinate_energy e q B hmk hq hB hmq hvalid s t, if_neg hst]
    exact le_of_eq (by ring)

theorem hidden_coordinate_entropy_gap {m k : ℕ} (e : Fin m ↪ Fin k) (q B a : ℝ)
    (hmk : m < k) (hq : 0 < q) (hB : 1 ≤ B) (hmq : m * q < 1)
    (hvalid : m * q + (B - 1) * q ≤ 1) (ha : 1 < a)
    (hreservoir : ((k : ℝ) - m) * hiddenNullReservoir k m q ^ a ≤ q ^ a)
    (s : Fin m) :
    (a * Real.log B - Real.log ((m : ℝ) + 1)) / (a - 1) ≤
      entropy (hiddenNull e q hmk hq.le hmq.le) a -
        entropy (hiddenAlternative e q B hmk hq.le hB hvalid s) a := by
  let p₀ := hiddenNull e q hmk hq.le hmq.le
  let p₁ := hiddenAlternative e q B hmk hq.le hB hvalid s
  have hBpos : 0 < B := lt_of_lt_of_le zero_lt_one hB
  have hnullpos : 0 < powerSum p₀ a := by
    have h := Finset.single_le_sum (s := Finset.univ) (f := fun j => p₀.mass j ^ a)
      (fun j _ => Real.rpow_nonneg (p₀.nonneg j) a) (Finset.mem_univ (e s))
    have heq : p₀.mass (e s) = q := labeledReservoirMass_at e _ _ s
    change p₀.mass (e s) ^ a ≤ powerSum p₀ a at h
    rw [heq] at h
    exact (Real.rpow_pos_of_pos hq a).trans_le h
  have hnull : powerSum p₀ a ≤ ((m : ℝ) + 1) * q ^ a := by
    dsimp [p₀]
    rw [hiddenNull_powerSum]
    linarith
  have halt := hiddenAlternative_powerSum_lower e q B hmk hq.le hB hvalid s a
  have hlog₀ := Real.log_le_log hnullpos hnull
  have hlog₁ := Real.log_le_log (Real.rpow_pos_of_pos (mul_pos hBpos hq) a) halt
  rw [Real.log_mul (by positivity : (m : ℝ) + 1 ≠ 0) (ne_of_gt (Real.rpow_pos_of_pos hq a)),
    Real.log_rpow hq] at hlog₀
  rw [Real.log_rpow (mul_pos hBpos hq), Real.log_mul hBpos.ne' hq.ne'] at hlog₁
  change (a * Real.log B - Real.log ((m : ℝ) + 1)) / (a - 1) ≤
    -Real.log (powerSum p₀ a) / (a - 1) - -Real.log (powerSum p₁ a) / (a - 1)
  rw [← sub_div]
  apply div_le_div_of_nonneg_right _ (sub_pos.mpr ha).le
  change a * (Real.log B + Real.log q) ≤ Real.log (powerSum p₁ a) at hlog₁
  linarith

end Renyi
