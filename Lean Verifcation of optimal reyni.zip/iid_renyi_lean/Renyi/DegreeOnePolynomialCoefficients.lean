import Renyi.CompletedCoupledPolynomial
import Renyi.CoupledLocalCoefficients

/-! Actual coefficient bounds for the degree-one completed low arm. -/
noncomputable section
open Set Polynomial
namespace Renyi

def degreeOneLowPolynomial (s c : ℝ) : ℝ[X] :=
  C (degreeOneNormalizer s c)⁻¹*(1-C c*X)

lemma degreeOneLowPolynomial_natDegree (s c : ℝ) : (degreeOneLowPolynomial s c).natDegree≤1 := by
  unfold degreeOneLowPolynomial
  apply (natDegree_C_mul_le _ _).trans
  apply (natDegree_sub_le _ _).trans
  apply max_le (by simp)
  exact (natDegree_mul_le).trans (by simp)

lemma degreeOneLowPolynomial_eval (s c x : ℝ) :
    (degreeOneLowPolynomial s c).eval x=(1-c*x)/degreeOneNormalizer s c := by
  simp only [degreeOneLowPolynomial,eval_mul,eval_C,eval_sub,eval_one,eval_X]
  ring

/-- Exact reverse-polynomial form, permitting the same count-coefficient machinery. -/
theorem degreeOne_reverse_polynomial {m : ℕ} (hm : 1≤m) {γ c a : ℝ}
    (hγ : 0<γ) (hc : 0<c) (ha : 0≤a) :
    C (a^γ)*reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a=
      X^(m-1)*nearOneTangentPolynomial γ (c*a*(1+γ)/γ) := by
  apply Polynomial.eq_of_infinite_eval_eq
  apply (Ioi_infinite (0:ℝ)).mono
  intro p hp
  have hp' : 0<p := hp
  have hrev := reverseScaledPolynomial_eval (degreeOneLowPolynomial γ c)
    ((degreeOneLowPolynomial_natDegree γ c).trans hm) a hp'.ne'
  have hT := degreeOne_reverse_tangent hγ hc ha hp'
  have hfrac := reverse_fractional_identity m γ ha hp'
  simp only [Set.mem_setOf_eq,eval_mul,eval_C,eval_pow,eval_X,hrev,degreeOneLowPolynomial_eval]
  rw [←hT]
  calc
    _ = (p^((m:ℝ)+γ)*(a/p)^γ)*(1-c*(a/p))/degreeOneNormalizer γ c := by rw [hfrac];ring
    _ = (p^(m-1)*p^(1+γ))*degreeOneProfile γ c (a/p) := by
      rw [order_power_completion hm hp'];unfold degreeOneProfile;ring
    _ = _ := by ring

/-- All terms of the completed polynomial in the common reverse/forward representation. -/
theorem degreeOneCoupledPolynomial_reverse {N m : ℕ} (hm : 1≤m)
    {γ c a b f ω A B : ℝ} (hγ : 0<γ) (hc : 0<c) (ha : 0≤a) :
    degreeOneCoupledPolynomial N m γ (c*a*(1+γ)/γ) b f ω A B=
      C (A*a^γ)*reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a*
        (1-(X*endpointProfilePolynomial N 6 1).comp (C b⁻¹*X))+
      C (B/b^(1-γ))*X^(m+1)*(highProfilePolynomial N (1-γ) f ω).comp (C b⁻¹*X)+
      C (ω*(1-B)/b^(1-γ))*X^(m+1)*(endpointProfilePolynomial N 6 (1-γ)).comp (C b⁻¹*X) := by
  have hrev := degreeOne_reverse_polynomial hm hγ hc ha
  have hpow : (X:ℝ[X])^(m-1)*X^2=X^(m+1) := by rw [←pow_add];congr 1;omega
  unfold degreeOneCoupledPolynomial nearOneCoupledPolynomial
  rw [C_mul]
  calc
    _ = C A*(X^(m-1)*nearOneTangentPolynomial γ (c*a*(1+γ)/γ))*
          (1-(X*endpointProfilePolynomial N 6 1).comp (C b⁻¹*X))+
        C (B/b^(1-γ))*(X^(m-1)*X^2)*(highProfilePolynomial N (1-γ) f ω).comp (C b⁻¹*X)+
        C (ω*(1-B)/b^(1-γ))*(X^(m-1)*X^2)*(endpointProfilePolynomial N 6 (1-γ)).comp (C b⁻¹*X) := by ring
    _ = _ := by rw [←hrev,hpow];ring

theorem degreeOneLowPolynomial_local_mass {γ c x : ℝ}
    (hγ : 0<γ) (hγ1 : γ≤1) (hc : c∈Ioo (γ/(1+γ)) 1) (hx : 0≤x) :
    coefficientMass ((degreeOneLowPolynomial γ c).comp (C x*X))≤4*(1+x) := by
  have hc0 : 0<c := (div_pos hγ (by positivity)).trans hc.1
  have hn := degreeOneNormalizer_bounds hγ hγ1 hc.1 hc.2
  have hnpos : 0<degreeOneNormalizer γ c := lt_of_lt_of_le (by norm_num) hn.1
  have hinv : (degreeOneNormalizer γ c)⁻¹≤4 := by
    rw [inv_eq_one_div]
    apply (div_le_iff₀ hnpos).mpr
    linarith only [hn.1]
  unfold degreeOneLowPolynomial
  simp only [mul_comp,C_comp,sub_comp,one_comp,X_comp,coefficientMass_C_mul,
    abs_of_pos (inv_pos.mpr hnpos)]
  have hsub := coefficientMass_sub_le (1:ℝ[X]) (C c*(C x*X))
  have hcx : coefficientMass (C c*(C x*X))=c*x := by
    rw [coefficientMass_C_mul,coefficientMass_C_mul_X,abs_of_pos hc0,abs_of_nonneg hx]
  rw [coefficientMass_one,hcx] at hsub
  have hcx1 := mul_le_mul_of_nonneg_right hc.2.le hx
  have hsub' : coefficientMass (1-C c*(C x*X))≤1+x := by linarith only [hsub,hcx1]
  exact mul_le_mul hinv hsub' (coefficientMass_nonneg _) (by norm_num)

theorem degreeOneLowPolynomial_coefficientMass {γ c : ℝ}
    (hγ : 0<γ) (hγ1 : γ≤1) (hc : c∈Ioo (γ/(1+γ)) 1) :
    coefficientMass (degreeOneLowPolynomial γ c)≤8 := by
  have hh := degreeOneLowPolynomial_local_mass hγ hγ1 hc (by norm_num : (0:ℝ)≤1)
  norm_num at hh ⊢
  exact hh

end Renyi
