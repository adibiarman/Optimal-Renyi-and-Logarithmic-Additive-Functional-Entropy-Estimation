import Renyi.CoupledConditionalCountCertificate
import Renyi.CompletedLeadingCoefficient

/-! Fixed choices of count calibration constants, made before the final sample multiplier. -/
noncomputable section
namespace Renyi

/-- The logarithmic degree coefficient can be fixed before all cutoff calibration. -/
theorem exists_count_logarithmic_degree_coefficient {CL Cmed Ct : ℝ}
    (hCL : 1 ≤ CL) (hCmed : 0 ≤ Cmed) (hCt : 0 ≤ Ct) :
    ∃ cL : ℝ, 0 < cL ∧ cL * (Cmed + Ct + 1 / (CL + 1)) ≤ 1 / 2 := by
  let A := Cmed + Ct + 1 / (CL + 1)
  have hA : 0 ≤ A := by dsimp [A]; positivity
  refine ⟨1 / (2 * (A + 1)), by positivity, ?_⟩
  change 1 / (2 * (A + 1)) * A ≤ 1 / 2
  have hratio : A / (A + 1) ≤ 1 := (div_le_one (by positivity : 0 < A + 1)).mpr (by linarith)
  calc
    _ = (A / (A + 1)) / 2 := by field_simp
    _ ≤ _ := div_le_div_of_nonneg_right hratio (by norm_num)


/-- A single baseline constant dominates all completed count blocks, uniformly in order and dimension. -/
theorem exists_count_reference_constants (rhoPlus rhoMinus Cp Cscale CL Cmed Ct cb c : ℝ)
    (hrhoMinus : 0 < rhoMinus) :
    ∃ R C0 : ℝ, 0 < R ∧ 1 ≤ C0 ∧ R ≤ C0 * rhoMinus ∧
      Real.exp (3 * (Real.log (lowCountExponentialConstant rhoPlus Cp) + c)) ≤ R ∧
      Real.exp (3 * (Real.log (highTinyExponentialConstant
        (completedLeadingCoefficientConstant * max 1 Cscale)) + c)) ≤ R ∧
      Real.exp (3 * (Real.log (highMediumExponentialConstant CL Cmed Ct cb) + c)) ≤ R := by
  let Rlow := Real.exp (3 * (Real.log (lowCountExponentialConstant rhoPlus Cp) + c))
  let Rtiny := Real.exp (3 * (Real.log (highTinyExponentialConstant
    (completedLeadingCoefficientConstant * max 1 Cscale)) + c))
  let Rmedium := Real.exp (3 * (Real.log (highMediumExponentialConstant CL Cmed Ct cb) + c))
  let R := max Rlow (max Rtiny Rmedium)
  let C0 := max 1 (R / rhoMinus)
  have hR : 0 < R := (Real.exp_pos _).trans_le (le_max_left _ _)
  have hC0 : 1 ≤ C0 := le_max_left _ _
  have hscale : R ≤ C0 * rhoMinus := by
    have h := mul_le_mul_of_nonneg_right (le_max_right 1 (R / rhoMinus)) hrhoMinus.le
    have hid : (R / rhoMinus) * rhoMinus = R := by field_simp
    rwa [hid] at h
  exact ⟨R, C0, hR, hC0, hscale, le_max_left _ _,
    (le_max_left _ _).trans (le_max_right _ _), (le_max_right _ _).trans (le_max_right _ _)⟩

/-- After the baseline is fixed, one D0 suffices for any prescribed count-noise tolerance. -/
theorem exists_count_sample_multiplier {E0 u0 ustar eta : ℝ}
    (hE0 : 0 < E0) (hu0 : 0 < u0) (hustar : 0 < ustar) (heta : 0 < eta) :
    ∃ D0 : ℝ, 1 ≤ D0 ∧ ∀ D : ℝ, D0 ≤ D →
      conditionalCountRateConstant E0 u0 * (1 + 1 / ustar) ^ 2 / D ≤ eta := by
  let F := conditionalCountRateConstant E0 u0 * (1 + 1 / ustar) ^ 2
  have hF : 0 < F := by
    have h := conditionalCountRateConstant_pos hE0 hu0
    dsimp [F]
    positivity
  refine ⟨max 1 (F / eta), le_max_left _ _, ?_⟩
  intro D hD
  have hD1 : 1 ≤ D := (le_max_left _ _).trans hD
  have hD0 : 0 < D := zero_lt_one.trans_le hD1
  have hthreshold : F / eta ≤ D := (le_max_right _ _).trans hD
  apply (div_le_iff₀ hD0).mpr
  have h := (div_le_iff₀ heta).mp hthreshold
  exact h.trans_eq (by ring)

end Renyi
