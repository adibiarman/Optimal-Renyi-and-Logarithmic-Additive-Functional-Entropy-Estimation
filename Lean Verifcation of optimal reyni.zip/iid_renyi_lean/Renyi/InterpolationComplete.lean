import Renyi.Interpolation

/-!
# The remaining algebra of the perturbed interpolation factor

The inverse-moment identity is obtained by inserting zero as one more
interpolation node. All weights are explicitly constructed.
-/

noncomputable section
open scoped BigOperators
open Polynomial
namespace Renyi

private def augmentedNodes {ι : Type*} (u : ι → ℝ) : Option ι → ℝ :=
  fun i => i.elim 0 u

private theorem augmented_basis_none {ι : Type*} [Fintype ι] [DecidableEq ι]
    (u : ι → ℝ) :
    Lagrange.basis Finset.univ (augmentedNodes u) none =
      ∏ i, Lagrange.basisDivisor 0 (u i) := by
  have heq : (Finset.univ : Finset (Option ι)).erase none =
      (Finset.univ : Finset ι).image some := by
    ext i
    cases i <;> simp
  rw [Lagrange.basis, heq, Finset.prod_image]
  · rfl
  · intro i _ j _ h
    exact Option.some.inj h

private theorem augmented_basis_some {ι : Type*} [Fintype ι] [DecidableEq ι]
    (u : ι → ℝ) (i : ι) :
    Lagrange.basis Finset.univ (augmentedNodes u) (some i) =
      Lagrange.basisDivisor (u i) 0 * Lagrange.basis Finset.univ u i := by
  have heq : (Finset.univ : Finset (Option ι)).erase (some i) =
      insert none (((Finset.univ : Finset ι).erase i).image some) := by
    ext j
    cases j <;> simp
  rw [Lagrange.basis, heq, Finset.prod_insert]
  · rw [Finset.prod_image]
    · rfl
    · intro j _ k _ h
      exact Option.some.inj h
  · simp

/-- The reciprocal interpolant's error is the normalized nodal product. -/
theorem lagrange_inverse_product {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) (hu0 : ∀ i, u i ≠ 0) (a : ℝ) :
    1 - a * (∑ i, lagrangeWeight u a i / u i) =
      ∏ i, (1 - a / u i) := by
  have hinj : Function.Injective (augmentedNodes u) := by
    intro i j hij
    cases i with
    | none =>
      cases j with
      | none => rfl
      | some j => exact False.elim (hu0 j hij.symm)
    | some i =>
      cases j with
      | none => exact False.elim (hu0 i hij)
      | some j => exact congrArg some (hu hij)
  have h := congrArg (Polynomial.eval a)
    (Lagrange.sum_basis (s := Finset.univ) hinj.injOn Finset.univ_nonempty)
  rw [Polynomial.eval_finset_sum] at h
  simp only [Fintype.sum_option, augmented_basis_none, augmented_basis_some,
    Polynomial.eval_prod, Polynomial.eval_mul, Polynomial.eval_one] at h
  have hnone : (∏ i, (Lagrange.basisDivisor 0 (u i)).eval a) =
      ∏ i, (1 - a / u i) := by
    apply Finset.prod_congr rfl
    intro i _
    simp only [Lagrange.basisDivisor, Polynomial.eval_mul, Polynomial.eval_C,
      Polynomial.eval_sub, Polynomial.eval_X]
    field_simp [hu0 i]
    ring
  have hsome : (∑ i, (Lagrange.basisDivisor (u i) 0).eval a *
      (Lagrange.basis Finset.univ u i).eval a) =
      a * (∑ i, lagrangeWeight u a i / u i) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    simp only [Lagrange.basisDivisor, Polynomial.eval_mul, Polynomial.eval_C,
      Polynomial.eval_sub, Polynomial.eval_X, sub_zero, lagrangeWeight]
    ring
  rw [hnone, hsome] at h
  linarith

def interpolationProduct {n : ℕ} (u : Fin (n + 1) → ℝ) (a : ℝ) : ℝ :=
  ∏ i, (1 - a / u i)

/-- The perturbed signed measure has mass exactly rho times the nodal product. -/
theorem perturbed_total_mass {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) (hu0 : ∀ i, u i ≠ 0) (a ρ : ℝ) :
    perturbedMoment u a ρ 0 = ρ * interpolationProduct u a := by
  have hbase : ∑ i, lagrangeWeight u a i = 1 := by
    simpa using lagrange_monomial u hu a 0 (Nat.zero_le n)
  have hsum : (∑ i, lagrangeWeight u a i * (1 + ρ * a / u i)) =
      1 + (ρ * a) * (∑ i, lagrangeWeight u a i / u i) := by
    calc
      (∑ i, lagrangeWeight u a i * (1 + ρ * a / u i)) =
          ∑ i, (lagrangeWeight u a i + (ρ * a) * (lagrangeWeight u a i / u i)) := by
            apply Finset.sum_congr rfl
            intro i _
            ring
      _ = _ := by rw [Finset.sum_add_distrib, ← Finset.mul_sum, hbase]
  simp only [perturbedMoment, pow_zero, mul_one]
  rw [hsum]
  calc
    1 + ρ - (1 + ρ * a * ∑ i, lagrangeWeight u a i / u i) =
        ρ * (1 - a * ∑ i, lagrangeWeight u a i / u i) := by ring
    _ = ρ * interpolationProduct u a := by
      rw [lagrange_inverse_product u hu hu0 a]
      rfl

/-- The inverse moment of the unperturbed signed measure. -/
theorem unperturbed_inverse_moment {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) (hu0 : ∀ i, u i ≠ 0) {a : ℝ} (ha : a ≠ 0) :
    1 / a - (∑ i, lagrangeWeight u a i / u i) = interpolationProduct u a / a := by
  unfold interpolationProduct
  rw [← lagrange_inverse_product u hu hu0 a]
  field_simp

/-- The distinct atoms supporting the finite signed measure. -/
def interpolationNodes {n : ℕ} (u : Fin (n + 1) → ℝ) (a : ℝ) :
    Option (Fin (n + 1)) → ℝ := fun i => i.elim a u

/-- The signed atomic coefficients of nu_rho, including the atom at a. -/
def interpolationWeights {n : ℕ} (u : Fin (n + 1) → ℝ) (a ρ : ℝ) :
    Option (Fin (n + 1)) → ℝ :=
  fun i => i.elim (1 + ρ) (fun j => -(lagrangeWeight u a j * (1 + ρ * a / u j)))

theorem interpolationNodes_injective {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) {a : ℝ} (ha : ∀ i, a < u i) :
    Function.Injective (interpolationNodes u a) := by
  intro i j hij
  cases i with
  | none =>
    cases j with
    | none => rfl
    | some j => exact False.elim (ne_of_lt (ha j) hij)
  | some i =>
    cases j with
    | none => exact False.elim (ne_of_lt (ha i) hij.symm)
    | some j => exact congrArg some (hu hij)

theorem interpolationNodes_pos {n : ℕ} (u : Fin (n + 1) → ℝ)
    {a : ℝ} (ha : 0 < a) (hau : ∀ i, a < u i) :
    ∀ i, 0 < interpolationNodes u a i := by
  intro i
  cases i with
  | none => exact ha
  | some i => exact ha.trans (hau i)

/-- Finite integration of every natural monomial agrees with the earlier functional. -/
theorem interpolationWeights_moment {n : ℕ} (u : Fin (n + 1) → ℝ)
    (a ρ : ℝ) (j : ℕ) :
    (∑ i, interpolationWeights u a ρ i * interpolationNodes u a i ^ j) =
      perturbedMoment u a ρ j := by
  simp only [Fintype.sum_option, interpolationWeights, interpolationNodes,
    Option.elim_none, Option.elim_some, perturbedMoment, neg_mul,
    Finset.sum_neg_distrib]
  ring

/-- The reciprocal moment written directly as a sum over the signed atoms. -/
theorem interpolationWeights_inverse_moment {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) (hu0 : ∀ i, u i ≠ 0) {a : ℝ} (ha : a ≠ 0) :
    (∑ i, interpolationWeights u a 0 i / interpolationNodes u a i) =
      interpolationProduct u a / a := by
  simpa only [Fintype.sum_option, interpolationWeights, interpolationNodes,
    Option.elim_none, Option.elim_some, zero_mul, zero_div, add_zero,
    mul_one, neg_div, Finset.sum_neg_distrib, ← sub_eq_add_neg] using
      unperturbed_inverse_moment u hu hu0 ha

/-- Every polynomial through degree n is annihilated by the unperturbed measure. -/
theorem unperturbed_polynomial_annihilation {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) (a : ℝ) (f : ℝ[X]) (hf : f.natDegree ≤ n) :
    (∑ i, interpolationWeights u a 0 i * f.eval (interpolationNodes u a i)) = 0 := by
  have hdeg : f.degree < (Finset.univ : Finset (Fin (n + 1))).card := by
    simp only [Finset.card_univ, Fintype.card_fin]
    apply lt_of_le_of_lt (Polynomial.degree_le_natDegree)
    exact_mod_cast (Nat.lt_succ_of_le hf)
  have heval := congrArg (Polynomial.eval a) (Lagrange.eq_interpolate hu.injOn hdeg)
  have hinterp : ∑ i, lagrangeWeight u a i * f.eval (u i) = f.eval a := by
    simpa [Lagrange.interpolate_apply, Polynomial.eval_finset_sum,
      lagrangeWeight, mul_comm] using heval.symm
  simp only [Fintype.sum_option, interpolationWeights, interpolationNodes,
    Option.elim_none, Option.elim_some, zero_mul, zero_div, add_zero,
    mul_one, one_mul, neg_mul, Finset.sum_neg_distrib]
  rw [hinterp]
  ring

theorem interpolationProduct_pos {n : ℕ} (u : Fin (n + 1) → ℝ)
    {a : ℝ} (ha : 0 < a) (hau : ∀ i, a < u i) :
    0 < interpolationProduct u a := by
  apply Finset.prod_pos
  intro i _
  apply sub_pos.mpr
  exact (div_lt_one (ha.trans (hau i))).2 (hau i)

/-- The positive Jordan mass of a finite signed measure at distinct atoms. -/
def positiveAtomicMass {ι : Type*} [Fintype ι] (w : ι → ℝ) : ℝ :=
  ∑ i, max (w i) 0

def weightedInterpolation {n : ℕ} (u : Fin (n + 1) → ℝ) (a ρ e : ℝ)
    (i : Option (Fin (n + 1))) : ℝ :=
  interpolationWeights u a ρ i * interpolationNodes u a i ^ (-e)

def interpolationNormalizer {n : ℕ} (u : Fin (n + 1) → ℝ) (a ρ e : ℝ) : ℝ :=
  positiveAtomicMass (weightedInterpolation u a ρ e)

def normalizedInterpolation {n : ℕ} (u : Fin (n + 1) → ℝ) (a ρ e : ℝ)
    (i : Option (Fin (n + 1))) : ℝ :=
  weightedInterpolation u a ρ e i / interpolationNormalizer u a ρ e

/-- The atom at a makes the positive normalizer strictly positive. -/
theorem interpolationNormalizer_pos {n : ℕ} (u : Fin (n + 1) → ℝ)
    {a ρ e : ℝ} (ha : 0 < a) (hρ : 0 ≤ ρ) :
    0 < interpolationNormalizer u a ρ e := by
  have hweight : 0 < weightedInterpolation u a ρ e none := by
    dsimp [weightedInterpolation, interpolationWeights, interpolationNodes]
    exact mul_pos (by linarith) (Real.rpow_pos_of_pos ha _)
  have hterm : 0 < max (weightedInterpolation u a ρ e none) 0 :=
    hweight.trans_le (le_max_left _ _)
  have hsum : max (weightedInterpolation u a ρ e none) 0 ≤
      interpolationNormalizer u a ρ e := by
    exact Finset.single_le_sum (fun i _ => le_max_right _ _) (Finset.mem_univ none)
  exact hterm.trans_le hsum

/-- Dividing by the positive Jordan mass normalizes that mass to one. -/
theorem normalizedInterpolation_positive_mass {n : ℕ} (u : Fin (n + 1) → ℝ)
    {a ρ e : ℝ} (ha : 0 < a) (hρ : 0 ≤ ρ) :
    positiveAtomicMass (normalizedInterpolation u a ρ e) = 1 := by
  have hP := interpolationNormalizer_pos u (e := e) ha hρ
  unfold positiveAtomicMass normalizedInterpolation
  have hterm (i : Option (Fin (n + 1))) :
      max (weightedInterpolation u a ρ e i / interpolationNormalizer u a ρ e) 0 =
        max (weightedInterpolation u a ρ e i) 0 / interpolationNormalizer u a ρ e := by
    simpa only [zero_div] using max_div_div_right hP.le (weightedInterpolation u a ρ e i) 0
  simp_rw [hterm]
  rw [← Finset.sum_div]
  exact div_self (ne_of_gt hP)

/-- Weighting by u^(-e) shifts real moments by e, exactly. -/
theorem normalizedInterpolation_shift {n : ℕ} (u : Fin (n + 1) → ℝ)
    {a ρ e : ℝ} (ha : 0 < a) (hau : ∀ i, a < u i) (j : ℕ) :
    (∑ i, normalizedInterpolation u a ρ e i *
      interpolationNodes u a i ^ (e + (j : ℝ))) =
      perturbedMoment u a ρ j / interpolationNormalizer u a ρ e := by
  have hp (i : Option (Fin (n + 1))) :
      interpolationNodes u a i ^ (-e) * interpolationNodes u a i ^ (e + (j : ℝ)) =
        interpolationNodes u a i ^ j := by
    rw [← Real.rpow_add (interpolationNodes_pos u ha hau i)]
    have he : -e + (e + (j : ℝ)) = (j : ℝ) := by ring
    rw [he, Real.rpow_natCast]
  have hterm (i : Option (Fin (n + 1))) :
      normalizedInterpolation u a ρ e i * interpolationNodes u a i ^ (e + (j : ℝ)) =
      (interpolationWeights u a ρ i * interpolationNodes u a i ^ j) /
        interpolationNormalizer u a ρ e := by
    unfold normalizedInterpolation weightedInterpolation
    rw [div_mul_eq_mul_div, mul_assoc, hp]
  simp_rw [hterm]
  rw [← Finset.sum_div, interpolationWeights_moment]

/-- The normalized weighted measure preserves the prescribed moment cancellations. -/
theorem normalizedInterpolation_moment_cancellation {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) {a ρ e : ℝ} (ha : 0 < a) (hau : ∀ i, a < u i)
    (j : ℕ) (hj0 : 1 ≤ j) (hjn : j ≤ n) :
    (∑ i, normalizedInterpolation u a ρ e i *
      interpolationNodes u a i ^ (e + (j : ℝ))) = 0 := by
  rw [normalizedInterpolation_shift u ha hau j,
    perturbed_moment_cancellation u hu (fun i => ne_of_gt (ha.trans (hau i))) a ρ j hj0 hjn,
    zero_div]

/-- The only lowest shifted-moment defect is exactly rho*C_a/P. -/
theorem normalizedInterpolation_lowest_moment {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) {a ρ e : ℝ} (ha : 0 < a) (hau : ∀ i, a < u i) :
    (∑ i, normalizedInterpolation u a ρ e i * interpolationNodes u a i ^ e) =
      ρ * interpolationProduct u a / interpolationNormalizer u a ρ e := by
  have h := normalizedInterpolation_shift u (ρ := ρ) (e := e) ha hau 0
  simp only [Nat.cast_zero, add_zero] at h
  rw [h, perturbed_total_mass u hu (fun i => ne_of_gt (ha.trans (hau i)))]

/-- The full perturbed interpolation factor, represented by its distinct atoms.

For a finite atomic signed measure, integration is precisely the finite sums
in this statement, and its positive Jordan mass is `positiveAtomicMass`.
This bundles the source lemma's conclusions without assumptions about any
interpolation or moment-matching certificate.
-/
theorem perturbed_interpolation_factor {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) {a ρ e : ℝ} (ha : 0 < a)
    (hau : ∀ i, a < u i) (hρ : 0 ≤ ρ) :
    Function.Injective (interpolationNodes u a) ∧
    (∀ j : ℕ, 1 ≤ j → j ≤ n →
      (∑ i, interpolationWeights u a ρ i * interpolationNodes u a i ^ j) = 0) ∧
    (∑ i, interpolationWeights u a ρ i) = ρ * interpolationProduct u a ∧
    (∑ i, interpolationWeights u a 0 i / interpolationNodes u a i) =
      interpolationProduct u a / a ∧
    (∀ f : ℝ[X], f.natDegree ≤ n →
      (∑ i, interpolationWeights u a 0 i * f.eval (interpolationNodes u a i)) = 0) ∧
    0 < interpolationNormalizer u a ρ e ∧
    positiveAtomicMass (normalizedInterpolation u a ρ e) = 1 ∧
    (∀ j : ℕ, 1 ≤ j → j ≤ n →
      (∑ i, normalizedInterpolation u a ρ e i *
        interpolationNodes u a i ^ (e + (j : ℝ))) = 0) ∧
    (∑ i, normalizedInterpolation u a ρ e i * interpolationNodes u a i ^ e) =
      ρ * interpolationProduct u a / interpolationNormalizer u a ρ e := by
  have hu0 : ∀ i, u i ≠ 0 := fun i => ne_of_gt (ha.trans (hau i))
  refine ⟨interpolationNodes_injective u hu hau, ?_, ?_,
    interpolationWeights_inverse_moment u hu hu0 (ne_of_gt ha), ?_,
    interpolationNormalizer_pos u ha hρ, normalizedInterpolation_positive_mass u ha hρ,
    ?_, normalizedInterpolation_lowest_moment u hu ha hau⟩
  · intro j hj0 hjn
    rw [interpolationWeights_moment,
      perturbed_moment_cancellation u hu hu0 a ρ j hj0 hjn]
  · have h := interpolationWeights_moment u a ρ 0
    simp only [pow_zero, mul_one] at h
    rw [h, perturbed_total_mass u hu hu0]
  · intro f hf
    exact unperturbed_polynomial_annihilation u hu a f hf
  · intro j hj0 hjn
    exact normalizedInterpolation_moment_cancellation u hu ha hau j hj0 hjn

end Renyi
