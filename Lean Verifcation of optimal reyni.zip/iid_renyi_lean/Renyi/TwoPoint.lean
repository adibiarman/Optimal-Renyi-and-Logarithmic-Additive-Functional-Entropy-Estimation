import Renyi.Model

/-!
# A lower-bound reduction for actual i.i.d. observations

This theorem covers arbitrary randomized real-valued estimators. It does not
construct the difficult priors in the manuscript or prove their distance bound.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory
namespace Renyi

/-- Two entropy-separated distributions with close sample laws preclude a
uniform estimator at the requested accuracy and confidence. -/
theorem two_point_impossibility {k n : ℕ} (p q : Simplex k) (α ε : ℝ)
    (hgap : 2 * ε < entropy q α - entropy p α)
    (hTV : finiteTV (iidMass p n) (iidMass q n) ≤ 1 / 4) :
    ¬ Achievable k n α ε := by
  rintro ⟨est, hest⟩
  let midpoint := (entropy p α + entropy q α) / 2
  let upper : Set ℝ := Set.Ioi midpoint
  let t : Sample k n → ℝ := fun x => (est x upper : ℝ)
  have ht0 : ∀ x, 0 ≤ t x := fun x => NNReal.coe_nonneg _
  have ht1 : ∀ x, t x ≤ 1 := by
    intro x
    exact_mod_cast (est x).apply_le_one upper
  have hlower := finite_testing_three_eighths (iidMass p n) (iidMass q n) t
    (iidMass_sum p n) (iidMass_sum q n) ht0 ht1 hTV
  have hleft : upper ⊆ {z : ℝ | ε < |z - entropy p α|} := by
    intro z hz
    by_contra h
    have haccurate : |z - entropy p α| ≤ ε := le_of_not_gt h
    have := separated_intervals_left hgap haccurate
    change midpoint < z at hz
    change z < midpoint at this
    linarith
  have hright : upperᶜ ⊆ {z : ℝ | ε < |z - entropy q α|} := by
    intro z hz
    by_contra h
    have haccurate : |z - entropy q α| ≤ ε := le_of_not_gt h
    have := separated_intervals_right hgap haccurate
    change ¬ midpoint < z at hz
    exact hz this
  have htleft : ∀ x, t x ≤ (est x {z : ℝ | ε < |z - entropy p α|} : ℝ) := by
    intro x
    exact_mod_cast (est x).apply_mono hleft
  have htright : ∀ x, 1 - t x ≤ (est x {z : ℝ | ε < |z - entropy q α|} : ℝ) := by
    intro x
    have hcomp : (est x upper : ℝ) + (est x upperᶜ : ℝ) = 1 := by
      simpa only [ProbabilityMeasure.measureReal_eq_coe_coeFn,
        ProbabilityMeasure.coeFn_univ, NNReal.coe_one] using
        (measureReal_add_measureReal_compl (μ := (est x : Measure ℝ))
          (show MeasurableSet upper from measurableSet_Ioi))
    have hmono : (est x upperᶜ : ℝ) ≤
        (est x {z : ℝ | ε < |z - entropy q α|} : ℝ) := by
      exact_mod_cast (est x).apply_mono hright
    change 1 - (est x upper : ℝ) ≤ _
    linarith
  have hsum : (∑ x, (iidMass p n x * t x + iidMass q n x * (1 - t x))) ≤
      errorProbability p α ε est + errorProbability q α ε est := by
    unfold errorProbability
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro x _
    exact add_le_add
      (mul_le_mul_of_nonneg_left (htleft x) (iidMass_nonneg p x))
      (mul_le_mul_of_nonneg_left (htright x) (iidMass_nonneg q x))
  have hp := hest p
  have hq := hest q
  linarith

end Renyi
