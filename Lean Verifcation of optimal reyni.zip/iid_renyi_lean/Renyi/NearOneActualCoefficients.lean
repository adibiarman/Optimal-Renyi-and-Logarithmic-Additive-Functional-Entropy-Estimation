import Renyi.NearOneActualPolynomial
import Renyi.NearOneCoefficients
import Renyi.CoupledCutoff

/-! Uniform beta coefficients for the actual root-calibrated near-one polynomial. -/
noncomputable section
open Polynomial
namespace Renyi

/-- Actual parameters imply the nonlinear beta coefficient bound; no coefficient certificate. -/
theorem actual_near_one_coefficients_uniform {eps cb lambda CL cL cmin q Q M cw f : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcL : 0<cL) (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hf : 0≤f) (hf1 : f≤1) :
    ∃ K : ℝ, 0<K ∧ ∀ (k N j : ℕ) (alpha Ch D c s0 : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) →
      0≤s0 → s0≤1 → 2≤j →
      |(actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f s0).coeff j| *
          (upperB k alpha eps D cb CL cL)^j ≤
        K*(alpha-1)*(upperB k alpha eps D cb CL cL)^alpha*
          Real.exp (K*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)) := by
  obtain ⟨Ca,hCa,ha⟩ := near_one_attenuated_amplitudes_uniform heps hM hcw hcw1
  obtain ⟨lo,hi,hlo,hhi,hratio⟩ := near_one_variable_tangent_compact heps hcb hlambda hCL hcL hcmin hq hQ
  let ML := |Real.log lo|+|Real.log hi|
  let F := nearOneCoefficientConstant ML Ca
  let d := 2+18*Real.log 9
  let K := F+d*Q+1
  have hML : 0≤ML := add_nonneg (abs_nonneg _) (abs_nonneg _)
  have hF : 0<F := nearOneCoefficientConstant_pos hML hCa.le
  have hd : 0<d := by
    dsimp [d]
    have := Real.log_nonneg (by norm_num : (1:ℝ)≤9)
    positivity
  have hK : 0<K := by dsimp [K];positivity
  have hFK : F≤K := by dsimp [K];nlinarith only [mul_pos hd hQ]
  have hdK : d*Q≤K := by dsimp [K];linarith only [hF]
  refine ⟨K,hK,?_⟩
  intro k N j alpha Ch D c s0 hk halpha halpha1 hCh hD hc hc1 hNlo hNhi hs0 hs1 hj
  have hβ : 0<alpha-1 := sub_pos.mpr halpha
  have hβ1 : alpha-1≤1/2 := by linarith only [halpha1]
  have hg : 0<fractionalPart alpha := by rw [(near_one_order halpha halpha1).2];exact hβ
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order halpha halpha1).2];linarith only [halpha1]
  have hL := upperDegree_pos halpha hCL hcL (one_le_rootMultiplier (k:=k) (ε:=eps) halpha hg hg1)
  have hNr : 0<(N:ℝ) := (mul_pos hq hL).trans_le hNlo
  have hN : 0<N := by exact_mod_cast hNr
  have hb := upperB_pos (ε:=eps) hk halpha hg hg1 hD hcb hCL hcL
  have ht : 0<upperB k alpha eps D cb CL cL/(N:ℝ)^2 := div_pos hb (sq_pos_of_pos hNr)
  have hr := hratio k alpha Ch D N c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
  have hτ : 0<c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1) := by
    have hh := (lt_div_iff₀ ht).mp (hlo.trans_le hr.1)
    simpa only [zero_mul] using hh
  have hlog := log_abs_of_compact hlo hr.1 hr.2
  have hid : (c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))/
      (upperB k alpha eps D cb CL cL/(N:ℝ)^2)=
      (N:ℝ)^2*((c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))/
        upperB k alpha eps D cb CL cL) := by rw [div_div_eq_mul_div];ring
  rw [hid] at hlog
  have hamp := ha k alpha Ch halpha halpha1 hCh
  have hE := upper_reserved_interval (k:=k) halpha hg hg1 heps hCh
  have hEpos : 0<upperE0 k alpha eps Ch := (mul_pos heps hβ).trans_le hE.1
  have hw : 0≤upperOmega k alpha eps Ch cw := (Real.exp_pos _).le
  have hw1 : upperOmega k alpha eps Ch cw<1 := Real.exp_lt_one_iff.mpr (by nlinarith)
  have hz := (upperOverlapZ_spec hg hg1 hEpos).1
  have hcoeff := overlap_coefficients_unit hg hg1 hz.1 hz.2
  have hA0 : 0≤overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*
      Real.exp (-M*(alpha-1)) := mul_nonneg hcoeff.1.le (Real.exp_pos _).le
  have hA1 : overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*
      Real.exp (-M*(alpha-1))≤1 :=
    (mul_le_of_le_one_left (Real.exp_pos _).le hcoeff.2.1.le).trans
      (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hβ]))
  have hbnd := nearOneCoupledPolynomial_beta_coefficients_exponential hN hj hβ hβ1 hτ hb
    hf hf1 hw hw1 hA0 hA1 hCa.le hlog hamp.1 hamp.2
  have hscaled : |(actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f s0).coeff j| *
      (upperB k alpha eps D cb CL cL)^j≤
      (upperB k alpha eps D cb CL cL)^alpha*F*(alpha-1)*Real.exp (d*(N:ℝ)) := by
    unfold actualNearOnePolynomial
    rw [coeff_C_mul,abs_mul,abs_of_nonneg hs0]
    have hs := mul_le_of_le_one_left
      (show 0≤|(nearOneCoupledPolynomial N (alpha-1)
        (c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))
        (upperB k alpha eps D cb CL cL) f (upperOmega k alpha eps Ch cw)
        (overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(alpha-1)))
        (overlapB (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(2-alpha)))).coeff j| *
        (upperB k alpha eps D cb CL cL)^j by positivity) hs1
    have hbnd' := hbnd
    rw [show 1+(alpha-1)=alpha by ring] at hbnd'
    change _≤(upperB k alpha eps D cb CL cL)^alpha*F*(alpha-1)*Real.exp (d*(N:ℝ)) at hbnd'
    nlinarith only [hs,hbnd']
  have he : Real.exp (d*(N:ℝ))≤Real.exp (K*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)) := by
    apply Real.exp_le_exp.mpr
    have h1 := mul_le_mul_of_nonneg_left hNhi hd.le
    have h2 := mul_le_mul_of_nonneg_right hdK hL.le
    nlinarith only [h1,h2]
  have hFK' := mul_le_mul_of_nonneg_left hFK (show 0≤(upperB k alpha eps D cb CL cL)^alpha*(alpha-1) by positivity)
  have hfinal := mul_le_mul hFK' he (Real.exp_pos _).le (show 0≤(upperB k alpha eps D cb CL cL)^alpha*(alpha-1)*K by positivity)
  apply hscaled.trans
  nlinarith only [hfinal]

end Renyi
