import Renyi.Model

/-!
# Uniform degree arithmetic for the upper construction

The floor and ceiling are the actual integer implementation choices from
`upcal:parameters`. Bounds are uniform over the order and root multiplier.
-/

noncomputable section
namespace Renyi

def upperDegree (alpha CL cL X : ℝ) : ℕ :=
  Nat.ceil (alpha * (CL + cL * Real.log X))

def upperOrderFloor (alpha : ℝ) : ℕ := Nat.floor alpha

theorem upperOrderFloor_one_le {alpha : ℝ} (halpha : 1 < alpha) :
    1 ≤ upperOrderFloor alpha :=
  (Nat.one_le_floor_iff alpha).mpr halpha.le

theorem upperOrderFloor_le {alpha : ℝ} (halpha : 1 < alpha) :
    (upperOrderFloor alpha : ℝ) ≤ alpha := Nat.floor_le (by linarith)

theorem alpha_lt_twice_upperOrderFloor {alpha : ℝ} (halpha : 1 < alpha) :
    alpha < 2 * (upperOrderFloor alpha : ℝ) := by
  have h1 : (1 : ℝ) ≤ upperOrderFloor alpha := by
    exact_mod_cast upperOrderFloor_one_le halpha
  have h2 := Nat.lt_floor_add_one alpha
  change alpha < (upperOrderFloor alpha : ℝ) + 1 at h2
  linarith

theorem upperOrderFloor_eq_intFloor {alpha : ℝ} (halpha : 1 < alpha) :
    (upperOrderFloor alpha : ℝ) = (⌊alpha⌋ : ℤ) :=
  natCast_floor_eq_intCast_floor (by linarith)

theorem fractionalPart_eq_upperOrderFloor {alpha : ℝ} (halpha : 1 < alpha) :
    fractionalPart alpha = alpha - (upperOrderFloor alpha : ℝ) := by
  rw [upperOrderFloor_eq_intFloor halpha]
  rfl

theorem fractionalPart_le_order_gap {alpha : ℝ} (halpha : 1 < alpha) :
    fractionalPart alpha ≤ alpha - 1 := by
  rw [fractionalPart_eq_upperOrderFloor halpha]
  have h : (1 : ℝ) ≤ upperOrderFloor alpha := by
    exact_mod_cast upperOrderFloor_one_le halpha
  linarith

theorem upperDegree_ge_exact (alpha CL cL X : ℝ) :
    alpha * (CL + cL * Real.log X) ≤ (upperDegree alpha CL cL X : ℝ) :=
  Nat.le_ceil _

/-- The ceiling changes the dimensionless degree by at most one. -/
theorem upperDegree_bounds {alpha CL cL X : ℝ} (halpha : 1 < alpha)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hX : 1 ≤ X) :
    alpha * CL ≤ (upperDegree alpha CL cL X : ℝ) ∧
      (upperDegree alpha CL cL X : ℝ) ≤ alpha * (CL + 1 + cL * Real.log X) := by
  have ht : 0 ≤ Real.log X := Real.log_nonneg hX
  have ha : 0 < alpha := by linarith
  have hC : 0 < CL := by linarith
  constructor
  · apply le_trans _ (upperDegree_ge_exact alpha CL cL X)
    exact mul_le_mul_of_nonneg_left (le_add_of_nonneg_right (mul_nonneg hcL.le ht)) ha.le
  · have hc := Nat.ceil_lt_add_one
      (by positivity : 0 ≤ alpha * (CL + cL * Real.log X))
    change (upperDegree alpha CL cL X : ℝ) < alpha * (CL + cL * Real.log X) + 1 at hc
    nlinarith

theorem upperDegree_pos {alpha CL cL X : ℝ} (halpha : 1 < alpha)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hX : 1 ≤ X) :
    0 < (upperDegree alpha CL cL X : ℝ) := by
  have h := (upperDegree_bounds halpha hCL hcL hX).1
  have ha : 0 < alpha := by linarith
  have hC : 0 < CL := by linarith
  exact lt_of_lt_of_le (mul_pos ha hC) h

/-- Both constants in the source's degree-factor comparison are explicit. -/
theorem upperDegree_factor_bounds {alpha CL cL X : ℝ} (halpha : 1 < alpha)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hX : 1 ≤ X) :
    1 / max (CL + 1) cL ≤
        alpha ^ 3 * (1 + Real.log X) /
          ((upperOrderFloor alpha : ℝ) ^ 2 * (upperDegree alpha CL cL X : ℝ)) ∧
      alpha ^ 3 * (1 + Real.log X) /
          ((upperOrderFloor alpha : ℝ) ^ 2 * (upperDegree alpha CL cL X : ℝ)) ≤
        4 / min CL cL := by
  have ha : 0 < alpha := by linarith
  have hC : 0 < CL := by linarith
  have ht : 0 ≤ Real.log X := Real.log_nonneg hX
  have hm1 : (1 : ℝ) ≤ upperOrderFloor alpha := by
    exact_mod_cast upperOrderFloor_one_le halpha
  have hmpos : 0 < (upperOrderFloor alpha : ℝ) := by linarith
  have hm := upperOrderFloor_le halpha
  have hma := alpha_lt_twice_upperOrderFloor halpha
  have hd := upperDegree_pos halpha hCL hcL hX
  have hdu := (upperDegree_bounds halpha hCL hcL hX).2
  have hdl := upperDegree_ge_exact alpha CL cL X
  have hU : 0 < max (CL + 1) cL := lt_of_lt_of_le (by linarith) (le_max_left _ _)
  have hl : 0 < min CL cL := lt_min hC hcL
  have hden : 0 < (upperOrderFloor alpha : ℝ) ^ 2 *
      (upperDegree alpha CL cL X : ℝ) := mul_pos (sq_pos_of_pos hmpos) hd
  have hupper : (upperDegree alpha CL cL X : ℝ) ≤
      alpha * max (CL + 1) cL * (1 + Real.log X) := by
    have hb : CL + 1 + cL * Real.log X ≤ max (CL + 1) cL * (1 + Real.log X) := by
      have hmul := mul_le_mul_of_nonneg_right (le_max_right (CL + 1) cL) ht
      nlinarith [le_max_left (CL + 1) cL]
    have hmul := mul_le_mul_of_nonneg_left hb ha.le
    nlinarith
  have hlower : alpha * min CL cL * (1 + Real.log X) ≤
      (upperDegree alpha CL cL X : ℝ) := by
    have hb : min CL cL * (1 + Real.log X) ≤ CL + cL * Real.log X := by
      have hmul := mul_le_mul_of_nonneg_right (min_le_right CL cL) ht
      nlinarith [min_le_left CL cL]
    have hmul := mul_le_mul_of_nonneg_left hb ha.le
    nlinarith
  have hmsq : (upperOrderFloor alpha : ℝ) ^ 2 ≤ alpha ^ 2 :=
    pow_le_pow_left₀ hmpos.le hm 2
  have hasq : alpha ^ 2 ≤ 4 * (upperOrderFloor alpha : ℝ) ^ 2 := by nlinarith
  constructor
  · apply (div_le_div_iff₀ hU hden).mpr
    have h := mul_le_mul hmsq hupper hd.le (sq_nonneg alpha)
    nlinarith [h]
  · apply (div_le_div_iff₀ hden hl).mpr
    have h := mul_le_mul hasq hlower
      (by positivity : 0 ≤ alpha * min CL cL * (1 + Real.log X))
      (by positivity : 0 ≤ 4 * (upperOrderFloor alpha : ℝ) ^ 2)
    nlinarith [h]

/-- The normalized degree stays bounded even when the root multiplier grows. -/
theorem upperDegree_over_alpha_X_le {alpha CL cL X : ℝ} (halpha : 1 < alpha)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hX : 1 ≤ X) :
    (upperDegree alpha CL cL X : ℝ) / (alpha * X) ≤ CL + 1 + cL := by
  have ha : 0 < alpha := by linarith
  have hx : 0 < X := by linarith
  have hL := (upperDegree_bounds halpha hCL hcL hX).2
  have hlog := Real.log_le_self hx.le
  have hc : 0 ≤ CL + 1 := by linarith
  have hpart : CL + 1 + cL * Real.log X ≤ (CL + 1 + cL) * X := by
    have h1 := mul_le_mul_of_nonneg_left hX hc
    have h2 := mul_le_mul_of_nonneg_left hlog hcL.le
    nlinarith
  have hh := mul_le_mul_of_nonneg_left hpart ha.le
  apply (div_le_iff₀ (mul_pos ha hx)).mpr
  nlinarith

end Renyi
