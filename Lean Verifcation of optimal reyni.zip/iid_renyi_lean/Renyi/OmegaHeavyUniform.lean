import Renyi.OmegaHeavy

/-! Explicit distribution-independent heavy concentration constants. -/
set_option maxHeartbeats 800000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def heavyConcentrationScale (t rho : ℝ) : ℝ :=
  1+2/t+1/(t*(1-2*t))+(4/(t*rho))^2

def omegaHeavyScale (eps c0 rho : ℝ) : ℝ :=
  heavyConcentrationScale (omegaHeavyTolerance eps c0) rho

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

theorem analyticCount_heavy_concentration_explicit {t rho : ℝ}
    (ht : 0 < t) (ht1 : t < 1 / 8) (hrho : 0 < rho) (hrho1 : rho < 1) :
    1 ≤ heavyConcentrationScale t rho ∧ ∀ (k : ℕ) (a : ℝ), 1 ≤ a →
      ∀ (N : Fin k → Ω → ℕ) (lam : Fin k → ℝ≥0),
        (∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i))) →
        (∀ i, heavyConcentrationScale t rho * a ≤ (lam i : ℝ)) →
        μ.real {ω | ¬ ((1 - 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a ≤
          ∑ i, analyticCount a (N i ω) ∧
          (∑ i, analyticCount a (N i ω)) ≤ (1 + 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a)}
          ≤ rho := by
  let B := heavyConcentrationScale t rho
  have hinner : 0 < t * (1 - 2 * t) := mul_pos ht (by linarith)
  have hB1 : 1 ≤ B := by dsimp [B,heavyConcentrationScale]; nlinarith [div_pos (by norm_num : (0:ℝ)<2) ht, div_pos (by norm_num : (0:ℝ)<1) hinner, sq_nonneg (4 / (t * rho))]
  have hB0 : 0 < B := zero_lt_one.trans_le hB1
  have h2 : 2 / t ≤ B := by dsimp [B,heavyConcentrationScale]; nlinarith [div_pos (by norm_num : (0:ℝ)<1) hinner, sq_nonneg (4 / (t * rho))]
  have h3 : 1 / (t * (1 - 2 * t)) ≤ B := by dsimp [B,heavyConcentrationScale]; nlinarith [div_pos (by norm_num : (0:ℝ)<2) ht, sq_nonneg (4 / (t * rho))]
  have h4 : (4 / (t * rho)) ^ 2 ≤ B := by dsimp [B,heavyConcentrationScale]; nlinarith [div_pos (by norm_num : (0:ℝ)<2) ht, div_pos (by norm_num : (0:ℝ)<1) hinner]
  have hshift : 1 / B ≤ t / 2 := by
    have h := (div_le_iff₀ ht).mp h2
    apply (div_le_iff₀ hB0).2
    nlinarith
  have hcorr : 1 / B ≤ t * (1 - 2 * t) := by
    have h := (div_le_iff₀ hinner).mp h3
    apply (div_le_iff₀ hB0).2
    nlinarith
  have hsqrt : 4 / (t * rho) ≤ Real.sqrt B := by
    have h := Real.sqrt_le_sqrt h4
    rwa [Real.sqrt_sq (by positivity)] at h
  have hsqrt0 : 0 < Real.sqrt B := Real.sqrt_pos.mpr hB0
  have htail : 1 / ((t / 2) * Real.sqrt B) ≤ rho / 2 := by
    have h := (div_le_iff₀ (mul_pos ht hrho)).mp hsqrt
    apply (div_le_iff₀ (mul_pos (by positivity) hsqrt0)).2
    nlinarith
  refine ⟨hB1, ?_⟩
  intro k a ha N lam hLaw hl
  rcases eq_or_lt_of_le (Nat.zero_le k) with rfl | hk
  · simp only [Finset.univ_eq_empty, Finset.sum_empty, mul_zero, le_refl, and_self,
      not_true_eq_false, Set.setOf_false, measureReal_empty]
    exact hrho.le
  have hsub : {ω | ¬ ((1 - 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a ≤
      ∑ i, analyticCount a (N i ω) ∧
      (∑ i, analyticCount a (N i ω)) ≤ (1 + 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a)} ⊆
      {ω | (t / 2) * finiteLNorm a (fun i => (lam i : ℝ)) <
        finiteLNorm a (fun i => (N i ω : ℝ) - lam i)} := by
    intro ω hw
    by_contra hc
    exact hw (signed_count_heavy_enclosure ha ht (by linarith) hB0 hshift hcorr
      (fun i => N i ω) (fun i => (lam i : ℝ)) hl (le_of_not_gt hc))
  apply (measureReal_mono (μ := μ) hsub).trans
  apply (poisson_vector_norm_tail hk (by linarith) hB1 (by positivity) N lam hLaw hl).trans
  have hx0 : 0 ≤ 1 / ((t / 2) * Real.sqrt B) := by positivity
  have hx1 : 1 / ((t / 2) * Real.sqrt B) ≤ 1 := by linarith
  have hp := Real.rpow_le_self_of_le_one hx0 hx1 ha
  nlinarith


theorem high_mean_gamma_concentration_explicit {t rho : ℝ}
    (ht : 0 < t) (ht1 : t < 1 / 8) (hrho : 0 < rho) (hrho1 : rho < 1) :
    1 ≤ heavyConcentrationScale t rho ∧ ∀ (k : ℕ) (a : ℝ), 3 / 2 ≤ a →
      ∀ (N : Fin k → Ω → ℕ) (lam : Fin k → ℝ≥0),
        (∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i))) →
        (∀ i, heavyConcentrationScale t rho * a ≤ (lam i : ℝ)) →
        1 - rho ≤ μ.real {ω | (1 - 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a ≤
          ∑ i, analyticCount a (N i ω) ∧
          (∑ i, analyticCount a (N i ω)) ≤ (1 + 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a} := by
  obtain ⟨hB, hconc⟩ := analyticCount_heavy_concentration_explicit (μ := μ) ht ht1 hrho hrho1
  refine ⟨hB, ?_⟩
  intro k a ha N lam hLaw hl
  have h := hconc k a (by linarith) N lam hLaw hl
  have hmeas : Measurable (fun ω => ∑ i, analyticCount a (N i ω)) := by
    apply Finset.measurable_sum
    intro i _
    exact (measurable_of_countable (analyticCount a)).comp (hLaw i).measurable
  have hset : MeasurableSet {ω | (1 - 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a ≤
      ∑ i, analyticCount a (N i ω) ∧
      (∑ i, analyticCount a (N i ω)) ≤ (1 + 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a} :=
    (measurableSet_le measurable_const hmeas).inter (measurableSet_le hmeas measurable_const)
  have hadd := measureReal_add_measureReal_compl (μ := μ) hset
  simp only [measureReal_univ_eq_one] at hadd
  change _ + μ.real {ω | ¬ ((1 - 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a ≤
    ∑ i, analyticCount a (N i ω) ∧
    (∑ i, analyticCount a (N i ω)) ≤ (1 + 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a)} = 1 at hadd
  linarith

theorem omega_heavy_concentration_explicit {eps c0 rho : ℝ}
    (heps : 0 < eps) (hc0 : 0 < c0) (hc01 : c0 < 1)
    (hrho : 0 < rho) (hrho1 : rho < 1) :
    0 < omegaHeavyMargin eps c0 ∧ 1 ≤ omegaHeavyScale eps c0 rho ∧ ∀ (k : ℕ) (a E0 : ℝ), 3 / 2 ≤ a →
      eps * (a - 1) ≤ E0 → E0 ≤ 2 * eps * (a - 1) →
      ∀ (N : Fin k → Ω → ℕ) (lam : Fin k → ℝ≥0),
        (∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i))) →
        (∀ i, omegaHeavyScale eps c0 rho * a ≤ (lam i : ℝ)) →
        let kappa := Real.exp (-(2 * eps * (a - 1)))
        let omega := Real.exp (-c0 * E0)
        1 - rho ≤ μ.real {w | (kappa + omegaHeavyMargin eps c0 * kappa) * ∑ i, (lam i : ℝ) ^ a ≤
          omega * ∑ i, analyticCount a (N i w) ∧
          omega * (∑ i, analyticCount a (N i w)) ≤ (1 - omegaHeavyMargin eps c0 * kappa) * ∑ i, (lam i : ℝ) ^ a} := by
  have hd : 0<omegaHeavyDistance c0 := lt_min (by positivity) (by linarith only [hc01])
  have ht : 0<omegaHeavyTolerance eps c0 := lt_min (by norm_num) (by positivity)
  have ht1 : omegaHeavyTolerance eps c0<1/8 := (min_le_left _ _).trans_lt (by norm_num)
  have hc : 0<omegaHeavyMargin eps c0 := by
    unfold omegaHeavyMargin
    exact sub_pos.mpr (Real.exp_lt_one_iff.mpr (by nlinarith only [mul_pos hd heps]))
  obtain ⟨hB, hconc⟩ := high_mean_gamma_concentration_explicit (μ := μ) ht ht1 hrho hrho1
  refine ⟨hc, hB, ?_⟩
  intro k a E0 ha hElow hEhigh N lam hLaw hmeans
  have h := hconc k a ha N lam hLaw hmeans
  have hscalar := omega_heavy_scalar_margins heps hc0 hc01 ha hElow hEhigh
  have hS : 0 ≤ ∑ i, (lam i : ℝ) ^ a := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (lam i).coe_nonneg _)
  apply h.trans
  refine measureReal_mono ?_ (by finiteness)
  intro w hw
  dsimp only at hw ⊢ hscalar
  constructor
  · have hleft := mul_le_mul_of_nonneg_right hscalar.1 hS
    have hmain := mul_le_mul_of_nonneg_left hw.1 (Real.exp_pos (-c0 * E0)).le
    nlinarith
  · have hright := mul_le_mul_of_nonneg_right hscalar.2 hS
    have hmain := mul_le_mul_of_nonneg_left hw.2 (Real.exp_pos (-c0 * E0)).le
    nlinarith

end Renyi
