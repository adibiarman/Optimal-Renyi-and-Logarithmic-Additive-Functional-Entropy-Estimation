import Renyi.UpperBaseline

/-! Transfer a proved reference count-variance rate to the manuscript's actual margin. -/
noncomputable section
namespace Renyi

lemma count_variance_reference_margin_transfer {V K D C Mref Mactual : ℝ}
    (hK : 0 ≤ K) (hD : 0 < D) (hC : 0 ≤ C) (hMref : 0 < Mref) (hMactual : 0 < Mactual)
    (hV : V / Mref ^ 2 ≤ K / D) (hmargin : Mref ≤ C * Mactual) :
    V ≤ (K * C ^ 2 / D) * Mactual ^ 2 := by
  have hVar := (div_le_iff₀ (sq_pos_of_pos hMref)).mp hV
  have hMsq : Mref ^ 2 ≤ (C * Mactual) ^ 2 :=
    (sq_le_sq₀ hMref.le (mul_nonneg hC hMactual.le)).mpr hmargin
  apply hVar.trans
  apply (mul_le_mul_of_nonneg_left hMsq (div_nonneg hK hD.le)).trans_eq
  ring

lemma count_variance_choose_sample_multiplier {V K D C M eta : ℝ}
    (hD : 0 < D) (heta : 0 < eta) (hDeta : K * C ^ 2 / eta ≤ D)
    (hV : V ≤ (K * C ^ 2 / D) * M ^ 2) : V ≤ eta * M ^ 2 := by
  have hbudget : K * C ^ 2 / D ≤ eta := by
    apply (div_le_iff₀ hD).mpr
    have h := (div_le_iff₀ heta).mp hDeta
    nlinarith
  exact hV.trans (mul_le_mul_of_nonneg_right hbudget (sq_nonneg M))

/-- Source CC10 transfers a reference conditional variance bound to the actual CC11 margin. -/
theorem count_variance_source_margin_transfer {V K D Ebase Eactual kappa u ustar Pstar P Bonus : ℝ}
    (hK : 0 ≤ K) (hD : 0 < D) (hEbase : 0 < Ebase) (hEactual : 0 ≤ Eactual)
    (hkappa : 0 < kappa) (hu : 0 < u) (hustar : 0 < ustar)
    (hPstar : 0 < Pstar) (hPP : Pstar ≤ P) (hBonus : 0 ≤ Bonus)
    (hbase : Ebase ≤ Eactual + kappa * u / ustar)
    (hV : V / (Ebase * Pstar + kappa * u * P + kappa * Bonus) ^ 2 ≤ K / D) :
    V ≤ (K * (1 + 1 / ustar) ^ 2 / D) *
      (Eactual * Pstar + kappa * u * P + kappa * Bonus) ^ 2 := by
  have hP : 0 < P := hPstar.trans_le hPP
  have hMref : 0 < Ebase * Pstar + kappa * u * P + kappa * Bonus := by positivity
  have hMactual : 0 < Eactual * Pstar + kappa * u * P + kappa * Bonus := by positivity
  have hC : 0 ≤ 1 + 1 / ustar := by positivity
  exact count_variance_reference_margin_transfer hK hD hC hMref hMactual hV
    (baseline_margin_transfer hEactual hkappa.le hu.le hustar hPstar.le hPP hBonus hbase)

end Renyi
