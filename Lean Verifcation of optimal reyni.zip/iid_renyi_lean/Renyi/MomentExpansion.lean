import Renyi.PoissonOverlap
import Mathlib.Data.Nat.Choose.Sum

/-!
# Exact moment expansion for finite signed Poisson mixtures

Both sides of the expansion are proved to be convergent series. The weights
may be signed, so a difference of two finitely supported priors is included.
Matching ordinary moments is then shown to cancel the corresponding centered
moments, and hence the entire initial segment of the series.
-/

noncomputable section
open scoped BigOperators NNReal
open ProbabilityTheory
namespace Renyi

def signedPoissonMass {m : ℕ} (ν : ℝ≥0) (u : Fin m → ℝ≥0)
    (w : Fin m → ℝ) (j : ℕ) : ℝ :=
  ∑ i, w i * poissonPMFReal (ν * u i) j

def signedRawMoment {m : ℕ} (u : Fin m → ℝ≥0)
    (w : Fin m → ℝ) (ℓ : ℕ) : ℝ :=
  ∑ i, w i * (u i : ℝ) ^ ℓ

def signedCenteredMoment {m : ℕ} (base : ℝ≥0) (u : Fin m → ℝ≥0)
    (w : Fin m → ℝ) (ℓ : ℕ) : ℝ :=
  ∑ i, w i * ((u i : ℝ) - base) ^ ℓ

def signedPoissonOverlap {m : ℕ} (ν base : ℝ≥0)
    (u : Fin m → ℝ≥0) (w : Fin m → ℝ) : ℝ :=
  ∑ i, ∑ k, (w i * w k) *
    Real.exp ((ν : ℝ) * ((u i : ℝ) - base) * ((u k : ℝ) - base) / base)

def poissonMomentTerm {m : ℕ} (ν base : ℝ≥0)
    (u : Fin m → ℝ≥0) (w : Fin m → ℝ) (ℓ : ℕ) : ℝ :=
  (ν : ℝ) ^ ℓ / ((ℓ.factorial : ℝ) * (base : ℝ) ^ ℓ) *
    signedCenteredMoment base u w ℓ ^ 2

theorem finite_weighted_square {m : ℕ} (w a : Fin m → ℝ) (p : ℝ) :
    (∑ i, w i * a i) ^ 2 * p =
      ∑ i, ∑ k, (w i * w k) * (a i * a k * p) := by
  simp only [pow_two, Finset.sum_mul, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro k _
  ring

/-- The finite signed mixture has the expected reference-density formula. -/
theorem signedPoissonMass_density {m : ℕ} (ν base : ℝ≥0)
    (u : Fin m → ℝ≥0) (w : Fin m → ℝ) (hbase : 0 < base) (j : ℕ) :
    signedPoissonMass ν u w j =
      (∑ i, w i * poissonLikelihood ν base (u i) j) *
        poissonPMFReal (ν * base) j := by
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i _
  rw [mul_assoc, poissonLikelihood_density ν base (u i) hbase j]

/-- Convergence and value of the weighted squared difference of actual count masses.
Lean's division convention also covers zero exposure, when both masses vanish
at every positive count. -/
theorem signedPoisson_distance_hasSum {m : ℕ} (ν base : ℝ≥0)
    (u : Fin m → ℝ≥0) (w : Fin m → ℝ) (hbase : 0 < base) :
    HasSum (fun j : ℕ => signedPoissonMass ν u w j ^ 2 /
      poissonPMFReal (ν * base) j) (signedPoissonOverlap ν base u w) := by
  have h := hasSum_sum (s := (Finset.univ : Finset (Fin m)))
    (fun i _ => hasSum_sum (s := (Finset.univ : Finset (Fin m)))
      (fun k _ => (poisson_overlap_hasSum ν base (u i) (u k) hbase).mul_left
        (w i * w k)))
  apply h.congr_fun
  intro j
  rw [signedPoissonMass_density ν base u w hbase j]
  have hs : ((∑ i, w i * poissonLikelihood ν base (u i) j) *
      poissonPMFReal (ν * base) j) ^ 2 / poissonPMFReal (ν * base) j =
      (∑ i, w i * poissonLikelihood ν base (u i) j) ^ 2 *
        poissonPMFReal (ν * base) j := by
    by_cases hp : poissonPMFReal (ν * base) j = 0
    · simp [hp]
    · field_simp
  rw [hs, finite_weighted_square]

/-- The exponential kernel expands into a convergent series of squared centered moments. -/
theorem poisson_moment_hasSum {m : ℕ} (ν base : ℝ≥0)
    (u : Fin m → ℝ≥0) (w : Fin m → ℝ) :
    HasSum (poissonMomentTerm ν base u w) (signedPoissonOverlap ν base u w) := by
  have he (i k : Fin m) := (NormedSpace.expSeries_div_hasSum_exp ℝ
    ((ν : ℝ) * ((u i : ℝ) - base) * ((u k : ℝ) - base) / base)).mul_left
      (w i * w k)
  simp only [← Real.exp_eq_exp_ℝ] at he
  have h := hasSum_sum (s := (Finset.univ : Finset (Fin m)))
    (fun i _ => hasSum_sum (s := (Finset.univ : Finset (Fin m))) (fun k _ => he i k))
  apply h.congr_fun
  intro ℓ
  unfold poissonMomentTerm signedCenteredMoment
  rw [mul_comm, finite_weighted_square]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro k _
  simp only [div_pow, mul_pow]
  ring

/-- Exact moment expansion for an arbitrary finite atomic signed measure. -/
theorem poisson_moment_expansion {m : ℕ} (ν base : ℝ≥0)
    (u : Fin m → ℝ≥0) (w : Fin m → ℝ) (hbase : 0 < base) :
    (∑' j : ℕ, signedPoissonMass ν u w j ^ 2 / poissonPMFReal (ν * base) j) =
      ∑' ℓ : ℕ, poissonMomentTerm ν base u w ℓ := by
  rw [(signedPoisson_distance_hasSum ν base u w hbase).tsum_eq,
    (poisson_moment_hasSum ν base u w).tsum_eq]

/-- The binomial theorem expresses every centered moment through ordinary moments. -/
theorem signedCenteredMoment_binomial {m : ℕ} (base : ℝ≥0)
    (u : Fin m → ℝ≥0) (w : Fin m → ℝ) (ℓ : ℕ) :
    signedCenteredMoment base u w ℓ =
      ∑ j ∈ Finset.range (ℓ + 1), (-(base : ℝ)) ^ (ℓ - j) *
        (ℓ.choose j : ℝ) * signedRawMoment u w j := by
  unfold signedCenteredMoment
  simp_rw [sub_eq_add_neg, add_pow, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  simp only [signedRawMoment, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  ring

/-- Vanishing ordinary moments through degree `L` imply vanishing centered moments. -/
theorem signedCenteredMoment_eq_zero {m L : ℕ} (base : ℝ≥0)
    (u : Fin m → ℝ≥0) (w : Fin m → ℝ)
    (hmatch : ∀ j ≤ L, signedRawMoment u w j = 0) {ℓ : ℕ} (hℓ : ℓ ≤ L) :
    signedCenteredMoment base u w ℓ = 0 := by
  rw [signedCenteredMoment_binomial]
  apply Finset.sum_eq_zero
  intro j hj
  have hjL : j ≤ L := by have := Finset.mem_range.mp hj; omega
  rw [hmatch j hjL, mul_zero]

/-- Moment matching removes the initial `L + 1` terms without changing the sum. -/
theorem poisson_moment_tail_hasSum {m L : ℕ} (ν base : ℝ≥0)
    (u : Fin m → ℝ≥0) (w : Fin m → ℝ)
    (hmatch : ∀ j ≤ L, signedRawMoment u w j = 0) :
    HasSum (fun k : ℕ => poissonMomentTerm ν base u w (k + (L + 1)))
      (signedPoissonOverlap ν base u w) := by
  have hprefix : (∑ j ∈ Finset.range (L + 1), poissonMomentTerm ν base u w j) = 0 := by
    apply Finset.sum_eq_zero
    intro j hj
    have hjL : j ≤ L := Nat.le_of_lt_succ (Finset.mem_range.mp hj)
    simp [poissonMomentTerm, signedCenteredMoment_eq_zero base u w hmatch hjL]
  have h := (hasSum_nat_add_iff' (L + 1)).mpr (poisson_moment_hasSum ν base u w)
  simpa only [hprefix, sub_zero] using h

/-- The exact weighted count distance starts at the first unmatched degree. -/
theorem poisson_moment_expansion_tail {m L : ℕ} (ν base : ℝ≥0)
    (u : Fin m → ℝ≥0) (w : Fin m → ℝ) (hbase : 0 < base)
    (hmatch : ∀ j ≤ L, signedRawMoment u w j = 0) :
    (∑' j : ℕ, signedPoissonMass ν u w j ^ 2 / poissonPMFReal (ν * base) j) =
      ∑' k : ℕ, poissonMomentTerm ν base u w (k + (L + 1)) := by
  rw [(signedPoisson_distance_hasSum ν base u w hbase).tsum_eq,
    (poisson_moment_tail_hasSum ν base u w hmatch).tsum_eq]

/-- Direct formulation for two priors on a common finite support. The identity
holds for arbitrary real weights, hence in particular for probability weights.
The only matching hypotheses are equality of their ordinary moments. -/
theorem poisson_matched_priors_expansion {m L : ℕ} (ν base : ℝ≥0)
    (u : Fin m → ℝ≥0) (p q : Fin m → ℝ) (hbase : 0 < base)
    (hmatch : ∀ j ≤ L, signedRawMoment u p j = signedRawMoment u q j) :
    (∑' j : ℕ, (signedPoissonMass ν u p j - signedPoissonMass ν u q j) ^ 2 /
      poissonPMFReal (ν * base) j) =
      ∑' k : ℕ, poissonMomentTerm ν base u (fun i => p i - q i) (k + (L + 1)) := by
  have hzero : ∀ j ≤ L, signedRawMoment u (fun i => p i - q i) j = 0 := by
    intro j hj
    simp only [signedRawMoment, sub_mul, Finset.sum_sub_distrib]
    exact sub_eq_zero.mpr (hmatch j hj)
  simpa only [signedPoissonMass, sub_mul, Finset.sum_sub_distrib] using
    poisson_moment_expansion_tail ν base u (fun i => p i - q i) hbase hzero

end Renyi
