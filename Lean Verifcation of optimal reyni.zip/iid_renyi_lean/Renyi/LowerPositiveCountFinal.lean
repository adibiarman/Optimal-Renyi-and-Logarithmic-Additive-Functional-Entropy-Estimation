import Renyi.LowerActualSecondMoments
import Renyi.LowerDefectScale
import Renyi.LowerMeanExponential
import Renyi.LowerCountBudget

/-! Actual positive-orientation mean and count calibration. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 400000

theorem lower_actual_positive_count_envelopes {τ : Type*} [Fintype τ]
    (p₀ p₁ : FiniteAtomicPrior τ) {k r : ℕ} {s ε : ℝ}
    (hk : 0<k) (hr : 2≤r) (hs : 0<s) (hs1 : s≤1/2) (hε : 0<ε) (hε1 : ε≤1/2)
    (hx : lowerPriorRootCutoff ε≤rootMultiplier k ((r:ℝ)+s) ε) :
    let α := (r:ℝ)+s
    let x := rootMultiplier k α ε
    let L := Nat.ceil (10*α*(1+Real.log x))
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let ds : ℝ := ((r-1:ℕ):ℝ)+1
    let dc : ℝ := ((L-r:ℕ):ℝ)+1
    let bs := (ζ/8)/ds^2
    let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
    let a := θ/((1/100)*(L:ℝ)*ac)
    let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
    let us := chebyshevNode (r-1) bs
    let uc := chebyshevNode (L-r) ((1-s)/dc^2)
    let l := normalizedInterpolation us a ρ s
    let t := normalizedInterpolation uc ac 0 (1-s)
    let U := interpolationNodes us a
    let V := interpolationNodes uc ac
    let B := (a*ac)⁻¹
    let Z := tensorNormalizer l t U V a α
    let Rs := ∑ i,negativeCoeff (l i)
    let Rc := ∑ j,negativeCoeff (t j)
    let D := B^((r:ℝ)-1)/Z*(a^(-s)*ac⁻¹/(interpolationNormalizer us a ρ s*interpolationNormalizer uc ac 0 (1-s)))
    0<Z →
    priorMoment p₀ α=B^(α-1)/Z*(Rs+Rc) →
    priorMoment p₁ α=B^(α-1)/Z*(1+Rs*Rc) →
    D≤Real.exp ((20+2/c)*r)/ζ ∧
    priorMoment p₀ α≤(lowerPriorIntensityConstant ε)^(-1/2:ℝ)*Real.exp ((20+2/c)*r)/ζ ∧
    priorMoment p₁ α≤(lowerPriorIntensityConstant ε)^(-1/2:ℝ)*Real.exp ((20+2/c)*r)/ζ := by
  let α := (r : ℝ)+s
  let x := rootMultiplier k α ε
  let L := Nat.ceil (10*α*(1+Real.log x))
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ds : ℝ := ((r-1 : ℕ) : ℝ)+1
  let dc : ℝ := ((L-r : ℕ) : ℝ)+1
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*(L : ℝ)*ac)
  have hrR : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hα : 3/2 ≤ α := by dsimp [α]; linarith
  have hα1 : 1 < α := by linarith
  have hα0 : 0 < α := by linarith
  have hγ : fractionalPart α = s := fractionalPart_nat_add_small r hs.le (by linarith)
  have hγ₀ : 0 < fractionalPart α := by rwa [hγ]
  have hγ₁ : fractionalPart α < 1 := by rw [hγ]; linarith
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hx0 : 0 < x := by linarith
  have hlog : 0 ≤ Real.log x := Real.log_nonneg (by linarith)
  have hLlo : 10*α*(1+Real.log x) ≤ (L : ℝ) := Nat.le_ceil _
  have _hLr : r ≤ L := by
    have : (r : ℝ) ≤ L := by dsimp [α] at *; nlinarith
    exact_mod_cast this
  have hds : 0 < ds := by dsimp [ds]; positivity
  have hdc : 0 < dc := by dsimp [dc]; positivity
  have hds_eq : ds = (r : ℝ) := by
    dsimp [ds]
    rw [Nat.cast_sub (by omega : 1 ≤ r)]
    push_cast
    ring
  have hdchi : dc ≤ (L : ℝ)+1 := by
    dsimp [dc]
    exact add_le_add_right (by exact_mod_cast (Nat.sub_le L r)) 1
  have hdim : ds*dc ≤ α*((L : ℝ)+1) := by
    have h1 := mul_le_mul_of_nonneg_left hdchi (by positivity : 0 ≤ ds)
    rw [hds_eq] at h1
    have h2 := mul_le_mul_of_nonneg_right (show (r : ℝ) ≤ α by dsimp [α]; linarith)
      (show 0 ≤ (L : ℝ)+1 by positivity)
    rw [hds_eq]
    exact h1.trans h2
  have hc := lowerPriorCoefficient_bounds hε
  have hc0 : 0<c := hc.1
  have hβ0 : 0 < α-1 := sub_pos.mpr hα1
  have hE : 0 < E := by dsimp [E]; positivity
  have hv : 0 ≤ v := by dsimp [v]; positivity
  have hw : 0 < w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv
  have hcon := lower_actual_principal_constraints_with_perturbation hk hα hε hs hs1 hγ₀ hγ₁
    (Or.inl hγ.symm) hx hds hdc hdim
  dsimp only at hcon
  let bs := (ζ/8)/ds^2
  let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
  change 0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 ∧ ρ ≤ 1 at hcon
  have hmul : 4*ζ*((ds-1)/ds) = 4*ζ*((r-1 : ℕ) : ℝ)/(((r-1 : ℕ) : ℝ)+1) := by
    dsimp [ds]
    ring
  have hpert : max (((a/bs)^s/κ)*
      Real.exp (4*ζ*((r-1 : ℕ) : ℝ)/(((r-1 : ℕ) : ℝ)+1))-1) 0 * a / bs ≤ ζ := by
    rw [← hmul]
    exact hcon.2.2.2.1
  let us := chebyshevNode (r-1) bs
  let uc := chebyshevNode (L-r) ((1-s)/dc^2)
  let l := normalizedInterpolation us a ρ s
  let t := normalizedInterpolation uc ac 0 (1-s)
  let U := interpolationNodes us a
  let V := interpolationNodes uc ac
  dsimp only
  intro hZ hA₀ hA₁
  have hns : 0<r-1 := by omega
  have hκ0 : 0<κ := Real.exp_pos _
  have hκ1 : κ≤1 := Real.exp_le_one_iff.mpr (by linarith only [hE,hw])
  have hζ0 : 0<ζ := hcon.2.2.2.2.1
  have hζsmall : ζ≤3/5 := by linarith only [hcon.2.2.2.2.2.1]
  have hbs0 : 0<bs := by dsimp [bs]; positivity
  have hbs1 : bs<1 := by
    apply (div_lt_one (by positivity : (0:ℝ)<ds^2)).mpr
    have hds1 : 1≤ds := by dsimp [ds]; exact le_add_of_nonneg_left (Nat.cast_nonneg _)
    nlinarith only [hcon.2.2.2.2.2.1,hds1]
  have hactive := active_interpolation_mass_bound (r-1) ζ a s κ hns hζ0 hζsmall hcon.1 hcon.2.1 hs.le hκ0 hκ1 hpert
  dsimp only at hactive
  rw [←hmul] at hactive
  change (∑ i, negativeCoeff (l i))≤κ ∧ 1/2≤l none at hactive
  have hLα : 10*α≤L := by nlinarith only [hLlo,mul_nonneg hα0.le hlog]
  have hdimlo : α*(L:ℝ)/4≤ds*dc := by
    rw [hds_eq]
    exact lower_nat_dimension_product_lower (by omega : 1≤r)
      (show (r:ℝ)≤α by dsimp [α]; linarith only [hs])
      (show α≤(r:ℝ)+1 by dsimp [α]; linarith only [hs1]) hLα
  let δ := Real.exp (lowerLogSampleConstant ε c/2-4)
  have hδ0 : 0<δ := Real.exp_pos _
  have hratio := lower_actual_active_ratio_floor hk hα hε hs hs1 hγ₀ hγ₁ (Or.inl hγ.symm) hx hds hdc hdim hdimlo
  change δ≤(a/bs)^s/κ at hratio
  have hfloor : δ*κ≤(a/bs)^s := (le_div_iff₀ hκ0).mp hratio
  have hau (i) : a<us i := by
    have hab : a<bs := by linarith only [hcon.1,hcon.2.1]
    exact hab.trans_le (chebyshevNode_bounds (r-1) bs hbs1.le i).1
  have hcancel := low_integer_factor_zero us (chebyshevNode_injective (r-1) bs hbs1)
    (ρ:=ρ) (γ:=s) hcon.1 hau 1 (by norm_num) (by omega) (Or.inl (by omega))
  simp only [Nat.cast_one] at hcancel
  have hEupper : E≤r := by
    have hh := mul_le_mul_of_nonneg_right hε1 (show 0≤2*(α-1) by positivity)
    have hβr : α-1≤r := by dsimp [α]; linarith only [hs1]
    dsimp only [E]
    nlinarith only [hh,hβr]
  have hvupper : v≤1/4 := by
    have hfrac : (α-1)/α≤1 := (div_le_one hα0).mpr (by linarith only)
    have hh := mul_le_mul_of_nonneg_right hfrac (Real.rpow_nonneg hx0.le (-α))
    have hp : x^(-α)≤x^(-1:ℝ) := Real.rpow_le_rpow_of_exponent_le (by linarith only [hx4] : 1≤x) (by linarith only [hα1])
    rw [Real.rpow_neg_one] at hp
    have hi : x⁻¹≤1/4 := by simpa only [one_div] using one_div_le_one_div_of_le (by norm_num : (0:ℝ)<4) hx4
    change v≤1/4
    exact (show v≤x^(-α) by simpa only [one_mul] using hh).trans (hp.trans hi)
  have hwupper : w≤1/2 := by dsimp [w]; nlinarith only [hvupper,sq_nonneg (s-1/2)]
  have hζfloor : (c/2)*s≤ζ := lower_target_fractional_floor hc.1 hs hs1 hE hv
  have hzκ : ζ*κ≤1 := by
    have hh := mul_le_mul_of_nonneg_left hκ1 hζ0.le
    nlinarith only [hh,hcon.2.2.2.2.2.1]
  have hgeom := complementary_factor_geometry (L-r) (show 0<1-s by linarith only [hs1])
    (by linarith only [hs]) (mul_pos hζ0 hκ0) hzκ
  change 0<ac ∧ ∀ i,ac≤V i at hgeom
  have hac : 0<ac := hgeom.1
  have hVp (i) : 0<V i := hac.trans_le (hgeom.2 i)
  have hucp (i) : 0<uc i := hVp (some i)
  have hcom := chebyshev_nodes_weighted (L-r) (1-s) (ζ*κ) (by linarith only [hs1]) (by linarith only [hs])
    (mul_pos hζ0 hκ0) hzκ
  change (∑ j,negativeCoeff (t j))≤Real.exp (-(1-s))*(ζ*κ) ∧ 1/2≤t none at hcom
  have hcom1 : (∑ j,negativeCoeff (t j))≤1 := by
    have he : Real.exp (-(1-s))≤1 := Real.exp_le_one_iff.mpr (by linarith only [hs1])
    exact hcom.1.trans ((mul_le_mul_of_nonneg_right he (mul_pos hζ0 hκ0).le).trans (by simpa only [one_mul] using hzκ))
  have hrawD := active_chebyshev_defect_bound uc (r:=(r:ℝ)) hns hcon.1 hac hcon.2.2.1 hζ0
    hcon.2.2.2.2.2.1 hcon.2.1 hucp hcancel hZ
  have hDexp : 32*(r:ℝ)^2≤Real.exp ((20+2/c)*r) := by
    apply (Real.log_le_iff_le_exp (by positivity : (0:ℝ)<32*(r:ℝ)^2)).mp
    rw [Real.log_mul (by norm_num : (32:ℝ)≠0) (by positivity),Real.log_pow]
    have hlog32 : Real.log (32:ℝ)≤5 := by
      rw [show (32:ℝ)=(2:ℝ)^5 by norm_num,Real.log_pow]
      have hh := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)
      norm_num only [Nat.cast_ofNat]
      nlinarith only [hh]
    have hlogr : Real.log (r:ℝ)≤r := by linarith only [Real.log_le_sub_one_of_pos (by linarith only [hrR] : (0:ℝ)<r)]
    have hpos : 0≤(2/c)*(r:ℝ) := by positivity
    norm_num only [Nat.cast_ofNat]
    nlinarith only [hlog32,hlogr,hpos,hrR]
  have hDsmall : _≤Real.exp ((20+2/c)*r)/ζ := hrawD.trans (by
    change 32*ds^2/ζ≤_
    rw [hds_eq]
    exact div_le_div_of_nonneg_right hDexp hζ0.le)
  have hcnδ : δ⁻¹=Real.exp 4*(lowerPriorIntensityConstant ε)^(-1/2:ℝ) := by
    dsimp [δ,lowerPriorIntensityConstant,c]
    rw [←Real.exp_neg,←Real.exp_mul,←Real.exp_add]
    congr 1
    ring
  have hcoef : 4096*Real.exp 1*ds^4/(δ*κ*(c/2)*ζ)=
      (lowerPriorIntensityConstant ε)^(-1/2:ℝ)*(8192*Real.exp 5*(r:ℝ)^4/(c*κ))/ζ := by
    rw [hds_eq]
    calc
      _=(lowerPriorIntensityConstant ε)^(-1/2:ℝ)*(8192*(Real.exp 1*Real.exp 4)*(r:ℝ)^4/(c*κ))/ζ := by
        simp only [div_eq_mul_inv,mul_inv_rev] at hcnδ ⊢
        rw [hcnδ]
        ring
      _=_ := by rw [←Real.exp_add]; norm_num
  have hmean (p : FiniteAtomicPrior τ) (M : ℝ) (hM : 0≤M) (hM2 : M≤2)
      (hA : priorMoment p α=((a*ac)⁻¹)^(α-1)/tensorNormalizer l t U V a α*M) :
      priorMoment p α≤(lowerPriorIntensityConstant ε)^(-1/2:ℝ)*Real.exp ((20+2/c)*r)/ζ := by
    have hh := tensor_prior_active_mean_shape p t V (r-1) ζ a ρ s α κ δ (c/2) ac M
      hns hζ0 hζsmall hcon.1 hcon.2.2.1 hcon.2.2.2.2.2.2 hs (by linarith only [hs1])
      hκ0 hδ0 (by positivity) (by linarith only [hc.2]) hζfloor hac
      (by dsimp [α]; linarith only [hrR]) hcon.2.1 hcon.2.2.2.1 hactive.2 hfloor hVp hgeom.2
      (normalizedInterpolation_positive_mass uc hac (by norm_num)) hcom1 none rfl
      (hcom.2.trans (le_abs_self _)) hM hM2 hcancel hA
    change priorMoment p α≤4096*Real.exp 1*ds^4/(δ*κ*(c/2)*ζ) at hh
    rw [hcoef] at hh
    apply hh.trans
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left (lower_mean_exponential_envelope hrR hc.1 hEupper hwupper)
        (Real.rpow_nonneg (Real.exp_nonneg _) _)) hζ0.le
  let Rs := ∑ i,negativeCoeff (l i)
  let Rc := ∑ j,negativeCoeff (t j)
  have hRs0 : 0≤Rs := Finset.sum_nonneg (fun _ _ => le_max_right _ _)
  have hRc0 : 0≤Rc := Finset.sum_nonneg (fun _ _ => le_max_right _ _)
  have hRs1 : Rs≤1 := hactive.1.trans hκ1
  have hRc1 : Rc≤1 := hcom1
  refine ⟨hDsmall,hmean p₀ (Rs+Rc) (by positivity) (by linarith only [hRs1,hRc1]) hA₀,
    hmean p₁ (1+Rs*Rc) (by positivity) ?_ hA₁⟩
  have hh := mul_le_one₀ hRs1 hRc0 hRc1
  linarith only [hh]

def lowerPositiveSmallCountConclusion (k r L : ℕ) (s E w c a θ : ℝ) : Prop :=
    let ζ := c * w / (1 - Real.exp (-E))
    let κ := Real.exp (-E - 4 * w)
    let ξ := 1 - s
    let ns := r - 1
    let nc := L - r
    let bs := (ζ / 8) / ((ns : ℝ) + 1) ^ 2
    let bc := ξ / ((nc : ℝ) + 1) ^ 2
    let ac := Real.exp (-5) * bc * (ζ * κ) ^ (1 / ξ)
    let ρ := max (((a / bs) ^ s / κ) *
      Real.exp (4 * ζ * (ns : ℝ) / ((ns : ℝ) + 1)) - 1) 0
    let us := chebyshevNode ns bs
    let uc := chebyshevNode nc bc
    let α := (r:ℝ)+s
    let l := normalizedInterpolation us a ρ s
    let t := normalizedInterpolation uc ac 0 (1-s)
    let U := interpolationNodes us a
    let V := interpolationNodes uc ac
    let Rs := ∑ i, negativeCoeff (l i)
    let Rc := ∑ j, negativeCoeff (t j)
    let B := (a*ac)⁻¹
    let Z := tensorNormalizer l t U V a α
    let D := B^((r:ℝ)-1)/Z*(a^(-s)*ac⁻¹/(interpolationNormalizer us a ρ s*interpolationNormalizer uc ac 0 (1-s)))
    0<Z ∧ 0<D ∧ ∃ p₀ p₁ : FiniteAtomicPrior
      (Option ((Option (Fin ((r-1)+1))) × (Option (Fin ((L-r)+1))))),
      (∀ i, p₀.value i=0 ∨ (1≤p₀.value i ∧ p₀.value i≤B)) ∧
      (∀ i, p₁.value i=0 ∨ (1≤p₁.value i ∧ p₁.value i≤B)) ∧
      priorMoment p₀ 1=1 ∧ priorMoment p₁ 1=1 ∧
      (∀ j : ℕ, 1≤j → j≤L+1 → j≠r → priorMoment p₁ (j:ℝ)=priorMoment p₀ (j:ℝ)) ∧
      priorMoment p₁ α=B^(α-1)/Z*(1+Rs*Rc) ∧
      priorMoment p₀ α=B^(α-1)/Z*(Rs+Rc) ∧
      Real.log (priorMoment p₁ α/priorMoment p₀ α)=Real.log ((1+Rs*Rc)/(Rs+Rc)) ∧
      (∀ j : ℝ, 0<j → priorMoment p₀ j=B^(j-1)/Z*(∑ ij, tensorNegative l t ij*tensorAtom U V a ij^(j-α))) ∧
      (∀ j : ℝ, 0<j → priorMoment p₁ j=B^(j-1)/Z*(∑ ij, tensorPositive l t ij*tensorAtom U V a ij^(j-α))) ∧
      |priorMoment p₁ (r:ℝ)-priorMoment p₀ (r:ℝ)|≤ρ*D ∧
      (∀ j : ℕ, j≤r → Real.exp (-1)*θ^r*D/(j.factorial:ℝ)≤poissonMixture p₀.mass p₀.value θ j) ∧
      (∀ j : ℕ, j≤r → Real.exp (-1)*θ^r*D/(j.factorial:ℝ)≤poissonMixture p₁.mass p₁.value θ j) ∧
      E+w≤Real.log (priorMoment p₁ α/priorMoment p₀ α) ∧ Rs≤κ ∧ Rc≤ζ*κ ∧
      (k:ℝ)*countDistance (poissonMixture p₀.mass p₀.value θ) (poissonMixture p₁.mass p₁.value θ)≤1/32

theorem lower_actual_positive_small_count_priors {k r : ℕ} {s ε : ℝ}
    (hk : 0 < k) (hr : 2 ≤ r) (hs : 0 < s) (hs1 : s ≤ 1/2) (hε : 0 < ε) (hε1 : ε≤1/2)
    (hx : lowerPriorRootCutoff ε ≤ rootMultiplier k ((r : ℝ)+s) ε) :
    let α := (r : ℝ)+s
    let x := rootMultiplier k α ε
    let L := Nat.ceil (10*α*(1+Real.log x))
    let c := lowerPriorCoefficient ε
    let E := 2*ε*(α-1)
    let v := (α-1)/α*x^(-α)
    let w := s*(1-s)+v
    let ζ := c*w/(1-Real.exp (-E))
    let κ := Real.exp (-E-4*w)
    let ac := Real.exp (-5)*((1-s)/(((L-r : ℕ) : ℝ)+1)^2)*(ζ*κ)^(1/(1-s))
    let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
    let a := θ/((1/100)*(L : ℝ)*ac)
    lowerPositiveSmallCountConclusion k r L s E w c a θ := by
  let α := (r : ℝ)+s
  let x := rootMultiplier k α ε
  let L := Nat.ceil (10*α*(1+Real.log x))
  let c := lowerPriorCoefficient ε
  let E := 2*ε*(α-1)
  let v := (α-1)/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := c*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ds : ℝ := ((r-1 : ℕ) : ℝ)+1
  let dc : ℝ := ((L-r : ℕ) : ℝ)+1
  let ac := Real.exp (-5)*((1-s)/dc^2)*(ζ*κ)^(1/(1-s))
  let θ := lowerPriorIntensityConstant ε*α*(k : ℝ)^(-1/α)*x
  let a := θ/((1/100)*(L : ℝ)*ac)
  have hrR : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hα : 3/2 ≤ α := by dsimp [α]; linarith
  have hα1 : 1 < α := by linarith
  have hα0 : 0 < α := by linarith
  have hγ : fractionalPart α = s := fractionalPart_nat_add_small r hs.le (by linarith)
  have hγ₀ : 0 < fractionalPart α := by rwa [hγ]
  have hγ₁ : fractionalPart α < 1 := by rw [hγ]; linarith
  have hx4 : 4 ≤ x := (le_max_left _ _).trans hx
  have hx0 : 0 < x := by linarith
  have hlog : 0 ≤ Real.log x := Real.log_nonneg (by linarith)
  have hLlo : 10*α*(1+Real.log x) ≤ (L : ℝ) := Nat.le_ceil _
  have hLr : r ≤ L := by
    have : (r : ℝ) ≤ L := by dsimp [α] at *; nlinarith
    exact_mod_cast this
  have hds : 0 < ds := by dsimp [ds]; positivity
  have hdc : 0 < dc := by dsimp [dc]; positivity
  have hds_eq : ds = (r : ℝ) := by
    dsimp [ds]
    rw [Nat.cast_sub (by omega : 1 ≤ r)]
    push_cast
    ring
  have hdchi : dc ≤ (L : ℝ)+1 := by
    dsimp [dc]
    exact add_le_add_right (by exact_mod_cast (Nat.sub_le L r)) 1
  have hdim : ds*dc ≤ α*((L : ℝ)+1) := by
    have h1 := mul_le_mul_of_nonneg_left hdchi (by positivity : 0 ≤ ds)
    rw [hds_eq] at h1
    have h2 := mul_le_mul_of_nonneg_right (show (r : ℝ) ≤ α by dsimp [α]; linarith)
      (show 0 ≤ (L : ℝ)+1 by positivity)
    rw [hds_eq]
    exact h1.trans h2
  have hc := lowerPriorCoefficient_bounds hε
  have hc0 : 0<c := hc.1
  have hβ0 : 0 < α-1 := sub_pos.mpr hα1
  have hE : 0 < E := by dsimp [E]; positivity
  have hv : 0 ≤ v := by dsimp [v]; positivity
  have hw : 0 < w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv
  have hcon := lower_actual_principal_constraints hk hα hε hs hs1 hγ₀ hγ₁
    (Or.inl hγ.symm) hx hds hdc hdim
  dsimp only at hcon
  let bs := (ζ/8)/ds^2
  let ρ := max (((a/bs)^s/κ)*Real.exp (4*ζ*((ds-1)/ds))-1) 0
  change 0 < a ∧ a ≤ bs/2 ∧ 0 ≤ ρ ∧ ρ*a/bs ≤ ζ ∧ 0 < ζ ∧ ζ ≤ 1/8 at hcon
  have hmul : 4*ζ*((ds-1)/ds) = 4*ζ*((r-1 : ℕ) : ℝ)/(((r-1 : ℕ) : ℝ)+1) := by
    dsimp [ds]
    ring
  have hpert : max (((a/bs)^s/κ)*
      Real.exp (4*ζ*((r-1 : ℕ) : ℝ)/(((r-1 : ℕ) : ℝ)+1))-1) 0 * a / bs ≤ ζ := by
    rw [← hmul]
    exact hcon.2.2.2.1
  have hθ : 0<θ := by
    dsimp [θ,lowerPriorIntensityConstant]
    exact mul_pos (mul_pos (mul_pos (Real.exp_pos _) hα0)
      (Real.rpow_pos_of_pos (by exact_mod_cast hk) _)) hx0
  have hLpos : (0:ℝ)<L := (show 0<10*α*(1+Real.log x) by positivity).trans_le hLlo
  have hζ0 : 0<ζ := hcon.2.2.2.2.1
  have hξ0 : 0<1-s := by linarith
  have hac : 0<ac := by dsimp [ac,κ]; positivity
  have hκ1 : κ≤1 := Real.exp_le_one_iff.mpr (by linarith only [hE,hw])
  have hLα : 10*α≤L := by nlinarith only [hLlo,mul_nonneg hα0.le hlog]
  have hlong : (L:ℝ)≤2*dc := lower_long_dimension (show (r:ℝ)≤α by dsimp [α]; linarith only [hs]) hLα
  have hscale : θ/a=(1/100)*(L:ℝ)*ac := by dsimp [a]; field_simp
  have hact := lower_actual_principal_constraints_with_activation hk hα hε hs hs1 hγ₀ hγ₁
    (Or.inl hγ.symm) hx hds hdc hdim
  dsimp only at hact
  have hdata := lower_actual_positive_count_priors hk hr hs hs1 hε hx
  dsimp only [lowerPositiveCountConclusion] at hdata
  rw [←hmul] at hdata
  obtain ⟨hZ,hD,p₀,p₁,hp₀,hp₁,hm₀,hm₁,hmatch,hA₁,hA₀,hlogA,hmom₀,hmom₁,hdef,hq₀,hq₁,hgap,hRs,hRc⟩ := hdata
  have henvelopes := lower_actual_positive_count_envelopes p₀ p₁ hk hr hs hs1 hε hε1 hx hZ hA₀ hA₁
  let B := (a*ac)⁻¹
  have hBdef : B=(1/100)*(L:ℝ)/θ := by dsimp [B,a]; field_simp
  have hv₀ (i) : 0≤p₀.value i := (hp₀ i).elim (fun h => h ▸ le_rfl) (fun h => le_trans zero_le_one h.1)
  have hv₁ (i) : 0≤p₁.value i := (hp₁ i).elim (fun h => h ▸ le_rfl) (fun h => le_trans zero_le_one h.1)
  have hb₀ (i) : p₀.value i≤B := (hp₀ i).elim (fun h => h ▸ le_of_lt (by dsimp [B]; positivity)) (fun h => h.2)
  have hb₁ (i) : p₁.value i≤B := (hp₁ i).elim (fun h => h ▸ le_of_lt (by dsimp [B]; positivity)) (fun h => h.2)
  have hcount := lower_actual_small_count_budget p₀ p₁ hk hr hα hε hε1 hs hs1 hγ₀ hγ₁
    (Or.inl hγ.symm) (Or.inl (show α-(r:ℝ)=s by dsimp [α]; ring))
    (show 1<rootMultiplier k α ε by change 1<x; linarith only [hx4]) hLlo rfl hBdef rfl
    hcon.2.2.1 hD hact.2.2.2.2.2.2.2.1 hact.2.2.2.2.2.2.2.2
    henvelopes.1 henvelopes.2.1 henvelopes.2.2 hv₀ hv₁ hb₀ hb₁ hmatch hdef
    (fun j _ hj => hq₀ j hj) (fun j _ hj => hq₁ j hj)
  dsimp only [lowerPositiveSmallCountConclusion]
  rw [←hmul]
  exact ⟨hZ,hD,p₀,p₁,hp₀,hp₁,hm₀,hm₁,hmatch,hA₁,hA₀,hlogA,hmom₀,hmom₁,hdef,hq₀,hq₁,hgap,hRs,hRc,hcount⟩

end Renyi
