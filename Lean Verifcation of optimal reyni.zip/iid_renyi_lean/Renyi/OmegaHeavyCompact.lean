import Renyi.OmegaHeavyTrueSelection

/-! Arbitrarily accurate actual selected-heavy concentration on every bounded order range. -/
noncomputable section
open scoped BigOperators NNReal
open Set MeasureTheory ProbabilityTheory
namespace Renyi

def compactHeavyTolerance (A eta : ℝ) : ℝ := min (1/16) (min (1/(8*A)) (eta/(8*A)))
def compactHeavyScale (A eta rho : ℝ) : ℝ := heavyConcentrationScale (compactHeavyTolerance A eta) rho

lemma compactHeavyTolerance_pos {A eta : ℝ} (hA : 0<A) (heta : 0<eta) :
    0<compactHeavyTolerance A eta := by unfold compactHeavyTolerance;positivity

lemma compactHeavyTolerance_lt {A eta : ℝ} : compactHeavyTolerance A eta<1/8 :=
  (min_le_left _ _).trans_lt (by norm_num)

/-- A fixed norm tolerance converts both heavy enclosure factors into an arbitrary relative error. -/
lemma compact_heavy_scalar_bounds {A eta a : ℝ} (hA : 0<A) (heta : 0<eta)
    (ha : 1≤a) (haA : a≤A) :
    1-eta≤(1-2*compactHeavyTolerance A eta)^a ∧
      (1+2*compactHeavyTolerance A eta)^a≤1+eta := by
  let t := compactHeavyTolerance A eta
  have ht : 0<t := compactHeavyTolerance_pos hA heta
  have ht1 : t<1/8 := compactHeavyTolerance_lt
  have hta : t≤1/(8*A) := (min_le_right _ _).trans (min_le_left _ _)
  have hte : t≤eta/(8*A) := (min_le_right _ _).trans (min_le_right _ _)
  have hta' := (le_div_iff₀ (show 0<8*A by positivity)).mp hta
  have hte' := (le_div_iff₀ (show 0<8*A by positivity)).mp hte
  have hat := mul_le_mul_of_nonneg_right haA ht.le
  have ha0 : 0≤a := zero_le_one.trans ha
  have hscalar : 0≤2*a*t := by positivity
  have hscalar1 : 2*a*t≤1 := by nlinarith only [hat,hta']
  have herror : 4*a*t≤eta := by nlinarith only [hat,hte',heta]
  constructor
  · have hb := one_add_mul_self_le_rpow_one_add (show -1≤ -2*t by linarith only [ht1]) ha
    have hid : 1+ -2*t=1-2*t := by ring
    rw [hid] at hb
    nlinarith only [hb,herror,heta]
  · have hl := Real.log_le_sub_one_of_pos (show 0<1+2*t by positivity)
    have hm := mul_le_mul_of_nonneg_right hl ha0
    have hp : (1+2*t)^a≤Real.exp (2*a*t) := by
      rw [Real.rpow_def_of_pos (show 0<1+2*t by positivity)]
      exact Real.exp_le_exp.mpr (by nlinarith only [hm])
    have he := Real.abs_exp_sub_one_le (show |2*a*t|≤1 by rwa [abs_of_nonneg hscalar])
    have he' := (le_abs_self (Real.exp (2*a*t)-1)).trans he
    rw [abs_of_nonneg hscalar] at he'
    exact hp.trans (by nlinarith only [he',herror])

/-- The compact heavy threshold is fixed before the probability space and distribution. -/
theorem compactHeavyScale_one_le {A eta rho : ℝ} (hA : 0<A) (heta : 0<eta)
    (hrho : 0<rho) (hrho1 : rho<1) : 1≤compactHeavyScale A eta rho := by
  exact (high_mean_gamma_concentration_explicit (μ:=(PMF.pure ()).toMeasure)
    (compactHeavyTolerance_pos hA heta) compactHeavyTolerance_lt hrho hrho1).1

/-- Arbitrary deterministic subsets have the same explicit compact-order concentration scale. -/
theorem compact_heavy_subset_concentration {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {A eta rho : ℝ}
    (hA : 0<A) (heta : 0<eta) (hrho : 0<rho) (hrho1 : rho<1)
    {k : ℕ} {a : ℝ} (ha : 3/2≤a) (haA : a≤A)
    (N : Fin k→Ω→ℕ) (lam : Fin k→ℝ≥0)
    (hLaw : ∀i,MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (S : Finset (Fin k)) (hmean : ∀i∈S,compactHeavyScale A eta rho*a≤(lam i:ℝ)) :
    1-rho≤μ.real {w | |(∑i∈S,analyticCount a (N i w))-(∑i∈S,(lam i:ℝ)^a)|≤
      eta*(∑i∈S,(lam i:ℝ)^a)} := by
  let e := (Fintype.equivFin S).symm
  have hh := (high_mean_gamma_concentration_explicit (μ:=μ)
    (compactHeavyTolerance_pos hA heta) compactHeavyTolerance_lt hrho hrho1).2
      (Fintype.card S) a ha (fun j => N (e j)) (fun j => lam (e j))
      (fun j => hLaw (e j)) (fun j => hmean (e j) (e j).property)
  have hsum (f : Fin k→ℝ) : (∑j:Fin (Fintype.card S),f (e j))=∑i∈S,f i := by
    have he := e.sum_comp (fun i:S => f i)
    simpa only [Finset.sum_coe_sort] using he
  have hsum1 := hsum (fun i => (lam i:ℝ)^a)
  have hsum2 (w : Ω) := hsum (fun i => analyticCount a (N i w))
  simp only [hsum1,hsum2] at hh
  apply hh.trans
  refine measureReal_mono ?_ (by finiteness)
  intro w hw
  have hb := compact_heavy_scalar_bounds hA heta (by linarith only [ha] : 1≤a) haA
  have hS : 0≤∑i∈S,(lam i:ℝ)^a := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (lam i).coe_nonneg a)
  have hl := mul_le_mul_of_nonneg_right hb.1 hS
  have hu := mul_le_mul_of_nonneg_right hb.2 hS
  change _∧_ at hw
  change |(∑i∈S,analyticCount a (N i w))-(∑i∈S,(lam i:ℝ)^a)|≤eta*(∑i∈S,(lam i:ℝ)^a)
  rw [abs_le]
  constructor <;> nlinarith only [hw.1,hw.2,hl,hu]

/-- The independent actual pilot can select the heavy subset arbitrarily. -/
theorem compact_heavy_pilot_subset_concentration {A eta rho : ℝ}
    (hA : 0<A) (heta : 0<eta) (hrho : 0<rho) (hrho1 : rho<1)
    {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) {a : ℝ} (ha : 3/2≤a) (haA : a≤A)
    (S : (Fin k→ℕ)→Finset (Fin k))
    (hmean : ∀y,∀i∈S y,compactHeavyScale A eta rho*a≤(n:ℝ)*p.mass i) :
    1-rho≤(pilotHistogramPMF n cp p).toMeasure.real {h |
      |(∑i∈S (fun i => pilotSelectionCount i h),analyticCount a (pilotMainCount i h))-
        (∑i∈S (fun i => pilotSelectionCount i h),((n:ℝ)*p.mass i)^a)|≤
          eta*(∑i∈S (fun i => pilotSelectionCount i h),((n:ℝ)*p.mass i)^a)} := by
  let μ := (finitePoissonPMF (fun i => n*simplexNN p i)).toMeasure
  let ν := (finitePoissonPMF (fun i => cp*(n*simplexNN p i))).toMeasure
  have hlaw (i : Fin k) : MeasurePreserving (fun x:Fin k→ℕ => x i) μ (poissonMeasure (n*simplexNN p i)) := by
    dsimp [μ]
    rw [finitePoissonPMF,Measure.toPMF_toMeasure]
    exact measurePreserving_eval (fun i => poissonMeasure (n*simplexNN p i)) i
  let E : Set ((Fin k→ℕ)×(Fin k→ℕ)) := {xy |
    |(∑i∈S xy.2,analyticCount a (xy.1 i))-(∑i∈S xy.2,((n:ℝ)*p.mass i)^a)|≤
      eta*(∑i∈S xy.2,((n:ℝ)*p.mass i)^a)}
  have hh : 1-rho≤(μ.prod ν).real E := by
    apply product_section_probability_lower (Set.to_countable _).measurableSet (by linarith only [hrho1])
    intro y
    have hb := compact_heavy_subset_concentration (μ:=μ) hA heta hrho hrho1 ha haA
      (fun i x => x i) (fun i => n*simplexNN p i) hlaw (S y) (by
        intro i hi
        simpa only [NNReal.coe_mul,simplexNN_coe] using hmean y i hi)
    simpa only [NNReal.coe_mul,simplexNN_coe] using hb
  have htransfer := (pilotHistogram_split_law n cp p).measureReal_preimage
    (s:=E) (Set.to_countable E).measurableSet.nullMeasurableSet
  change (pilotHistogramPMF n cp p).toMeasure.real (splitPilotHistogram⁻¹' E)=(μ.prod ν).real E at htransfer
  rw [←htransfer] at hh
  exact hh


/-- A common coefficient in [0,1] preserves the requested normalized error. -/
lemma compact_heavy_normalize {C P nalpha w eta : ℝ} (hn : 0<nalpha)
    (hP : 0≤P) (hw : 0≤w) (hw1 : w≤1) (heta : 0≤eta)
    (herror : |C-nalpha*P|≤eta*(nalpha*P)) :
    |(w/nalpha)*C-w*P|≤eta*P := by
  have hid : (w/nalpha)*C-w*P=(w/nalpha)*(C-nalpha*P) := by field_simp
  rw [hid,abs_mul,abs_of_nonneg (div_nonneg hw hn.le)]
  have hm := mul_le_mul_of_nonneg_left herror (div_nonneg hw hn.le)
  have hid' : (w/nalpha)*(eta*(nalpha*P))=w*(eta*P) := by field_simp
  rw [hid'] at hm
  exact hm.trans (mul_le_of_le_one_left (mul_nonneg heta hP) hw1)

/-- Arbitrarily accurate selected true-heavy concentration in probability units.
The threshold is explicit before all model parameters and permits taking a maximum with other thresholds. -/
theorem compact_heavy_true_selection_concentration {A eta rho : ℝ}
    (hA : 0<A) (heta : 0<eta) (hrho : 0<rho) (hrho1 : rho<1)
    {k : ℕ} (n cp : ℝ≥0) (hn : 0<(n:ℝ)) (p : Simplex k) {a B w : ℝ}
    (ha : 3/2≤a) (haA : a≤A) (hw : 0≤w) (hw1 : w≤1)
    (hB : 2*compactHeavyScale A eta rho≤B) :
    1-rho≤(pilotHistogramPMF n cp p).toMeasure.real {h |
      |pilotTrueHeavyPower p.mass (fun i => pilotSelectionCount i) (fun i => pilotMainCount i)
        n a cp B w h-w*(∑i∈trueHeavyPilotSubset p n a cp B (fun i => pilotSelectionCount i h),(p.mass i)^a)|≤
      eta*(∑i∈trueHeavyPilotSubset p n a cp B (fun i => pilotSelectionCount i h),(p.mass i)^a)} := by
  have hmean : ∀y,∀i∈trueHeavyPilotSubset p n a cp B y,
      compactHeavyScale A eta rho*a≤(n:ℝ)*p.mass i := by
    intro y i hi
    have hh := (Finset.mem_filter.mp hi).2.1
    have hmul := mul_le_mul_of_nonneg_right hB (show 0≤a by linarith only [ha])
    linarith only [hh,hmul]
  have hh := compact_heavy_pilot_subset_concentration hA heta hrho hrho1 n cp p ha haA
    (trueHeavyPilotSubset p n a cp B) hmean
  apply hh.trans
  refine measureReal_mono ?_ (by finiteness)
  intro h hh
  let S := trueHeavyPilotSubset p n a cp B (fun i => pilotSelectionCount i h)
  have hnalpha : 0<(n:ℝ)^a := Real.rpow_pos_of_pos hn a
  have hP : 0≤∑i∈S,(p.mass i)^a := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (p.nonneg i) a)
  have hsum : (∑i∈S,((n:ℝ)*p.mass i)^a)=(n:ℝ)^a*(∑i∈S,(p.mass i)^a) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    exact Real.mul_rpow n.coe_nonneg (p.nonneg i)
  have hstat : pilotTrueHeavyPower p.mass (fun i => pilotSelectionCount i) (fun i => pilotMainCount i)
      n a cp B w h=(w/(n:ℝ)^a)*(∑i∈S,analyticCount a (pilotMainCount i h)) := by
    rw [pilotTrueHeavyPower_subset_sum,←Finset.sum_div,←Finset.mul_sum]
    ring
  change |(∑i∈S,analyticCount a (pilotMainCount i h))-(∑i∈S,((n:ℝ)*p.mass i)^a)|≤
    eta*(∑i∈S,((n:ℝ)*p.mass i)^a) at hh
  rw [hsum] at hh
  change |pilotTrueHeavyPower p.mass (fun i => pilotSelectionCount i) (fun i => pilotMainCount i)
    n a cp B w h-w*(∑i∈S,(p.mass i)^a)|≤eta*(∑i∈S,(p.mass i)^a)
  rw [hstat]
  exact compact_heavy_normalize hnalpha hP hw hw1 heta.le hh

end Renyi
