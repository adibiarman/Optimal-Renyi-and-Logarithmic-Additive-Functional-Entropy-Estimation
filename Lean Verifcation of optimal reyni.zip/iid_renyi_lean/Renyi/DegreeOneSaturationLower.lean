import Renyi.DegreeOneCentralCertificate
import Renyi.CoupledSaturationLower

/-! Actual canonical degree-one lower certificate. -/
noncomputable section
namespace Renyi.DegreeOneCompletion

lemma coupledDampedExpression_arms_lower {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z M ω fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hM : 0≤M) (hω : 0≤ω) (hω1 : ω<1)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1) :
    (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)≤
        coupledDampedExpression ℓ N γ z M ω fL f x y ∧
      (overlapB γ z*Real.exp (-M*(1-γ)))*highProfile N (1-γ) f ω y≤
        coupledDampedExpression ℓ N γ z M ω fL f x y := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hy hy1
  have hb1 : overlapB γ z*Real.exp (-M*(1-γ))≤1 :=
    (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hd]))
  have hl0 := mul_nonneg (mul_nonneg (mul_nonneg hc.1.le (Real.exp_pos (-M*γ)).le) hu.1) (sub_nonneg.mpr hH.2)
  have hh0 := mul_nonneg (mul_nonneg hc.2.2.1.le (Real.exp_pos (-M*(1-γ))).le) hv.1
  have hj0 := mul_nonneg (mul_nonneg hω (sub_nonneg.mpr hb1)) hJ.1
  unfold coupledDampedExpression
  constructor <;> linarith only [hl0,hh0,hj0]

def coupledLowSaturationConstant (f E M : ℝ) : ℝ :=
  coupledSaturationCoefficient E M*degreeOneFloorConstant f*endpointCutoffTailConstant

def coupledHighSaturationConstant (f E M : ℝ) : ℝ :=
  coupledSaturationCoefficient E M*coupledFloorConstant f

theorem coupledLowSaturationConstant_pos {f E M : ℝ} (hf : 0<f) (hf1 : f<1) (hE : 0<E) :
    0<coupledLowSaturationConstant f E M :=
  mul_pos (mul_pos (coupledSaturationCoefficient_pos hE) (degreeOneFloorConstant_pos hf hf1)) endpointCutoffTailConstant_pos

theorem coupledHighSaturationConstant_pos {f E M : ℝ} (hf : 0<f) (hf1 : f<1) (hE : 0<E) :
    0<coupledHighSaturationConstant f E M :=
  mul_pos (coupledSaturationCoefficient_pos hE) (coupledFloorConstant_pos hf hf1)

/-- A saturated actual low profile supplies a fixed positive amount under capacity. -/
theorem coupledProfiles_low_saturation_lower {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z E M ω fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hE : 0<E) (hzE : z≤Real.exp (-E)) (hM : 0≤M) (hω : 0≤ω) (hω1 : ω<1)
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1) (hZ : γ≤x)
    (hcap : (x)*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledLowSaturationConstant fL E M≤coupledDampedExpression ℓ N γ z M ω fL f x y := by
  have hprod := coupled_capacity_product_le_h hγ hγ1 hz hz1 hcap
  have hmZ := mul_le_mul_of_nonneg_right hZ (show 0≤(N:ℝ)^2*y by positivity)
  have hY : (N:ℝ)^2*y≤1-γ := (mul_le_mul_iff_right₀ hγ).mp (hmZ.trans hprod)
  have htail := endpointProfile_one_cutoff_tail hN hy hy1 (hY.trans (by linarith only [hγ] : 1-γ≤1))
  have hu := lowProfile_transition_floor hℓ hγ hγ1.le hfL.le hfL1 hx hx1 hZ
  have hweights := (coupled_saturation_weights hγ hγ1 hz hz1 hE hzE hM).1
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hmul := mul_le_mul hweights hu (degreeOneFloorConstant_pos hfL hfL1).le
    (mul_nonneg hc.1.le (Real.exp_pos _).le)
  have hmul' := mul_le_mul hmul htail endpointCutoffTailConstant_pos.le
    (mul_nonneg (mul_nonneg hc.1.le (Real.exp_pos _).le) (lowProfile_range (by omega) hγ hfL.le hfL1 hx hx1).1)
  exact hmul'.trans (coupledDampedExpression_arms_lower (by omega : 0<ℓ) (by omega : 0<N)
    hγ hγ1 hz hz1 hM hω hω1 hfL.le hfL1 hf hf1 hx hx1 hy hy1).1

/-- A saturated actual high profile supplies a fixed positive multiple of omega. -/
theorem coupledProfiles_high_saturation_lower {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 2≤N)
    {γ z E M ω fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hE : 0<E) (hzE : z≤Real.exp (-E)) (hM : 0≤M) (hω : 0≤ω) (hω1 : ω<1)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1) (hY : 1-γ≤(N:ℝ)^2*y) :
    coupledHighSaturationConstant f E M*ω≤coupledDampedExpression ℓ N γ z M ω fL f x y := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hv := highProfile_transition_floor hN hd (by linarith only [hγ]) hf.le hf1 hω hω1 hy hy1 hY
  have hweights := (coupled_saturation_weights hγ hγ1 hz hz1 hE hzE hM).2
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hmul := mul_le_mul hweights hv (mul_nonneg hω (coupledFloorConstant_pos hf hf1).le)
    (mul_nonneg hc.2.2.1.le (Real.exp_pos _).le)
  have hbound := hmul.trans (coupledDampedExpression_arms_lower hℓ (by omega : 0<N)
    hγ hγ1 hz hz1 hM hω hω1 hfL hfL1 hf.le hf1.le hx hx1 hy hy1).2
  unfold coupledHighSaturationConstant
  nlinarith only [hbound]

/-- The full actual deterministic lower certificate for all sufficiently large calibrated energies. -/
theorem coupledProfiles_large_energy_lower {fL f Emin lam0 M : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hEmin : 0<Emin) (hlam0 : 0<lam0) (hlam1 : lam0≤1) (hM : 1≤M) :
    ∃ Estar C c : ℝ, 0<Estar ∧ 0≤C ∧ 0<c ∧
      ∀ (ℓ N : ℕ) (γ z E x y : ℝ), 2≤ℓ → 2≤N → 0<γ → γ<1 →
        0<z → z<1 → Estar≤E → overlapG γ z=Real.exp (-E) →
        0≤x → x≤1 → 0<y → y≤1 →
        lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤(x)*((N:ℝ)^2*y) →
        (x)*((N:ℝ)^2*y)≤
          Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) →
        Real.exp (-E)*Real.exp (-C*(γ*(1-γ)))+
          c*Real.exp (-E)*min ((N:ℝ)^2*y) 1≤
          coupledDampedExpression ℓ N γ z M (Real.exp (-E/8)) fL f x y := by
  let A := coupledLowSaturationConstant fL Emin M
  let B := coupledHighSaturationConstant f Emin M
  have hA : 0<A := coupledLowSaturationConstant_pos hfL hfL1 hEmin
  have hB : 0<B := coupledHighSaturationConstant_pos hf hf1 hEmin
  let Estar := max Emin (max (2/A) (16/(7*B)))
  let C := coupledCentralCertificateConstant fL f M lam0
  let c := min (coupledReserveConstant f Emin M) 1
  have hM0 : 0≤M := by linarith only [hM]
  have hK := coupledCentralLoss_nonneg hfL.le hfL1 hf.le hf1 hM0 hlam0 hlam1
  have hC : 0≤C := add_nonneg hK (div_nonneg (mul_nonneg (Real.exp_pos _).le (Real.exp_pos _).le) endpointCutoffTailConstant_pos.le)
  have hc : 0<c := lt_min (coupledReserveConstant_pos hEmin) (by norm_num)
  refine ⟨Estar,C,c,hEmin.trans_le (le_max_left _ _),hC,hc,?_⟩
  intro ℓ N γ z E x y hℓ hN hγ hγ1 hz hz1 hEstar hG hx hx1 hy hy1 hcaplo hcaphi
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hEE : Emin≤E := (le_max_left _ _).trans hEstar
  have hE : 0<E := hEmin.trans_le hEE
  have hzE : z≤Real.exp (-E) := by have hh := overlapG_ge_parameter hγ hγ1 hz hz1;rwa [hG] at hh
  have hzEmin : z≤Real.exp (-Emin) := hzE.trans (Real.exp_le_exp.mpr (by linarith only [hEE]))
  have hω : 0≤Real.exp (-E/8) := (Real.exp_pos _).le
  have hω1 : Real.exp (-E/8)<1 := Real.exp_lt_one_iff.mpr (by linarith only [hE])
  have htwo : Real.exp (-E)*Real.exp (-C*(γ*(1-γ)))+c*Real.exp (-E)*min ((N:ℝ)^2*y) 1≤2*Real.exp (-E) := by
    have hb : Real.exp (-E)*Real.exp (-C*(γ*(1-γ)))≤Real.exp (-E) := mul_le_of_le_one_right (Real.exp_pos (-E)).le
      (Real.exp_le_one_iff.mpr (by nlinarith only [mul_nonneg hC (mul_nonneg hγ.le hd.le)]))
    have hg := mul_le_of_le_one_right (mul_nonneg hc.le (Real.exp_pos (-E)).le) (min_le_right ((N:ℝ)^2*y) 1)
    have hcg := mul_le_mul_of_nonneg_right (min_le_right (coupledReserveConstant f Emin M) 1) (Real.exp_pos (-E)).le
    nlinarith only [hb,hg,hcg]
  by_cases hZ : x≤γ
  · by_cases hY : (N:ℝ)^2*y≤1-γ
    · have hcentral := coupledProfiles_central_lower_certificate hℓ hN hγ hγ1 hz hz1 hEmin hEE hG hlam0 hlam1 hM
        hfL.le hfL1 hf.le hf1 hx hx1 hy hy1 hZ hY hcaplo hcaphi
      have hunit : (N:ℝ)^2*y≤1 := hY.trans (by linarith only [hγ])
      rw [min_eq_left hunit]
      have hgain := mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right (min_le_left (coupledReserveConstant f Emin M) 1) (Real.exp_pos (-E)).le)
        (show 0≤(N:ℝ)^2*y by positivity)
      nlinarith only [hcentral,hgain]
    · have hsat := coupledProfiles_high_saturation_lower (by omega : 0<ℓ) hN hγ hγ1 hz hz1 hEmin hzEmin hM0 hω hω1
        hfL.le hfL1 hf hf1 hx hx1 hy.le hy1 (le_of_lt (lt_of_not_ge hY))
      have hthreshold : 16/(7*B)≤E := ((le_max_right _ _).trans (le_max_right _ _)).trans hEstar
      have ht := (div_le_iff₀ (show 0<7*B by positivity)).mp hthreshold
      have he := exp_neg_le_of_large (show 0<B/2 by positivity)
        (show 1/(B/2)≤7*E/8 by apply (div_le_iff₀ (show 0<B/2 by positivity)).mpr;nlinarith only [ht])
      rw [show -(7*E/8)=-7*E/8 by ring] at he
      have hm := mul_le_mul_of_nonneg_right he (Real.exp_pos (-E/8)).le
      have hid : Real.exp (-7*E/8)*Real.exp (-E/8)=Real.exp (-E) := by
        rw [←Real.exp_add]
        congr 1
        ring
      rw [hid] at hm
      exact htwo.trans (by dsimp [B] at hm;nlinarith only [hsat,hm])
  · have hsat := coupledProfiles_low_saturation_lower hℓ hN hγ hγ1 hz hz1 hEmin hzEmin hM0 hω hω1
      hfL hfL1 hf.le hf1.le hx hx1 hy.le hy1 (le_of_lt (lt_of_not_ge hZ)) hcaphi
    have hthreshold : 2/A≤E := ((le_max_left _ _).trans (le_max_right _ _)).trans hEstar
    have ht := (div_le_iff₀ hA).mp hthreshold
    have he := exp_neg_le_of_large (show 0<A/2 by positivity)
      (show 1/(A/2)≤E by apply (div_le_iff₀ (show 0<A/2 by positivity)).mpr;nlinarith only [ht])
    exact htwo.trans (by dsimp [A] at he;nlinarith only [hsat,he])


end Renyi.DegreeOneCompletion
