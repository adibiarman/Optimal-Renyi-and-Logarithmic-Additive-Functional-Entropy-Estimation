import Renyi.OmegaHeavyPilot
import Renyi.UpperRescaling

/-! Power-sum units and the actual final rescaling for the random-pilot heavy event. -/
noncomputable section
open scoped BigOperators NNReal
open Set MeasureTheory ProbabilityTheory
namespace Renyi

/-- The selected source heavy sum in probability units. -/
def omegaHeavyNormalizedSubsetEvent {Ω : Type*} {k : ℕ} (N : Fin k→Ω→ℕ) (p : Simplex k)
    (n : ℝ≥0) (a E0 eps c0 c sigma : ℝ) (S : Finset (Fin k)) : Set Ω :=
  {w | (Real.exp (-(2*eps*(a-1)))+c*Real.exp (-(2*eps*(a-1))))*
      ∑i∈S,(p.mass i)^a ≤ ∑i∈S,(sigma*Real.exp (-c0*E0))*analyticCount a (N i w)/(n:ℝ)^a ∧
    (∑i∈S,(sigma*Real.exp (-c0*E0))*analyticCount a (N i w)/(n:ℝ)^a)≤
      (1-c*Real.exp (-(2*eps*(a-1))))*∑i∈S,(p.mass i)^a}

/-- Normalization and a small downward rescaling preserve half the heavy margin. -/
theorem omegaHeavySubsetEvent_normalized {Ω : Type*} {k : ℕ}
    (N : Fin k→Ω→ℕ) (p : Simplex k) {n : ℝ≥0} (hn : 0<(n:ℝ))
    {a E0 eps c0 c sigma : ℝ} (hc : 0≤c) (hsigma : 0≤sigma) (hsigma1 : sigma≤1)
    (hheadroom : 1+c/2≤sigma*(1+c)) (S : Finset (Fin k)) :
    omegaHeavySubsetEvent N (fun i => n*simplexNN p i) a E0 eps c0 c S ⊆
      omegaHeavyNormalizedSubsetEvent N p n a E0 eps c0 (c/2) sigma S := by
  intro w hw
  have hnα := Real.rpow_pos_of_pos hn a
  have hsum : (∑i∈S,((n*simplexNN p i:ℝ≥0):ℝ)^a)=(n:ℝ)^a*∑i∈S,(p.mass i)^a := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    simp only [NNReal.coe_mul,simplexNN_coe,Real.mul_rpow n.coe_nonneg (p.nonneg i)]
  have hstat : (∑i∈S,(sigma*Real.exp (-c0*E0))*analyticCount a (N i w)/(n:ℝ)^a)=
      (sigma/(n:ℝ)^a)*(Real.exp (-c0*E0)*∑i∈S,analyticCount a (N i w)) := by
    rw [←Finset.sum_div,←Finset.mul_sum]
    ring
  have hS : 0≤∑i∈S,(p.mass i)^a := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (p.nonneg i) a)
  change _∧_ at hw
  rw [hsum] at hw
  have hl := mul_le_mul_of_nonneg_left hw.1 (div_nonneg hsigma hnα.le)
  have hu := mul_le_mul_of_nonneg_left hw.2 (div_nonneg hsigma hnα.le)
  have hl' : sigma*(Real.exp (-(2*eps*(a-1)))+c*Real.exp (-(2*eps*(a-1))))*
      (∑i∈S,(p.mass i)^a)≤(sigma/(n:ℝ)^a)*(Real.exp (-c0*E0)*∑i∈S,analyticCount a (N i w)) := by
    convert hl using 1; field_simp
  have hu' : (sigma/(n:ℝ)^a)*(Real.exp (-c0*E0)*∑i∈S,analyticCount a (N i w))≤
      sigma*((1-c*Real.exp (-(2*eps*(a-1))))*∑i∈S,(p.mass i)^a) := by
    convert hu using 1; field_simp
  have hnonneg : 0≤(1-c*Real.exp (-(2*eps*(a-1))))*∑i∈S,(p.mass i)^a := by
    have hlow : 0≤Real.exp (-c0*E0)*∑i∈S,analyticCount a (N i w) :=
      (mul_nonneg (add_nonneg (Real.exp_pos _).le (mul_nonneg hc (Real.exp_pos _).le))
        (mul_nonneg hnα.le hS)).trans hw.1
    have hh := hlow.trans hw.2
    have hid : (1-c*Real.exp (-(2*eps*(a-1))))*((n:ℝ)^a*∑i∈S,(p.mass i)^a)=
        (n:ℝ)^a*((1-c*Real.exp (-(2*eps*(a-1))))*∑i∈S,(p.mass i)^a) := by ring
    rw [hid] at hh
    exact (nonneg_of_mul_nonneg_right hh hnα)
  have hupper := (mul_le_of_le_one_left hnonneg hsigma1)
  have hmargin := mul_le_mul_of_nonneg_right hheadroom
    (mul_nonneg (Real.exp_pos (-(2*eps*(a-1)))).le hS)
  have hc2 := mul_nonneg (show 0≤c/2 by positivity)
    (mul_nonneg (Real.exp_pos (-(2*eps*(a-1)))).le hS)
  change _∧_
  rw [hstat]
  constructor <;> nlinarith only [hl',hu',hmargin,hupper,hc2]

/-- The actual upper rescaling preserves half the heavy interior margin. -/
theorem upperRescaling_heavy_headroom {k : ℕ} {alpha eps cu u0 c : ℝ}
    (halpha : 1<alpha) (hγ : 0<fractionalPart alpha) (hγ1 : fractionalPart alpha<1)
    (hcu : 0≤cu) (hu0 : 0<u0) (hc : 0≤c) (hsmall : cu*u0*(2+c)≤c) :
    1+c/2≤upperRescaling k alpha eps cu u0*(1+c) := by
  have hu := upperU_pos (k:=k) (eps:=eps) halpha hγ hγ1 hu0
  have hupper : upperU k alpha eps u0≤u0 := min_le_right _ _
  have hden : 0<1+cu*upperU k alpha eps u0 := by positivity
  unfold upperRescaling
  rw [inv_mul_eq_div]
  apply (le_div_iff₀ hden).mpr
  have hh := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hupper hcu)
    (show 0≤2+c by positivity)
  nlinarith only [hh,hsmall]

/-- Actual random-pilot heavy concentration in probability units, after rescaling. -/
theorem omega_heavy_pilot_normalized_concentration {eps c0 rho : ℝ}
    (heps : 0<eps) (hc0 : 0<c0) (hc01 : c0<1) (hrho : 0<rho) (hrho1 : rho<1)
    {k : ℕ} (n cp : ℝ≥0) (hn : 0<(n:ℝ)) (p : Simplex k) {a E0 sigma : ℝ}
    (ha : 3/2≤a) (hElow : eps*(a-1)≤E0) (hEhigh : E0≤2*eps*(a-1))
    (hsigma : 0≤sigma) (hsigma1 : sigma≤1)
    (hheadroom : 1+omegaHeavyMargin eps c0/2≤sigma*(1+omegaHeavyMargin eps c0))
    (S : (Fin k→ℕ)→Finset (Fin k)) (G : Set (Fin k→ℕ))
    (hmean : ∀y∈G,∀i∈S y,omegaHeavyScale eps c0 rho*a≤(n:ℝ)*p.mass i) :
    (finitePoissonPMF (fun i => cp*(n*simplexNN p i))).toMeasure.real G-rho≤
      (pilotHistogramPMF n cp p).toMeasure.real {h |
        (fun i => pilotSelectionCount i h)∈G ∧
        h∈omegaHeavyNormalizedSubsetEvent (fun i => pilotMainCount i) p n
          a E0 eps c0 (omegaHeavyMargin eps c0/2) sigma (S (fun i => pilotSelectionCount i h))} := by
  have hc := (omega_heavy_concentration_explicit (μ:=(pilotHistogramPMF n cp p).toMeasure)
    heps hc0 hc01 hrho hrho1).1
  apply (omega_heavy_pilot_joint_concentration heps hc0 hc01 hrho hrho1 n cp p ha hElow hEhigh S G hmean).trans
  refine measureReal_mono ?_ (by finiteness)
  intro h hh
  exact ⟨hh.1,omegaHeavySubsetEvent_normalized (fun i => pilotMainCount i) p hn hc.le hsigma hsigma1
    hheadroom (S (fun i => pilotSelectionCount i h)) hh.2⟩

end Renyi
