import Renyi.UpperProfileDesign
import Renyi.UpperAssignedCompact
import Renyi.UpperAssignedLargeWidthLower
import Renyi.OmegaHeavyFixed
import Renyi.UpperAssignedBiasUpper

/-! Fixed scalar design and the full deterministic interval for the actual
noninteger estimator. All fixed choices precede count and pilot calibration. -/
noncomputable section
namespace Renyi
set_option maxHeartbeats 1000000

/-- The fixed gap used for every realized heavy aggregate. -/
def upperFinalHeavyMargin (eps : ℝ) : ℝ := omegaHeavyMargin eps (1/8)/2

lemma upperFinalHeavyMargin_pos {eps : ℝ} (heps : 0<eps) : 0<upperFinalHeavyMargin eps := by
  have hh : 0<omegaHeavyMargin eps (1/8) := by
    have hdist : omegaHeavyDistance (1/8)=(1/16:ℝ) := by norm_num [omegaHeavyDistance]
    unfold omegaHeavyMargin
    rw [hdist]
    exact sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith only [heps]))
  exact div_pos hh (by norm_num)

/-- The raw heavy statistic is rescaled only within the actual assigned oracle. -/
def ActualAssignedInterior (eps fL f M lambda Ch cu W c : ℝ) : Prop :=
  ∀ (cb CL cL C0 : ℝ), 0<cb → 1≤CL → 0<cL → 1≤cb*CL → 100≤C0 →
    ∃ d0 : ℝ, 0<d0 ∧ d0≤1 ∧ ∀ d : ℝ, 0<d → d≤d0 →
      ∃ D0 : ℝ, 1≤D0 ∧ ∀ (k : ℕ) (alpha D heavy : ℝ),
        0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → D0≤D →
        ∀ (p : Simplex k) (light : Fin k→Bool),
          (∀i,light i=true→p.mass i≤upperB k alpha eps D cb CL cL) →
          upperKappa alpha eps*(1+upperFinalHeavyMargin eps)*assignedHeavyPower p light alpha≤heavy →
          heavy≤(1-upperFinalHeavyMargin eps)*assignedHeavyPower p light alpha →
          (2*eps*(alpha-1)/(fractionalPart alpha*(1-fractionalPart alpha))≤W →
            |heavy-Real.exp (-upperE0 k alpha eps Ch/8)*assignedHeavyPower p light alpha|≤
              (compactOmegaGap eps W/4)*assignedHeavyPower p light alpha) →
          upperKappa alpha eps*powerSum p alpha+
              3*c*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d 1≤
            actualAssignedOracleMean p light heavy alpha eps Ch D cb lambda CL cL fL f M cu 1 C0 d ∧
            actualAssignedOracleMean p light heavy alpha eps Ch D cb lambda CL cL fL f M cu 1 C0 d+
              3*c*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d 1≤powerSum p alpha

/-- A complete design includes the proved interior for the actual polynomial,
not an approximation hypothesis to be supplied by the user. -/
structure UpperFinalDesign (eps : ℝ) where
  fL : ℝ
  f : ℝ
  qL : ℝ
  qH : ℝ
  lambda : ℝ
  M : ℝ
  Ch : ℝ
  cu : ℝ
  W : ℝ
  margin : ℝ
  fL_pos : 0<fL
  fL_lt_one : fL<1
  f_pos : 0<f
  f_lt_one : f<1
  qL_floor : Real.exp (-(eps/2))<qL
  qL_lt_fL : qL<fL
  qH_floor : Real.exp (-7*(eps/2)/8)<qH
  qH_lt_f : qH<f
  lambda_pos : 0<lambda
  lambda_bound : lambda≤Real.exp (-2*coupledProfileConstant)
  one_le_M : 1≤M
  Ch_nonneg : 0≤Ch
  cu_pos : 0<cu
  cu_bound : cu≤min 1 (eps/4)/2
  heavy_headroom : cu*(2+omegaHeavyMargin eps (1/8))≤omegaHeavyMargin eps (1/8)
  W_pos : 0<W
  compact_small : cu≤compactOmegaLowerGap eps W/2
  margin_pos : 0<margin
  interior : ActualAssignedInterior eps fL f M lambda Ch cu W margin

/-- The fixed choices and the actual full deterministic certificate are jointly
constructed before all later pilot, degree, and coefficient calibrations. -/
theorem upperFinalDesign_exists {eps : ℝ} (heps : 0<eps) : Nonempty (UpperFinalDesign eps) := by
  obtain ⟨base⟩ := upperProfileDesign_exists heps
  obtain ⟨M0,hM0,hupper⟩ := upper_actual_assigned_bias_upper heps
    base.fL_pos base.fL_lt_one base.f_pos.le base.f_lt_one
  let M := max base.M M0
  have hM : 1≤M := hM0.trans (le_max_right _ _)
  obtain ⟨C,hC,hlower⟩ := upper_actual_assigned_large_width_bias_lower heps
    base.fL_pos base.fL_lt_one base.f_pos base.f_lt_one hM base.lambda_pos base.lambda_bound
    base.qL_floor base.qL_lt_fL base.qH_floor base.qH_lt_f
  let Ch := 2*C+2
  have hCh : 0≤Ch := by dsimp [Ch];linarith only [hC]
  let W := max 1 (4*C)
  have hW : 0<W := zero_lt_one.trans_le (le_max_left _ _)
  have hWlarge : 4*C≤W := le_max_right _ _
  let cH := upperFinalHeavyMargin eps
  have hcH : 0<cH := upperFinalHeavyMargin_pos heps
  have hcFull : 0<omegaHeavyMargin eps (1/8) := by
    change 0<omegaHeavyMargin eps (1/8)/2 at hcH
    linarith only [hcH]
  have hcompact : 0<compactOmegaLowerGap eps W/2 :=
    (compactOmegaGap_pos heps).trans_le (min_le_left _ _)
  let cu := min base.cu (min (cH/2) (min (compactOmegaLowerGap eps W/2)
    (omegaHeavyMargin eps (1/8)/(2+omegaHeavyMargin eps (1/8)))))
  have hcu : 0<cu := lt_min base.cu_pos (lt_min (by positivity)
    (lt_min hcompact (div_pos hcFull (by linarith only [hcFull]))))
  have hcubase : cu≤base.cu := min_le_left _ _
  have hcuH : cu≤cH/2 := (min_le_right _ _).trans (min_le_left _ _)
  have hcucompact : cu≤compactOmegaLowerGap eps W/2 :=
    (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
  have hcuhead : cu*(2+omegaHeavyMargin eps (1/8))≤omegaHeavyMargin eps (1/8) := by
    apply (le_div_iff₀ (by linarith only [hcFull] : 0<2+omegaHeavyMargin eps (1/8))).mp
    exact (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _))
  have hcu1 : cu≤1 := hcubase.trans base.cu_le_one
  have hcubound : cu≤min 1 (eps/4)/2 := hcubase.trans base.cu_bound
  obtain ⟨cL,hcL,hlower'⟩ := hlower Ch cu 1 cH (le_refl _) hcu.le zero_lt_one hcubound hcH
    (by simpa only [mul_one] using (hcuH.trans_lt (by linarith only [hcH] : cH/2<cH)))
  obtain ⟨cU,hcU,hupper'⟩ := hupper M (le_max_right _ _) Ch cu 1 cH hCh hcu zero_lt_one
    (by simpa only [mul_one] using hcu1) hcH
  let c := min (cL/3) (min (cU/3) (compactInteriorCoefficient eps W 1))
  have hc : 0<c := lt_min (by positivity) (lt_min (by positivity) (compactInteriorCoefficient_pos heps zero_lt_one))
  have hcL' : 3*c≤cL := by have hh : c≤cL/3 := min_le_left _ _;linarith only [hh]
  have hcU' : 3*c≤cU := by have hh : c≤cU/3 := (min_le_right _ _).trans (min_le_left _ _);linarith only [hh]
  have hccompact : c≤compactInteriorCoefficient eps W 1 := (min_le_right _ _).trans (min_le_right _ _)
  refine ⟨{
    fL := base.fL, f := base.f, qL := base.qL, qH := base.qH, lambda := base.lambda,
    M := M, Ch := Ch, cu := cu, W := W, margin := c,
    fL_pos := base.fL_pos, fL_lt_one := base.fL_lt_one,
    f_pos := base.f_pos, f_lt_one := base.f_lt_one,
    qL_floor := base.qL_floor, qL_lt_fL := base.qL_lt_fL,
    qH_floor := base.qH_floor, qH_lt_f := base.qH_lt_f,
    lambda_pos := base.lambda_pos, lambda_bound := base.lambda_bound, one_le_M := hM,
    Ch_nonneg := hCh, cu_pos := hcu, cu_bound := hcubound, heavy_headroom := hcuhead,
    W_pos := hW, compact_small := hcucompact, margin_pos := hc, interior := ?_ }⟩
  intro cb CL cSmall C0 hcb hCL hcSmall hcbCL hC0
  obtain ⟨d0,DU,hd0,hd01,hDU,hupper''⟩ := hupper' cb base.lambda CL cSmall C0
    hcb base.lambda_pos base.lambda_bound hCL hcSmall hcbCL hC0
  refine ⟨d0,hd0,hd01,?_⟩
  intro d hd hdd
  obtain ⟨DL,hDL,hlower''⟩ := hlower' C0 d cb CL cSmall hC0 hd hcb hCL hcSmall hcbCL
  obtain ⟨DC,hDC,hcompact'⟩ := upper_actual_assigned_compact_interior heps hW hCh hcb
    base.lambda_pos (by linarith only [coupled_capacity_lambda_le_one base.lambda_bound] : base.lambda≤4)
    hCL hcSmall hcbCL base.fL_pos.le base.fL_lt_one base.f_pos.le base.f_lt_one.le
    (by linarith only [hM] : 0≤M) hcu.le zero_lt_one (by linarith only [hC0] : 1≤C0) hd.le
    (hdd.trans hd01) (by simpa only [mul_one] using hcucompact)
  refine ⟨max DU (max DL DC),hDU.trans (le_max_left _ _),?_⟩
  intro k alpha D heavy hk ha hg hg1 hD p light hlight hheavyL hheavyU hheavyC
  have hDU' : DU≤D := (le_max_left _ _).trans hD
  have hDL' : DL≤D := (le_max_left _ _).trans ((le_max_right _ _).trans hD)
  have hDC' : DC≤D := (le_max_right _ _).trans ((le_max_right _ _).trans hD)
  have hDpos : 0<D := zero_lt_one.trans_le (hDU.trans hDU')
  have ha1 : 1<alpha := by linarith only [ha]
  have hgeometry := upper_actual_count_geometry hk ha hg hg1 heps hCh hDpos hcb base.lambda_pos
    (by linarith only [coupled_capacity_lambda_le_one base.lambda_bound] : base.lambda≤4) hCL hcSmall hcbCL
  have hbudget := actualBiasBudget_nonneg p ha1 hg hg1 zero_lt_one
    (by linarith only [hC0] : 0≤C0) hd.le hgeometry.1.le hgeometry.2.2.1
  have hupperFinal := hupper'' d hd.le hdd k alpha D heavy hk ha hg hg1 hDU' p light hlight hheavyU
  have hU := mul_le_mul_of_nonneg_right hcU' hbudget
  constructor
  · by_cases hwidth : 2*eps*(alpha-1)/(fractionalPart alpha*(1-fractionalPart alpha))≤W
    · have hcBound := (hcompact' k alpha D heavy hk ha hg hg1 hDC' hwidth p light hlight (hheavyC hwidth)).1
      have hcoeff : 3*c≤3*compactInteriorCoefficient eps W 1 := by linarith only [hccompact]
      have hh := mul_le_mul_of_nonneg_right hcoeff hbudget
      linarith only [hcBound,hh]
    · have hh : 0<fractionalPart alpha*(1-fractionalPart alpha) := mul_pos hg (sub_pos.mpr hg1)
      have hwidth' := (lt_div_iff₀ hh).mp (lt_of_not_ge hwidth)
      have hlarge : 4*C*(fractionalPart alpha*(1-fractionalPart alpha))≤2*eps*(alpha-1) :=
        (mul_le_mul_of_nonneg_right hWlarge hh.le).trans hwidth'.le
      have hlBound := hlower'' k alpha D heavy hk ha hg hg1 hDL' hlarge p light hlight hheavyL
      have hlcoef := mul_le_mul_of_nonneg_right hcL' hbudget
      linarith only [hlBound,hlcoef]
  · linarith only [hupperFinal,hU]

end Renyi
