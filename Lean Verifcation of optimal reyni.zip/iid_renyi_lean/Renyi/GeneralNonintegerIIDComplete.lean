import Renyi.GeneralNonintegerHistogramBand
import Renyi.ActualHeavyGoodEvent
import Renyi.ActualHistogramIdeal
import Renyi.UpperFinalDesign
import Renyi.GeneralHistogramIdeal

/-! Completion of the general noninteger iid upper bound for the actual common estimator. -/
set_option maxHeartbeats 2000000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

lemma general_noninteger_fractional_part {alpha : ℝ} (ha : 1 < alpha)
    (hnotint : ¬ ∃ r : ℕ, alpha = (r : ℝ)) :
    0 < fractionalPart alpha ∧ fractionalPart alpha < 1 := by
  have hnonneg : 0 ≤ fractionalPart alpha := Int.fract_nonneg alpha
  have hlt : fractionalPart alpha < 1 := Int.fract_lt_one alpha
  refine ⟨?_, hlt⟩
  by_contra h
  have hz : fractionalPart alpha = 0 := le_antisymm (le_of_not_gt h) hnonneg
  apply hnotint
  refine ⟨upperOrderFloor alpha, ?_⟩
  rw [fractionalPart_eq_upperOrderFloor ha] at hz
  linarith

/-- The actual common polynomial/Gamma histogram statistic achieves the full
general noninteger iid rate, with every auxiliary constant fixed uniformly. -/
theorem general_noninteger_iid_rate_upper_uniform {eps : ℝ} (heps : 0 < eps) :
    ∃ C : ℝ, 0 < C ∧ ∃ K : ℕ, 1 ≤ K ∧ ∀ k : ℕ, K ≤ k →
      ∀ alpha : ℝ, 3 / 2 ≤ alpha → (¬ ∃ r : ℕ, alpha = (r : ℝ)) → alpha < Real.log k →
        ∃ n : ℕ, (n : ℝ) ≤ C * rate k alpha eps ∧ Achievable k n alpha eps := by
  obtain ⟨design⟩ := upperFinalDesign_exists heps
  have hmargin := design.margin_pos
  have hlambda4 : design.lambda ≤ 4 := by
    have hh := coupled_capacity_lambda_le_one design.lambda_bound
    linarith
  have hM : 0 ≤ design.M := zero_le_one.trans design.one_le_M
  have hetaHeavy : 0 < compactOmegaGap eps design.W / 4 := div_pos (compactOmegaGap_pos heps) (by norm_num)
  obtain ⟨B, hB, hHeavy⟩ := actual_heavy_good_event_uniform
    (C := design.W) heps (by norm_num : (0 : ℝ) < 1 / 8) (by norm_num : (1 / 8 : ℝ) < 1)
    design.W_pos.le hetaHeavy
  let CL := 2 * B + 1
  have hCL : 1 ≤ CL := by dsimp [CL]; linarith
  have hscale : 2 * B ≤ (1 : ℝ) * CL := by dsimp [CL]; linarith
  have hcbCL : 1 ≤ (1 : ℝ) * CL := by simpa only [one_mul] using hCL
  have hBpos : 0 < B := by linarith
  obtain ⟨cpR, hcpR1, hcpDegree, hPilotParameters⟩ := actual_pilot_reserve_mean_uniform_experiments
    heps design.Ch_nonneg (by norm_num : (0 : ℝ) < 1) design.lambda_pos hlambda4 hCL hB hscale
    design.fL_pos.le design.fL_lt_one design.f_pos.le design.f_lt_one.le hM design.cu_pos.le
    zero_lt_one (by positivity : 0 < design.margin / 16)
  have hcpR : 0 < cpR := zero_lt_one.trans_le hcpR1
  let cp : ℝ≥0 := ⟨cpR, hcpR.le⟩
  have hcpcoe : (cp : ℝ) = cpR := rfl
  obtain ⟨cL, C0, hcL, _hcLmax, hC0, hC0low, hCountParameters⟩ :=
    actual_source_conditional_count_variance_uniform_experiments heps design.Ch_nonneg
      (by norm_num : (0 : ℝ) < 1) design.lambda_pos hlambda4 hCL hcbCL hcpR hcpDegree hBpos
      hM design.fL_pos.le design.fL_lt_one design.f_pos.le design.f_lt_one.le design.cu_pos.le
      zero_lt_one (by positivity : 0 < design.margin ^ 2 / 16) (by norm_num : (0 : ℝ) < 1)
  have hLow100 : (100 : ℝ) ≤ coupledLowCoefficientConstant := by
    unfold coupledLowCoefficientConstant
    nlinarith only [Real.exp_pos (12 : ℝ)]
  have hC0100 : 100 ≤ C0 := hLow100.trans hC0low
  obtain ⟨d0, hd0, hd01, hDetParameters⟩ := design.interior 1 CL cL C0
    (by norm_num) hCL hcL hcbCL hC0100
  let db := d0 / 2
  have hdb : 0 < db := by dsimp [db]; positivity
  have hdbd0 : db ≤ d0 := by dsimp [db]; linarith
  have hdb1 : db ≤ 1 := hdbd0.trans hd01
  obtain ⟨Ddet, hDdet, hDet⟩ := hDetParameters db hdb hdbd0
  obtain ⟨Dcount, hDcount, hCount⟩ := hCountParameters db hdb hdb1
  obtain ⟨Dpilot, hDpilot, hPilot⟩ := hPilotParameters cpR (le_refl _) cL C0 db hcL hC0100 hdb
  obtain ⟨Kanchor, hAnchor⟩ := actual_source_affine_noise_uniform heps design.Ch_nonneg
    (by norm_num : (0 : ℝ) < 1) design.lambda_pos hlambda4 hCL hcL hcbCL design.fL_pos.le
    design.fL_lt_one hM design.cu_pos.le zero_lt_one hC0low hdb
    (by positivity : 0 < design.margin ^ 2 / 16)
  let D := max Ddet (max Dcount (max Dpilot (3 * Real.log 12)))
  have hDdetD : Ddet ≤ D := le_max_left _ _
  have hDcountD : Dcount ≤ D := (le_max_left _ _).trans (le_max_right _ _)
  have hDpilotD : Dpilot ≤ D := (le_max_left _ _).trans ((le_max_right _ _).trans (le_max_right _ _))
  have hDtail : 3 * Real.log 12 ≤ D := (le_max_right _ _).trans ((le_max_right _ _).trans (le_max_right _ _))
  have hD1 : 1 ≤ D := hDdet.trans hDdetD
  have hD : 0 < D := zero_lt_one.trans_le hD1
  let C := 3 * (1 + cpR) * D
  have hC : 0 < C := by dsimp [C]; positivity
  refine ⟨C, hC, max 1 Kanchor, le_max_left _ _, ?_⟩
  intro k hk alpha ha hnotint horder
  have hk1 : 1 ≤ k := (le_max_left _ _).trans hk
  have hkpos : 0 < k := Nat.zero_lt_one.trans_le hk1
  have hkAnchor : Kanchor ≤ k := (le_max_right _ _).trans hk
  have ha1 : 1 < alpha := by linarith
  obtain ⟨hg, hg1⟩ := general_noninteger_fractional_part ha1 hnotint
  let n := nonintegerPoissonMean k alpha eps D
  have hncoe : (n : ℝ) = upperSample k alpha eps D := nonintegerPoissonMean_coe hkpos ha1 hg hg1 hD
  have hn : 0 < (n : ℝ) := hncoe.symm ▸ upperSample_pos hkpos ha1 hg hg1 hD
  let Q := actualSourcePolynomial k alpha eps design.Ch D 1 design.lambda CL cL design.fL design.f design.M design.cu 1
  let F := nonintegerHistogramStatistic (k := k) n cp Q (upperCountDegree k alpha eps CL cL) alpha B
    (upperRescaling k alpha eps design.cu 1 * Real.exp (-upperE0 k alpha eps design.Ch / 8))
    (2 * actualCutoffBudget k alpha eps design.Ch D 1 design.lambda CL cL C0 db)
  have hband : ∀ p : Simplex k, (pilotHistogramPMF n cp p).toMeasure.real
      {h | F h < Real.exp (-2 * eps * (alpha - 1)) * powerSum p alpha ∨ powerSum p alpha < F h} ≤ 1 / 4 := by
    intro p
    let mu := (pilotHistogramPMF n cp p).toMeasure
    let lam : Fin k → ℝ≥0 := fun i => n * simplexNN p i
    have hLaw (i : Fin k) : MeasurePreserving (pilotMainCount i) mu (poissonMeasure (lam i)) :=
      pilotMainCount_law n cp p i
    have hPilotLaw (i : Fin k) : MeasurePreserving (pilotSelectionCount i) mu
        (poissonMeasure ⟨cpR * lam i, mul_nonneg hcpR.le (lam i).coe_nonneg⟩) := by
      convert pilotSelectionCount_law n cp p i using 1
    have hlam (i : Fin k) : (lam i : ℝ) = upperSample k alpha eps D * p.mass i := by
      simp only [lam, NNReal.coe_mul, simplexNN_coe, hncoe]
    have hcount := hCount k alpha D hkpos ha hg hg1 hDcountD mu mu p pilotMainCount pilotSelectionCount lam
      hLaw (pilotMainCount_independent n cp p) hPilotLaw hlam
    have hanchor := hAnchor k hkAnchor alpha D ha hg hg1 hD1 p
    have hLawReal (i : Fin k) : MeasurePreserving (pilotMainCount i) mu
        (poissonMeasure (Real.toNNReal (upperSample k alpha eps D * p.mass i))) := by
      simpa only [hncoe] using pilotMainCount_law_real n cp p i
    have hPilotReal (i : Fin k) : MeasurePreserving (pilotSelectionCount i) mu
        (poissonMeasure (Real.toNNReal (cpR * upperSample k alpha eps D * p.mass i))) := by
      simpa only [hncoe, hcpcoe] using pilotSelectionCount_law_real n cp p i
    have hboundary := hPilot k alpha D hkpos ha hg hg1 hDpilotD mu p pilotSelectionCount pilotMainCount
      hLawReal (pilotSelectionCount_independent_main n cp p) hPilotReal
    let G := actualHeavyGoodEvent n cp p alpha eps design.Ch (1 / 8) B
      (actualHeavyGap eps (1 / 8)) (compactOmegaGap eps design.W / 4) (2 + 8 * design.W / eps)
    have hgood := hHeavy B (le_refl _) n cp hn p alpha design.Ch ha hg hg1 design.Ch_nonneg
    have hbad := actualHeavyGoodEvent_bad_le n cp p alpha eps design.Ch (1 / 8) B
      (actualHeavyGap eps (1 / 8)) (compactOmegaGap eps design.W / 4) (2 + 8 * design.W / eps) hgood
    have hideal : ∀ h ∈ G, upperKappa alpha eps * powerSum p alpha +
        3 * design.margin * actualBiasBudget p alpha eps design.Ch D 1 design.lambda CL cL C0 db 1 ≤
        nonintegerHistogramIdeal n cp p Q (upperB k alpha eps D 1 CL cL) alpha B
          (upperRescaling k alpha eps design.cu 1 * Real.exp (-upperE0 k alpha eps design.Ch / 8))
          (2 * actualCutoffBudget k alpha eps design.Ch D 1 design.lambda CL cL C0 db) h ∧
      nonintegerHistogramIdeal n cp p Q (upperB k alpha eps D 1 CL cL) alpha B
          (upperRescaling k alpha eps design.cu 1 * Real.exp (-upperE0 k alpha eps design.Ch / 8))
          (2 * actualCutoffBudget k alpha eps design.Ch D 1 design.lambda CL cL C0 db) h +
        3 * design.margin * actualBiasBudget p alpha eps design.Ch D 1 design.lambda CL cL C0 db 1 ≤ powerSum p alpha := by
      intro h hh
      exact general_histogram_ideal_on_heavy_good n cp p hkpos ha hg hg1 heps design.Ch_nonneg hD
        (by norm_num) hCL hcL hB hscale design.W_pos hncoe
        (fun light heavy hlight hheavyL hheavyU hheavyC =>
          hDet k alpha D heavy hkpos ha hg hg1 hDdetD p light hlight hheavyL hheavyU hheavyC) hh
    have hh := general_noninteger_histogram_band p cp hkpos ha hg hg1 heps design.Ch_nonneg hD1
      design.lambda_pos hlambda4 hCL hcL (zero_le_one.trans hC0) hdb.le design.cu_pos.le zero_lt_one
      design.margin_pos G hbad hideal hcount hanchor hboundary.1 hboundary.2
    simpa only [F, Q, n, upperKappa] using hh
  have hfinal := noninteger_iid_rate_upper_of_histogram_band hkpos ha1 hg hg1 horder hnotint hD1 hDtail cp F hband
  simpa only [C, hcpcoe] using hfinal

end Renyi
