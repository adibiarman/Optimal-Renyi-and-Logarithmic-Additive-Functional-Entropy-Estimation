import Renyi.DegreeOneMinEnvelope
import Renyi.CoupledCentralLower

/-! Lower local and transition bounds for the canonical degree-one completion. -/
noncomputable section
namespace Renyi.DegreeOneCompletion

lemma completionFloor_idem (f : ℝ) : completionFloor (completionFloor f)=completionFloor f :=
  completionFloor_eq completionFloor_pos completionFloor_lt_one

lemma coefficient_completionFloor (s f : ℝ) : coefficient s (completionFloor f)=coefficient s f := by
  simp only [coefficient,completionFloor_idem]

lemma lowProfile_completionFloor (N : ℕ) (s f x : ℝ) :
    lowProfile N s (completionFloor f) x=lowProfile N s f x := by
  simp only [lowProfile,coefficient_completionFloor]

def degreeOneLocalLowerConstant (f : ℝ) : ℝ := localEnvelopeConstant (completionFloor f)

theorem degreeOneLocalLowerConstant_nonneg {f : ℝ} (_hf : 0≤f) (_hf1 : f<1) :
    0≤degreeOneLocalLowerConstant f :=
  (localEnvelopeConstant_pos completionFloor_pos completionFloor_lt_one).le

lemma lowProfile_local_exponential_lower {N : ℕ} (_hN : 2≤N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (_hf : 0≤f) (_hf1 : f<1) (hx : 0≤x) (_hx1 : x≤1)
    (hy : x≤s) :
    Real.exp (-degreeOneLocalLowerConstant f*s)*(x/s)^s≤lowProfile N s f x := by
  simpa only [degreeOneLocalLowerConstant,lowProfile_completionFloor] using
    (lowProfile_local_power_lower (N:=N) hs hs1 (completionFloor_pos (f:=f))
      completionFloor_lt_one hx hy)

def degreeOneFloorConstant (f : ℝ) : ℝ := lowProfileLinearConstant f

theorem degreeOneFloorConstant_pos {f : ℝ} (hf : 0<f) (_hf1 : f<1) :
    0<degreeOneFloorConstant f := lowProfileLinearConstant_pos hf

lemma lowProfile_transition_floor {N : ℕ} (_hN : 2≤N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (_hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1)
    (hy : s≤x) : degreeOneFloorConstant f≤lowProfile N s f x := by
  have hq := completionFloor_pos (f:=f)
  have hq1 := completionFloor_lt_one (f:=f)
  have hc := coefficient_spec hs hf1
  have hp := degreeOneProfile_power_lower hs hs1 hc.1 hq hq1 hc.2 ⟨hx,hx1⟩
  have hpow : 1≤(x/s)^s := Real.one_le_rpow ((le_div_iff₀ hs).mpr (by simpa using hy)) hs.le
  have hlog := Real.log_nonpos (sub_nonneg.mpr hq1.le) (by linarith only [hq] : 1-completionFloor f≤1)
  have he : 1-completionFloor f≤Real.exp (Real.log (1-completionFloor f)*s) := by
    calc
      _ = Real.exp (Real.log (1-completionFloor f)) := (Real.exp_log (sub_pos.mpr hq1)).symm
      _ ≤ _ := Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonpos_left hs1 hlog])
  have hmul := mul_le_mul he hpow (by norm_num : (0:ℝ)≤1) (Real.exp_pos _).le
  simp only [mul_one] at hmul
  exact (min_le_min (le_refl _) hmul).trans hp

end Renyi.DegreeOneCompletion
