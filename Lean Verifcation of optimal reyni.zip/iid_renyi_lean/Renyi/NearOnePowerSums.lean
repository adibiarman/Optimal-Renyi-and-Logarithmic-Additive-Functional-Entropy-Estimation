import Renyi.UpperBaseline
import Renyi.HighOrderNorm

/-! Power-sum ratios needed for uniform near-one stochastic calibration. -/
set_option maxHeartbeats 500000
noncomputable section
open scoped BigOperators
namespace Renyi

theorem simplex_powerSum_double_order {k : ℕ} (p : Simplex k) {alpha : ℝ}
    (halpha : 1 < alpha) :
    powerSum p (2 * alpha - 1) ≤ (powerSum p alpha) ^ (2 - 1 / alpha) := by
  let P := powerSum p alpha
  have hP : 0 < P := simplex_powerSum_pos p alpha
  have ha0 : 0 < alpha := by linarith
  have hexp : 0 ≤ (alpha - 1) / alpha := div_nonneg (by linarith) ha0.le
  have hi (i : Fin k) : p.mass i ^ alpha ≤ P :=
    Finset.single_le_sum (fun j _ => Real.rpow_nonneg (p.nonneg j) _) (Finset.mem_univ i)
  have hterm (i : Fin k) : p.mass i ^ (2 * alpha - 1) ≤
      p.mass i ^ alpha * P ^ ((alpha - 1) / alpha) := by
    have hm := Real.rpow_le_rpow (Real.rpow_nonneg (p.nonneg i) alpha) (hi i) hexp
    rw [← Real.rpow_mul (p.nonneg i), show alpha * ((alpha - 1) / alpha) = alpha - 1 by field_simp] at hm
    have hm' := mul_le_mul_of_nonneg_left hm (Real.rpow_nonneg (p.nonneg i) alpha)
    rw [← Real.rpow_add_of_nonneg (p.nonneg i) ha0.le (by linarith : 0 ≤ alpha - 1)] at hm'
    simpa only [show alpha + (alpha - 1) = 2 * alpha - 1 by ring] using hm'
  have hsum := Finset.sum_le_sum (s := Finset.univ) (fun i _ => hterm i)
  have heq : P * P ^ ((alpha - 1) / alpha) = P ^ (2 - 1 / alpha) := by
    calc
      P * P ^ ((alpha - 1) / alpha) = P ^ (1 : ℝ) * P ^ ((alpha - 1) / alpha) := by rw [Real.rpow_one]
      _ = P ^ (1 + (alpha - 1) / alpha) := (Real.rpow_add hP _ _).symm
      _ = _ := by congr 1; field_simp; ring
  rw [← Finset.sum_mul] at hsum
  exact hsum.trans_eq heq

theorem simplex_powerSum_double_order_ratio {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {alpha : ℝ} (halpha : 1 < alpha) :
    powerSum p (2 * alpha - 1) / (powerSum p alpha) ^ 2 ≤ (k : ℝ) ^ ((alpha - 1) / alpha) := by
  have hk0 : (0 : ℝ) < k := by exact_mod_cast hk
  have hP := simplex_powerSum_pos p alpha
  have ha0 : 0 < alpha := by linarith
  have hbase := simplex_powerSum_uniform_lower hk p halpha.le
  have hnegative := Real.rpow_le_rpow_of_nonpos (Real.rpow_pos_of_pos hk0 (1 - alpha)) hbase
    (neg_nonpos.mpr (one_div_nonneg.mpr ha0.le))
  have hright : ((k : ℝ) ^ (1 - alpha)) ^ (-(1 / alpha)) = (k : ℝ) ^ ((alpha - 1) / alpha) := by
    rw [← Real.rpow_mul hk0.le]
    congr 1
    ring
  rw [hright] at hnegative
  have hmono := div_le_div_of_nonneg_right (simplex_powerSum_double_order p halpha) (sq_nonneg (powerSum p alpha))
  have hratio : (powerSum p alpha) ^ (2 - 1 / alpha) / (powerSum p alpha) ^ 2 =
      (powerSum p alpha) ^ (-(1 / alpha)) := by
    rw [← Real.rpow_two, ← Real.rpow_sub hP]
    congr 1
    ring
  rw [hratio] at hmono
  exact hmono.trans hnegative

theorem simplex_powerSum_near_one_ratio {k : ℕ} (hk : 0 < k) (p : Simplex k)
    {alpha : ℝ} (halpha : 1 < alpha) (halpha1 : alpha ≤ 3 / 2) :
    powerSum p (2 * alpha - 1) / (powerSum p alpha) ^ 2 ≤ (k : ℝ) ^ (1 / 3 : ℝ) := by
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hfrac : (alpha - 1) / alpha ≤ (1 / 3 : ℝ) := by
    apply (div_le_iff₀ (by linarith : 0 < alpha)).2
    linarith
  exact (simplex_powerSum_double_order_ratio hk p halpha).trans
    (Real.rpow_le_rpow_of_exponent_le hk1 hfrac)

end Renyi
