import Renyi.IntegerTails

/-! Exact moments of the common affine anchor under actual independent counts. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi
variable {ι Ω : Type*} [Fintype ι] [MeasurableSpace Ω]
variable {μ : Measure Ω} [IsProbabilityMeasure μ]

def poissonAffineAnchor (N : ι → Ω → ℕ) (n q : ℝ) : Ω → ℝ :=
  fun w => q * (1 - (∑ i, (N i w : ℝ)) / n)

omit [IsProbabilityMeasure μ] in
theorem poisson_total_count_memLp (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i))) :
    MemLp (fun w => ∑ i, (N i w : ℝ)) 2 μ := by
  exact memLp_finset_sum (s := Finset.univ) (fun i _ =>
    (poisson_nat_memLp (lam i)).comp_measurePreserving (hLaw i))

theorem poisson_total_count_mean (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i))) :
    (∫ w, ∑ i, (N i w : ℝ) ∂μ) = ∑ i, (lam i : ℝ) := by
  rw [integral_finset_sum]
  · apply Finset.sum_congr rfl
    intro i _
    have h := (hLaw i).hasLaw.integral_comp (measurable_of_countable (fun j : ℕ => (j : ℝ))).aestronglyMeasurable
    change (∫ w, ((fun j : ℕ => (j : ℝ)) ∘ N i) w ∂μ) = _
    rw [h, poisson_nat_mean]
  · intro i _
    exact ((poisson_nat_memLp (lam i)).comp_measurePreserving (hLaw i)).integrable one_le_two

omit [IsProbabilityMeasure μ] in
theorem poisson_total_count_variance (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ)) :
    variance (fun w => ∑ i, (N i w : ℝ)) μ = ∑ i, (lam i : ℝ) := by
  let X : ι → Ω → ℝ := fun i w => (N i w : ℝ)
  have hX (i : ι) : MemLp (X i) 2 μ := (poisson_nat_memLp (lam i)).comp_measurePreserving (hLaw i)
  have hpairX : Pairwise (fun i j => IndepFun (X i) (X j) μ) := by
    intro i j hij
    exact (hpair hij).comp (measurable_of_countable (fun z : ℕ => (z : ℝ)))
      (measurable_of_countable (fun z : ℕ => (z : ℝ)))
  have hv : variance (fun w => ∑ i, X i w) μ = ∑ i, variance (X i) μ := by
    convert (IndepFun.variance_sum (s := Finset.univ) (X := X)
      (fun i _ => hX i) (fun i _ j _ hij => hpairX hij)) using 1
    congr 1
    funext w
    simp only [Finset.sum_apply]
  rw [hv]
  apply Finset.sum_congr rfl
  intro i _
  have h := (hLaw i).variance_fun_comp (measurable_of_countable (fun j : ℕ => (j : ℝ))).aemeasurable
  change variance ((fun j : ℕ => (j : ℝ)) ∘ N i) μ = _
  exact h.trans (poisson_nat_variance (lam i))

/-- The full common-anchor identity: it is centered, square integrable, and has
variance exactly q squared divided by the total exposure. -/
theorem common_affine_anchor_moments (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    {n : ℝ} (hn : 0 < n) (hsum : ∑ i, (lam i : ℝ) = n) (q : ℝ) :
    MemLp (poissonAffineAnchor N n q) 2 μ ∧
      (∫ w, poissonAffineAnchor N n q w ∂μ) = 0 ∧
      variance (poissonAffineAnchor N n q) μ = q ^ 2 / n := by
  have hS := poisson_total_count_memLp N lam hLaw
  have hmean := poisson_total_count_mean N lam hLaw
  have hvar := poisson_total_count_variance N lam hLaw hpair
  rw [hsum] at hmean hvar
  have heq : poissonAffineAnchor N n q = fun w => q - (q / n) * ∑ i, (N i w : ℝ) := by
    funext w
    unfold poissonAffineAnchor
    ring
  rw [heq]
  refine ⟨(memLp_const q).sub (hS.const_mul (q / n)), ?_, ?_⟩
  · rw [integral_sub (integrable_const q) ((hS.integrable one_le_two).const_mul (q / n)),
      integral_const_mul, integral_const, hmean]
    simp only [measureReal_univ_eq_one, smul_eq_mul, one_mul]
    field_simp
    ring
  · rw [variance_const_sub (hS.const_mul (q / n)).1 q, variance_mul, hvar]
    field_simp

/-- Explicit variance budget after the source coefficient bound has been proved. -/
theorem common_affine_anchor_variance_bound (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    {n q C M : ℝ} (hn : 0 < n) (hsum : ∑ i, (lam i : ℝ) = n)
    (hC : 0 ≤ C) (hM : 0 ≤ M) (hq : |q| ≤ C * M) :
    variance (poissonAffineAnchor N n q) μ ≤ C ^ 2 * M ^ 2 / n := by
  rw [(common_affine_anchor_moments N lam hLaw hpair hn hsum q).2.2]
  have hsq := mul_le_mul hq hq (abs_nonneg q) (mul_nonneg hC hM)
  simp only [← pow_two, sq_abs, mul_pow] at hsq
  exact div_le_div_of_nonneg_right hsq hn.le

/-- The source margin absorbs the exponential low-degree coefficient bound
uniformly in its remaining scale. -/
theorem common_affine_anchor_margin_variance (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    {n q C C0 A margin d : ℝ} {m : ℕ}
    (hn : 0 < n) (hsum : ∑ i, (lam i : ℝ) = n)
    (hC : 0 ≤ C) (hCC : C ≤ C0) (hA : 0 ≤ A) (hd : 0 < d)
    (hq : |q| ≤ C ^ m * A) (hmargin : d * C0 ^ m * A ≤ margin) :
    variance (poissonAffineAnchor N n q) μ ≤ margin ^ 2 / (d ^ 2 * n) := by
  have hqmargin : |q| ≤ (1 / d) * margin := by
    have hp := mul_le_mul_of_nonneg_right (pow_le_pow_left₀ hC hCC m) hA
    have hm : d * |q| ≤ margin := by
      have hh := mul_le_mul_of_nonneg_left (hq.trans hp) hd.le
      nlinarith only [hh, hmargin]
    have hh := (le_div_iff₀ hd).2 (show |q| * d ≤ margin by nlinarith only [hm])
    simpa only [div_eq_mul_inv, one_mul, mul_one, mul_comm] using hh
  have hC0 : 0 ≤ C0 := hC.trans hCC
  have hmargin0 : 0 ≤ margin := (by positivity : 0 ≤ d * C0 ^ m * A).trans hmargin
  have hbound := common_affine_anchor_variance_bound N lam hLaw hpair hn hsum
    (by positivity : 0 ≤ 1 / d) hmargin0 hqmargin
  convert hbound using 1
  field_simp

/-- The near-one anchor keeps the beta-squared cancellation of its actual
affine coefficient. -/
theorem near_one_affine_anchor_variance (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    {n q t beta C : ℝ} (hn : 0 < n) (hsum : ∑ i, (lam i : ℝ) = n)
    (ht : 0 < t) (hbeta : 0 ≤ beta) (hC : 0 ≤ C)
    (hq : |q - t ^ beta| ≤ C * beta * t ^ beta) :
    variance (poissonAffineAnchor N n (q - t ^ beta)) μ ≤
      C ^ 2 * beta ^ 2 * t ^ (2 * beta) / n := by
  have hcoeff : |q - t ^ beta| ≤ C * (beta * t ^ beta) := by simpa only [mul_assoc] using hq
  have hbound := common_affine_anchor_variance_bound N lam hLaw hpair hn hsum hC
    (mul_nonneg hbeta (Real.rpow_nonneg ht.le _)) hcoeff
  have hp : t ^ (2 * beta) = (t ^ beta) ^ (2 : ℕ) := by
    rw [mul_comm (2 : ℝ), Real.rpow_mul ht.le, Real.rpow_two]
  rw [hp]
  convert hbound using 1
  ring

end Renyi
