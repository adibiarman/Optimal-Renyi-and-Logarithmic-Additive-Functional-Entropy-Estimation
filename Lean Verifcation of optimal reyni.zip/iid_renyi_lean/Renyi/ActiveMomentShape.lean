import Renyi.LowerJordanMoments
import Renyi.LowerActiveMass

/-! Refined mass and moment bounds for the actual active Chebyshev factor. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- The actual active mass bound controls all higher absolute moments while
its principal-ratio floor controls the small tensor parity mass. -/
theorem active_factor_moment_shape (n : ℕ) (zeta a rho s beta kappa delta : ℝ)
    (hn : 0<n) (hz0 : 0<zeta) (hz1 : zeta≤3/5)
    (ha : 0<a) (hrho : 0≤rho) (hrho1 : rho≤1) (hs : 0≤s) (hk : 0<kappa)
    (haB : a≤((zeta/8)/((n:ℝ)+1)^2)/2)
    (hpert : rho*a/((zeta/8)/((n:ℝ)+1)^2)≤zeta)
    (hbeta : s+1≤beta)
    (hprincipal : 1/2≤normalizedInterpolation (chebyshevNode n ((zeta/8)/((n:ℝ)+1)^2)) a rho s none)
    (hmass : (∑ i, negativeCoeff (normalizedInterpolation (chebyshevNode n ((zeta/8)/((n:ℝ)+1)^2)) a rho s i))≤kappa)
    (hfloor : delta*kappa≤(a/((zeta/8)/((n:ℝ)+1)^2))^s) :
    let b := (zeta/8)/((n:ℝ)+1)^2
    let u := chebyshevNode n b
    delta*kappa/4≤(∑ i, negativeCoeff (normalizedInterpolation u a rho s i)) ∧
    a^s≤4*kappa ∧
    (∑ i, |normalizedInterpolation u a rho s i| *interpolationNodes u a i^beta)≤12*zeta*kappa := by
  let b := (zeta/8)/((n:ℝ)+1)^2
  let u := chebyshevNode n b
  have hb0 : 0<b := by dsimp [b]; positivity
  have hn0 : (0:ℝ)≤n := Nat.cast_nonneg n
  have hden : (1:ℝ)≤((n:ℝ)+1)^2 := by nlinarith
  have hb1 : b<1 := by
    apply (div_lt_one (by positivity : (0:ℝ)<((n:ℝ)+1)^2)).mpr
    linarith
  have hu0 : u 0=b := chebyshevNode_zero n b hn
  have hell := lagrangeWeight_first_ge_one u (chebyshevNode_strictMono n b hb1)
    (show a≤u 0 by rw [hu0]; change a≤b/2 at haB; linarith)
  have hlower := active_negative_mass_lower u ha hb0 hrho hrho1 hu0 hell hprincipal
  have hratio : (a/b)^s≤4*kappa := by linarith
  have hbpow : 0<b^s := Real.rpow_pos_of_pos hb0 s
  have hbpow1 : b^s≤1 := Real.rpow_le_one hb0.le hb1.le hs
  have haPower : a^s≤4*kappa := by
    rw [Real.div_rpow ha.le hb0.le] at hratio
    have hh := (div_le_iff₀ hbpow).mp hratio
    have hh' := mul_le_mul_of_nonneg_left hbpow1 (show 0≤4*kappa by positivity)
    linarith
  have habs := active_absolute_power_bound n zeta a rho s beta hn hz0 hz1 ha hrho haB hpert hbeta
  refine ⟨?_,haPower,?_⟩
  · have hh := div_le_div_of_nonneg_right hfloor (by norm_num : (0:ℝ)≤4)
    exact hh.trans hlower
  · have hh := mul_le_mul_of_nonneg_left haPower (show 0≤3*zeta by positivity)
    linarith

end Renyi
