import Renyi.CoupledBoundedEnergyBase

/-! Actual high-arm reserve and cutoff lower bounds on the bounded forward band. -/
noncomputable section
namespace Renyi

def coupledBandLinearConstant (f Ω D : ℝ) : ℝ :=
  min (Real.exp (-coupledLocalLowerConstant f)) (Ω*coupledFloorConstant f/D)

theorem coupledBandLinearConstant_pos {f Ω D : ℝ} (hf : 0<f) (hf1 : f<1) (hΩ : 0<Ω) (hD : 0<D) :
    0<coupledBandLinearConstant f Ω D :=
  lt_min (Real.exp_pos _) (div_pos (mul_pos hΩ (coupledFloorConstant_pos hf hf1)) hD)

/-- The actual high arm has a linear-in-Y lower bound over every fixed transition band. -/
theorem highProfile_band_linear_lower {N : ℕ} (hN : 2≤N) {s f ω Ω D x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0<f) (hf1 : f<1) (hΩ : 0<Ω) (hΩω : Ω≤ω) (hω1 : ω<1)
    (hD : 0<D) (hx : 0≤x) (hx1 : x≤1) (hY : (N:ℝ)^2*x≤D*s) :
    coupledBandLinearConstant f Ω D*((N:ℝ)^2*x)≤s*highProfile N s f ω x := by
  have hω : 0≤ω := hΩ.le.trans hΩω
  have hY0 : 0≤(N:ℝ)^2*x := by positivity
  by_cases hlocal : (N:ℝ)^2*x≤s
  · exact (mul_le_mul_of_nonneg_right (min_le_left _ _) hY0).trans
      (highProfile_local_linear_lower hN hs hs1 hf.le hf1 hω hω1 hx hx1 hlocal)
  · have hv := highProfile_transition_floor hN hs hs1 hf.le hf1 hω hω1 hx hx1 (le_of_lt (lt_of_not_ge hlocal))
    have hΩv := (mul_le_mul_of_nonneg_right hΩω (coupledFloorConstant_pos hf hf1).le).trans hv
    have hsΩv := mul_le_mul_of_nonneg_left hΩv hs.le
    have hscale := mul_le_mul_of_nonneg_left hY
      (div_nonneg (mul_nonneg hΩ.le (coupledFloorConstant_pos hf hf1).le) hD.le)
    have hid : (Ω*coupledFloorConstant f/D)*(D*s)=s*(Ω*coupledFloorConstant f) := by field_simp
    rw [hid] at hscale
    exact (mul_le_mul_of_nonneg_right (min_le_right _ _) hY0).trans (hscale.trans hsΩv)

def coupledBandReserveConstant (f Ω D E M : ℝ) : ℝ :=
  (1-Real.exp (-E))*Real.exp (-M)*coupledBandLinearConstant f Ω D/2

theorem coupledBandReserveConstant_pos {f Ω D E M : ℝ}
    (hf : 0<f) (hf1 : f<1) (hΩ : 0<Ω) (hD : 0<D) (hE : 0<E) :
    0<coupledBandReserveConstant f Ω D E M := by
  have hb := coupledBandLinearConstant_pos hf hf1 hΩ hD
  have he : 0<1-Real.exp (-E) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  unfold coupledBandReserveConstant
  positivity

/-- The same reserved high arm supplies the full local gain throughout a fixed forward band. -/
theorem coupledProfiles_band_reserve_lower {N : ℕ} (hN : 2≤N)
    {γ z E M f ω Ω D y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hE : 0<E) (hzE : z≤Real.exp (-E)) (hM : 0≤M)
    (hf : 0<f) (hf1 : f<1) (hΩ : 0<Ω) (hΩω : Ω≤ω) (hω1 : ω<1) (hD : 0<D)
    (hy : 0≤y) (hy1 : y≤1) (hY : (N:ℝ)^2*y≤D*(1-γ)) :
    coupledBandReserveConstant f Ω D E M*overlapG γ z*((N:ℝ)^2*y)≤coupledHighReserve N γ z M f ω y := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hω : 0≤ω := hΩ.le.trans hΩω
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hG := overlapG_mem_Ioo hγ hγ1 hz hz1
  have hB : 1-Real.exp (-E)≤overlapB γ z := by
    have hh := overlap_complement_le_parameter hγ hγ1 hz hz1
    linarith only [hh,hzE]
  have he0 : 0≤1-Real.exp (-E) := sub_nonneg.mpr (Real.exp_le_one_iff.mpr (by linarith only [hE]))
  have hMexp : Real.exp (-M)≤Real.exp (-M*(1-γ)) := Real.exp_le_exp.mpr (by nlinarith only [mul_nonneg hM hγ.le])
  have hexp := exp_neg_le_linear_half hd.le hd1
  have hid : Real.exp (-(M+1)*(1-γ))=Real.exp (-M*(1-γ))*Real.exp (-(1-γ)) := by
    rw [←Real.exp_add]
    congr 1
    ring
  have hdiff : (1-Real.exp (-E))*Real.exp (-M)*((1-γ)/2)≤
      overlapB γ z*Real.exp (-M*(1-γ))-overlapB γ z*Real.exp (-(M+1)*(1-γ)) := by
    have hm := mul_le_mul hB hMexp (Real.exp_pos (-M)).le hc.2.2.1.le
    have hm' := mul_le_mul_of_nonneg_right hm (show 0≤(1-γ)/2 by positivity)
    have hhalf := mul_le_mul_of_nonneg_left hexp
      (mul_nonneg hc.2.2.1.le (Real.exp_pos (-M*(1-γ))).le)
    rw [hid]
    nlinarith only [hm',hhalf]
  have hv0 := (highProfile_range (by omega : 0<N) hd hf.le hf1.le hω hω1 hy hy1).1
  have hlocal := highProfile_band_linear_lower hN hd hd1 hf hf1 hΩ hΩω hω1 hD hy hy1 hY
  have hdiffv := mul_le_mul_of_nonneg_right hdiff hv0
  have hlin := mul_le_mul_of_nonneg_left hlocal
    (show 0≤(1-Real.exp (-E))*Real.exp (-M)/2 by positivity)
  have hgain : coupledBandReserveConstant f Ω D E M*((N:ℝ)^2*y)≤coupledHighReserve N γ z M f ω y := by
    unfold coupledBandReserveConstant coupledHighReserve
    nlinarith only [hdiffv,hlin]
  have hκ := mul_le_of_le_one_left (show 0≤coupledBandReserveConstant f Ω D E M*((N:ℝ)^2*y) by
    exact mul_nonneg (coupledBandReserveConstant_pos hf hf1 hΩ hD hE).le (by positivity)) hG.2.le
  nlinarith only [hκ,hgain]

lemma coupledProfiles_reserved_cutoff_linear {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z E M fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hE : 0≤E) (hzE : z≤Real.exp (-E)) (hM : 1≤M) (hfL : 0≤fL) (hfL1 : fL<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0<y) (hy1 : y≤1)
    (hcap : ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledReservedBase ℓ N γ z M fL f (Real.exp (-E/8)) x y-
      Real.exp (Real.log 12+1)*Real.exp (-E)*(γ*(1-γ))≤
      coupledDampedExpression ℓ N γ z M (Real.exp (-E/8)) fL f x y-
        coupledHighReserve N γ z M f (Real.exp (-E/8)) y := by
  have hcut := coupledProfiles_cutoff_lower (ℓ:=ℓ) (fL:=fL) (f:=f) (x:=x) hN
    hγ hγ1 hz hz1 hE hM hzE hy.le hy1
  dsimp only at hcut
  change (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ fL x+
    (overlapB γ z*Real.exp (-M*(1-γ)))*highProfile N (1-γ) f (Real.exp (-E/8)) y-
    max ((overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ fL x-1+overlapB γ z) 0*endpointProfile N 6 1 y≤
    coupledDampedExpression ℓ N γ z M (Real.exp (-E/8)) fL f x y at hcut
  have hloss := coupledProfiles_cutoff_loss hℓ hN hγ hγ1 hz hz1 hzE (show 0≤M by linarith only [hM]) hfL hfL1 hx hx1 hy hy1 hcap
  unfold coupledReservedBase coupledHighReserve
  nlinarith only [hcut,hloss]

lemma coupledProfiles_reserved_high_lower {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z M ω fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hM : 0≤M) (hω : 0≤ω) (_hω1 : ω<1)
    (hfL : 0≤fL) (hfL1 : fL<1) (_hf : 0≤f) (_hf1 : f≤1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1) :
    (overlapB γ z*Real.exp (-(M+1)*(1-γ)))*highProfile N (1-γ) f ω y≤
      coupledDampedExpression ℓ N γ z M ω fL f x y-coupledHighReserve N γ z M f ω y := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := (lowProfile_range hℓ hγ hfL hfL1 hx hx1).1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hy hy1
  have hb1 : overlapB γ z*Real.exp (-M*(1-γ))≤1 :=
    (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hd]))
  have hl0 := mul_nonneg (mul_nonneg (mul_nonneg hc.1.le (Real.exp_pos (-M*γ)).le) hu) (sub_nonneg.mpr hH.2)
  have hj0 := mul_nonneg (mul_nonneg hω (sub_nonneg.mpr hb1)) hJ.1
  unfold coupledDampedExpression coupledHighReserve
  nlinarith only [hl0,hj0]

lemma small_affine_exponential_lower {T S κ K D h : ℝ}
    (hκ : 0≤κ) (hK : 0≤K) (hD : 0≤D) (hh : 0≤h) (hh1 : h≤1/4)
    (hsmall : 2*(D*Real.exp (K/4))*h≤1) (hbase : κ*Real.exp (-K*h)≤S)
    (hlinear : S-D*κ*h≤T) :
    κ*Real.exp (-(K+2*(D*Real.exp (K/4)))*h)≤T := by
  let L := D*Real.exp (K/4)
  have hL : 0≤L := mul_nonneg hD (Real.exp_pos _).le
  have hexp := exp_neg_le_linear_half (show 0≤2*L*h by positivity) hsmall
  have hm := mul_le_mul_of_nonneg_left hexp (mul_nonneg hκ (Real.exp_pos (-K*h)).le)
  have hKexp : Real.exp (-K/4)≤Real.exp (-K*h) := Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_left hh1 hK])
  have hloss := mul_le_mul_of_nonneg_left hKexp hL
  have hid : L*Real.exp (-K/4)=D := by
    dsimp [L]
    rw [mul_assoc,←Real.exp_add,show K/4+-K/4=0 by ring,Real.exp_zero,mul_one]
  rw [hid] at hloss
  have hbudget := mul_le_mul_of_nonneg_right hloss (mul_nonneg hκ hh)
  have hid' : (κ*Real.exp (-K*h))*Real.exp (-(2*L*h))=κ*Real.exp (-(K+2*L)*h) := by
    rw [mul_assoc,←Real.exp_add]
    congr 2
    ring
  rw [hid'] at hm
  dsimp [L] at *
  nlinarith only [hm,hbudget,hbase,hlinear]

end Renyi
