import Renyi.CompletedConditionalCountCertificate
import Renyi.CompletedPilotCalibration

/-! Canonical integer profile resolutions and actual count scales. -/
noncomputable section
namespace Renyi

def upperLowResolution (alpha : ℝ) : ℕ := upperOrderFloor alpha / 4 + 1

def upperCountDegree (k : ℕ) (alpha eps CL cL : ℝ) : ℕ :=
  upperOrderFloor alpha + 1 + 18 * (upperDegree alpha CL cL (rootMultiplier k alpha eps) - 1)

theorem upperLowResolution_geometry {alpha : ℝ} (halpha : 1 < alpha) :
    0 < upperLowResolution alpha ∧ upperLowResolution alpha ≤ upperOrderFloor alpha ∧
      4 * (upperLowResolution alpha - 1) ≤ upperOrderFloor alpha := by
  have hm := upperOrderFloor_one_le halpha
  unfold upperLowResolution
  have hh := Nat.div_mul_le_self (upperOrderFloor alpha) 4
  omega

/-- All count-specific geometric hypotheses follow from the actual source cutoffs. -/
theorem upper_actual_count_geometry {k : ℕ} {alpha eps Ch D cb lambda CL cL : ℝ}
    (hk : 0 < k) (halpha : 3 / 2 ≤ alpha) (hg : 0 < fractionalPart alpha)
    (hg1 : fractionalPart alpha < 1) (heps : 0 < eps) (hCh : 0 ≤ Ch) (hD : 0 < D)
    (hcb : 0 < cb) (hlambda : 0 < lambda) (hlambda4 : lambda ≤ 4)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hcbCL : 1 ≤ cb * CL) :
    let a := upperA k alpha eps Ch D cb lambda CL cL
    let b := upperB k alpha eps D cb CL cL
    let n := upperSample k alpha eps D
    let N := upperDegree alpha CL cL (rootMultiplier k alpha eps)
    let ell := upperLowResolution alpha
    let d := upperCountDegree k alpha eps CL cL
    0 < a ∧ a ≤ b ∧ 0 < b ∧ 0 < ell ∧ 2 ≤ N ∧
      ell ≤ upperOrderFloor alpha ∧ 4 * (ell - 1) ≤ upperOrderFloor alpha ∧
      (ell : ℝ) ≤ N ∧ (ell : ℝ) ^ 2 * (a * (N : ℝ) ^ 2 / b) ≤ 1 ∧
      n * b = cb * N ∧ 1 ≤ n * b ∧ (N : ℝ) ^ 2 / (n * b) ≤ (1 / cb) * N ∧
      upperOrderFloor alpha + 1 ≤ d ∧ (d : ℝ) ≤ 20 * N ∧ (d : ℝ) ≤ (20 / cb) * (n * b) := by
  dsimp only
  have ha1 : 1 < alpha := by linarith
  have hX := one_le_rootMultiplier (k := k) (ε := eps) ha1 hg hg1
  have hn := upperSample_pos hk ha1 hg hg1 hD (ε := eps)
  have hb := upperB_pos hk ha1 hg hg1 hD hcb hCL hcL (ε := eps)
  have hN := upperDegree_pos ha1 hCL hcL hX
  have hNpos : (0 : ℝ) < upperDegree alpha CL cL (rootMultiplier k alpha eps) := by exact_mod_cast hN
  have hdegree := (upperDegree_bounds ha1 hCL hcL hX).1
  have haN : alpha ≤ (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) := by nlinarith only [hdegree, hCL, halpha]
  have hN2 : 2 ≤ upperDegree alpha CL cL (rootMultiplier k alpha eps) := by
    by_contra h
    have hh : (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ≤ 1 := by exact_mod_cast (show upperDegree alpha CL cL (rootMultiplier k alpha eps) ≤ 1 by omega)
    linarith
  have hell := upperLowResolution_geometry ha1
  have hm : 0 < (upperOrderFloor alpha : ℝ) := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one (upperOrderFloor_one_le ha1))
  have hellm : (upperLowResolution alpha : ℝ) ≤ upperOrderFloor alpha := by exact_mod_cast hell.2.1
  have hmN : (upperOrderFloor alpha : ℝ) ≤ upperDegree alpha CL cL (rootMultiplier k alpha eps) :=
    (upperOrderFloor_le ha1).trans haN
  have hcap := upper_convolution hk ha1 hg hg1 heps hCh hD hcb hlambda hCL hcL
  have hcaple := hcap.1.trans_le hcap.2
  have ha : 0 < upperA k alpha eps Ch D cb lambda CL cL := by
    unfold upperA upperOverlapZ
    have hd : 0 < 1 - fractionalPart alpha := sub_pos.mpr hg1
    positivity
  have hlocalm : upperA k alpha eps Ch D cb lambda CL cL * (upperOrderFloor alpha : ℝ)^2 *
      (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)^2 / upperB k alpha eps D cb CL cL ≤ 1 := by linarith
  have hlocal : (upperLowResolution alpha : ℝ)^2 *
      (upperA k alpha eps Ch D cb lambda CL cL * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)^2 /
        upperB k alpha eps D cb CL cL) ≤ 1 := by
    have hs := pow_le_pow_left₀ (by positivity : (0 : ℝ) ≤ upperLowResolution alpha) hellm 2
    have hmultiply := mul_le_mul_of_nonneg_right hs (show 0 ≤ upperA k alpha eps Ch D cb lambda CL cL *
      (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)^2 / upperB k alpha eps D cb CL cL by positivity)
    apply hmultiply.trans
    convert hlocalm using 1
    ring
  have hab : upperA k alpha eps Ch D cb lambda CL cL ≤ upperB k alpha eps D cb CL cL := by
    have hden : 1 ≤ (upperOrderFloor alpha : ℝ)^2 * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)^2 := by
      have hm1 : (1 : ℝ) ≤ upperOrderFloor alpha := by exact_mod_cast upperOrderFloor_one_le ha1
      have hN1 : (1 : ℝ) ≤ upperDegree alpha CL cL (rootMultiplier k alpha eps) := by exact_mod_cast (show 1 ≤ upperDegree alpha CL cL (rootMultiplier k alpha eps) by omega)
      nlinarith only [hm1, hN1, sq_nonneg ((upperOrderFloor alpha : ℝ) - 1), sq_nonneg ((upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) - 1)]
    have hh := (div_le_iff₀ hb).mp hlocalm
    have hmul := mul_le_mul_of_nonneg_left hden ha.le
    nlinarith only [hh, hmul]
  have hnb : upperSample k alpha eps D * upperB k alpha eps D cb CL cL =
      cb * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) := by unfold upperB; field_simp
  have hnb1 : 1 ≤ upperSample k alpha eps D * upperB k alpha eps D cb CL cL := by
    rw [hnb]
    have hCLN : CL ≤ (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) := by nlinarith only [hdegree, halpha, hCL]
    exact hcbCL.trans (mul_le_mul_of_nonneg_left hCLN hcb.le)
  have hscale : (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)^2 /
      (upperSample k alpha eps D * upperB k alpha eps D cb CL cL) ≤
      (1 / cb) * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) := by
    rw [hnb]
    apply le_of_eq
    field_simp
  have hdL : (upperCountDegree k alpha eps CL cL : ℝ) ≤ 20 *
      (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) := by
    have hN1 : 1 ≤ upperDegree alpha CL cL (rootMultiplier k alpha eps) := by omega
    unfold upperCountDegree
    push_cast [Nat.cast_sub hN1]
    nlinarith only [hmN, hNpos]
  have hdH : (upperCountDegree k alpha eps CL cL : ℝ) ≤ (20 / cb) *
      (upperSample k alpha eps D * upperB k alpha eps D cb CL cL) := by
    rw [hnb]
    convert hdL using 1
    field_simp
  exact ⟨ha, hab, hb, hell.1, hN2, hell.2.1, hell.2.2, hellm.trans hmN,
    hlocal, hnb, hnb1, hscale, by unfold upperCountDegree; omega, hdL, hdH⟩

end Renyi
