import Renyi.AnalyticCounts
import Renyi.GammaTail
import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
import Mathlib.MeasureTheory.Integral.DominatedConvergence

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Set
namespace Renyi

/-- The actual Poisson mean series is absolutely convergent for every real order. -/
theorem analyticCount_pmf_summable (lam : ℝ≥0) (a : ℝ) :
    Summable (fun j => analyticCount a j * poissonPMFReal lam j) := by
  obtain ⟨m, C, hC, hbound⟩ := analyticCount_polynomial_growth a
  have hexp := (poisson_exp_hasSum lam 1).summable.mul_left
    (C * (m.factorial : ℝ) * Real.exp 1)
  apply hexp.of_norm_bounded
  intro j
  simp only [norm_mul, Real.norm_eq_abs, abs_of_nonneg poissonPMFReal_nonneg, one_mul]
  have hp := real_pow_le_factorial_mul_exp ((j : ℝ) + 1) (by positivity) m
  rw [Real.exp_add] at hp
  calc
    _ ≤ (C * ((j : ℝ) + 1) ^ m) * poissonPMFReal lam j :=
      mul_le_mul_of_nonneg_right (hbound j) poissonPMFReal_nonneg
    _ ≤ (C * ((m.factorial : ℝ) * (Real.exp (j : ℝ) * Real.exp 1))) * poissonPMFReal lam j := by
      exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hp hC) poissonPMFReal_nonneg
    _ = _ := by ring

/-- Shifting the absolutely convergent series gives a first-order recurrence in the order. -/
theorem analyticMean_order_succ (lam : ℝ≥0) (a : ℝ) :
    analyticMean lam (a + 1) = (lam : ℝ) * analyticMean lam a +
      Real.exp (-(lam : ℝ)) / Real.Gamma (-a) := by
  rw [analyticMean_eq_tsum, (analyticCount_pmf_summable lam (a + 1)).tsum_eq_zero_add,
    analyticMean_eq_tsum, ← tsum_mul_left]
  have hterm (j : ℕ) : analyticCount (a + 1) (j + 1) * poissonPMFReal lam (j + 1) =
      (lam : ℝ) * (analyticCount a j * poissonPMFReal lam j) := by
    unfold analyticCount poissonPMFReal
    have hj : (j.factorial : ℝ) ≠ 0 := by positivity
    have hj1 : ((j + 1).factorial : ℝ) ≠ 0 := by positivity
    have hexp : ((j + 1 : ℕ) : ℝ) + 1 - (a + 1) = (j : ℝ) + 1 - a := by push_cast; ring
    rw [hexp, pow_succ]
    field_simp
  simp_rw [hterm]
  rw [add_comm]
  congr 1
  simp [analyticCount, poissonPMFReal]
  ring

/-- Complex beta kernels at real parameters agree with the real integrand. -/
theorem beta_nat_kernel (a : ℝ) (j : ℕ) {t : ℝ} (ht : t ∈ Icc (0 : ℝ) 1) :
    (t : ℂ) ^ (((j : ℝ) + 1 : ℝ) - 1 : ℂ) *
      (1 - (t : ℂ)) ^ ((-a : ℝ) - 1 : ℂ) =
        ((t ^ j * (1 - t) ^ (-a - 1) : ℝ) : ℂ) := by
  rw [show (((j : ℝ) + 1 : ℝ) - 1 : ℂ) = (j : ℂ) by push_cast; ring]
  rw [Complex.cpow_natCast]
  have hsub : 1 - (t : ℂ) = ((1 - t : ℝ) : ℂ) := by push_cast; ring
  rw [hsub]
  rw [show ((-a : ℝ) : ℂ) - 1 = ((-a - 1 : ℝ) : ℂ) by push_cast; ring]
  rw [← Complex.ofReal_cpow (sub_nonneg.mpr ht.2)]
  push_cast
  ring

/-- The beta integral supplies the negative-order kernel, including its normalizing constant. -/
theorem analyticCount_beta (a : ℝ) (ha : a < 0) (j : ℕ) :
    analyticCount a j = (Real.Gamma (-a))⁻¹ *
      ∫ t : ℝ in 0..1, t ^ j * (1 - t) ^ (-a - 1) := by
  have hu : 0 < (((j : ℝ) + 1 : ℝ) : ℂ).re := by simp; positivity
  have hv : 0 < ((-a : ℝ) : ℂ).re := by simpa using neg_pos.mpr ha
  have hb := Complex.betaIntegral_eq_Gamma_mul_div
    (((j : ℝ) + 1 : ℝ) : ℂ) ((-a : ℝ) : ℂ) hu hv
  have heq : Complex.betaIntegral (((j : ℝ) + 1 : ℝ) : ℂ) ((-a : ℝ) : ℂ) =
      ((∫ t : ℝ in 0..1, t ^ j * (1 - t) ^ (-a - 1) : ℝ) : ℂ) := by
    unfold Complex.betaIntegral
    rw [← intervalIntegral.integral_ofReal]
    apply intervalIntegral.integral_congr
    intro t ht
    exact beta_nat_kernel a j (by simpa using ht)
  rw [heq, ← Complex.ofReal_add, Complex.Gamma_ofReal, Complex.Gamma_ofReal,
    Complex.Gamma_ofReal] at hb
  have hbR := congrArg Complex.re hb
  simp only [← Complex.ofReal_mul, ← Complex.ofReal_div, Complex.ofReal_re] at hbR
  rw [Real.Gamma_nat_eq_factorial] at hbR
  unfold analyticCount
  have hg : Real.Gamma (-a) ≠ 0 := (Real.Gamma_pos_of_pos (neg_pos.mpr ha)).ne'
  have harg : (j : ℝ) + 1 + -a = (j : ℝ) + 1 - a := by ring
  rw [harg] at hbR
  rw [hbR]
  field_simp

/-- The real beta kernel is integrable for every negative order. -/
theorem analyticCount_beta_integrable (a : ℝ) (ha : a < 0) (j : ℕ) :
    IntervalIntegrable (fun t : ℝ => t ^ j * (1 - t) ^ (-a - 1)) volume 0 1 := by
  have hu : 0 < (((j : ℝ) + 1 : ℝ) : ℂ).re := by simp; positivity
  have hv : 0 < ((-a : ℝ) : ℂ).re := by simpa using neg_pos.mpr ha
  have h := Complex.betaIntegral_convergent hu hv
  have hre : IntervalIntegrable
      (fun t : ℝ => ((t : ℂ) ^ (((j : ℝ) + 1 : ℝ) - 1 : ℂ) *
        (1 - (t : ℂ)) ^ ((-a : ℝ) - 1 : ℂ)).re) volume 0 1 := ⟨h.1.re, h.2.re⟩
  apply hre.congr
  intro t ht
  have htc : t ∈ Icc (0 : ℝ) 1 := by
    rw [uIoc_of_le (by norm_num : (0 : ℝ) ≤ 1)] at ht
    exact ⟨ht.1.le, ht.2⟩
  dsimp only
  rw [beta_nat_kernel a j htc, Complex.ofReal_re]

/-- The Poisson power generating function, also at the zero endpoint. -/
theorem poisson_power_hasSum (lam : ℝ≥0) (t : ℝ) :
    HasSum (fun j : ℕ => poissonPMFReal lam j * t ^ j)
      (Real.exp ((lam : ℝ) * (t - 1))) := by
  have h := (NormedSpace.expSeries_div_hasSum_exp ℝ ((lam : ℝ) * t)).mul_left
    (Real.exp (-(lam : ℝ)))
  rw [← Real.exp_eq_exp_ℝ] at h
  convert h using 1
  · funext j
    simp only [poissonPMFReal, mul_pow]
    ring
  · rw [← Real.exp_add]
    congr 1
    ring

/-- Before subtracting the Gamma tail, the negative-order mean is an integral over the unit interval. -/
theorem analyticMean_negative_unit_integral (lam : ℝ≥0) (a : ℝ) (ha : a < 0) :
    analyticMean lam a = (Real.Gamma (-a))⁻¹ *
      ∫ u : ℝ in 0..1, Real.exp (-(lam : ℝ) * u) * u ^ (-a - 1) := by
  let F : ℕ → ℝ → ℝ := fun j t => poissonPMFReal lam j * (t ^ j * (1 - t) ^ (-a - 1))
  let b : ℕ → ℝ → ℝ := fun j t => poissonPMFReal lam j * (1 - t) ^ (-a - 1)
  let f : ℝ → ℝ := fun t => Real.exp ((lam : ℝ) * (t - 1)) * (1 - t) ^ (-a - 1)
  have hbint : IntervalIntegrable (fun t => ∑' j, b j t) volume 0 1 := by
    have heq : (fun t => ∑' j, b j t) = fun t : ℝ => (1 - t) ^ (-a - 1) := by
      funext t
      simp only [b, tsum_mul_right, (poissonPMFRealSum lam).tsum_eq, one_mul]
    rw [heq]
    simpa only [pow_zero, one_mul] using analyticCount_beta_integrable a ha 0
  have hsum : HasSum (fun j => ∫ t in 0..1, F j t) (∫ t in 0..1, f t) := by
    apply intervalIntegral.hasSum_integral_of_dominated_convergence b
    · intro j
      fun_prop
    · intro j
      filter_upwards [] with t ht
      rw [uIoc_of_le (by norm_num : (0 : ℝ) ≤ 1)] at ht
      have hnon : 0 ≤ (1 - t) ^ (-a - 1) := Real.rpow_nonneg (sub_nonneg.mpr ht.2) _
      have htj : 0 ≤ t ^ j := pow_nonneg ht.1.le _
      have hpow : t ^ j ≤ 1 := pow_le_one₀ ht.1.le ht.2
      simp only [F, b, Real.norm_eq_abs,
        abs_of_nonneg (mul_nonneg poissonPMFReal_nonneg (mul_nonneg htj hnon))]
      exact mul_le_mul_of_nonneg_left
        (by simpa using mul_le_mul_of_nonneg_right hpow hnon) poissonPMFReal_nonneg
    · filter_upwards [] with t _
      exact (poissonPMFRealSum lam).summable.mul_right _
    · exact hbint
    · filter_upwards [] with t _
      convert (poisson_power_hasSum lam t).mul_right ((1 - t) ^ (-a - 1)) using 1
      funext j
      simp only [F]
      ring
  have hint (j : ℕ) : (∫ t in 0..1, F j t) =
      Real.Gamma (-a) * (analyticCount a j * poissonPMFReal lam j) := by
    simp only [F, intervalIntegral.integral_const_mul]
    rw [analyticCount_beta a ha j]
    have hg : Real.Gamma (-a) ≠ 0 := (Real.Gamma_pos_of_pos (neg_pos.mpr ha)).ne'
    field_simp
  simp_rw [hint] at hsum
  have hmean : Real.Gamma (-a) * analyticMean lam a = ∫ t in 0..1, f t := by
    rw [analyticMean_eq_tsum, ← tsum_mul_left]
    exact hsum.tsum_eq
  have hsub : (∫ t in 0..1, f t) =
      ∫ u : ℝ in 0..1, Real.exp (-(lam : ℝ) * u) * u ^ (-a - 1) := by
    have h := intervalIntegral.integral_comp_sub_left
      (fun u : ℝ => Real.exp (-(lam : ℝ) * u) * u ^ (-a - 1)) (a := 0) (b := 1) 1
    norm_num only [sub_self, sub_zero] at h
    rw [← h]
    apply intervalIntegral.integral_congr
    intro t _
    dsimp [f]
    congr 2
    ring
  rw [hsub] at hmean
  have hg : Real.Gamma (-a) ≠ 0 := (Real.Gamma_pos_of_pos (neg_pos.mpr ha)).ne'
  rw [← hmean]
  field_simp

/-- The exact formula propagates one order upward without analytic continuation. -/
theorem analyticMean_formula_order_step (lam : ℝ≥0) (hlam : 0 < (lam : ℝ)) (a : ℝ)
    (ha : analyticMean lam a = (lam : ℝ) ^ a -
      (Real.Gamma (-a))⁻¹ * gammaTail a lam) :
    analyticMean lam (a + 1) = (lam : ℝ) ^ (a + 1) -
      (Real.Gamma (-(a + 1)))⁻¹ * gammaTail (a + 1) lam := by
  have hg : (Real.Gamma (-(a + 1)))⁻¹ = -(a + 1) * (Real.Gamma (-a))⁻¹ := by
    rw [gamma_inv_recurrence (-(a + 1))]
    rw [show -(a + 1) + 1 = -a by ring]
  rw [analyticMean_order_succ, ha, Real.rpow_add hlam, Real.rpow_one, hg, div_eq_mul_inv]
  have ht := gammaTail_recurrence a hlam
  linear_combination -(Real.Gamma (-a))⁻¹ * ht

/-- Subtracting the upper tail from the complete Gamma integral proves the negative-order base. -/
theorem analyticMean_exact_negative (lam : ℝ≥0) (hlam : 0 < (lam : ℝ))
    (a : ℝ) (ha : a < 0) :
    analyticMean lam a = (lam : ℝ) ^ a - (Real.Gamma (-a))⁻¹ * gammaTail a lam := by
  have hs := gamma_unit_add_tail ha hlam
  have hu : (∫ t in (0 : ℝ)..1, gammaTailIntegrand a lam t) =
      Real.Gamma (-a) * (lam : ℝ) ^ a - gammaTail a lam := by linarith
  rw [analyticMean_negative_unit_integral lam a ha]
  change (Real.Gamma (-a))⁻¹ * (∫ t in (0 : ℝ)..1, gammaTailIntegrand a lam t) = _
  rw [hu]
  have hg : Real.Gamma (-a) ≠ 0 := (Real.Gamma_pos_of_pos (neg_pos.mpr ha)).ne'
  field_simp

/-- The exact analytic-count mean formula for every real order and every positive intensity.

The proof uses the negative-order Beta integral and finitely many applications
of the order recurrence; no analytic-continuation assumption is needed.
-/
theorem analyticMean_exact (lam : ℝ≥0) (hlam : 0 < (lam : ℝ)) (a : ℝ) :
    analyticMean lam a = (lam : ℝ) ^ a - (Real.Gamma (-a))⁻¹ * gammaTail a lam := by
  have hdegree : ∀ n : ℕ, ∀ b : ℝ, b < n →
      analyticMean lam b = (lam : ℝ) ^ b - (Real.Gamma (-b))⁻¹ * gammaTail b lam := by
    intro n
    induction n with
    | zero =>
        intro b hb
        exact analyticMean_exact_negative lam hlam b (by simpa using hb)
    | succ n ih =>
        intro b hb
        have hprev : b - 1 < (n : ℝ) := by push_cast at hb; linarith
        simpa only [sub_add_cancel] using
          analyticMean_formula_order_step lam hlam (b - 1) (ih (b - 1) hprev)
  obtain ⟨n, hn⟩ := exists_nat_gt a
  exact hdegree n a hn

end Renyi
