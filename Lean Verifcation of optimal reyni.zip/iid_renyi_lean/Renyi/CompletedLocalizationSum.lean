import Renyi.LocalizationPowerSum
import Renyi.CompletedBelowCutoff

/-! Full finite-sum localized bias for arbitrary actual light assignments. -/
noncomputable section
open scoped BigOperators
open Polynomial
namespace Renyi
set_option maxHeartbeats 800000

lemma localization_scale_identity {N : ℕ} (hN : 0<N) {p b : ℝ} (hp : 0<p) (hb : 0<b) :
    ((N:ℝ)^2*(p/b))^(-2:ℝ)=((b/(N:ℝ)^2)/p)^2 := by
  rw [Real.rpow_neg (by positivity),Real.rpow_two]
  field_simp

/-- The same completed polynomial has a uniform localized power-sum bias.
This includes the below-a contribution and any deterministic rescaling in [0,1]. -/
theorem completed_polynomial_localized_sum {k ell N m : ℕ} (hk : 0<k)
    (hell : 0<ell) (hN : 0<N) (hm : 1≤m) (hdegree : 4*(ell-1)≤m)
    {gamma a b fL f A B omega sigma : ℝ}
    (hg : 0<gamma) (hg1 : gamma<1) (ha : 0<a) (hab : a≤b)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hA : 0≤A) (hA1 : A≤1) (hB : 0≤B) (hB1 : B≤1)
    (hw : 0≤omega) (hw1 : omega<1) (hs : 0≤sigma) (hs1 : sigma≤1)
    (p : Simplex k) (light : Fin k→Bool) (hlight : ∀i,light i=true→p.mass i≤b) :
    let alpha := (m:ℝ)+gamma
    let Q := completedCoupledPolynomial ell N m gamma a b (DegreeOneCompletion.coefficient gamma fL) fL f A B omega
    |(∑i,if light i then sigma*Q.eval (p.mass i) else sigma*omega*p.mass i^alpha)-
      sigma*omega*powerSum p alpha|≤
      (k:ℝ)*(100:ℝ)^(m+1)*a^alpha+
        2*completedLocalizationConstant*((k:ℝ)*(b/(N:ℝ)^2))^(min alpha 2)*powerSum p alpha := by
  let alpha := (m:ℝ)+gamma
  let Q := completedCoupledPolynomial ell N m gamma a b (DegreeOneCompletion.coefficient gamma fL) fL f A B omega
  let t := b/(N:ℝ)^2
  let nu := min alpha 2
  let err := (100:ℝ)^(m+1)*a^alpha
  have hb : 0<b := ha.trans_le hab
  have halpha : 1≤alpha := by
    have hmm : (1:ℝ)≤m := by exact_mod_cast hm
    dsimp [alpha]
    linarith only [hmm,hg]
  have ht : 0≤t := by dsimp [t];positivity
  have hnu : 0≤nu := le_min (by linarith only [halpha]) (by norm_num)
  have hnu2 : nu≤2 := min_le_right _ _
  have hnua : nu≤alpha := min_le_left _ _
  have herr : 0≤err := by dsimp [err];positivity
  have hC : 0≤completedLocalizationConstant := completedLocalizationConstant_pos.le
  have hterm (i:Fin k) : |(if light i then sigma*Q.eval (p.mass i) else sigma*omega*p.mass i^alpha)-
      sigma*omega*p.mass i^alpha|≤err+completedLocalizationConstant*(p.mass i^alpha*min 1 ((t/p.mass i)^2)) := by
    have htail0 : 0≤completedLocalizationConstant*(p.mass i^alpha*min 1 ((t/p.mass i)^2)) :=
      mul_nonneg hC (mul_nonneg (Real.rpow_nonneg (p.nonneg i) _) (le_min (by norm_num) (sq_nonneg _)))
    by_cases hl : light i=true
    · simp only [hl,ite_true]
      have hid : sigma*Q.eval (p.mass i)-sigma*omega*p.mass i^alpha=
          sigma*(Q.eval (p.mass i)-omega*p.mass i^alpha) := by ring
      rw [hid,abs_mul,abs_of_nonneg hs]
      have hscale : sigma*|Q.eval (p.mass i)-omega*p.mass i^alpha|≤
          |Q.eval (p.mass i)-omega*p.mass i^alpha| := mul_le_of_le_one_left (abs_nonneg _) hs1
      by_cases hpa : a≤p.mass i
      · have hp : 0<p.mass i := ha.trans_le hpa
        have hloc := completedCoupledPolynomial_localization hell hN hm hdegree hg hg1 ha hpa
          (hlight i hl) hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1
        rw [localization_scale_identity hN hp hb] at hloc
        change |Q.eval (p.mass i)-omega*p.mass i^alpha|≤
          completedLocalizationConstant*p.mass i^alpha*min 1 ((t/p.mass i)^2) at hloc
        nlinarith only [hscale,hloc,herr]
      · have hlow := completedCoupledPolynomial_below_cutoff_exponential hell hN hm hdegree hg hg1 ha hab
          (p.nonneg i) (le_of_not_ge hpa) (DegreeOneCompletion.coefficient_spec hg hfL1).1
          hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1
        change |Q.eval (p.mass i)|+p.mass i^alpha≤err at hlow
        have htri := abs_sub (Q.eval (p.mass i)) (omega*p.mass i^alpha)
        rw [abs_of_nonneg (mul_nonneg hw (Real.rpow_nonneg (p.nonneg i) _))] at htri
        have hwP := mul_le_of_le_one_left (Real.rpow_nonneg (p.nonneg i) alpha) hw1.le
        nlinarith only [hscale,hlow,htri,hwP,htail0]
    · simp only [Bool.eq_false_iff.mpr hl,Bool.false_eq_true,ite_false,sub_self,abs_zero]
      exact add_nonneg herr htail0
  have hsum := (Finset.abs_sum_le_sum_abs _ _).trans
    (Finset.sum_le_sum (fun i (_:i∈Finset.univ) => hterm i))
  have hpower := mul_le_mul_of_nonneg_left (localization_power_sum hk p halpha ht hnu hnu2 hnua) hC
  rw [Finset.sum_sub_distrib,←Finset.mul_sum] at hsum
  rw [Finset.sum_add_distrib,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,←Finset.mul_sum] at hsum
  change |(∑i,if light i then sigma*Q.eval (p.mass i) else sigma*omega*p.mass i^alpha)-sigma*omega*powerSum p alpha|≤_
  change |(∑i,if light i then sigma*Q.eval (p.mass i) else sigma*omega*p.mass i^alpha)-sigma*omega*powerSum p alpha|≤
      (k:ℝ)*err+completedLocalizationConstant*(∑i,p.mass i^alpha*min 1 ((t/p.mass i)^2)) at hsum
  dsimp only [err] at hsum
  nlinarith only [hsum,hpower]

end Renyi
