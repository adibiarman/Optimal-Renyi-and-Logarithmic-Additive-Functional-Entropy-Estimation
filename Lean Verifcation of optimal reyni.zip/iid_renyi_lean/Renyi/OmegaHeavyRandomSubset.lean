import Renyi.OmegaHeavyUniform
import Mathlib.MeasureTheory.Measure.Prod

/-! Omega-heavy concentration for a subset chosen by the independent pilot sample. -/
noncomputable section
open scoped BigOperators NNReal
open Set MeasureTheory ProbabilityTheory
namespace Renyi

/-- The exact heavy-sum event over an arbitrary selected subset. -/
def omegaHeavySubsetEvent {Ω : Type*} {k : ℕ} (N : Fin k→Ω→ℕ) (lam : Fin k→ℝ≥0)
    (a E0 eps c0 c : ℝ) (S : Finset (Fin k)) : Set Ω :=
  {w | (Real.exp (-(2*eps*(a-1)))+c*Real.exp (-(2*eps*(a-1))))*
      ∑i∈S,(lam i:ℝ)^a ≤ Real.exp (-c0*E0)*∑i∈S,analyticCount a (N i w) ∧
    Real.exp (-c0*E0)*(∑i∈S,analyticCount a (N i w))≤
      (1-c*Real.exp (-(2*eps*(a-1))))*∑i∈S,(lam i:ℝ)^a}

/-- A deterministic subset inherits the dimension-free omega-heavy bound. -/
theorem omega_heavy_subset_concentration {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {eps c0 rho : ℝ}
    (heps : 0<eps) (hc0 : 0<c0) (hc01 : c0<1) (hrho : 0<rho) (hrho1 : rho<1) :
    ∃ c B : ℝ, 0<c ∧ 1≤B ∧ ∀ (k : ℕ) (a E0 : ℝ), 3/2≤a →
      eps*(a-1)≤E0 → E0≤2*eps*(a-1) →
      ∀ (N : Fin k→Ω→ℕ) (lam : Fin k→ℝ≥0),
        (∀i,MeasurePreserving (N i) μ (poissonMeasure (lam i))) →
        ∀ (S : Finset (Fin k)), (∀i∈S,B*a≤(lam i:ℝ)) →
        1-rho≤μ.real (omegaHeavySubsetEvent N lam a E0 eps c0 c S) := by
  obtain ⟨c,B,hc,hB,hbound⟩ := omega_heavy_concentration (μ:=μ) heps hc0 hc01 hrho hrho1
  refine ⟨c,B,hc,hB,?_⟩
  intro k a E0 ha hElow hEhigh N lam hLaw S hmean
  let e := (Fintype.equivFin S).symm
  have hh := hbound (Fintype.card S) a E0 ha hElow hEhigh
    (fun j => N (e j)) (fun j => lam (e j))
    (fun j => hLaw (e j)) (fun j => hmean (e j) (e j).property)
  have hsum (f : Fin k→ℝ) : (∑j:Fin (Fintype.card S),f (e j))=∑i∈S,f i := by
    have he := e.sum_comp (fun i:S => f i)
    simpa only [Finset.sum_coe_sort] using he
  dsimp only at hh
  have hsum1 := hsum (fun i => (lam i:ℝ)^a)
  have hsum2 (w : Ω) := hsum (fun i => analyticCount a (N i w))
  simp only [hsum1,hsum2] at hh
  exact hh

/-- Integrating section bounds under an independent pilot preserves their probability. -/
lemma product_section_probability_lower {Ω Ψ : Type*}
    [MeasurableSpace Ω] [MeasurableSpace Ψ] {μ : Measure Ω} {ν : Measure Ψ}
    [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {E : Set (Ω×Ψ)} (hE : MeasurableSet E) {r : ℝ} (hr : 0≤r)
    (hsection : ∀y,r≤μ.real ((fun x => (x,y))⁻¹' E)) :
    r≤(μ.prod ν).real E := by
  have hh : ENNReal.ofReal r≤(μ.prod ν) E := by
    rw [Measure.prod_apply_symm hE]
    calc
      _ = ∫⁻ _y,ENNReal.ofReal r ∂ν := by simp
      _ ≤ _ := lintegral_mono (fun y => by
        have hs := ENNReal.ofReal_le_ofReal (hsection y)
        rwa [ofReal_measureReal] at hs)
  have ht := ENNReal.toReal_mono (measure_ne_top (μ.prod ν) E) hh
  simpa only [ENNReal.toReal_ofReal hr] using ht

/-- A high-probability event loses at most rho after intersecting a pilot event. -/
lemma probability_inter_lower {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {E F : Set Ω} {rho : ℝ}
    (hF : MeasurableSet F) (hE : 1-rho≤μ.real E) :
    μ.real F-rho≤μ.real (E∩F) := by
  have hh := measureReal_union_add_inter (μ:=μ) (s:=E) hF
  have hu : μ.real (E∪F)≤1 := by
    have hm := measureReal_mono (μ:=μ) (subset_univ (E∪F))
    simpa only [measureReal_univ_eq_one] using hm
  linarith only [hh,hu,hE]

/-- The selected set is allowed to depend arbitrarily on the independent pilot.
Only the means of coordinates actually selected on the good pilot event must be high. -/
theorem omega_heavy_random_subset_concentration {Ω Ψ : Type*}
    [MeasurableSpace Ω] [MeasurableSpace Ψ] [Countable Ω] [Countable Ψ]
    [MeasurableSingletonClass Ω] [MeasurableSingletonClass Ψ]
    {μ : Measure Ω} {ν : Measure Ψ} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {eps c0 rho : ℝ} (heps : 0<eps) (hc0 : 0<c0) (hc01 : c0<1)
    (hrho : 0<rho) (hrho1 : rho<1) :
    ∃ c B : ℝ, 0<c ∧ 1≤B ∧ ∀ (k : ℕ) (a E0 : ℝ), 3/2≤a →
      eps*(a-1)≤E0 → E0≤2*eps*(a-1) →
      ∀ (N : Fin k→Ω→ℕ) (lam : Fin k→ℝ≥0),
        (∀i,MeasurePreserving (N i) μ (poissonMeasure (lam i))) →
        ∀ (S : Ψ→Finset (Fin k)) (G : Set Ψ),
          (∀y∈G,∀i∈S y,B*a≤(lam i:ℝ)) →
          1-rho≤(μ.prod ν).real {xy | xy.2∈G →
            xy.1∈omegaHeavySubsetEvent N lam a E0 eps c0 c (S xy.2)} := by
  classical
  obtain ⟨c,B,hc,hB,hbound⟩ := omega_heavy_subset_concentration (μ:=μ) heps hc0 hc01 hrho hrho1
  refine ⟨c,B,hc,hB,?_⟩
  intro k a E0 ha hElow hEhigh N lam hLaw S G hmean
  apply product_section_probability_lower (Set.to_countable _).measurableSet (by linarith only [hrho1])
  intro y
  by_cases hy : y∈G
  · simpa only [preimage_setOf_eq,hy,true_implies] using
      hbound k a E0 ha hElow hEhigh N lam hLaw (S y) (hmean y hy)
  · simp only [preimage_setOf_eq,hy,false_implies,setOf_true]
    simp only [Measure.real,measure_univ,ENNReal.toReal_one]
    linarith only [hrho]

theorem omega_heavy_subset_concentration_explicit {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {eps c0 rho : ℝ}
    (heps : 0<eps) (hc0 : 0<c0) (hc01 : c0<1) (hrho : 0<rho) (hrho1 : rho<1) :
    0<omegaHeavyMargin eps c0 ∧ 1≤omegaHeavyScale eps c0 rho ∧ ∀ (k : ℕ) (a E0 : ℝ), 3/2≤a →
      eps*(a-1)≤E0 → E0≤2*eps*(a-1) →
      ∀ (N : Fin k→Ω→ℕ) (lam : Fin k→ℝ≥0),
        (∀i,MeasurePreserving (N i) μ (poissonMeasure (lam i))) →
        ∀ (S : Finset (Fin k)), (∀i∈S,omegaHeavyScale eps c0 rho*a≤(lam i:ℝ)) →
        1-rho≤μ.real (omegaHeavySubsetEvent N lam a E0 eps c0 (omegaHeavyMargin eps c0) S) := by
  obtain ⟨hc,hB,hbound⟩ := omega_heavy_concentration_explicit (μ:=μ) heps hc0 hc01 hrho hrho1
  refine ⟨hc,hB,?_⟩
  intro k a E0 ha hElow hEhigh N lam hLaw S hmean
  let e := (Fintype.equivFin S).symm
  have hh := hbound (Fintype.card S) a E0 ha hElow hEhigh
    (fun j => N (e j)) (fun j => lam (e j))
    (fun j => hLaw (e j)) (fun j => hmean (e j) (e j).property)
  have hsum (f : Fin k→ℝ) : (∑j:Fin (Fintype.card S),f (e j))=∑i∈S,f i := by
    have he := e.sum_comp (fun i:S => f i)
    simpa only [Finset.sum_coe_sort] using he
  dsimp only at hh
  have hsum1 := hsum (fun i => (lam i:ℝ)^a)
  have hsum2 (w : Ω) := hsum (fun i => analyticCount a (N i w))
  simp only [hsum1,hsum2] at hh
  exact hh


theorem omega_heavy_random_subset_concentration_explicit {Ω Ψ : Type*}
    [MeasurableSpace Ω] [MeasurableSpace Ψ] [Countable Ω] [Countable Ψ]
    [MeasurableSingletonClass Ω] [MeasurableSingletonClass Ψ]
    {μ : Measure Ω} {ν : Measure Ψ} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {eps c0 rho : ℝ} (heps : 0<eps) (hc0 : 0<c0) (hc01 : c0<1)
    (hrho : 0<rho) (hrho1 : rho<1) :
    0<omegaHeavyMargin eps c0 ∧ 1≤omegaHeavyScale eps c0 rho ∧ ∀ (k : ℕ) (a E0 : ℝ), 3/2≤a →
      eps*(a-1)≤E0 → E0≤2*eps*(a-1) →
      ∀ (N : Fin k→Ω→ℕ) (lam : Fin k→ℝ≥0),
        (∀i,MeasurePreserving (N i) μ (poissonMeasure (lam i))) →
        ∀ (S : Ψ→Finset (Fin k)) (G : Set Ψ),
          (∀y∈G,∀i∈S y,omegaHeavyScale eps c0 rho*a≤(lam i:ℝ)) →
          1-rho≤(μ.prod ν).real {xy | xy.2∈G →
            xy.1∈omegaHeavySubsetEvent N lam a E0 eps c0 (omegaHeavyMargin eps c0) (S xy.2)} := by
  classical
  obtain ⟨hc,hB,hbound⟩ := omega_heavy_subset_concentration_explicit (μ:=μ) heps hc0 hc01 hrho hrho1
  refine ⟨hc,hB,?_⟩
  intro k a E0 ha hElow hEhigh N lam hLaw S G hmean
  apply product_section_probability_lower (Set.to_countable _).measurableSet (by linarith only [hrho1])
  intro y
  by_cases hy : y∈G
  · simpa only [preimage_setOf_eq,hy,true_implies] using
      hbound k a E0 ha hElow hEhigh N lam hLaw (S y) (hmean y hy)
  · simp only [preimage_setOf_eq,hy,false_implies,setOf_true]
    simp only [Measure.real,measure_univ,ENNReal.toReal_one]
    linarith only [hrho]

end Renyi
