import Renyi.PoissonThinning

/-! Exact thinning law for the original ordered Poisson marking experiment. -/
noncomputable section
open scoped BigOperators ENNReal NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- Conditional on the retention flags, retained positive marks remain iid. -/
theorem iid_thin_positive_law (q : PMF ℕ) (n : ℕ) :
    (iidCountablePMF q n).map (fun x => thinPositiveRecord ⟨n, x⟩) =
      (iidCountablePMF (retentionFlagPMF q) n).bind (fun flags =>
        (iidCountablePMF (visibleMarkPMF q) (flagPositions flags).card).map
          (fun y => ⟨(flagPositions flags).card, y⟩)) := by
  rw [iid_retention_decomposition, PMF.map_bind]
  congr 1
  funext flags
  rw [PMF.map_comp]
  change (iidCountablePMF (visibleMarkPMF q) n).map
      (fun x => thinPositiveRecord ⟨n, maskedMarks flags x⟩) = _
  simp_rw [thinPositiveRecord_masked]
  rw [← iidCountablePMF_restrict (visibleMarkPMF q) (flagEmbedding flags), PMF.map_comp]
  rfl

/-- The number of true flags is the true-cell histogram coordinate. -/
theorem flagPositions_card_eq_count {n : ℕ} (flags : Fin n → Bool) :
    (flagPositions flags).card = poissonMarkCount true (⟨n, flags⟩ : PoissonMarkedSample Bool) := by
  simp only [flagPositions, poissonMarkCount, Finset.card_filter]

/-- A Poisson number of independent retention flags has the exact retained-count law. -/
theorem poisson_retention_count_law (b : ℝ≥0) (q : PMF ℕ) :
    (poissonCountableSamplePMF b (retentionFlagPMF q)).map
      (fun x => (flagPositions x.2).card) = poissonPMF (b * positiveMarkMass q) := by
  have heq : (fun x : PoissonMarkedSample Bool => (flagPositions x.2).card) =
      poissonMarkCount true := by
    funext x
    exact flagPositions_card_eq_count x.2
  rw [heq]
  apply PMF.toMeasure_injective
  rw [← PMF.toMeasure_map _ _ (measurable_of_countable _), poisson_mark_count_law]
  simp only [retentionFlagPMF_true, ENNReal.toNNReal_coe]
  rfl

/-- Deleting zero marks from the original ordered Poisson experiment gives
exactly a Poisson experiment of iid positive marks, with no conditioning or
unobserved coordinates supplied to the output. This includes zero retained mass. -/
theorem poisson_thin_positive_law (b : ℝ≥0) (q : PMF ℕ) :
    (poissonCountableSamplePMF b q).map thinPositiveRecord =
      poissonCountableSamplePMF (b * positiveMarkMass q) (visibleMarkPMF q) := by
  rw [poissonCountableSamplePMF, PMF.map_bind]
  simp_rw [PMF.map_comp]
  change (poissonPMF b).bind (fun n =>
      (iidCountablePMF q n).map (fun x => thinPositiveRecord ⟨n, x⟩)) = _
  simp_rw [iid_thin_positive_law]
  change _ = (poissonPMF (b * positiveMarkMass q)).bind (fun n =>
    (iidCountablePMF (visibleMarkPMF q) n).map (fun x => (⟨n, x⟩ : PoissonMarkedSample ℕ)))
  rw [← poisson_retention_count_law b q, poissonCountableSamplePMF,
    PMF.map_bind, PMF.bind_bind]
  congr 1
  funext n
  rw [PMF.map_comp, PMF.bind_map]
  rfl

end Renyi
