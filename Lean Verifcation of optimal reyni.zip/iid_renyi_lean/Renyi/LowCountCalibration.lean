import Renyi.CountMarginCalibration
import Renyi.CoupledLocalCoefficients

/-! Uniform low-degree count calibration against the reference affine margin. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- Exponential coefficient and entropy costs are absorbed by one fixed reference baseline. -/
theorem low_count_exponential_budget {alpha j C c R : ℝ}
    (ha : 3 / 2 ≤ alpha) (_hj : 0 ≤ j) (hja : j ≤ alpha)
    (hC : 1 ≤ C) (hc : 0 ≤ c) (hR : Real.exp (3 * (Real.log C + c)) ≤ R) :
    C ^ alpha * R ^ ((alpha - 1) * (j / alpha - 2)) * Real.exp (c * j) ≤ 1 := by
  have ha0 : 0 < alpha := by linarith
  have hC0 : 0 < C := zero_lt_one.trans_le hC
  let R0 := Real.exp (3 * (Real.log C + c))
  have hlog : 0 ≤ Real.log C := Real.log_nonneg hC
  have hR01 : 1 ≤ R0 := by dsimp [R0]; exact Real.one_le_exp_iff.mpr (by positivity)
  have hR0 : 0 < R0 := Real.exp_pos _
  have hθ : j / alpha ≤ 1 := (div_le_one ha0).mpr hja
  have hexp : (alpha - 1) * (j / alpha - 2) ≤ -(alpha - 1) := by nlinarith
  have hpow : R ^ ((alpha - 1) * (j / alpha - 2)) ≤ R0 ^ (-(alpha - 1)) :=
    (Real.rpow_le_rpow_of_nonpos hR0 hR (by nlinarith)).trans
      (Real.rpow_le_rpow_of_exponent_le hR01 hexp)
  have hexpj : Real.exp (c * j) ≤ Real.exp (c * alpha) :=
    Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left hja hc)
  have heq : C ^ alpha * R0 ^ (-(alpha - 1)) * Real.exp (c * alpha) =
      Real.exp ((Real.log C + c) * (3 - 2 * alpha)) := by
    rw [Real.rpow_def_of_pos hC0, Real.rpow_def_of_pos hR0]
    dsimp [R0]
    rw [Real.log_exp, ← Real.exp_add, ← Real.exp_add]
    congr 1
    ring
  calc
    _ ≤ C ^ alpha * R0 ^ (-(alpha - 1)) * Real.exp (c * alpha) :=
      mul_le_mul (mul_le_mul_of_nonneg_left hpow (Real.rpow_nonneg hC0.le _)) hexpj
        (Real.exp_pos _).le (by positivity)
    _ = _ := heq
    _ ≤ 1 := Real.exp_le_one_iff.mpr (mul_nonpos_of_nonneg_of_nonpos (by positivity) (by linarith))

lemma low_count_prefactor_bound {E u θ : ℝ} (hE : 0 < E) (hu : 0 < u)
    (hθ : 0 ≤ θ) (hθ1 : θ ≤ 1) :
    E ^ (θ - 2) * u ^ (-θ) ≤ max (E ^ (-2 : ℝ)) (E ^ (-1 : ℝ)) * max 1 (u ^ (-1 : ℝ)) := by
  have hEp : E ^ (θ - 2) ≤ max (E ^ (-2 : ℝ)) (E ^ (-1 : ℝ)) := by
    by_cases hE1 : 1 ≤ E
    · exact (Real.rpow_le_rpow_of_exponent_le hE1 (by linarith : θ - 2 ≤ -1)).trans (le_max_right _ _)
    · exact (Real.rpow_le_rpow_of_exponent_ge hE (by linarith : E ≤ 1)
        (by linarith : (-2 : ℝ) ≤ θ - 2)).trans (le_max_left _ _)
  have hup : u ^ (-θ) ≤ max 1 (u ^ (-1 : ℝ)) := by
    by_cases hu1 : 1 ≤ u
    · have h := Real.rpow_le_rpow_of_exponent_le hu1 (neg_nonpos.mpr hθ)
      rw [Real.rpow_zero] at h
      exact h.trans (le_max_left _ _)
    · exact (Real.rpow_le_rpow_of_exponent_ge hu (by linarith : u ≤ 1)
        (by linarith : (-1 : ℝ) ≤ -θ)).trans (le_max_right _ _)
  exact mul_le_mul hEp hup (Real.rpow_nonneg hu.le _) (by positivity)

/-- After the exact source exponent cancellation, one D controls every low degree. -/
theorem low_count_calibrated_scalar_budget {alpha j C c R D E u : ℝ}
    (ha : 3 / 2 ≤ alpha) (hj : 0 ≤ j) (hja : j ≤ alpha)
    (hC : 1 ≤ C) (hc : 0 ≤ c) (hR : Real.exp (3 * (Real.log C + c)) ≤ R)
    (hD : 1 ≤ D) (hE : 0 < E) (hu : 0 < u) :
    (C ^ alpha * R ^ ((alpha - 1) * (j / alpha - 2)) * Real.exp (c * j)) *
      (E ^ (j / alpha - 2) * u ^ (-(j / alpha))) *
      D ^ (-2 * (alpha - j) - j + (alpha - 1) * (2 - j / alpha)) ≤
        (max (E ^ (-2 : ℝ)) (E ^ (-1 : ℝ)) * max 1 (u ^ (-1 : ℝ))) / D := by
  have ha0 : 0 < alpha := by linarith
  have hθ0 : 0 ≤ j / alpha := div_nonneg hj ha0.le
  have hθ1 : j / alpha ≤ 1 := (div_le_one ha0).mpr hja
  have he := low_count_exponential_budget ha hj hja hC hc hR
  have hp := low_count_prefactor_bound hE hu hθ0 hθ1
  have hDpow := count_degree_sample_multiplier ha0 hja hD
  have h := mul_le_mul (mul_le_mul he hp (by positivity) (by positivity)) hDpow
    (Real.rpow_nonneg (by linarith : 0 ≤ D) _) (by positivity)
  apply h.trans_eq
  simp only [one_mul, Real.rpow_neg_one, div_eq_mul_inv]

variable {ι Ω Ξ : Type*} [Fintype ι] [MeasurableSpace Ω] [MeasurableSpace Ξ]
variable {μ : Measure Ω} {ν : Measure Ξ}

/-- The actual low-degree part of Q, compared to the reference affine margin. -/
theorem coupled_low_count_variance_affine_margin (Bp cp : ℝ) (hBp : 0 < Bp) (hcp : 0 < cp)
    (Ncount : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (Ncount i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (Ncount i) (Ncount j) μ))
    (Y : ι → Ξ → ℕ)
    (hY : ∀ i, MeasurePreserving (Y i) ν
      (poissonMeasure ⟨cp * lam i, mul_nonneg hcp.le (lam i).coe_nonneg⟩))
    (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) (hk : (0 : ℝ) < Fintype.card ι)
    {ℓ Nk m : ℕ} (hℓ : 0 < ℓ) (hNk : 0 < Nk) (hdegree : 4 * (ℓ - 1) ≤ m)
    {γ a b fL f A B ω n E v : ℝ} (hγ : 0 < γ) (hγ1 : γ ≤ 1)
    (ha : 0 < a) (hb : 0 < b) (hf : 0 ≤ fL) (hf1 : fL < 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hZ : (Nk : ℝ) ^ 2 * (a / b) ≤ 1)
    (hn : 0 < n) (hlam : ∀ i, (lam i : ℝ) = n * p i) (hE : 0 < E) (hv : 0 < v) :
    pilotAveragedCountVariance Ncount Y (cp * Bp * ((m : ℝ) + γ)) m
        (coupledQPolynomial ℓ Nk m γ a b fL f A B ω).coeff n μ ν /
      (((Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + γ))) *
        (E + v * ((∑ i, p i ^ ((m : ℝ) + γ)) /
          (Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + γ))))) ^ 2 ≤
    (m : ℝ) * ∑ r ∈ Finset.range m,
      ((coupledLowCoefficientConstant ^ (m + 1) * a ^ ((m : ℝ) + γ - ((r + 1 : ℕ) : ℝ))) ^ 2 *
        (pilotConstant Bp cp * ((m : ℝ) + γ)) ^ (r + 1) / n ^ (r + 1) /
        ((Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + γ))) ^ 2) *
      ((Fintype.card ι : ℝ) ^ (1 - ((r + 1 : ℕ) : ℝ)) *
        E ^ (((r + 1 : ℕ) : ℝ) / ((m : ℝ) + γ) - 2) *
        v ^ (-(((r + 1 : ℕ) : ℝ) / ((m : ℝ) + γ)))) := by
  let alpha := (m : ℝ) + γ
  let Pstar := (Fintype.card ι : ℝ) ^ (1 - alpha)
  let Anorm := (∑ i, p i ^ alpha) / Pstar
  have hPa : 0 ≤ ∑ i, p i ^ alpha := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (hp i) _)
  have hPstar : 0 < Pstar := Real.rpow_pos_of_pos hk _
  have hAnorm : 0 ≤ Anorm := div_nonneg hPa hPstar.le
  have hmargin : 0 < E + v * Anorm := by positivity
  have hbase := pilot_low_degree_count_variance_probability_units Bp cp alpha hBp hcp Ncount lam hLaw hpair Y hY
    m (by dsimp [alpha]; linarith) (coupledQPolynomial ℓ Nk m γ a b fL f A B ω).coeff n hn.ne' p hlam
  have hden : 0 ≤ (Pstar * (E + v * Anorm)) ^ 2 := sq_nonneg _
  apply (div_le_div_of_nonneg_right hbase hden).trans
  have heq : ((m : ℝ) * ∑ r ∈ Finset.range m,
      (coupledQPolynomial ℓ Nk m γ a b fL f A B ω).coeff (r + 1) ^ 2 *
        (pilotConstant Bp cp * alpha) ^ (r + 1) / n ^ (r + 1) * powerSumNat p (r + 1)) /
      (Pstar * (E + v * Anorm)) ^ 2 =
    (m : ℝ) * ∑ r ∈ Finset.range m,
      ((coupledQPolynomial ℓ Nk m γ a b fL f A B ω).coeff (r + 1) ^ 2 *
        (pilotConstant Bp cp * alpha) ^ (r + 1) / n ^ (r + 1) / Pstar ^ 2) *
        (powerSumNat p (r + 1) / (E + v * Anorm) ^ 2) := by
    rw [mul_div_assoc, Finset.sum_div]
    congr 1
    apply Finset.sum_congr rfl
    intro r _
    field_simp
  rw [heq]
  apply mul_le_mul_of_nonneg_left _ (Nat.cast_nonneg m)
  apply Finset.sum_le_sum
  intro r hr
  have hrm : r + 1 ≤ m := by have := Finset.mem_range.mp hr; omega
  have hrma : ((r + 1 : ℕ) : ℝ) ≤ alpha := by
    have h : ((r + 1 : ℕ) : ℝ) ≤ m := by exact_mod_cast hrm
    dsimp [alpha]
    linarith
  have hcoef := coupledQPolynomial_low_coefficient_exponential (f := f) (B := B) (ω := ω)
    hℓ hNk hdegree hrm hγ hγ1 ha hb hf hf1 hA hA1 hZ
  have hcoef2 : (coupledQPolynomial ℓ Nk m γ a b fL f A B ω).coeff (r + 1) ^ 2 ≤
      (coupledLowCoefficientConstant ^ (m + 1) * a ^ (alpha - ((r + 1 : ℕ) : ℝ))) ^ 2 := by
    have hc : 0 ≤ coupledLowCoefficientConstant := by unfold coupledLowCoefficientConstant; positivity
    simpa only [sq_abs] using (sq_le_sq₀ (abs_nonneg _) (by positivity)).mpr hcoef
  have hcp : 0 ≤ pilotConstant Bp cp * alpha := by
    have hpc : 0 < pilotConstant Bp cp :=
      (by linarith : 0 < 2 * Bp + 1).trans_le (le_max_left _ _)
    dsimp [alpha]
    positivity
  have hleft := div_le_div_of_nonneg_right
    (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right hcoef2 (pow_nonneg hcp (r + 1)))
      (pow_nonneg hn.le (r + 1))) (sq_nonneg Pstar)
  have hright := finite_power_sum_over_affine_margin p hp hk (by omega : 0 < r + 1) hrma hE hv
  have hPj : 0 ≤ powerSumNat p (r + 1) :=
    Finset.sum_nonneg (fun i _ => pow_nonneg (hp i) _)
  exact mul_le_mul hleft hright (by positivity) (by positivity)

/-- Exact probability-to-count normalization at the source sample size. -/
theorem low_count_sample_normalization {k a alpha j Cp D X : ℝ}
    (hk : 0 < k) (ha : 0 < a) (halpha : 0 < alpha) (hCp : 0 < Cp)
    (hD : 0 < D) (hX : 0 < X) :
    a ^ (2 * (alpha - j)) * (Cp * alpha) ^ j /
      (D * alpha * k ^ (1 - 1 / alpha) * X) ^ j /
        (k ^ (1 - alpha)) ^ 2 * k ^ (1 - j) =
      (k * a) ^ (2 * (alpha - j)) * (Cp / (D * X)) ^ j * k ^ (j / alpha - 1) := by
  have hkpow : 0 < k ^ (1 - 1 / alpha) := Real.rpow_pos_of_pos hk _
  have hp : 0 < k ^ (1 - alpha) := Real.rpow_pos_of_pos hk _
  apply Real.log_injOn_pos (by apply Set.mem_Ioi.mpr; positivity) (by apply Set.mem_Ioi.mpr; positivity)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow]
  field_simp
  ring

/-- Exact baseline and root-width factorization of a low-degree contribution. -/
theorem low_count_margin_factorization {alpha j rho Cp D X R E0 u0 c : ℝ}
    (halpha : 0 < alpha) (hrho : 0 < rho) (hCp : 0 < Cp) (hD : 0 < D) (hX : 0 < X)
    (hR : 0 < R) (hE0 : 0 < E0) (hu0 : 0 < u0) :
    (rho / D) ^ (2 * (alpha - j)) * (Cp / (D * X)) ^ j *
      (E0 * (R / D) ^ (alpha - 1)) ^ (j / alpha - 2) *
      (u0 * Real.exp (-c * alpha) * X ^ (-alpha)) ^ (-(j / alpha)) =
    (rho ^ (2 * (alpha - j)) * Cp ^ j) * R ^ ((alpha - 1) * (j / alpha - 2)) *
      Real.exp (c * j) * (E0 ^ (j / alpha - 2) * u0 ^ (-(j / alpha))) *
      D ^ (-2 * (alpha - j) - j + (alpha - 1) * (2 - j / alpha)) := by
  apply Real.log_injOn_pos (by apply Set.mem_Ioi.mpr; positivity) (by apply Set.mem_Ioi.mpr; positivity)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_exp]
  field_simp
  ring

def lowCountExponentialConstant (rho Cp : ℝ) : ℝ :=
  max 1 (Real.exp 2 * coupledLowCoefficientConstant ^ 4 * (max 1 rho) ^ 2 * max 1 Cp)

lemma lowCountExponentialConstant_ge_one (rho Cp : ℝ) : 1 ≤ lowCountExponentialConstant rho Cp := le_max_left _ _

/-- All coefficient, pilot, cutoff, and finite-sum costs have a fixed exponential order envelope. -/
theorem low_count_actual_coefficient_budget {m : ℕ} (hm : 0 < m) {alpha j rho Cp : ℝ}
    (hma : (m : ℝ) ≤ alpha) (hj : 0 ≤ j) (hja : j ≤ alpha) (hrho : 0 < rho) (hCp : 0 < Cp) :
    (m : ℝ) ^ 2 * (coupledLowCoefficientConstant ^ (m + 1)) ^ 2 *
      rho ^ (2 * (alpha - j)) * Cp ^ j ≤ (lowCountExponentialConstant rho Cp) ^ alpha := by
  have hm0 : 0 < (m : ℝ) := by exact_mod_cast hm
  have hm1 : 1 ≤ (m : ℝ) := by exact_mod_cast hm
  have ha : 0 < alpha := hm0.trans_le hma
  have hQ : 1 ≤ coupledLowCoefficientConstant := by unfold coupledLowCoefficientConstant; nlinarith [Real.exp_pos 12]
  have hQ0 : 0 < coupledLowCoefficientConstant := zero_lt_one.trans_le hQ
  have hRho : 0 < max 1 rho := zero_lt_one.trans_le (le_max_left _ _)
  have hPilot : 0 < max 1 Cp := zero_lt_one.trans_le (le_max_left _ _)
  have hmexp : (m : ℝ) ^ 2 ≤ Real.exp (2 * alpha) := by
    have h : (m : ℝ) ≤ Real.exp alpha :=
      (by linarith [Real.add_one_le_exp (m : ℝ)] : (m : ℝ) ≤ Real.exp (m : ℝ)).trans
        (Real.exp_le_exp.mpr hma)
    have hs := pow_le_pow_left₀ hm0.le h 2
    rw [← Real.exp_nat_mul] at hs
    norm_num at hs
    exact hs
  have hQpow : (coupledLowCoefficientConstant ^ (m + 1)) ^ 2 ≤
      coupledLowCoefficientConstant ^ (4 * alpha) := by
    rw [← pow_mul, ← Real.rpow_natCast]
    apply Real.rpow_le_rpow_of_exponent_le hQ
    push_cast
    nlinarith
  have hRhopow : rho ^ (2 * (alpha - j)) ≤ (max 1 rho) ^ (2 * alpha) := by
    apply (Real.rpow_le_rpow hrho.le (le_max_right _ _) (by linarith : 0 ≤ 2 * (alpha - j))).trans
    exact Real.rpow_le_rpow_of_exponent_le (le_max_left _ _) (by linarith)
  have hCppow : Cp ^ j ≤ (max 1 Cp) ^ alpha :=
    (Real.rpow_le_rpow hCp.le (le_max_right _ _) hj).trans
      (Real.rpow_le_rpow_of_exponent_le (le_max_left _ _) hja)
  let F := Real.exp 2 * coupledLowCoefficientConstant ^ 4 * (max 1 rho) ^ 2 * max 1 Cp
  have hF : 0 < F := by dsimp [F]; positivity
  have hid : F ^ alpha = Real.exp (2 * alpha) * coupledLowCoefficientConstant ^ (4 * alpha) *
      (max 1 rho) ^ (2 * alpha) * (max 1 Cp) ^ alpha := by
    apply Real.log_injOn_pos (by apply Set.mem_Ioi.mpr; positivity) (by apply Set.mem_Ioi.mpr; positivity)
    dsimp [F]
    simp (disch := positivity) only [Real.log_mul, Real.log_rpow, Real.log_pow, Real.log_exp]
    ring
  calc
    _ ≤ Real.exp (2 * alpha) * coupledLowCoefficientConstant ^ (4 * alpha) *
        (max 1 rho) ^ (2 * alpha) * (max 1 Cp) ^ alpha := by
      exact mul_le_mul (mul_le_mul (mul_le_mul hmexp hQpow (by positivity) (by positivity))
        hRhopow (by positivity) (by positivity)) hCppow (by positivity) (by positivity)
    _ = F ^ alpha := hid.symm
    _ ≤ _ := Real.rpow_le_rpow hF.le (le_max_right _ _) ha.le

/-- The source sample size, cutoff, baseline, and root width yield D^-1 per normalized low block. -/
theorem low_count_single_degree_calibration {m : ℕ} (hm : 0 < m)
    {alpha j k a rho Cp D X R E0 u0 c E v : ℝ}
    (halpha : 3 / 2 ≤ alpha) (hma : (m : ℝ) ≤ alpha) (hj : 0 ≤ j) (hja : j ≤ alpha)
    (hk : 1 ≤ k) (ha : 0 < a) (hrho : 0 < rho) (hCp : 0 < Cp) (hD : 1 ≤ D) (hX : 1 ≤ X)
    (hE0 : 0 < E0) (hu0 : 0 < u0) (hc : 0 ≤ c)
    (hR : Real.exp (3 * (Real.log (lowCountExponentialConstant rho Cp) + c)) ≤ R)
    (hcut : k * a ≤ rho / D)
    (hE : E0 * (R / D) ^ (alpha - 1) ≤ E)
    (hv : u0 * Real.exp (-c * alpha) * X ^ (-alpha) ≤ v) :
    (m : ℝ) ^ 2 * (coupledLowCoefficientConstant ^ (m + 1) * a ^ (alpha - j)) ^ 2 *
      (Cp * alpha) ^ j / (D * alpha * k ^ (1 - 1 / alpha) * X) ^ j /
      (k ^ (1 - alpha)) ^ 2 * k ^ (1 - j) * E ^ (j / alpha - 2) * v ^ (-(j / alpha)) ≤
        (max (E0 ^ (-2 : ℝ)) (E0 ^ (-1 : ℝ)) * max 1 (u0 ^ (-1 : ℝ))) / D := by
  have halpha0 : 0 < alpha := by linarith
  have hk0 : 0 < k := zero_lt_one.trans_le hk
  have hD0 : 0 < D := zero_lt_one.trans_le hD
  have hX0 : 0 < X := zero_lt_one.trans_le hX
  have hR0 : 0 < R := (Real.exp_pos _).trans_le hR
  have hθ : j / alpha ≤ 1 := (div_le_one halpha0).mpr hja
  have hθ0 : 0 ≤ j / alpha := div_nonneg hj halpha0.le
  let Eref := E0 * (R / D) ^ (alpha - 1)
  let vref := u0 * Real.exp (-c * alpha) * X ^ (-alpha)
  have hEref : 0 < Eref := by dsimp [Eref]; positivity
  have hvref : 0 < vref := by dsimp [vref]; positivity
  have hE0' : 0 < E := hEref.trans_le hE
  have hv0 : 0 < v := hvref.trans_le hv
  have hpow : (a ^ (alpha - j)) ^ 2 = a ^ (2 * (alpha - j)) := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul ha.le]
    norm_num
    congr 1
    ring
  have hsample := low_count_sample_normalization hk0 ha halpha0 hCp hD0 hX0 (j := j)
  have hcutpow := Real.rpow_le_rpow (mul_pos hk0 ha).le hcut (by linarith : 0 ≤ 2 * (alpha - j))
  have hkpow : k ^ (j / alpha - 1) ≤ 1 :=
    Real.rpow_le_one_of_one_le_of_nonpos hk (by linarith)
  have hEpow := Real.rpow_le_rpow_of_nonpos hEref hE (by linarith : j / alpha - 2 ≤ 0)
  have hvpow := Real.rpow_le_rpow_of_nonpos hvref hv (neg_nonpos.mpr hθ0)
  let F := (m : ℝ) ^ 2 * (coupledLowCoefficientConstant ^ (m + 1)) ^ 2 * (Cp / (D * X)) ^ j
  have hF : 0 ≤ F := by dsimp [F]; positivity
  have hprod := mul_le_mul (mul_le_mul (mul_le_mul hcutpow hkpow (by positivity) (by positivity))
    hEpow (by positivity) (by positivity)) hvpow (by positivity) (by positivity)
  have hcoef := low_count_actual_coefficient_budget hm hma hj hja hrho hCp
  have hscalar := low_count_calibrated_scalar_budget halpha hj hja
    (lowCountExponentialConstant_ge_one rho Cp) hc hR hD hE0 hu0
  calc
    _ = F * ((k * a) ^ (2 * (alpha - j)) * k ^ (j / alpha - 1) *
        E ^ (j / alpha - 2) * v ^ (-(j / alpha))) := by
      rw [mul_pow, hpow]
      have h := congrArg (fun z : ℝ =>
        (m : ℝ) ^ 2 * (coupledLowCoefficientConstant ^ (m + 1)) ^ 2 * z *
          E ^ (j / alpha - 2) * v ^ (-(j / alpha))) hsample
      convert h using 1 <;> dsimp [F] <;> ring
    _ ≤ F * ((rho / D) ^ (2 * (alpha - j)) * 1 * Eref ^ (j / alpha - 2) * vref ^ (-(j / alpha))) :=
      mul_le_mul_of_nonneg_left hprod hF
    _ = ((m : ℝ) ^ 2 * (coupledLowCoefficientConstant ^ (m + 1)) ^ 2 *
        rho ^ (2 * (alpha - j)) * Cp ^ j) * R ^ ((alpha - 1) * (j / alpha - 2)) *
        Real.exp (c * j) * (E0 ^ (j / alpha - 2) * u0 ^ (-(j / alpha))) *
        D ^ (-2 * (alpha - j) - j + (alpha - 1) * (2 - j / alpha)) := by
      have hfac := low_count_margin_factorization halpha0 hrho hCp hD0 hX0 hR0 hE0 hu0 (j := j) (c := c)
      have h := congrArg (fun z : ℝ => (m : ℝ) ^ 2 * (coupledLowCoefficientConstant ^ (m + 1)) ^ 2 * z) hfac
      convert h using 1 <;> dsimp [F, Eref, vref] <;> ring
    _ ≤ _ := by
      apply (mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_right hcoef (by positivity)) (by positivity)) (by positivity)) (by positivity)).trans hscalar

/-- Complete actual low-count calibration: one fixed baseline leaves a uniform D^-1 margin ratio. -/
theorem coupled_low_count_variance_calibrated (Bp cp : ℝ) (hBp : 0 < Bp) (hcp : 0 < cp)
    (Ncount : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (Ncount i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (Ncount i) (Ncount j) μ))
    (Y : ι → Ξ → ℕ)
    (hY : ∀ i, MeasurePreserving (Y i) ν
      (poissonMeasure ⟨cp * lam i, mul_nonneg hcp.le (lam i).coe_nonneg⟩))
    (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) (hk : (0 : ℝ) < Fintype.card ι)
    {ℓ Nk m : ℕ} (hm : 0 < m) (hℓ : 0 < ℓ) (hNk : 0 < Nk) (hdegree : 4 * (ℓ - 1) ≤ m)
    {γ a b fL f A B ω n E v rho D X R E0 u0 c : ℝ}
    (hγ : 0 < γ) (hγ1 : γ ≤ 1) (halpha : 3 / 2 ≤ (m : ℝ) + γ)
    (ha : 0 < a) (hb : 0 < b) (hf : 0 ≤ fL) (hf1 : fL < 1) (hA : 0 ≤ A) (hA1 : A ≤ 1)
    (hZ : (Nk : ℝ) ^ 2 * (a / b) ≤ 1) (hrho : 0 < rho) (hD : 1 ≤ D) (hX : 1 ≤ X)
    (hE0 : 0 < E0) (hu0 : 0 < u0) (hc : 0 ≤ c)
    (hR : Real.exp (3 * (Real.log (lowCountExponentialConstant rho (pilotConstant Bp cp)) + c)) ≤ R)
    (hcut : (Fintype.card ι : ℝ) * a ≤ rho / D)
    (hE : E0 * (R / D) ^ ((m : ℝ) + γ - 1) ≤ E)
    (hv : u0 * Real.exp (-c * ((m : ℝ) + γ)) * X ^ (-((m : ℝ) + γ)) ≤ v)
    (hnsize : n = D * ((m : ℝ) + γ) * (Fintype.card ι : ℝ) ^ (1 - 1 / ((m : ℝ) + γ)) * X)
    (hlam : ∀ i, (lam i : ℝ) = n * p i) :
    pilotAveragedCountVariance Ncount Y (cp * Bp * ((m : ℝ) + γ)) m
        (coupledQPolynomial ℓ Nk m γ a b fL f A B ω).coeff n μ ν /
      (((Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + γ))) *
        (E + v * ((∑ i, p i ^ ((m : ℝ) + γ)) /
          (Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + γ))))) ^ 2 ≤
        (max (E0 ^ (-2 : ℝ)) (E0 ^ (-1 : ℝ)) * max 1 (u0 ^ (-1 : ℝ))) / D := by
  let alpha := (m : ℝ) + γ
  let k := (Fintype.card ι : ℝ)
  let Pstar := k ^ (1 - alpha)
  let Cp := pilotConstant Bp cp
  let K := max (E0 ^ (-2 : ℝ)) (E0 ^ (-1 : ℝ)) * max 1 (u0 ^ (-1 : ℝ))
  have hCp : 0 < Cp := (by linarith : 0 < 2 * Bp + 1).trans_le (le_max_left _ _)
  have hD0 : 0 < D := zero_lt_one.trans_le hD
  have hX0 : 0 < X := zero_lt_one.trans_le hX
  have hR0 : 0 < R := (Real.exp_pos _).trans_le hR
  have halpha0 : 0 < alpha := by dsimp [alpha]; linarith
  have hn : 0 < n := by rw [hnsize]; positivity
  have hEpos : 0 < E := (by positivity : 0 < E0 * (R / D) ^ ((m : ℝ) + γ - 1)).trans_le hE
  have hvpos : 0 < v := (by positivity : 0 < u0 * Real.exp (-c * ((m : ℝ) + γ)) * X ^ (-((m : ℝ) + γ))).trans_le hv
  have hk1 : 1 ≤ k := by
    have hkNat : 0 < Fintype.card ι := by exact_mod_cast hk
    dsimp [k]
    exact_mod_cast hkNat
  have hmR : 0 < (m : ℝ) := by exact_mod_cast hm
  let T : ℕ → ℝ := fun r =>
    ((coupledLowCoefficientConstant ^ (m + 1) * a ^ (alpha - ((r + 1 : ℕ) : ℝ))) ^ 2 *
      (Cp * alpha) ^ (r + 1) / n ^ (r + 1) / Pstar ^ 2) *
      (k ^ (1 - ((r + 1 : ℕ) : ℝ)) * E ^ (((r + 1 : ℕ) : ℝ) / alpha - 2) *
        v ^ (-(((r + 1 : ℕ) : ℝ) / alpha)))
  have hbase := coupled_low_count_variance_affine_margin (f := f) (B := B) (ω := ω) Bp cp hBp hcp Ncount lam hLaw hpair Y hY p hp hk
    hℓ hNk hdegree hγ hγ1 ha hb hf hf1 hA hA1 hZ hn hlam hEpos hvpos
  have hterm : ∀ r ∈ Finset.range m, T r ≤ (K / D) / (m : ℝ) ^ 2 := by
    intro r hr
    have hrm : r + 1 ≤ m := by have := Finset.mem_range.mp hr; omega
    have hrma : ((r + 1 : ℕ) : ℝ) ≤ alpha := by
      have h : ((r + 1 : ℕ) : ℝ) ≤ m := by exact_mod_cast hrm
      dsimp [alpha]
      linarith
    have hscalar := low_count_single_degree_calibration hm halpha (by linarith)
      (by positivity : 0 ≤ ((r + 1 : ℕ) : ℝ)) hrma hk1 ha hrho hCp hD hX hE0 hu0 hc hR hcut hE hv
    rw [← hnsize] at hscalar
    simp only [Real.rpow_natCast] at hscalar
    apply (le_div_iff₀ (sq_pos_of_pos hmR)).mpr
    convert hscalar using 1
    dsimp [T, K, Pstar, k, Cp, alpha]
    ring
  calc
    _ ≤ (m : ℝ) * ∑ r ∈ Finset.range m, T r := hbase
    _ ≤ (m : ℝ) * ∑ _r ∈ Finset.range m, (K / D) / (m : ℝ) ^ 2 :=
      mul_le_mul_of_nonneg_left (Finset.sum_le_sum hterm) hmR.le
    _ = _ := by
      simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
      dsimp [K]
      field_simp

/-- The manuscript's calibrated C0^m baseline dominates the fixed reference used above. -/
theorem source_baseline_dominates_low_count_reference {m : ℕ} {alpha C0 rho D R chi d : ℝ}
    (halpha : 1 ≤ alpha) (ham : alpha - 1 ≤ (m : ℝ)) (hC0 : 1 ≤ C0)
    (hrho : 0 < rho) (hD : 0 < D) (hR : 0 < R) (hscale : R ≤ C0 * rho)
    (hchi : 1 / 2 ≤ chi) (hd : 0 < d) :
    (d / 2) * (R / D) ^ (alpha - 1) ≤ chi * d * C0 ^ m * (rho / D) ^ (alpha - 1) := by
  have hC0pos : 0 < C0 := zero_lt_one.trans_le hC0
  have hpower : C0 ^ (alpha - 1) ≤ C0 ^ m := by
    rw [← Real.rpow_natCast]
    exact Real.rpow_le_rpow_of_exponent_le hC0 ham
  have hscaled : (R / D) ^ (alpha - 1) ≤ C0 ^ m * (rho / D) ^ (alpha - 1) := by
    calc
      _ ≤ (C0 * (rho / D)) ^ (alpha - 1) :=
        Real.rpow_le_rpow (div_pos hR hD).le
          ((div_le_div_of_nonneg_right hscale hD.le).trans_eq (by ring)) (by linarith)
      _ = C0 ^ (alpha - 1) * (rho / D) ^ (alpha - 1) :=
        Real.mul_rpow hC0pos.le (div_pos hrho hD).le
      _ ≤ _ := mul_le_mul_of_nonneg_right hpower (Real.rpow_nonneg (div_pos hrho hD).le _)
  have hscalar : d / 2 ≤ chi * d := by nlinarith
  have h := mul_le_mul hscalar hscaled (Real.rpow_nonneg (div_pos hR hD).le _) (by positivity)
  exact h.trans_eq (by ring)

/-- The actual entropy attenuation and root reserve imply the uniform reference root width. -/
theorem source_root_width_dominates_reference {alpha eps X cu u : ℝ}
    (heps : 0 ≤ eps) (hX : 0 < X) (hcu : 0 < cu) (hu : cu * X ^ (-alpha) ≤ u) :
    cu * Real.exp (-(2 * eps) * alpha) * X ^ (-alpha) ≤
      Real.exp (-(2 * eps) * (alpha - 1)) * u := by
  have h1 : Real.exp (-(2 * eps) * alpha) ≤ Real.exp (-(2 * eps) * (alpha - 1)) :=
    Real.exp_le_exp.mpr (by nlinarith)
  have h := mul_le_mul h1 hu (by positivity) (Real.exp_pos _).le
  convert h using 1
  ring

end Renyi
