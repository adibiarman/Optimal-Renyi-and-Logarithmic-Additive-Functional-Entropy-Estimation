import Renyi.Foundations
import Mathlib.Probability.ProbabilityMassFunction.Basic
import Mathlib.Analysis.Normed.Group.InfiniteSum

/-!
# Countable testing and contraction to arbitrary reported observations

All real series have their convergence proved. The arguments work on arbitrary
index types; summability supplies the relevant countable support automatically.
The output space of a statistic need not be countable.
-/

noncomputable section
open MeasureTheory
namespace Renyi

def realTV {Ω : Type*} (p q : Ω → ℝ) : ℝ :=
  (∑' x, |p x - q x|) / 2

theorem realTV_nonneg {Ω : Type*} (p q : Ω → ℝ) : 0 ≤ realTV p q :=
  div_nonneg (tsum_nonneg (fun _ => abs_nonneg _)) (by norm_num)

/-- Multiplication by a randomized test preserves absolute summability. -/
theorem summable_bounded_test {Ω : Type*} (f t : Ω → ℝ) (hf : Summable f)
    (ht0 : ∀ x, 0 ≤ t x) (ht1 : ∀ x, t x ≤ 1) :
    Summable (fun x => f x * t x) := by
  apply hf.abs.of_norm_bounded
  intro x
  rw [Real.norm_eq_abs, abs_mul, abs_of_nonneg (ht0 x)]
  exact mul_le_of_le_one_right (abs_nonneg _) (ht1 x)

/-- Every randomized test contracts total variation. Normalization and
summability suffice; the result even allows signed input weights. -/
theorem discrete_test_signed_sum_bound {Ω : Type*} (p q t : Ω → ℝ)
    (hp : HasSum p 1) (hq : HasSum q 1)
    (ht0 : ∀ x, 0 ≤ t x) (ht1 : ∀ x, t x ≤ 1) :
    |∑' x, (p x - q x) * t x| ≤ realTV p q := by
  have hd : HasSum (fun x => p x - q x) 0 := by simpa using hp.sub hq
  have hs := summable_bounded_test (fun x => p x - q x) t hd.summable ht0 ht1
  have hcenter : HasSum (fun x => (p x - q x) * (t x - 1 / 2))
      (∑' x, (p x - q x) * t x) := by
    convert hs.hasSum.sub (hd.mul_right (1 / 2)) using 1
    · funext x
      ring
    · ring
  have hnorm : ∀ x, ‖(p x - q x) * (t x - 1 / 2)‖ ≤ |p x - q x| / 2 := by
    intro x
    have ht : |t x - 1 / 2| ≤ (1 / 2 : ℝ) := abs_le.mpr ⟨by linarith [ht0 x], by linarith [ht1 x]⟩
    rw [Real.norm_eq_abs, abs_mul]
    have h := mul_le_mul_of_nonneg_left ht (abs_nonneg (p x - q x))
    nlinarith
  have h := tsum_of_norm_bounded (hd.summable.abs.hasSum.div_const 2) hnorm
  rw [hcenter.tsum_eq, Real.norm_eq_abs] at h
  exact h

/-- Equivalent expectation formulation, with the two test expectations convergent. -/
theorem discrete_bounded_test_contraction {Ω : Type*} (p q t : Ω → ℝ)
    (hp : HasSum p 1) (hq : HasSum q 1)
    (ht0 : ∀ x, 0 ≤ t x) (ht1 : ∀ x, t x ≤ 1) :
    |(∑' x, p x * t x) - ∑' x, q x * t x| ≤ realTV p q := by
  have hpT := summable_bounded_test p t hp.summable ht0 ht1
  have hqT := summable_bounded_test q t hq.summable ht0 ht1
  rw [← hpT.tsum_sub hqT]
  simpa only [sub_mul] using discrete_test_signed_sum_bound p q t hp hq ht0 ht1

/-- Every randomized binary decision has sum of errors at least `1 - TV`. -/
theorem discrete_testing_lower_bound {Ω : Type*} (p q t : Ω → ℝ)
    (hp : HasSum p 1) (hq : HasSum q 1)
    (ht0 : ∀ x, 0 ≤ t x) (ht1 : ∀ x, t x ≤ 1) :
    1 - realTV p q ≤ ∑' x, (p x * t x + q x * (1 - t x)) := by
  have hpT := summable_bounded_test p t hp.summable ht0 ht1
  have hqT := summable_bounded_test q t hq.summable ht0 ht1
  have herr : HasSum (fun x => p x * t x + q x * (1 - t x))
      (1 + ((∑' x, p x * t x) - ∑' x, q x * t x)) := by
    convert hpT.hasSum.add (hq.sub hqT.hasSum) using 1
    · funext x
      ring
    · ring
  rw [herr.tsum_eq]
  have h := (abs_le.mp (discrete_bounded_test_contraction p q t hp hq ht0 ht1)).1
  linarith

private theorem pmf_mass_hasSum {Ω : Type*} (p : PMF Ω) :
    HasSum (fun x => (p x).toReal) 1 := by
  have hs := ENNReal.summable_toReal (f := fun x => p x) (by
    rw [p.tsum_coe]
    exact ENNReal.one_ne_top)
  have heq : (∑' x, (p x).toReal) = 1 := by
    rw [← ENNReal.tsum_toReal_eq (fun x => p.apply_ne_top x), p.tsum_coe]
    rfl
  exact heq ▸ hs.hasSum

/-- Event probability as a convergent real-valued countable test expectation. -/
theorem pmf_event_real_hasSum {Ω : Type*} [MeasurableSpace Ω]
    [MeasurableSingletonClass Ω] (p : PMF Ω) (S : Set Ω) :
    HasSum (fun x => (p x).toReal * S.indicator (fun _ => (1 : ℝ)) x)
      (p.toMeasure.real S) := by
  classical
  have hs := summable_bounded_test (fun x => (p x).toReal)
    (S.indicator (fun _ => (1 : ℝ))) (pmf_mass_hasSum p).summable
    (fun x => by by_cases hx : x ∈ S <;> simp [hx])
    (fun x => by by_cases hx : x ∈ S <;> simp [hx])
  have heq : p.toMeasure.real S =
      ∑' x, (p x).toReal * S.indicator (fun _ => (1 : ℝ)) x := by
    rw [Measure.real_def, p.toMeasure_apply_eq_tsum]
    rw [ENNReal.tsum_toReal_eq (fun x => by
      by_cases hx : x ∈ S
      · simpa [hx] using p.apply_ne_top x
      · simp [hx])]
    apply tsum_congr
    intro x
    by_cases hx : x ∈ S <;> simp [hx]
  exact heq.symm ▸ hs.hasSum

/-- The difference of arbitrary event probabilities is bounded by half the L1
distance of the actual PMF masses. No countability restriction on the type is needed. -/
theorem pmf_event_tv_bound {Ω : Type*} [MeasurableSpace Ω]
    [MeasurableSingletonClass Ω] (p q : PMF Ω) (S : Set Ω) :
    |p.toMeasure.real S - q.toMeasure.real S| ≤
      realTV (fun x => (p x).toReal) (fun x => (q x).toReal) := by
  classical
  have h := discrete_bounded_test_contraction (fun x => (p x).toReal)
    (fun x => (q x).toReal) (S.indicator (fun _ => (1 : ℝ)))
    (pmf_mass_hasSum p) (pmf_mass_hasSum q)
    (fun x => by by_cases hx : x ∈ S <;> simp [hx])
    (fun x => by by_cases hx : x ∈ S <;> simp [hx])
  rwa [(pmf_event_real_hasSum p S).tsum_eq, (pmf_event_real_hasSum q S).tsum_eq] at h

/-- Any reported statistic contracts total variation, including fingerprints
with an uncountable output type. Events are evaluated through their preimages. -/
theorem pmf_statistic_event_tv_bound {Ω Y : Type*} [MeasurableSpace Ω]
    [MeasurableSingletonClass Ω] (p q : PMF Ω) (f : Ω → Y) (A : Set Y) :
    |p.toMeasure.real (f ⁻¹' A) - q.toMeasure.real (f ⁻¹' A)| ≤
      realTV (fun x => (p x).toReal) (fun x => (q x).toReal) :=
  pmf_event_tv_bound p q (f ⁻¹' A)

end Renyi
