import Renyi.FalseClassification

/-! Actual near-one Gamma residual under the light pilot, including selector
randomness and every signed low-count value. -/
set_option maxHeartbeats 600000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def gammaResidualPilotConstant (Cw : ℝ) : ℝ := smallOrderRatioConstant + 3 + Cw

/-- A direct pointwise near-one residual bound, with a fixed polynomial envelope. -/
theorem gamma_residual_pilot_pointwise {beta xi omega Cw : ℝ}
    (hbeta : 0 < beta) (hbeta1 : beta ≤ 1 / 2) (hxi : 0 < xi) (hxi1 : xi ≤ 1)
    (hw0 : 0 ≤ omega) (hw1 : omega ≤ 1) (hCw : 0 ≤ Cw)
    (hwdiff : |omega - 1| ≤ Cw * beta) (j : ℕ) :
    |omega * analyticCount (1 + beta) j - xi ^ beta * (j : ℝ)| ≤
      gammaResidualPilotConstant Cw * beta * (1 + |Real.log xi|) * ((j : ℝ) + 1) ^ (3 : ℕ) := by
  let x := (j : ℝ) + 1
  let p := x ^ beta
  have hx0 : 0 < x := by dsimp [x]; positivity
  have hx1 : 1 ≤ x := by dsimp [x]; have := Nat.cast_nonneg (α := ℝ) j; linarith
  have hp0 : 0 ≤ p := Real.rpow_nonneg hx0.le _
  have hp1 : 1 ≤ p := Real.one_le_rpow hx1 hbeta.le
  have hz0 : 0 ≤ xi ^ beta := Real.rpow_nonneg hxi.le _
  have hz1 : xi ^ beta ≤ 1 := Real.rpow_le_one hxi.le hxi1 hbeta.le
  have hHpos : 0 < analyticCount beta j := analyticCount_pos beta j (by have := Nat.cast_nonneg (α := ℝ) j; linarith)
  have hHup := analyticCount_small_order_upper hbeta hbeta1 j
  have hHerror := analyticCount_small_order_error hbeta hbeta1 j
  have hK := smallOrderRatioConstant_nonneg
  have hfirst : |analyticCount (1 + beta) j - (j : ℝ) * p| ≤
      (smallOrderRatioConstant + 1) * beta * x * p := by
    have heq : analyticCount (1 + beta) j - (j : ℝ) * p =
        (j : ℝ) * (analyticCount beta j - p) - beta * analyticCount beta j := by
      rw [show 1 + beta = beta + 1 by ring, analyticCount_order_succ]
      ring
    rw [heq]
    have htri := abs_sub_le ((j : ℝ) * (analyticCount beta j - p)) 0 (beta * analyticCount beta j)
    simp only [sub_zero, zero_sub, abs_neg] at htri
    apply htri.trans
    rw [abs_mul, abs_mul, abs_of_nonneg (Nat.cast_nonneg j), abs_of_pos hbeta, abs_of_pos hHpos]
    have hm := mul_le_mul_of_nonneg_left hHerror (Nat.cast_nonneg j)
    have hn := mul_le_mul_of_nonneg_left hHup hbeta.le
    change (j : ℝ) * |analyticCount beta j - p| ≤ (j : ℝ) * (smallOrderRatioConstant * beta * p) at hm
    change beta * analyticCount beta j ≤ beta * p at hn
    dsimp [x]
    have hnon : 0 ≤ smallOrderRatioConstant * beta * p := by positivity
    have hjnon : 0 ≤ (j : ℝ) * beta * p := by positivity
    nlinarith only [hm, hn, hnon, hjnon]
  have hlogx : 0 ≤ Real.log x := Real.log_nonneg hx1
  have hlogxi : Real.log xi ≤ 0 := Real.log_nonpos hxi.le hxi1
  have hlogratio : |Real.log (x / xi)| = Real.log x + |Real.log xi| := by
    rw [Real.log_div hx0.ne' hxi.ne', abs_of_nonneg (by linarith), abs_of_nonpos hlogxi]
    ring
  have hdiff := abs_rpow_sub_le_sum_mul_log hx0 hxi hbeta.le
  rw [hlogratio] at hdiff
  have hsecond : |(j : ℝ) * p - xi ^ beta * (j : ℝ)| ≤
      2 * beta * x * p * (Real.log x + |Real.log xi|) := by
    have heq : (j : ℝ) * p - xi ^ beta * (j : ℝ) = (j : ℝ) * (p - xi ^ beta) := by ring
    rw [heq, abs_mul, abs_of_nonneg (Nat.cast_nonneg j)]
    have hm := mul_le_mul_of_nonneg_left hdiff (Nat.cast_nonneg j)
    change (j : ℝ) * |p - xi ^ beta| ≤ (j : ℝ) * (beta * (p + xi ^ beta) * (Real.log x + |Real.log xi|)) at hm
    have hjx : (j : ℝ) ≤ x := by dsimp [x]; linarith
    have hpz : p + xi ^ beta ≤ 2 * p := by linarith
    have hprod := mul_le_mul hjx hpz (by positivity : 0 ≤ p + xi ^ beta) hx0.le
    have hnon : 0 ≤ beta * (Real.log x + |Real.log xi|) := by positivity
    have hmul := mul_le_mul_of_nonneg_right hprod hnon
    nlinarith only [hm, hmul]
  have hraw : |analyticCount (1 + beta) j - xi ^ beta * (j : ℝ)| ≤
      (smallOrderRatioConstant + 3) * beta * x * p * (1 + |Real.log xi| + Real.log x) := by
    have ht := abs_sub_le (analyticCount (1 + beta) j) ((j : ℝ) * p) (xi ^ beta * (j : ℝ))
    have hnon : 0 ≤ beta * x * p := by positivity
    have hnonlog : 0 ≤ (smallOrderRatioConstant + 1) * beta * x * p *
        (|Real.log xi| + Real.log x) := by positivity
    nlinarith only [ht, hfirst, hsecond, hnon, hnonlog]
  have homega : |omega * analyticCount (1 + beta) j - xi ^ beta * (j : ℝ)| ≤
      |analyticCount (1 + beta) j - xi ^ beta * (j : ℝ)| + Cw * beta * (j : ℝ) := by
    have heq : omega * analyticCount (1 + beta) j - xi ^ beta * (j : ℝ) =
        omega * (analyticCount (1 + beta) j - xi ^ beta * (j : ℝ)) +
          (omega - 1) * xi ^ beta * (j : ℝ) := by ring
    rw [heq]
    apply (abs_add_le _ _).trans
    simp only [abs_mul, abs_of_nonneg hw0, abs_of_nonneg hz0,
      abs_of_nonneg (Nat.cast_nonneg j : (0 : ℝ) ≤ j)]
    have hleft := mul_le_of_le_one_left (abs_nonneg (analyticCount (1 + beta) j - xi ^ beta * (j : ℝ))) hw1
    have hright := mul_le_mul_of_nonneg_right (mul_le_mul hwdiff hz1 hz0 (by positivity : 0 ≤ Cw * beta)) (Nat.cast_nonneg j)
    nlinarith only [hleft, hright]
  have hlogbound : 1 + |Real.log xi| + Real.log x ≤ (1 + |Real.log xi|) * x := by
    have hl := Real.log_le_sub_one_of_pos hx0
    have hm := mul_le_mul_of_nonneg_left hx1 (abs_nonneg (Real.log xi))
    nlinarith only [hl, hm]
  have hpower : p ≤ x := Real.rpow_le_self_of_one_le hx1 (by linarith)
  have hpoly : x * p * (1 + |Real.log xi| + Real.log x) ≤
      (1 + |Real.log xi|) * x ^ (3 : ℕ) := by
    have hm := mul_le_mul hpower hlogbound (by positivity : 0 ≤ 1 + |Real.log xi| + Real.log x)
      hx0.le
    have hn := mul_le_mul_of_nonneg_left hm hx0.le
    nlinarith only [hn]
  have hmain := mul_le_mul_of_nonneg_left hpoly (mul_nonneg (by linarith : 0 ≤ smallOrderRatioConstant + 3) hbeta.le)
  have hextra : Cw * beta * (j : ℝ) ≤ Cw * beta * (1 + |Real.log xi|) * x ^ (3 : ℕ) := by
    have hxpoly : (j : ℝ) ≤ (1 + |Real.log xi|) * x ^ (3 : ℕ) := by
      have hjx : (j : ℝ) ≤ x := by dsimp [x]; linarith
      have hxx : x ≤ x ^ (3 : ℕ) := by
        have hxx2 : 1 ≤ x ^ (2 : ℕ) := one_le_pow₀ hx1
        have hmul := mul_le_mul_of_nonneg_left hxx2 hx0.le
        nlinarith only [hmul]
      have hmul := mul_le_mul_of_nonneg_right
        (show (1 : ℝ) ≤ 1 + |Real.log xi| by linarith [abs_nonneg (Real.log xi)]) (by positivity : 0 ≤ x ^ (3 : ℕ))
      nlinarith only [hjx, hxx, hmul]
    simpa only [mul_assoc] using mul_le_mul_of_nonneg_left hxpoly (mul_nonneg hCw hbeta.le)
  dsimp [gammaResidualPilotConstant]
  nlinarith only [homega, hraw, hmain, hextra]

theorem poissonLowerSelected_hasSum (lam mu : ℝ≥0) (T : ℝ) (f : ℕ → ℝ)
    (hf0 : ∀ j, 0 ≤ f j) (hf : Integrable f (poissonMeasure lam)) :
    HasSum (fun z : ℕ × ℕ =>
      (if (z.1 : ℝ) ≤ T then f z.2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1))
      (poissonLowerMass mu T * ∫ j, f j ∂poissonMeasure lam) := by
  let g : ℕ → ℝ := fun y => if (y : ℝ) ≤ T then poissonPMFReal mu y else 0
  let h : ℕ → ℝ := fun j => f j * poissonPMFReal lam j
  have hg := poissonLowerMass_summable mu T
  have hh := poisson_integrable_summable lam f hf
  have hg0 : 0 ≤ g := by intro j; dsimp [g]; split_ifs <;> simp [poissonPMFReal_nonneg]
  have hh0 : 0 ≤ h := fun j => mul_nonneg (hf0 j) poissonPMFReal_nonneg
  have hprod := hg.mul_of_nonneg hh hg0 hh0
  have hs := hg.hasSum.mul hh.hasSum hprod
  have heq (z : ℕ × ℕ) : g z.1 * h z.2 =
      (if (z.1 : ℝ) ≤ T then f z.2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1) := by
    dsimp [g, h]
    split_ifs <;> ring
  rw [poisson_integral_eq_tsum lam f hf]
  convert hs using 1
  funext z
  exact (heq z).symm

/-- A fixed shifted Poisson moment is exponentially bounded with no intensity
restriction. The displayed expression comes from the actual exponential mgf. -/
theorem poisson_shifted_sixth_moment_bound (lam : ℝ≥0) :
    (∫ j : ℕ, ((j : ℝ) + 1) ^ (6 : ℕ) ∂poissonMeasure lam) ≤
      (6 : ℝ) ^ (6 : ℕ) * Real.exp ((lam : ℝ) * (Real.exp 1 - 1)) := by
  have hf := (poisson_count_power_memLp lam 6).integrable one_le_two
  rw [poisson_integral_eq_tsum lam _ hf]
  have hg := (poisson_exp_shift_hasSum lam 1 5).mul_left ((6 : ℝ) ^ (6 : ℕ))
  simp only [one_mul] at hg
  have hpoint (j : ℕ) : ((j : ℝ) + 1) ^ (6 : ℕ) * poissonPMFReal lam j ≤
      (6 : ℝ) ^ (6 : ℕ) * (Real.exp ((j : ℝ) - 5) * poissonPMFReal lam j) := by
    have h := rpow_le_scaled_exponential (by positivity : 0 ≤ (j : ℝ) + 1)
      (by norm_num : (0 : ℝ) < 6) (by norm_num : (0 : ℝ) < 1)
    simp only [div_one, one_mul] at h
    rw [show ((j : ℝ) + 1) ^ (6 : ℝ) = ((j : ℝ) + 1) ^ (6 : ℕ) from
      Real.rpow_natCast _ _, show (6 : ℝ) ^ (6 : ℝ) = (6 : ℝ) ^ (6 : ℕ) from
      Real.rpow_natCast _ _] at h
    rw [show (j : ℝ) + 1 - 6 = (j : ℝ) - 5 by ring] at h
    have hm := mul_le_mul_of_nonneg_right h (poissonPMFReal_nonneg (r := lam) (n := j))
    simpa only [mul_assoc] using hm
  have hs := poisson_integrable_summable lam _ hf
  have hh := hs.tsum_le_tsum hpoint hg.summable
  rw [hg.tsum_eq] at hh
  exact hh.trans (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by linarith)) (by norm_num))

/-- Light-pilot selection uniformly bounds the sixth shifted count moment. -/
theorem poisson_light_shifted_sixth_bound (lam : ℝ≥0) {cp T : ℝ}
    (hcp0 : 0 < cp) (hcp : 2 * Real.exp 1 ≤ cp) :
    poissonLowerMass ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ T *
      (∫ j : ℕ, ((j : ℝ) + 1) ^ (6 : ℕ) ∂poissonMeasure lam) ≤
      (6 : ℝ) ^ (6 : ℕ) * Real.exp T := by
  have ht := poissonLowerMass_exp_bound (⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ : ℝ≥0) T
  have htail : poissonLowerMass (⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ : ℝ≥0) T ≤
      Real.exp (T - cp * (lam : ℝ) / 2) := by
    apply ht.trans
    apply Real.exp_le_exp.mpr
    have hm := mul_le_mul_of_nonneg_left exp_neg_one_le_three_eighths (mul_nonneg hcp0.le lam.coe_nonneg)
    have hnon : 0 ≤ cp * (lam : ℝ) := by positivity
    simp only [NNReal.coe_mk]
    nlinarith
  have hmoment := poisson_shifted_sixth_moment_bound lam
  have hnon : 0 ≤ ∫ j : ℕ, ((j : ℝ) + 1) ^ (6 : ℕ) ∂poissonMeasure lam :=
    integral_nonneg (fun j => by positivity)
  have hprod := mul_le_mul htail hmoment hnon (Real.exp_pos _).le
  have hexp : Real.exp (T - cp * (lam : ℝ) / 2) *
      Real.exp ((lam : ℝ) * (Real.exp 1 - 1)) ≤ Real.exp T := by
    rw [← Real.exp_add]
    apply Real.exp_le_exp.mpr
    have hm := mul_le_mul_of_nonneg_right hcp lam.coe_nonneg
    nlinarith [lam.coe_nonneg]
  nlinarith only [hprod, hexp]

/-- The complete near-one Gamma branch-replacement second moment under the
actual independent pilot/main count law. All signed values, including count
zero, are retained. -/
theorem gamma_residual_light_joint_second {beta xi omega Cw cp T : ℝ}
    (hbeta : 0 < beta) (hbeta1 : beta ≤ 1 / 2) (hxi : 0 < xi) (hxi1 : xi ≤ 1)
    (hw0 : 0 ≤ omega) (hw1 : omega ≤ 1) (hCw : 0 ≤ Cw)
    (hwdiff : |omega - 1| ≤ Cw * beta)
    (hcp0 : 0 < cp) (hcp : 2 * Real.exp 1 ≤ cp) (lam : ℝ≥0) :
    let mu : ℝ≥0 := ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩
    Summable (fun z : ℕ × ℕ =>
      (if (z.1 : ℝ) ≤ T then (omega * analyticCount (1 + beta) z.2 - xi ^ beta * (z.2 : ℝ)) ^ 2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1)) ∧
    (∑' z : ℕ × ℕ,
      (if (z.1 : ℝ) ≤ T then (omega * analyticCount (1 + beta) z.2 - xi ^ beta * (z.2 : ℝ)) ^ 2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1)) ≤
      (6 : ℝ) ^ (6 : ℕ) * Real.exp T * gammaResidualPilotConstant Cw ^ 2 * beta ^ 2 *
        (1 + |Real.log xi|) ^ 2 := by
  dsimp only
  let mu : ℝ≥0 := ⟨cp * lam, by positivity⟩
  let R : ℕ → ℝ := fun j => omega * analyticCount (1 + beta) j - xi ^ beta * (j : ℝ)
  let K := gammaResidualPilotConstant Cw ^ 2 * beta ^ 2 * (1 + |Real.log xi|) ^ 2
  have hK : 0 ≤ K := by dsimp [K]; positivity
  have hR : MemLp R 2 (poissonMeasure lam) :=
    ((analyticCount_memLp lam (1 + beta)).const_mul omega).sub ((poisson_nat_memLp lam).const_mul (xi ^ beta))
  have hpoint (j : ℕ) : R j ^ 2 ≤ K * ((j : ℝ) + 1) ^ (6 : ℕ) := by
    have h := gamma_residual_pilot_pointwise hbeta hbeta1 hxi hxi1 hw0 hw1 hCw hwdiff j
    have hD : 0 ≤ gammaResidualPilotConstant Cw := by
      dsimp [gammaResidualPilotConstant]
      linarith [smallOrderRatioConstant_nonneg]
    have hs := mul_le_mul h h (abs_nonneg _) (by positivity : 0 ≤ gammaResidualPilotConstant Cw * beta * (1 + |Real.log xi|) * ((j : ℝ) + 1) ^ (3 : ℕ))
    simp only [← pow_two, sq_abs] at hs
    dsimp [K, R]
    nlinarith only [hs]
  have hmono := integral_mono hR.integrable_sq (((poisson_count_power_memLp lam 6).integrable one_le_two).const_mul K) hpoint
  rw [integral_const_mul] at hmono
  have hselected := poissonLowerSelected_hasSum lam mu T (fun j => R j ^ 2) (fun j => sq_nonneg _) hR.integrable_sq
  refine ⟨hselected.summable, ?_⟩
  rw [hselected.tsum_eq]
  have hprob0 := poissonLowerMass_nonneg mu T
  have hfirst := mul_le_mul_of_nonneg_left hmono hprob0
  have hbudget := poisson_light_shifted_sixth_bound lam hcp0 hcp (T := T)
  have hsecond := mul_le_mul_of_nonneg_left hbudget hK
  dsimp [K] at *
  nlinarith only [hfirst, hsecond]

/-- Count-unit and probability-unit residuals agree under the actual scaling
`xi = n*t`. -/
theorem gamma_residual_probability_identity {n t beta omega : ℝ}
    (hn : 0 < n) (ht : 0 < t) (j : ℕ) :
    omega * analyticCount (1 + beta) j / n ^ (1 + beta) -
        t ^ beta * (j : ℝ) / n =
      (omega * analyticCount (1 + beta) j - (n * t) ^ beta * (j : ℝ)) /
        n ^ (1 + beta) := by
  rw [Real.mul_rpow hn.le ht.le, Real.rpow_add hn, Real.rpow_one]
  have hp := (Real.rpow_pos_of_pos hn beta).ne'
  field_simp

/-- The actual Gamma branch-replacement second moment in probability units.
It preserves the full near-one factor and retains every signed low count. -/
theorem gamma_residual_light_probability_second {n t beta omega Cw cp T : ℝ}
    (hn : 0 < n) (ht : 0 < t) (hnt : n * t ≤ 1)
    (hbeta : 0 < beta) (hbeta1 : beta ≤ 1 / 2)
    (hw0 : 0 ≤ omega) (hw1 : omega ≤ 1) (hCw : 0 ≤ Cw)
    (hwdiff : |omega - 1| ≤ Cw * beta)
    (hcp0 : 0 < cp) (hcp : 2 * Real.exp 1 ≤ cp) (lam : ℝ≥0) :
    let mu : ℝ≥0 := ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩
    Summable (fun z : ℕ × ℕ =>
      (if (z.1 : ℝ) ≤ T then
        (omega * analyticCount (1 + beta) z.2 / n ^ (1 + beta) -
          t ^ beta * (z.2 : ℝ) / n) ^ 2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1)) ∧
    (∑' z : ℕ × ℕ,
      (if (z.1 : ℝ) ≤ T then
        (omega * analyticCount (1 + beta) z.2 / n ^ (1 + beta) -
          t ^ beta * (z.2 : ℝ) / n) ^ 2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1)) ≤
      (6 : ℝ) ^ (6 : ℕ) * Real.exp T * gammaResidualPilotConstant Cw ^ 2 * beta ^ 2 /
        n ^ (2 * (1 + beta)) * (1 + |Real.log (n * t)|) ^ 2 := by
  dsimp only
  let mu : ℝ≥0 := ⟨cp * lam, by positivity⟩
  let d := n ^ (1 + beta)
  have hd : 0 < d := Real.rpow_pos_of_pos hn _
  have hh := gamma_residual_light_joint_second hbeta hbeta1 (mul_pos hn ht) hnt
    hw0 hw1 hCw hwdiff hcp0 hcp lam (T := T)
  dsimp only at hh
  have heq : (fun z : ℕ × ℕ =>
      (if (z.1 : ℝ) ≤ T then
        (omega * analyticCount (1 + beta) z.2 / n ^ (1 + beta) -
          t ^ beta * (z.2 : ℝ) / n) ^ 2 else 0) *
        (poissonPMFReal lam z.2 * poissonPMFReal mu z.1)) =
      (fun z : ℕ × ℕ => (1 / d ^ 2) *
        ((if (z.1 : ℝ) ≤ T then
          (omega * analyticCount (1 + beta) z.2 - (n * t) ^ beta * (z.2 : ℝ)) ^ 2 else 0) *
          (poissonPMFReal lam z.2 * poissonPMFReal mu z.1))) := by
    funext z
    split_ifs
    · rw [gamma_residual_probability_identity hn ht]
      dsimp [d]
      field_simp
    · ring
  have hdn : n ^ (2 * (1 + beta)) = d ^ 2 := by
    rw [mul_comm (2 : ℝ), Real.rpow_mul hn.le, Real.rpow_two]
  refine ⟨?_, ?_⟩
  · rw [heq]
    exact hh.1.mul_left _
  · rw [heq, tsum_mul_left, hdn]
    have hbound := mul_le_mul_of_nonneg_left hh.2 (by positivity : 0 ≤ 1 / d ^ 2)
    convert hbound using 1
    ring

end Renyi
