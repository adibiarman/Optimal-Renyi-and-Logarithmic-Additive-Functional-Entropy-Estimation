import Mathlib.Analysis.SpecialFunctions.Pow.Deriv
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Tactic

/-! The uniquely normalized degree-one endpoint completion. -/
noncomputable section
open Set
namespace Renyi

def degreeOneBoundary (s c : ℝ) : ℝ :=
  (1 - c) * c ^ s * (1 + s) ^ (1 + s) / s ^ s

def degreeOneNormalizer (s c : ℝ) : ℝ := s ^ s / (c ^ s * (1 + s) ^ (1 + s))

def degreeOneProfile (s c x : ℝ) : ℝ := x ^ s * (1 - c * x) / degreeOneNormalizer s c

theorem degreeOneBoundary_continuous {s : ℝ} (hs : 0 < s) :
    Continuous (degreeOneBoundary s) := by
  exact (((continuous_const.sub continuous_id).mul
    (Real.continuous_rpow_const hs.le)).mul continuous_const).div_const _

theorem degreeOneBoundary_left {s : ℝ} (hs : 0 < s) :
    degreeOneBoundary s (s / (1 + s)) = 1 := by
  have h1 : 0 < 1 + s := by positivity
  have hsn : s ^ s ≠ 0 := (Real.rpow_pos_of_pos hs _).ne'
  have h1n : (1 + s) ^ s ≠ 0 := (Real.rpow_pos_of_pos h1 _).ne'
  unfold degreeOneBoundary
  rw [Real.div_rpow hs.le h1.le, Real.rpow_add h1, Real.rpow_one]
  field_simp
  ring

@[simp] theorem degreeOneBoundary_right (s : ℝ) : degreeOneBoundary s 1 = 0 := by
  simp [degreeOneBoundary]

theorem degreeOneBoundary_hasDerivAt {s c : ℝ} (hc : 0 < c) :
    HasDerivAt (degreeOneBoundary s)
      (c ^ (s - 1) * (s - (s + 1) * c) * (1 + s) ^ (1 + s) / s ^ s) c := by
  have h := (((hasDerivAt_const c (1 : ℝ)).sub (hasDerivAt_id c)).mul
    (Real.hasDerivAt_rpow_const (Or.inl hc.ne') :
      HasDerivAt (fun x : ℝ => x ^ s) (s * c ^ (s - 1)) c)).mul_const
        ((1 + s) ^ (1 + s)) |>.div_const (s ^ s)
  convert h using 1
  have hp : c ^ s = c ^ (s - 1) * c := by
    calc
      c ^ s = c ^ ((s - 1) + 1) := by congr 1; ring
      _ = _ := by rw [Real.rpow_add hc, Real.rpow_one]
  rw [hp]
  simp only [Pi.sub_apply, id_eq]
  ring

theorem degreeOneBoundary_strictAnti {s : ℝ} (hs : 0 < s) :
    StrictAntiOn (degreeOneBoundary s) (Icc (s / (1 + s)) 1) := by
  have h1 : 0 < 1 + s := by positivity
  apply strictAntiOn_of_deriv_neg (convex_Icc _ _) (degreeOneBoundary_continuous hs).continuousOn
  intro c hc
  rw [interior_Icc] at hc
  have hc0 : 0 < c := (div_pos hs h1).trans hc.1
  rw [(degreeOneBoundary_hasDerivAt hc0).deriv]
  have hneg : s - (s + 1) * c < 0 := by
    have h := (div_lt_iff₀ h1).mp hc.1
    nlinarith
  exact div_neg_of_neg_of_pos
    (mul_neg_of_neg_of_pos
      (mul_neg_of_pos_of_neg (Real.rpow_pos_of_pos hc0 _) hneg)
      (Real.rpow_pos_of_pos h1 _)) (Real.rpow_pos_of_pos hs _)

/-- The floor equation has exactly one solution in its stated open interval. -/
theorem degreeOneBoundary_existsUnique {s q : ℝ} (hs : 0 < s)
    (hq : 0 < q) (hq1 : q < 1) :
    ∃! c : ℝ, c ∈ Ioo (s / (1 + s)) 1 ∧ degreeOneBoundary s c = q := by
  have h1 : 0 < 1 + s := by positivity
  have hstart : s / (1 + s) < 1 := (div_lt_one h1).2 (by linarith)
  have hqmem : q ∈ Icc (degreeOneBoundary s 1) (degreeOneBoundary s (s / (1 + s))) := by
    rw [degreeOneBoundary_right, degreeOneBoundary_left hs]
    exact ⟨hq.le, hq1.le⟩
  obtain ⟨c, hc, heq⟩ := intermediate_value_Icc' hstart.le
    (degreeOneBoundary_continuous hs).continuousOn hqmem
  have hcleft : s / (1 + s) < c := lt_of_le_of_ne hc.1 (by
    intro he
    rw [← he, degreeOneBoundary_left hs] at heq
    linarith)
  have hcright : c < 1 := lt_of_le_of_ne hc.2 (by
    intro he
    rw [he, degreeOneBoundary_right] at heq
    linarith)
  refine ⟨c, ⟨⟨hcleft, hcright⟩, heq⟩, ?_⟩
  intro d hd
  exact (degreeOneBoundary_strictAnti hs).injOn ⟨hd.1.1.le, hd.1.2.le⟩ hc
    (hd.2.trans heq.symm)

theorem degreeOneNumerator_hasDerivAt {s c x : ℝ} (hx : 0 < x) :
    HasDerivAt (fun y => y ^ s * (1 - c * y))
      (x ^ (s - 1) * (s - c * (s + 1) * x)) x := by
  have h := (Real.hasDerivAt_rpow_const (Or.inl hx.ne') :
    HasDerivAt (fun y : ℝ => y ^ s) (s * x ^ (s - 1)) x).mul
      ((hasDerivAt_const x (1 : ℝ)).sub ((hasDerivAt_id x).const_mul c))
  convert h using 1
  have hp : x ^ s = x ^ (s - 1) * x := by
    calc
      x ^ s = x ^ ((s - 1) + 1) := by congr 1; ring
      _ = _ := by rw [Real.rpow_add hx, Real.rpow_one]
  rw [hp]
  simp only [Pi.sub_apply, id_eq]
  ring

theorem degreeOneNumerator_at_critical {s c : ℝ} (hs : 0 < s) (hc : 0 < c) :
    (s / (c * (1 + s))) ^ s * (1 - c * (s / (c * (1 + s)))) =
      degreeOneNormalizer s c := by
  have h1 : 0 < 1 + s := by positivity
  have hid : 1 - c * (s / (c * (1 + s))) = 1 / (1 + s) := by field_simp; ring
  have hp : (1 + s) ^ (1 + s) = (1 + s) ^ s * (1 + s) := by
    rw [Real.rpow_add h1, Real.rpow_one]
    ring
  rw [hid, Real.div_rpow hs.le (mul_pos hc h1).le, Real.mul_rpow hc.le h1.le]
  unfold degreeOneNormalizer
  rw [hp]
  field_simp

theorem degreeOneNumerator_max {s c : ℝ} (hs : 0 < s)
    (hc : s / (1 + s) < c) {x : ℝ} (hx : x ∈ Icc (0 : ℝ) 1) :
    x ^ s * (1 - c * x) ≤ degreeOneNormalizer s c := by
  have h1 : 0 < 1 + s := by positivity
  have hc0 : 0 < c := (div_pos hs h1).trans hc
  let z := s / (c * (1 + s))
  have hz : 0 < z := by dsimp [z]; positivity
  have hz1 : z < 1 := by
    dsimp [z]
    apply (div_lt_one (mul_pos hc0 h1)).2
    exact (div_lt_iff₀ h1).mp hc
  have hcont : Continuous (fun y : ℝ => y ^ s * (1 - c * y)) :=
    (Real.continuous_rpow_const hs.le).mul
      (continuous_const.sub (continuous_const.mul continuous_id))
  have hcrit : c * (s + 1) * z = s := by dsimp [z]; field_simp; ring
  have hincr : MonotoneOn (fun y : ℝ => y ^ s * (1 - c * y)) (Icc 0 z) := by
    apply monotoneOn_of_deriv_nonneg (convex_Icc _ _) hcont.continuousOn
    · intro y hy
      rw [interior_Icc] at hy
      exact (degreeOneNumerator_hasDerivAt hy.1).differentiableAt.differentiableWithinAt
    · intro y hy
      rw [interior_Icc] at hy
      rw [(degreeOneNumerator_hasDerivAt hy.1).deriv]
      apply mul_nonneg (Real.rpow_nonneg hy.1.le _)
      have h := mul_le_mul_of_nonneg_left hy.2.le (by positivity : 0 ≤ c * (s + 1))
      linarith
  have hdecr : AntitoneOn (fun y : ℝ => y ^ s * (1 - c * y)) (Icc z 1) := by
    apply antitoneOn_of_deriv_nonpos (convex_Icc _ _) hcont.continuousOn
    · intro y hy
      rw [interior_Icc] at hy
      exact (degreeOneNumerator_hasDerivAt (hz.trans hy.1)).differentiableAt.differentiableWithinAt
    · intro y hy
      rw [interior_Icc] at hy
      rw [(degreeOneNumerator_hasDerivAt (hz.trans hy.1)).deriv]
      apply mul_nonpos_of_nonneg_of_nonpos (Real.rpow_nonneg (hz.trans hy.1).le _)
      have h := mul_le_mul_of_nonneg_left hy.1.le (by positivity : 0 ≤ c * (s + 1))
      linarith
  rw [← degreeOneNumerator_at_critical hs hc0]
  change _ ≤ z ^ s * (1 - c * z)
  rcases le_total x z with hxz | hzx
  · exact hincr ⟨hx.1, hxz⟩ ⟨hz.le, le_rfl⟩ hxz
  · exact hdecr ⟨le_rfl, hz1.le⟩ ⟨hzx, hx.2⟩ hzx

theorem degreeOneProfile_completed {s q : ℝ} (hs : 0 < s)
    (hq : 0 < q) (hq1 : q < 1) :
    ∃ c : ℝ, s / (1 + s) < c ∧ c < 1 ∧
      degreeOneBoundary s c = q ∧
      0 < degreeOneNormalizer s c ∧
      degreeOneProfile s c 0 = 0 ∧ degreeOneProfile s c 1 = q ∧
      degreeOneProfile s c (s / (c * (1 + s))) = 1 ∧
      ∀ x ∈ Icc (0 : ℝ) 1, 0 ≤ degreeOneProfile s c x ∧ degreeOneProfile s c x ≤ 1 := by
  obtain ⟨c, hc, _⟩ := degreeOneBoundary_existsUnique hs hq hq1
  have hc0 : 0 < c := (div_pos hs (by positivity)).trans hc.1.1
  have hn : 0 < degreeOneNormalizer s c := by unfold degreeOneNormalizer; positivity
  refine ⟨c, hc.1.1, hc.1.2, hc.2, hn, ?_, ?_, ?_, ?_⟩
  · simp [degreeOneProfile, Real.zero_rpow hs.ne']
  · rw [degreeOneProfile, Real.one_rpow, one_mul, mul_one]
    unfold degreeOneNormalizer
    rw [div_div_eq_mul_div]
    simpa only [degreeOneBoundary, mul_assoc] using hc.2
  · rw [degreeOneProfile, degreeOneNumerator_at_critical hs hc0, div_self hn.ne']
  · intro x hx
    constructor
    · unfold degreeOneProfile
      apply div_nonneg (mul_nonneg (Real.rpow_nonneg hx.1 _) _) hn.le
      nlinarith [mul_le_mul_of_nonneg_left hx.2 hc0.le, hc.1.2]
    · exact (div_le_one hn).2 (degreeOneNumerator_max hs hc.1.1 hx)

theorem degreeOneNormalizer_bounds {s c : ℝ} (hs : 0 < s) (hs1 : s ≤ 1)
    (hc : s / (1 + s) < c) (hc1 : c < 1) :
    1 / 4 ≤ degreeOneNormalizer s c ∧ degreeOneNormalizer s c ≤ 1 := by
  have h1 : 0 < 1 + s := by positivity
  have hc0 : 0 < c := (div_pos hs h1).trans hc
  have hpow := Real.self_le_rpow_of_le_one (by norm_num : (0:ℝ) ≤ 1/2)
    (by norm_num : (1/2:ℝ) ≤ 1) hs1
  have hmax := degreeOneNumerator_max hs hc (show (1/2:ℝ) ∈ Icc (0:ℝ) 1 by norm_num)
  have hprod := mul_le_mul_of_nonneg_right hpow (by linarith : 0 ≤ 1 - c * (1/2))
  constructor
  · nlinarith
  · let z := s / (c * (1 + s))
    have hz : 0 < z := by dsimp [z]; positivity
    have hz1 : z < 1 := by
      dsimp [z]
      apply (div_lt_one (mul_pos hc0 h1)).2
      exact (div_lt_iff₀ h1).mp hc
    rw [← degreeOneNumerator_at_critical hs hc0]
    change z ^ s * (1 - c * z) ≤ 1
    have hp := Real.rpow_le_one hz.le hz1.le hs.le
    have hpos : 0 ≤ 1 - c * z := by nlinarith [mul_le_mul_of_nonneg_left hz1.le hc0.le]
    exact mul_le_one₀ hp hpos (by nlinarith [mul_pos hc0 hz])

theorem degreeOneBoundary_mul_normalizer {s c : ℝ} (hs : 0 < s) (hc : 0 < c) :
    degreeOneBoundary s c * degreeOneNormalizer s c = 1 - c := by
  have h1 : 0 < 1 + s := by positivity
  have hsP := (Real.rpow_pos_of_pos hs s).ne'
  have hcP := (Real.rpow_pos_of_pos hc s).ne'
  have h1P := (Real.rpow_pos_of_pos h1 (1+s)).ne'
  unfold degreeOneBoundary degreeOneNormalizer
  field_simp

/-- The chosen coefficient stays in an explicit positive compact interval. -/
theorem degreeOneCoefficient_uniform_bounds {s c q : ℝ} (hs : 0 < s) (hs1 : s ≤ 1)
    (hc : c ∈ Ioo (s / (1 + s)) 1) (hq : 0 < q)
    (heq : degreeOneBoundary s c = q) :
    1 - q ≤ c ∧ c ≤ 1 - q / 4 := by
  have hc0 : 0 < c := (div_pos hs (by positivity)).trans hc.1
  have hn := degreeOneNormalizer_bounds hs hs1 hc.1 hc.2
  have hid := degreeOneBoundary_mul_normalizer hs hc0
  rw [heq] at hid
  constructor <;> nlinarith

theorem degreeOneNormalizer_log {s c : ℝ} (hs : 0 < s) (hc : 0 < c) :
    Real.log (degreeOneNormalizer s c) =
      s * Real.log s - s * Real.log c - (1 + s) * Real.log (1 + s) := by
  have h1 : 0 < 1 + s := by positivity
  unfold degreeOneNormalizer
  rw [Real.log_div (Real.rpow_pos_of_pos hs _).ne'
    (mul_pos (Real.rpow_pos_of_pos hc _) (Real.rpow_pos_of_pos h1 _)).ne',
    Real.log_mul (Real.rpow_pos_of_pos hc _).ne' (Real.rpow_pos_of_pos h1 _).ne',
    Real.log_rpow hs, Real.log_rpow hc, Real.log_rpow h1]
  ring

/-- The sharp normalizer preserves exp(O(s)) precision at the endpoint. -/
theorem degreeOneNormalizer_sharp {s c q : ℝ} (hs : 0 < s) (hs1 : s ≤ 1)
    (hc : c ∈ Ioo (s / (1 + s)) 1) (hq : 0 < q) (hq1 : q < 1)
    (heq : degreeOneBoundary s c = q) :
    s ^ s * Real.exp (-2 * s) ≤ degreeOneNormalizer s c ∧
    degreeOneNormalizer s c ≤ s ^ s * Real.exp (-Real.log (1 - q) * s) := by
  have hc0 : 0 < c := (div_pos hs (by positivity)).trans hc.1
  have hn : 0 < degreeOneNormalizer s c := by unfold degreeOneNormalizer; positivity
  have hlog := degreeOneNormalizer_log hs hc0
  have h1 : 0 < 1 + s := by positivity
  have hl1 := Real.log_le_sub_one_of_pos h1
  have hl10 : 0 ≤ Real.log (1 + s) := Real.log_nonneg (by linarith)
  have hlc : Real.log c ≤ 0 := Real.log_nonpos hc0.le hc.2.le
  have hlog1 : (1 + s) * Real.log (1 + s) ≤ 2 * s := by
    have h := mul_le_mul_of_nonneg_left hl1 h1.le
    nlinarith
  have hcoef := (degreeOneCoefficient_uniform_bounds hs hs1 hc hq heq).1
  have hlclo : Real.log (1 - q) ≤ Real.log c := Real.log_le_log (by linarith) hcoef
  constructor
  · have h := Real.exp_le_exp.mpr (show s * Real.log s - 2 * s ≤ Real.log (degreeOneNormalizer s c) by nlinarith)
    rw [Real.exp_log hn, Real.exp_sub] at h
    rw [Real.rpow_def_of_pos hs, neg_mul, Real.exp_neg]
    simpa only [mul_comm, div_eq_mul_inv] using h
  · have h := Real.exp_le_exp.mpr (show Real.log (degreeOneNormalizer s c) ≤
        s * Real.log s - Real.log (1 - q) * s by nlinarith)
    rw [Real.exp_log hn, Real.exp_sub] at h
    rw [Real.rpow_def_of_pos hs, neg_mul, Real.exp_neg]
    simpa only [mul_comm, div_eq_mul_inv] using h

theorem degreeOneProfile_factor {s c : ℝ} (hs : 0 < s) (hc : 0 < c)
    {x : ℝ} (hx : 0 ≤ x) :
    degreeOneProfile s c x = (c * x / s) ^ s * (1 + s) ^ (1 + s) * (1 - c * x) := by
  unfold degreeOneProfile degreeOneNormalizer
  rw [Real.div_rpow (mul_nonneg hc.le hx) hs.le, Real.mul_rpow hc.le hx,
    div_div_eq_mul_div]
  ring

theorem degreeOneProfile_power_upper {s c q : ℝ} (hs : 0 < s) (hs1 : s ≤ 1)
    (hc : c ∈ Ioo (s / (1 + s)) 1) (hq : 0 < q) (hq1 : q < 1)
    (heq : degreeOneBoundary s c = q) {x : ℝ} (hx : x ∈ Icc (0 : ℝ) 1) :
    degreeOneProfile s c x ≤ Real.exp (2 * s) * (x / s) ^ s := by
  have hc0 : 0 < c := (div_pos hs (by positivity)).trans hc.1
  have hn : 0 < degreeOneNormalizer s c := by unfold degreeOneNormalizer; positivity
  have hlower := (degreeOneNormalizer_sharp hs hs1 hc hq hq1 heq).1
  unfold degreeOneProfile
  apply (div_le_iff₀ hn).2
  calc
    x ^ s * (1 - c * x) ≤ x ^ s := by
      have := mul_nonneg hc0.le hx.1
      nlinarith [Real.rpow_nonneg hx.1 s]
    _ = (Real.exp (2 * s) * (x / s) ^ s) * (s ^ s * Real.exp (-2 * s)) := by
      rw [Real.div_rpow hx.1 hs.le, show -2 * s = -(2 * s) by ring, Real.exp_neg]
      field_simp
    _ ≤ _ := mul_le_mul_of_nonneg_left hlower (mul_nonneg (Real.exp_pos _).le (Real.rpow_nonneg (div_nonneg hx.1 hs.le) _))

theorem degreeOneProfile_local_lower {s c : ℝ} (hs : 0 < s) (hc : 0 < c)
    {x : ℝ} (hx : 0 ≤ x) (hxcrit : x ≤ s / (c * (1 + s))) :
    (c * x / s) ^ s ≤ degreeOneProfile s c x := by
  have h1 : 0 < 1 + s := by positivity
  have hxmul := (le_div_iff₀ (mul_pos hc h1)).mp hxcrit
  have hcx : (1 + s) * (1 - c * x) ≥ 1 := by nlinarith
  have hlin : 0 ≤ 1 - c * x := by nlinarith
  have hp : 1 ≤ (1 + s) ^ s := Real.one_le_rpow (by linarith) hs.le
  have hfac : 1 ≤ (1 + s) ^ (1 + s) * (1 - c * x) := by
    rw [Real.rpow_add h1, Real.rpow_one]
    nlinarith [mul_le_mul_of_nonneg_right hp (show 0 ≤ (1 + s) * (1 - c * x) by positivity)]
  rw [degreeOneProfile_factor hs hc hx]
  have h := mul_le_mul_of_nonneg_left hfac (Real.rpow_nonneg (by positivity : 0 ≤ c * x / s) s)
  nlinarith only [h]

theorem degreeOneProfile_tail_floor {s c : ℝ} (hs : 0 < s)
    (hc : c ∈ Ioo (s / (1 + s)) 1) {x : ℝ}
    (hx : x ∈ Icc (s / (c * (1 + s))) 1) :
    degreeOneBoundary s c ≤ degreeOneProfile s c x := by
  have h1 : 0 < 1 + s := by positivity
  have hc0 : 0 < c := (div_pos hs h1).trans hc.1
  let z := s / (c * (1 + s))
  have hz : 0 < z := by dsimp [z]; positivity
  have hz1 : z < 1 := (div_lt_one (mul_pos hc0 h1)).2 ((div_lt_iff₀ h1).mp hc.1)
  have hcrit : c * (s + 1) * z = s := by dsimp [z]; field_simp; ring
  have hcont : Continuous (fun y : ℝ => y ^ s * (1 - c * y)) :=
    (Real.continuous_rpow_const hs.le).mul
      (continuous_const.sub (continuous_const.mul continuous_id))
  have hdecr : AntitoneOn (fun y : ℝ => y ^ s * (1 - c * y)) (Icc z 1) := by
    apply antitoneOn_of_deriv_nonpos (convex_Icc _ _) hcont.continuousOn
    · intro y hy
      rw [interior_Icc] at hy
      exact (degreeOneNumerator_hasDerivAt (hz.trans hy.1)).differentiableAt.differentiableWithinAt
    · intro y hy
      rw [interior_Icc] at hy
      rw [(degreeOneNumerator_hasDerivAt (hz.trans hy.1)).deriv]
      apply mul_nonpos_of_nonneg_of_nonpos (Real.rpow_nonneg (hz.trans hy.1).le _)
      have h := mul_le_mul_of_nonneg_left hy.1.le (by positivity : 0 ≤ c * (s + 1))
      linarith
  have h := hdecr hx ⟨hz1.le, le_rfl⟩ hx.2
  simp only [Real.one_rpow, one_mul, mul_one] at h
  have hn : 0 < degreeOneNormalizer s c := by unfold degreeOneNormalizer; positivity
  have hid := degreeOneBoundary_mul_normalizer hs hc0
  unfold degreeOneProfile
  apply (le_div_iff₀ hn).2
  rwa [hid]

theorem degreeOneProfile_power_lower {s c q : ℝ} (hs : 0 < s) (hs1 : s ≤ 1)
    (hc : c ∈ Ioo (s / (1 + s)) 1) (hq : 0 < q) (hq1 : q < 1)
    (heq : degreeOneBoundary s c = q) {x : ℝ} (hx : x ∈ Icc (0 : ℝ) 1) :
    min q (Real.exp (Real.log (1 - q) * s) * (x / s) ^ s) ≤ degreeOneProfile s c x := by
  have hc0 : 0 < c := (div_pos hs (by positivity)).trans hc.1
  rcases le_total x (s / (c * (1 + s))) with hxcrit | hxcrit
  · apply (min_le_right _ _).trans
    apply le_trans _ (degreeOneProfile_local_lower hs hc0 hx.1 hxcrit)
    have hcmin := (degreeOneCoefficient_uniform_bounds hs hs1 hc hq heq).1
    have hbase : (1 - q) * (x / s) ≤ c * x / s := by
      have h := mul_le_mul_of_nonneg_right hcmin (div_nonneg hx.1 hs.le)
      simpa only [mul_div_assoc] using h
    have h := Real.rpow_le_rpow (mul_nonneg (by linarith : 0 ≤ 1 - q) (div_nonneg hx.1 hs.le)) hbase hs.le
    rw [Real.mul_rpow (by linarith) (div_nonneg hx.1 hs.le),
      Real.rpow_def_of_pos (by linarith : 0 < 1 - q)] at h
    exact h
  · apply (min_le_left _ _).trans
    rw [← heq]
    exact degreeOneProfile_tail_floor hs hc ⟨hxcrit, hx.2⟩

theorem log_add_two_le_linear {v d : ℝ} (hv : 0 < v) (hd : 0 < d)
    (hscale : 16 / d ^ 2 ≤ v) : Real.log v + 2 ≤ d * v / 2 := by
  have hr : 0 < Real.sqrt v := Real.sqrt_pos.mpr hv
  have hlog := Real.log_le_sub_one_of_pos hr
  rw [Real.log_sqrt hv.le] at hlog
  have hscaled : 16 ≤ d ^ 2 * v := by
    have h := (div_le_iff₀ (sq_pos_of_pos hd)).mp hscale
    nlinarith only [h]
  have hroot : 4 ≤ d * Real.sqrt v := by
    have hs := Real.sq_sqrt hv.le
    have hmul : 16 ≤ (d * Real.sqrt v) ^ 2 := by nlinarith [sq_nonneg d]
    nlinarith [mul_pos hd hr]
  have h := mul_le_mul_of_nonneg_right hroot hr.le
  have hs := Real.sq_sqrt hv.le
  nlinarith

theorem exp_half_mul_complement_le {z : ℝ} (hz : 0 ≤ z) (hz1 : z ≤ 1) :
    Real.exp (z / 2) * (1 - z) ≤ 1 - z / 2 := by
  have hd : 0 < 1 - z / 2 := by linarith
  have he := Real.exp_bound_div_one_sub_of_interval (by linarith : 0 ≤ z / 2)
    (by linarith : z / 2 < 1)
  calc
    Real.exp (z / 2) * (1 - z) ≤ (1 / (1 - z / 2)) * (1 - z) :=
      mul_le_mul_of_nonneg_right he (by linarith)
    _ = (1 - z) / (1 - z / 2) := by ring
    _ ≤ 1 - z / 2 := (div_le_iff₀ hd).2 (by nlinarith [sq_nonneg z])

/-- An explicit fixed deficit away from the degree-one maximum. -/
theorem degreeOneProfile_deficit {s c q : ℝ} (hs : 0 < s) (hs1 : s ≤ 1)
    (hc : c ∈ Ioo (s / (1 + s)) 1) (hq : 0 < q) (hq1 : q < 1)
    (heq : degreeOneBoundary s c = q) {x : ℝ} (hx : x ∈ Icc (0 : ℝ) 1)
    (haway : (16 / (1 - q) ^ 2) * s ≤ x) :
    ((1 - q) / 2) * x ≤ 1 - degreeOneProfile s c x := by
  have hd : 0 < 1 - q := by linarith
  have hc0 : 0 < c := (div_pos hs (by positivity)).trans hc.1
  have hx0 : 0 < x := (mul_pos (div_pos (by norm_num) (sq_pos_of_pos hd)) hs).trans_le haway
  have hcx : 0 ≤ c * x := mul_nonneg hc0.le hx.1
  have hcx1 : c * x ≤ 1 := by nlinarith [mul_le_mul_of_nonneg_left hx.2 hc0.le, hc.2]
  have hd_c := (degreeOneCoefficient_uniform_bounds hs hs1 hc hq heq).1
  have hscale : 16 / (1 - q) ^ 2 ≤ x / s := (le_div_iff₀ hs).2 haway
  have hlog := log_add_two_le_linear (div_pos hx0 hs) hd hscale
  have hexponent : s * Real.log (x / s) + 2 * s ≤ c * x / 2 := by
    have h := mul_le_mul_of_nonneg_left hlog hs.le
    have hid : s * ((1 - q) * (x / s) / 2) = (1 - q) * x / 2 := by field_simp
    rw [hid] at h
    have hcx' := mul_le_mul_of_nonneg_right hd_c hx.1
    nlinarith
  have hlower := (degreeOneNormalizer_sharp hs hs1 hc hq hq1 heq).1
  have hlow0 : 0 < s ^ s * Real.exp (-2 * s) := by positivity
  have hnum : 0 ≤ x ^ s * (1 - c * x) := mul_nonneg (Real.rpow_nonneg hx.1 _) (by linarith)
  have hupper : degreeOneProfile s c x ≤ Real.exp (s * Real.log (x / s) + 2 * s) * (1 - c * x) := by
    unfold degreeOneProfile
    calc
      x ^ s * (1 - c * x) / degreeOneNormalizer s c ≤
          x ^ s * (1 - c * x) / (s ^ s * Real.exp (-2 * s)) :=
        div_le_div_of_nonneg_left hnum hlow0 hlower
      _ = _ := by
        rw [Real.exp_add, show s * Real.log (x / s) = Real.log (x / s) * s by ring,
          ← Real.rpow_def_of_pos (div_pos hx0 hs), Real.div_rpow hx.1 hs.le,
          show -2 * s = -(2 * s) by ring, Real.exp_neg]
        field_simp
  have hexp := mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr hexponent) (by linarith : 0 ≤ 1 - c * x)
  have hbound := hupper.trans (hexp.trans (exp_half_mul_complement_le hcx hcx1))
  have hcx' := mul_le_mul_of_nonneg_right hd_c hx.1
  nlinarith

end Renyi
