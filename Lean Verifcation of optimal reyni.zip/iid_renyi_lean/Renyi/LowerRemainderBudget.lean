import Renyi.LowerDefectBudget

/-! The Taylor remainder at the common support and intensity scale. -/
noncomputable section
namespace Renyi

/-- Explicit logarithmic size of the chosen lower sample constant. -/
theorem lower_actual_log_sample_bound {ε : ℝ} (hε : 0<ε) :
    Real.log (lowerPriorIntensityConstant ε)≤ -1000-26/lowerPriorCoefficient ε := by
  let c := lowerPriorCoefficient ε
  have hc : 0<c := (lowerPriorCoefficient_bounds hε).1
  have hd : 0<1-Real.exp (-ε) := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith))
  have hC : lowerVelocityConstant ε c=41/4 := by
    dsimp [lowerVelocityConstant,c,lowerPriorCoefficient]
    field_simp
    ring
  have hdC : 4*c/(1-Real.exp (-ε))=1/4 := by
    dsimp [c,lowerPriorCoefficient]
    field_simp
    ring
  unfold lowerPriorIntensityConstant
  rw [Real.log_exp]
  change lowerLogSampleConstant ε c≤ -1000-26/c
  unfold lowerLogSampleConstant lowerPrincipalMargin
  rw [hC,hdC]
  field_simp
  nlinarith

/-- The common small sample constant absorbs both power-mean envelopes. -/
theorem lower_remainder_prefactor {c cn α r : ℝ}
    (hc : 0<c) (hcn : 0<cn) (hα : 3/2≤α) (hr : r≤α+1/2)
    (hlogcn : Real.log cn≤ -1000-26/c) :
    (12/c)*cn^(α-1/2)*Real.exp ((20+2/c)*r)*10^α≤1 := by
  have hαpos : 0<α-1/2 := by linarith
  have hlogc : -Real.log c≤1/c := by
    have hh := Real.one_sub_inv_le_log_of_pos hc
    rw [←one_div] at hh
    linarith
  have hlog12 : Real.log (12:ℝ)≤11 := by
    have hh := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<12)
    norm_num at hh
    exact hh
  have hlog10 : Real.log (10:ℝ)≤9 := by
    have hh := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<10)
    norm_num at hh
    exact hh
  have hprod := mul_le_mul_of_nonneg_left hlogcn hαpos.le
  have hrprod := mul_le_mul_of_nonneg_left hr (show 0≤20+2/c by positivity)
  have hten := mul_le_mul_of_nonneg_left hlog10 (show 0≤α by linarith)
  have hi : 0<1/c := by positivity
  have hαi := mul_le_mul_of_nonneg_right hα hi.le
  have hpos : 0<(12/c)*cn^(α-1/2)*Real.exp ((20+2/c)*r)*10^α := by positivity
  suffices hh : Real.log ((12/c)*cn^(α-1/2)*Real.exp ((20+2/c)*r)*10^α)≤0 by
    simpa only [Real.exp_zero] using (Real.log_le_iff_le_exp hpos).mp hh
  rw [Real.log_mul (by positivity) (by positivity),
    Real.log_mul (by positivity) (Real.exp_pos _).ne',
    Real.log_mul (by positivity) (Real.rpow_pos_of_pos hcn _).ne',
    Real.log_div (by norm_num : (12:ℝ)≠0) hc.ne',Real.log_rpow hcn,Real.log_exp,
    Real.log_rpow (by norm_num : (0:ℝ)<10)]
  rw [show 26/c=26*(1/c) by ring] at hprod
  rw [show 2/c=2*(1/c) by ring] at hrprod ⊢
  nlinarith only [hlog12,hlogc,hprod,hrprod,hten,hi,hαi,hα]

/-- The logarithmic degree alone controls the geometric Taylor tail. -/
theorem lower_log_degree_tail {x α : ℝ} {L : ℕ}
    (hx : 1≤x) (hα : 0≤α) (hL : 10*α*(1+Real.log x)≤L) :
    x^(2*α)*(1/16:ℝ)^(L+2)≤1/256 := by
  have hx0 : 0<x := lt_of_lt_of_le zero_lt_one hx
  have hlx : 0≤Real.log x := Real.log_nonneg hx
  have hexponent : 2*α*Real.log x≤L := by nlinarith [mul_nonneg hα hlx]
  have he1 : Real.exp 1≤16 := (le_of_lt (Real.exp_one_lt_d9.trans (by norm_num)))
  have hpower : x^(2*α)≤(16:ℝ)^L := by
    calc
      _=Real.exp (2*α*Real.log x) := by rw [Real.rpow_def_of_pos hx0]; congr 1; ring
      _≤Real.exp (L:ℝ) := Real.exp_le_exp.mpr hexponent
      _=(Real.exp 1)^L := by rw [←Real.exp_nat_mul]; congr 1; ring
      _≤(16:ℝ)^L := pow_le_pow_left₀ (Real.exp_nonneg _) he1 L
  have hh := mul_le_mul_of_nonneg_right hpower (show 0≤(1/16:ℝ)^(L+2) by positivity)
  apply hh.trans_eq
  rw [pow_add,div_pow,one_pow]
  field_simp
  norm_num

/-- At the common support/intensity product the entire Taylor remainder,
including both actual power means, is at most 1/256. -/
theorem lower_remainder_term_budget {k α x cn c ζ A₀ A₁ r : ℝ} {L : ℕ}
    (hk : 0<k) (hα : 3/2≤α) (hx : 1≤x) (hcn : 0<cn) (hc : 0<c)
    (hr : r≤α+1/2) (hL : 10*α*(1+Real.log x)≤L)
    (hlogcn : Real.log cn≤ -1000-26/c)
    (hζfloor : (c/3)*x^(-α)≤ζ)
    (_hA₀ : 0≤A₀) (_hA₁ : 0≤A₁)
    (hmean₀ : A₀≤cn^(-1/2:ℝ)*Real.exp ((20+2/c)*r)/ζ)
    (hmean₁ : A₁≤cn^(-1/2:ℝ)*Real.exp ((20+2/c)*r)/ζ) :
    let θ := cn*α*k^(-1/α)*x
    let B := (1/100)*(L:ℝ)/θ
    k*2*(A₁+A₀)*B^(-α)*(2*Real.exp 1*θ*B/(L+2:ℕ))^(L+2)≤1/256 := by
  let θ := cn*α*k^(-1/α)*x
  let B := (1/100)*(L:ℝ)/θ
  have hα0 : 0<α := by linarith
  have hx0 : 0<x := lt_of_lt_of_le zero_lt_one hx
  have hlx : 0≤Real.log x := Real.log_nonneg hx
  have hLα : 10*α≤L := by nlinarith [mul_nonneg hα0.le hlx]
  have hL0 : (0:ℝ)<L := (show 0<10*α by positivity).trans_le hLα
  have hθ : 0<θ := by dsimp [θ]; positivity
  have hB : 0<B := by dsimp [B]; positivity
  have hζ : 0<ζ := lt_of_lt_of_le (by positivity) hζfloor
  have hζinv : 1/ζ≤(3/c)*x^α := by
    calc
      _≤1/((c/3)*x^(-α)) := one_div_le_one_div_of_le (by positivity) hζfloor
      _=_ := by rw [Real.rpow_neg hx0.le]; field_simp
  have hBscale : k*B^(-α)=(cn*α/((1/100)*(L:ℝ)))^α*x^α :=
    lower_remainder_scale_identity hk hα0 hx0 hcn (by norm_num) hL0
  have hratio : cn*α/((1/100)*(L:ℝ))≤10*cn := by
    apply (div_le_iff₀ (by positivity : (0:ℝ)<(1/100)*(L:ℝ))).mpr
    have hh := mul_le_mul_of_nonneg_left hLα hcn.le
    nlinarith only [hh]
  have hBbound : k*B^(-α)≤(10*cn)^α*x^α := by
    rw [hBscale]
    exact mul_le_mul_of_nonneg_right (Real.rpow_le_rpow (by positivity) hratio hα0.le)
      (Real.rpow_nonneg hx0.le _)
  have hAadd : A₁+A₀≤2*(cn^(-1/2:ℝ)*Real.exp ((20+2/c)*r)/ζ) := by
    linarith only [hmean₀,hmean₁]
  have hpre : k*2*(A₁+A₀)*B^(-α)≤x^(2*α) := by
    calc
      _=2*(A₁+A₀)*(k*B^(-α)) := by ring
      _≤2*(2*(cn^(-1/2:ℝ)*Real.exp ((20+2/c)*r)/ζ))*((10*cn)^α*x^α) := by gcongr
      _=4*cn^(-1/2:ℝ)*Real.exp ((20+2/c)*r)*(1/ζ)*(10*cn)^α*x^α := by ring
      _≤4*cn^(-1/2:ℝ)*Real.exp ((20+2/c)*r)*((3/c)*x^α)*(10*cn)^α*x^α := by gcongr
      _=((12/c)*cn^(α-1/2)*Real.exp ((20+2/c)*r)*10^α)*x^(2*α) := by
        rw [Real.mul_rpow (by norm_num : (0:ℝ)≤10) hcn.le]
        have hec : cn^(-1/2:ℝ)*cn^α=cn^(α-1/2) := by rw [←Real.rpow_add hcn]; congr 1; ring
        have hex : x^α*x^α=x^(2*α) := by rw [←Real.rpow_add hx0]; congr 1; ring
        calc
          _=(12/c)*(cn^(-1/2:ℝ)*cn^α)*Real.exp ((20+2/c)*r)*10^α*(x^α*x^α) := by ring
          _=_ := by rw [hec,hex]
      _≤1*x^(2*α) := mul_le_mul_of_nonneg_right (lower_remainder_prefactor hc hcn hα hr hlogcn)
        (Real.rpow_nonneg hx0.le _)
      _=x^(2*α) := one_mul _
  have hscale : θ*B=(1/100)*(L:ℝ) := by dsimp [B]; field_simp
  have hM : (0:ℝ)<(L+2:ℕ) := by positivity
  have he1 : Real.exp 1≤3 := le_of_lt (Real.exp_one_lt_d9.trans (by norm_num))
  have hbase : 2*Real.exp 1*θ*B/(L+2:ℕ)≤1/16 := by
    apply (div_le_iff₀ hM).mpr
    have hh := mul_le_mul_of_nonneg_right he1 hL0.le
    have hid : 2*Real.exp 1*θ*B=2*Real.exp 1*((1/100)*(L:ℝ)) := by rw [←hscale]; ring
    rw [hid]
    push_cast
    nlinarith only [hh]
  change k*2*(A₁+A₀)*B^(-α)*(2*Real.exp 1*θ*B/(L+2:ℕ))^(L+2)≤_
  calc
    _≤x^(2*α)*(1/16:ℝ)^(L+2) := by gcongr
    _≤1/256 := lower_log_degree_tail hx hα0.le hL

end Renyi
