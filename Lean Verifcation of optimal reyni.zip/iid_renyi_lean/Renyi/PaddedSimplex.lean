import Renyi.Model

/-! Padding a normalized finite weight vector on an injectively labeled alphabet. -/
noncomputable section
open scoped BigOperators
namespace Renyi

def paddedWeight {Q k : ℕ} (e : Fin Q ↪ Fin k) (w : Fin Q → ℝ) (j : Fin k) : ℝ :=
  ∑ i, if e i = j then w i else 0

@[simp] theorem paddedWeight_at {Q k : ℕ} (e : Fin Q ↪ Fin k)
    (w : Fin Q → ℝ) (i : Fin Q) : paddedWeight e w (e i) = w i := by
  simp [paddedWeight, e.injective.eq_iff]

theorem paddedWeight_off {Q k : ℕ} (e : Fin Q ↪ Fin k)
    (w : Fin Q → ℝ) {j : Fin k} (hj : ¬ ∃ i, e i = j) : paddedWeight e w j = 0 := by
  simp only [paddedWeight]
  apply Finset.sum_eq_zero
  intro i _
  exact if_neg (fun h => hj ⟨i, h⟩)

theorem paddedWeight_nonneg {Q k : ℕ} (e : Fin Q ↪ Fin k)
    (w : Fin Q → ℝ) (hw : ∀ i, 0 ≤ w i) (j : Fin k) : 0 ≤ paddedWeight e w j := by
  apply Finset.sum_nonneg
  intro i _
  split_ifs
  · exact hw i
  · exact le_rfl

theorem paddedWeight_sum {Q k : ℕ} (e : Fin Q ↪ Fin k)
    (w : Fin Q → ℝ) : ∑ j, paddedWeight e w j = ∑ i, w i := by
  simp only [paddedWeight]
  rw [Finset.sum_comm]
  simp

theorem paddedWeight_sum_map {Q k : ℕ} (e : Fin Q ↪ Fin k)
    (w : Fin Q → ℝ) (f : ℝ → ℝ) (hf : f 0 = 0) :
    ∑ j, f (paddedWeight e w j) = ∑ i, f (w i) := by
  have hterm (j : Fin k) : f (paddedWeight e w j) = paddedWeight e (fun i => f (w i)) j := by
    by_cases hj : ∃ i, e i = j
    · obtain ⟨i, rfl⟩ := hj
      simp
    · rw [paddedWeight_off e w hj, paddedWeight_off e _ hj, hf]
  simp_rw [hterm]
  exact paddedWeight_sum e _

def paddedSimplex {Q k : ℕ} (e : Fin Q ↪ Fin k) (w : Fin Q → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hW : 0 < ∑ i, w i) : Simplex k where
  mass := paddedWeight e (fun i => w i / ∑ j, w j)
  nonneg := paddedWeight_nonneg e _ (fun i => div_nonneg (hw i) hW.le)
  normalized := by
    rw [paddedWeight_sum, ← Finset.sum_div]
    exact div_self (ne_of_gt hW)

@[simp] theorem paddedSimplex_mass_at {Q k : ℕ} (e : Fin Q ↪ Fin k)
    (w : Fin Q → ℝ) (hw : ∀ i, 0 ≤ w i) (hW : 0 < ∑ i, w i) (i : Fin Q) :
    (paddedSimplex e w hw hW).mass (e i) = w i / ∑ j, w j :=
  paddedWeight_at e _ i

theorem paddedSimplex_powerSum {Q k : ℕ} (e : Fin Q ↪ Fin k)
    (w : Fin Q → ℝ) (hw : ∀ i, 0 ≤ w i) (hW : 0 < ∑ i, w i)
    {a : ℝ} (ha : a ≠ 0) :
    powerSum (paddedSimplex e w hw hW) a = (∑ i, w i ^ a) / (∑ i, w i) ^ a := by
  unfold powerSum paddedSimplex
  rw [paddedWeight_sum_map e _ (fun x => x ^ a) (Real.zero_rpow ha)]
  simp_rw [Real.div_rpow (hw _) hW.le]
  exact (Finset.sum_div _ _ _).symm

theorem paddedSimplex_entropy {Q k : ℕ} (e : Fin Q ↪ Fin k)
    (w : Fin Q → ℝ) (hw : ∀ i, 0 ≤ w i) (hW : 0 < ∑ i, w i)
    {a : ℝ} (ha : a ≠ 0) :
    entropy (paddedSimplex e w hw hW) a =
      entropyFromPower (a - 1) ((∑ i, w i ^ a) / (∑ i, w i) ^ a) := by
  unfold entropy
  rw [paddedSimplex_powerSum e w hw hW ha]

end Renyi
