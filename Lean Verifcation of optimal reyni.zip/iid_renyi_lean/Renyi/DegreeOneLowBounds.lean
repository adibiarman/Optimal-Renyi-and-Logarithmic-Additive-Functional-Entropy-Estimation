import Renyi.CoupledGlobalUpper
import Renyi.DegreeOneProfile

/-! Actual degree-one low profile bounds for the deterministic coupled certificate. -/
noncomputable section
open Set
namespace Renyi
namespace DegreeOneCompletion

/-- Harmless extension at floor zero; positive source floors are unchanged. -/
def completionFloor (f : ℝ) : ℝ := if 0<f ∧ f<1 then f else 1/2

lemma completionFloor_pos {f : ℝ} : 0<completionFloor f := by
  unfold completionFloor
  split
  · exact ‹0<f ∧ f<1›.1
  · norm_num

lemma completionFloor_lt_one {f : ℝ} : completionFloor f<1 := by
  unfold completionFloor
  split
  · exact ‹0<f ∧ f<1›.2
  · norm_num

/-- The uniquely specified coefficient of the source degree-one completion. -/
def coefficient (s f : ℝ) : ℝ :=
  if h : 0<s ∧ completionFloor f<1 then
    Classical.choose (degreeOneBoundary_existsUnique h.1 completionFloor_pos h.2)
  else 0

theorem coefficient_spec {s f : ℝ} (hs : 0<s) (_hf1 : f<1) :
    coefficient s f ∈ Ioo (s/(1+s)) 1 ∧
      degreeOneBoundary s (coefficient s f)=completionFloor f := by
  have h : 0<s ∧ completionFloor f<1 := ⟨hs,completionFloor_lt_one⟩
  simp only [coefficient,dif_pos h]
  exact (Classical.choose_spec (degreeOneBoundary_existsUnique h.1 completionFloor_pos h.2)).1

theorem coefficient_pos {s f : ℝ} (hs : 0<s) (hf1 : f<1) : 0<coefficient s f :=
  (div_pos hs (by positivity)).trans (coefficient_spec hs hf1).1.1

/-- This family is independent of the auxiliary low-degree index. -/
def lowProfile (_N : ℕ) (s f x : ℝ) : ℝ := degreeOneProfile s (coefficient s f) x

theorem lowProfile_range {N : ℕ} (_hN : 0<N) {s f x : ℝ} (hs : 0<s)
    (_hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1) :
    0≤lowProfile N s f x ∧ lowProfile N s f x≤1 := by
  have hc := coefficient_spec hs hf1
  have hc0 := coefficient_pos hs hf1
  have hn : 0<degreeOneNormalizer s (coefficient s f) := by unfold degreeOneNormalizer;positivity
  constructor
  · unfold lowProfile degreeOneProfile
    apply div_nonneg (mul_nonneg (Real.rpow_nonneg hx _) _) hn.le
    nlinarith only [mul_le_mul_of_nonneg_left hx1 hc0.le,hc.1.2]
  · exact (div_le_one hn).mpr (degreeOneNumerator_max hs hc.1.1 ⟨hx,hx1⟩)

theorem lowProfile_upper_power {N : ℕ} (_hN : 0<N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (_hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1) :
    lowProfile N s f x≤Real.exp (coupledProfileConstant*s)*(x/s)^s := by
  have hc := coefficient_spec hs hf1
  have hp := degreeOneProfile_power_upper hs hs1 hc.1 completionFloor_pos
    (completionFloor_lt_one) hc.2 ⟨hx,hx1⟩
  apply hp.trans
  apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg (div_nonneg hx hs.le) s)
  apply Real.exp_le_exp.mpr
  have hC : 2≤coupledProfileConstant := by
    unfold coupledProfileConstant
    have := Real.log_nonneg (by norm_num : (1:ℝ)≤24)
    linarith only [this]
  exact mul_le_mul_of_nonneg_right hC hs.le

def lowProfileLinearConstant (f : ℝ) : ℝ :=
  min (completionFloor f) (1-completionFloor f)

theorem lowProfileLinearConstant_pos {f : ℝ} (_hf : 0<f) :
    0<lowProfileLinearConstant f :=
  lt_min completionFloor_pos (sub_pos.mpr (completionFloor_lt_one))

theorem lowProfile_min_linear_lower {N : ℕ} (_hN : 2≤N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (_hf : 0<f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1) :
    lowProfileLinearConstant f*min x 1≤lowProfile N s f x := by
  have hc := coefficient_spec hs hf1
  have hq0 : 0<completionFloor f := completionFloor_pos
  have hq1 := completionFloor_lt_one (f:=f)
  have hC : 0≤ -Real.log (1-completionFloor f) :=
    neg_nonneg.mpr (Real.log_nonpos (by linarith only [hq1]) (by linarith only [hq0]))
  have hh := fractional_power_min_linear hs hs1 hx hC hq0
  simp only [neg_neg,Real.exp_log (by linarith only [hq1] : 0<1-completionFloor f)] at hh
  have hp := degreeOneProfile_power_lower hs hs1 hc.1 hq0 hq1 hc.2 ⟨hx,hx1⟩
  exact hh.trans hp

def deficitOrder (_f : ℝ) : ℝ := 1

def deficitScale (f : ℝ) : ℝ := max 1 (16/(1-completionFloor f)^2)

def deficitConstant (f : ℝ) : ℝ := (1-completionFloor f)/2

theorem deficitOrder_pos {f : ℝ} (_hf : 0≤f) (_hf1 : f<1) : 0<deficitOrder f := by
  norm_num [deficitOrder]

theorem deficitConstant_pos {f : ℝ} (_hf1 : f<1) : 0<deficitConstant f := by
  have hh := completionFloor_lt_one (f:=f)
  dsimp [deficitConstant]
  linarith only [hh]

theorem lowProfile_deficit {N : ℕ} (_hN : 2≤N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (_hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1)
    (_hsmall : s≤deficitOrder f) (hscale : deficitScale f*s≤x) :
    deficitConstant f*min x 1≤1-lowProfile N s f x := by
  have hc := coefficient_spec hs hf1
  have hthreshold : 16/(1-completionFloor f)^2*s≤x := by
    have hh := mul_le_mul_of_nonneg_right (le_max_right 1 (16/(1-completionFloor f)^2)) hs.le
    dsimp [deficitScale] at hscale
    exact hh.trans hscale
  rw [min_eq_left hx1]
  exact degreeOneProfile_deficit hs hs1 hc.1 completionFloor_pos
    (completionFloor_lt_one) hc.2 ⟨hx,hx1⟩ hthreshold

end DegreeOneCompletion
end Renyi
