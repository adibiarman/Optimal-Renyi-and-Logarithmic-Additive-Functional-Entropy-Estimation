import Renyi.NearOneActualBias
import Renyi.NearOnePolynomial

/-! The actual near-one polynomial, with all prescribed root and overlap parameters. -/
noncomputable section
open Polynomial
namespace Renyi

def actualNearOnePolynomial (k N : ℕ) (alpha eps Ch D cb lambda CL cL c M cw f s0 : ℝ) : ℝ[X] :=
  Polynomial.C s0 * nearOneCoupledPolynomial N (alpha-1)
    (c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))
    (upperB k alpha eps D cb CL cL) f (upperOmega k alpha eps Ch cw)
    (overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*
      Real.exp (-M*(alpha-1)))
    (overlapB (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*
      Real.exp (-M*(2-alpha)))

theorem nearOneCoupledPolynomial_eval_expression {N : ℕ} (hN : 0<N)
    {β τ b f ω A B s0 p : ℝ} (hβ : 0<β) (hβ1 : β<1) (hb : 0<b)
    (hp : 0≤p) (hpb : p≤b) :
    s0*(nearOneCoupledPolynomial N β τ b f ω A B).eval p =
      nearOneExpression N τ β f ω A B s0 b p := by
  rw [nearOneCoupledPolynomial_eval hN hβ hβ1 hb hp hpb]
  unfold nearOneExpression tangentPlane
  ring

/-- Exact evaluation bridge to the actual-parameter localized bias theorem. -/
theorem actualNearOnePolynomial_eval {k N : ℕ} (hN : 0<N)
    {alpha eps Ch D cb lambda CL cL c M cw f s0 p : ℝ}
    (halpha : 1<alpha) (halpha1 : alpha≤3/2)
    (hb : 0<upperB k alpha eps D cb CL cL)
    (hp : 0≤p) (hpb : p≤upperB k alpha eps D cb CL cL) :
    (actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f s0).eval p =
      actualNearOneExpression k N alpha eps Ch D cb lambda CL cL c M cw f s0 p := by
  unfold actualNearOnePolynomial actualNearOneExpression
  rw [Polynomial.eval_mul,Polynomial.eval_C]
  exact nearOneCoupledPolynomial_eval_expression hN (by linarith only [halpha])
    (by linarith only [halpha1]) hb hp hpb

/-- Actual parameter substitution preserves the explicit polynomial degree budget. -/
theorem actualNearOnePolynomial_natDegree (k N : ℕ)
    (alpha eps Ch D cb lambda CL cL c M cw f s0 : ℝ) :
    (actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f s0).natDegree ≤
      2+18*(N-1) := by
  unfold actualNearOnePolynomial
  apply natDegree_mul_le.trans
  simpa only [natDegree_C,zero_add] using
    nearOneCoupledPolynomial_natDegree N (alpha-1)
      (c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))
      (upperB k alpha eps D cb CL cL) f (upperOmega k alpha eps Ch cw)
      (overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(alpha-1)))
      (overlapB (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(2-alpha)))

theorem actualNearOnePolynomial_natDegree_le {k N : ℕ} (hN : 0<N)
    (alpha eps Ch D cb lambda CL cL c M cw f s0 : ℝ) :
    (actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f s0).natDegree ≤20*N :=
  (actualNearOnePolynomial_natDegree k N alpha eps Ch D cb lambda CL cL c M cw f s0).trans (by omega)

end Renyi
