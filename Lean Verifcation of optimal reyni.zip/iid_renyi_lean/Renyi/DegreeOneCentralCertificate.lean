import Renyi.DegreeOneCentralLower
import Renyi.DegreeOneCutoff
import Renyi.DegreeOneStrictUpper
import Renyi.CoupledCentralCertificate

/-! Actual canonical degree-one lower certificate. -/
noncomputable section
namespace Renyi.DegreeOneCompletion

def coupledCentralCertificateConstant (fL f M lam0 : ℝ) : ℝ :=
  coupledCentralLoss fL f M lam0+
    Real.exp (Real.log 12+1)*Real.exp (coupledCentralLoss fL f M lam0/4)/endpointCutoffTailConstant

theorem coupledCentralLoss_nonneg {fL f M lam0 : ℝ}
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1)
    (hM : 0≤M) (hlam0 : 0<lam0) (hlam1 : lam0≤1) : 0≤coupledCentralLoss fL f M lam0 := by
  have hCL := degreeOneLocalLowerConstant_nonneg hfL hfL1
  have hCH := coupledLocalLowerConstant_nonneg hf hf1
  have hlog := Real.log_nonpos hlam0.le hlam1
  unfold coupledCentralLoss
  linarith only [hCL,hCH,hlog,hM]

/-- Both cutoff lower mechanisms for the actual reserved base, with actual kernel estimates. -/
theorem coupledProfiles_reserved_cutoff_bounds {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z E M fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hE : 0<E) (hzE : z≤Real.exp (-E)) (hM : 1≤M)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0<y) (hy1 : y≤1) (hY : (N:ℝ)^2*y≤1)
    (hcap : (x)*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    let ω := Real.exp (-E/8)
    let S := coupledReservedBase ℓ N γ z M fL f ω x y
    let R := coupledHighReserve N γ z M f ω y
    let T := coupledDampedExpression ℓ N γ z M ω fL f x y
    S-Real.exp (Real.log 12+1)*Real.exp (-E)*(γ*(1-γ))≤T-R ∧
      endpointCutoffTailConstant*S≤T-R := by
  dsimp only
  let ω := Real.exp (-E/8)
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hM0 : 0≤M := by linarith only [hM]
  have hω : 0≤ω := (Real.exp_pos _).le
  have hω1 : ω<1 := Real.exp_lt_one_iff.mpr (by linarith only [hE])
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range (by omega : 0<ℓ) hγ hfL hfL1 hx hx1
  have hv := highProfile_range (by omega : 0<N) hd hf hf1.le hω hω1 hy.le hy1
  have hH := endpointProfile_range (by omega : 0<N) (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy.le hy1
  have hJ := endpointProfile_range (by omega : 0<N) (by norm_num : 6≤6) hd hy.le hy1
  have hb1 : overlapB γ z*Real.exp (-M*(1-γ))≤1 :=
    (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      (Real.exp_le_one_iff.mpr (by nlinarith only [hM0,hd]))
  constructor
  · have hcut := coupledProfiles_cutoff_lower (ℓ:=ℓ) (fL:=fL) (f:=f) (x:=x) (by omega : 0<N)
      hγ hγ1 hz hz1 hE.le hM hzE hy.le hy1
    dsimp only at hcut
    change (overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ fL x+
      (overlapB γ z*Real.exp (-M*(1-γ)))*highProfile N (1-γ) f ω y-
      max ((overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ fL x-1+overlapB γ z) 0*endpointProfile N 6 1 y≤
      coupledDampedExpression ℓ N γ z M ω fL f x y at hcut
    have hloss := coupledProfiles_cutoff_loss (by omega : 0<ℓ) (by omega : 0<N)
      hγ hγ1 hz hz1 hzE hM0 hfL hfL1 hx hx1 hy hy1 hcap
    unfold coupledReservedBase coupledHighReserve
    nlinarith only [hcut,hloss]
  · have htail := endpointProfile_one_cutoff_tail hN hy.le hy1 hY
    have hS0 : 0≤coupledReservedBase ℓ N γ z M fL f ω x y := by
      unfold coupledReservedBase
      exact add_nonneg (mul_nonneg (mul_nonneg hc.1.le (Real.exp_pos _).le) hu.1)
        (mul_nonneg (mul_nonneg hc.2.2.1.le (Real.exp_pos _).le) hv.1)
    have htailS := mul_le_mul_of_nonneg_right htail hS0
    have hhigh : 0≤(overlapB γ z*Real.exp (-(M+1)*(1-γ)))*
        highProfile N (1-γ) f ω y*endpointProfile N 6 1 y :=
      mul_nonneg (mul_nonneg (mul_nonneg hc.2.2.1.le (Real.exp_pos _).le) hv.1) hH.1
    have hcomp : 0≤ω*(1-overlapB γ z*Real.exp (-M*(1-γ)))*endpointProfile N 6 (1-γ) y :=
      mul_nonneg (mul_nonneg hω (sub_nonneg.mpr hb1)) hJ.1
    unfold coupledDampedExpression coupledReservedBase coupledHighReserve at *
    nlinarith only [htailS,hhigh,hcomp]

/-- Complete actual central lower bound, retaining the linear forward gain after cutoff losses. -/
theorem coupledProfiles_central_lower_certificate {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z E Emin lam0 M fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hEmin : 0<Emin) (hEE : Emin≤E) (hG : overlapG γ z=Real.exp (-E))
    (hlam0 : 0<lam0) (hlam1 : lam0≤1) (hM : 1≤M)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0<y) (hy1 : y≤1)
    (hZ : x≤γ) (hY : (N:ℝ)^2*y≤1-γ)
    (hcaplo : lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤(x)*((N:ℝ)^2*y))
    (hcaphi : (x)*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    Real.exp (-E)*Real.exp (-coupledCentralCertificateConstant fL f M lam0*(γ*(1-γ)))+
      coupledReserveConstant f Emin M*Real.exp (-E)*((N:ℝ)^2*y)≤
      coupledDampedExpression ℓ N γ z M (Real.exp (-E/8)) fL f x y := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hE : 0<E := hEmin.trans_le hEE
  have hzE : z≤Real.exp (-E) := by have hh := overlapG_ge_parameter hγ hγ1 hz hz1;rwa [hG] at hh
  have hzEmin : z≤Real.exp (-Emin) := hzE.trans (Real.exp_le_exp.mpr (by linarith only [hEE]))
  have hM0 : 0≤M := by linarith only [hM]
  have hω0 : 0≤Real.exp (-E/8) := (Real.exp_pos _).le
  have hω1 : Real.exp (-E/8)<1 := Real.exp_lt_one_iff.mpr (by linarith only [hE])
  have hbase := coupledProfiles_central_base_lower (M:=M) hℓ hN hγ hγ1 hz hz1 hlam0
    hfL hfL1 hf hf1 hω0 hω1 hx hx1 hy.le hy1 hZ hY hcaplo
  rw [hG] at hbase
  have hcuts := coupledProfiles_reserved_cutoff_bounds hℓ hN hγ hγ1 hz hz1 hE hzE hM
    hfL hfL1 hf hf1 hx hx1 hy hy1 (hY.trans (by linarith only [hγ] : 1-γ≤1)) hcaphi
  dsimp only at hcuts
  have hK := coupledCentralLoss_nonneg hfL hfL1 hf hf1 hM0 hlam0 hlam1
  have hh0 : 0≤γ*(1-γ) := mul_nonneg hγ.le hd.le
  have hh1 : γ*(1-γ)≤1/4 := by nlinarith only [sq_nonneg (γ-1/2)]
  have hmain := two_lower_bounds_exponential (Real.exp_pos (-E)).le hK
    (Real.exp_pos (Real.log 12+1)).le endpointCutoffTailConstant_pos endpointCutoffTailConstant_le_one
    hh0 hh1 hbase hcuts.1 hcuts.2
  have hreserve := coupledProfiles_high_reserve_lower hN hγ hγ1 hz hz1 hEmin hzEmin hM0
    hf hf1 hω0 hω1 hy.le hy1 hY
  rw [hG] at hreserve
  change Real.exp (-E)*Real.exp (-coupledCentralCertificateConstant fL f M lam0*(γ*(1-γ)))≤
    coupledDampedExpression ℓ N γ z M (Real.exp (-E/8)) fL f x y-
      coupledHighReserve N γ z M f (Real.exp (-E/8)) y at hmain
  nlinarith only [hmain,hreserve]


end Renyi.DegreeOneCompletion
