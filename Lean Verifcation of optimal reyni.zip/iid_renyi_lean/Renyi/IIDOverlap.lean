import Renyi.MixtureTesting
import Renyi.PoissonOverlap

/-! Exact likelihood overlaps for fixed-size iid samples. -/
noncomputable section
open scoped BigOperators
namespace Renyi

def iidLikelihood {k : ℕ} (p q : Simplex k) (n : ℕ) (x : Sample k n) : ℝ :=
  iidMass q n x / iidMass p n x

theorem iidMass_pos {k n : ℕ} (p : Simplex k) (hp : ∀ i, 0 < p.mass i)
    (x : Sample k n) : 0 < iidMass p n x :=
  Finset.prod_pos (fun i _ => hp (x i))

theorem iidLikelihood_density {k n : ℕ} (p q : Simplex k)
    (hp : ∀ i, 0 < p.mass i) (x : Sample k n) :
    iidLikelihood p q n x * iidMass p n x = iidMass q n x := by
  exact div_mul_cancel₀ _ (ne_of_gt (iidMass_pos p hp x))

theorem iidLikelihood_mean {k n : ℕ} (p q : Simplex k)
    (hp : ∀ i, 0 < p.mass i) :
    ∑ x : Sample k n, iidLikelihood p q n x * iidMass p n x = 1 := by
  simp_rw [iidLikelihood_density p q hp]
  exact iidMass_sum q n

def iidOverlapEnergy {k : ℕ} (p q r : Simplex k) : ℝ :=
  ∑ i, (q.mass i - p.mass i) * (r.mass i - p.mass i) / p.mass i

theorem iid_coordinate_overlap {k : ℕ} (p q r : Simplex k)
    (hp : ∀ i, 0 < p.mass i) :
    ∑ i, q.mass i * r.mass i / p.mass i = 1 + iidOverlapEnergy p q r := by
  have hterm (i : Fin k) : q.mass i * r.mass i / p.mass i =
      (q.mass i - p.mass i) * (r.mass i - p.mass i) / p.mass i +
        q.mass i + r.mass i - p.mass i := by
    field_simp [ne_of_gt (hp i)]
    ring
  simp_rw [hterm]
  simp only [Finset.sum_sub_distrib, Finset.sum_add_distrib, p.normalized,
    q.normalized, r.normalized, iidOverlapEnergy]
  ring

theorem iid_likelihood_overlap {k n : ℕ} (p q r : Simplex k)
    (hp : ∀ i, 0 < p.mass i) :
    (∑ x : Sample k n, iidLikelihood p q n x * iidLikelihood p r n x * iidMass p n x) =
      (1 + iidOverlapEnergy p q r) ^ n := by
  have hterm (x : Sample k n) :
      iidLikelihood p q n x * iidLikelihood p r n x * iidMass p n x =
        ∏ j, (q.mass (x j) * r.mass (x j) / p.mass (x j)) := by
    unfold iidLikelihood
    rw [mul_assoc, div_mul_cancel₀ _ (ne_of_gt (iidMass_pos p hp x))]
    unfold iidMass
    rw [Finset.prod_div_distrib, Finset.prod_mul_distrib]
    ring
  simp_rw [hterm]
  have h := Finset.prod_univ_sum (ι := Fin n)
    (fun _ => (Finset.univ : Finset (Fin k)))
    (fun _ i => q.mass i * r.mass i / p.mass i)
  simpa [iid_coordinate_overlap p q r hp] using h.symm

theorem iid_likelihood_overlap_le_exp {k n : ℕ} (p q r : Simplex k)
    (hp : ∀ i, 0 < p.mass i) :
    (∑ x : Sample k n, iidLikelihood p q n x * iidLikelihood p r n x * iidMass p n x) ≤
      Real.exp ((n : ℝ) * iidOverlapEnergy p q r) := by
  rw [iid_likelihood_overlap p q r hp]
  have hnonneg : 0 ≤ 1 + iidOverlapEnergy p q r := by
    rw [← iid_coordinate_overlap p q r hp]
    exact Finset.sum_nonneg (fun i _ => div_nonneg (mul_nonneg (q.nonneg i) (r.nonneg i)) (hp i).le)
  calc
    _ ≤ (Real.exp (iidOverlapEnergy p q r)) ^ n := by
      apply pow_le_pow_left₀ hnonneg
      simpa [add_comm] using Real.add_one_le_exp (iidOverlapEnergy p q r)
    _ = _ := by rw [← Real.exp_nat_mul]

def iidUniformMixture {k m : ℕ} (q : Fin m → Simplex k) (n : ℕ) (x : Sample k n) : ℝ :=
  (∑ s, iidMass (q s) n x) / m

def iidMixtureLikelihood {k m : ℕ} (p : Simplex k) (q : Fin m → Simplex k)
    (n : ℕ) (x : Sample k n) : ℝ := (∑ s, iidLikelihood p (q s) n x) / m

theorem iidUniformMixture_nonneg {k m n : ℕ} (q : Fin m → Simplex k) (x : Sample k n) :
    0 ≤ iidUniformMixture q n x := by
  exact div_nonneg (Finset.sum_nonneg (fun s _ => iidMass_nonneg (q s) x)) (Nat.cast_nonneg _)

theorem iidUniformMixture_sum {k m : ℕ} (q : Fin m → Simplex k) (n : ℕ) (hm : 0 < m) :
    ∑ x, iidUniformMixture q n x = 1 := by
  unfold iidUniformMixture
  rw [← Finset.sum_div, Finset.sum_comm]
  simp_rw [iidMass_sum]
  simp [ne_of_gt hm]

theorem iidMixtureLikelihood_density {k m n : ℕ} (p : Simplex k) (q : Fin m → Simplex k)
    (hp : ∀ i, 0 < p.mass i) (x : Sample k n) :
    iidMixtureLikelihood p q n x * iidMass p n x = iidUniformMixture q n x := by
  unfold iidMixtureLikelihood iidUniformMixture
  rw [div_mul_eq_mul_div, Finset.sum_mul]
  simp_rw [iidLikelihood_density p _ hp]

def iidMixtureChiSq {k m : ℕ} (p : Simplex k) (q : Fin m → Simplex k) (n : ℕ) : ℝ :=
  ∑ x : Sample k n, (iidMixtureLikelihood p q n x - 1) ^ 2 * iidMass p n x

theorem iidMixtureChiSq_identity {k m n : ℕ} (p : Simplex k) (q : Fin m → Simplex k)
    (hp : ∀ i, 0 < p.mass i) (hm : 0 < m) :
    iidMixtureChiSq p q n =
      (∑ s, ∑ t, (1 + iidOverlapEnergy p (q s) (q t)) ^ n) / (m : ℝ) ^ 2 - 1 := by
  have hfirst : ∑ x : Sample k n, iidMixtureLikelihood p q n x * iidMass p n x = 1 := by
    simp_rw [iidMixtureLikelihood_density p q hp]
    exact iidUniformMixture_sum q n hm
  have hsecond : ∑ x : Sample k n, iidMixtureLikelihood p q n x ^ 2 * iidMass p n x =
      (∑ s, ∑ t, (1 + iidOverlapEnergy p (q s) (q t)) ^ n) / (m : ℝ) ^ 2 := by
    have hterm (x : Sample k n) : iidMixtureLikelihood p q n x ^ 2 * iidMass p n x =
        (∑ s, ∑ t, iidLikelihood p (q s) n x * iidLikelihood p (q t) n x *
          iidMass p n x) / (m : ℝ) ^ 2 := by
      simp only [iidMixtureLikelihood, div_pow, ← Finset.sum_mul, ← Finset.mul_sum]
      ring
    simp_rw [hterm]
    rw [← Finset.sum_div, Finset.sum_comm]
    congr 1
    apply Finset.sum_congr rfl
    intro s _
    rw [Finset.sum_comm]
    simp_rw [iid_likelihood_overlap p _ _ hp]
  unfold iidMixtureChiSq
  have hterm (x : Sample k n) : (iidMixtureLikelihood p q n x - 1) ^ 2 * iidMass p n x =
      iidMixtureLikelihood p q n x ^ 2 * iidMass p n x -
      2 * (iidMixtureLikelihood p q n x * iidMass p n x) + iidMass p n x := by ring
  simp_rw [hterm]
  rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum,
    hfirst, hsecond, iidMass_sum]
  ring

theorem iidMixtureTV_le_sqrt_chisq {k m n : ℕ} (p : Simplex k) (q : Fin m → Simplex k)
    (hp : ∀ i, 0 < p.mass i) :
    finiteTV (iidMass p n) (iidUniformMixture q n) ≤ Real.sqrt (iidMixtureChiSq p q n) / 2 := by
  have h := discrete_tv_le_sqrt_chisq (iidMass p n) (iidUniformMixture q n)
    (iidMixtureLikelihood p q n) (iidMass_nonneg p) (iidUniformMixture_nonneg q)
    (by simpa only [iidMass_sum] using hasSum_fintype (iidMass p n))
    (hasSum_fintype _).summable (iidMixtureLikelihood_density p q hp) (hasSum_fintype _).summable
  simpa [finiteTV, iidMixtureChiSq, tsum_fintype, abs_sub_comm] using h

/-- Finite mixture bound retaining the common off-diagonal overlap. -/
theorem finite_mixture_common_overlap_bound {m : ℕ} (hm : 0 < m)
    (A : Fin m → Fin m → ℝ) (u v : ℝ)
    (hdiag : ∀ s, A s s ≤ Real.exp (u + v))
    (hoff : ∀ s t, s ≠ t → A s t ≤ Real.exp v) :
    (∑ s, ∑ t, A s t) / (m : ℝ) ^ 2 - 1 ≤
      Real.exp v * (Real.exp u - 1) / m + Real.exp v - 1 := by
  have hmpos : 0 < (m : ℝ) := by exact_mod_cast hm
  have hrow (s : Fin m) : ∑ t, A s t ≤
      m * Real.exp v + Real.exp (u + v) - Real.exp v := by
    calc
      ∑ t, A s t ≤ ∑ t, (Real.exp v + if s = t then Real.exp (u + v) - Real.exp v else 0) := by
        apply Finset.sum_le_sum
        intro t _
        by_cases hst : s = t
        · subst t
          simpa using hdiag s
        · simpa [hst] using hoff s t hst
      _ = _ := by simp [Finset.sum_add_distrib]; ring
  have hsum := Finset.sum_le_sum (s := Finset.univ) (fun s _ => hrow s)
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at hsum
  apply (sub_le_iff_le_add).2
  apply (div_le_iff₀ (sq_pos_of_pos hmpos)).2
  convert hsum using 1
  rw [Real.exp_add]
  field_simp
  ring

theorem iidMixtureChiSq_common_bound {k m n : ℕ} (p : Simplex k)
    (q : Fin m → Simplex k) (hp : ∀ i, 0 < p.mass i) (hm : 0 < m)
    (u v : ℝ)
    (hdiag : ∀ s, (n : ℝ) * iidOverlapEnergy p (q s) (q s) ≤ u + v)
    (hoff : ∀ s t, s ≠ t → (n : ℝ) * iidOverlapEnergy p (q s) (q t) ≤ v) :
    iidMixtureChiSq p q n ≤ Real.exp v * (Real.exp u - 1) / m + Real.exp v - 1 := by
  rw [iidMixtureChiSq_identity p q hp hm]
  apply finite_mixture_common_overlap_bound hm
  · intro s
    rw [← iid_likelihood_overlap p (q s) (q s) hp]
    exact (iid_likelihood_overlap_le_exp p (q s) (q s) hp).trans (Real.exp_le_exp.mpr (hdiag s))
  · intro s t hst
    rw [← iid_likelihood_overlap p (q s) (q t) hp]
    exact (iid_likelihood_overlap_le_exp p (q s) (q t) hp).trans (Real.exp_le_exp.mpr (hoff s t hst))

/-- Actual fixed-size iid testing against a uniform alternative mixture. -/
theorem iidUniformMixture_impossibility {k m n : ℕ} (p : Simplex k)
    (q : Fin m → Simplex k) (hm : 0 < m) (a eps : ℝ)
    (hgap : ∀ s, 2 * eps < entropy p a - entropy (q s) a)
    (hTV : finiteTV (iidMass p n) (iidUniformMixture q n) ≤ 1 / 4) :
    ¬ Achievable k n a eps := by
  rintro ⟨est, hest⟩
  let low : Set ℝ := Set.Iio (entropy p a - eps)
  let t : Sample k n → ℝ := fun x => (est x low : ℝ)
  have ht0 : ∀ x, 0 ≤ t x := fun _ => NNReal.coe_nonneg _
  have ht1 : ∀ x, t x ≤ 1 := by
    intro x
    exact_mod_cast (est x).apply_le_one low
  have htest := finite_testing_lower_bound (iidMass p n) (iidUniformMixture q n) t
    (iidMass_sum p n) (iidUniformMixture_sum q n hm) ht0 ht1
  have hleft : ∑ x, iidMass p n x * t x ≤ errorProbability p a eps est := by
    apply Finset.sum_le_sum
    intro x _
    apply mul_le_mul_of_nonneg_left _ (iidMass_nonneg p x)
    apply NNReal.coe_le_coe.mpr
    apply (est x).apply_mono
    intro z hz
    change z < entropy p a - eps at hz
    change eps < |z - entropy p a|
    exact (by linarith : eps < -(z - entropy p a)).trans_le (neg_le_abs _)
  have hright (s : Fin m) : ∑ x, iidMass (q s) n x * (1 - t x) ≤
      errorProbability (q s) a eps est := by
    apply Finset.sum_le_sum
    intro x _
    apply mul_le_mul_of_nonneg_left _ (iidMass_nonneg (q s) x)
    have hcomp : (est x low : ℝ) + (est x lowᶜ : ℝ) = 1 := by
      simpa only [MeasureTheory.ProbabilityMeasure.measureReal_eq_coe_coeFn,
        MeasureTheory.ProbabilityMeasure.coeFn_univ, NNReal.coe_one] using
        (MeasureTheory.measureReal_add_measureReal_compl (μ := (est x : MeasureTheory.Measure ℝ))
          (show MeasurableSet low from measurableSet_Iio))
    have hb : (est x lowᶜ : ℝ) ≤ (est x {z | eps < |z - entropy (q s) a|} : ℝ) := by
      apply NNReal.coe_le_coe.mpr
      apply (est x).apply_mono
      intro z hz
      have hz' : entropy p a - eps ≤ z := le_of_not_gt hz
      exact (by linarith [hgap s] : eps < z - entropy (q s) a).trans_le (le_abs_self _)
    dsimp [t]
    linarith
  have hmix : ∑ x, iidUniformMixture q n x * (1 - t x) ≤ 1 / 3 := by
    have hbound := Finset.sum_le_sum (s := Finset.univ)
      (fun s _ => (hright s).trans (hest (q s)))
    have hmpos : 0 < (m : ℝ) := by exact_mod_cast hm
    unfold iidUniformMixture
    simp_rw [div_mul_eq_mul_div, Finset.sum_mul]
    rw [← Finset.sum_div, Finset.sum_comm]
    apply (div_le_iff₀ hmpos).2
    simpa [mul_comm] using hbound
  rw [Finset.sum_add_distrib] at htest
  linarith [hleft.trans (hest p)]

end Renyi
