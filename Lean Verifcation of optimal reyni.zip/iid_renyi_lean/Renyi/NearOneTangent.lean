import Renyi.EndpointExponentTail

/-! Actual localized tangent cancellation at orders approaching one. -/
noncomputable section
open MeasureTheory Set
namespace Renyi

def unitTangentError (beta y : ℝ) : ℝ := (1+beta)*y-beta-y^(1+beta)

theorem unitTangentError_low {beta y : ℝ} (hb : 0 ≤ beta) (hy : 0 < y)
    (hy1 : y ≤ 1) : |unitTangentError beta y| ≤ 5*beta := by
  have hp0 : 0 ≤ y^beta := Real.rpow_nonneg hy.le _
  have hp1 : y^beta ≤ 1 := Real.rpow_le_one hy.le hy1 hb
  have hlog : Real.log y ≤ 0 := Real.log_nonpos hy.le hy1
  have he := Real.add_one_le_exp (beta*Real.log y)
  rw [mul_comm beta, ← Real.rpow_def_of_pos hy] at he
  have hl := endpoint_low_log_bound hy hy1
  rw [abs_of_nonpos hlog] at hl
  have hY : y*(1-y^beta) ≤ 4*beta := by
    have h1 := mul_le_mul_of_nonneg_left (show 1-y^beta ≤ beta*(-Real.log y) by nlinarith) hy.le
    have h2 := mul_le_mul_of_nonneg_left hl (mul_nonneg hb hy.le)
    have hp : y*y^(-(1/4:ℝ)) = y^(3/4:ℝ) := by
      calc
        _ = y^(1:ℝ)*y^(-(1/4:ℝ)) := by rw [Real.rpow_one]
        _ = _ := by rw [← Real.rpow_add hy]; norm_num
    have hh : y^(3/4:ℝ) ≤ 1 := Real.rpow_le_one hy.le hy1 (by norm_num)
    calc
      _ ≤ beta*y*(-Real.log y) := by nlinarith only [h1]
      _ ≤ 4*beta*(y*y^(-(1/4:ℝ))) := by nlinarith only [h2]
      _ ≤ 4*beta := by rw [hp]; nlinarith
  have heq : unitTangentError beta y = beta*(y-1)+y*(1-y^beta) := by
    unfold unitTangentError
    rw [Real.rpow_add hy, Real.rpow_one]
    ring
  rw [heq]
  apply le_trans (abs_add_le _ _)
  rw [abs_mul, abs_of_nonneg hb, abs_of_nonpos (sub_nonpos.mpr hy1),
    abs_of_nonneg (mul_nonneg hy.le (sub_nonneg.mpr hp1))]
  nlinarith

theorem unitTangentError_high {beta y : ℝ} (hb : 0 ≤ beta) (hb1 : beta ≤ 1/2)
    (hy : 1 ≤ y) : |unitTangentError beta y| ≤ 3*beta*y^2 := by
  have hy0 : 0 < y := zero_lt_one.trans_le hy
  have hp1 : 1 ≤ y^beta := Real.one_le_rpow hy hb
  have hp : y^beta ≤ y^(1/2:ℝ) := Real.rpow_le_rpow_of_exponent_le hy hb1
  have hlog : 0 ≤ Real.log y := Real.log_nonneg hy
  have he := Real.add_one_le_exp (-beta*Real.log y)
  have hm := mul_le_mul_of_nonneg_left he (Real.rpow_nonneg hy0.le beta)
  have hid : y^beta*Real.exp (-beta*Real.log y) = 1 := by
    rw [Real.rpow_def_of_pos hy0, ← Real.exp_add]
    convert Real.exp_zero using 1
    ring
  rw [hid] at hm
  have hl := endpoint_high_log_bound hy
  have hprod := mul_le_mul hp hl hlog (Real.rpow_nonneg hy0.le _)
  have hsquare : y^(1/2:ℝ)*(2*y^(1/2:ℝ)) = 2*y := by
    rw [mul_left_comm, ← Real.rpow_add hy0]
    norm_num
  rw [hsquare] at hprod
  have hinc : y^beta-1 ≤ 2*beta*y := by
    have := mul_le_mul_of_nonneg_left hprod hb
    nlinarith only [hm,this]
  have heq : unitTangentError beta y = beta*(y-1)-y*(y^beta-1) := by
    unfold unitTangentError
    rw [Real.rpow_add hy0, Real.rpow_one]
    ring
  rw [heq]
  apply le_trans (abs_sub_le _ 0 _ )
  simp only [sub_zero, zero_sub, abs_neg]
  rw [abs_mul, abs_of_nonneg hb, abs_of_nonneg (sub_nonneg.mpr hy),
    abs_of_nonneg (mul_nonneg hy0.le (sub_nonneg.mpr hp1))]
  have hh := mul_le_mul_of_nonneg_left hinc hy0.le
  have hy2 : y ≤ y^2 := by nlinarith
  have hbY := mul_le_mul_of_nonneg_left hy2 hb
  nlinarith

def nearOneTangentConstant : ℝ :=
  5+43*Real.exp (Real.log 12+1)+
    (1+20*Real.exp (Real.log 12+1))*Real.exp (Real.log 12+1)

/-- The actual normalized endpoint profiles cancel the tangent uniformly, with
an explicit factor beta and a degree-independent constant. -/
theorem endpoint_tangent_cancellation {N : ℕ} (hN : 0<N) {beta y : ℝ}
    (hb : 0≤beta) (hb1 : beta≤1/2) (hy : 0≤y) (hyR : y≤(N:ℝ)^2) :
    |unitTangentError beta y*(1-endpointProfile N 6 1 (y/(N:ℝ)^2)) +
      y^(1+beta)*(endpointProfile N 6 (1-beta) (y/(N:ℝ)^2)-
        endpointProfile N 6 1 (y/(N:ℝ)^2))| ≤ nearOneTangentConstant*beta := by
  let C := Real.exp (Real.log 12+1)
  let D := (1+20*C)*C
  have hC : 0<C := Real.exp_pos _
  have hD : 0<D := by dsimp [D]; positivity
  have hR : 0<(N:ℝ)^2 := by positivity
  have hx : 0≤y/(N:ℝ)^2 := div_nonneg hy hR.le
  have hx1 : y/(N:ℝ)^2≤1 := (div_le_one hR).mpr hyR
  have hJ := endpointProfile_range (d:=6) hN (by norm_num) (s:=1) (by norm_num) hx hx1
  have hcomp := endpointProfile_order_one_comparison (d:=6) hN (by norm_num)
    (by norm_num) (s:=1-beta) (by linarith) (by linarith) hx hx1
  have hcommon : endpointProfile N 6 (1-beta) (y/(N:ℝ)^2)-
      endpointProfile N 6 1 (y/(N:ℝ)^2) ≤ 40*C*beta := by
    convert hcomp.2 using 1
    ring
  have hpower : 0≤y^(1+beta) := Real.rpow_nonneg hy _
  have hsecond0 : 0≤y^(1+beta)*(endpointProfile N 6 (1-beta) (y/(N:ℝ)^2)-
      endpointProfile N 6 1 (y/(N:ℝ)^2)) := mul_nonneg hpower hcomp.1
  have hfirst : |unitTangentError beta y*(1-endpointProfile N 6 1 (y/(N:ℝ)^2))| ≤
      (5+3*C)*beta := by
    rw [abs_mul, abs_of_nonneg (sub_nonneg.mpr hJ.2)]
    by_cases hy0 : y=0
    · subst y
      simp only [unitTangentError, mul_zero, zero_div, endpointProfile_zero, sub_zero,
        Real.zero_rpow (by linarith : 1+beta≠0), zero_sub, abs_neg, abs_of_nonneg hb,
        mul_one]
      nlinarith
    have hypos : 0<y := lt_of_le_of_ne hy (Ne.symm hy0)
    by_cases hy1 : y≤1
    · have h := mul_le_of_le_one_right (abs_nonneg (unitTangentError beta y))
        (show 1-endpointProfile N 6 1 (y/(N:ℝ)^2)≤1 by linarith [hJ.1])
      have he := unitTangentError_low hb hypos hy1
      nlinarith [mul_nonneg hC.le hb]
    · have hy1' : 1≤y := (lt_of_not_ge hy1).le
      have ht := endpointProfile_tail (d:=6) hN (by norm_num) (by norm_num)
        (s:=1) (by norm_num) le_rfl (div_pos hypos hR) hx1
      rw [mul_div_cancel₀ _ hR.ne'] at ht
      have ht' : 1-endpointProfile N 6 1 (y/(N:ℝ)^2)≤C*y^(-(5:ℝ)) := by
        convert ht using 1
        norm_num [C]
      have hm := mul_le_mul (unitTangentError_high hb hb1 hy1') ht'
        (sub_nonneg.mpr hJ.2) (by positivity : 0≤3*beta*y^2)
      have hp : y^2*y^(-(5:ℝ))≤1 := by
        have hid : y^2*y^(-(5:ℝ))=y^(-(3:ℝ)) := by
          rw [← Real.rpow_two, ← Real.rpow_add hypos]
          norm_num
        rw [hid]
        exact Real.rpow_le_one_of_one_le_of_nonpos hy1' (by norm_num)
      have hh := mul_le_mul_of_nonneg_left hp (by positivity : 0≤3*beta*C)
      nlinarith only [hm,hh,mul_nonneg hC.le hb,hb]
  have hsecond : |y^(1+beta)*(endpointProfile N 6 (1-beta) (y/(N:ℝ)^2)-
      endpointProfile N 6 1 (y/(N:ℝ)^2))|≤(40*C+D)*beta := by
    rw [abs_of_nonneg hsecond0]
    by_cases hy1 : y≤1
    · have hp : y^(1+beta)≤1 := Real.rpow_le_one hy hy1 (by linarith)
      have hh := mul_le_mul hp hcommon hcomp.1 (by norm_num : (0:ℝ)≤1)
      nlinarith [mul_nonneg hD.le hb]
    · have hy1' : 1≤y := (lt_of_not_ge hy1).le
      have hypos : 0<y := zero_lt_one.trans_le hy1'
      have ht := endpointProfile_exponent_tail hN (s:=1-beta) (by linarith)
        (by linarith) (div_pos hypos hR) hx1
        (by rw [mul_div_cancel₀ _ hR.ne']; exact hy1')
      rw [mul_div_cancel₀ _ hR.ne', abs_of_nonneg hcomp.1] at ht
      have ht' : endpointProfile N 6 (1-beta) (y/(N:ℝ)^2)-
          endpointProfile N 6 1 (y/(N:ℝ)^2)≤D*beta*y^(-(9/2:ℝ)) := by
        convert ht using 1
        ring
      have hh := mul_le_mul_of_nonneg_left ht' hpower
      have hp : y^(1+beta)*y^(-(9/2:ℝ))≤1 := by
        rw [← Real.rpow_add hypos]
        exact Real.rpow_le_one_of_one_le_of_nonpos hy1' (by linarith)
      have hh' := mul_le_mul_of_nonneg_left hp (mul_nonneg hD.le hb)
      nlinarith only [hh,hh',mul_nonneg hC.le hb]
  have hsum := abs_add_le
    (unitTangentError beta y*(1-endpointProfile N 6 1 (y/(N:ℝ)^2)))
    (y^(1+beta)*(endpointProfile N 6 (1-beta) (y/(N:ℝ)^2)-endpointProfile N 6 1 (y/(N:ℝ)^2)))
  dsimp [nearOneTangentConstant, D, C] at *
  linarith

end Renyi
