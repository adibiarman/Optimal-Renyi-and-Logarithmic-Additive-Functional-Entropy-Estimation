import Renyi.PoissonPoincare
import Renyi.AnalyticBias
import Renyi.PositiveCounts
import Mathlib.Analysis.SpecialFunctions.Gamma.BohrMollerup

/-!
# Uniform control of the signed low-count correction

These estimates concern the actual analytic Gamma-ratio count family. All
constants below are uniform over the fractional part of the order.
-/

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Set
namespace Renyi

/-- Reciprocal Gamma is bounded on the positive unit interval `[1,2]`. -/
theorem exists_uniform_gamma_reciprocal_bound :
    ∃ C : ℝ, 0 < C ∧ ∀ x ∈ Icc (1 : ℝ) 2, (Real.Gamma x)⁻¹ ≤ C := by
  have hc : ContinuousOn Real.Gamma (Icc (1 : ℝ) 2) := by
    intro x hx
    refine (Real.differentiableAt_Gamma (fun n => ?_)).continuousAt.continuousWithinAt
    have hn : 0 ≤ (n : ℝ) := Nat.cast_nonneg _
    linarith [hx.1]
  obtain ⟨x, hx, hmin⟩ := isCompact_Icc.exists_isMinOn (nonempty_Icc.mpr (by norm_num : (1 : ℝ) ≤ 2)) hc
  have hpos : 0 < Real.Gamma x := Real.Gamma_pos_of_pos (by linarith [hx.1])
  refine ⟨(Real.Gamma x)⁻¹, inv_pos.mpr hpos, ?_⟩
  intro y hy
  exact inv_anti₀ hpos (hmin hy)

/-- The reciprocal Gamma coefficient carries both endpoint factors. -/
theorem gamma_low_coefficient_bound {C γ : ℝ} (hC : 0 ≤ C)
    (hΓ : ∀ x ∈ Icc (1 : ℝ) 2, (Real.Gamma x)⁻¹ ≤ C)
    (hγ : 0 ≤ γ) (hγ1 : γ ≤ 1) (d : ℕ) :
    |(Real.Gamma (-(d : ℝ) - γ))⁻¹| ≤
      C * (γ * (1 - γ)) * ((d + 1).factorial : ℝ) := by
  induction d with
  | zero =>
      have hΓpos : 0 < Real.Gamma (2 - γ) := Real.Gamma_pos_of_pos (by linarith)
      have hrec : (Real.Gamma (-γ))⁻¹ =
          -γ * (1 - γ) * (Real.Gamma (2 - γ))⁻¹ := by
        rw [gamma_inv_recurrence (-γ), gamma_inv_recurrence (-γ + 1)]
        rw [show -γ + 1 + 1 = 2 - γ by ring]
        ring
      have hb := hΓ (2 - γ) ⟨by linarith, by linarith⟩
      simp only [Nat.cast_zero, neg_zero, zero_sub, Nat.zero_add, Nat.factorial_one,
        Nat.cast_one, mul_one]
      rw [hrec, abs_mul, abs_mul, abs_neg, abs_of_nonneg hγ,
        abs_of_nonneg (by linarith : 0 ≤ 1 - γ), abs_of_pos (inv_pos.mpr hΓpos)]
      nlinarith [mul_nonneg hγ (sub_nonneg.mpr hγ1)]
  | succ d ih =>
      have hrec := gamma_inv_recurrence (-((d + 1 : ℕ) : ℝ) - γ)
      have heq : -((d + 1 : ℕ) : ℝ) - γ + 1 = -(d : ℝ) - γ := by push_cast; ring
      rw [heq] at hrec
      rw [hrec, abs_mul]
      have ha : |-((d + 1 : ℕ) : ℝ) - γ| = (d : ℝ) + 1 + γ := by
        rw [abs_of_nonpos (by push_cast; linarith [Nat.cast_nonneg (α := ℝ) d])]
        push_cast
        ring
      rw [ha]
      have hfactor : (d : ℝ) + 1 + γ ≤ (d : ℝ) + 2 := by linarith
      have ht : 0 ≤ 1 - γ := by linarith
      have hn : 0 ≤ C * (γ * (1 - γ)) * ((d + 1).factorial : ℝ) := by positivity
      calc
        _ ≤ ((d : ℝ) + 1 + γ) * (C * (γ * (1 - γ)) * ((d + 1).factorial : ℝ)) :=
          mul_le_mul_of_nonneg_left ih (by positivity)
        _ ≤ ((d : ℝ) + 2) * (C * (γ * (1 - γ)) * ((d + 1).factorial : ℝ)) :=
          mul_le_mul_of_nonneg_right hfactor hn
        _ = _ := by
          rw [Nat.factorial_succ (d + 1)]
          push_cast
          ring

/-- A finite factorial tail is geometric once the intensity dominates the degree. -/
theorem factorial_poisson_partial_sum (m : ℕ) {lam : ℝ}
    (hlam : 2 * ((m : ℝ) + 1) ≤ lam) :
    ∑ j ∈ Finset.range (m + 1), lam ^ j * ((m + 1 - j).factorial : ℝ) ≤
      2 * lam ^ m := by
  induction m with
  | zero => norm_num
  | succ m ih =>
      have hl0 : 0 ≤ lam := by have := Nat.cast_nonneg (α := ℝ) m; push_cast at hlam; linarith
      have hm0 : 0 ≤ (m : ℝ) + 2 := by positivity
      have hbase := ih (by push_cast at hlam; linarith)
      calc
        _ = (∑ j ∈ Finset.range (m + 1), lam ^ j * ((m + 2 - j).factorial : ℝ)) +
            lam ^ (m + 1) := by
          rw [show m.succ + 1 = (m + 1) + 1 by omega, Finset.sum_range_succ]
          simp
        _ ≤ ((m : ℝ) + 2) *
            (∑ j ∈ Finset.range (m + 1), lam ^ j * ((m + 1 - j).factorial : ℝ)) +
            lam ^ (m + 1) := by
          gcongr
          rw [Finset.mul_sum]
          apply Finset.sum_le_sum
          intro j hj
          have hjm : j < m + 1 := Finset.mem_range.mp hj
          rw [show m + 2 - j = (m + 1 - j) + 1 by omega, Nat.factorial_succ]
          push_cast
          have hnat : ((m + 1 - j + 1 : ℕ) : ℝ) ≤ (m : ℝ) + 2 := by exact_mod_cast (show m + 1 - j + 1 ≤ m + 2 by omega)
          have hf : 0 ≤ ((m + 1 - j).factorial : ℝ) := by positivity
          have hp : 0 ≤ lam ^ j := pow_nonneg hl0 _
          have ht := mul_le_mul_of_nonneg_right hnat (mul_nonneg hp hf)
          push_cast at ht
          convert ht using 1
          ring
        _ ≤ ((m : ℝ) + 2) * (2 * lam ^ m) + lam ^ (m + 1) := by
          gcongr
        _ ≤ 2 * lam ^ (m + 1) := by
          rw [pow_succ]
          have hp : 0 ≤ lam ^ m := pow_nonneg hl0 _
          push_cast at hlam
          nlinarith

/-- Cancellation of the factorial in a Poisson-weighted signed count. -/
theorem analyticCount_abs_poisson_mass (lam : ℝ≥0) (a : ℝ) (j : ℕ) :
    |analyticCount a j| * poissonPMFReal lam j =
      Real.exp (-(lam : ℝ)) * (lam : ℝ) ^ j *
        |(Real.Gamma ((j : ℝ) + 1 - a))⁻¹| := by
  have hf : (j.factorial : ℝ) ≠ 0 := by positivity
  unfold analyticCount poissonPMFReal
  rw [div_eq_mul_inv, abs_mul, abs_of_nonneg (Nat.cast_nonneg _)]
  field_simp

/-- The actual low-count expectation obeys the uniform endpoint-factor bound. -/
theorem signed_low_count_bound_of_gamma_bound {C γ : ℝ} (hC : 0 ≤ C)
    (hΓ : ∀ x ∈ Icc (1 : ℝ) 2, (Real.Gamma x)⁻¹ ≤ C)
    (hγ : 0 ≤ γ) (hγ1 : γ ≤ 1) (m : ℕ) (hm : 1 ≤ m)
    (lam : ℝ≥0) (hlam : 2 * ((m : ℝ) + 1) ≤ (lam : ℝ)) :
    (∫ j : ℕ, (if j < m then |analyticCount ((m : ℝ) + γ) j| else 0)
      ∂poissonMeasure lam) ≤
      (2 * C) * (γ * (1 - γ)) * Real.exp (-(lam : ℝ)) * (lam : ℝ) ^ (m - 1) := by
  let f : ℕ → ℝ := fun j => if j < m then |analyticCount ((m : ℝ) + γ) j| else 0
  have hint : Integrable f (poissonMeasure lam) := by
    apply poisson_integrable_of_summable
    apply summable_of_ne_finset_zero (s := Finset.range m)
    intro j hj
    have hjm : ¬j < m := by simpa only [Finset.mem_range] using hj
    simp [f, hjm]
  have hsum : (∫ j : ℕ, f j ∂poissonMeasure lam) =
      ∑ j ∈ Finset.range m, |analyticCount ((m : ℝ) + γ) j| * poissonPMFReal lam j := by
    rw [poisson_integral_eq_tsum lam f hint,
      tsum_eq_sum (s := Finset.range m) (by
        intro j hj
        have hjm : ¬j < m := by simpa only [Finset.mem_range] using hj
        simp [f, hjm])]
    apply Finset.sum_congr rfl
    intro j hj
    simp [f, Finset.mem_range.mp hj]
  change (∫ j : ℕ, f j ∂poissonMeasure lam) ≤ _
  rw [hsum]
  have hpoint (j : ℕ) (hj : j ∈ Finset.range m) :
      |analyticCount ((m : ℝ) + γ) j| * poissonPMFReal lam j ≤
        C * (γ * (1 - γ)) * Real.exp (-(lam : ℝ)) *
          ((lam : ℝ) ^ j * ((m - j).factorial : ℝ)) := by
    have hjm : j < m := Finset.mem_range.mp hj
    let d := m - j - 1
    have hmd : m = j + d + 1 := by dsimp [d]; omega
    have harg : (j : ℝ) + 1 - ((m : ℝ) + γ) = -(d : ℝ) - γ := by
      rw [hmd]
      push_cast
      ring
    have hfac : d + 1 = m - j := by dsimp [d]; omega
    have hb := gamma_low_coefficient_bound hC hΓ hγ hγ1 d
    rw [hfac] at hb
    rw [analyticCount_abs_poisson_mass, harg]
    have hs : 0 ≤ Real.exp (-(lam : ℝ)) * (lam : ℝ) ^ j := by positivity
    have hb' := mul_le_mul_of_nonneg_left hb hs
    convert hb' using 1
    ring
  have hpartial : ∑ j ∈ Finset.range m, (lam : ℝ) ^ j * ((m - j).factorial : ℝ) ≤
      2 * (lam : ℝ) ^ (m - 1) := by
    have hnat : m - 1 + 1 = m := by omega
    have hcast : ((m - 1 : ℕ) : ℝ) + 1 = (m : ℝ) := by exact_mod_cast hnat
    have hs := factorial_poisson_partial_sum (m - 1) (by rw [hcast]; linarith :
      2 * (((m - 1 : ℕ) : ℝ) + 1) ≤ (lam : ℝ))
    simpa only [hnat] using hs
  have hs := Finset.sum_le_sum hpoint
  rw [← Finset.mul_sum] at hs
  have ht : 0 ≤ C * (γ * (1 - γ)) * Real.exp (-(lam : ℝ)) := by
    have hg : 0 ≤ 1 - γ := by linarith
    positivity
  have hb := mul_le_mul_of_nonneg_left hpartial ht
  apply hs.trans
  convert hb using 1
  ring

/-- The signed low-count correction in the manuscript, with one absolute constant. -/
theorem signed_low_count_uniform :
    ∃ C : ℝ, 0 < C ∧ ∀ (m : ℕ) (_ : 1 ≤ m) (γ : ℝ) (_ : 0 < γ) (_ : γ < 1)
      (lam : ℝ≥0) (_ : 2 * ((m : ℝ) + 1) ≤ (lam : ℝ)),
      (∫ j : ℕ, (if j < m then |analyticCount ((m : ℝ) + γ) j| else 0)
        ∂poissonMeasure lam) ≤
        C * (γ * (1 - γ)) * Real.exp (-(lam : ℝ)) * (lam : ℝ) ^ (m - 1) := by
  obtain ⟨C, hC, hΓ⟩ := exists_uniform_gamma_reciprocal_bound
  refine ⟨2 * C, by positivity, ?_⟩
  intro m hm γ hγ hγ1 lam hlam
  exact signed_low_count_bound_of_gamma_bound hC.le hΓ hγ.le hγ1.le m hm lam hlam

/-- Gamma is at least one to the left of its unit argument. -/
theorem gamma_one_le_of_pos_le_one {x : ℝ} (hx : 0 < x) (hx1 : x ≤ 1) :
    1 ≤ Real.Gamma x := by
  rcases hx1.eq_or_lt with rfl | hx1
  · simp
  have h := Real.convexOn_Gamma.slope_mono_adjacent
    (x := x) (y := 1) (z := 2) hx (by norm_num) hx1 (by norm_num)
  have hs : (1 - Real.Gamma x) / (1 - x) ≤ 0 := by
    simpa only [Real.Gamma_one, Real.Gamma_two, sub_self, zero_div] using h
  have ht := (div_le_iff₀ (sub_pos.mpr hx1)).mp hs
  linarith

/-- A sharp elementary reciprocal-Gamma bound below the count cutoff. -/
theorem gamma_floor_coefficient_bound {γ : ℝ} (hγ : 0 ≤ γ) (hγ1 : γ < 1)
    (d : ℕ) :
    |(Real.Gamma (1 - γ - (d : ℝ)))⁻¹| ≤ (d.factorial : ℝ) := by
  induction d with
  | zero =>
      have hg : 0 < 1 - γ := by linarith
      have hG := gamma_one_le_of_pos_le_one hg (by linarith : 1 - γ ≤ 1)
      have hpos := Real.Gamma_pos_of_pos hg
      simpa only [Nat.cast_zero, sub_zero, Nat.factorial_zero, Nat.cast_one,
        abs_of_pos (inv_pos.mpr hpos)] using (inv_le_one₀ hpos).mpr hG
  | succ d ih =>
      have hd : 0 ≤ (d : ℝ) := Nat.cast_nonneg _
      have hrec := gamma_inv_recurrence (1 - γ - ((d + 1 : ℕ) : ℝ))
      have heq : 1 - γ - ((d + 1 : ℕ) : ℝ) + 1 = 1 - γ - (d : ℝ) := by push_cast; ring
      rw [heq] at hrec
      rw [hrec, abs_mul]
      have habs : |1 - γ - ((d + 1 : ℕ) : ℝ)| = (d : ℝ) + γ := by
        rw [abs_of_nonpos (by push_cast; linarith)]
        push_cast
        ring
      rw [habs]
      calc
        _ ≤ ((d : ℝ) + γ) * (d.factorial : ℝ) := mul_le_mul_of_nonneg_left ih (by positivity)
        _ ≤ ((d : ℝ) + 1) * (d.factorial : ℝ) := by gcongr
        _ = ((d + 1).factorial : ℝ) := by rw [Nat.factorial_succ]; push_cast; rfl

/-- Every analytic count at or below the integer part is bounded by its factorial. -/
theorem analyticCount_below_cutoff_abs {γ : ℝ} (hγ : 0 ≤ γ) (hγ1 : γ < 1)
    (m j : ℕ) (hjm : j ≤ m) :
    |analyticCount ((m : ℝ) + γ) j| ≤ (m.factorial : ℝ) := by
  have harg : (j : ℝ) + 1 - ((m : ℝ) + γ) = 1 - γ - ((m - j : ℕ) : ℝ) := by
    rw [Nat.cast_sub hjm]
    ring
  have hb := gamma_floor_coefficient_bound hγ hγ1 (m - j)
  unfold analyticCount
  rw [div_eq_mul_inv, abs_mul, abs_of_nonneg (Nat.cast_nonneg _), harg]
  apply (mul_le_mul_of_nonneg_left hb (Nat.cast_nonneg _)).trans
  have hfact := Nat.le_of_dvd (Nat.factorial_pos m) (Nat.factorial_mul_factorial_dvd_factorial hjm)
  exact_mod_cast hfact

/-- Below the actual real cutoff, the signed count is bounded by the order power. -/
theorem analyticCount_abs_below_order {a : ℝ} (ha : 1 ≤ a) (j : ℕ) (hj : (j : ℝ) < a) :
    |analyticCount a j| ≤ a ^ a := by
  let m := ⌊a⌋₊
  let γ := a - (m : ℝ)
  have hm : (m : ℝ) ≤ a := Nat.floor_le (by linarith)
  have hγ : 0 ≤ γ := sub_nonneg.mpr hm
  have hγ1 : γ < 1 := by have := Nat.lt_floor_add_one a; dsimp [γ, m]; linarith
  have hjm : j ≤ m := Nat.le_floor hj.le
  have heq : a = (m : ℝ) + γ := by dsimp [γ]; ring
  have hb := analyticCount_below_cutoff_abs hγ hγ1 m j hjm
  rw [← heq] at hb
  apply hb.trans
  calc
    (m.factorial : ℝ) ≤ (m : ℝ) ^ m := by exact_mod_cast Nat.factorial_le_pow m
    _ = (m : ℝ) ^ (m : ℝ) := by rw [Real.rpow_natCast]
    _ ≤ a ^ (m : ℝ) := Real.rpow_le_rpow (Nat.cast_nonneg _) hm (Nat.cast_nonneg _)
    _ ≤ a ^ a := Real.rpow_le_rpow_of_exponent_le ha hm

/-- The bias part of the order-one proposition has the explicit constant two. -/
theorem analyticMean_order_one_bias {β : ℝ} (hβ : 0 < β) (hβ1 : β ≤ 1 / 2)
    (lam : ℝ≥0) (hlam : 0 < (lam : ℝ)) :
    |analyticMean lam (1 + β) - (lam : ℝ) ^ (1 + β)| ≤
      2 * β * Real.exp (-(lam : ℝ)) / (lam : ℝ) := by
  have hG : Real.Gamma (1 + β + 1) ≤ 2 := by
    have h := Real.Gamma_strictMonoOn_Ici.monotoneOn
      (by simp only [mem_Ici]; linarith : 1 + β + 1 ∈ Ici (2 : ℝ))
      (by norm_num : (3 : ℝ) ∈ Ici (2 : ℝ)) (by linarith : 1 + β + 1 ≤ 3)
    norm_num [Real.Gamma_add_one] at h
    exact h
  have hs : |Real.sin (Real.pi * (1 + β))| ≤ Real.pi * β := by
    rw [show Real.pi * (1 + β) = Real.pi * β + Real.pi by ring,
      Real.sin_add_pi, abs_neg]
    exact (Real.abs_sin_le_abs (x := Real.pi * β)).trans_eq (abs_of_nonneg (by positivity))
  have hb := analyticMean_bias_bound lam hlam (1 + β) (by linarith)
  calc
    _ ≤ _ := hb
    _ ≤ 2 * (Real.pi * β) / Real.pi * Real.exp (-(lam : ℝ)) * (lam : ℝ)⁻¹ := by
      gcongr
      exact min_le_right _ _
    _ = _ := by field_simp

/-- A floor at least the order makes the signed and truncated transforms identical. -/
theorem analyticCount_positiveCount_floor {a b : ℝ} (ha : 1 ≤ a) (hb : a ≤ b)
    (j : ℕ) :
    max (analyticCount a j) (b ^ a) = max (positiveCount a j) (b ^ a) := by
  by_cases hj : a ≤ (j : ℝ)
  · simp only [positiveCount, if_pos hj]
  · have hsmall := analyticCount_abs_below_order ha j (lt_of_not_ge hj)
    have hp : a ^ a ≤ b ^ a := Real.rpow_le_rpow (by linarith) hb (by linarith)
    have hcount : analyticCount a j ≤ b ^ a := (le_abs_self _).trans (hsmall.trans hp)
    have hbpos : 0 ≤ b ^ a := Real.rpow_nonneg (by linarith) _
    rw [max_eq_right hcount, positiveCount, if_neg hj, max_eq_right hbpos]

/-- A short terminal Gamma secant is bounded by the following unit secant. -/
theorem logGamma_ratio_upper_following {x a : ℝ} (ha : 0 < a) (hxa : a < x + 1) :
    Real.log (Real.Gamma (x + 1)) - Real.log (Real.Gamma (x + 1 - a)) ≤
      a * Real.log (x + 1) := by
  have hx : 0 < x + 1 := lt_trans ha hxa
  have h := Real.convexOn_log_Gamma.slope_mono_adjacent
    (x := x + 1 - a) (y := x + 1) (z := x + 2)
    (by simp only [mem_Ioi]; linarith) (by simp only [mem_Ioi]; linarith)
    (by linarith) (by linarith)
  simp only [Function.comp_apply] at h
  rw [show x + 1 - (x + 1 - a) = a by ring,
    show x + 2 - (x + 1) = 1 by ring, div_one] at h
  have hu := logGamma_unit_increment hx
  rw [show x + 1 + 1 = x + 2 by ring] at hu
  rw [hu] at h
  exact (div_le_iff₀ ha).mp h |>.trans_eq (mul_comm _ _)

/-- The small-order analytic count is below its neighboring power, including count zero. -/
theorem analyticCount_small_order_upper {β : ℝ} (hβ : 0 < β) (hβ1 : β ≤ 1 / 2)
    (j : ℕ) : analyticCount β j ≤ ((j : ℝ) + 1) ^ β := by
  have hj0 : 0 ≤ (j : ℝ) := Nat.cast_nonneg _
  have hden : 0 < (j : ℝ) + 1 - β := by linarith
  have hb := Real.exp_le_exp.mpr (logGamma_ratio_upper_following hβ
    (by linarith : β < (j : ℝ) + 1))
  rw [Real.exp_sub, Real.exp_log (Real.Gamma_pos_of_pos (by linarith : 0 < (j : ℝ) + 1)),
    Real.exp_log (Real.Gamma_pos_of_pos hden), Real.Gamma_nat_eq_factorial] at hb
  exact hb.trans_eq (by rw [Real.rpow_def_of_pos (by positivity : 0 < (j : ℝ) + 1)]; congr 1; ring)

/-- At positive counts the relative small-order discrepancy is uniformly linear in the order. -/
theorem analyticCount_small_order_positive_error {β : ℝ} (hβ : 0 < β) (hβ1 : β ≤ 1 / 2)
    (j : ℕ) (hj : 1 ≤ j) :
    |analyticCount β j - ((j : ℝ) + 1) ^ β| ≤
      β * Real.log 4 * ((j : ℝ) + 1) ^ β := by
  have hj1 : 1 ≤ (j : ℝ) := by exact_mod_cast hj
  have hjpos : 0 < (j : ℝ) + 1 := by linarith
  have hsmall : β < (j : ℝ) := by linarith
  have hden : 0 < (j : ℝ) + 1 - β := by linarith
  have hlog : Real.log ((j : ℝ) + 1) - Real.log 4 ≤ Real.log ((j : ℝ) - β) := by
    rw [← Real.log_div (by positivity : (j : ℝ) + 1 ≠ 0) (by norm_num : (4 : ℝ) ≠ 0)]
    exact Real.log_le_log (by positivity) (by linarith)
  have hlo := (mul_le_mul_of_nonneg_left hlog hβ.le).trans (logGamma_ratio_lower hβ hsmall)
  have hb := Real.exp_le_exp.mpr hlo
  rw [Real.exp_sub, Real.exp_log (Real.Gamma_pos_of_pos (by linarith : 0 < (j : ℝ) + 1)),
    Real.exp_log (Real.Gamma_pos_of_pos hden), Real.Gamma_nat_eq_factorial] at hb
  have heq : Real.exp (β * (Real.log ((j : ℝ) + 1) - Real.log 4)) =
      Real.exp (-(β * Real.log 4)) * ((j : ℝ) + 1) ^ β := by
    rw [Real.rpow_def_of_pos hjpos, ← Real.exp_add]
    congr 1
    ring
  rw [heq] at hb
  change Real.exp (-(β * Real.log 4)) * ((j : ℝ) + 1) ^ β ≤ analyticCount β j at hb
  have hexp := Real.add_one_le_exp (-(β * Real.log 4))
  have hp : 0 ≤ ((j : ℝ) + 1) ^ β := Real.rpow_nonneg (by positivity) _
  have hmul := mul_le_mul_of_nonneg_right hexp hp
  have hup := analyticCount_small_order_upper hβ hβ1 j
  rw [abs_of_nonpos (sub_nonpos.mpr hup)]
  nlinarith

/-- At count zero, convexity of log Gamma gives the same uniform first-order behavior. -/
theorem analyticCount_small_order_zero_error {β : ℝ} (hβ : 0 < β) (hβ1 : β ≤ 1 / 2) :
    |analyticCount β 0 - 1| ≤ 2 * β * Real.log (Real.Gamma (1 / 2)) := by
  have hGpos : 0 < Real.Gamma (1 - β) := Real.Gamma_pos_of_pos (by linarith)
  have hG := gamma_one_le_of_pos_le_one (by linarith : 0 < 1 - β) (by linarith : 1 - β ≤ 1)
  have hc := Real.convexOn_log_Gamma.2
    (by norm_num : (1 / 2 : ℝ) ∈ Ioi (0 : ℝ)) (by norm_num : (1 : ℝ) ∈ Ioi (0 : ℝ))
    (by positivity : 0 ≤ 2 * β) (by linarith : 0 ≤ 1 - 2 * β)
    (by ring : 2 * β + (1 - 2 * β) = 1)
  simp only [smul_eq_mul, Function.comp_apply, Real.Gamma_one, Real.log_one, mul_zero, add_zero] at hc
  rw [show 2 * β * (1 / 2) + (1 - 2 * β) * 1 = 1 - β by ring] at hc
  have hb := Real.exp_le_exp.mpr (neg_le_neg hc)
  have hi : Real.exp (-Real.log (Real.Gamma (1 - β))) = (Real.Gamma (1 - β))⁻¹ := by
    rw [Real.exp_neg, Real.exp_log hGpos]
  rw [hi] at hb
  have hexp := Real.add_one_le_exp (-(2 * β * Real.log (Real.Gamma (1 / 2))))
  have hup : (Real.Gamma (1 - β))⁻¹ ≤ 1 := (inv_le_one₀ hGpos).mpr hG
  simp only [analyticCount, Nat.factorial_zero, Nat.cast_one, Nat.cast_zero, zero_add, one_div]
  rw [abs_of_nonpos (sub_nonpos.mpr hup)]
  linarith

def smallOrderRatioConstant : ℝ := Real.log 4 + 2 * Real.log (Real.Gamma (1 / 2))

/-- The actual Gamma-ratio estimate required in the order-one noise proposition. -/
theorem analyticCount_small_order_error {β : ℝ} (hβ : 0 < β) (hβ1 : β ≤ 1 / 2)
    (j : ℕ) :
    |analyticCount β j - ((j : ℝ) + 1) ^ β| ≤
      smallOrderRatioConstant * β * ((j : ℝ) + 1) ^ β := by
  have hlog4 : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
  have hlogG : 0 ≤ Real.log (Real.Gamma (1 / 2)) :=
    Real.log_nonneg (gamma_one_le_of_pos_le_one (by norm_num) (by norm_num))
  cases j with
  | zero =>
      have h := analyticCount_small_order_zero_error hβ hβ1
      simp only [Nat.cast_zero, zero_add, Real.one_rpow, mul_one]
      apply h.trans
      dsimp [smallOrderRatioConstant]
      nlinarith
  | succ j =>
      have h := analyticCount_small_order_positive_error hβ hβ1 (j + 1) (by omega)
      apply h.trans
      have hp : 0 ≤ (((j + 1 : ℕ) : ℝ) + 1) ^ β := Real.rpow_nonneg (by positivity) _
      dsimp [smallOrderRatioConstant]
      have ht : 0 ≤ 2 * Real.log (Real.Gamma (1 / 2)) * β *
          ((((j + 1 : ℕ) : ℝ) + 1) ^ β) := by positivity
      nlinarith

/-- An elementary global exponential difference bound. -/
theorem abs_exp_sub_le_sum_mul_abs (u v : ℝ) :
    |Real.exp u - Real.exp v| ≤ (Real.exp u + Real.exp v) * |u - v| := by
  have hcase (u v : ℝ) (huv : u ≤ v) :
      |Real.exp u - Real.exp v| ≤ (Real.exp u + Real.exp v) * |u - v| := by
    have h := mul_le_mul_of_nonneg_left (Real.add_one_le_exp (u - v)) (Real.exp_pos v).le
    have hid : Real.exp v * Real.exp (u - v) = Real.exp u := by rw [← Real.exp_add]; congr 1; ring
    rw [hid] at h
    have hprod : 0 ≤ Real.exp u * (v - u) := mul_nonneg (Real.exp_pos _).le (sub_nonneg.mpr huv)
    rw [abs_of_nonpos (sub_nonpos.mpr (Real.exp_le_exp.mpr huv)), abs_of_nonpos (sub_nonpos.mpr huv)]
    nlinarith
  rcases le_total u v with h | h
  · exact hcase u v h
  · simpa only [abs_sub_comm (Real.exp v) (Real.exp u), abs_sub_comm v u, add_comm] using hcase v u h

/-- A real-power divided difference controlled by the logarithmic distance. -/
theorem abs_rpow_sub_le_sum_mul_log {x y β : ℝ} (hx : 0 < x) (hy : 0 < y) (hβ : 0 ≤ β) :
    |x ^ β - y ^ β| ≤ β * (x ^ β + y ^ β) * |Real.log (x / y)| := by
  have h := abs_exp_sub_le_sum_mul_abs (Real.log x * β) (Real.log y * β)
  rw [show Real.log x * β - Real.log y * β = (Real.log x - Real.log y) * β by ring,
    abs_mul, abs_of_nonneg hβ, ← Real.log_div hx.ne' hy.ne'] at h
  rw [Real.rpow_def_of_pos hx, Real.rpow_def_of_pos hy]
  convert h using 1
  ring

def smallOrderStepConstant : ℝ := 2 * smallOrderRatioConstant + 2

theorem smallOrderRatioConstant_nonneg : 0 ≤ smallOrderRatioConstant := by
  have hlog4 : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
  have hlogG : 0 ≤ Real.log (Real.Gamma (1 / 2)) :=
    Real.log_nonneg (gamma_one_le_of_pos_le_one (by norm_num) (by norm_num))
  dsimp [smallOrderRatioConstant]
  positivity

theorem smallOrderStepConstant_ge_two : 2 ≤ smallOrderStepConstant := by
  dsimp [smallOrderStepConstant]
  linarith [smallOrderRatioConstant_nonneg]

/-- The actual order-one count increment has the required logarithmic envelope. -/
theorem analyticCount_order_one_increment {β B : ℝ} (hβ : 0 < β) (hβ1 : β ≤ 1 / 2)
    (hB : 0 < B) (j : ℕ) :
    |((1 + β) * analyticCount β j - B ^ β) / β| ≤
      smallOrderStepConstant * (((j : ℝ) + 1) ^ β + B ^ β) *
        (1 + |Real.log (((j : ℝ) + 1) / B)|) := by
  let p := ((j : ℝ) + 1) ^ β
  let z := B ^ β
  let t := |Real.log (((j : ℝ) + 1) / B)|
  have hp : 0 ≤ p := Real.rpow_nonneg (by positivity) _
  have hz : 0 ≤ z := (Real.rpow_pos_of_pos hB β).le
  have ht : 0 ≤ t := abs_nonneg _
  have hK := smallOrderRatioConstant_nonneg
  have hD := smallOrderStepConstant_ge_two
  have hr := analyticCount_small_order_error hβ hβ1 j
  have hpow := abs_rpow_sub_le_sum_mul_log (by positivity : 0 < (j : ℝ) + 1) hB hβ.le
  have haff : |(1 + β) * analyticCount β j - p| ≤
      ((1 + β) * smallOrderRatioConstant + 1) * β * p := by
    have heq : (1 + β) * analyticCount β j - p =
        (1 + β) * (analyticCount β j - p) + β * p := by ring
    rw [heq]
    apply (abs_add_le _ _).trans
    rw [abs_mul, abs_of_nonneg (by linarith : 0 ≤ 1 + β),
      abs_of_nonneg (mul_nonneg hβ.le hp)]
    have hmul := mul_le_mul_of_nonneg_left hr (by linarith : 0 ≤ 1 + β)
    change (1 + β) * |analyticCount β j - p| ≤ (1 + β) * (smallOrderRatioConstant * β * p) at hmul
    linarith
  have hcoef : (1 + β) * smallOrderRatioConstant + 1 ≤ smallOrderStepConstant := by
    dsimp [smallOrderStepConstant]
    nlinarith
  have haff' : |(1 + β) * analyticCount β j - p| ≤ smallOrderStepConstant * β * p :=
    haff.trans (by gcongr)
  have hraw : |(1 + β) * analyticCount β j - z| ≤
      smallOrderStepConstant * β * (p + z) * (1 + t) := by
    have htri := abs_sub_le ((1 + β) * analyticCount β j) p z
    have hbase : smallOrderStepConstant * β * p ≤ smallOrderStepConstant * β * (p + z) := by gcongr; linarith
    have hterm : β * (p + z) * t ≤ smallOrderStepConstant * β * (p + z) * t := by
      have hprod : 0 ≤ β * (p + z) * t := by positivity
      nlinarith
    change |p - z| ≤ β * (p + z) * t at hpow
    nlinarith
  change |((1 + β) * analyticCount β j - z) / β| ≤ _
  rw [abs_div, abs_of_pos hβ]
  apply (div_le_iff₀ hβ).mpr
  convert hraw using 1
  ring

end Renyi
