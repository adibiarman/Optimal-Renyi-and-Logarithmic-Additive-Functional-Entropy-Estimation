import Renyi.CoupledProfileBounds
import Renyi.CoupledNormalizerBounds
import Renyi.DegreeOneProfile

/-! Quantitative deficits for the actual raised low endpoint profile. -/
noncomputable section
open Set
namespace Renyi

def lowDeficitLocalScale (f : ℝ) : ℝ :=
  max 1 (max (16/((1-f)/256)^2) (2*(Real.log 24+1)/((1-f)/256)))

lemma exp_le_one_add_twice {t : ℝ} (ht : 0≤t) (ht1 : t≤1/2) :
    Real.exp t≤1+2*t := by
  have he := Real.exp_bound_div_one_sub_of_interval ht (by linarith : t<1)
  apply he.trans
  apply (div_le_iff₀ (by linarith : 0<1-t)).mpr
  nlinarith only [mul_nonneg ht (show 0≤1-2*t by linarith)]

lemma coupled_bump_upper_kernel {N d : ℕ} (hN : 0<N) (hd : d≤6)
    {s b x : ℝ} {H : ℝ → ℝ} (hs : 0<s) (hs1 : s≤1) (hb : b<1)
    (hH : ∀ x ∈ Icc (0:ℝ) 1, 0≤H x ∧ H x≤b) (hx : 0≤x) (_hx1 : x≤1) :
    x^s*endpointKernel N d x/coupledNormalizer s (endpointKernel N d) H≤
      Real.exp ((Real.log 24+1)*s)*((N:ℝ)^2*x/s)^s*endpointKernel N d x := by
  have hK := fun y (hy : y ∈ Icc (0:ℝ) 1) =>
    And.intro (endpointKernel_nonneg N d y) (endpointKernel_le_one hN d hy.1 hy.2)
  have ha := coupledNormalizer_pos hs.le hb hK (fun y hy => (hH y hy).2)
    (endpointKernel_positive_witness hN hd)
  have hl := coupledNormalizer_sharp_lower hN hd hs hs1 hb hH
  have hm := mul_le_mul_of_nonneg_left hl
    (show 0≤Real.exp ((Real.log 24+1)*s)*((N:ℝ)^2*x/s)^s by positivity)
  rw [coupled_sharp_scale_identity hN hs hx] at hm
  have hmK := mul_le_mul_of_nonneg_right hm (endpointKernel_nonneg N d x)
  apply (div_le_iff₀ ha).mpr
  nlinarith only [hmK]

lemma lowProfile_bump_comparison {N : ℕ} (hN : 0<N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1) :
    lowProfile N s f x≤
      Real.exp ((Real.log 24+1)*s)*((N:ℝ)^2*x/s)^s*endpointKernel N 2 x+
        f*(1-endpointKernel N 2 x) := by
  have hbump := coupled_bump_upper_kernel (d:=2) hN (by norm_num) hs hs1 hf1
    (fun _y hy => lowShoulder_range hN hs hf hy.1 hy.2) hx hx1
  have hshoulder := lowShoulder_kernel_bound hN hs hf hx hx1
  unfold lowProfile coupledProfile
  exact add_le_add hbump hshoulder

/-- Actual low-profile deficit in the endpoint neighborhood. -/
theorem lowProfile_local_deficit {N : ℕ} (hN : 2≤N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1)
    (hy : lowDeficitLocalScale f*s≤(N:ℝ)^2*x) (hy1 : (N:ℝ)^2*x≤1/24) :
    ((1-f)/128)*((N:ℝ)^2*x)≤1-lowProfile N s f x := by
  let y : ℝ := (N:ℝ)^2*x
  let v : ℝ := y/s
  let d : ℝ := (1-f)/256
  let B : ℝ := Real.log 24+1
  let E : ℝ := s*(B+Real.log v)
  have hρ : 0<1-f := by linarith
  have hρ1 : 1-f≤1 := by linarith
  have hd : 0<d := by dsimp [d];positivity
  have hB : 0<B := by have hl := Real.log_nonneg (by norm_num : (1:ℝ)≤24);dsimp [B];linarith
  have hv1 : 1≤v := by
    apply (le_div_iff₀ hs).mpr
    have hscale : 1≤lowDeficitLocalScale f := le_max_left _ _
    have hm := mul_le_mul_of_nonneg_right hscale hs.le
    exact hm.trans hy
  have hv : 0<v := zero_lt_one.trans_le hv1
  have hlog := log_add_two_le_linear hv hd (show 16/d^2≤v by
    apply (le_div_iff₀ hs).mpr
    have hscale : 16/d^2≤lowDeficitLocalScale f :=
      (le_max_left _ _).trans (le_max_right _ _)
    exact (mul_le_mul_of_nonneg_right hscale hs.le).trans hy)
  have hBscale : 2*B/d≤v := by
    apply (le_div_iff₀ hs).mpr
    have hscale : 2*B/d≤lowDeficitLocalScale f := (le_max_right _ _).trans (le_max_right _ _)
    exact (mul_le_mul_of_nonneg_right hscale hs.le).trans hy
  have hBv : B≤d*v/2 := by
    have hm := (div_le_iff₀ hd).mp hBscale
    nlinarith only [hm]
  have hbudget : E≤d*y := by
    have hm := mul_le_mul_of_nonneg_left (show B+Real.log v≤d*v by linarith only [hlog,hBv]) hs.le
    have hid : s*v=y := by dsimp [v];field_simp
    change s*(B+Real.log v)≤d*y
    calc
      _ ≤ s*(d*v) := hm
      _ = d*(s*v) := by ring
      _ = _ := by rw [hid]
  have hE0 : 0≤E := mul_nonneg hs.le (add_nonneg hB.le (Real.log_nonneg hv1))
  have hy0 : 0≤y := by dsimp [y];positivity
  have hρy : (1-f)*y≤y := by nlinarith only [mul_le_mul_of_nonneg_right hρ1 hy0]
  have hEhalf : E≤1/2 := by dsimp [d] at hbudget; nlinarith only [hbudget,hρy,hy1]
  have hexp := exp_le_one_add_twice hE0 hEhalf
  have hK0 := endpointKernel_nonneg N 2 x
  have hK1 := endpointKernel_le_one (by omega : 0<N) 2 hx hx1
  have hKexp := endpointKernel_local_exp_upper hN (by norm_num : 1≤2) hx hx1 (by linarith only [hy1])
  have hKlin : y/64≤1-endpointKernel N 2 x := by
    have he := endpoint_exp_neg_le_half (show 0≤y/32 by positivity) (show y/32≤1 by linarith only [hy1])
    change endpointKernel N 2 x≤Real.exp (-y/32) at hKexp
    have heq : Real.exp (-(y/32))=Real.exp (-y/32) := by congr 1;ring
    rw [heq] at he
    nlinarith only [hKexp,he]
  have hcmp := lowProfile_bump_comparison (by omega : 0<N) hs hs1 hf hf1 hx hx1
  have hidexp : Real.exp ((Real.log 24+1)*s)*((N:ℝ)^2*x/s)^s=Real.exp E := by
    rw [Real.rpow_def_of_pos hv,←Real.exp_add]
    congr 1
    dsimp [E,B,v,y]
    ring
  rw [hidexp] at hcmp
  have hexpK := mul_le_mul_of_nonneg_right hexp hK0
  have hEK : 2*E*endpointKernel N 2 x≤2*E := mul_le_of_le_one_right (by positivity) hK1
  have hgap := mul_le_mul_of_nonneg_left hKlin hρ.le
  dsimp [d] at hbudget
  nlinarith only [hcmp,hexpK,hEK,hgap,hbudget]

lemma endpointKernel_interpolated_ratio {N d : ℕ} (hN : 2≤N) (hd : 2≤d)
    {s a x : ℝ} (hs : 0<s) (ha : 0<a) (hsa : s≤a) (hx : 0≤x) (hx1 : x≤1) :
    ((N:ℝ)^2*x/s)^s*endpointKernel N d x≤(32/a)^s*(endpointKernel N d x)^(1-a) := by
  have hK := endpointKernel_nonneg N d x
  have ht := div_pos hs ha
  have ht1 := (div_le_one ha).mpr hsa
  have hraw := endpointKernel_sharp_weight_upper hN hd ht ht1 hx hx1
  have hraise := Real.rpow_le_rpow (show 0≤(N:ℝ)^(2*(s/a))*(x^(s/a)*endpointKernel N d x) by positivity) hraw ha.le
  have hleft : ((N:ℝ)^(2*(s/a))*(x^(s/a)*endpointKernel N d x))^a =
      (N:ℝ)^(2*s)*(x^s*(endpointKernel N d x)^a) := by
    rw [Real.mul_rpow (by positivity) (by positivity),Real.mul_rpow (by positivity) hK,
      ←Real.rpow_mul (by positivity : 0≤(N:ℝ)),←Real.rpow_mul hx]
    have hid : (s/a)*a=s := by field_simp
    have hid2 : (2*(s/a))*a=2*s := by field_simp
    rw [hid,hid2]
  have hright : ((32*(s/a))^(s/a))^a=(32*(s/a))^s := by
    rw [←Real.rpow_mul (by positivity)]
    congr 1
    field_simp
  rw [hleft,hright] at hraise
  have hm := mul_le_mul_of_nonneg_right hraise (Real.rpow_nonneg hK (1-a))
  have hKprod : (endpointKernel N d x)^a*(endpointKernel N d x)^(1-a)=endpointKernel N d x := by
    rw [←Real.rpow_add' hK (show a+(1-a)≠0 by ring_nf;norm_num)]
    simp
  have hweighted : (N:ℝ)^(2*s)*(x^s*endpointKernel N d x)≤
      (32*(s/a))^s*(endpointKernel N d x)^(1-a) := by
    calc
      _ = (N:ℝ)^(2*s)*(x^s*((endpointKernel N d x)^a*(endpointKernel N d x)^(1-a))) := by rw [hKprod]
      _ = ((N:ℝ)^(2*s)*(x^s*(endpointKernel N d x)^a))*(endpointKernel N d x)^(1-a) := by ring
      _ ≤ _ := hm
  have hsp : 0<s^s := Real.rpow_pos_of_pos hs s
  have hy : 0≤(N:ℝ)^2*x/s := by positivity
  apply (mul_le_mul_iff_right₀ hsp).mp
  calc
    _ = ((N:ℝ)^2*x)^s*endpointKernel N d x := by
      rw [←mul_assoc,←Real.mul_rpow hs.le hy]
      have hid : s*((N:ℝ)^2*x/s)=(N:ℝ)^2*x := by field_simp
      rw [hid]
    _ = (N:ℝ)^(2*s)*(x^s*endpointKernel N d x) := by rw [←endpoint_scale_power (by omega : 0<N) hx];ring
    _ ≤ (32*(s/a))^s*(endpointKernel N d x)^(1-a) := hweighted
    _ = _ := by
      rw [←mul_assoc,←Real.mul_rpow hs.le (show 0≤32/a by positivity)]
      congr 2
      ring

lemma lowProfile_interpolated_upper {N : ℕ} (hN : 2≤N) {s a f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (ha : 0<a) (hsa : s≤a)
    (hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1) :
    lowProfile N s f x≤Real.exp ((Real.log 24+1+Real.log (32/a))*s)*(endpointKernel N 2 x)^(1-a)+
      f*(1-endpointKernel N 2 x) := by
  have hcmp := lowProfile_bump_comparison (by omega : 0<N) hs hs1 hf hf1 hx hx1
  have hratio := endpointKernel_interpolated_ratio hN (by norm_num : 2≤2) hs ha hsa hx hx1
  have hm := mul_le_mul_of_nonneg_left hratio (Real.exp_pos ((Real.log 24+1)*s)).le
  have hid : Real.exp ((Real.log 24+1)*s)*(32/a)^s=
      Real.exp ((Real.log 24+1+Real.log (32/a))*s) := by
    rw [Real.rpow_def_of_pos (by positivity : 0<32/a),←Real.exp_add]
    congr 1
    ring
  rw [←mul_assoc (Real.exp ((Real.log 24+1)*s)) ((32/a)^s) ((endpointKernel N 2 x)^(1-a)),hid] at hm
  nlinarith only [hcmp,hm]

def lowDeficitTilt (f : ℝ) : ℝ := (1-f)/4
def lowDeficitRate (f : ℝ) : ℝ := Real.log 24+1+Real.log (32/lowDeficitTilt f)
def lowDeficitKernelGap : ℝ := 1-Real.exp (-(1:ℝ)/768)
def lowDeficitOrder (f : ℝ) : ℝ := min (lowDeficitTilt f)
  (min (1/(2*lowDeficitRate f)) ((1-f)*lowDeficitKernelGap/(8*lowDeficitRate f)))
def lowDeficitOuterConstant (f : ℝ) : ℝ := (1-f)*lowDeficitKernelGap/2

theorem lowDeficitKernelGap_pos : 0<lowDeficitKernelGap := by
  unfold lowDeficitKernelGap
  have he := Real.exp_lt_one_iff.mpr (by norm_num : -(1:ℝ)/768<0)
  linarith only [he]

lemma lowDeficitRate_pos {f : ℝ} (hf : 0≤f) (hf1 : f<1) : 0<lowDeficitRate f := by
  have ha : 0<lowDeficitTilt f := by unfold lowDeficitTilt;linarith
  have ha1 : lowDeficitTilt f≤1 := by unfold lowDeficitTilt;linarith
  have hb : 1≤32/lowDeficitTilt f := by
    apply (le_div_iff₀ ha).mpr
    linarith only [ha1]
  have hlog := Real.log_nonneg hb
  have hlog24 := Real.log_nonneg (by norm_num : (1:ℝ)≤24)
  unfold lowDeficitRate
  linarith only [hlog,hlog24]

theorem lowDeficitOrder_pos {f : ℝ} (hf : 0≤f) (hf1 : f<1) : 0<lowDeficitOrder f := by
  have ha : 0<lowDeficitTilt f := by unfold lowDeficitTilt;linarith
  have hr := lowDeficitRate_pos hf hf1
  unfold lowDeficitOrder
  exact lt_min ha (lt_min (by positivity) (div_pos (mul_pos (by linarith : 0<1-f) lowDeficitKernelGap_pos) (by positivity)))

theorem lowDeficitOuterConstant_pos {f : ℝ} (hf1 : f<1) : 0<lowDeficitOuterConstant f := by
  unfold lowDeficitOuterConstant
  exact div_pos (mul_pos (by linarith) lowDeficitKernelGap_pos) (by norm_num)

/-- A fixed low-profile deficit outside the endpoint neighborhood, uniformly for small orders. -/
theorem lowProfile_outer_deficit {N : ℕ} (hN : 2≤N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1)
    (hsmall : s≤lowDeficitOrder f) (hy : (1/24:ℝ)≤(N:ℝ)^2*x) :
    lowDeficitOuterConstant f≤1-lowProfile N s f x := by
  let a : ℝ := lowDeficitTilt f
  let K : ℝ := endpointKernel N 2 x
  let E : ℝ := lowDeficitRate f*s
  let S : ℝ := (1-a)*K+a
  have ha : 0<a := by dsimp [a,lowDeficitTilt];linarith
  have ha1 : a≤1 := by dsimp [a,lowDeficitTilt];linarith
  have hsa : s≤a := hsmall.trans (min_le_left _ _)
  have hrate := lowDeficitRate_pos hf hf1
  have hE0 : 0≤E := mul_nonneg hrate.le hs.le
  have hrate1 : s≤1/(2*lowDeficitRate f) :=
    hsmall.trans ((min_le_right _ _).trans (min_le_left _ _))
  have hrate2 : s≤(1-f)*lowDeficitKernelGap/(8*lowDeficitRate f) :=
    hsmall.trans ((min_le_right _ _).trans (min_le_right _ _))
  have hEhalf : E≤1/2 := by
    have hm := (le_div_iff₀ (mul_pos (by norm_num : (0:ℝ)<2) hrate)).mp hrate1
    dsimp [E]
    nlinarith only [hm]
  have hEbudget : 2*E≤(1-f)*lowDeficitKernelGap/4 := by
    have hm := (le_div_iff₀ (mul_pos (by norm_num : (0:ℝ)<8) hrate)).mp hrate2
    dsimp [E]
    nlinarith only [hm]
  have hxpos : 0<x := by
    by_contra hn
    have hm := mul_nonpos_of_nonneg_of_nonpos (sq_nonneg (N:ℝ)) (le_of_not_gt hn)
    nlinarith only [hm,hy]
  have hK0 : 0≤K := endpointKernel_nonneg N 2 x
  have hK1 : K≤1 := endpointKernel_le_one (by omega : 0<N) 2 hx hx1
  have hKg : lowDeficitKernelGap≤1-K := by
    have hk := endpointKernel_uniform_gap_scale (d:=2) hN (by norm_num) hxpos hx1
      (by norm_num : (0:ℝ)<1/24) (by norm_num : (1/24:ℝ)≤1) hy
    have heq : -(1/24:ℝ)/32=-(1:ℝ)/768 := by norm_num
    rw [heq] at hk
    unfold lowDeficitKernelGap
    dsimp [K]
    linarith only [hk]
  have hAM := Real.geom_mean_le_arith_mean2_weighted (sub_nonneg.mpr ha1) ha.le hK0
    (by norm_num : (0:ℝ)≤1) (show (1-a)+a=1 by ring)
  simp only [Real.one_rpow,mul_one] at hAM
  have hS0 : 0≤S := (Real.rpow_nonneg hK0 (1-a)).trans hAM
  have hS1 : S≤1 := by dsimp [S];nlinarith only [mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hK1)]
  have hcmp := lowProfile_interpolated_upper hN hs hs1 ha hsa hf hf1 hx hx1
  change lowProfile N s f x≤Real.exp E*K^(1-a)+f*(1-K) at hcmp
  have hAMexp := mul_le_mul_of_nonneg_left hAM (Real.exp_pos E).le
  have hexpS := mul_le_mul_of_nonneg_right (exp_le_one_add_twice hE0 hEhalf) hS0
  have hES : 2*E*S≤2*E := mul_le_of_le_one_right (by positivity) hS1
  have hρa : 1-f-a=3*(1-f)/4 := by dsimp [a,lowDeficitTilt];ring
  have hρapos : 0≤1-f-a := by linarith only [hρa,hf1]
  have hgap := mul_le_mul_of_nonneg_left hKg hρapos
  have hρag := congrArg (fun z:ℝ => z*lowDeficitKernelGap) hρa
  unfold lowDeficitOuterConstant
  dsimp [S] at hexpS hES
  nlinarith only [hcmp,hAMexp,hexpS,hES,hEbudget,hgap,hρag]

def lowDeficitConstant (f : ℝ) : ℝ := min ((1-f)/128) (lowDeficitOuterConstant f)

theorem lowDeficitConstant_pos {f : ℝ} (hf1 : f<1) : 0<lowDeficitConstant f := by
  unfold lowDeficitConstant
  exact lt_min (by linarith) (lowDeficitOuterConstant_pos hf1)

/-- Complete actual low-profile deficit, uniform in the order and endpoint resolution. -/
theorem lowProfile_deficit {N : ℕ} (hN : 2≤N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1)
    (hsmall : s≤lowDeficitOrder f) (hy : lowDeficitLocalScale f*s≤(N:ℝ)^2*x) :
    lowDeficitConstant f*min ((N:ℝ)^2*x) 1≤1-lowProfile N s f x := by
  by_cases hlocal : (N:ℝ)^2*x≤1/24
  · have hgap := lowProfile_local_deficit hN hs hs1 hf hf1 hx hx1 hy hlocal
    have hy1 : (N:ℝ)^2*x≤1 := by linarith only [hlocal]
    rw [min_eq_left hy1]
    exact (mul_le_mul_of_nonneg_right (min_le_left _ _) (show 0≤(N:ℝ)^2*x by positivity)).trans hgap
  · have hgap := lowProfile_outer_deficit hN hs hs1 hf hf1 hx hx1 hsmall (le_of_lt (lt_of_not_ge hlocal))
    have hscale : lowDeficitConstant f*min ((N:ℝ)^2*x) 1≤lowDeficitConstant f :=
      mul_le_of_le_one_right (lowDeficitConstant_pos hf1).le (min_le_right _ _)
    exact (hscale.trans (min_le_right _ _)).trans hgap

/-- Quantified source form: all constants are fixed once the floor parameter is fixed. -/
theorem lowProfile_deficit_uniform {f : ℝ} (hf : 0≤f) (hf1 : f<1) :
    ∃ s0 C c : ℝ, 0<s0 ∧ 0<C ∧ 0<c ∧
      ∀ (N:ℕ) (s x:ℝ), 2≤N → 0<s → s≤1 → s≤s0 → 0≤x → x≤1 →
        C*s≤(N:ℝ)^2*x → c*min ((N:ℝ)^2*x) 1≤1-lowProfile N s f x := by
  refine ⟨lowDeficitOrder f,lowDeficitLocalScale f,lowDeficitConstant f,
    lowDeficitOrder_pos hf hf1,?_,lowDeficitConstant_pos hf1,?_⟩
  · exact zero_lt_one.trans_le (le_max_left _ _)
  · intro N s x hN hs hs1 hsmall hx hx1 hy
    exact lowProfile_deficit hN hs hs1 hf hf1 hx hx1 hsmall hy

end Renyi
