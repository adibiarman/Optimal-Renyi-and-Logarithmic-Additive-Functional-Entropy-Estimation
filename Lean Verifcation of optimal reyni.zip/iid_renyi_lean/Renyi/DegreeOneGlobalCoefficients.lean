import Renyi.DegreeOnePolynomialCoefficients
import Renyi.CoupledCoefficientExponential

/-! Global coefficient budget for the degree-one completed polynomial. -/
noncomputable section
open Polynomial
namespace Renyi

theorem degreeOneCoupledPolynomial_scaled_coefficientMass {N m : ℕ}
    (hm : 1≤m) {γ a b c f A B ω : ℝ}
    (hγ : 0<γ) (hc : 0<c)
    (ha : 0 ≤ a) (hab : a ≤ b) (hb : 0 < b)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) :
    coefficientMass ((degreeOneCoupledPolynomial N m γ (c*a*(1+γ)/γ) b f ω A B).comp (C b*X)) ≤
      A*a^γ*b^m*coefficientMass (degreeOneLowPolynomial γ c)*
        (1+coefficientMass (endpointProfilePolynomial N 6 1)) +
      (B/b^(1-γ))*b^(m+1)*coefficientMass (highProfilePolynomial N (1-γ) f ω) +
      (ω*(1-B)/b^(1-γ))*b^(m+1)*coefficientMass (endpointProfilePolynomial N 6 (1-γ)) := by
  have hbpow := Real.rpow_pos_of_pos hb (1-γ)
  have hrev := reverseScaledPolynomial_comp_coefficientMass (degreeOneLowPolynomial γ c)
    ((degreeOneLowPolynomial_natDegree γ c).trans hm) ha hab
  have hcut : coefficientMass (1-X*endpointProfilePolynomial N 6 1) ≤
      1+coefficientMass (endpointProfilePolynomial N 6 1) := by
    have hm := coefficientMass_mul_le X (endpointProfilePolynomial N 6 1)
    simp only [coefficientMass_X, one_mul] at hm
    exact (coefficientMass_sub_le _ _).trans (by simpa using add_le_add_left hm 1)
  have hlow := (coefficientMass_mul_le
    (C (A*a^γ)*(reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a).comp (C b*X))
    (1-X*endpointProfilePolynomial N 6 1)).trans
    (mul_le_mul (show coefficientMass (C (A*a^γ)*(reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a).comp (C b*X)) ≤
      A*a^γ*(coefficientMass (degreeOneLowPolynomial γ c)*b^m) by
      rw [coefficientMass_C_mul, abs_of_nonneg (mul_nonneg hA (Real.rpow_nonneg ha γ))]
      exact mul_le_mul_of_nonneg_left hrev (mul_nonneg hA (Real.rpow_nonneg ha γ))) hcut
      (coefficientMass_nonneg _)
      (mul_nonneg (mul_nonneg hA (Real.rpow_nonneg ha γ))
        (mul_nonneg (coefficientMass_nonneg _) (pow_nonneg hb.le m))))
  have hpow := coefficientMass_scaled_power hb.le (m+1)
  have hhigh := (coefficientMass_mul_le
    (C (B/b^(1-γ))*(C b*X)^(m+1)) (highProfilePolynomial N (1-γ) f ω)).trans
    (mul_le_mul_of_nonneg_right (show coefficientMass (C (B/b^(1-γ))*(C b*X)^(m+1)) ≤
      (B/b^(1-γ))*b^(m+1) by
      rw [coefficientMass_C_mul, abs_of_nonneg (div_nonneg hB hbpow.le)]
      exact mul_le_mul_of_nonneg_left hpow (div_nonneg hB hbpow.le)) (coefficientMass_nonneg _))
  have hrest := (coefficientMass_mul_le
    (C (ω*(1-B)/b^(1-γ))*(C b*X)^(m+1)) (endpointProfilePolynomial N 6 (1-γ))).trans
    (mul_le_mul_of_nonneg_right (show coefficientMass (C (ω*(1-B)/b^(1-γ))*(C b*X)^(m+1)) ≤
      (ω*(1-B)/b^(1-γ))*b^(m+1) by
      rw [coefficientMass_C_mul, abs_of_nonneg (div_nonneg (mul_nonneg hω (sub_nonneg.mpr hB1)) hbpow.le)]
      exact mul_le_mul_of_nonneg_left hpow (div_nonneg (mul_nonneg hω (sub_nonneg.mpr hB1)) hbpow.le))
      (coefficientMass_nonneg _))
  rw [degreeOneCoupledPolynomial_reverse hm hγ hc ha]
  simp only [add_comp, mul_comp, C_comp, pow_comp, X_comp, sub_comp, one_comp,
    comp_assoc, inverse_scale_comp hb.ne', comp_X]
  have hs1 := coefficientMass_add_le
    (C (A*a^γ)*(reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a).comp (C b*X)*(1-X*endpointProfilePolynomial N 6 1))
    (C (B/b^(1-γ))*(C b*X)^(m+1)*highProfilePolynomial N (1-γ) f ω)
  have hs2 := coefficientMass_add_le
    (C (A*a^γ)*(reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a).comp (C b*X)*(1-X*endpointProfilePolynomial N 6 1) +
      C (B/b^(1-γ))*(C b*X)^(m+1)*highProfilePolynomial N (1-γ) f ω)
    (C (ω*(1-B)/b^(1-γ))*(C b*X)^(m+1)*endpointProfilePolynomial N 6 (1-γ))
  nlinarith

theorem degreeOneCoupledPolynomial_scaled_mass_factored {N m : ℕ}
    (hm : 1≤m) {γ a b c f A B ω : ℝ}
    (hγ : 0<γ) (hc : 0<c)
    (ha : 0 ≤ a) (hab : a ≤ b) (hb : 0 < b)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) :
    coefficientMass ((degreeOneCoupledPolynomial N m γ (c*a*(1+γ)/γ) b f ω A B).comp (C b*X)) ≤
      b^((m:ℝ)+γ) *
        (A*(a/b)^γ*coefficientMass (degreeOneLowPolynomial γ c)*
          (1+coefficientMass (endpointProfilePolynomial N 6 1)) +
        B*coefficientMass (highProfilePolynomial N (1-γ) f ω) +
        ω*(1-B)*coefficientMass (endpointProfilePolynomial N 6 (1-γ))) := by
  have h := degreeOneCoupledPolynomial_scaled_coefficientMass (N:=N) (γ:=γ) (c:=c) (f:=f) hm hγ hc ha hab hb hA hB hB1 hω
  have hr := reverse_fractional_identity m γ ha hb
  have hf : b^((m:ℝ)+γ)=b^(m+1)/b^(1-γ) := by
    simpa [hb.ne'] using forward_fractional_identity m γ hb hb
  apply h.trans_eq
  have hl : A*a^γ*b^m*coefficientMass (degreeOneLowPolynomial γ c)*
      (1+coefficientMass (endpointProfilePolynomial N 6 1)) =
      b^((m:ℝ)+γ)*(A*(a/b)^γ*coefficientMass (degreeOneLowPolynomial γ c)*
        (1+coefficientMass (endpointProfilePolynomial N 6 1))) := by
    calc
      _ = (a^γ*b^m)*(A*coefficientMass (degreeOneLowPolynomial γ c)*
        (1+coefficientMass (endpointProfilePolynomial N 6 1))) := by ring
      _ = _ := by rw [←hr]; ring
  rw [hl]
  rw [hf]
  ring


theorem degreeOneCoupledPolynomial_scaled_mass_budget {N m : ℕ} (hN : 0 < N)
    (hm : 1≤m) {γ a b c f A B ω : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 ≤ a) (hab : a ≤ b) (hb : 0 < b)
    (hc : c∈Set.Ioo (γ/(1+γ)) 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1) :
    coefficientMass ((degreeOneCoupledPolynomial N m γ (c*a*(1+γ)/γ) b f ω A B).comp (C b*X)) ≤
      b^((m:ℝ)+γ)*coupledCoefficientBudget 1 N γ a b A B ω := by
  have hmass := degreeOneCoupledPolynomial_scaled_mass_factored (N:=N) (γ:=γ) (c:=c) (f:=f) hm hγ ((div_pos hγ (by positivity)).trans hc.1) ha hab hb hA hB hB1 hω
  have hl : coefficientMass (degreeOneLowPolynomial γ c)≤96 :=
    (degreeOneLowPolynomial_coefficientMass hγ hγ1.le hc).trans (by norm_num)
  have hv := highProfilePolynomial_coefficientMass hN (by linarith : 0<1-γ)
    (by linarith : 1-γ≤1) hf hf1 hω hω1
  have hj1 := endpointProfilePolynomial_coefficientMass hN (by norm_num : 6≤6)
    (by norm_num : (0:ℝ)<1) (by norm_num : (1:ℝ)≤1)
  have hjδ := endpointProfilePolynomial_coefficientMass hN (by norm_num : 6≤6)
    (by linarith : 0<1-γ) (by linarith : 1-γ≤1)
  have hl' := mul_le_mul
    (mul_le_mul_of_nonneg_left hl (mul_nonneg hA (Real.rpow_nonneg (div_nonneg ha hb.le) γ)))
    (add_le_add_left hj1 1)
    (show 0 ≤ 1+coefficientMass (endpointProfilePolynomial N 6 1) by linarith [coefficientMass_nonneg (endpointProfilePolynomial N 6 1)])
    (show 0 ≤ A*(a/b)^γ*(96) by positivity)
  have hv' := mul_le_mul_of_nonneg_left hv hB
  have hj' := mul_le_mul_of_nonneg_left hjδ (mul_nonneg hω (sub_nonneg.mpr hB1))
  have hbgt : A*(a/b)^γ*coefficientMass (degreeOneLowPolynomial γ c)*
      (1+coefficientMass (endpointProfilePolynomial N 6 1)) +
      B*coefficientMass (highProfilePolynomial N (1-γ) f ω) +
      ω*(1-B)*coefficientMass (endpointProfilePolynomial N 6 (1-γ)) ≤
      coupledCoefficientBudget 1 N γ a b A B ω := by
    unfold coupledCoefficientBudget
    norm_num only [Nat.cast_one,one_pow,one_mul,mul_one,Nat.sub_self,pow_zero,Nat.mul_zero]
    nlinarith only [hl',hv',hj']
  exact hmass.trans (mul_le_mul_of_nonneg_left hbgt (Real.rpow_nonneg hb.le _))

end Renyi
