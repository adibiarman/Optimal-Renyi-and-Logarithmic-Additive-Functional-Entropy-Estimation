import Renyi.CompletedPilotReserve

/-! Exact finite-alphabet decomposition of the actual completed hybrid statistic. -/
noncomputable section
open scoped BigOperators
open MeasureTheory ProbabilityTheory
namespace Renyi
set_option maxHeartbeats 800000
variable {ι Ω : Type*} [Fintype ι]

def pilotHybridPower (Qhat : ι→Ω→ℝ) (Y Counts : ι→Ω→ℕ)
    (n alpha cp B omega : ℝ) : Ω→ℝ := fun w => ∑i,
  if (Y i w:ℝ)≤cp*B*alpha then Qhat i w else omega*analyticCount alpha (Counts i w)/n^alpha

def pilotIdealPower (p Q : ι→ℝ) (Y Counts : ι→Ω→ℕ)
    (n b alpha cp B omega : ℝ) : Ω→ℝ := fun w => ∑i,
  pilotIdealCoordinate (p i) (Q i) (omega*analyticCount alpha (Counts i w)/n^alpha)
    n b alpha B omega ((Y i w:ℝ)≤cp*B*alpha)

def pilotCenteredPolynomial (Q : ι→ℝ) (Qhat : ι→Ω→ℝ) (Y : ι→Ω→ℕ)
    (alpha cp B : ℝ) : Ω→ℝ := fun w => ∑i,
  if (Y i w:ℝ)≤cp*B*alpha then Qhat i w-Q i else 0

/-- The actual hybrid differs from its true-small/true-heavy ideal only by the
centered selected polynomial noise and the proved nonnegative boundary envelope. -/
theorem pilot_sum_comparison (p Q : ι→ℝ) (hp : ∀i,0≤p i)
    (Qhat : ι→Ω→ℝ) (Y Counts : ι→Ω→ℕ) (n b alpha cp B omega : ℝ)
    (hw : 0≤omega) (w : Ω) :
    |pilotHybridPower Qhat Y Counts n alpha cp B omega w-
      pilotIdealPower p Q Y Counts n b alpha cp B omega w-
      pilotCenteredPolynomial Q Qhat Y alpha cp B w|≤
      pilotTotalBoundary p Q Y Counts n b alpha cp B omega w := by
  unfold pilotHybridPower pilotIdealPower pilotCenteredPolynomial
  rw [←Finset.sum_sub_distrib,←Finset.sum_sub_distrib]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  unfold pilotTotalBoundary pilotPolynomialBoundary pilotGammaBoundary
  rw [←Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro i _
  have hi := pilot_coordinate_comparison (Q:=Q i) (Qhat:=Qhat i w)
    (G:=omega*analyticCount alpha (Counts i w)/n^alpha)
    (n:=n) (b:=b) (alpha:=alpha) (B:=B) (hp i) hw ((Y i w:ℝ)≤cp*B*alpha)
  apply hi.trans_eq
  by_cases hsmall : n*p i<B*alpha/2 <;>
    by_cases hlight : (Y i w:ℝ)≤cp*B*alpha <;>
      simp [hsmall,hlight,←not_le]

/-- Deterministic part of the ideal: all true-small bins use the polynomial;
false-light large bins use the ideal power arm. -/
def pilotIdealDeterministic (p Q : ι→ℝ) (Y : ι→Ω→ℕ)
    (n b alpha cp B omega : ℝ) : Ω→ℝ := fun w => ∑i,
  if n*p i<B*alpha/2 then Q i else
    if (Y i w:ℝ)≤cp*B*alpha then (if p i≤b then Q i else omega*p i^alpha) else 0

/-- Selected true-heavy bins are the only Gamma variables in the ideal. -/
def pilotTrueHeavyPower (p : ι→ℝ) (Y Counts : ι→Ω→ℕ)
    (n alpha cp B omega : ℝ) : Ω→ℝ := fun w => ∑i,
  if B*alpha/2≤n*p i ∧ cp*B*alpha<(Y i w:ℝ) then
    omega*analyticCount alpha (Counts i w)/n^alpha else 0

theorem pilot_ideal_decomposition (p Q : ι→ℝ) (Y Counts : ι→Ω→ℕ)
    (n b alpha cp B omega : ℝ) (w : Ω) :
    pilotIdealPower p Q Y Counts n b alpha cp B omega w=
      pilotIdealDeterministic p Q Y n b alpha cp B omega w+
      pilotTrueHeavyPower p Y Counts n alpha cp B omega w := by
  unfold pilotIdealPower pilotIdealDeterministic pilotTrueHeavyPower
  rw [←Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  unfold pilotIdealCoordinate
  by_cases hsmall : n*p i<B*alpha/2 <;>
    by_cases hlight : (Y i w:ℝ)≤cp*B*alpha <;>
      by_cases hb : p i≤b <;>
        simp [hsmall,hlight,hb,not_le.mpr,not_lt.mpr,not_le.mp,not_lt.mp]

/-- Any shared affine correction cancels exactly in the comparison. -/
theorem pilot_affine_sum_comparison (p Q : ι→ℝ) (hp : ∀i,0≤p i)
    (Qhat : ι→Ω→ℝ) (Y Counts : ι→Ω→ℕ) (n b alpha cp B omega anchor correction : ℝ)
    (hw : 0≤omega) (w : Ω) :
    |(pilotHybridPower Qhat Y Counts n alpha cp B omega w+anchor-correction)-
      (pilotIdealPower p Q Y Counts n b alpha cp B omega w+anchor-correction)|≤
      |pilotCenteredPolynomial Q Qhat Y alpha cp B w|+
      pilotTotalBoundary p Q Y Counts n b alpha cp B omega w := by
  have hh := pilot_sum_comparison p Q hp Qhat Y Counts n b alpha cp B omega hw w
  have htri := abs_add_le (pilotCenteredPolynomial Q Qhat Y alpha cp B w)
    (pilotHybridPower Qhat Y Counts n alpha cp B omega w-
      pilotIdealPower p Q Y Counts n b alpha cp B omega w-
      pilotCenteredPolynomial Q Qhat Y alpha cp B w)
  have hid : (pilotHybridPower Qhat Y Counts n alpha cp B omega w+anchor-correction)-
      (pilotIdealPower p Q Y Counts n b alpha cp B omega w+anchor-correction)=
      pilotCenteredPolynomial Q Qhat Y alpha cp B w+
        (pilotHybridPower Qhat Y Counts n alpha cp B omega w-
          pilotIdealPower p Q Y Counts n b alpha cp B omega w-
          pilotCenteredPolynomial Q Qhat Y alpha cp B w) := by ring
  rw [hid]
  exact htri.trans (add_le_add_left hh _)
end Renyi
