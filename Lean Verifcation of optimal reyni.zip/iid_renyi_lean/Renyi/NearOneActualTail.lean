import Renyi.NearOnePolynomialTail

/-! Uniform actual-root false-light mean bound, preserving alpha-1. -/
noncomputable section
open Polynomial
namespace Renyi
set_option maxHeartbeats 600000

theorem actual_near_one_false_light_uniform
    {eps cb lambda CL cmin q Q M cw f cu u0 B eta : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hf : 0≤f) (hf1 : f≤1)
    (hcu : 0≤cu) (hu0 : 0<u0) (hCLB : 2*B≤cb*CL) (heta : 0<eta) :
    ∃ cp0 : ℝ, 0<cp0 ∧ ∀ cp : ℝ, cp0≤cp → ∀ cL : ℝ, 0<cL →
      ∀ (k N : ℕ) (alpha Ch D c p : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) →
      upperB k alpha eps D cb CL cL≤p →
      let n := upperSample k alpha eps D
      let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
        (upperRescaling k alpha eps cu u0)
      poissonLowerMass (Real.toNNReal (cp*n*p)) (cp*B*alpha)*
        |P.eval p-upperOmega k alpha eps Ch cw*p^alpha|≤eta*(alpha-1)*p^alpha := by
  obtain ⟨K,hK,hcoeff⟩ := actual_near_one_residual_coefficients_degree_uniform
    heps hcb hlambda hCL hcmin hq hQ hM hcw hcw1 hf hf1 hcu hu0
  obtain ⟨Dt,hDt,hfactor⟩ := near_one_tail_factor_small (Cw:=2*cw*eps) (CN:=Q) (by positivity) hQ.le heta
  let Cd := 20*Q
  let Cmass := 2*K+Cd+1
  let cp0 := 8*(Cmass+Cd+Dt)/cb+1
  have hCd : 0≤Cd := by dsimp [Cd]; positivity
  have hCmass : 0≤Cmass := by dsimp [Cmass]; positivity
  have hcp0 : 0<cp0 := by dsimp [cp0]; positivity
  refine ⟨cp0,hcp0,?_⟩
  intro cp hcp cL hcL k N alpha Ch D c p hk ha ha1 hCh hD hc hc1 hNlo hNhi hpb
  let n := upperSample k alpha eps D
  let b := upperB k alpha eps D cb CL cL
  let L := (upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)
  let t := b/(N:ℝ)^2
  let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
    (upperRescaling k alpha eps cu u0)
  let R := P-C (t^(alpha-1))*X
  let omega := upperOmega k alpha eps Ch cw
  have hbeta : 0<alpha-1 := sub_pos.mpr ha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order ha ha1).2]; exact hbeta
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order ha ha1).2]; linarith only [ha1]
  have hn : 0<n := upperSample_pos hk ha hg hg1 hD
  have hb : 0<b := upperB_pos hk ha hg hg1 hD hcb hCL hcL
  have hp : 0<p := hb.trans_le hpb
  have hLge : alpha*CL≤L := (upperDegree_bounds ha hCL hcL (one_le_rootMultiplier ha hg hg1)).1
  have hL : 1≤L := by nlinarith only [hLge,ha,hCL]
  have hNpos : (0:ℝ)<N := (mul_pos hq (zero_lt_one.trans_le hL)).trans_le hNlo
  have hNnat : 0<N := by exact_mod_cast hNpos
  have hN1 : (1:ℝ)≤N := by exact_mod_cast (show 1≤N by omega)
  have hcpPos : 0<cp := hcp0.trans_le hcp
  have hpilot : 8*(Cmass+Cd+Dt)≤cp*cb := by
    have hh := mul_le_mul_of_nonneg_right hcp hcb.le
    dsimp [cp0] at hh
    rw [add_mul,div_mul_cancel₀ _ hcb.ne'] at hh
    linarith only [hh,hcb]
  have hnb : n*b=cb*L := by
    change n*(cb*L/n)=cb*L
    field_simp
  have hcut : 2*B*alpha≤n*b := by
    rw [hnb]
    have hh := mul_le_mul_of_nonneg_right hCLB (by linarith : 0≤alpha)
    have hh' := mul_le_mul_of_nonneg_left hLge hcb.le
    nlinarith only [hh,hh']
  have hdegreeNat : R.natDegree≤20*N := by
    have hP : P.natDegree≤20*N := actualNearOnePolynomial_natDegree_le (k:=k) hNnat alpha eps Ch D cb lambda CL cL c M cw f (upperRescaling k alpha eps cu u0)
    have hlin : (C (t^(alpha-1))*X : ℝ[X]).natDegree≤20*N := (show (C (t^(alpha-1))*X : ℝ[X]).natDegree≤1 by compute_degree).trans (by omega)
    exact (Polynomial.natDegree_sub_le P (C (t^(alpha-1))*X)).trans (max_le hP hlin)
  have hd : (R.natDegree:ℝ)≤Cd*L := by
    have hh : (R.natDegree:ℝ)≤20*(N:ℝ) := by exact_mod_cast hdegreeNat
    dsimp [Cd]
    nlinarith only [hh,hNhi]
  have hcf (j:ℕ) : |R.coeff j|≤K*(alpha-1)*b^(alpha-(j:ℝ))*Real.exp (K*L) :=
    hcoeff cL hcL k N j alpha Ch D c hk ha ha1 hCh hD hc hc1 hNlo hNhi
  have hmass := scaled_coefficient_mass_beta hb hbeta.le hK hL hd hcf
  have homega := upperOmega_near_one_margins (k:=k) ha ha1 hg hg1 heps hCh hcw hcw1
  have hE := upper_reserved_interval (k:=k) ha hg hg1 heps hCh
  have hE0 : 0<upperE0 k alpha eps Ch := (mul_pos heps hbeta).trans_le hE.1
  have hw1 : omega≤1 := Real.exp_le_one_iff.mpr (by nlinarith only [hcw,hE0])
  have hw : |omega-1|≤(2*cw*eps)*(alpha-1) := by
    rw [abs_of_nonpos (sub_nonpos.mpr hw1)]
    have hdiff := homega.2
    change 1-omega≤_ at hdiff
    linarith only [hdiff]
  have hmean := near_one_false_light_mean (P:=R) hn hb hpb hbeta.le hL hN1 hQ.le hNhi
    hCmass hCd (show 0≤2*cw*eps by positivity) hDt hcpPos hnb
    (by simpa only [show 1+(alpha-1)=alpha by ring] using hcut) hd
    (by simpa only [show 1+(alpha-1)=alpha by ring] using hmass) hw hpilot
  have hres : R.eval p+t^(alpha-1)*p=P.eval p := by
    dsimp [R]
    simp only [Polynomial.eval_sub,Polynomial.eval_mul,Polynomial.eval_C,Polynomial.eval_X]
    ring
  change poissonLowerMass _ (cp*B*(1+(alpha-1)))*|R.eval p+t^(alpha-1)*p-omega*p^(1+(alpha-1))|≤_ at hmean
  rw [hres,show 1+(alpha-1)=alpha by ring] at hmean
  have hmean' : poissonLowerMass (Real.toNNReal (cp*n*p)) (cp*B*alpha)*|P.eval p-omega*p^alpha|≤
      (Real.exp (-Dt)+(2*cw*eps+1+2*Q)*Real.exp (1-Dt))*(alpha-1)*p^alpha := by
    simpa only [show 1+(alpha-1)=alpha by ring,hres,Real.toNNReal_of_nonneg (by positivity : 0≤cp*n*p)] using hmean
  exact hmean'.trans (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hfactor hbeta.le) (Real.rpow_nonneg hp.le _))

end Renyi
