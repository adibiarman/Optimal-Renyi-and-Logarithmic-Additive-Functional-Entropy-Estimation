import Renyi.LowerPositiveComplete
import Renyi.LowerNegativeComplete
import Renyi.LowerNearOneComplete
import Renyi.LowerBoundedRoot
import Renyi.LowerOrderBranches

/-! The complete uniform iid sample lower bound at the public extended rate. -/
noncomputable section
namespace Renyi
set_option maxHeartbeats 1500000

/-- Every finite real order above one satisfies the same accuracy-dependent
iid sample lower bound. This includes both noninteger orientations, orders
approaching one or any integer, bounded roots, integer orders, and saturation. -/
theorem iid_uniform_lower_verified {eps : ℝ} (he : 0<eps) (he1 : eps≤1/2) :
    ∃ c : ℝ, 0<c ∧ ∃ K : ℕ, 2≤K ∧ ∀ k : ℕ, K≤k → 2<Real.log k →
      ∀ alpha : ℝ, 1<alpha → ∀ n : ℕ, Achievable k n alpha eps → c*rate k alpha eps≤n := by
  obtain ⟨cE,CE,hcE,_hCE,KE,hKE2,hEndpoint⟩ := endpoint_iid_minimax_verified he he1
  obtain ⟨cN,hcN,KN,hNear⟩ := lower_near_one_uniform he he1
  obtain ⟨cP,hcP,KP,XP,hXP,hPos⟩ := lower_positive_sample_lower he he1
  obtain ⟨cM,hcM,KM,XM,_hXM,hNeg⟩ := lower_negative_sample_lower he he1
  let X := max XP XM
  have hX1 : 1≤X := (show (1:ℝ)≤lowerPriorRootCutoff eps from
    (by norm_num : (1:ℝ)≤4).trans (le_max_left _ _)).trans (hXP.trans (le_max_left _ _))
  obtain ⟨cB,hcB,KB,_hKB,hBound⟩ := lower_bounded_noninteger_rate he hX1
  let c := min cE (min cN (min cP (min cM cB)))
  let K := max KE (max KN (max KP (max KM KB)))
  have hc : 0<c := lt_min hcE (lt_min hcN (lt_min hcP (lt_min hcM hcB)))
  have hcE' : c≤cE := min_le_left _ _
  have hcN' : c≤cN := (min_le_right _ _).trans (min_le_left _ _)
  have hcP' : c≤cP := (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
  have hcM' : c≤cM := (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _)))
  have hcB' : c≤cB := (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _)))
  have hKEK : KE≤K := le_max_left _ _
  refine ⟨c,hc,K,hKE2.trans hKEK,?_⟩
  intro k hk hlog alpha ha n hach
  have hKE : KE≤k := hKEK.trans hk
  have hKN : KN≤k := (le_trans (le_max_left _ _) (le_max_right _ _)).trans hk
  have hKP : KP≤k := (le_trans (le_max_left _ _) (le_trans (le_max_right _ _) (le_max_right _ _))).trans hk
  have hKM : KM≤k := (le_trans (le_max_left _ _) (le_trans (le_max_right _ _) (le_trans (le_max_right _ _) (le_max_right _ _)))).trans hk
  have hKB : KB≤k := (le_trans (le_max_right _ _) (le_trans (le_max_right _ _) (le_trans (le_max_right _ _) (le_max_right _ _)))).trans hk
  have hk1 : 1≤k := by have hh : 2≤k := hKE2.trans hKE; omega
  have hRate : 0≤rate k alpha eps := rate_nonneg (by linarith) hk1
  by_cases hcase : (∃r:ℕ,alpha=(r:ℝ)) ∨ Real.log k≤alpha
  · exact (mul_le_mul_of_nonneg_right hcE' hRate).trans ((hEndpoint k hKE hlog alpha ha hcase).2 n hach)
  · have hnoninteger : ¬∃r:ℕ,alpha=(r:ℝ) := fun h => hcase (Or.inl h)
    have hlow : alpha<Real.log k := lt_of_not_ge (fun h => hcase (Or.inr h))
    have hrepr := rate_noninteger_low (eps:=eps) hlow hnoninteger
    by_cases hnear : alpha≤3/2
    · apply (mul_le_mul_of_nonneg_right hcN' hRate).trans
      rw [hrepr]
      simpa only [mul_assoc] using hNear k hKN alpha ha hnear n hach
    · by_cases hroot : rootMultiplier k alpha eps≤X
      · exact (mul_le_mul_of_nonneg_right hcB' hRate).trans
          (hBound k hKB alpha (by linarith) hlow hnoninteger hroot n hach)
      · have hlarge : X≤rootMultiplier k alpha eps := (lt_of_not_ge hroot).le
        rcases positive_degree_order_decomposition (show 3/2<alpha by linarith) hnoninteger with h | h
        · obtain ⟨r,s,hr,hs,hs1,rfl⟩ := h
          apply (mul_le_mul_of_nonneg_right hcP' hRate).trans
          rw [hrepr]
          simpa only [mul_assoc] using hPos k hKP r s hr hs hs1 ((le_max_left _ _).trans hlarge) n hach
        · obtain ⟨m,s,hm,hs,hs1,rfl⟩ := h
          apply (mul_le_mul_of_nonneg_right hcM' hRate).trans
          rw [hrepr]
          simpa only [mul_assoc] using hNeg k hKM m s hm hs hs1 ((le_max_right _ _).trans hlarge) n hach

end Renyi
