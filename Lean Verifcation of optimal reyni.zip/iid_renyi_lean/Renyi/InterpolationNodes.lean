import Renyi.InterpolationComplete
import Renyi.TensorPriors
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Chebyshev
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Series
import Mathlib.Order.Interval.Finset.Fin

/-!
# Actual Chebyshev extrema and their interpolation coefficients

The nodes are explicit real cosine values. Auxiliary results refer to the
actual Lagrange basis from `Renyi.Interpolation`, not to abstract coefficient
or approximation certificates.
-/

noncomputable section
open scoped BigOperators
open Polynomial Finset
namespace Renyi

/-- Ascending Chebyshev extrema on `[b,1]`; degree zero has the single node 1. -/
def chebyshevNode (n : ℕ) (b : ℝ) (i : Fin (n + 1)) : ℝ :=
  if n = 0 then 1 else
    (1 + b - (1 - b) * Real.cos ((i : ℝ) * Real.pi / n)) / 2

theorem chebyshevNode_zero (n : ℕ) (b : ℝ) (hn : 0 < n) :
    chebyshevNode n b 0 = b := by
  simp [chebyshevNode, ne_of_gt hn]

theorem chebyshevNode_last (n : ℕ) (b : ℝ) :
    chebyshevNode n b (Fin.last n) = 1 := by
  by_cases hn : n = 0
  · simp [chebyshevNode, hn]
  · have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast hn
    simp only [chebyshevNode, if_neg hn, Fin.val_last]
    rw [mul_div_cancel_left₀ Real.pi hn', Real.cos_pi]
    ring

theorem chebyshevNode_bounds (n : ℕ) (b : ℝ) (hb : b ≤ 1) (i : Fin (n + 1)) :
    b ≤ chebyshevNode n b i ∧ chebyshevNode n b i ≤ 1 := by
  by_cases hn : n = 0
  · simp [chebyshevNode, hn, hb]
  · simp only [chebyshevNode, if_neg hn]
    have hl := mul_le_mul_of_nonneg_left (Real.neg_one_le_cos ((i : ℝ) * Real.pi / n)) (sub_nonneg.mpr hb)
    have hu := mul_le_mul_of_nonneg_left (Real.cos_le_one ((i : ℝ) * Real.pi / n)) (sub_nonneg.mpr hb)
    constructor <;> linarith

theorem chebyshevNode_strictMono (n : ℕ) (b : ℝ) (hb : b < 1) :
    StrictMono (chebyshevNode n b) := by
  intro i j hij
  have hn : 0 < n := by have := i.isLt; have := j.isLt; have := hij; omega
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  have hi : 0 ≤ (i : ℝ) * Real.pi / n := by positivity
  have hj : (j : ℝ) * Real.pi / n ≤ Real.pi := by
    apply (div_le_iff₀ hn').2
    have hjn : (j : ℝ) ≤ n := by exact_mod_cast (Nat.le_of_lt_succ j.isLt)
    nlinarith [Real.pi_pos]
  have hij' : (i : ℝ) * Real.pi / n < (j : ℝ) * Real.pi / n := by
    apply div_lt_div_of_pos_right _ hn'
    exact mul_lt_mul_of_pos_right (by exact_mod_cast hij) Real.pi_pos
  have hc := Real.cos_lt_cos_of_nonneg_of_le_pi hi hj hij'
  simp only [chebyshevNode, if_neg (ne_of_gt hn)]
  nlinarith [mul_pos (sub_pos.mpr hb) (sub_pos.mpr hc)]

theorem chebyshevNode_injective (n : ℕ) (b : ℝ) (hb : b < 1) :
    Function.Injective (chebyshevNode n b) := (chebyshevNode_strictMono n b hb).injective

/-- The product expression is the definition of the actual Lagrange coefficient. -/
theorem lagrangeWeight_product {n : ℕ} (u : Fin (n + 1) → ℝ) (a : ℝ) (i : Fin (n + 1)) :
    lagrangeWeight u a i = ∏ j ∈ (Finset.univ.erase i), (a - u j) / (u i - u j) := by
  simp only [lagrangeWeight, Lagrange.basis, Polynomial.eval_prod,
    Lagrange.basisDivisor, Polynomial.eval_mul, Polynomial.eval_C,
    Polynomial.eval_sub, Polynomial.eval_X, div_eq_mul_inv, mul_comm]

/-- At a point left of the smallest node, its Lagrange coefficient is at least 1. -/
theorem lagrangeWeight_first_ge_one {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : StrictMono u) {a : ℝ} (ha : a ≤ u 0) :
    1 ≤ lagrangeWeight u a 0 := by
  rw [lagrangeWeight_product]
  have hone : (∏ j ∈ (Finset.univ.erase (0 : Fin (n + 1))), (1 : ℝ)) = 1 := by simp
  rw [← hone]
  apply Finset.prod_le_prod (fun _ _ => zero_le_one)
  intro j hj
  have hj0 : j ≠ 0 := (Finset.mem_erase.mp hj).1
  have h0j : (0 : Fin (n + 1)) < j := Fin.pos_iff_ne_zero.mpr hj0
  have hden : u 0 - u j < 0 := sub_neg.mpr (hu h0j)
  apply (le_div_iff_of_neg hden).2
  linarith

/-- For ascending nodes, the signs alternate at every point strictly to their left. -/
theorem lagrangeWeight_alternating_sign {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : StrictMono u) {a : ℝ} (ha : a < u 0) (i : Fin (n + 1)) :
    lagrangeWeight u a i = (-1 : ℝ) ^ (i : ℕ) * |lagrangeWeight u a i| := by
  let f := fun j => (a - u j) / (u i - u j)
  have hau (j : Fin (n + 1)) : a < u j := ha.trans_le (hu.monotone (Fin.zero_le j))
  have hf (j : Fin (n + 1)) (hj : j ∈ Finset.univ.erase i) :
      f j = (if j < i then (-1 : ℝ) else 1) * |f j| := by
    have hji : j ≠ i := (Finset.mem_erase.mp hj).1
    by_cases hlt : j < i
    · have hneg : f j ≤ 0 := le_of_lt (div_neg_of_neg_of_pos
        (sub_neg.mpr (hau j)) (sub_pos.mpr (hu hlt)))
      simp [hlt, abs_of_nonpos hneg]
    · have hgt : i < j := lt_of_le_of_ne (le_of_not_gt hlt) hji.symm
      have hpos : 0 ≤ f j := le_of_lt (div_pos_of_neg_of_neg
        (sub_neg.mpr (hau j)) (sub_neg.mpr (hu hgt)))
      simp [hlt, abs_of_nonneg hpos]
  have hset : (Finset.univ.erase i).filter (fun j => j < i) = Finset.Iio i := by
    ext j
    simp only [Finset.mem_filter, Finset.mem_erase, Finset.mem_univ, and_true, Finset.mem_Iio]
    exact ⟨fun h => h.2, fun h => ⟨ne_of_lt h, h⟩⟩
  have hsign : (∏ j ∈ Finset.univ.erase i, if j < i then (-1 : ℝ) else 1) = (-1 : ℝ) ^ (i : ℕ) := by
    rw [← Finset.prod_filter]
    rw [Finset.prod_const, hset, Fin.card_Iio]
  rw [lagrangeWeight_product]
  change (∏ j ∈ Finset.univ.erase i, f j) = (-1 : ℝ) ^ (i : ℕ) * |∏ j ∈ Finset.univ.erase i, f j|
  calc
    _ = ∏ j ∈ Finset.univ.erase i, ((if j < i then (-1 : ℝ) else 1) * |f j|) := Finset.prod_congr rfl hf
    _ = (∏ j ∈ Finset.univ.erase i, if j < i then (-1 : ℝ) else 1) *
        (∏ j ∈ Finset.univ.erase i, |f j|) := Finset.prod_mul_distrib
    _ = _ := by rw [hsign, Finset.abs_prod]

/-- The Chebyshev degree estimate, proved from its polynomial recurrence. -/
theorem chebyshev_T_natDegree_le (n : ℕ) : (Polynomial.Chebyshev.T ℝ (n : ℤ)).natDegree ≤ n := by
  induction n using Nat.twoStepInduction with
  | zero => simp
  | one => simp
  | more n ih₀ ih₁ =>
    rw [show ((n + 2 : ℕ) : ℤ) = (n : ℤ) + 2 by omega, Polynomial.Chebyshev.T_add_two]
    apply (Polynomial.natDegree_sub_le _ _).trans
    apply max_le
    · have hfirst : (2 * X : ℝ[X]).natDegree ≤ 1 := by
        exact (Polynomial.natDegree_mul_le).trans (by simp)
      have hnext : (Polynomial.Chebyshev.T ℝ ((n : ℤ) + 1)).natDegree ≤ n + 1 := by
        simpa only [Nat.cast_add, Nat.cast_one] using ih₁
      exact (Polynomial.natDegree_mul_le).trans (by omega)
    · omega

/-- Polynomial reproduction in the form used for the Chebyshev polynomial. -/
theorem lagrange_polynomial_reproduction {n : ℕ} (u : Fin (n + 1) → ℝ)
    (hu : Function.Injective u) (a : ℝ) (p : ℝ[X]) (hp : p.natDegree ≤ n) :
    (∑ i, lagrangeWeight u a i * p.eval (u i)) = p.eval a := by
  have hdeg : p.degree < (Finset.univ : Finset (Fin (n + 1))).card := by
    simp only [Finset.card_univ, Fintype.card_fin]
    apply lt_of_le_of_lt (Polynomial.degree_le_natDegree)
    exact_mod_cast Nat.lt_succ_of_le hp
  have h := congrArg (Polynomial.eval a) (Lagrange.eq_interpolate hu.injOn hdeg)
  simpa [Lagrange.interpolate_apply, Polynomial.eval_finset_sum, lagrangeWeight, mul_comm] using h.symm

def chebyshevCoordinate (b : ℝ) : ℝ[X] :=
  C ((1 + b) / (1 - b)) - C (2 / (1 - b)) * X

theorem chebyshevCoordinate_eval (b x : ℝ) :
    (chebyshevCoordinate b).eval x = (1 + b - 2 * x) / (1 - b) := by
  simp only [chebyshevCoordinate, Polynomial.eval_sub, Polynomial.eval_C,
    Polynomial.eval_mul, Polynomial.eval_X]
  ring

theorem chebyshevCoordinate_degree (b : ℝ) : (chebyshevCoordinate b).natDegree ≤ 1 := by
  unfold chebyshevCoordinate
  apply (Polynomial.natDegree_sub_le _ _).trans
  apply max_le
  · simp
  · exact (Polynomial.natDegree_mul_le).trans (by simp)

theorem chebyshevCoordinate_node (n : ℕ) (b : ℝ) (hn : 0 < n) (hb : b < 1)
    (i : Fin (n + 1)) :
    (chebyshevCoordinate b).eval (chebyshevNode n b i) =
      Real.cos ((i : ℝ) * Real.pi / n) := by
  rw [chebyshevCoordinate_eval]
  simp only [chebyshevNode, if_neg (ne_of_gt hn)]
  field_simp [ne_of_gt (sub_pos.mpr hb)]
  ring

theorem chebyshev_T_at_node (n : ℕ) (b : ℝ) (hn : 0 < n) (hb : b < 1)
    (i : Fin (n + 1)) :
    ((Polynomial.Chebyshev.T ℝ (n : ℤ)).comp (chebyshevCoordinate b)).eval
      (chebyshevNode n b i) = (-1 : ℝ) ^ (i : ℕ) := by
  rw [Polynomial.eval_comp, chebyshevCoordinate_node n b hn hb i, Polynomial.Chebyshev.T_real_cos]
  have harg : ((n : ℤ) : ℝ) * ((i : ℝ) * Real.pi / n) = (i : ℝ) * Real.pi := by
    push_cast
    field_simp
  rw [harg]
  simpa only [sub_zero, Real.cos_zero, mul_one] using Real.cos_nat_mul_pi_sub 0 (i : ℕ)

/-- The exact absolute-coefficient sum at an extrapolation point. -/
theorem chebyshev_absolute_sum (n : ℕ) (b a : ℝ) (hn : 0 < n) (hb : b < 1) (ha : a < b) :
    (∑ i, |lagrangeWeight (chebyshevNode n b) a i|) =
      (Polynomial.Chebyshev.T ℝ (n : ℤ)).eval ((1 + b - 2 * a) / (1 - b)) := by
  let p := (Polynomial.Chebyshev.T ℝ (n : ℤ)).comp (chebyshevCoordinate b)
  have hp : p.natDegree ≤ n :=
    (Polynomial.natDegree_comp_le).trans
      ((Nat.mul_le_mul (chebyshev_T_natDegree_le n) (chebyshevCoordinate_degree b)).trans_eq (Nat.mul_one n))
  have he := lagrange_polynomial_reproduction (chebyshevNode n b)
    (chebyshevNode_injective n b hb) a p hp
  have hsign (i : Fin (n + 1)) :
      lagrangeWeight (chebyshevNode n b) a i * (-1 : ℝ) ^ (i : ℕ) =
        |lagrangeWeight (chebyshevNode n b) a i| := by
    have hs := lagrangeWeight_alternating_sign (chebyshevNode n b)
      (chebyshevNode_strictMono n b hb) (by rwa [chebyshevNode_zero n b hn]) i
    have hsq : ((-1 : ℝ) ^ (i : ℕ)) ^ 2 = 1 := by rw [← sq_abs]; simp [abs_pow]
    calc
      _ = (((-1 : ℝ) ^ (i : ℕ)) ^ 2) * |lagrangeWeight (chebyshevNode n b) a i| := by
        nth_rw 1 [hs]
        ring
      _ = _ := by rw [hsq, one_mul]
  have hnodes (i : Fin (n + 1)) : p.eval (chebyshevNode n b i) = (-1 : ℝ) ^ (i : ℕ) :=
    chebyshev_T_at_node n b hn hb i
  simp_rw [hnodes, hsign] at he
  simpa only [p, Polynomial.eval_comp, chebyshevCoordinate_eval] using he

/-- Quantitative extrapolation bound at the actual cosine extrema.
For `b = t/(n+1)^2` and `0 ≤ t ≤ 1`, the absolute coefficient sum is at most
`exp (2t)`, uniformly in the interpolation degree. -/
theorem chebyshev_absolute_sum_le_exp (n : ℕ) (t a : ℝ) (hn : 0 < n)
    (ht₀ : 0 ≤ t) (ht₁ : t ≤ 1) (ha₀ : 0 ≤ a)
    (ha : a < t / ((n : ℝ) + 1) ^ 2) :
    (∑ i, |lagrangeWeight (chebyshevNode n (t / ((n : ℝ) + 1) ^ 2)) a i|) ≤
      Real.exp (2 * t) := by
  let b := t / ((n : ℝ) + 1) ^ 2
  let s := Real.sqrt t / ((n : ℝ) + 1)
  let u := Real.log ((1 + s) / (1 - s))
  have hn₀ : (0 : ℝ) ≤ n := Nat.cast_nonneg _
  have hn₁ : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hnp : 0 < (n : ℝ) + 1 := by positivity
  have hsqrt₀ : 0 ≤ Real.sqrt t := Real.sqrt_nonneg t
  have hsqrt₁ : Real.sqrt t ≤ 1 := (Real.sqrt_le_one).mpr ht₁
  have hs₀ : 0 ≤ s := div_nonneg hsqrt₀ hnp.le
  have hs₁ : s < 1 := (div_lt_one hnp).mpr (by linarith)
  have hbsq : b = s ^ 2 := by dsimp [b, s]; rw [div_pow, Real.sq_sqrt ht₀]
  have hb₀ : 0 ≤ b := by rw [hbsq]; positivity
  have hb₁ : b < 1 := by rw [hbsq]; nlinarith
  have hsm : 0 < 1 - s := by linarith
  have hratio : 0 < (1 + s) / (1 - s) := div_pos (by linarith) hsm
  have hratio₁ : 1 ≤ (1 + s) / (1 - s) := (le_div_iff₀ hsm).mpr (by linarith)
  have hu₀ : 0 ≤ u := Real.log_nonneg hratio₁
  have hucos : Real.cosh u = (1 + b) / (1 - b) := by
    rw [hbsq]
    dsimp only [u]
    rw [Real.cosh_eq, Real.exp_neg, Real.exp_log hratio]
    have hs2 : 1 - s ^ 2 ≠ 0 := by nlinarith
    field_simp [hs2]
    ring
  have hulog : u ≤ 2 * s / (1 - s) := by
    have hh := Real.log_le_sub_one_of_pos hratio
    dsimp only [u]
    convert hh using 1
    field_simp
    ring
  have hsrel : ((n : ℝ) + 1) * s = Real.sqrt t := by dsimp [s]; field_simp
  have hns : (n : ℝ) * s ≤ Real.sqrt t * (1 - s) := by
    have hh := mul_le_mul_of_nonneg_right hsqrt₁ hs₀
    nlinarith
  have hnu : (n : ℝ) * u ≤ 2 * Real.sqrt t := by
    calc
      _ ≤ (n : ℝ) * (2 * s / (1 - s)) := mul_le_mul_of_nonneg_left hulog hn₀
      _ ≤ _ := by rw [← mul_div_assoc]; apply (div_le_iff₀ hsm).mpr; nlinarith
  let y := (1 + b - 2 * a) / (1 - b)
  have hy₁ : 1 ≤ y := (le_div_iff₀ (sub_pos.mpr hb₁)).mpr (by change a < b at ha; linarith)
  have hycos : y ≤ Real.cosh u := by
    rw [hucos]
    exact div_le_div_of_nonneg_right (by linarith) (sub_nonneg.mpr hb₁.le)
  have hyimage : y ∈ Real.cosh '' Set.Icc 0 u :=
    intermediate_value_Icc hu₀ Real.continuous_cosh.continuousOn
      ⟨by simpa only [Real.cosh_zero] using hy₁, hycos⟩
  rcases hyimage with ⟨v, hv, hvc⟩
  have hnv₀ : 0 ≤ (n : ℝ) * v := mul_nonneg hn₀ hv.1
  have hnv₁ : (n : ℝ) * v ≤ 2 * Real.sqrt t :=
    (mul_le_mul_of_nonneg_left hv.2 hn₀).trans hnu
  have hsquare : ((n : ℝ) * v) ^ 2 / 2 ≤ 2 * t := by
    have hsq := sq_le_sq₀ hnv₀ (show 0 ≤ 2 * Real.sqrt t by positivity) |>.mpr hnv₁
    nlinarith [Real.sq_sqrt ht₀]
  change (∑ i, |lagrangeWeight (chebyshevNode n b) a i|) ≤ _
  rw [chebyshev_absolute_sum n b a hn hb₁ ha]
  change (Polynomial.Chebyshev.T ℝ (n : ℤ)).eval y ≤ _
  rw [← hvc, Polynomial.Chebyshev.T_real_cosh]
  push_cast
  exact (Real.cosh_le_exp_half_sq _).trans (Real.exp_le_exp.mpr hsquare)

/-- Reflection pairs the interior extrema about the midpoint of `[b,1]`. -/
theorem chebyshevNode_reflection (n : ℕ) (b : ℝ) (hn : 0 < n) (i : Fin (n + 1)) :
    chebyshevNode n b i.rev = 1 + b - chebyshevNode n b i := by
  have hi : ((i.rev : Fin (n + 1)) : ℝ) = (n : ℝ) - (i : ℝ) := by
    have hv : i.rev.val = n - i.val := by simp [Fin.val_rev]
    change (i.rev.val : ℝ) = (n : ℝ) - (i.val : ℝ)
    rw [hv, Nat.cast_sub (Nat.le_of_lt_succ i.isLt)]
  have harg : ((i.rev : Fin (n + 1)) : ℝ) * Real.pi / n =
      Real.pi - (i : ℝ) * Real.pi / n := by
    rw [hi]
    field_simp
  simp only [chebyshevNode, if_neg (ne_of_gt hn), harg, Real.cos_pi_sub]
  ring

/-- For any reflected increasing node set, the far endpoint coefficient has
a uniform lower bound. This avoids a separate second-kind Chebyshev formula. -/
theorem lagrangeWeight_last_lower {n : ℕ} (u : Fin (n + 1) → ℝ) (b a : ℝ)
    (hn : 0 < n) (hu : StrictMono u) (hu₀ : u 0 = b) (hu₁ : u (Fin.last n) = 1)
    (hreflect : ∀ i, u i.rev = 1 + b - u i) (ha : a ≤ b) (hb : b < 1) :
    (b - a) / (1 - b) ≤ |lagrangeWeight u a (Fin.last n)| := by
  let I := ((Finset.univ : Finset (Fin (n + 1))).erase (Fin.last n)).erase 0
  have hmem (j : Fin (n + 1)) : j ∈ I ↔ j ≠ 0 ∧ j ≠ Fin.last n := by
    simp only [I, Finset.mem_erase, Finset.mem_univ, and_true]
  have hrev (j : Fin (n + 1)) (hj : j ∈ I) : j.rev ∈ I := by
    obtain ⟨hj₀, hj₁⟩ := (hmem j).mp hj
    apply (hmem _).mpr
    constructor
    · intro he
      have hh := congrArg Fin.rev he
      exact hj₁ (by simpa using hh)
    · intro he
      have hh := congrArg Fin.rev he
      exact hj₀ (by simpa using hh)
  have hpairs : (∏ j ∈ I, (u j - b)) = ∏ j ∈ I, (1 - u j) := by
    refine Finset.prod_bij (fun (j : Fin (n + 1)) _ => j.rev) hrev ?_ ?_ ?_
    · intro i hi j hj he
      exact Fin.rev_injective he
    · intro j hj
      exact ⟨j.rev, hrev j hj, by simp⟩
    · intro j hj
      rw [hreflect]
      ring
  have hden (j : Fin (n + 1)) (hj : j ∈ I) : 0 < 1 - u j := by
    have hjlast := ((hmem j).mp hj).2
    have hjlt : j < Fin.last n := lt_of_le_of_ne (Fin.le_last j) hjlast
    rw [← hu₁]
    exact sub_pos.mpr (hu hjlt)
  have hnum (j : Fin (n + 1)) (hj : j ∈ I) : 0 ≤ u j - b := by
    rw [← hu₀]
    exact sub_nonneg.mpr (hu.monotone (Fin.zero_le j))
  have hprod : 1 ≤ ∏ j ∈ I, (u j - a) / (1 - u j) := by
    rw [Finset.prod_div_distrib]
    apply (one_le_div (Finset.prod_pos hden)).mpr
    rw [← hpairs]
    exact Finset.prod_le_prod hnum (fun j _ => by linarith)
  have h0last : (0 : Fin (n + 1)) ≠ Fin.last n := by
    intro he
    have := congrArg Fin.val he
    simp only [Fin.val_zero, Fin.val_last] at this
    omega
  have h0mem : (0 : Fin (n + 1)) ∈ (Finset.univ.erase (Fin.last n)) := by simp [h0last]
  have habs : |lagrangeWeight u a (Fin.last n)| =
      ∏ j ∈ Finset.univ.erase (Fin.last n), (u j - a) / (1 - u j) := by
    rw [lagrangeWeight_product, Finset.abs_prod]
    apply Finset.prod_congr rfl
    intro j hj
    have hjne : j ≠ Fin.last n := (Finset.mem_erase.mp hj).1
    have hjlt : j < Fin.last n := lt_of_le_of_ne (Fin.le_last j) hjne
    have hd : 0 ≤ u (Fin.last n) - u j := (sub_pos.mpr (hu hjlt)).le
    have huj : b ≤ u j := by rw [← hu₀]; exact hu.monotone (Fin.zero_le j)
    rw [abs_div, abs_of_nonpos (by linarith : a - u j ≤ 0), abs_of_nonneg hd, hu₁]
    congr 1
    ring
  rw [habs, ← Finset.mul_prod_erase _ _ h0mem, hu₀]
  change (b - a) / (1 - b) ≤ (b - a) / (1 - b) * (∏ j ∈ I, (u j - a) / (1 - u j))
  simpa only [mul_one] using mul_le_mul_of_nonneg_left hprod
    (div_nonneg (sub_nonneg.mpr ha) (sub_nonneg.mpr hb.le))

/-- The endpoint atom needed in the statistical denominator is at least b/2. -/
theorem chebyshev_last_weight_lower (n : ℕ) (b a : ℝ)
    (hn : 0 < n) (hb₀ : 0 ≤ b) (hb₁ : b < 1) (ha : a ≤ b / 2) :
    b / 2 ≤ |lagrangeWeight (chebyshevNode n b) a (Fin.last n)| := by
  apply le_trans _ (lagrangeWeight_last_lower (chebyshevNode n b) b a hn
    (chebyshevNode_strictMono n b hb₁) (chebyshevNode_zero n b hn)
    (chebyshevNode_last n b) (chebyshevNode_reflection n b hn) (by linarith) hb₁)
  apply (le_div_iff₀ (sub_pos.mpr hb₁)).mpr
  nlinarith [sq_nonneg b]

/-- A convenient explicit linear bound for the small extrapolation regime. -/
theorem exp_two_mul_le_one_add_four_mul {t : ℝ} (ht₀ : 0 ≤ t) (ht₁ : t ≤ 1 / 4) :
    Real.exp (2 * t) ≤ 1 + 4 * t := by
  have hx : 2 * t < 1 := by linarith
  apply (Real.exp_bound_div_one_sub_of_interval (by linarith) hx).trans
  apply (div_le_iff₀ (by linarith : 0 < 1 - 2 * t)).mpr
  nlinarith [mul_nonneg ht₀ (sub_nonneg.mpr ht₁)]

/-- **First part of `cal:lem:nodes`, with explicit constants** `c_b = 1/8`,
`C = 1/2` in the sum bounds. All four conclusions refer to the explicit nodes. -/
theorem chebyshev_nodes_small_interval (n : ℕ) (η a : ℝ) (hn : 0 < n)
    (hη₀ : 0 < η) (hη₁ : η ≤ 3 / 5) (ha₀ : 0 < a)
    (ha₁ : a ≤ ((η / 8) / ((n : ℝ) + 1) ^ 2) / 2) :
    let b := (η / 8) / ((n : ℝ) + 1) ^ 2
    let u := chebyshevNode n b
    (∑ i, |lagrangeWeight u a i|) ≤ 1 + η / 2 ∧
    1 ≤ lagrangeWeight u a 0 ∧
    (∑ i ∈ (Finset.univ.erase (0 : Fin (n + 1))), |lagrangeWeight u a i|) ≤ η / 2 ∧
    b / 2 ≤ |lagrangeWeight u a (Fin.last n)| := by
  dsimp only
  let b := (η / 8) / ((n : ℝ) + 1) ^ 2
  let u := chebyshevNode n b
  have hb₀ : 0 < b := by dsimp [b]; positivity
  have hnp : (1 : ℝ) ≤ ((n : ℝ) + 1) ^ 2 := by have hn0 : (0 : ℝ) ≤ n := Nat.cast_nonneg _; nlinarith
  have hb₁ : b < 1 := by
    apply (div_lt_one (by positivity : (0 : ℝ) < ((n : ℝ) + 1) ^ 2)).mpr
    linarith
  have hab : a < b := by change a ≤ b / 2 at ha₁; linarith
  have hsum : (∑ i, |lagrangeWeight u a i|) ≤ 1 + η / 2 := by
    have he := chebyshev_absolute_sum_le_exp n (η / 8) a hn (by positivity) (by linarith) ha₀.le hab
    have hl := exp_two_mul_le_one_add_four_mul (t := η / 8) (by positivity) (by linarith)
    have hh := he.trans hl
    convert hh using 1
    ring
  have hfirst : 1 ≤ lagrangeWeight u a 0 :=
    lagrangeWeight_first_ge_one u (chebyshevNode_strictMono n b hb₁)
      (by dsimp [u]; rw [chebyshevNode_zero n b hn]; exact hab.le)
  refine ⟨hsum, hfirst, ?_, chebyshev_last_weight_lower n b a hn hb₀.le hb₁ ha₁⟩
  have hs := Finset.sum_erase_add (s := (Finset.univ : Finset (Fin (n + 1))))
    (fun i => |lagrangeWeight u a i|) (Finset.mem_univ (0 : Fin (n + 1)))
  dsimp only at hs
  rw [abs_of_nonneg (by linarith : 0 ≤ lagrangeWeight u a 0)] at hs
  linarith

/-- Normalizing a finite signed measure at its positive mass preserves the
small negative mass and a large principal atom, with explicit inequalities. -/
theorem signed_atom_normalization_bounds {ι : Type*} [Fintype ι]
    (w : Option ι → ℝ) (K : ℝ) (hw : 0 < w none) (hK₀ : 0 ≤ K) (hK₁ : K ≤ 1)
    (hnodal : (∑ i : ι, |w (some i)|) ≤ K * w none) :
    (∑ i : Option ι, negativeCoeff (w i / positiveAtomicMass w)) ≤ K ∧
      (1 / 2 : ℝ) ≤ w none / positiveAtomicMass w := by
  let P := positiveAtomicMass w
  have hP₀ : w none ≤ P := by
    have hh := Finset.single_le_sum (s := (Finset.univ : Finset (Option ι)))
      (f := fun i => max (w i) 0) (fun i _ => le_max_right _ _) (Finset.mem_univ none)
    simpa only [max_eq_left hw.le] using hh
  have hPpos : 0 < P := hw.trans_le hP₀
  have hPupper : P ≤ w none + (∑ i : ι, |w (some i)|) := by
    dsimp only [P, positiveAtomicMass]
    rw [Fintype.sum_option, max_eq_left hw.le]
    apply add_le_add_left
    apply Finset.sum_le_sum
    intro i _
    exact max_le (le_abs_self _) (abs_nonneg _)
  have hneg : (∑ i : Option ι, negativeCoeff (w i)) ≤ (∑ i : ι, |w (some i)|) := by
    rw [Fintype.sum_option]
    simp only [negativeCoeff, max_eq_right (neg_nonpos.mpr hw.le), zero_add]
    apply Finset.sum_le_sum
    intro i _
    exact max_le (neg_le_abs _) (abs_nonneg _)
  have hdivide (i : Option ι) : negativeCoeff (w i / P) = negativeCoeff (w i) / P := by
    unfold negativeCoeff
    rw [← neg_div]
    simpa only [zero_div] using (max_div_div_right hPpos.le (-w i) 0)
  constructor
  · change (∑ i, negativeCoeff (w i / P)) ≤ K
    simp_rw [hdivide]
    rw [← Finset.sum_div]
    apply (div_le_iff₀ hPpos).mpr
    exact (hneg.trans hnodal).trans (mul_le_mul_of_nonneg_left hP₀ hK₀)
  · change (1 / 2 : ℝ) ≤ w none / P
    apply (le_div_iff₀ hPpos).mpr
    have hh := mul_le_mul_of_nonneg_right hK₁ hw.le
    nlinarith

/-- The weighted nodal mass for the actual interpolation coefficients. -/
theorem weightedInterpolation_nodal_bound {n : ℕ} (u : Fin (n + 1) → ℝ)
    (a b ξ : ℝ) (hb : 0 < b) (hu : ∀ i, b ≤ u i) (hξ : 0 ≤ ξ) :
    (∑ i, |weightedInterpolation u a 0 ξ (some i)|) ≤
      b ^ (-ξ) * (∑ i, |lagrangeWeight u a i|) := by
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i _
  simp only [weightedInterpolation, interpolationWeights, interpolationNodes,
    Option.elim_some, zero_mul, zero_div, add_zero, mul_one, neg_mul, abs_neg, abs_mul]
  rw [abs_of_nonneg (Real.rpow_nonneg (hb.le.trans (hu i)) _)]
  have hh := mul_le_mul_of_nonneg_left
    (Real.rpow_le_rpow_of_nonpos hb (hu i) (neg_nonpos.mpr hξ))
    (abs_nonneg (lagrangeWeight u a i))
  simpa only [mul_comm] using hh

/-- The exponential coefficient bound also includes the single-node case. -/
theorem chebyshev_absolute_sum_le_exp_all (n : ℕ) (t a : ℝ)
    (ht₀ : 0 ≤ t) (ht₁ : t ≤ 1) (ha₀ : 0 ≤ a)
    (ha : a < t / ((n : ℝ) + 1) ^ 2) :
    (∑ i, |lagrangeWeight (chebyshevNode n (t / ((n : ℝ) + 1) ^ 2)) a i|) ≤
      Real.exp (2 * t) := by
  by_cases hn : n = 0
  · subst n
    simpa [lagrangeWeight, Lagrange.basis] using Real.one_le_exp (show 0 ≤ 2 * t by positivity)
  · exact chebyshev_absolute_sum_le_exp n t a (Nat.pos_of_ne_zero hn) ht₀ ht₁ ha₀ ha

/-- **Second part of `cal:lem:nodes`, including degree zero.**
The negative Jordan mass is at most `exp(-ξ)z`, and the principal atom
carries at least half of the normalized positive mass. -/
theorem chebyshev_nodes_weighted (n : ℕ) (ξ z : ℝ)
    (hξ₀ : 1 / 2 ≤ ξ) (hξ₁ : ξ < 1) (hz₀ : 0 < z) (hz₁ : z ≤ 1) :
    let b := ξ / ((n : ℝ) + 1) ^ 2
    let a := Real.exp (-5) * b * z ^ (1 / ξ)
    let u := chebyshevNode n b
    (∑ i, negativeCoeff (normalizedInterpolation u a 0 ξ i)) ≤ Real.exp (-ξ) * z ∧
      (1 / 2 : ℝ) ≤ normalizedInterpolation u a 0 ξ none := by
  dsimp only
  let b := ξ / ((n : ℝ) + 1) ^ 2
  let a := Real.exp (-5) * b * z ^ (1 / ξ)
  let u := chebyshevNode n b
  let w := weightedInterpolation u a 0 ξ
  let K := Real.exp (-ξ) * z
  have hξpos : 0 < ξ := by linarith
  have hξne : ξ ≠ 0 := ne_of_gt hξpos
  have hb₀ : 0 < b := by dsimp [b]; positivity
  have hnp : (1 : ℝ) ≤ ((n : ℝ) + 1) ^ 2 := by
    have hn₀ : (0 : ℝ) ≤ n := Nat.cast_nonneg _
    nlinarith
  have hb₁ : b < 1 := by
    apply (div_lt_one (by positivity : (0 : ℝ) < ((n : ℝ) + 1) ^ 2)).mpr
    linarith
  have hzp : 0 < z ^ (1 / ξ) := Real.rpow_pos_of_pos hz₀ _
  have hzp₁ : z ^ (1 / ξ) ≤ 1 := Real.rpow_le_one hz₀.le hz₁ (by positivity)
  have ha₀ : 0 < a := by dsimp [a]; positivity
  have ha₁ : a < b := by
    have hh := mul_le_mul_of_nonneg_left hzp₁ (mul_nonneg (Real.exp_nonneg (-5)) hb₀.le)
    have hexp : Real.exp (-5) < 1 := Real.exp_lt_one_iff.mpr (by norm_num)
    dsimp only [a]
    nlinarith
  have hu : ∀ i, b ≤ u i := fun i => (chebyshevNode_bounds n b hb₁.le i).1
  have hw : w none = a ^ (-ξ) := by
    simp [w, weightedInterpolation, interpolationWeights, interpolationNodes]
  have hwpos : 0 < w none := by rw [hw]; exact Real.rpow_pos_of_pos ha₀ _
  have hK₀ : 0 ≤ K := by dsimp [K]; positivity
  have hK₁ : K ≤ 1 := by
    have hh : Real.exp (-ξ) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
    have hh' := mul_le_mul_of_nonneg_right hh hz₀.le
    dsimp only [K]
    linarith
  have hsum : (∑ i, |lagrangeWeight u a i|) ≤ Real.exp (2 * ξ) :=
    chebyshev_absolute_sum_le_exp_all n ξ a hξpos.le hξ₁.le ha₀.le ha₁
  have haPower : a ^ ξ = Real.exp (-5 * ξ) * b ^ ξ * z := by
    dsimp only [a]
    rw [Real.mul_rpow (mul_nonneg (Real.exp_nonneg _) hb₀.le) hzp.le,
      Real.mul_rpow (Real.exp_nonneg _) hb₀.le, ← Real.exp_mul,
      ← Real.rpow_mul hz₀.le]
    rw [one_div_mul_cancel hξne, Real.rpow_one]
  have hscale : b ^ (-ξ) * Real.exp (2 * ξ) = a ^ (-ξ) * (Real.exp (-3 * ξ) * z) := by
    have he : Real.exp (-5 * ξ) * Real.exp (2 * ξ) = Real.exp (-3 * ξ) := by
      rw [← Real.exp_add]
      congr 1
      ring
    rw [Real.rpow_neg hb₀.le, Real.rpow_neg ha₀.le]
    field_simp [ne_of_gt (Real.rpow_pos_of_pos hb₀ ξ), ne_of_gt (Real.rpow_pos_of_pos ha₀ ξ)]
    rw [haPower]
    ring_nf at he ⊢
    linear_combination (b ^ ξ * z) * he
  have hnodal : (∑ i, |w (some i)|) ≤ K * w none := by
    have hh := weightedInterpolation_nodal_bound u a b ξ hb₀ hu hξpos.le
    calc
      _ ≤ b ^ (-ξ) * (∑ i, |lagrangeWeight u a i|) := hh
      _ ≤ b ^ (-ξ) * Real.exp (2 * ξ) :=
        mul_le_mul_of_nonneg_left hsum (Real.rpow_nonneg hb₀.le _)
      _ = a ^ (-ξ) * (Real.exp (-3 * ξ) * z) := hscale
      _ ≤ a ^ (-ξ) * (Real.exp (-ξ) * z) := by
        apply mul_le_mul_of_nonneg_left _ (Real.rpow_nonneg ha₀.le _)
        apply mul_le_mul_of_nonneg_right _ hz₀.le
        apply Real.exp_le_exp.mpr
        linarith
      _ = K * w none := by rw [hw]; dsimp [K]; ring
  have hh := signed_atom_normalization_bounds w K hwpos hK₀ hK₁ hnodal
  simpa only [w, K, normalizedInterpolation, interpolationNormalizer] using hh

end Renyi
