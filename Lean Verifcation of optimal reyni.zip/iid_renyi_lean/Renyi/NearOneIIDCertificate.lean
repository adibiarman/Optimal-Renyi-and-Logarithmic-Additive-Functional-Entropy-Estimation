import Renyi.PowerBandCertificate
import Renyi.NonintegerIID

/-! Actual fixed-iid achievability from calibrated near-one moments. -/
noncomputable section
open scoped NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- All probability laws in this statement are the concrete independent
Poisson histogram experiment. The statistic itself is independent of p. -/
theorem near_one_iid_of_histogram_moments {k:ℕ} {alpha eps D Ch cw:ℝ}
    (hk:0<k) (ha:1<alpha) (ha1:alpha≤3/2) (heps:0<eps) (hCh:0≤Ch)
    (hcw:0<cw) (hcw1:cw<1) (hD:1≤D) (hDtail:3*Real.log 12≤D)
    (cp:ℝ≥0) (F:PilotHistogram k→ℝ)
    (hstat:∀p:Simplex k,
      let mu:=(pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure
      MemLp F 2 mu ∧
      |(∫h,F h ∂mu)-upperOmega k alpha eps Ch cw*powerSum p alpha|≤
        nearOneMarginConstant eps cw*(alpha-1)*powerSum p alpha/2 ∧
      variance F mu≤(nearOneMarginConstant eps cw)^2*(alpha-1)^2*(powerSum p alpha)^2/16) :
    ∃m:ℕ,(m:ℝ)≤(3*(1+(cp:ℝ))*D)*
      (alpha*(k:ℝ)^(1-1/alpha)*rootMultiplier k alpha eps) ∧ Achievable k m alpha eps := by
  have hfloor:⌊alpha⌋=(1:ℤ) := Int.floor_eq_iff.mpr (by norm_num; constructor <;> linarith)
  have hfract:fractionalPart alpha=alpha-1 := by simp only [fractionalPart,hfloor,Int.cast_one]
  have hg:0<fractionalPart alpha := by rw [hfract]; linarith
  have hg1:fractionalPart alpha<1 := by rw [hfract]; linarith
  apply noninteger_iid_upper_of_histogram_band hk ha hg hg1 hD hDtail cp F
  intro p
  rcases hstat p with ⟨hF,hbias,hvar⟩
  apply near_one_power_band_of_mean_variance hF ha ha1 heps hCh hcw hcw1
    (simplex_powerSum_pos p alpha) hbias
  calc
    variance F (pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure≤
      (nearOneMarginConstant eps cw)^2*(alpha-1)^2*(powerSum p alpha)^2/16 := hvar
    _ = (1/4:ℝ)*(nearOneMarginConstant eps cw*(alpha-1)*powerSum p alpha/2)^2 := by ring

end Renyi
