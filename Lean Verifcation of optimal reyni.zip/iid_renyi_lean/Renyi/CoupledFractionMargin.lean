import Renyi.CoupledStrictMargin

/-! Strict spatial margin near fractional part zero for the same actual polynomial. -/
noncomputable section
namespace Renyi

def highProfileIntegralConstant (f : ℝ) : ℝ :=
  Real.exp (Real.log 12+289+Real.log (endpointReserveConstant f))

theorem highProfileIntegralConstant_pos (f : ℝ) : 0<highProfileIntegralConstant f := Real.exp_pos _

/-- The high profile controls its actual normalized primitive throughout the sharp endpoint range. -/
theorem highProfile_integral_local_comparison {N : ℕ} (hN : 2≤N) {s f ω x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f<1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : (N:ℝ)^2*x≤s) :
    endpointProfile N 6 s x≤highProfileIntegralConstant f*highProfile N s f ω x := by
  let Y := (N:ℝ)^2*x
  let C := Real.log (endpointReserveConstant f)+288
  let B := Real.log 12+1
  have hCf := endpointReserveConstant_pos hf1
  have hCf1 := endpointReserveConstant_one_le hf hf1
  have hC : 0≤C := by have hl := Real.log_nonneg hCf1;dsimp [C];linarith only [hl]
  have hB : 0≤B := by have hl := Real.log_nonneg (by norm_num : (1:ℝ)≤12);dsimp [B];linarith only [hl]
  have hY : 0≤Y := by dsimp [Y];positivity
  have hfirst := highProfile_local_lower hN hs hs1 hf hf1 hω hω1 hx hx1 hy
  rw [profile_rescaled_power hY hCf hs, mul_assoc, ←Real.exp_add] at hfirst
  have hexp : Real.exp (-C)≤Real.exp (-Real.log (endpointReserveConstant f)*s+-288*s) := by
    apply Real.exp_le_exp.mpr
    dsimp [C] at *
    nlinarith only [mul_le_mul_of_nonneg_left hs1 hC]
  have hYscale : Y≤Y/s := (le_div_iff₀ hs).mpr (mul_le_of_le_one_right hY hs1)
  have hp := Real.rpow_le_rpow hY hYscale hs.le
  have hm := mul_le_mul hp hexp (Real.exp_pos (-C)).le (Real.rpow_nonneg (div_nonneg hY hs.le) s)
  have hlower : Y^s*Real.exp (-C)≤highProfile N s f ω x := hm.trans hfirst
  have hraise := mul_le_mul_of_nonneg_left hlower (Real.exp_pos C).le
  have hid : Real.exp C*(Y^s*Real.exp (-C))=Y^s := by
    rw [mul_left_comm,←Real.exp_add,add_neg_cancel,Real.exp_zero,mul_one]
  rw [hid] at hraise
  have hJ := endpointProfile_upper_power (by omega : 0<N) (by norm_num : 6≤6) hs hx hx1
  have heB : Real.exp (B*s)≤Real.exp B := Real.exp_le_exp.mpr (mul_le_of_le_one_right hB hs1)
  have hJ' := hJ.trans (mul_le_mul_of_nonneg_right heB (Real.rpow_nonneg hY s))
  have hlast := hJ'.trans (mul_le_mul_of_nonneg_left hraise (Real.exp_pos B).le)
  have hconst : Real.exp B*Real.exp C=highProfileIntegralConstant f := by
    rw [←Real.exp_add]
    congr 1
    dsimp [B,C,highProfileIntegralConstant]
    ring
  simpa only [←mul_assoc,hconst] using hlast

/-- Uniformly on the half-order range, the actual high profile is at most a constant times sqrt(Y). -/
theorem highProfile_half_order_upper {N : ℕ} (hN : 0<N) {s f ω x : ℝ}
    (hs : (1:ℝ)/2≤s) (hs1 : s≤1) (hf : 0≤f) (hf1 : f≤1) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : (N:ℝ)^2*x≤1) :
    highProfile N s f ω x≤Real.exp (coupledProfileConstant+1)*Real.sqrt ((N:ℝ)^2*x) := by
  have hsp : 0<s := by linarith only [hs]
  have hY : 0≤(N:ℝ)^2*x := by positivity
  have hupper := highProfile_upper_power hN hsp hs1 hf hf1 hω hω1 hx hx1
  have hss := endpoint_self_power_lower hsp
  have hscale : (((N:ℝ)^2*x)/s)^s≤Real.exp 1*((N:ℝ)^2*x)^s := by
    rw [Real.div_rpow hY hsp.le]
    apply (div_le_iff₀ (Real.rpow_pos_of_pos hsp s)).mpr
    have he := mul_le_mul_of_nonneg_left hss (Real.exp_pos 1).le
    have hid : Real.exp 1*Real.exp (-1)=1 := by rw [←Real.exp_add];norm_num
    rw [hid] at he
    nlinarith only [mul_le_mul_of_nonneg_right he (Real.rpow_nonneg hY s)]
  have hpower : ((N:ℝ)^2*x)^s≤Real.sqrt ((N:ℝ)^2*x) := by
    rw [Real.sqrt_eq_rpow]
    by_cases hy0 : (N:ℝ)^2*x=0
    · rw [hy0,Real.zero_rpow hsp.ne',Real.zero_rpow (by norm_num : (1/(2:ℝ))≠0)]
    · exact Real.rpow_le_rpow_of_exponent_ge (lt_of_le_of_ne hY (Ne.symm hy0)) hy hs
  have hC : 0≤coupledProfileConstant := by have hl := Real.log_nonneg (by norm_num : (1:ℝ)≤24);unfold coupledProfileConstant;linarith only [hl]
  have he : Real.exp (coupledProfileConstant*s)≤Real.exp coupledProfileConstant :=
    Real.exp_le_exp.mpr (mul_le_of_le_one_right hC hs1)
  have hm := mul_le_mul he (hscale.trans (mul_le_mul_of_nonneg_left hpower (Real.exp_pos 1).le))
    (by positivity) (Real.exp_pos coupledProfileConstant).le
  have hid : Real.exp coupledProfileConstant*(Real.exp 1*Real.sqrt ((N:ℝ)^2*x))=
      Real.exp (coupledProfileConstant+1)*Real.sqrt ((N:ℝ)^2*x) := by rw [←mul_assoc,←Real.exp_add]
  exact hupper.trans (hm.trans_eq hid)

/-- Reverse capacity forces a fixed low-profile gap as soon as the forward scale exceeds gamma. -/
theorem lowProfile_capacity_fraction_outer {ℓ : ℕ} (hℓ : 0<ℓ) {γ z E f x Y : ℝ}
    (hγ : 0<γ) (hγ1 : γ<1) (hf : 0≤f) (hf1 : f<1)
    (hx : 0≤x) (hx1 : x≤1) (hz : 0<z) (hzE : z≤Real.exp (-E))
    (hY : γ≤Y) (hroot : 8*Real.sqrt γ≤E)
    (hcap : ((ℓ:ℝ)^2*x)*Y≤Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    lowProfile ℓ γ f x≤Real.exp (-E/2) := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hYp : 0<Y := hγ.trans_le hY
  have hE : 0≤E := (by positivity : 0≤8*Real.sqrt γ).trans hroot
  have hu0 := (lowProfile_range hℓ hγ hf hf1 hx hx1).1
  have hu := (lowProfile_upper_power hℓ hγ hγ1.le hf hf1 hx hx1).trans
    (reverse_capacity_power hγ hγ1 (by positivity) hYp hz hcap)
  have hp := Real.rpow_le_rpow hz.le hzE (one_div_pos.mpr hd).le
  rw [←Real.exp_mul] at hp
  rw [show -E*(1/(1-γ))=-E/(1-γ) by ring] at hp
  have hpe : z^(1/(1-γ))≤Real.exp (-E) := hp.trans (Real.exp_le_exp.mpr (by
    have h := (le_div_iff₀ hd).mpr (mul_le_of_le_one_right hE hd1)
    simpa only [neg_div] using neg_le_neg h))
  have hquot : ((1-γ)/Y)*γ≤1 := by
    have h := mul_le_mul_of_nonneg_left hY hd.le
    have hδY : (1-γ)*γ≤Y := h.trans (mul_le_of_le_one_left hYp.le hd1)
    calc
      _ = ((1-γ)*γ)/Y := by ring
      _ ≤ 1 := (div_le_one hYp).mpr hδY
  have hqp : ((1-γ)/Y)^γ*γ^γ≤1 := by
    rw [←Real.mul_rpow (div_nonneg hd.le hYp.le) hγ.le]
    exact Real.rpow_le_one (mul_nonneg (div_nonneg hd.le hYp.le) hγ.le) hquot hγ.le
  have hm := mul_le_mul_of_nonneg_right hu (Real.rpow_nonneg hγ.le γ)
  have hm' := mul_le_mul_of_nonneg_left hqp (Real.rpow_nonneg hz.le (1/(1-γ)))
  have hprod : lowProfile ℓ γ f x*γ^γ≤Real.exp (-E) := by nlinarith only [hm,hm',hpe]
  have hpow := small_order_scaled_power_lower hγ (by norm_num : (0:ℝ)<1) hroot
    (by simpa using hE : 4*γ*(-Real.log 1)≤E)
  simp only [one_mul] at hpow
  have hlow := mul_le_mul_of_nonneg_left hpow hu0
  apply (mul_le_mul_iff_right₀ (Real.exp_pos (-E/2))).mp
  have hid : Real.exp (-E/2)*Real.exp (-E/2)=Real.exp (-E) := by rw [←Real.exp_add];congr 1;ring
  rw [hid]
  nlinarith only [hprod,hlow]

/-- Actual near-zero-fraction expression outside its forward transition has a fixed strict gap. -/
theorem coupledProfiles_fraction_outer_gap {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z E M ω ρ fL f x y : ℝ} (hγ : 0<γ) (hγhalf : γ≤1/2) (hM : 0≤M)
    (hρ : 0<ρ) (hω : 0≤ω) (hωρ : ω≤1-ρ)
    (hMρ : Real.exp (-M/2)≤ρ/4) (hEρ : Real.exp (-E/2)≤1-ρ)
    (hroot : 8*Real.sqrt γ≤E) (herror : (40*Real.exp (Real.log 12+1))*γ≤ρ/4)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hzE : z≤Real.exp (-E)) (hY : γ≤(N:ℝ)^2*y)
    (hcap : ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤1-ρ/2 := by
  have hγ1 : γ<1 := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hE : 0<E := lt_of_lt_of_le (by positivity : 0<8*Real.sqrt γ) hroot
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hlow := lowProfile_capacity_fraction_outer hℓ hγ hγ1 hfL hfL1 hx hx1 hz hzE hY hroot hcap
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have ha1 : a≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hγ]))
  have hb : b≤ρ/4 := by
    apply (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
    apply le_trans _ hMρ
    apply Real.exp_le_exp.mpr
    nlinarith only [mul_le_mul_of_nonneg_left hγhalf hM]
  have hb1 : b≤1 := by
    have hρ1 : ρ≤1 := by linarith only [hω,hωρ]
    linarith only [hb,hρ1]
  have hS : a*lowProfile ℓ γ fL x+b*highProfile N (1-γ) f ω y≤1-3*ρ/4 := by
    have hl := (mul_le_of_le_one_left hu.1 ha1).trans (hlow.trans hEρ)
    have hh := (mul_le_of_le_one_right hb0 hv.2).trans hb
    linarith only [hl,hh]
  have hR : ω+(1-ω)*b≤1-3*ρ/4 := by
    have hm := mul_le_of_le_one_left hb0 (by linarith only [hω] : 1-ω≤1)
    linarith only [hm,hb,hωρ]
  have hdiff := (endpointProfile_order_one_comparison hN (by norm_num : 2≤6) (by norm_num : 6≤6)
    (by linarith only [hγhalf] : (1:ℝ)/2≤1-γ) (by linarith only [hγ] : 1-γ≤1) hy hy1).2
  have hdiff' : endpointProfile N 6 (1-γ) y-endpointProfile N 6 1 y≤(40*Real.exp (Real.log 12+1))*γ := by
    convert hdiff using 1;ring
  have hcut := cutoff_convex_upper hH.1 hH.2 hb0 hb1 hv.2 hω hS hdiff'
  have hmax := max_le (le_refl (1-3*ρ/4)) hR
  have hcoef : ω*(1-b)≤1 := by
    have hm := mul_le_of_le_one_right hω (by linarith only [hb0] : 1-b≤1)
    linarith only [hm,hω1]
  have herr := mul_le_mul_of_nonneg_right hcoef (show 0≤(40*Real.exp (Real.log 12+1))*γ by positivity)
  unfold coupledDampedExpression
  change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+
    b*highProfile N (1-γ) f ω y+ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
  nlinarith only [hcut,hmax,herr,herror]

lemma product_exponential_separation {u v γ z E : ℝ}
    (hγ : 0<γ) (hγ1 : γ<1) (hE : 0≤E) (hu : Real.exp (-E/4)≤u)
    (hv : 0≤v) (hprod : u^(1-γ)*v^γ≤z) (hz : z≤Real.exp (-E)) :
    v≤Real.exp (-E/(2*γ)) := by
  have hd : 0≤1-γ := by linarith only [hγ1]
  have hp := Real.rpow_le_rpow (Real.exp_pos (-E/4)).le hu hd
  rw [←Real.exp_mul] at hp
  have hlow : Real.exp (-E/2)≤u^(1-γ) := by
    apply le_trans _ hp
    apply Real.exp_le_exp.mpr
    nlinarith only [hE,mul_nonneg hE hγ.le]
  have hm := (mul_le_mul_of_nonneg_right hlow (Real.rpow_nonneg hv γ)).trans (hprod.trans hz)
  have hpv : v^γ≤Real.exp (-E/2) := by
    apply (mul_le_mul_iff_right₀ (Real.exp_pos (-E/2))).mp
    have hid : Real.exp (-E/2)*Real.exp (-E/2)=Real.exp (-E) := by rw [←Real.exp_add];congr 1;ring
    rw [hid]
    exact hm
  by_cases hv0 : v=0
  · rw [hv0];exact (Real.exp_pos _).le
  have hvp : 0<v := lt_of_le_of_ne hv (Ne.symm hv0)
  rw [Real.rpow_def_of_pos hvp] at hpv
  have hlog := Real.exp_le_exp.mp hpv
  calc
    v = Real.exp (Real.log v) := (Real.exp_log hvp).symm
    _ ≤ Real.exp (-E/(2*γ)) := by
      apply Real.exp_le_exp.mpr
      rw [show -E/(2*γ)=(-E/2)/γ by ring]
      apply (le_div_iff₀ hγ).mpr
      nlinarith only [hlog]

/-- In the actual sharp forward neighborhood the cutoff expression is dominated by its low arm and v. -/
theorem coupledProfiles_fraction_local_upper {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 2≤N)
    {γ z M ω fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hM : 0≤M)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1)
    (hω : 0≤ω) (hω1 : ω<1) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hz1 : z<1) (hY : (N:ℝ)^2*y≤1-γ) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤
      Real.exp (-M*γ)*lowProfile ℓ γ fL x+
      (1+highProfileIntegralConstant f)*highProfile N (1-γ) f ω y := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range (by omega : 0<N) hd hf hf1.le hω hω1 hy hy1
  have hH := endpointProfile_range (by omega : 0<N) (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range (by omega : 0<N) (by norm_num : 6≤6) hd hy hy1
  have hcmp := highProfile_integral_local_comparison hN hd (by linarith only [hγ] : 1-γ≤1) hf hf1 hω hω1 hy hy1 hY
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have ha : a≤Real.exp (-M*γ) := mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le
  have hb : b≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hd]))
  have hlowcut := mul_le_of_le_one_right (mul_nonneg ha0 hu.1)
    (by linarith only [hH.1] : 1-endpointProfile N 6 1 y≤1)
  have hlow := mul_le_mul_of_nonneg_right ha hu.1
  have hhigh := mul_le_of_le_one_left hv.1 hb
  have hcoef : ω*(1-b)≤1 := (mul_le_of_le_one_right hω (by linarith only [hb0] : 1-b≤1)).trans hω1.le
  have hlast := (mul_le_of_le_one_left hJ.1 hcoef).trans hcmp
  unfold coupledDampedExpression
  change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+
    b*highProfile N (1-γ) f ω y+ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
  nlinarith only [hlowcut,hlow,hhigh,hlast]

def fractionSeparationLevel (E : ℝ) : ℝ := max (1/2) (Real.exp (-E/4))

def fractionMarginConstant (f ρ E : ℝ) : ℝ :=
  min (ρ/6) (min ((1-fractionSeparationLevel E)/6)
    (min (1/(8*(2+lowDeficitLocalScale f))) (min (1/16) (lowDeficitConstant f))))

theorem fractionSeparationLevel_lt_one {E : ℝ} (hE : 0<E) : fractionSeparationLevel E<1 := by
  exact max_lt (by norm_num) (Real.exp_lt_one_iff.mpr (by linarith only [hE]))

theorem fractionMarginConstant_pos {f ρ E : ℝ} (hf1 : f<1) (hρ : 0<ρ) (hE : 0<E) :
    0<fractionMarginConstant f ρ E := by
  have hD : 0<lowDeficitLocalScale f := zero_lt_one.trans_le (le_max_left _ _)
  have hg := lowDeficitConstant_pos hf1
  have hr := fractionSeparationLevel_lt_one hE
  have hrr : 0<1-fractionSeparationLevel E := sub_pos.mpr hr
  unfold fractionMarginConstant
  positivity

/-- Complete actual strict spatial margin for fractional parts close to zero. -/
theorem coupledProfiles_fraction_spatial_gap {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z E M ω ρ fL f x y : ℝ} (hγ : 0<γ) (hγhalf : γ≤1/2) (hM : 1≤M)
    (hρ : 0<ρ) (hω : 0≤ω) (hωρ : ω≤1-ρ)
    (hMρ : Real.exp (-M/2)≤ρ/4) (hEρ : Real.exp (-E/2)≤1-ρ)
    (hroot : 16*Real.sqrt γ≤E) (herror : (40*Real.exp (Real.log 12+1))*γ≤ρ/4)
    (hlog : 8*γ*(-Real.log (1/(8*(1+highProfileIntegralConstant f))))≤E)
    (hforward : (1+highProfileIntegralConstant f)*Real.exp (coupledProfileConstant+1)*Real.sqrt γ≤
      (1-fractionSeparationLevel E)/2)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hzE : z≤Real.exp (-E)) (hsmall : γ≤lowDeficitOrder fL)
    (hcap : ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤1-fractionMarginConstant fL ρ E*
      (γ+min ((N:ℝ)^2*y) 1+min ((ℓ:ℝ)^2*x) 1) := by
  have hγ1 : γ<1 := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hM0 : 0≤M := by linarith only [hM]
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hE : 0<E := lt_of_lt_of_le (by positivity : 0<16*Real.sqrt γ) hroot
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  have hc := (fractionMarginConstant_pos hfL1 hρ hE).le
  have hY0 : 0≤min ((N:ℝ)^2*y) 1 := le_min (by positivity) (by norm_num)
  have hZ0 : 0≤min ((ℓ:ℝ)^2*x) 1 := le_min (by positivity) (by norm_num)
  have hsum : γ+min ((N:ℝ)^2*y) 1+min ((ℓ:ℝ)^2*x) 1≤3 := by
    nlinarith only [min_le_right ((N:ℝ)^2*y) 1,min_le_right ((ℓ:ℝ)^2*x) 1,hγhalf]
  by_cases hY : γ≤(N:ℝ)^2*y
  · have hgap := coupledProfiles_fraction_outer_gap (by omega : 0<ℓ) (by omega : 0<N)
      hγ hγhalf hM0 hρ hω hωρ hMρ hEρ
      (by have h := Real.sqrt_nonneg γ;nlinarith only [hroot,h]) herror
      hfL hfL1 hf hf1.le hx hx1 hy hy1 hz hzE hY hcap
    have hcoef : fractionMarginConstant fL ρ E≤ρ/6 := min_le_left _ _
    have hm := mul_le_mul_of_nonneg_left hsum hc
    nlinarith only [hgap,hm,hcoef]
  have hYγ : (N:ℝ)^2*y≤γ := (lt_of_not_ge hY).le
  have hYδ : (N:ℝ)^2*y≤1-γ := by linarith only [hYγ,hγhalf]
  have hlocal := coupledProfiles_fraction_local_upper (by omega : 0<ℓ) hN hγ hγ1 hM0
    hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hz hz1 hYδ
  have hu := lowProfile_range (by omega : 0<ℓ) hγ hfL hfL1 hx hx1
  have hv := highProfile_range (by omega : 0<N) hd hf hf1.le hω hω1 hy hy1
  have hK : 0<1+highProfileIntegralConstant f := by have hp := highProfileIntegralConstant_pos f;linarith only [hp]
  by_cases hur : lowProfile ℓ γ fL x≤fractionSeparationLevel E
  · have hvsmall := highProfile_half_order_upper (by omega : 0<N)
      (by linarith only [hγhalf] : (1:ℝ)/2≤1-γ) (by linarith only [hγ] : 1-γ≤1)
      hf hf1.le hω hω1 hy hy1 (by linarith only [hYγ,hγhalf])
    have hsqrt := Real.sqrt_le_sqrt hYγ
    have hpower := (mul_le_mul_of_nonneg_left hsqrt (Real.exp_pos (coupledProfileConstant+1)).le)
    have hvsmall' := hvsmall.trans hpower
    have hvsmall'' := (mul_le_mul_of_nonneg_left hvsmall' hK.le).trans (by simpa only [mul_assoc] using hforward)
    have hlow : Real.exp (-M*γ)*lowProfile ℓ γ fL x≤fractionSeparationLevel E :=
      (mul_le_of_le_one_left hu.1 (Real.exp_le_one_iff.mpr (by nlinarith only [hM0,hγ]))).trans hur
    have hcoef : fractionMarginConstant fL ρ E≤(1-fractionSeparationLevel E)/6 :=
      (min_le_right _ _).trans (min_le_left _ _)
    have hm := mul_le_mul_of_nonneg_left hsum hc
    nlinarith only [hlocal,hvsmall'',hlow,hm,hcoef]
  have hr : fractionSeparationLevel E≤lowProfile ℓ γ fL x := (lt_of_not_ge hur).le
  have hprod := coupledProfiles_product_le (by omega : 0<ℓ) (by omega : 0<N) hγ hγ1
    hfL hfL1 hf hf1.le hω hω1 hx hx1 hy hy1 hz hcap
  have hvsep := product_exponential_separation hγ hγ1 hE.le ((le_max_right _ _).trans hr) hv.1 hprod hzE
  have hcpos : 0<1/(8*(1+highProfileIntegralConstant f)) := by positivity
  have hvsep' := (small_order_exp_div_linear (E:=E/2) hγ hcpos
    (by nlinarith only [hroot]) (by nlinarith only [hlog]))
  have hid : -(E/2)/γ=-E/(2*γ) := by ring
  rw [hid] at hvsep'
  have hvbudget := mul_le_mul_of_nonneg_left (hvsep.trans hvsep') hK.le
  have hident : (1+highProfileIntegralConstant f)*(1/(8*(1+highProfileIntegralConstant f))*γ)=γ/8 := by
    field_simp [hK.ne']
  rw [hident] at hvbudget
  have he : Real.exp (-M*γ)≤1-γ/2 := by
    exact (Real.exp_le_exp.mpr (by nlinarith only [hM,hγ])).trans (exp_neg_le_linear_half hγ.le hγ1.le)
  have hlow := mul_le_mul_of_nonneg_right he hu.1
  have hurhalf : (1:ℝ)/2≤lowProfile ℓ γ fL x := (le_max_left _ _).trans hr
  have hgap : coupledDampedExpression ℓ N γ z M ω fL f x y≤lowProfile ℓ γ fL x-γ/8 := by
    have hm := mul_le_mul_of_nonneg_left hurhalf hγ.le
    nlinarith only [hlocal,hvbudget,hlow,hm]
  by_cases hZ : lowDeficitLocalScale fL*γ≤(ℓ:ℝ)^2*x
  · have hdef := lowProfile_deficit hℓ hγ hγ1.le hfL hfL1 hx hx1 hsmall hZ
    have hcoef1 : fractionMarginConstant fL ρ E≤1/16 :=
      (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _)))
    have hcoef2 : fractionMarginConstant fL ρ E≤lowDeficitConstant fL :=
      (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _)))
    have hYmin := (min_le_left ((N:ℝ)^2*y) 1).trans hYγ
    have hmγ := mul_le_mul_of_nonneg_right hcoef1 hγ.le
    have hmY := mul_le_mul_of_nonneg_left hYmin hc
    have hmZ := mul_le_mul_of_nonneg_right hcoef2 hZ0
    nlinarith only [hgap,hdef,hmγ,hmY,hmZ]
  · have hZmin := (min_le_left ((ℓ:ℝ)^2*x) 1).trans (le_of_lt (lt_of_not_ge hZ))
    have hYmin := (min_le_left ((N:ℝ)^2*y) 1).trans hYγ
    have hsum' : γ+min ((N:ℝ)^2*y) 1+min ((ℓ:ℝ)^2*x) 1≤(2+lowDeficitLocalScale fL)*γ := by
      nlinarith only [hZmin,hYmin]
    have hcoef : fractionMarginConstant fL ρ E≤1/(8*(2+lowDeficitLocalScale fL)) :=
      (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
    have hden : 0<8*(2+lowDeficitLocalScale fL) := by
      have hd : 0<lowDeficitLocalScale fL := zero_lt_one.trans_le (le_max_left _ _)
      positivity
    have hcoef' := (le_div_iff₀ hden).mp hcoef
    have hm := mul_le_mul_of_nonneg_left hsum' hc
    have hmγ := mul_le_mul_of_nonneg_right hcoef' hγ.le
    nlinarith only [hgap,hu.2,hm,hmγ]

end Renyi
