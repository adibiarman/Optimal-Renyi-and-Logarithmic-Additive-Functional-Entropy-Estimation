import Renyi.PoissonToIID
import Renyi.IntegerRaw

/-!
# The integer-order iid upper theorem in the statistical model

The estimator is the logarithm of the raw collision statistic, applied to
histograms of actual iid samples. The final construction uses the randomized
fixed-sample estimator from `PoissonToIID`.
-/

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- The symmetric exponential power-sum band gives the exact entropy error. -/
theorem entropy_of_symmetric_power_band {beta eps P Z : ℝ}
    (hbeta : 0 < beta) (hP : 0 < P)
    (hlo : Real.exp (-eps * beta) * P ≤ Z)
    (hhi : Z ≤ Real.exp (eps * beta) * P) :
    |entropyFromPower beta Z - entropyFromPower beta P| ≤ eps := by
  have hZ : 0 < Z := lt_of_lt_of_le (mul_pos (Real.exp_pos _) hP) hlo
  have hl := Real.log_le_log (mul_pos (Real.exp_pos (-eps * beta)) hP) hlo
  have hh := Real.log_le_log hZ hhi
  rw [Real.log_mul (Real.exp_ne_zero _) (ne_of_gt hP), Real.log_exp] at hl hh
  unfold entropyFromPower
  simp only [neg_div]
  rw [abs_le]
  constructor
  · have h := (div_le_div_iff_of_pos_right hbeta).mpr hh
    have hid : (eps * beta + Real.log P) / beta = eps + Real.log P / beta := by field_simp
    rw [hid] at h
    linarith
  · have h := (div_le_div_iff_of_pos_right hbeta).mpr hl
    have hid : (-eps * beta + Real.log P) / beta = -eps + Real.log P / beta := by field_simp
    rw [hid] at h
    linarith

theorem simplex_powerSum_nat {k : ℕ} (p : Simplex k) (r : ℕ) :
    powerSum p (r : ℝ) = powerSumNat p.mass r := by
  simp [powerSum, powerSumNat, Real.rpow_natCast]

def iidHistogramCount {k : ℕ} (i : Fin k) (x : PoissonMarkedSample (Fin k)) : ℕ :=
  markHistogram x.2 i

/-- The estimator is independent of the unknown probability vector. -/
def rawIntegerEntropy {k : ℕ} (b : ℝ≥0) (r : ℕ)
    (x : PoissonMarkedSample (Fin k)) : ℝ :=
  entropyFromPower ((r : ℝ) - 1) (rawCollision iidHistogramCount r (b : ℝ) x)

theorem rawIntegerEntropy_error_subset {k : ℕ} (b : ℝ≥0) (p : Simplex k)
    {r : ℕ} (hr : 2 ≤ r) (eps : ℝ) :
    {x : PoissonMarkedSample (Fin k) | eps < |rawIntegerEntropy b r x - entropy p (r : ℝ)|} ⊆
      {x | rawCollision iidHistogramCount r (b : ℝ) x <
          Real.exp (-eps * ((r : ℝ) - 1)) * powerSumNat p.mass r ∨
        Real.exp (eps * ((r : ℝ) - 1)) * powerSumNat p.mass r <
          rawCollision iidHistogramCount r (b : ℝ) x} := by
  intro x hx
  by_contra hbad
  have hlo : Real.exp (-eps * ((r : ℝ) - 1)) * powerSumNat p.mass r ≤
      rawCollision iidHistogramCount r (b : ℝ) x := le_of_not_gt (fun h => hbad (Or.inl h))
  have hhi : rawCollision iidHistogramCount r (b : ℝ) x ≤
      Real.exp (eps * ((r : ℝ) - 1)) * powerSumNat p.mass r :=
    le_of_not_gt (fun h => hbad (Or.inr h))
  have hr2 : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have h := entropy_of_symmetric_power_band (by linarith : 0 < (r : ℝ) - 1)
    (powerSumNat_pos p.mass p.nonneg p.normalized r) hlo hhi
  dsimp only [Set.mem_setOf_eq] at hx
  unfold rawIntegerEntropy entropy at hx
  rw [simplex_powerSum_nat] at hx
  exact (not_lt_of_ge h) hx

theorem iidHistogramCount_law {k : ℕ} (b : ℝ≥0) (p : Simplex k) (i : Fin k) :
    MeasurePreserving (iidHistogramCount i)
      (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure
      (poissonMeasure (b * simplexNN p i)) :=
  poissonMarkedSample_histogram_coordinate b (simplexNN p) (simplexNN_sum p) i

theorem iidHistogramCount_independent {k : ℕ} (b : ℝ≥0) (p : Simplex k) :
    Pairwise (fun i j => IndepFun (iidHistogramCount i) (iidHistogramCount j)
      (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure) := by
  intro i j hij
  exact (poissonMarkedSample_histogram_independent b (simplexNN p)
    (simplexNN_sum p)).indepFun hij

/-- Exact Poisson sample mean chosen by the integer upper theorem. -/
def integerPoissonMean (k r : ℕ) (eps : ℝ) : ℝ≥0 :=
  Real.toNNReal (integerSampleConstant eps * r * (k : ℝ) ^ (1 - 1 / (r : ℝ)))

theorem integerPoissonMean_coe {eps : ℝ} (heps : 0 < eps) (k r : ℕ) :
    (integerPoissonMean k r eps : ℝ) =
      integerSampleConstant eps * r * (k : ℝ) ^ (1 - 1 / (r : ℝ)) := by
  unfold integerPoissonMean
  apply Real.coe_toNNReal
  have hD := integerSampleConstant_pos heps
  positivity

theorem integer_alphabet_scale_ge_one {k r : ℕ} (hk : 2 ≤ k) (hr : 2 ≤ r) :
    1 ≤ (k : ℝ) ^ (1 - 1 / (r : ℝ)) := by
  have hk2 : (2 : ℝ) ≤ k := by exact_mod_cast hk
  have hr2 : (2 : ℝ) ≤ r := by exact_mod_cast hr
  apply Real.one_le_rpow (by linarith)
  have hi : 1 / (r : ℝ) ≤ 1 := (div_le_one (by linarith : (0 : ℝ) < r)).mpr (by linarith)
  linarith

theorem integerPoissonMean_ge_Dr {eps : ℝ} (heps : 0 < eps)
    {k r : ℕ} (hk : 2 ≤ k) (hr : 2 ≤ r) :
    integerSampleConstant eps * r ≤ (integerPoissonMean k r eps : ℝ) := by
  rw [integerPoissonMean_coe heps]
  have hD := integerSampleConstant_pos heps
  simpa only [mul_one] using mul_le_mul_of_nonneg_left
    (integer_alphabet_scale_ge_one hk hr) (by positivity : 0 ≤ integerSampleConstant eps * r)

theorem integerPoissonMean_ge_one {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) {k r : ℕ} (hk : 2 ≤ k) (hr : 2 ≤ r) :
    1 ≤ (integerPoissonMean k r eps : ℝ) := by
  have hD := integerSampleConstant_pos heps
  have hDe := (div_le_iff₀ heps).mp (integerSampleConstant_ge_two_div heps)
  have hr2 : (2 : ℝ) ≤ r := by exact_mod_cast hr
  have hb := integerPoissonMean_ge_Dr heps hk hr
  nlinarith

theorem integer_iid_sample_size_bound {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) {k r : ℕ} (hk : 2 ≤ k) (hr : 2 ≤ r) :
    (⌈2 * (integerSampleConstant eps * r * (k : ℝ) ^ (1 - 1 / (r : ℝ)))⌉₊ : ℝ) ≤
      (3 * integerSampleConstant eps) * ((r : ℝ) * (k : ℝ) ^ (1 - 1 / (r : ℝ))) := by
  have h := poisson_fixed_sample_size_le (integerPoissonMean k r eps)
    (integerPoissonMean_ge_one heps hepshalf hk hr)
  rw [integerPoissonMean_coe heps] at h
  nlinarith

/-- Uniform entropy accuracy for the actual Poissonized iid sample and raw estimator. -/
theorem rawIntegerEntropy_poisson_error {k r : ℕ} (b : ℝ≥0) (p : Simplex k)
    (hr : 2 ≤ r) {eps : ℝ} (heps : 0 < eps) (hepshalf : eps ≤ 1 / 2)
    (hb : 0 < (b : ℝ))
    (hsize : integerSampleConstant eps * r * (k : ℝ) ^ (1 - 1 / (r : ℝ)) ≤ (b : ℝ)) :
    (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure.real
      {x | eps < |rawIntegerEntropy b r x - entropy p (r : ℝ)|} < 1 / 12 := by
  have hband := integer_raw_poisson_band iidHistogramCount
    (fun i => b * simplexNN p i) (iidHistogramCount_law b p)
    (iidHistogramCount_independent b p) r hr (b : ℝ) p.mass p.nonneg p.normalized
    eps heps hepshalf hb
    (fun i => by simp only [NNReal.coe_mul, simplexNN_coe])
    (by simpa only [Fintype.card_fin] using hsize)
  exact lt_of_le_of_lt (measureReal_mono (μ :=
    (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure)
    (rawIntegerEntropy_error_subset b p hr eps)) hband

/-- The complete source integer upper theorem, in the actual fixed-iid model.
The only hypotheses concern epsilon, the alphabet size, and the integer order. -/
theorem integer_iid_achievable {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) {k r : ℕ} (hk : 2 ≤ k) (hr : 2 ≤ r) :
    Achievable k
      ⌈2 * (integerSampleConstant eps * r * (k : ℝ) ^ (1 - 1 / (r : ℝ)))⌉₊
      (r : ℝ) eps := by
  have hb : 0 < (integerPoissonMean k r eps : ℝ) :=
    lt_of_lt_of_le zero_lt_one (integerPoissonMean_ge_one heps hepshalf hk hr)
  have h := integer_achievable_of_poissonized_error (integerPoissonMean k r eps)
    heps hepshalf hr (integerPoissonMean_ge_Dr heps hk hr)
    (rawIntegerEntropy (integerPoissonMean k r eps) r) (fun p =>
      (rawIntegerEntropy_poisson_error (integerPoissonMean k r eps) p hr heps hepshalf hb
        (by rw [integerPoissonMean_coe heps])).le)
  simpa only [integerPoissonMean_coe heps] using h

/-- Uniform O_epsilon(r k^(1-1/r)) iid achievability for every integer r >= 2. -/
theorem integer_iid_upper_uniform {eps : ℝ} (heps : 0 < eps)
    (hepshalf : eps ≤ 1 / 2) :
    ∃ C : ℝ, 0 < C ∧ ∀ k r : ℕ, 2 ≤ k → 2 ≤ r →
      ∃ m : ℕ, (m : ℝ) ≤ C * ((r : ℝ) * (k : ℝ) ^ (1 - 1 / (r : ℝ))) ∧
        Achievable k m (r : ℝ) eps := by
  refine ⟨3 * integerSampleConstant eps, mul_pos (by norm_num)
    (integerSampleConstant_pos heps), ?_⟩
  intro k r hk hr
  exact ⟨_, integer_iid_sample_size_bound heps hepshalf hk hr,
    integer_iid_achievable heps hepshalf hk hr⟩

end Renyi
