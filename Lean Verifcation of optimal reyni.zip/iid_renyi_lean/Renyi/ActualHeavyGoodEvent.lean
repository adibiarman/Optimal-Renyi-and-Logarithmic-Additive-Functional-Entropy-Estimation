import Renyi.OmegaHeavyFixedPilot
import Renyi.OmegaHeavyCompact
import Renyi.PilotOracleComparison

/-! One actual heavy event for both wide and compact reserved widths. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def actualHeavyGap (eps cw:ℝ) : ℝ := omegaHeavyMargin eps cw/2

theorem actualHeavyGap_pos {eps cw:ℝ} (heps:0<eps) (hcw:0<cw) (hcw1:cw<1) :
    0<actualHeavyGap eps cw := by
  have hh:0<omegaHeavyMargin eps cw:=
    (omega_heavy_fixed_concentration_uniform.{0} (rho:=1/32) heps hcw hcw1 (by norm_num) (by norm_num)).1
  exact div_pos hh (by norm_num)

theorem actualHeavyGap_lt_one (eps cw:ℝ) : actualHeavyGap eps cw<1 := by
  unfold actualHeavyGap omegaHeavyMargin
  linarith only [Real.exp_pos (-(omegaHeavyDistance cw*eps/2))]

def selectedTrueHeavyPowerSum {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) (alpha B:ℝ) : PilotHistogram k→ℝ :=
  fun h=>∑i∈trueHeavyPilotSubset p n alpha cp B (fun i=>pilotSelectionCount i h),(p.mass i)^alpha

def actualTrueHeavyStatistic {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) (alpha eps Ch cw B:ℝ) : PilotHistogram k→ℝ :=
  pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B (upperOmega k alpha eps Ch cw)

def actualHeavyGoodEvent {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) (alpha eps Ch cw B cH eta A:ℝ) : Set (PilotHistogram k) :=
  {h | upperKappa alpha eps*(1+cH)*selectedTrueHeavyPowerSum n cp p alpha B h≤
      actualTrueHeavyStatistic n cp p alpha eps Ch cw B h ∧
    actualTrueHeavyStatistic n cp p alpha eps Ch cw B h≤
      (1-cH)*selectedTrueHeavyPowerSum n cp p alpha B h ∧
    (alpha≤A → |actualTrueHeavyStatistic n cp p alpha eps Ch cw B h-
      upperOmega k alpha eps Ch cw*selectedTrueHeavyPowerSum n cp p alpha B h|≤
      eta*selectedTrueHeavyPowerSum n cp p alpha B h)}

/-- The small reserved-width condition forces the real order into a fixed
compact interval, uniformly in the alphabet and its fractional part. -/
theorem small_reserved_width_order_bound {alpha eps C E:ℝ}
    (heps:0<eps) (hC:0≤C)
    (hElow:eps*(alpha-1)/2≤E)
    (hEhigh:E<4*C*(fractionalPart alpha*(1-fractionalPart alpha))) :
    alpha≤2+8*C/eps := by
  have hh:fractionalPart alpha*(1-fractionalPart alpha)≤1/4:=by
    nlinarith only [sq_nonneg (fractionalPart alpha-1/2)]
  have hm:=mul_le_mul_of_nonneg_left hh (show 0≤4*C by positivity)
  have hprod:eps*(alpha-1)<2*C:=by linarith only [hElow,hEhigh,hm]
  have hbound:alpha<1+2*C/eps:=by
    have hh:eps*(alpha-1)/eps<2*C/eps:=(div_lt_div_iff_of_pos_right heps).mpr hprod
    rw [mul_div_cancel_left₀ _ heps.ne'] at hh
    linarith only [hh]
  have hnonneg:0≤C/eps:=div_nonneg hC heps.le
  have hid2:2*C/eps=2*(C/eps):=by ring
  have hid8:8*C/eps=8*(C/eps):=by ring
  rw [hid2] at hbound
  rw [hid8]
  linarith only [hbound,hnonneg]

/-- Both heavy concentration requirements hold on one concrete event of
probability at least fifteen sixteenths. All constants precede the experiment. -/
theorem actual_heavy_good_event_uniform {eps cw C eta:ℝ}
    (heps:0<eps) (hcw:0<cw) (hcw1:cw<1) (hC:0≤C) (heta:0<eta) :
    ∃B0:ℝ,16≤B0 ∧
      ∀B:ℝ,B0≤B → ∀{k:ℕ} (n cp:ℝ≥0),0<(n:ℝ) → ∀p:Simplex k,
      ∀alpha Ch:ℝ,3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → 0≤Ch →
      (15/16:ℝ)≤(pilotHistogramPMF n cp p).toMeasure.real
        (actualHeavyGoodEvent n cp p alpha eps Ch cw B (actualHeavyGap eps cw) eta (2+8*C/eps)) := by
  let rho:ℝ:=1/32
  let A:ℝ:=2+8*C/eps
  have hrho:0<rho:=by norm_num [rho]
  have hrho1:rho<1:=by norm_num [rho]
  have hA:0<A:=by dsimp [A]; positivity
  have hcm:0<omegaHeavyMargin eps cw:=
    (omega_heavy_fixed_concentration_uniform.{0} heps hcw hcw1 hrho hrho1).1
  let cH:=omegaHeavyMargin eps cw/2
  let B0:=max 16 (max (2*omegaHeavyScale eps cw rho) (2*compactHeavyScale A eta rho))
  refine ⟨B0,le_max_left _ _,?_⟩
  intro B hB k n cp hn p alpha Ch ha hg hg1 hCh
  have hBfixed:2*omegaHeavyScale eps cw rho≤B:=
    ((le_max_left _ _).trans (le_max_right _ _)).trans hB
  have hBcompact:2*compactHeavyScale A eta rho≤B:=
    ((le_max_right _ _).trans (le_max_right _ _)).trans hB
  have ha1:1<alpha:=by linarith only [ha]
  have hE:=upper_reserved_interval (k:=k) ha1 hg hg1 heps hCh
  have hfixed0:=omega_heavy_true_selection_fixed_concentration heps hcw hcw1 hrho hrho1
    n cp hn p ha hE.1 hE.2 (by norm_num : (0:ℝ)≤1) (le_refl (1:ℝ))
    (by nlinarith only [hcm]) hBfixed
  let HF:Set (PilotHistogram k):={h | upperKappa alpha eps*(1+cH)*selectedTrueHeavyPowerSum n cp p alpha B h≤
      actualTrueHeavyStatistic n cp p alpha eps Ch cw B h ∧
    actualTrueHeavyStatistic n cp p alpha eps Ch cw B h≤(1-cH)*selectedTrueHeavyPowerSum n cp p alpha B h}
  have hfixed:1-rho≤(pilotHistogramPMF n cp p).toMeasure.real HF:=by
    have hsubset:{h | (Real.exp (-(2*eps*(alpha-1)))+(omegaHeavyMargin eps cw/2)*Real.exp (-(2*eps*(alpha-1))))*
        (∑i∈trueHeavyPilotSubset p n alpha cp B (fun i=>pilotSelectionCount i h),(p.mass i)^alpha)≤
          pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B
            (1*Real.exp (-cw*upperE0 k alpha eps Ch)) h ∧
      pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B
        (1*Real.exp (-cw*upperE0 k alpha eps Ch)) h≤
          (1-omegaHeavyMargin eps cw/2)*(∑i∈trueHeavyPilotSubset p n alpha cp B (fun i=>pilotSelectionCount i h),(p.mass i)^alpha)}⊆HF:=by
      intro h hh
      dsimp only [HF,actualTrueHeavyStatistic,selectedTrueHeavyPowerSum,cH,upperKappa,upperOmega] at ⊢
      simp only [one_mul,neg_mul] at hh ⊢
      constructor
      · nlinarith only [hh.1]
      · exact hh.2
    exact hfixed0.trans (measureReal_mono (μ:=(pilotHistogramPMF n cp p).toMeasure) hsubset)
  by_cases hcompact:alpha≤A
  · have hw0:0≤upperOmega k alpha eps Ch cw:=(Real.exp_pos _).le
    have hw1:upperOmega k alpha eps Ch cw≤1:=Real.exp_le_one_iff.mpr (by
      have hE0:0<upperE0 k alpha eps Ch:=(mul_pos heps (sub_pos.mpr ha1)).trans_le hE.1
      nlinarith only [mul_pos hcw hE0])
    have hcompact0:=compact_heavy_true_selection_concentration hA heta hrho hrho1 n cp hn p
      ha hcompact hw0 hw1 hBcompact
    let HC:Set (PilotHistogram k):={h | |actualTrueHeavyStatistic n cp p alpha eps Ch cw B h-
      upperOmega k alpha eps Ch cw*selectedTrueHeavyPowerSum n cp p alpha B h|≤
      eta*selectedTrueHeavyPowerSum n cp p alpha B h}
    have hcompactProb:1-rho≤(pilotHistogramPMF n cp p).toMeasure.real HC:=hcompact0
    have hinter:1-2*rho≤(pilotHistogramPMF n cp p).toMeasure.real (HF∩HC):=by
      have hu:(pilotHistogramPMF n cp p).toMeasure.real (HF∪HC)≤1:=by
        simpa only [measureReal_univ_eq_one] using measureReal_mono
          (μ:=(pilotHistogramPMF n cp p).toMeasure) (Set.subset_univ (HF∪HC))
      have hid:=measureReal_union_add_inter (μ:=(pilotHistogramPMF n cp p).toMeasure)
        (s:=HF) (t:=HC) (Set.to_countable HC).measurableSet
      linarith only [hfixed,hcompactProb,hu,hid]
    have hsubset:HF∩HC⊆actualHeavyGoodEvent n cp p alpha eps Ch cw B cH eta A:=by
      intro h hh
      exact ⟨hh.1.1,hh.1.2,fun _=>hh.2⟩
    exact (by norm_num [rho] : (15/16:ℝ)≤1-2*rho).trans (hinter.trans
      (measureReal_mono (μ:=(pilotHistogramPMF n cp p).toMeasure) hsubset))
  · have hsubset:HF⊆actualHeavyGoodEvent n cp p alpha eps Ch cw B cH eta A:=by
      intro h hh
      exact ⟨hh.1,hh.2,fun h=>False.elim (hcompact h)⟩
    have hh:=hfixed.trans (measureReal_mono (μ:=(pilotHistogramPMF n cp p).toMeasure) hsubset)
    exact (by norm_num [rho] : (15/16:ℝ)≤1-rho).trans hh


/-- The selected true-heavy contribution is bounded by the full power sum. -/
theorem selectedTrueHeavyPowerSum_bounds {k:ℕ} (n cp:ℝ≥0) (p:Simplex k)
    (alpha B:ℝ) (h:PilotHistogram k) :
    0≤selectedTrueHeavyPowerSum n cp p alpha B h ∧
      selectedTrueHeavyPowerSum n cp p alpha B h≤powerSum p alpha := by
  constructor
  · exact Finset.sum_nonneg (fun i _=>Real.rpow_nonneg (p.nonneg i) alpha)
  · exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
      (fun i _ _=>Real.rpow_nonneg (p.nonneg i) alpha)

/-- The joint good-event probability is in the form used by the final union bound. -/
theorem actualHeavyGoodEvent_bad_le {k:ℕ} (n cp:ℝ≥0) (p:Simplex k)
    (alpha eps Ch cw B cH eta A:ℝ)
    (hgood:(15/16:ℝ)≤(pilotHistogramPMF n cp p).toMeasure.real
      (actualHeavyGoodEvent n cp p alpha eps Ch cw B cH eta A)) :
    (pilotHistogramPMF n cp p).toMeasure.real
      (actualHeavyGoodEvent n cp p alpha eps Ch cw B cH eta A)ᶜ≤1/16 := by
  have hh:=measureReal_add_measureReal_compl (μ:=(pilotHistogramPMF n cp p).toMeasure)
    (Set.to_countable (actualHeavyGoodEvent n cp p alpha eps Ch cw B cH eta A)).measurableSet
  simp only [measureReal_univ_eq_one] at hh
  linarith only [hh,hgood]

/-- The compact clause on the same good event applies directly to the source
small-width regime, including the final downward rescaling. -/
theorem actualHeavyGoodEvent_compact_of_width {k:ℕ} (n cp:ℝ≥0) (p:Simplex k)
    {alpha eps Ch cw B cH eta C E sigma:ℝ} (heps:0<eps) (hC:0≤C) (heta:0≤eta)
    (hsigma:0≤sigma) (hsigma1:sigma≤1)
    (hElow:eps*(alpha-1)/2≤E)
    (hEhigh:E<4*C*(fractionalPart alpha*(1-fractionalPart alpha)))
    {h:PilotHistogram k}
    (hgood:h∈actualHeavyGoodEvent n cp p alpha eps Ch cw B cH eta (2+8*C/eps)) :
    |sigma*actualTrueHeavyStatistic n cp p alpha eps Ch cw B h-
      sigma*upperOmega k alpha eps Ch cw*selectedTrueHeavyPowerSum n cp p alpha B h|≤eta*powerSum p alpha := by
  have hbounded:=small_reserved_width_order_bound heps hC hElow hEhigh
  have hh:=hgood.2.2 hbounded
  have hPH:=selectedTrueHeavyPowerSum_bounds n cp p alpha B h
  have hscaled:=mul_le_mul_of_nonneg_left hh hsigma
  have hsigmabound:=mul_le_of_le_one_left (mul_nonneg heta hPH.1) hsigma1
  have hfull:=mul_le_mul_of_nonneg_left hPH.2 heta
  have hid:sigma*actualTrueHeavyStatistic n cp p alpha eps Ch cw B h-
      sigma*upperOmega k alpha eps Ch cw*selectedTrueHeavyPowerSum n cp p alpha B h=
      sigma*(actualTrueHeavyStatistic n cp p alpha eps Ch cw B h-
        upperOmega k alpha eps Ch cw*selectedTrueHeavyPowerSum n cp p alpha B h):=by ring
  rw [hid,abs_mul,abs_of_nonneg hsigma]
  exact hscaled.trans (hsigmabound.trans hfull)


/-- The scalar omega satisfies the same fixed heavy band, uniformly in order. -/
theorem actual_heavy_omega_band {k:ℕ} {alpha eps Ch cw:ℝ}
    (heps:0<eps) (hcw:0<cw) (hcw1:cw<1) (ha:3/2≤alpha)
    (hg:0<fractionalPart alpha) (hg1:fractionalPart alpha<1) (hCh:0≤Ch) :
    upperKappa alpha eps*(1+actualHeavyGap eps cw)≤upperOmega k alpha eps Ch cw ∧
      upperOmega k alpha eps Ch cw≤1-actualHeavyGap eps cw := by
  have ha1:1<alpha:=by linarith only [ha]
  have hE:=upper_reserved_interval (k:=k) ha1 hg hg1 heps hCh
  let t:=omegaHeavyTolerance eps cw
  have hd:0<omegaHeavyDistance cw:=lt_min (by positivity) (sub_pos.mpr hcw1)
  have ht:0<t:=lt_min (by norm_num) (by change 0<omegaHeavyDistance cw*eps/12; positivity)
  have ht16:t≤1/16:=min_le_left _ _
  have hlow:(1-2*t)^alpha≤1:=Real.rpow_le_one (by linarith only [ht16])
    (by linarith only [ht]) (by linarith only [ha])
  have hhigh:1≤(1+2*t)^alpha:=Real.one_le_rpow (by linarith only [ht]) (by linarith only [ha])
  have hw0:0≤upperOmega k alpha eps Ch cw:=(Real.exp_pos _).le
  have hkap0:0≤upperKappa alpha eps:=(Real.exp_pos _).le
  have hcm:0≤omegaHeavyMargin eps cw:=by
    have hh:=actualHeavyGap_pos heps hcw hcw1
    unfold actualHeavyGap at hh
    linarith only [hh]
  have hscalar:upperKappa alpha eps+omegaHeavyMargin eps cw*upperKappa alpha eps≤
      upperOmega k alpha eps Ch cw*(1-2*t)^alpha ∧
      upperOmega k alpha eps Ch cw*(1+2*t)^alpha≤1-omegaHeavyMargin eps cw:=by
    simpa only [upperKappa,upperOmega,neg_mul,t] using
      omega_heavy_fixed_scalar_margins heps hcw hcw1 ha hE.1 hE.2
  have hl:=mul_le_mul_of_nonneg_left hlow hw0
  have hu:=mul_le_mul_of_nonneg_left hhigh hw0
  unfold actualHeavyGap
  constructor
  · nlinarith only [hscalar.1,hl,mul_nonneg hcm hkap0]
  · nlinarith only [hscalar.2,hu,hcm]

/-- The actual compact width gives exactly the order cap used by the joint event. -/
theorem actual_compact_width_order_bound {alpha eps W:ℝ} (heps:0<eps) (hW:0<W)
    (hg:0<fractionalPart alpha) (hg1:fractionalPart alpha<1)
    (hwidth:2*eps*(alpha-1)/(fractionalPart alpha*(1-fractionalPart alpha))≤W) :
    alpha≤2+8*W/eps := by
  have hh:0<fractionalPart alpha*(1-fractionalPart alpha):=mul_pos hg (sub_pos.mpr hg1)
  have hp:2*eps*(alpha-1)≤W*(fractionalPart alpha*(1-fractionalPart alpha)):=
    (div_le_iff₀ hh).mp hwidth
  have hWh:0<W*(fractionalPart alpha*(1-fractionalPart alpha)):=mul_pos hW hh
  exact small_reserved_width_order_bound heps hW.le (le_refl (eps*(alpha-1)/2))
    (by nlinarith only [hp,hWh])

/-- The normalized compact width used in the actual deterministic oracle
activates the same joint heavy event, with no additional probability loss. -/
theorem actualHeavyGoodEvent_compact_of_actual_width {k:ℕ} (n cp:ℝ≥0) (p:Simplex k)
    {alpha eps Ch cw B cH eta W sigma:ℝ} (heps:0<eps) (hW:0<W) (heta:0≤eta)
    (hg:0<fractionalPart alpha) (hg1:fractionalPart alpha<1)
    (hsigma:0≤sigma) (hsigma1:sigma≤1)
    (hwidth:2*eps*(alpha-1)/(fractionalPart alpha*(1-fractionalPart alpha))≤W)
    {h:PilotHistogram k}
    (hgood:h∈actualHeavyGoodEvent n cp p alpha eps Ch cw B cH eta (2+8*W/eps)) :
    |sigma*actualTrueHeavyStatistic n cp p alpha eps Ch cw B h-
      sigma*upperOmega k alpha eps Ch cw*selectedTrueHeavyPowerSum n cp p alpha B h|≤eta*powerSum p alpha := by
  have hh:=hgood.2.2 (actual_compact_width_order_bound heps hW hg hg1 hwidth)
  have hPH:=selectedTrueHeavyPowerSum_bounds n cp p alpha B h
  have hscaled:=mul_le_mul_of_nonneg_left hh hsigma
  have hsigmabound:=mul_le_of_le_one_left (mul_nonneg heta hPH.1) hsigma1
  have hfull:=mul_le_mul_of_nonneg_left hPH.2 heta
  have hid:sigma*actualTrueHeavyStatistic n cp p alpha eps Ch cw B h-
      sigma*upperOmega k alpha eps Ch cw*selectedTrueHeavyPowerSum n cp p alpha B h=
      sigma*(actualTrueHeavyStatistic n cp p alpha eps Ch cw B h-
        upperOmega k alpha eps Ch cw*selectedTrueHeavyPowerSum n cp p alpha B h):=by ring
  rw [hid,abs_mul,abs_of_nonneg hsigma]
  exact hscaled.trans (hsigmabound.trans hfull)


@[simp] theorem selectedTrueHeavyPowerSum_eq_pilotTrueHeavyMass {k:ℕ} (n cp:ℝ≥0)
    (p:Simplex k) (alpha B:ℝ) (h:PilotHistogram k) :
    selectedTrueHeavyPowerSum n cp p alpha B h=
      pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h := by
  simp only [selectedTrueHeavyPowerSum,trueHeavyPilotSubset,Finset.sum_filter,pilotTrueHeavyMass]

@[simp] theorem upperOmega_one_eighth (k:ℕ) (alpha eps Ch:ℝ) :
    upperOmega k alpha eps Ch (1/8)=Real.exp (-upperE0 k alpha eps Ch/8) := by
  unfold upperOmega
  congr 1
  ring


/-- The fixed clause in the exact mass notation of the assigned-oracle bridge. -/
theorem actualHeavyGoodEvent_fixed_band {k:ℕ} {n cp:ℝ≥0} {p:Simplex k}
    {alpha eps Ch cw B cH eta A:ℝ} {h:PilotHistogram k}
    (hgood:h∈actualHeavyGoodEvent n cp p alpha eps Ch cw B cH eta A) :
    upperKappa alpha eps*(1+cH)*pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h≤
      pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B
        (upperOmega k alpha eps Ch cw) h ∧
    pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B
      (upperOmega k alpha eps Ch cw) h≤(1-cH)*pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h := by
  simpa only [actualTrueHeavyStatistic,selectedTrueHeavyPowerSum_eq_pilotTrueHeavyMass] using
    And.intro hgood.1 hgood.2.1

/-- The compact clause in the exact mass notation of the assigned-oracle bridge. -/
theorem actualHeavyGoodEvent_compact_band {k:ℕ} {n cp:ℝ≥0} {p:Simplex k}
    {alpha eps Ch cw B cH eta A:ℝ} {h:PilotHistogram k}
    (hgood:h∈actualHeavyGoodEvent n cp p alpha eps Ch cw B cH eta A) (horder:alpha≤A) :
    |pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B
        (upperOmega k alpha eps Ch cw) h-
      upperOmega k alpha eps Ch cw*pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h|≤
        eta*pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h := by
  simpa only [actualTrueHeavyStatistic,selectedTrueHeavyPowerSum_eq_pilotTrueHeavyMass] using hgood.2.2 horder

end Renyi

