import Renyi.PoissonToIID
import Renyi.DiscreteTesting

/-! Coordinate concentration for the actual Poissonized iid histogram. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

theorem poisson_centered_exponential_hasSum (μ : ℝ≥0) (s R : ℝ) :
    HasSum (fun n : ℕ => Real.exp (s * ((n : ℝ) - μ) - R) * poissonPMFReal μ n)
      (Real.exp ((μ : ℝ) * (Real.exp s - 1 - s) - R)) := by
  have h := (poisson_exp_hasSum μ s).mul_left (Real.exp (-s * μ - R))
  have hv : Real.exp (-s * μ - R) * Real.exp ((μ : ℝ) * (Real.exp s - 1)) =
      Real.exp ((μ : ℝ) * (Real.exp s - 1 - s) - R) := by
    rw [← Real.exp_add]
    congr 1
    ring
  rw [hv] at h
  apply h.congr_fun
  intro n
  rw [← mul_assoc, ← Real.exp_add]
  congr 2
  ring

/-- A direct two-sided exponential bound with relative and additive tolerance. -/
theorem poisson_relative_additive_tail (μ : ℝ≥0) {η A : ℝ}
    (hη : 0 < η) (hη1 : η ≤ 1) :
    (poissonMeasure μ).real {n : ℕ | η * ((μ : ℝ) + A) < |(n : ℝ) - μ|} ≤
      2 * Real.exp (-(η ^ 2 * A / 2)) := by
  classical
  let s := η / 2
  let T := η * ((μ : ℝ) + A)
  let B : Set ℕ := {n : ℕ | T < |(n : ℝ) - μ|}
  have hs0 : 0 ≤ s := by dsimp [s]; positivity
  have hs1 : |s| ≤ 1 := by dsimp [s]; rw [abs_of_pos (by positivity)]; linarith
  have hpos := poisson_centered_exponential_hasSum μ s (s * T)
  have hneg := poisson_centered_exponential_hasSum μ (-s) (s * T)
  have hevent := pmf_event_real_hasSum (poissonPMF μ) B
  have hmass (n : ℕ) : (poissonPMF μ n).toReal = poissonPMFReal μ n := by
    exact ENNReal.toReal_ofReal poissonPMFReal_nonneg
  simp only [hmass] at hevent
  have hpoint (n : ℕ) : poissonPMFReal μ n * B.indicator (fun _ => (1 : ℝ)) n ≤
      Real.exp (s * ((n : ℝ) - μ) - s * T) * poissonPMFReal μ n +
        Real.exp (-s * ((n : ℝ) - μ) - s * T) * poissonPMFReal μ n := by
    by_cases hn : n ∈ B
    · rw [Set.indicator_of_mem hn, mul_one]
      have hnt : T < |(n : ℝ) - μ| := hn
      rcases lt_abs.mp hnt with hplus | hminus
      · have he : 1 ≤ Real.exp (s * ((n : ℝ) - μ) - s * T) :=
          Real.one_le_exp_iff.mpr (by nlinarith [mul_nonneg hs0 (sub_nonneg.mpr hplus.le)])
        have hm := mul_le_mul_of_nonneg_right he (poissonPMFReal_nonneg (r := μ) (n := n))
        nlinarith [mul_nonneg (Real.exp_pos (-s * ((n : ℝ) - μ) - s * T)).le
          (poissonPMFReal_nonneg (r := μ) (n := n))]
      · have he : 1 ≤ Real.exp (-s * ((n : ℝ) - μ) - s * T) :=
          Real.one_le_exp_iff.mpr (by nlinarith [mul_nonneg hs0 (sub_nonneg.mpr hminus.le)])
        have hm := mul_le_mul_of_nonneg_right he (poissonPMFReal_nonneg (r := μ) (n := n))
        nlinarith [mul_nonneg (Real.exp_pos (s * ((n : ℝ) - μ) - s * T)).le
          (poissonPMFReal_nonneg (r := μ) (n := n))]
    · rw [Set.indicator_of_notMem hn, mul_zero]
      exact add_nonneg (mul_nonneg (Real.exp_pos _).le poissonPMFReal_nonneg)
        (mul_nonneg (Real.exp_pos _).le poissonPMFReal_nonneg)
  have hsum := hevent.summable.tsum_le_tsum hpoint (hpos.add hneg).summable
  rw [hevent.tsum_eq, (hpos.add hneg).tsum_eq] at hsum
  have hb (v : ℝ) (hv : v = s ∨ v = -s) :
      Real.exp ((μ : ℝ) * (Real.exp v - 1 - v) - s * T) ≤
        Real.exp (-(η ^ 2 * A / 2)) := by
    have hvabs : |v| ≤ 1 := by rcases hv with rfl | rfl <;> simpa using hs1
    have hsq : v ^ 2 = s ^ 2 := by rcases hv with rfl | rfl <;> ring
    have hrem := (abs_le.mp (Real.abs_exp_sub_one_sub_id_le hvabs)).2
    rw [hsq] at hrem
    have hm := mul_le_mul_of_nonneg_left hrem μ.coe_nonneg
    apply Real.exp_le_exp.mpr
    dsimp [s, T] at hm ⊢
    nlinarith [mul_nonneg (sq_nonneg η) μ.coe_nonneg]
  exact hsum.trans (by nlinarith [hb s (Or.inl rfl), hb (-s) (Or.inr rfl)])

/-- Uniform control of every empirical coordinate in the original random-length
iid sample; this uses the proved Poisson marginal law and a finite union bound. -/
theorem poisson_histogram_relative_tail {k : ℕ} (hk : 0 < k) (b : ℝ≥0)
    (hb : 0 < (b : ℝ)) (p : Simplex k) {η : ℝ} (hη : 0 < η) (hη1 : η ≤ 1) :
    (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure.real
      {x | ∃ i : Fin k, η * (p.mass i + 1 / (k : ℝ)) <
        |(markHistogram x.2 i : ℝ) / b - p.mass i|} ≤
      2 * (k : ℝ) * Real.exp (-(η ^ 2 * ((b : ℝ) / k) / 2)) := by
  have hkR : 0 < (k : ℝ) := by exact_mod_cast hk
  let P := (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure
  let B (i : Fin k) : Set (PoissonMarkedSample (Fin k)) :=
    {x | η * (p.mass i + 1 / (k : ℝ)) < |(markHistogram x.2 i : ℝ) / b - p.mass i|}
  have hcoord (i : Fin k) : P.real (B i) ≤
      2 * Real.exp (-(η ^ 2 * ((b : ℝ) / k) / 2)) := by
    let μ := b * simplexNN p i
    let E : Set ℕ := {n | η * ((μ : ℝ) + (b : ℝ) / k) < |(n : ℝ) - μ|}
    have heq : B i = (fun x : PoissonMarkedSample (Fin k) => markHistogram x.2 i) ⁻¹' E := by
      ext x
      change η * (p.mass i + 1 / (k : ℝ)) < |(markHistogram x.2 i : ℝ) / b - p.mass i| ↔ _
      have hid : (markHistogram x.2 i : ℝ) / b - p.mass i =
          ((markHistogram x.2 i : ℝ) - (b : ℝ) * p.mass i) / b := by field_simp
      rw [hid, abs_div, abs_of_pos hb, lt_div_iff₀ hb]
      dsimp [E, μ, simplexNN]
      ring_nf
    have hpres := poissonMarkedSample_histogram_coordinate b (simplexNN p) (simplexNN_sum p) i
    have hm := hpres.measure_preimage (s := E) (Set.to_countable E).measurableSet.nullMeasurableSet
    rw [heq]
    change (P ((fun x : PoissonMarkedSample (Fin k) => markHistogram x.2 i) ⁻¹' E)).toReal ≤ _
    rw [hm]
    exact poisson_relative_additive_tail μ hη hη1
  have hu := measureReal_iUnion_fintype_le (μ := P) B
  have heq : {x : PoissonMarkedSample (Fin k) | ∃ i : Fin k,
      η * (p.mass i + 1 / (k : ℝ)) < |(markHistogram x.2 i : ℝ) / b - p.mass i|} = ⋃ i, B i := by
    ext x
    simp [B]
  rw [heq]
  apply hu.trans
  calc
    (∑ i, P.real (B i)) ≤ ∑ _i : Fin k, 2 * Real.exp (-(η ^ 2 * ((b : ℝ) / k) / 2)) :=
      Finset.sum_le_sum (fun i _ => hcoord i)
    _ = _ := by simp [mul_assoc, mul_comm]

end Renyi
