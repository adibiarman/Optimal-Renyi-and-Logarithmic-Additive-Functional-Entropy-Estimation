import Renyi.NearOneRateParameters
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

/-! Uniform decay of the logarithmic budgets in the near-one variance proof. -/
noncomputable section
open Filter Asymptotics
namespace Renyi

def nearOneLogWeight (k : ℕ) : ℝ := 1 + Real.log 3 + Real.log k

theorem near_one_log_power_decay (m : ℕ) {C r eta : ℝ}
    (hC : 0 ≤ C) (hr : 0 < r) (heta : 0 < eta) :
    ∃ K : ℕ, ∀ k : ℕ, K ≤ k → C * nearOneLogWeight k ^ m / (k : ℝ) ^ r ≤ eta := by
  let CW : ℝ := 2 + Real.log 3
  have hlog3 : 0 ≤ Real.log 3 := Real.log_nonneg (by norm_num)
  have hCW : 0 < CW := by dsimp [CW]; linarith
  let e := eta / (C * CW ^ m + 1)
  have hden : 0 < C * CW ^ m + 1 := by positivity
  have he : 0 < e := div_pos heta hden
  have hbound := (isLittleO_log_rpow_rpow_atTop (m : ℝ) hr).def he
  have hnat : Tendsto (fun k : ℕ => (k : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hboundNat := hnat.eventually hbound
  have hlarge := hnat.eventually (eventually_ge_atTop (Real.exp 1))
  have hfinal : ∀ᶠ k : ℕ in atTop, C * nearOneLogWeight k ^ m / (k : ℝ) ^ r ≤ eta := by
    filter_upwards [hboundNat, hlarge] with k hk hkl
    have hkpos : (0 : ℝ) < k := (Real.exp_pos 1).trans_le hkl
    have hlog1 : 1 ≤ Real.log k := by
      have hh := Real.log_le_log (Real.exp_pos 1) hkl
      simpa only [Real.log_exp] using hh
    have hlog0 : 0 ≤ Real.log k := by linarith
    have hW0 : 0 ≤ nearOneLogWeight k := by dsimp [nearOneLogWeight]; linarith
    have hW : nearOneLogWeight k ≤ CW * Real.log k := by
      have hh := mul_le_mul_of_nonneg_left hlog1 (show 0 ≤ 1 + Real.log 3 by linarith)
      dsimp [nearOneLogWeight, CW]
      nlinarith only [hh]
    have hpow := pow_le_pow_left₀ hW0 hW m
    rw [mul_pow] at hpow
    rw [Real.rpow_natCast] at hk
    rw [Real.norm_of_nonneg (pow_nonneg hlog0 m), Real.norm_of_nonneg (Real.rpow_nonneg hkpos.le r)] at hk
    have hfirst := mul_le_mul_of_nonneg_left hpow hC
    have hsecond := mul_le_mul_of_nonneg_left hk (mul_nonneg hC (pow_nonneg hCW.le m))
    have hcoeff : C * CW ^ m * e ≤ eta := by
      dsimp [e]
      rw [← mul_div_assoc]
      apply (div_le_iff₀ hden).2
      nlinarith only [heta]
    have hlast := mul_le_mul_of_nonneg_right hcoeff (Real.rpow_nonneg hkpos.le r)
    apply (div_le_iff₀ (Real.rpow_pos_of_pos hkpos r)).2
    nlinarith only [hfirst, hsecond, hlast]
  exact eventually_atTop.mp hfinal

end Renyi
