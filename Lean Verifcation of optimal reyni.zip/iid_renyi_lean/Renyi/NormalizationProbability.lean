import Renyi.Normalization
import Mathlib.Probability.Moments.Variance
import Mathlib.Probability.IdentDistrib
import Mathlib.Probability.ProbabilityMassFunction.Integrals

/-!
# Probability of failure of lower-prior normalization

The fixed-size independent experiment is proved from marginal second moments
and independence. Aggregate variance identities are derived in the proof.
-/

noncomputable section
open scoped BigOperators ENNReal NNReal
open MeasureTheory ProbabilityTheory

namespace Renyi

/-- A summable absolute Poisson moment defines an integrable random variable. -/
theorem poisson_integrable_of_summable (lam : ℝ≥0) (f : ℕ → ℝ)
    (hs : Summable (fun n => ‖f n‖ * poissonPMFReal lam n)) :
    Integrable f (poissonMeasure lam) := by
  refine ⟨(measurable_of_countable f).aestronglyMeasurable, ?_⟩
  rw [hasFiniteIntegral_iff_norm, lintegral_countable']
  have hmass (n : ℕ) : poissonMeasure lam {n} = ENNReal.ofReal (poissonPMFReal lam n) :=
    PMF.toMeasure_apply_singleton _ _ (MeasurableSet.singleton _)
  simp_rw [hmass, ← ENNReal.ofReal_mul (norm_nonneg _)]
  rw [← ENNReal.ofReal_tsum_of_nonneg
    (fun n => mul_nonneg (norm_nonneg (f n)) poissonPMFReal_nonneg) hs]
  exact ENNReal.ofReal_lt_top

theorem poisson_integral_eq_tsum (lam : ℝ≥0) (f : ℕ → ℝ)
    (hf : Integrable f (poissonMeasure lam)) :
    (∫ n, f n ∂poissonMeasure lam) = ∑' n, f n * poissonPMFReal lam n := by
  rw [poissonMeasure, PMF.integral_eq_tsum _ _ hf]
  apply tsum_congr
  intro n
  change (ENNReal.ofReal (poissonPMFReal lam n)).toReal * f n = f n * poissonPMFReal lam n
  rw [ENNReal.toReal_ofReal poissonPMFReal_nonneg]
  ring

theorem poisson_nat_second_hasSum (lam : ℝ≥0) :
    HasSum (fun n : ℕ => (n : ℝ) ^ 2 * poissonPMFReal lam n)
      ((lam : ℝ) ^ 2 + (lam : ℝ)) := by
  have hid (n : ℕ) : (n : ℝ) ^ 2 = (n.descFactorial 2 : ℝ) + (n : ℝ) := by
    cases n with
    | zero => norm_num [Nat.descFactorial_succ]
    | succ n => simp [Nat.descFactorial_succ, Nat.cast_add]; ring
  have h := (poisson_factorial_hasSum lam 2).add (poisson_factorial_hasSum lam 1)
  simpa only [hid, add_mul, Nat.descFactorial_one, pow_one] using h

theorem poisson_nat_memLp (lam : ℝ≥0) :
    MemLp (fun n : ℕ => (n : ℝ)) 2 (poissonMeasure lam) := by
  apply (memLp_two_iff_integrable_sq (by fun_prop)).2
  apply poisson_integrable_of_summable
  simpa only [Real.norm_eq_abs, abs_pow, Nat.abs_cast] using
    (poisson_nat_second_hasSum lam).summable

/-- A convergent squared Poisson moment gives the full L2 condition. -/
theorem poisson_memLp_of_squared_hasSum (lam : ℝ≥0) (f : ℕ → ℝ) (c : ℝ)
    (hs : HasSum (fun n => f n ^ 2 * poissonPMFReal lam n) c) :
    MemLp f 2 (poissonMeasure lam) := by
  apply (memLp_two_iff_integrable_sq (measurable_of_countable f).aestronglyMeasurable).2
  apply poisson_integrable_of_summable
  simpa only [Real.norm_of_nonneg (sq_nonneg _)] using hs.summable

theorem poisson_nat_mean (lam : ℝ≥0) :
    (∫ n : ℕ, (n : ℝ) ∂poissonMeasure lam) = (lam : ℝ) := by
  rw [poisson_integral_eq_tsum lam _ ((poisson_nat_memLp lam).integrable one_le_two)]
  simpa only [Nat.descFactorial_one, pow_one] using poisson_factorial_moment lam 1

theorem poisson_nat_variance (lam : ℝ≥0) :
    variance (fun n : ℕ => (n : ℝ)) (poissonMeasure lam) = (lam : ℝ) := by
  rw [variance_eq_sub (poisson_nat_memLp lam), poisson_nat_mean]
  simp only [Pi.pow_apply]
  rw [poisson_integral_eq_tsum lam _ (poisson_nat_memLp lam).integrable_sq]
  rw [(poisson_nat_second_hasSum lam).tsum_eq]
  ring

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

/-- Real-valued Chebyshev bound for the strict deviation event. -/
theorem real_chebyshev_gt {X : Ω → ℝ} (hX : MemLp X 2 μ) {t : ℝ} (ht : 0 < t) :
    μ.real {ω | t < |X ω - ∫ x, X x ∂μ|} ≤ variance X μ / t ^ 2 := by
  have h := meas_ge_le_variance_div_sq hX ht
  have hreal := ENNReal.toReal_mono (by finiteness) h
  rw [ENNReal.toReal_ofReal (div_nonneg (variance_nonneg X μ) (sq_nonneg t))] at hreal
  have hsub : {ω | t < |X ω - ∫ x, X x ∂μ|} ⊆
      {ω | t ≤ |X ω - ∫ x, X x ∂μ|} := by
    intro ω hx
    change t ≤ |X ω - ∫ x, X x ∂μ|
    exact le_of_lt hx
  exact (measureReal_mono (μ := μ) hsub).trans hreal

def sampleAverage {N : ℕ} (X : Fin N → Ω → ℝ) : Ω → ℝ :=
  fun ω => (N : ℝ)⁻¹ * ∑ i, X i ω

omit [IsProbabilityMeasure μ] in
theorem sampleAverage_memLp {N : ℕ} (X : Fin N → Ω → ℝ)
    (hX : ∀ i, MemLp (X i) 2 μ) : MemLp (sampleAverage X) 2 μ := by
  have hs : MemLp (fun ω => ∑ i, X i ω) 2 μ := by
    convert (memLp_finset_sum' (s := Finset.univ) (f := X) (fun i _ => hX i)) using 1
    funext ω
    simp
  exact hs.const_mul _

theorem sampleAverage_mean {N : ℕ} (hN : 0 < N) (X : Fin N → Ω → ℝ)
    (hX : ∀ i, MemLp (X i) 2 μ) {a : ℝ}
    (hmean : ∀ i, ∫ ω, X i ω ∂μ = a) :
    ∫ ω, sampleAverage X ω ∂μ = a := by
  have hN0 : (N : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hN)
  unfold sampleAverage
  rw [integral_const_mul, integral_finset_sum]
  · simp only [hmean, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
    field_simp
  · intro i _
    exact (hX i).integrable one_le_two

omit [IsProbabilityMeasure μ] in
theorem sampleAverage_variance {N : ℕ} (hN : 0 < N) (X : Fin N → Ω → ℝ)
    (hX : ∀ i, MemLp (X i) 2 μ)
    (hpair : Pairwise (fun i j => IndepFun (X i) (X j) μ)) {v : ℝ}
    (hvar : ∀ i, variance (X i) μ = v) :
    variance (sampleAverage X) μ = v / N := by
  have hN0 : (N : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hN)
  have hs : variance (fun ω => ∑ i, X i ω) μ = ∑ i, variance (X i) μ := by
    convert (IndepFun.variance_sum (s := Finset.univ) (X := X)
        (fun i _ => hX i) (fun i _ j _ hij => hpair hij)) using 1
    congr 1
    funext ω
    simp
  unfold sampleAverage
  rw [variance_mul, hs]
  simp only [hvar, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  field_simp

/-- The exact union bound, once two centered random errors have been identified. -/
theorem normalization_event_failure {S W : Ω → ℝ}
    (hS : MemLp S 2 μ) (hW : MemLp W 2 μ)
    (hSmean : ∫ ω, S ω ∂μ = 1) (hWmean : ∫ ω, W ω ∂μ = 0)
    {A t u : ℝ} (hA : 0 < A) (ht : 0 < t) (hu : 0 < u) :
    μ.real {ω | t < |S ω - 1| ∨ A * u < |W ω|} ≤
      variance S μ / t ^ 2 + variance W μ / (A ^ 2 * u ^ 2) := by
  have hs := real_chebyshev_gt hS ht
  have hw := real_chebyshev_gt hW (mul_pos hA hu)
  rw [hSmean] at hs
  rw [hWmean] at hw
  simp only [sub_zero, mul_pow] at hw
  exact (measureReal_union_le {ω | t < |S ω - 1|} {ω | A * u < |W ω|}).trans
    (add_le_add hs hw)

variable {Ω' : Type*} [MeasurableSpace Ω'] {ν : Measure Ω'} [IsProbabilityMeasure ν]

/-- The full failure bound for the fixed-size i.i.d. normalization experiment.

The two aggregate variances are derived from independence and identical laws.
Only the original one-coordinate second moments are assumed finite.
-/
theorem iid_normalization_probability {N : ℕ} (hN : 0 < N)
    (U : Ω' → ℝ) (X : Fin N → Ω → ℝ) (α A t u : ℝ)
    (hU : MemLp U 2 ν) (hUα : MemLp (fun ω => U ω ^ α) 2 ν)
    (hmean : ∫ ω, U ω ∂ν = 1) (hpower : ∫ ω, U ω ^ α ∂ν = A)
    (hident : ∀ i, IdentDistrib U (X i) ν μ)
    (hpair : Pairwise (fun i j => IndepFun (X i) (X j) μ))
    (hA : 0 < A) (ht : 0 < t) (hu : 0 < u) :
    μ.real {ω | t < |sampleAverage X ω - 1| ∨
      A * u < |sampleAverage (fun i ω => X i ω ^ α) ω - A * sampleAverage X ω|} ≤
      variance U ν / ((N : ℝ) * t ^ 2) +
        (∫ ω, (U ω ^ α - A * U ω) ^ 2 ∂ν) / ((N : ℝ) * A ^ 2 * u ^ 2) := by
  let g : ℝ → ℝ := fun x => x ^ α - A * x
  let Y : Fin N → Ω → ℝ := fun i ω => g (X i ω)
  have hg : Measurable g := by unfold g; fun_prop
  have hX : ∀ i, MemLp (X i) 2 μ := fun i => (hident i).memLp_snd hU
  have hG : MemLp (g ∘ U) 2 ν := hUα.sub (hU.const_mul A)
  have hGmean : ∫ ω, g (U ω) ∂ν = 0 := by
    change ∫ ω, U ω ^ α - A * U ω ∂ν = 0
    rw [integral_sub (hUα.integrable one_le_two)
      ((hU.integrable one_le_two).const_mul A), integral_const_mul, hpower, hmean]
    ring
  have hY : ∀ i, MemLp (Y i) 2 μ := fun i => ((hident i).comp hg).memLp_snd hG
  have hYpair : Pairwise (fun i j => IndepFun (Y i) (Y j) μ) :=
    fun _ _ hij => (hpair hij).comp hg hg
  have hXmean : ∀ i, ∫ ω, X i ω ∂μ = 1 :=
    fun i => (hident i).integral_eq.symm.trans hmean
  have hYmean : ∀ i, ∫ ω, Y i ω ∂μ = 0 :=
    fun i => ((hident i).comp hg).integral_eq.symm.trans hGmean
  have hXvar : ∀ i, variance (X i) μ = variance U ν :=
    fun i => (hident i).variance_eq.symm
  have hYvar : ∀ i, variance (Y i) μ = ∫ ω, (U ω ^ α - A * U ω) ^ 2 ∂ν := by
    intro i
    change variance (g ∘ X i) μ = _
    rw [← ((hident i).comp hg).variance_eq]
    exact variance_of_integral_eq_zero hG.aemeasurable hGmean
  have hSX := sampleAverage_memLp X hX
  have hWY := sampleAverage_memLp Y hY
  have hSXmean := sampleAverage_mean hN X hX hXmean
  have hWYmean := sampleAverage_mean hN Y hY hYmean
  have hSXvar := sampleAverage_variance hN X hX hpair hXvar
  have hWYvar := sampleAverage_variance hN Y hY hYpair hYvar
  have h := normalization_event_failure hSX hWY hSXmean hWYmean hA ht hu
  have hres (ω : Ω) : sampleAverage Y ω =
      sampleAverage (fun i ω => X i ω ^ α) ω - A * sampleAverage X ω := by
    simp only [sampleAverage, Y, g, Finset.sum_sub_distrib, ← Finset.mul_sum]
    ring
  simp_rw [hres] at h
  rw [hSXvar, hWYvar] at h
  convert h using 1
  ring

/-- Independent Poisson multiplicities of finitely many atom types. -/
def poissonAtomAverage {L : ℕ} (b : ℝ≥0) (C : Fin L → Ω → ℝ)
    (z : Fin L → ℝ) : Ω → ℝ :=
  fun ω => (b : ℝ)⁻¹ * ∑ i, z i * C i ω

omit [IsProbabilityMeasure μ] in
theorem poissonAtomAverage_memLp {L : ℕ} (b : ℝ≥0) (p : Fin L → ℝ≥0)
    (C : Fin L → Ω → ℝ) (z : Fin L → ℝ)
    (hC : ∀ i, IdentDistrib (fun n : ℕ => (n : ℝ)) (C i)
      (poissonMeasure (b * p i)) μ) :
    MemLp (poissonAtomAverage b C z) 2 μ := by
  have hi (i) : MemLp (fun ω => z i * C i ω) 2 μ :=
    ((hC i).memLp_snd (poisson_nat_memLp _)).const_mul _
  have hs := memLp_finset_sum (s := Finset.univ) (fun i _ => hi i)
  exact hs.const_mul _

/-- The finite-atom compound-Poisson mean, derived from the Poisson laws. -/
theorem poissonAtomAverage_mean {L : ℕ} (b : ℝ≥0) (hb : 0 < (b : ℝ))
    (p : Fin L → ℝ≥0) (C : Fin L → Ω → ℝ) (z : Fin L → ℝ)
    (hC : ∀ i, IdentDistrib (fun n : ℕ => (n : ℝ)) (C i)
      (poissonMeasure (b * p i)) μ) :
    (∫ ω, poissonAtomAverage b C z ω ∂μ) = ∑ i, (p i : ℝ) * z i := by
  have hint (i) : Integrable (fun ω => z i * C i ω) μ :=
    (((hC i).memLp_snd (poisson_nat_memLp _)).integrable one_le_two).const_mul _
  have hmean (i) : (∫ ω, C i ω ∂μ) = (b : ℝ) * (p i : ℝ) := by
    rw [← (hC i).integral_eq, poisson_nat_mean]
    rfl
  unfold poissonAtomAverage
  rw [integral_const_mul, integral_finset_sum Finset.univ (fun i _ => hint i)]
  simp_rw [integral_const_mul, hmean]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  field_simp

omit [IsProbabilityMeasure μ] in
/-- The finite-atom compound-Poisson variance, with no assumed aggregate moments. -/
theorem poissonAtomAverage_variance {L : ℕ} (b : ℝ≥0) (hb : 0 < (b : ℝ))
    (p : Fin L → ℝ≥0) (C : Fin L → Ω → ℝ) (z : Fin L → ℝ)
    (hC : ∀ i, IdentDistrib (fun n : ℕ => (n : ℝ)) (C i)
      (poissonMeasure (b * p i)) μ)
    (hpair : Pairwise (fun i j => IndepFun (C i) (C j) μ)) :
    variance (poissonAtomAverage b C z) μ =
      (∑ i, (p i : ℝ) * z i ^ 2) / (b : ℝ) := by
  let Y : Fin L → Ω → ℝ := fun i ω => z i * C i ω
  have hY (i) : MemLp (Y i) 2 μ :=
    ((hC i).memLp_snd (poisson_nat_memLp _)).const_mul _
  have hYpair : Pairwise (fun i j => IndepFun (Y i) (Y j) μ) :=
    fun _ _ hij => (hpair hij).comp (by fun_prop) (by fun_prop)
  have hvar (i) : variance (Y i) μ = z i ^ 2 * ((b : ℝ) * (p i : ℝ)) := by
    unfold Y
    rw [variance_mul, ← (hC i).variance_eq, poisson_nat_variance]
    rfl
  have hsum : variance (fun ω => ∑ i, Y i ω) μ = ∑ i, variance (Y i) μ := by
    convert (IndepFun.variance_sum (s := Finset.univ) (X := Y)
      (fun i _ => hY i) (fun i _ j _ hij => hYpair hij)) using 1
    congr 1
    funext ω
    simp
  change variance (fun ω => (b : ℝ)⁻¹ * ∑ i, Y i ω) μ = _
  rw [variance_mul, hsum]
  simp_rw [hvar]
  rw [Finset.mul_sum, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i _
  field_simp

/-- Normalization failure for the finite-atomic compound-Poisson construction.

The coordinates count atom multiplicities independently with means b*p_i.
This is a directly specified probability experiment; the separate Poisson
marking identity with a random total number of draws is not assumed here.
-/
theorem atomic_poisson_normalization_probability {L : ℕ}
    (b : ℝ≥0) (hb : 0 < (b : ℝ)) (p : Fin L → ℝ≥0)
    (C : Fin L → Ω → ℝ) (z : Fin L → ℝ) (α A t u : ℝ)
    (hC : ∀ i, IdentDistrib (fun n : ℕ => (n : ℝ)) (C i)
      (poissonMeasure (b * p i)) μ)
    (hpair : Pairwise (fun i j => IndepFun (C i) (C j) μ))
    (hmean : ∑ i, (p i : ℝ) * z i = 1)
    (hpower : ∑ i, (p i : ℝ) * z i ^ α = A)
    (hA : 0 < A) (ht : 0 < t) (hu : 0 < u) :
    μ.real {ω | t < |poissonAtomAverage b C z ω - 1| ∨
      A * u < |poissonAtomAverage b C (fun i => z i ^ α) ω -
        A * poissonAtomAverage b C z ω|} ≤
      (∑ i, (p i : ℝ) * z i ^ 2) / ((b : ℝ) * t ^ 2) +
        (∑ i, (p i : ℝ) * (z i ^ α - A * z i) ^ 2) /
          ((b : ℝ) * A ^ 2 * u ^ 2) := by
  let g : Fin L → ℝ := fun i => z i ^ α - A * z i
  have hgmean : ∑ i, (p i : ℝ) * g i = 0 := by
    simp only [g, mul_sub, Finset.sum_sub_distrib]
    have hfactor : (∑ i, (p i : ℝ) * (A * z i)) = A * ∑ i, (p i : ℝ) * z i := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro i _
      ring
    rw [hfactor, hmean, hpower]
    ring
  have hSmean := (poissonAtomAverage_mean b hb p C z hC).trans hmean
  have hWmean := (poissonAtomAverage_mean b hb p C g hC).trans hgmean
  have h := normalization_event_failure
    (poissonAtomAverage_memLp b p C z hC) (poissonAtomAverage_memLp b p C g hC)
    hSmean hWmean hA ht hu
  have hres (ω : Ω) : poissonAtomAverage b C g ω =
      poissonAtomAverage b C (fun i => z i ^ α) ω - A * poissonAtomAverage b C z ω := by
    simp only [poissonAtomAverage, g, sub_mul, Finset.sum_sub_distrib]
    have hfactor : (∑ i, A * z i * C i ω) = A * ∑ i, z i * C i ω := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro i _
      ring
    rw [hfactor]
    ring
  simp_rw [hres] at h
  rw [poissonAtomAverage_variance b hb p C z hC hpair,
    poissonAtomAverage_variance b hb p C g hC hpair] at h
  convert h using 1
  dsimp only [g]
  ring

/-- The deterministic event needed for a valid normalization and entropy reserve. -/
def normalizationGood (α b m A S V : ℝ) : Prop :=
  0 < S ∧ 0 < V ∧
    |entropyFromPower (α - 1) (b ^ (1 - α) * V / S ^ α) -
      (Real.log b - Real.log A / (α - 1))| < m / (4 * (α - 1))

omit [MeasurableSpace Ω] in
/-- Failure of normalized entropy control requires one of the two deviations. -/
theorem normalization_bad_subset (S V : Ω → ℝ) {α b m A : ℝ}
    (hα : 1 < α) (hb : 0 < b) (hm : 0 < m) (hm1 : m ≤ 1) (hA : 0 < A) :
    {ω | ¬ normalizationGood α b m A (S ω) (V ω)} ⊆
      {ω | min (1 / 4) (m / (16 * (α - 1))) < |S ω - 1| ∨
        A * (m / 16) < |V ω - A * S ω|} := by
  intro ω hbad
  by_contra h
  have hs : |S ω - 1| ≤ min (1 / 4) (m / (16 * (α - 1))) := by
    by_contra hs
    exact h (Or.inl (lt_of_not_ge hs))
  have hw : |V ω - A * S ω| ≤ A * (m / 16) := by
    by_contra hw
    exact h (Or.inr (lt_of_not_ge hw))
  have hSlow : 3 / 4 ≤ S ω := by
    have := (abs_le.mp hs).1
    have hmin : min (1 / 4) (m / (16 * (α - 1))) ≤ 1 / 4 := min_le_left _ _
    linarith
  have hSpos : 0 < S ω := by linarith
  have hVpos : 0 < V ω := by
    have hwlo := (abs_le.mp hw).1
    have hAS := mul_le_mul_of_nonneg_left hSlow hA.le
    have hAm := mul_le_mul_of_nonneg_left hm1 hA.le
    nlinarith
  exact hbad ⟨hSpos, hVpos,
    normalization_entropy_error hα hb hm hm1 hA hSpos hVpos hs hw⟩

/-- The fixed-size i.i.d. normalization lemma, including entropy control. -/
theorem iid_normalization_entropy_failure {N : ℕ} (hN : 0 < N)
    (U : Ω' → ℝ) (X : Fin N → Ω → ℝ) (α A m : ℝ)
    (hα : 1 < α) (hm : 0 < m) (hm1 : m ≤ 1)
    (hU : MemLp U 2 ν) (hUα : MemLp (fun ω => U ω ^ α) 2 ν)
    (hmean : ∫ ω, U ω ∂ν = 1) (hpower : ∫ ω, U ω ^ α ∂ν = A)
    (hident : ∀ i, IdentDistrib U (X i) ν μ)
    (hpair : Pairwise (fun i j => IndepFun (X i) (X j) μ)) (hA : 0 < A) :
    μ.real {ω | ¬ normalizationGood α N m A
      (sampleAverage X ω) (sampleAverage (fun i ω => X i ω ^ α) ω)} ≤
      variance U ν / ((N : ℝ) * (min (1 / 4) (m / (16 * (α - 1)))) ^ 2) +
        (∫ ω, (U ω ^ α - A * U ω) ^ 2 ∂ν) / ((N : ℝ) * A ^ 2 * (m / 16) ^ 2) := by
  have hβ : 0 < α - 1 := sub_pos.mpr hα
  have hb : 0 < (N : ℝ) := by exact_mod_cast hN
  have ht : 0 < min (1 / 4) (m / (16 * (α - 1))) := by positivity
  have hu : 0 < m / 16 := by positivity
  exact (measureReal_mono (μ := μ)
    (normalization_bad_subset (sampleAverage X)
      (sampleAverage (fun i ω => X i ω ^ α)) hα hb hm hm1 hA)).trans
    (iid_normalization_probability hN U X α A _ _ hU hUα hmean hpower hident hpair hA ht hu)

/-- The entropy failure bound for a finite-atomic Poissonized prior. -/
theorem atomic_poisson_normalization_entropy_failure {L : ℕ}
    (b : ℝ≥0) (hb : 0 < (b : ℝ)) (p : Fin L → ℝ≥0)
    (C : Fin L → Ω → ℝ) (z : Fin L → ℝ) (α A m : ℝ)
    (hα : 1 < α) (hm : 0 < m) (hm1 : m ≤ 1)
    (hC : ∀ i, IdentDistrib (fun n : ℕ => (n : ℝ)) (C i)
      (poissonMeasure (b * p i)) μ)
    (hpair : Pairwise (fun i j => IndepFun (C i) (C j) μ))
    (hmean : ∑ i, (p i : ℝ) * z i = 1)
    (hpower : ∑ i, (p i : ℝ) * z i ^ α = A) (hA : 0 < A) :
    μ.real {ω | ¬ normalizationGood α b m A
      (poissonAtomAverage b C z ω) (poissonAtomAverage b C (fun i => z i ^ α) ω)} ≤
      (∑ i, (p i : ℝ) * z i ^ 2) /
        ((b : ℝ) * (min (1 / 4) (m / (16 * (α - 1)))) ^ 2) +
        (∑ i, (p i : ℝ) * (z i ^ α - A * z i) ^ 2) /
          ((b : ℝ) * A ^ 2 * (m / 16) ^ 2) := by
  have hβ : 0 < α - 1 := sub_pos.mpr hα
  have ht : 0 < min (1 / 4) (m / (16 * (α - 1))) := by positivity
  have hu : 0 < m / 16 := by positivity
  exact (measureReal_mono (μ := μ)
    (normalization_bad_subset (poissonAtomAverage b C z)
      (poissonAtomAverage b C (fun i => z i ^ α)) hα hb hm hm1 hA)).trans
    (atomic_poisson_normalization_probability b hb p C z α A _ _ hC hpair hmean hpower hA ht hu)

end Renyi
