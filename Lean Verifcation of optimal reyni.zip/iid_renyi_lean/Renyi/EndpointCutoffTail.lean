import Renyi.EndpointIntegral

/-! A uniform actual cutoff tail in the scaled unit neighborhood. -/
noncomputable section
open MeasureTheory Set
namespace Renyi

def endpointCutoffTailConstant : ℝ := (1/2:ℝ)^14/Real.exp 1

theorem endpointCutoffTailConstant_pos : 0<endpointCutoffTailConstant := by
  unfold endpointCutoffTailConstant
  positivity

/-- The primitive used as cutoff leaves a fixed positive tail on the central forward interval. -/
theorem endpointProfile_one_cutoff_tail {N : ℕ} (hN : 2≤N) {x : ℝ}
    (_hx : 0≤x) (_hx1 : x≤1) (hy : (N:ℝ)^2*x≤1) :
    endpointCutoffTailConstant≤1-endpointProfile N 6 1 x := by
  have hN0 : 0<N := by omega
  have hNr : (2:ℝ)≤N := by exact_mod_cast hN
  have hN2 : 0<(N:ℝ)^2 := by positivity
  let a := (1:ℝ)/(N:ℝ)^2
  let b := (5/4:ℝ)/(N:ℝ)^2
  have ha : 0<a := by dsimp [a];positivity
  have hab : a≤b := by dsimp [a,b];exact div_le_div_of_nonneg_right (by norm_num) hN2.le
  have hb1 : b≤1 := by
    apply (div_le_one hN2).mpr
    nlinarith only [hNr]
  have hxa : x≤a := (le_div_iff₀ hN2).mpr (by dsimp [a] at *;nlinarith only [hy])
  have hKlower : ∀ t∈Icc a b, (1/2:ℝ)^12≤endpointKernel N 6 t := by
    intro t ht
    have ht0 : 0<t := ha.trans_le ht.1
    have ht1 : t≤1 := ht.2.trans hb1
    have htscale : (N:ℝ)^2*t≤5/4 := by simpa only [mul_comm] using (le_div_iff₀ hN2).mp ht.2
    have hq := endpoint_chebyshev_half_lower hN ht0 ht1 htscale
    exact pow_le_pow_left₀ (by norm_num : (0:ℝ)≤1/2) hq 12
  have hint (u v : ℝ) : IntervalIntegrable (endpointKernel N 6) volume u v := by
    simpa only [sub_self,Real.rpow_zero,one_mul] using
      endpointKernel_weight_integrable N 6 (by norm_num : (0:ℝ)<1) u v
  have hpatch := intervalIntegral.integral_mono_on hab
    (intervalIntegral.intervalIntegrable_const) (hint a b) hKlower
  rw [intervalIntegral.integral_const] at hpatch
  have hinterval := intervalIntegral.integral_mono_interval hxa hab hb1
    (Filter.Eventually.of_forall (fun t => endpointKernel_nonneg N 6 t)) (hint x 1)
  have htail : (1/2:ℝ)^14/(N:ℝ)^2≤endpointTailIntegral N 6 1 x := by
    have hid : (b-a)*(1/2:ℝ)^12=(1/2:ℝ)^14/(N:ℝ)^2 := by
      dsimp [a,b]
      ring
    simpa only [endpointTailIntegral,sub_self,Real.rpow_zero,one_mul,smul_eq_mul, hid] using hpatch.trans hinterval
  have hnorm := endpointIntegral_normalized_upper hN0 (by norm_num : 2≤6)
    (by norm_num : (0:ℝ)<1) (by norm_num : (1:ℝ)≤1)
  norm_num only [mul_one,Real.rpow_ofNat] at hnorm
  have hI := endpointIntegral_pos hN0 (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1)
  rw [endpointProfile_complement hN0 (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1)]
  apply (le_div_iff₀ hI).mpr
  have hm := mul_le_mul_of_nonneg_left hnorm (show 0≤(1/2:ℝ)^14/Real.exp 1 by positivity)
  have hscale : endpointCutoffTailConstant*endpointIntegral N 6 1≤(1/2:ℝ)^14/(N:ℝ)^2 := by
    apply (le_div_iff₀ hN2).mpr
    unfold endpointCutoffTailConstant
    have hid : ((1/2:ℝ)^14/Real.exp 1)*Real.exp 1=(1/2:ℝ)^14 := by field_simp
    rw [hid] at hm
    nlinarith only [hm]
  exact hscale.trans htail

end Renyi
