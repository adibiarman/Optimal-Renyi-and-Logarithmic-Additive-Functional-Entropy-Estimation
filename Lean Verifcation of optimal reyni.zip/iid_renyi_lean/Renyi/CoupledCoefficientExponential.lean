import Renyi.CoupledCoefficients

/-! A fixed exponential coefficient budget for the actual coupled polynomial. -/
set_option maxHeartbeats 700000
noncomputable section
namespace Renyi

def coupledCoefficientExponentialConstant : ℝ := 2716 + 18 * Real.log 9

theorem coupledCoefficientExponentialConstant_pos : 0 < coupledCoefficientExponentialConstant := by
  have hlog : 0 ≤ Real.log 9 := Real.log_nonneg (by norm_num)
  unfold coupledCoefficientExponentialConstant
  positivity

private theorem nine_pow_le_exp {j : ℕ} {L : ℝ} (hj : (j : ℝ) ≤ L) :
    (9 : ℝ) ^ j ≤ Real.exp (Real.log 9 * L) := by
  rw [← Real.rpow_natCast, Real.rpow_def_of_pos (by norm_num : (0 : ℝ) < 9)]
  exact Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left hj (Real.log_nonneg (by norm_num)))

/-- Every scale in the actual coefficient budget is absorbed by one fixed
exponential in the degree parameter, uniformly in both fractional exponents. -/
theorem coupledCoefficientBudget_exponential {ell N : ℕ} {gamma a b A B omega L : ℝ}
    (hgamma : 0 ≤ gamma) (ha : 0 ≤ a) (hab : a ≤ b) (hb : 0 < b)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hB : 0 ≤ B) (hB1 : B ≤ 1)
    (hw : 0 ≤ omega) (hw1 : omega ≤ 1)
    (hL : 1 ≤ L) (hell : (ell : ℝ) ≤ L) (hN : (N : ℝ) ≤ L) :
    coupledCoefficientBudget ell N gamma a b A B omega ≤
      Real.exp (coupledCoefficientExponentialConstant * L) := by
  have hL0 : 0 ≤ L := by linarith
  have hsell : ((ell - 1 : ℕ) : ℝ) ≤ ell := by exact_mod_cast Nat.sub_le ell 1
  have hsN : ((N - 1 : ℕ) : ℝ) ≤ N := by exact_mod_cast Nat.sub_le N 1
  let E := Real.exp (Real.log 9 * (18 * L))
  have hP : (9 : ℝ) ^ (4 * (ell - 1)) ≤ E := by
    apply nine_pow_le_exp
    push_cast
    nlinarith only [hsell, hell, hL0]
  have hQ : (9 : ℝ) ^ (6 * (N - 1)) ≤ E := by
    apply nine_pow_le_exp
    push_cast
    nlinarith only [hsN, hN, hL0]
  have hS : (9 : ℝ) ^ (18 * (N - 1)) ≤ E := by
    apply nine_pow_le_exp
    push_cast
    nlinarith only [hsN, hN]
  have hPQ : (9 : ℝ) ^ (4 * (ell - 1)) * (9 : ℝ) ^ (6 * (N - 1)) ≤ E := by
    rw [← pow_add]
    apply nine_pow_le_exp
    push_cast
    nlinarith only [hsell, hsN, hell, hN, hL0]
  have hell2 := pow_le_pow_left₀ (Nat.cast_nonneg ell : (0 : ℝ) ≤ ell) hell 2
  have hN2 := pow_le_pow_left₀ (Nat.cast_nonneg N : (0 : ℝ) ≤ N) hN 2
  have hL24 : L ^ (2 : ℕ) ≤ L ^ (4 : ℕ) := by
    have hh := one_le_pow₀ (n := 2) hL
    nlinarith only [sq_nonneg (L ^ (2 : ℕ)), mul_le_mul_of_nonneg_left hh (sq_nonneg L)]
  have hell4 := hell2.trans hL24
  have hN4 := hN2.trans hL24
  have hellN : (ell : ℝ) ^ 2 * (N : ℝ) ^ 2 ≤ L ^ (4 : ℕ) := by
    have hh := mul_le_mul hell2 hN2 (sq_nonneg (N : ℝ)) (sq_nonneg L)
    nlinarith only [hh]
  have ht1 := mul_le_mul hell4 hP (by positivity : 0 ≤ (9 : ℝ) ^ (4 * (ell - 1))) (by positivity : 0 ≤ L ^ (4 : ℕ))
  have ht2 := mul_le_mul hellN hPQ (by positivity : 0 ≤ (9 : ℝ) ^ (4 * (ell - 1)) * (9 : ℝ) ^ (6 * (N - 1)))
    (by positivity : 0 ≤ L ^ (4 : ℕ))
  have ht3 := mul_le_mul hN4 hS (by positivity : 0 ≤ (9 : ℝ) ^ (18 * (N - 1))) (by positivity : 0 ≤ L ^ (4 : ℕ))
  have ht4 := mul_le_mul hN4 hQ (by positivity : 0 ≤ (9 : ℝ) ^ (6 * (N - 1))) (by positivity : 0 ≤ L ^ (4 : ℕ))
  have hRatio := Real.rpow_le_one (div_nonneg ha hb.le) ((div_le_one hb).2 hab) hgamma
  have hweight : A * (a / b) ^ gamma ≤ 1 := (mul_le_of_le_one_right hA hRatio).trans hA1
  have hrest : omega * (1 - B) ≤ 1 :=
    (mul_le_of_le_one_right hw (by linarith : 1 - B ≤ 1)).trans hw1
  have hlow := mul_le_mul_of_nonneg_right hweight
    (by positivity : 0 ≤ (96 * (ell : ℝ) ^ 2 * (9 : ℝ) ^ (4 * (ell - 1))) *
      (1 + 24 * (N : ℝ) ^ 2 * (9 : ℝ) ^ (6 * (N - 1))))
  have hhigh := mul_le_mul_of_nonneg_right hB1
    (by positivity : 0 ≤ 288 * (N : ℝ) ^ 2 * (9 : ℝ) ^ (18 * (N - 1)))
  have hend := mul_le_mul_of_nonneg_right hrest
    (by positivity : 0 ≤ 24 * (N : ℝ) ^ 2 * (9 : ℝ) ^ (6 * (N - 1)))
  have hbudget : coupledCoefficientBudget ell N gamma a b A B omega ≤ 2712 * L ^ (4 : ℕ) * E := by
    dsimp [coupledCoefficientBudget]
    simp only [Nat.mul_comm (N - 1) 6]
    nlinarith only [hlow, hhigh, hend, ht1, ht2, ht3, ht4]
  have hconst : (2712 : ℝ) ≤ Real.exp (2712 * L) := by
    have hh := Real.add_one_le_exp (2712 * L)
    nlinarith only [hh, hL]
  have hpoly : L ^ (4 : ℕ) ≤ Real.exp (4 * L) := by
    have he : L ≤ Real.exp L := by linarith [Real.add_one_le_exp L]
    have hp := pow_le_pow_left₀ hL0 he 4
    simpa only [← Real.exp_nat_mul] using hp
  have hfinal := mul_le_mul_of_nonneg_right
    (mul_le_mul hconst hpoly (by positivity : 0 ≤ L ^ (4 : ℕ)) (Real.exp_pos _).le) (Real.exp_pos (Real.log 9 * (18 * L))).le
  apply hbudget.trans
  dsimp [E] at *
  have hexp : Real.exp (2712 * L) * Real.exp (4 * L) * Real.exp (Real.log 9 * (18 * L)) =
      Real.exp (coupledCoefficientExponentialConstant * L) := by
    rw [← Real.exp_add, ← Real.exp_add]
    congr 1
    unfold coupledCoefficientExponentialConstant
    ring
  rw [hexp] at hfinal
  exact hfinal

end Renyi
