import Renyi.LowerCalibrationFinal
import Renyi.NearOne
import Renyi.OneDefect
import Mathlib.Analysis.Complex.ExponentialBounds

/-! Actual root envelopes and exact-matching count budgets near order one. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- The common interpolation degree is at least half the logarithm of the
alphabet size, uniformly all the way down to order one. -/
theorem lower_near_one_log_alphabet {k : ℕ} {α ε : ℝ}
    (hk : 0<k) (hα : 1<α) (hα1 : α≤3/2) (hε : 0<ε) (hε1 : ε≤1/2) :
    Real.log k≤2*(Nat.ceil (10*α*(1+Real.log (rootMultiplier k α ε))) : ℝ) := by
  let x := rootMultiplier k α ε
  let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
  have hk0 : 0<(k:ℝ) := by exact_mod_cast hk
  have hα0 : 0<α := by linarith
  have hγ : fractionalPart α=α-1 := (near_one_order hα hα1).2
  have hg : 0<fractionalPart α := by rw [hγ]; linarith
  have hg1 : fractionalPart α<1 := by rw [hγ]; linarith
  have hx1 : 1≤x := one_le_rootMultiplier hα hg hg1
  have hx0 : 0<x := by linarith
  have hlx : 0≤Real.log x := Real.log_nonneg hx1
  have hlog0 : 0<1+Real.log x := by linarith
  have hq := (near_one_Q_bounds hk hα hα1 hε).1.trans (upper_root_Q_bound hα hg hg1)
  have hl := Real.log_le_log (mul_pos (nearOneQConstant_pos ε) (Real.rpow_pos_of_pos hk0 _)) hq
  change Real.log (nearOneQConstant ε*(k:ℝ)^(1/α))≤Real.log (Real.exp 1*x*(1+Real.log x)) at hl
  rw [Real.log_mul (nearOneQConstant_pos ε).ne' (Real.rpow_pos_of_pos hk0 _).ne',
    Real.log_rpow hk0, Real.log_mul (mul_pos (Real.exp_pos _) hx0).ne' hlog0.ne',
    Real.log_mul (Real.exp_pos _).ne' hx0.ne', Real.log_exp] at hl
  have hcq : Real.log (nearOneQConstant ε)=-5-4*ε-Real.log 4 := by
    unfold nearOneQConstant
    rw [Real.log_div (Real.exp_pos _).ne' (by norm_num), Real.log_exp]
  rw [hcq] at hl
  have hl4 : Real.log 4≤3 := by linarith [Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<4)]
  have hll : Real.log (1+Real.log x)≤Real.log x := by
    linarith [Real.log_le_sub_one_of_pos hlog0]
  have hquot : Real.log k/α≤11+2*Real.log x := by
    rw [div_eq_mul_inv]
    simp only [one_div] at hl
    nlinarith
  have hmul := (div_le_iff₀ hα0).mp hquot
  have hL : 10*α*(1+Real.log x)≤L := Nat.le_ceil _
  change Real.log k≤2*L
  nlinarith [mul_nonneg hα0.le hlx]

/-- Exact moment matching at the actual small support-intensity product
implies the required count-distance budget without any denominator premise. -/
theorem exact_matching_small_count_budget {ι₀ ι₁ : Type*} [Fintype ι₀] [Fintype ι₁]
    (p₀ : FiniteAtomicPrior ι₀) (p₁ : FiniteAtomicPrior ι₁)
    {k L : ℕ} {θ B : ℝ}
    (hk : 0<k) (hθ : 0<θ) (hB : 0<B)
    (hv₀ : ∀ i, 0≤p₀.value i) (hv₁ : ∀ i, 0≤p₁.value i)
    (hb₀ : ∀ i, p₀.value i≤B) (hb₁ : ∀ i, p₁.value i≤B)
    (hscale : θ*B≤(L:ℝ)/100) (hkL : Real.log k≤2*(L:ℝ))
    (hmatch : ∀ j : ℕ, 1≤j → j≤L+1 → priorMoment p₁ (j:ℝ)=priorMoment p₀ (j:ℝ)) :
    (k:ℝ)*countDistance (poissonMixture p₀.mass p₀.value θ)
      (poissonMixture p₁.mass p₁.value θ)≤1/64 := by
  have hm : ∀ j : ℕ, j<L+2 → atomicMoment p₁.mass p₁.value j=atomicMoment p₀.mass p₀.value j := by
    intro j hj
    by_cases hj0 : j=0
    · subst j
      simp [atomicMoment, p₀.mass_sum, p₁.mass_sum]
    · simpa only [priorMoment, atomicMoment, Real.rpow_natCast] using hmatch j (by omega) (by omega)
  have hd := exact_matching_calibration_finite p₀.mass p₀.value p₁.mass p₁.value θ 0 B (L+2)
    p₀.mass_nonneg hv₀ p₁.mass_nonneg hv₁ hb₀ hb₁ hθ (by norm_num) (by positivity)
    hB (by omega) hm
  have hzero (p : FiniteAtomicPrior ι₀) : atomicPowerMoment p.mass p.value 0=1 := by
    simp [atomicPowerMoment, p.mass_sum]
  have hzero1 : atomicPowerMoment p₁.mass p₁.value 0=1 := by
    simp [atomicPowerMoment, p₁.mass_sum]
  rw [hzero p₀, hzero1] at hd
  norm_num only [neg_zero, Real.rpow_zero, mul_one] at hd
  have he3 : Real.exp 1≤3 := le_of_lt (Real.exp_one_lt_d9.trans (by norm_num))
  have hbase : 2*Real.exp 1*θ*B/((L+2:ℕ):ℝ)≤1/16 := by
    apply (div_le_iff₀ (by positivity : (0:ℝ)<((L+2:ℕ):ℝ))).mpr
    have hh := mul_le_mul_of_nonneg_left hscale (show 0≤2*Real.exp 1 by positivity)
    have hh' := mul_le_mul_of_nonneg_right he3 (show 0≤(L:ℝ) by positivity)
    push_cast
    nlinarith
  have hp : (2*Real.exp 1*θ*B/((L+2:ℕ):ℝ))^(L+2)≤(1/16:ℝ)^(L+2) :=
    pow_le_pow_left₀ (by positivity) hbase _
  have hk9 : (k:ℝ)≤(9:ℝ)^L := by
    have hk0 : 0<(k:ℝ) := by exact_mod_cast hk
    calc
      (k:ℝ)=Real.exp (Real.log k) := (Real.exp_log hk0).symm
      _≤Real.exp (2*(L:ℝ)) := Real.exp_le_exp.mpr hkL
      _=(Real.exp 1*Real.exp 1)^L := by
        rw [←Real.exp_add, ←Real.exp_nat_mul]
        congr 1
        ring
      _≤(9:ℝ)^L := pow_le_pow_left₀ (by positivity) (by nlinarith [Real.exp_pos 1]) _
  have hgeom : (9:ℝ)^L*(1/16:ℝ)^L≤1 := by
    rw [←mul_pow]
    exact pow_le_one₀ (by norm_num) (by norm_num)
  have hh := mul_le_mul_of_nonneg_left hd (show 0≤(k:ℝ) by positivity)
  have hh' := mul_le_mul hk9 hp (by positivity) (by positivity : (0:ℝ)≤9^L)
  have hpow : (1/16:ℝ)^(L+2)=(1/16:ℝ)^L/256 := by rw [pow_add]; norm_num; ring
  rw [hpow] at hh'
  nlinarith only [hh, hh', hgeom]



/-- In the near-one branch above the root cutoff, the root never exceeds
the alphabet size. -/
theorem lower_near_one_root_le_alphabet {k : ℕ} {α ε : ℝ}
    (hk : 0<k) (hα : 1<α) (hα1 : α≤3/2) (hε : 0<ε)
    (hx4 : 4≤rootMultiplier k α ε) : rootMultiplier k α ε≤k := by
  let x := rootMultiplier k α ε
  let s := α-1
  let v := s/α*x^(-α)
  have hk0 : 0<(k:ℝ) := by exact_mod_cast hk
  have hk1 : (1:ℝ)≤k := by exact_mod_cast hk
  have hα0 : 0<α := by linarith
  have hs : 0<s := sub_pos.mpr hα
  have hs1 : s≤1/2 := by dsimp [s]; linarith
  have hx1 : 1<x := by dsimp [x]; linarith
  have hx0 : 0<x := by linarith
  have hγ : fractionalPart α=s := (near_one_order hα hα1).2
  have hg : 0<fractionalPart α := by rwa [hγ]
  have hg1 : fractionalPart α<1 := by rw [hγ]; linarith
  have hvsmall : v≤s/4 := by
    have hp : x^(-α)≤1/x := by
      simpa only [Real.rpow_neg_one, one_div] using
        Real.rpow_le_rpow_of_exponent_le hx1.le (neg_le_neg hα.le)
    have hf : s/α≤s := div_le_self hs.le hα.le
    have hxinv : 1/x≤1/4 := one_div_le_one_div_of_le (by norm_num) hx4
    calc
      v≤s*(1/x) := mul_le_mul hf hp (Real.rpow_nonneg hx0.le _) hs.le
      _≤s*(1/4) := mul_le_mul_of_nonneg_left hxinv hs.le
      _=s/4 := by ring
  have hh : 0<s*(1-s) := mul_pos hs (by linarith)
  have hvh : v/(s*(1-s))≤1 := (div_le_one hh).mpr (by nlinarith)
  have hroot := regularized_root_slack (k:=k) (ε:=ε) hα hg hg1
  dsimp only at hroot
  rw [hroot.2.1 hx1, sub_zero, hγ] at hroot
  have he : 1≤Real.exp (1-v/(s*(1-s))) := Real.one_le_exp (by linarith)
  have ht : 1≤1+Real.log x := by linarith [Real.log_nonneg hx1.le]
  have hq : x≤rootQSquared k α ε := by
    have hprod := one_le_mul_of_one_le_of_one_le ht he
    have hid := hroot.2.2
    change rootQSquared k α ε/x=(1+Real.log x)*Real.exp (1-v/(s*(1-s))) at hid
    rw [←hid] at hprod
    simpa only [one_mul] using (le_div_iff₀ hx0).mp hprod
  have hkpow : (k:ℝ)^(1/α)≤k := by
    have he : 1/α≤1 := (div_le_one hα0).mpr hα.le
    simpa only [Real.rpow_one] using Real.rpow_le_rpow_of_exponent_le hk1 he
  exact hq.trans ((near_one_Q_bounds hk hα hα1 hε).2.trans hkpow)

/-- A fixed positive constant controls the actual near-one Poisson
intensity from below by the reciprocal logarithm of the alphabet size. -/
theorem lower_near_one_intensity_lower {k : ℕ} {α ε : ℝ}
    (hk : 0<k) (hα : 1<α) (hα1 : α≤3/2) (hε : 0<ε)
    (hx4 : 4≤rootMultiplier k α ε) :
    (lowerPriorIntensityConstant ε*nearOneQConstant ε/Real.exp 1)/(1+Real.log k)≤
      lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*rootMultiplier k α ε := by
  let x := rootMultiplier k α ε
  let cn := lowerPriorIntensityConstant ε
  let cq := nearOneQConstant ε
  let t := 1+Real.log k
  let kp := (k:ℝ)^(1/α)
  have hk0 : 0<(k:ℝ) := by exact_mod_cast hk
  have hk1 : (1:ℝ)≤k := by exact_mod_cast hk
  have hα0 : 0<α := by linarith
  have hx0 : 0<x := by dsimp [x]; linarith
  have hcn : 0<cn := Real.exp_pos _
  have hcq : 0<cq := nearOneQConstant_pos ε
  have hkp : 0<kp := Real.rpow_pos_of_pos hk0 _
  have ht : 0<t := by dsimp [t]; linarith [Real.log_nonneg hk1]
  have hγ : fractionalPart α=α-1 := (near_one_order hα hα1).2
  have hg : 0<fractionalPart α := by rw [hγ]; linarith
  have hg1 : fractionalPart α<1 := by rw [hγ]; linarith
  have hxk := lower_near_one_root_le_alphabet hk hα hα1 hε hx4
  have hlog := Real.log_le_log hx0 hxk
  have hq := (near_one_Q_bounds hk hα hα1 hε).1.trans (upper_root_Q_bound hα hg hg1)
  have hq' : cq*kp≤Real.exp 1*x*t := by
    apply hq.trans
    exact mul_le_mul_of_nonneg_left (add_le_add_left hlog 1) (by positivity)
  have hratio : cq/(Real.exp 1*t)≤x/kp :=
    (div_le_div_iff₀ (by positivity) hkp).mpr (by nlinarith only [hq'])
  have hpower : (k:ℝ)^(-1/α)=kp⁻¹ := by
    rw [show (-1:ℝ)/α=-(1/α) by rw [neg_div], Real.rpow_neg hk0.le]
  change cn*cq/Real.exp 1/t≤cn*α*(k:ℝ)^(-1/α)*x
  rw [hpower]
  calc
    cn*cq/Real.exp 1/t=cn*(cq/(Real.exp 1*t)) := by
      rw [div_div]
      ring
    _≤cn*(x/kp) := mul_le_mul_of_nonneg_left hratio hcn.le
    _≤cn*α*kp⁻¹*x := by
      have hh := mul_le_mul_of_nonneg_left hα.le (show 0≤cn*(x/kp) by positivity)
      ring_nf at hh ⊢
      linarith only [hh]

/-- The actual support bound is a fixed constant times `(1+log k)^2`
throughout the near-one branch. -/
theorem lower_near_one_support_upper {k : ℕ} {α ε : ℝ}
    (hk : 0<k) (hα : 1<α) (hα1 : α≤3/2) (hε : 0<ε)
    (hx4 : 4≤rootMultiplier k α ε) :
    let x := rootMultiplier k α ε
    let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
    let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
    let ct := lowerPriorIntensityConstant ε*nearOneQConstant ε/Real.exp 1
    (L/100)/θ≤(1/ct)*(1+Real.log k)^2 := by
  let x := rootMultiplier k α ε
  let L : ℝ := Nat.ceil (10*α*(1+Real.log x))
  let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
  let ct := lowerPriorIntensityConstant ε*nearOneQConstant ε/Real.exp 1
  let t := 1+Real.log k
  change (L/100)/θ≤(1/ct)*t^2
  have hk0 : 0<(k:ℝ) := by exact_mod_cast hk
  have hk1 : (1:ℝ)≤k := by exact_mod_cast hk
  have hα0 : 0<α := by linarith
  have hx0 : 0<x := by dsimp [x]; linarith
  have hx1 : 1≤x := by dsimp [x]; linarith
  have hθ : 0<θ := by dsimp [θ, lowerPriorIntensityConstant]; positivity
  have hct : 0<ct := by
    dsimp [ct, lowerPriorIntensityConstant]
    exact div_pos (mul_pos (Real.exp_pos _) (nearOneQConstant_pos ε)) (Real.exp_pos _)
  have ht1 : 1≤t := by dsimp [t]; linarith [Real.log_nonneg hk1]
  have ht : 0<t := by linarith
  have hlog := Real.log_le_log hx0 (lower_near_one_root_le_alphabet hk hα hα1 hε hx4)
  have hL : L≤17*t := by
    have hh := (Nat.ceil_lt_add_one (show 0≤10*α*(1+Real.log x) by
      have hh := Real.log_nonneg hx1
      positivity)).le
    change L≤10*α*(1+Real.log x)+1 at hh
    have hh' := mul_le_mul_of_nonneg_right hα1 (show 0≤1+Real.log x by linarith [Real.log_nonneg hx1])
    dsimp [t] at *
    nlinarith
  have hθlo : ct/t≤θ := lower_near_one_intensity_lower hk hα hα1 hε hx4
  have hθt := (div_le_iff₀ ht).mp hθlo
  apply (div_le_iff₀ hθ).mpr
  have hh : t≤(1/ct)*t^2*θ := by
    have hm : t*ct≤t^2*θ := by
      have hm := mul_le_mul_of_nonneg_left hθt ht.le
      nlinarith only [hm]
    have hd := (le_div_iff₀ hct).mpr hm
    convert hd using 1
    ring
  linarith



/-- Actual entropy-separated near-one priors whose Poisson mixture counts
already satisfy the numerical testing budget. -/
theorem lower_actual_near_one_count_priors {k : ℕ} {s ε : ℝ}
    (hk : 0<k) (hs : 0<s) (hs1 : s≤1/2) (hε : 0<ε) (hε1 : ε≤1/2)
    (hx : lowerPriorRootCutoff ε≤rootMultiplier k (1+s) ε) :
    let α := 1+s
    let x := rootMultiplier k α ε
    let L := Nat.ceil (10*α*(1+Real.log x))
    let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
    let B := ((L:ℝ)/100)/θ
    let w := s*(1-s)+s/α*x^(-α)
    ∃ p₀ p₁ : FiniteAtomicPrior (Option ((Option (Fin 1)) × (Option (Fin ((L-1)+1))))),
      (∀ i, p₀.value i=0 ∨ (1≤p₀.value i ∧ p₀.value i≤B)) ∧
      (∀ i, p₁.value i=0 ∨ (1≤p₁.value i ∧ p₁.value i≤B)) ∧
      priorMoment p₀ 1=1 ∧ priorMoment p₁ 1=1 ∧
      2*ε*(α-1)+w≤Real.log (priorMoment p₁ α/priorMoment p₀ α) ∧
      (k:ℝ)*countDistance (poissonMixture p₀.mass p₀.value θ)
        (poissonMixture p₁.mass p₁.value θ)≤1/64 := by
  let α := 1+s
  let x := rootMultiplier k α ε
  let L := Nat.ceil (10*α*(1+Real.log x))
  let θ := lowerPriorIntensityConstant ε*α*(k:ℝ)^(-1/α)*x
  let B := ((L:ℝ)/100)/θ
  let E := 2*ε*s
  let v := s/α*x^(-α)
  let w := s*(1-s)+v
  let ζ := lowerPriorCoefficient ε*w/(1-Real.exp (-E))
  let κ := Real.exp (-E-4*w)
  let ac := Real.exp (-5)*((1-s)/(L:ℝ)^2)*(ζ*κ)^(1/(1-s))
  let a := θ/((1/100)*(L:ℝ)*ac)
  have hα : 1<α := by dsimp [α]; linarith
  have hα1 : α≤3/2 := by dsimp [α]; linarith
  have hα0 : 0<α := by linarith
  have hx4 : 4≤x := (le_max_left _ _).trans hx
  have hx0 : 0<x := by linarith
  have hx1 : 1<x := by linarith
  have hL : (0:ℝ)<L := (show 0<10*α*(1+Real.log x) by
    have hh := Real.log_pos hx1
    positivity).trans_le (Nat.le_ceil _)
  have hθ : 0<θ := by
    dsimp [θ, lowerPriorIntensityConstant]
    exact mul_pos (mul_pos (mul_pos (Real.exp_pos _) hα0)
      (Real.rpow_pos_of_pos (by exact_mod_cast hk) _)) hx0
  have hB : 0<B := by dsimp [B]; positivity
  have hcon := lower_actual_zero_degree_constraints hk hs hs1 hε hε1 hx
  change 0<a ∧ a≤(ζ/8)/2 ∧ a^s≤κ ∧ 0<ζ ∧ ζ≤1/8 at hcon
  have hζ : 0<ζ := hcon.2.2.2.1
  have hξ : 0<1-s := by linarith
  have hac : 0<ac := by dsimp [ac, κ]; positivity
  have hBeq : (a*ac)⁻¹=B := by
    dsimp [a, B]
    field_simp
  obtain ⟨p₀,p₁,hp₀,hp₁,hm₀,hm₁,hmatch,hgap⟩ :=
    lower_actual_near_one_priors hk hs hs1 hε hε1 hx
  change ∀ i, p₀.value i=0 ∨ (1≤p₀.value i ∧ p₀.value i≤(a*ac)⁻¹) at hp₀
  change ∀ i, p₁.value i=0 ∨ (1≤p₁.value i ∧ p₁.value i≤(a*ac)⁻¹) at hp₁
  rw [hBeq] at hp₀ hp₁
  have hv₀ : ∀ i, 0≤p₀.value i := fun i => (hp₀ i).elim (fun h => h ▸ le_rfl) (fun h => le_trans zero_le_one h.1)
  have hv₁ : ∀ i, 0≤p₁.value i := fun i => (hp₁ i).elim (fun h => h ▸ le_rfl) (fun h => le_trans zero_le_one h.1)
  have hb₀ : ∀ i, p₀.value i≤B := fun i => (hp₀ i).elim (fun h => h ▸ hB.le) (fun h => h.2)
  have hb₁ : ∀ i, p₁.value i≤B := fun i => (hp₁ i).elim (fun h => h ▸ hB.le) (fun h => h.2)
  have hscale : θ*B≤(L:ℝ)/100 := by
    dsimp [B]
    rw [mul_div_cancel₀ _ hθ.ne']
  have hd := exact_matching_small_count_budget p₀ p₁ hk hθ hB hv₀ hv₁ hb₀ hb₁ hscale
    (lower_near_one_log_alphabet hk hα hα1 hε hε1) hmatch
  exact ⟨p₀,p₁,hp₀,hp₁,hm₀,hm₁,hgap,hd⟩

end Renyi
