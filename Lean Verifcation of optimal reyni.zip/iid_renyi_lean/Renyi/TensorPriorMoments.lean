import Renyi.TensorPriors

/-! Exact individual moment and designated-atom identities for the actual tensor priors. -/
noncomputable section
open scoped BigOperators
namespace Renyi

theorem tensor_priors_with_atoms {ι κ : Type*} [Fintype ι] [Fintype κ]
    (l : ι → ℝ) (r : κ → ℝ) (u : ι → ℝ) (w : κ → ℝ) {a b α Rl Rr : ℝ}
    (hα : 1 < α) (ha : 0 < a) (hb : 0 < b)
    (hua : ∀ i, a ≤ u i) (hu1 : ∀ i, u i ≤ 1)
    (hwb : ∀ j, b ≤ w j) (hw1 : ∀ j, w j ≤ 1)
    (hl : ∑ i, positiveCoeff (l i) = 1) (hr : ∑ j, positiveCoeff (r j) = 1)
    (hnl : ∑ i, negativeCoeff (l i) = Rl) (hnr : ∑ j, negativeCoeff (r j) = Rr)
    (hR : 0 < Rl + Rr)
    (hmean : (∑ i, l i * u i ^ (α - 1)) * (∑ j, r j * w j ^ (1 - α)) = 0) :
    let B := (a * b)⁻¹
    let Z := tensorNormalizer l r u w a α
    0 < Z ∧ ∃ p₀ p₁ : FiniteAtomicPrior (Option (ι × κ)),
      (∀ i, p₀.value i = 0 ∨ (1 ≤ p₀.value i ∧ p₀.value i ≤ B)) ∧
      (∀ i, p₁.value i = 0 ∨ (1 ≤ p₁.value i ∧ p₁.value i ≤ B)) ∧
      priorMoment p₀ 1 = 1 ∧ priorMoment p₁ 1 = 1 ∧
      (∀ j : ℝ, 0 < j →
        priorMoment p₁ j - priorMoment p₀ j =
          B ^ (j - 1) / Z *
            ((∑ i, l i * (u i / a) ^ (α - j)) * (∑ t, r t * w t ^ (j - α)))) ∧
      priorMoment p₁ α = B ^ (α - 1) / Z * (1 + Rl * Rr) ∧
      priorMoment p₀ α = B ^ (α - 1) / Z * (Rl + Rr) ∧
      Real.log (priorMoment p₁ α / priorMoment p₀ α) =
        Real.log ((1 + Rl * Rr) / (Rl + Rr)) ∧
      (∀ j : ℝ, 0 < j → priorMoment p₀ j = B^(j-1)/Z *
        (∑ ij, tensorNegative l r ij * tensorAtom u w a ij^(j-α))) ∧
      (∀ j : ℝ, 0 < j → priorMoment p₁ j = B^(j-1)/Z *
        (∑ ij, tensorPositive l r ij * tensorAtom u w a ij^(j-α))) ∧
      (∀ ij, p₀.mass (some ij) = reweightedMass (tensorNegative l r) (tensorAtom u w a) B Z α ij) ∧
      (∀ ij, p₁.mass (some ij) = reweightedMass (tensorPositive l r) (tensorAtom u w a) B Z α ij) ∧
      (∀ ij, p₀.value (some ij) = B*tensorAtom u w a ij) ∧
      (∀ ij, p₁.value (some ij) = B*tensorAtom u w a ij) ∧
      p₀.value none = 0 ∧ p₁.value none = 0 := by
  let B := (a * b)⁻¹
  let Z := tensorNormalizer l r u w a α
  let z := tensorAtom u w a
  have hB : 0 < B := inv_pos.mpr (mul_pos ha hb)
  have hu : ∀ i, 0 < u i := fun i => ha.trans_le (hua i)
  have hw : ∀ j, 0 < w j := fun j => hb.trans_le (hwb j)
  have hs := tensorAtom_support u w ha hb hua hu1 hwb hw1
  have hz : ∀ ij, 0 < z ij := fun ij => (hs ij).1
  have hz1 : ∀ ij, z ij ≤ 1 := fun ij => (hs ij).2.1
  have hv : ∀ ij, 1 ≤ B * z ij := fun ij => (hs ij).2.2
  have hZ : 0 < Z := tensorNormalizer_pos l r u w ha hu hw hl hr hnl hnr hR
  have hZ0 : Z = ∑ ij, tensorNegative l r ij * z ij ^ (1 - α) := rfl
  have hZ1 : Z = ∑ ij, tensorPositive l r ij * z ij ^ (1 - α) :=
    (tensor_common_normalizer l r u w ha hu hw hmean).symm
  let p₀ := reweightedPrior (tensorNegative l r) z B Z α
    (tensorNegative_nonneg l r) hB hZ hz hv hZ0
  let p₁ := reweightedPrior (tensorPositive l r) z B Z α
    (tensorPositive_nonneg l r) hB hZ hz hv hZ1
  have hm0 (j : ℝ) (hj : 0 < j) : priorMoment p₀ j =
      B ^ (j - 1) / Z * (∑ ij, tensorNegative l r ij * z ij ^ (j - α)) :=
    reweightedPrior_power_moment _ _ _ _ _ _ _ _ _ _ _ hj
  have hm1 (j : ℝ) (hj : 0 < j) : priorMoment p₁ j =
      B ^ (j - 1) / Z * (∑ ij, tensorPositive l r ij * z ij ^ (j - α)) :=
    reweightedPrior_power_moment _ _ _ _ _ _ _ _ _ _ _ hj
  have hαpos : 0 < α := by linarith
  have hA0 : priorMoment p₀ α = B ^ (α - 1) / Z * (Rl + Rr) := by
    rw [hm0 α hαpos]
    simp only [sub_self, Real.rpow_zero, mul_one]
    rw [tensorNegative_mass l r hl hr hnl hnr]
  have hA1 : priorMoment p₁ α = B ^ (α - 1) / Z * (1 + Rl * Rr) := by
    rw [hm1 α hαpos]
    simp only [sub_self, Real.rpow_zero, mul_one]
    rw [tensorPositive_mass l r hl hr hnl hnr]
  refine ⟨hZ, p₀, p₁,
    reweightedPrior_support _ _ _ _ _ _ _ _ _ _ _ hz1,
    reweightedPrior_support _ _ _ _ _ _ _ _ _ _ _ hz1,
    reweightedPrior_mean _ _ _ _ _ _ _ _ _ _ _,
    reweightedPrior_mean _ _ _ _ _ _ _ _ _ _ _, ?_, hA1, hA0, ?_, hm0, hm1,
    ?_, ?_, ?_, ?_, rfl, rfl⟩
  · intro j hj
    rw [hm1 j hj, hm0 j hj, ← mul_sub]
    have hdiff := tensor_power_difference l r u w ha hu hw (j - α)
    have he : -(j - α) = α - j := by ring
    rw [he] at hdiff
    rw [hdiff]
  · rw [hA1, hA0, parity_ratio hB (ne_of_gt hZ) (ne_of_gt hR)]

  · intro ij; rfl
  · intro ij; rfl
  · intro ij; rfl
  · intro ij; rfl

end Renyi
