import Renyi.HighOrderConcentration
import Renyi.HighOrderNorm

/-!
# The high-order and min-entropy iid upper bounds

The estimator uses the actual empirical Poisson histogram, followed by a proved
conversion to a fixed iid sample. Raw empirical counts already suffice; the
optional Gamma smoothing in the manuscript is unnecessary for this upper bound.
-/

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def poissonEmpiricalVector {k : ℕ} (b : ℝ≥0) (x : PoissonMarkedSample (Fin k)) : Fin k → ℝ :=
  fun i => (markHistogram x.2 i : ℝ) / b

def highOrderPoissonOutput {k : ℕ} (α : ℝ) (b : ℝ≥0)
    (x : PoissonMarkedSample (Fin k)) : ℝ :=
  empiricalNormEntropy α (poissonEmpiricalVector b x)

def minEntropyPoissonOutput {k : ℕ} (b : ℝ≥0)
    (x : PoissonMarkedSample (Fin k)) : ℝ :=
  empiricalMaxEntropy (poissonEmpiricalVector b x)

/-- This is exactly the logarithmic empirical power-sum statistic. -/
theorem highOrderPoissonOutput_eq_power {k : ℕ} {α : ℝ} (hα : 0 < α)
    (b : ℝ≥0) (x : PoissonMarkedSample (Fin k)) :
    highOrderPoissonOutput α b x = entropyFromPower (α - 1)
      (∑ i, ((markHistogram x.2 i : ℝ) / b) ^ α) :=
  empiricalNormEntropy_eq_power hα _ (fun _ => by unfold poissonEmpiricalVector; positivity)

theorem highOrder_poisson_error {k : ℕ} (hk : 0 < k) (b : ℝ≥0) (hb : 0 < (b : ℝ))
    (p : Simplex k) {α ε η : ℝ} (hα : 2 ≤ α) (hη : 0 < η)
    (hη8 : η ≤ 1 / 8) (hε : 8 * η ≤ ε) :
    (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure.real
      {x | ε < |highOrderPoissonOutput α b x - entropy p α|} ≤
      2 * (k : ℝ) * Real.exp (-(η ^ 2 * ((b : ℝ) / k) / 2)) := by
  have hsub : {x | ε < |highOrderPoissonOutput α b x - entropy p α|} ⊆
      {x | ∃ i : Fin k, η * (p.mass i + 1 / (k : ℝ)) <
        |(markHistogram x.2 i : ℝ) / b - p.mass i|} := by
    intro x hx
    by_contra hn
    have hclose (i : Fin k) : |poissonEmpiricalVector b x i - p.mass i| ≤
        η * (p.mass i + 1 / (k : ℝ)) := by
      apply le_of_not_gt
      intro hi
      exact hn ⟨i, hi⟩
    have h := empirical_norm_entropy_error hk p hα hη.le hη8 _ hclose
    exact (not_lt_of_ge (h.trans hε)) hx
  exact (measureReal_mono hsub).trans (poisson_histogram_relative_tail hk b hb p hη (by linarith))

theorem minEntropy_poisson_error {k : ℕ} (hk : 0 < k) (b : ℝ≥0) (hb : 0 < (b : ℝ))
    (p : Simplex k) {ε η : ℝ} (hη : 0 < η) (hη8 : η ≤ 1 / 8) (hε : 8 * η ≤ ε) :
    (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure.real
      {x | ε < |minEntropyPoissonOutput b x - minEntropy p|} ≤
      2 * (k : ℝ) * Real.exp (-(η ^ 2 * ((b : ℝ) / k) / 2)) := by
  have hsub : {x | ε < |minEntropyPoissonOutput b x - minEntropy p|} ⊆
      {x | ∃ i : Fin k, η * (p.mass i + 1 / (k : ℝ)) <
        |(markHistogram x.2 i : ℝ) / b - p.mass i|} := by
    intro x hx
    by_contra hn
    have hclose (i : Fin k) : |poissonEmpiricalVector b x i - p.mass i| ≤
        η * (p.mass i + 1 / (k : ℝ)) := by
      apply le_of_not_gt
      intro hi
      exact hn ⟨i, hi⟩
    have h := empirical_max_entropy_error hk p hη.le hη8 _ hclose
    exact (not_lt_of_ge (h.trans hε)) hx
  exact (measureReal_mono hsub).trans (poisson_histogram_relative_tail hk b hb p hη (by linarith))

def highOrderTolerance (ε : ℝ) : ℝ := min (1 / 8) (ε / 8)
def highOrderCoefficient (ε : ℝ) : ℝ := 12 + 2 / highOrderTolerance ε ^ 2
def highOrderExposure (k : ℕ) (ε : ℝ) : ℝ :=
  highOrderCoefficient ε * k * (Real.log k + 4)
def highOrderSampleSize (k : ℕ) (ε : ℝ) : ℕ := ⌈2 * highOrderExposure k ε⌉₊
def highOrderRateConstant (ε : ℝ) : ℝ := 27 * highOrderCoefficient ε

theorem highOrderTolerance_bounds {ε : ℝ} (hε : 0 < ε) :
    0 < highOrderTolerance ε ∧ highOrderTolerance ε ≤ 1 / 8 ∧ 8 * highOrderTolerance ε ≤ ε := by
  unfold highOrderTolerance
  exact ⟨lt_min (by norm_num) (by positivity), min_le_left _ _,
    by have h := min_le_right (1 / 8 : ℝ) (ε / 8); linarith⟩

theorem highOrderCoefficient_ge (ε : ℝ) : 12 ≤ highOrderCoefficient ε := by
  unfold highOrderCoefficient
  have h : 0 ≤ 2 / highOrderTolerance ε ^ 2 := by positivity
  linarith

theorem highOrderExposure_ge {k : ℕ} (hk : 1 ≤ k) (ε : ℝ) : 12 ≤ highOrderExposure k ε := by
  have hkR : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hl : 0 ≤ Real.log k := Real.log_nonneg hkR
  have hc := highOrderCoefficient_ge ε
  unfold highOrderExposure
  nlinarith [mul_nonneg (by linarith : 0 ≤ highOrderCoefficient ε) (by linarith : 0 ≤ (k : ℝ) - 1),
    mul_nonneg (by positivity : 0 ≤ highOrderCoefficient ε * (k : ℝ)) (by linarith : 0 ≤ Real.log k + 3)]

private theorem exp_neg_four_le : Real.exp (-4 : ℝ) ≤ 1 / 12 := by
  have h := Real.quadratic_le_exp_of_nonneg (by norm_num : (0 : ℝ) ≤ 4)
  rw [Real.exp_neg, inv_le_iff_one_le_mul₀ (Real.exp_pos 4)]
  norm_num at h ⊢
  linarith

/-- The entire histogram failure event has probability at most one sixth. -/
theorem highOrder_histogram_budget {k : ℕ} (hk : 1 ≤ k) {ε : ℝ} (hε : 0 < ε) :
    2 * (k : ℝ) * Real.exp (-(highOrderTolerance ε ^ 2 * (highOrderExposure k ε / k) / 2)) ≤
      1 / 6 := by
  have hkR : 0 < (k : ℝ) := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hk)
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hη := (highOrderTolerance_bounds hε).1
  have hl : 0 ≤ Real.log k + 4 := by have h := Real.log_nonneg hk1; linarith
  have hid : highOrderTolerance ε ^ 2 * (highOrderExposure k ε / k) / 2 =
      (6 * highOrderTolerance ε ^ 2 + 1) * (Real.log k + 4) := by
    unfold highOrderExposure highOrderCoefficient
    field_simp
    ring
  have hlow : Real.log k + 4 ≤ highOrderTolerance ε ^ 2 * (highOrderExposure k ε / k) / 2 := by
    rw [hid]
    nlinarith [mul_nonneg (sq_nonneg (highOrderTolerance ε)) hl]
  have he := mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (neg_le_neg hlow))
    (by positivity : 0 ≤ 2 * (k : ℝ))
  have heq : 2 * (k : ℝ) * Real.exp (-(Real.log k + 4)) = 2 * Real.exp (-4) := by
    rw [neg_add, Real.exp_add, Real.exp_neg, Real.exp_log hkR]
    field_simp
  rw [heq] at he
  exact he.trans (by linarith [exp_neg_four_le])

theorem highOrder_overflow_budget {k : ℕ} (hk : 1 ≤ k) (ε : ℝ) :
    (1 / 6 : ℝ) + Real.exp (-highOrderExposure k ε / 3) ≤ 1 / 3 := by
  have h := Real.exp_le_exp.mpr (show -highOrderExposure k ε / 3 ≤ -4 by
    linarith [highOrderExposure_ge hk ε])
  linarith [h.trans exp_neg_four_le]

/-- A concrete fixed iid sample size achieves the claimed finite-order accuracy. -/
theorem high_order_achievable {k : ℕ} (hk : 1 ≤ k) {ε α : ℝ}
    (hε : 0 < ε) (hα : 2 ≤ α) : Achievable k (highOrderSampleSize k ε) α ε := by
  have hB : 0 < highOrderExposure k ε := by linarith [highOrderExposure_ge hk ε]
  let b : ℝ≥0 := ⟨highOrderExposure k ε, hB.le⟩
  have hη := highOrderTolerance_bounds hε
  apply achievable_of_poissonized_error_ceil_twice b α ε (1 / 6) (highOrderPoissonOutput α b)
  · intro p
    exact (highOrder_poisson_error (lt_of_lt_of_le Nat.zero_lt_one hk) b hB p hα hη.1 hη.2.1 hη.2.2).trans
      (highOrder_histogram_budget hk hε)
  · exact highOrder_overflow_budget hk ε

/-- The same fixed iid sample size achieves min-entropy accuracy directly. -/
theorem min_entropy_achievable {k : ℕ} (hk : 1 ≤ k) {ε : ℝ}
    (hε : 0 < ε) : MinEntropyAchievable k (highOrderSampleSize k ε) ε := by
  have hB : 0 < highOrderExposure k ε := by linarith [highOrderExposure_ge hk ε]
  let b : ℝ≥0 := ⟨highOrderExposure k ε, hB.le⟩
  have hη := highOrderTolerance_bounds hε
  apply minEntropyAchievable_of_poissonized_error_ceil_twice b ε (1 / 6) (minEntropyPoissonOutput b)
  · intro p
    exact (minEntropy_poisson_error (lt_of_lt_of_le Nat.zero_lt_one hk) b hB p hη.1 hη.2.1 hη.2.2).trans
      (highOrder_histogram_budget hk hε)
  · exact highOrder_overflow_budget hk ε

/-- The concrete fixed budget is at most a constant times `k log k`. -/
theorem highOrderSampleSize_le {k : ℕ} (hk : 2 ≤ k) (ε : ℝ) :
    (highOrderSampleSize k ε : ℝ) ≤ highOrderRateConstant ε * ((k : ℝ) * Real.log k) := by
  have hk1 : 1 ≤ k := by omega
  have hkR : (2 : ℝ) ≤ k := by exact_mod_cast hk
  have hlog2 : (1 / 2 : ℝ) ≤ Real.log 2 := by
    have h := Real.le_log_one_add_of_nonneg (by norm_num : (0 : ℝ) ≤ 1)
    norm_num at h
    linarith
  have hlog : (1 / 2 : ℝ) ≤ Real.log k := hlog2.trans (Real.log_le_log (by norm_num) hkR)
  have hB := highOrderExposure_ge hk1 ε
  let b : ℝ≥0 := ⟨highOrderExposure k ε, by linarith⟩
  have hceil := poisson_fixed_sample_size_le b (by change 1 ≤ highOrderExposure k ε; linarith)
  have hcoef : 0 ≤ highOrderCoefficient ε := by linarith [highOrderCoefficient_ge ε]
  have hscale := mul_le_mul_of_nonneg_left (show Real.log k + 4 ≤ 9 * Real.log k by linarith)
    (mul_nonneg hcoef (Nat.cast_nonneg k))
  change (highOrderSampleSize k ε : ℝ) ≤ 3 * highOrderExposure k ε at hceil
  unfold highOrderExposure at hceil
  unfold highOrderRateConstant
  nlinarith

/-- The source endpoint upper rate, with a single accuracy-dependent constant
uniform over all finite orders at least two and also min-entropy. -/
theorem high_order_and_min_entropy_upper {ε : ℝ} (hε : 0 < ε) :
    ∃ C : ℝ, 0 < C ∧ ∀ k : ℕ, 2 ≤ k →
      ∃ n : ℕ, (n : ℝ) ≤ C * ((k : ℝ) * Real.log k) ∧
        (∀ α : ℝ, 2 ≤ α → Achievable k n α ε) ∧ MinEntropyAchievable k n ε := by
  refine ⟨highOrderRateConstant ε, ?_, ?_⟩
  · unfold highOrderRateConstant
    have h := highOrderCoefficient_ge ε
    positivity
  · intro k hk
    refine ⟨highOrderSampleSize k ε, highOrderSampleSize_le hk ε, ?_, ?_⟩
    · intro α hα
      exact high_order_achievable (by omega) hε hα
    · exact min_entropy_achievable (by omega) hε

end Renyi
