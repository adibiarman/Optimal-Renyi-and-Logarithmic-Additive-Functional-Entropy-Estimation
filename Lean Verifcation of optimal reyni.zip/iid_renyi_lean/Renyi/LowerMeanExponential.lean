import Renyi.TensorPriorMeanShapes

/-! Exponential envelopes of the actual prior power means. -/
noncomputable section
namespace Renyi

/-- The polynomial short-degree mean bound is absorbed by the same explicit
exponential constant used for the count remainder. -/
theorem lower_mean_exponential_envelope {r c E w : ℝ}
    (hr : 2≤r) (hc : 0<c) (hE : E≤r) (hw : w≤1/2) :
    8192*Real.exp 5*r^4/(c*Real.exp (-E-4*w))≤Real.exp ((20+2/c)*r) := by
  have hr0 : 0<r := by linarith
  have hF : 0<8192*Real.exp 5*r^4/(c*Real.exp (-E-4*w)) := by positivity
  apply (Real.log_le_iff_le_exp hF).mp
  rw [Real.log_div (by positivity) (by positivity),
    Real.log_mul (by positivity : (8192:ℝ)*Real.exp 5≠0) (by positivity : r^4≠0),
    Real.log_mul (by norm_num : (8192:ℝ)≠0) (Real.exp_ne_zero _),
    Real.log_mul hc.ne' (Real.exp_ne_zero _),Real.log_exp,Real.log_exp,Real.log_pow]
  norm_num only [Nat.cast_ofNat]
  have hlog8192 : Real.log (8192:ℝ)≤13 := by
    have hid : (8192:ℝ)=(2:ℝ)^13 := by norm_num
    rw [hid,Real.log_pow]
    norm_num only [Nat.cast_ofNat]
    have hh := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)
    nlinarith
  have hlogr : Real.log r≤r := by linarith [Real.log_le_sub_one_of_pos hr0]
  have hlogc : -Real.log c≤1/c := by
    have hh := Real.one_sub_inv_le_log_of_pos hc
    rw [←one_div] at hh
    linarith
  have hcInv : 0<1/c := one_div_pos.mpr hc
  have hpay : 1/c≤(2/c)*r := by
    have hh := mul_le_mul_of_nonneg_right (show (1:ℝ)≤2*r by linarith) hcInv.le
    simpa only [one_mul,div_eq_mul_inv,mul_comm,mul_left_comm,mul_assoc] using hh
  calc
    _ ≤ 20+5*r+1/c := by linarith
    _ ≤ 20*r+(2/c)*r := add_le_add (by linarith) hpay
    _ = _ := by ring

/-- The complementary mean envelope is dominated by the same active bound. -/
theorem lower_complementary_mean_exponential_envelope {r c E w : ℝ}
    (hr : 2≤r) (hc : 0<c) (hc1 : c≤1) (hE : E≤r) (hw : w≤1/2) :
    128*Real.exp 5*r^4/Real.exp (-E-4*w)≤Real.exp ((20+2/c)*r) := by
  apply le_trans ?_ (lower_mean_exponential_envelope hr hc hE hw)
  apply (div_le_div_iff₀ (Real.exp_pos _) (mul_pos hc (Real.exp_pos _))).mpr
  have hbase : 0≤Real.exp 5*r^4*Real.exp (-E-4*w) := by positivity
  have hh := mul_le_mul_of_nonneg_right hc1 hbase
  nlinarith only [hh,hbase]

end Renyi
