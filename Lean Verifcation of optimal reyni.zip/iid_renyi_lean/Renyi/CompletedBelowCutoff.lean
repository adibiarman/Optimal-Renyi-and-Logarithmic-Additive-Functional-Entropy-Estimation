import Renyi.DegreeOnePolynomialCoefficients

/-! Actual below-cutoff bound for both low-arm completions. -/
noncomputable section
open Polynomial
namespace Renyi

theorem degreeOneCoupledPolynomial_eval_forward {N m : ℕ} (hN : 0 < N) (hm : 1≤m)
    {γ a b p c f A B ω : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hc : 0<c) (ha : 0≤a) (hb : 0 < b) (hp : 0 ≤ p) (hpb : p ≤ b) :
    (degreeOneCoupledPolynomial N m γ (c*a*(1+γ)/γ) b f ω A B).eval p =
      A*a^γ*(reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a).eval p *
        (1-endpointProfile N 6 1 (p/b)) +
      p^((m:ℝ)+γ)*(B*highProfile N (1-γ) f ω (p/b) +
        ω*(1-B)*endpointProfile N 6 (1-γ) (p/b)) := by
  rw [degreeOneCoupledPolynomial_reverse hm hγ hc ha]
  rcases hp.eq_or_lt with rfl | hp
  · have hα : (m:ℝ)+γ ≠ 0 := by positivity
    simp [Real.zero_rpow hα]
  have hf0 : 0 ≤ p/b := div_nonneg hp.le hb.le
  have hf1 : p/b ≤ 1 := (div_le_one hb).mpr hpb
  have hδ : 0 < 1-γ := by linarith
  have hfpow := forward_fractional_identity m γ hb hp
  simp only [eval_add, eval_mul, eval_C, eval_X, eval_sub,
    eval_one, eval_pow, eval_comp]
  have hscale : b⁻¹*p=p/b := by ring
  rw [hscale, highProfile_polynomial hN hδ hf0 hf1,
    endpointProfile_polynomial hN 6 hδ hf0 hf1,
    endpointProfile_polynomial hN 6 (by norm_num : (0:ℝ)<1) hf0 hf1, Real.rpow_one]
  calc
    _ = A*a^γ*(reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a).eval p *
          (1-p/b*(endpointProfilePolynomial N 6 1).eval (p/b)) +
        (p^(m+1)/b^(1-γ))*(B*(highProfilePolynomial N (1-γ) f ω).eval (p/b) +
          ω*(1-B)*(endpointProfilePolynomial N 6 (1-γ)).eval (p/b)) := by ring
    _ = _ := by rw [←hfpow]; ring

/-- Actual below-cutoff contribution, prior to the exponential simplification of the constant. -/
theorem degreeOneCoupledPolynomial_below_cutoff {N m : ℕ} (hN : 0 < N) (hm : 1≤m) {γ a b p c f A B ω : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 < a) (hab : a ≤ b)
    (hp : 0 ≤ p) (hpa : p ≤ a) (hc : c∈Set.Ioo (γ/(1+γ)) 1)
    (hf : 0 ≤ f) (hf1 : f ≤ 1) (hA : 0 ≤ A) (hA1 : A ≤ 1)
    (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1) :
    |(degreeOneCoupledPolynomial N m γ (c*a*(1+γ)/γ) b f ω A B).eval p| + p^((m:ℝ)+γ) ≤
      (8+2)*a^((m:ℝ)+γ) := by
  have hb := ha.trans_le hab
  have hpb := hpa.trans hab
  have hx := div_nonneg hp hb.le
  have hx1 := (div_le_one hb).mpr hpb
  have hδ : 0 < 1-γ := by linarith
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hx hx1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hδ hx hx1
  have hv := highProfile_range hN hδ hf hf1 hω hω1 hx hx1
  have hbr0 : 0 ≤ B*highProfile N (1-γ) f ω (p/b) + ω*(1-B)*endpointProfile N 6 (1-γ) (p/b) := by
    exact add_nonneg (mul_nonneg hB hv.1) (mul_nonneg (mul_nonneg hω (sub_nonneg.mpr hB1)) hJ.1)
  have hbr1 : B*highProfile N (1-γ) f ω (p/b) + ω*(1-B)*endpointProfile N 6 (1-γ) (p/b) ≤ 1 := by
    have hvb := mul_le_of_le_one_right hB hv.2
    have hjb := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hB1)) hJ.2
    have hw := mul_le_of_le_one_left (sub_nonneg.mpr hB1) hω1.le
    linarith
  have hα : 0 < (m:ℝ)+γ := by positivity
  have hpα := Real.rpow_le_rpow hp hpa hα.le
  have haid : a^γ*a^m=a^((m:ℝ)+γ) := by rw [mul_comm, ←Real.rpow_natCast, ←Real.rpow_add ha]
  have hrev := reverseScaledPolynomial_abs_eval (degreeOneLowPolynomial γ c)
    ((degreeOneLowPolynomial_natDegree γ c).trans hm) hp hpa
  have hmass := degreeOneLowPolynomial_coefficientMass hγ hγ1.le hc
  have hrev' : |(reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a).eval p| ≤
      (8)*a^m :=
    hrev.trans (mul_le_mul_of_nonneg_right hmass (pow_nonneg ha.le m))
  have hlow : |A*a^γ*(reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a).eval p *
      (1-endpointProfile N 6 1 (p/b))| ≤
      (8)*a^((m:ℝ)+γ) := by
    rw [abs_mul, abs_mul, abs_mul, abs_of_nonneg hA, abs_of_nonneg (Real.rpow_nonneg ha.le γ),
      abs_of_nonneg (sub_nonneg.mpr hH.2)]
    have hscale := mul_le_mul_of_nonneg_left hrev' (show 0 ≤ A*a^γ by positivity)
    have hc := mul_le_of_le_one_right
      (show 0 ≤ A*a^γ*|(reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a).eval p| by positivity)
      (show 1-endpointProfile N 6 1 (p/b) ≤ 1 by linarith [hH.1])
    have hcoef : A*a^γ*((8)*a^m) ≤
        (8)*a^((m:ℝ)+γ) := by
      have haA := mul_le_of_le_one_left
        (show 0 ≤ (8)*a^((m:ℝ)+γ) by positivity) hA1
      calc
        _ = A*((8)*a^((m:ℝ)+γ)) := by rw [←haid]; ring
        _ ≤ _ := haA
    exact hc.trans (hscale.trans hcoef)
  rw [degreeOneCoupledPolynomial_eval_forward hN hm hγ hγ1 ((div_pos hγ (by positivity)).trans hc.1) ha.le hb hp hpb]
  have hhigh : |p^((m:ℝ)+γ)*(B*highProfile N (1-γ) f ω (p/b) +
      ω*(1-B)*endpointProfile N 6 (1-γ) (p/b))| ≤ a^((m:ℝ)+γ) := by
    rw [abs_of_nonneg (mul_nonneg (Real.rpow_nonneg hp _) hbr0)]
    exact (mul_le_of_le_one_right (Real.rpow_nonneg hp _) hbr1).trans hpα
  have ht := abs_add_le
    (A*a^γ*(reverseScaledPolynomial (degreeOneLowPolynomial γ c) m a).eval p *
      (1-endpointProfile N 6 1 (p/b)))
    (p^((m:ℝ)+γ)*(B*highProfile N (1-γ) f ω (p/b) + ω*(1-B)*endpointProfile N 6 (1-γ) (p/b)))
  nlinarith

/-- Source below-cutoff bound for the completed polynomial, uniformly over both branches. -/
theorem completedCoupledPolynomial_below_cutoff_exponential {ℓ N m : ℕ}
    (hℓ : 0<ℓ) (hN : 0<N) (hm : 1≤m) (hdegree : 4*(ℓ-1)≤m)
    {γ a b p c fL f A B ω : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (ha : 0<a) (hab : a≤b)
    (hp : 0≤p) (hpa : p≤a) (hc : c∈Set.Ioo (γ/(1+γ)) 1)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hA : 0≤A) (hA1 : A≤1) (hB : 0≤B) (hB1 : B≤1) (hω : 0≤ω) (hω1 : ω<1) :
    |(completedCoupledPolynomial ℓ N m γ a b c fL f A B ω).eval p|+p^((m:ℝ)+γ)≤
      (100:ℝ)^(m+1)*a^((m:ℝ)+γ) := by
  unfold completedCoupledPolynomial
  split
  · have hh := degreeOneCoupledPolynomial_below_cutoff hN hm hγ hγ1 ha hab hp hpa hc
      hf hf1 hA hA1 hB hB1 hω hω1
    have hconst : (8:ℝ)+2≤100^(m+1) := (by norm_num : (8:ℝ)+2≤100).trans
      (le_self_pow₀ (by norm_num : (1:ℝ)≤100) (by omega : m+1≠0))
    exact hh.trans (mul_le_mul_of_nonneg_right hconst (Real.rpow_nonneg ha.le _))
  · exact coupledQPolynomial_below_cutoff_exponential hℓ hN hdegree hγ hγ1 ha hab hp hpa hfL hfL1
      hf hf1 hA hA1 hB hB1 hω hω1

end Renyi
