import Renyi.CompletedPilotReserveMean
import Renyi.ActualCountCoupledBridge
import Renyi.UpperRescaling

/-! Actual source calibration of the pilot boundary expectation. -/
set_option maxHeartbeats 1500000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def actualPilotTotalBoundary {k : ℕ} {Ω : Type*} (p : Simplex k) (Y Counts : Fin k → Ω → ℕ)
    (alpha eps Ch D cb lambda CL cL fL f M cu u0 cp Bpilot : ℝ) : Ω → ℝ :=
  pilotTotalBoundary p.mass
    (fun i => upperRescaling k alpha eps cu u0 *
      (actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M).eval (p.mass i))
    Y Counts (upperSample k alpha eps D) (upperB k alpha eps D cb CL cL) alpha cp Bpilot
    (upperRescaling k alpha eps cu u0 * Real.exp (-upperE0 k alpha eps Ch / 8))

/-- The pilot multiplier is chosen before the logarithmic degree and baseline.
The final count multiplier then controls the boundary in every actual experiment. -/
theorem actual_pilot_reserve_mean_uniform_experiments
    {eps Ch cb lambda CL Bpilot fL f M cu u0 eta : ℝ}
    (heps : 0 < eps) (hCh : 0 ≤ Ch) (hcb : 0 < cb) (hlambda : 0 < lambda) (hlambda4 : lambda ≤ 4)
    (hCL : 1 ≤ CL) (hBp : 16 ≤ Bpilot) (hscale : 2 * Bpilot ≤ cb * CL)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hM : 0 ≤ M) (hcu : 0 ≤ cu) (hu0 : 0 < u0) (heta : 0 < eta) :
    ∃ cp0 : ℝ, 1 ≤ cp0 ∧ 80 / cb ≤ cp0 ∧ ∀ cp : ℝ, cp0 ≤ cp →
      ∀ cL C0 db : ℝ, 0 < cL → 100 ≤ C0 → 0 < db →
      ∃ D0 : ℝ, 1 ≤ D0 ∧ ∀ (k : ℕ) (alpha D : ℝ), 0 < k → 3 / 2 ≤ alpha →
        0 < fractionalPart alpha → fractionalPart alpha < 1 → D0 ≤ D →
        ∀ {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) (p : Simplex k)
          (Y Counts : Fin k → Ω → ℕ),
        (∀ i, MeasurePreserving (Counts i) μ
          (poissonMeasure (Real.toNNReal (upperSample k alpha eps D * p.mass i)))) →
        (∀ i, IndepFun (Y i) (Counts i) μ) →
        (∀ i, MeasurePreserving (Y i) μ
          (poissonMeasure (Real.toNNReal (cp * upperSample k alpha eps D * p.mass i)))) →
        Integrable (actualPilotTotalBoundary p Y Counts alpha eps Ch D cb lambda CL cL fL f M cu u0 cp Bpilot) μ ∧
          (∫ w, actualPilotTotalBoundary p Y Counts alpha eps Ch D cb lambda CL cL fL f M cu u0 cp Bpilot w ∂μ) ≤
          eta * (upperActualBaseline k alpha C0 db (upperA k alpha eps Ch D cb lambda CL cL) * (k : ℝ) ^ (1 - alpha) +
            upperKappa alpha eps * upperU k alpha eps u0 * powerSum p alpha +
            min (alpha - 1) 1 * upperKappa alpha eps * conditionalCountBonus p.mass alpha (upperSample k alpha eps D)
              (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)) := by
  let eta0 := min eta 1
  have heta0 : 0 < eta0 := lt_min heta zero_lt_one
  have heta01 : eta0 ≤ 1 := min_le_right _ _
  have heta0eta : eta0 ≤ eta := min_le_left _ _
  let cstar := pilotSourceExponent eps eta0
  let cpBase := pilotSourceMultiplier eps eta0 Bpilot cb
  let cp0 := max cpBase (80 / cb)
  have hconstants := pilot_source_constants (eps := eps) (eta := eta0) (B := Bpilot) hcb
  refine ⟨cp0, hconstants.2.2.1.trans (le_max_left _ _), le_max_right _ _, ?_⟩
  intro cp hcp cL C0 db hcL hC0 hdb
  have hcpBase : cpBase ≤ cp := (le_max_left _ _).trans hcp
  have hcp1 : 1 ≤ cp := hconstants.2.2.1.trans hcpBase
  have hcpPos : 0 < cp := zero_lt_one.trans_le hcp1
  have hcpGamma : 2 * Bpilot + cstar + 11 ≤ cp := hconstants.2.2.2.1.trans hcpBase
  have hcpCb : 8 * (coupledCoefficientExponentialConstant + 20 + cstar) ≤ cp * cb :=
    hconstants.2.2.2.2.trans (mul_le_mul_of_nonneg_right hcpBase hcb.le)
  obtain ⟨rminus, rplus, _hrminus, hrplus, hcut⟩ := upper_actual_cutoff heps hCh hcb hlambda hCL hcL
  let D0 := max 1 (400 * rplus / (db * eta0))
  refine ⟨D0, le_max_left _ _, ?_⟩
  intro k alpha D hk halpha hg hg1 hD Ω instΩ μ p Y Counts hCounts hind hY
  have hD1 : 1 ≤ D := (le_max_left _ _).trans hD
  have hDpos : 0 < D := zero_lt_one.trans_le hD1
  have hDbudget : 400 * rplus / (db * eta0) ≤ D := (le_max_right _ _).trans hD
  have ha1 : 1 < alpha := by linarith
  have hsplit : (upperOrderFloor alpha : ℝ) + fractionalPart alpha = alpha := by
    rw [fractionalPart_eq_upperOrderFloor ha1]
    ring
  have hcbCL : 1 ≤ cb * CL := by linarith only [hscale, hBp]
  have hgeometry := upper_actual_count_geometry hk halpha hg hg1 heps hCh hDpos hcb hlambda hlambda4 hCL hcL hcbCL
  rcases hgeometry with ⟨ha, hab, hb, hell, hN2, _hellm, hdegree, hellL, _hlocal, _hnb, _hH, _hcountScale, _hrd, _hdegreeL, _hdegreeH⟩
  have hN : 0 < upperDegree alpha CL cL (rootMultiplier k alpha eps) := by omega
  have hPilotGeometry := upper_pilot_cutoff_geometry (eps := eps) hk halpha hg hg1 hDpos hcb hCL hcL hBp hscale
  rcases hPilotGeometry with ⟨hn, _hb, hL, halphaL, hnb, hcutoff, hLn⟩
  have hprofile := upper_actual_count_profile_ranges (k := k) ha1 hg hg1 heps hCh hM (by norm_num : (0 : ℝ) < 1 / 8) hfL1
  rcases hprofile with ⟨_hcProfile, hA, hA1, hB, hB1, hw, hw1⟩
  have hrescale := upperRescaling_range (k := k) (eps := eps) ha1 hg hg1 hcu hu0
  have hCounts' (i : Fin k) : MeasurePreserving (Counts i) μ
      (poissonMeasure ⟨upperSample k alpha eps D * p.mass i, mul_nonneg hn.le (p.nonneg i)⟩) := by
    convert hCounts i using 1
    congr 1
    apply NNReal.eq
    exact (Real.coe_toNNReal _ (mul_nonneg hn.le (p.nonneg i))).symm
  have hY' (i : Fin k) : MeasurePreserving (Y i) μ
      (poissonMeasure ⟨cp * upperSample k alpha eps D * p.mass i,
        mul_nonneg (mul_nonneg hcpPos.le hn.le) (p.nonneg i)⟩) := by
    convert hY i using 1
    congr 1
    apply NNReal.eq
    exact (Real.coe_toNNReal _ (mul_nonneg (mul_nonneg hcpPos.le hn.le) (p.nonneg i))).symm
  have hka := upper_cutoff_scaled_upper hk ha1 hg hg1 hrplus hDpos (hcut k alpha D hk ha1 hg hg1 hDpos).2
  have hU := upperU_pos (k := k) (eps := eps) ha1 hg hg1 hu0
  have hsource := completed_polynomial_pilot_reserve_mean hell hN (upperOrderFloor_one_le ha1) hdegree
    hg hg1 ha hab hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1 hrescale.1.le hrescale.2 hn
    (by simpa only [hsplit] using halpha) hL hellL (le_refl _) (by simpa only [hsplit] using halphaL)
    hcp1 hBp hconstants.1 hnb (by simpa only [hsplit] using hcutoff) hLn hcpCb hcpGamma
    p.mass p.nonneg Y Counts hCounts' hind hY' heps.le hC0 hdb hDpos hrplus.le heta0 heta01 hU.le
    (by simpa only [Fintype.card_fin] using hka) hDbudget hconstants.2.1
  simp only [hsplit] at hsource
  have homega : upperOmega k alpha eps Ch (1 / 8) = Real.exp (-upperE0 k alpha eps Ch / 8) := by
    unfold upperOmega
    congr 1
    ring
  rw [homega] at hsource
  change Integrable (actualPilotTotalBoundary p Y Counts alpha eps Ch D cb lambda CL cL fL f M cu u0 cp Bpilot) μ ∧ _ at hsource
  refine ⟨hsource.1, ?_⟩
  have hbaseEq := upperActualBaseline_power_identity (alpha := alpha) (C0 := C0) (d := db) hk ha.le
  have hMargin : 0 ≤ upperActualBaseline k alpha C0 db (upperA k alpha eps Ch D cb lambda CL cL) * (k : ℝ) ^ (1 - alpha) +
      upperKappa alpha eps * upperU k alpha eps u0 * powerSum p alpha +
      min (alpha - 1) 1 * upperKappa alpha eps * conditionalCountBonus p.mass alpha (upperSample k alpha eps D)
        (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) := by
    have hC00 : 0 ≤ C0 := by linarith
    have hP : 0 ≤ powerSum p alpha := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (p.nonneg i) _)
    have hchi : 0 ≤ min (alpha - 1) 1 := le_min (by linarith) zero_le_one
    have hbonus := conditionalCountBonus_nonneg p.mass p.nonneg hn.le (by linarith : (0 : ℝ) ≤ upperDegree alpha CL cL (rootMultiplier k alpha eps)) (alpha := alpha)
    have hbase := upperActualBaseline_nonneg (k := k) ha1.le hC00 hdb.le ha.le
    unfold upperKappa
    positivity
  have hbound : (∫ w, actualPilotTotalBoundary p Y Counts alpha eps Ch D cb lambda CL cL fL f M cu u0 cp Bpilot w ∂μ) ≤
      eta0 * (upperActualBaseline k alpha C0 db (upperA k alpha eps Ch D cb lambda CL cL) * (k : ℝ) ^ (1 - alpha) +
        upperKappa alpha eps * upperU k alpha eps u0 * powerSum p alpha +
        min (alpha - 1) 1 * upperKappa alpha eps * conditionalCountBonus p.mass alpha (upperSample k alpha eps D)
          (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)) := by
    rw [hbaseEq]
    exact hsource.2
  exact hbound.trans (mul_le_mul_of_nonneg_right heta0eta hMargin)

end Renyi
