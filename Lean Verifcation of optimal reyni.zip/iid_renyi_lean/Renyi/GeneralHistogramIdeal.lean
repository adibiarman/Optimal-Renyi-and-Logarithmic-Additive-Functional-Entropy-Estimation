import Renyi.CompactOmegaGap
import Renyi.ActualHistogramIdeal
import Renyi.ActualHeavyGoodEvent
import Renyi.ActualNoiseBudget
import Renyi.CompletedPilotCalibration

/-! The actual heavy good event supplies the deterministic interval for the
actual source polynomial and its concrete histogram ideal. -/
noncomputable section
open scoped BigOperators NNReal
namespace Renyi
set_option maxHeartbeats 600000

/-- Every heavy condition used by the deterministic design holds for the
augmented assigned heavy statistic on the same concrete good event. -/
theorem actual_heavy_good_assigned_conditions {k : ℕ} (n cp : ℝ≥0) (p : Simplex k)
    {alpha eps Ch b B W : ℝ}
    (heps : 0<eps) (hCh : 0≤Ch) (ha : 3/2≤alpha)
    (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1) (hW : 0<W)
    {h : PilotHistogram k}
    (hgood : h∈actualHeavyGoodEvent n cp p alpha eps Ch (1/8) B
      (actualHeavyGap eps (1/8)) (compactOmegaGap eps W/4) (2+8*W/eps)) :
    let light := actualPilotLight p n cp b alpha B h
    let heavy := actualPilotAssignedHeavy p n cp b alpha B (Real.exp (-upperE0 k alpha eps Ch/8)) h
    upperKappa alpha eps*(1+actualHeavyGap eps (1/8))*assignedHeavyPower p light alpha≤heavy ∧
      heavy≤(1-actualHeavyGap eps (1/8))*assignedHeavyPower p light alpha ∧
      (2*eps*(alpha-1)/(fractionalPart alpha*(1-fractionalPart alpha))≤W →
        |heavy-Real.exp (-upperE0 k alpha eps Ch/8)*assignedHeavyPower p light alpha|≤
          (compactOmegaGap eps W/4)*assignedHeavyPower p light alpha) := by
  have hw := actual_heavy_omega_band (k:=k) (cw:=1/8) heps (by norm_num) (by norm_num)
    ha hg hg1 hCh
  simp only [upperOmega_one_eighth] at hw
  have hraw : upperKappa alpha eps*(1+actualHeavyGap eps (1/8))*
        pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h≤
      pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B
        (Real.exp (-upperE0 k alpha eps Ch/8)) h ∧
      pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B
        (Real.exp (-upperE0 k alpha eps Ch/8)) h≤
        (1-actualHeavyGap eps (1/8))*pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h := by
    simpa only [actualTrueHeavyStatistic,upperOmega_one_eighth,
      selectedTrueHeavyPowerSum_eq_pilotTrueHeavyMass] using And.intro hgood.1 hgood.2.1
  have hband := actualPilotAssignedHeavy_band p n cp (b:=b) h hw.1 hw.2 hraw
  refine ⟨hband.1,hband.2,?_⟩
  intro hwidth
  have hcap := actual_compact_width_order_bound heps hW hg hg1 hwidth
  apply actualPilotAssignedHeavy_closeness p n cp
    (div_nonneg (compactOmegaGap_pos heps).le (by norm_num)) h
  simpa only [actualTrueHeavyStatistic,upperOmega_one_eighth,
    selectedTrueHeavyPowerSum_eq_pilotTrueHeavyMass] using hgood.2.2 hcap

/-- The only input from the deterministic analysis is its proved assigned-mean
interior at these fixed parameters. The pilot event, cutoff admissibility,
rescaling, correction and actual source polynomial are handled internally. -/
theorem general_histogram_ideal_on_heavy_good {k : ℕ} (n cp : ℝ≥0) (p : Simplex k)
    {alpha eps Ch D cb lambda CL cL fL f M cu C0 d B W c : ℝ}
    (hk : 0<k) (ha : 3/2≤alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (heps : 0<eps) (hCh : 0≤Ch) (hD : 0<D) (hcb : 0<cb)
    (hCL : 1≤CL) (hcL : 0<cL) (hB : 16≤B) (hscale : 2*B≤cb*CL) (hW : 0<W)
    (hn : (n:ℝ)=upperSample k alpha eps D)
    (hInterior : ∀ (light : Fin k→Bool) (heavy : ℝ),
      (∀i,light i=true→p.mass i≤upperB k alpha eps D cb CL cL) →
      upperKappa alpha eps*(1+actualHeavyGap eps (1/8))*assignedHeavyPower p light alpha≤heavy →
      heavy≤(1-actualHeavyGap eps (1/8))*assignedHeavyPower p light alpha →
      (2*eps*(alpha-1)/(fractionalPart alpha*(1-fractionalPart alpha))≤W →
        |heavy-Real.exp (-upperE0 k alpha eps Ch/8)*assignedHeavyPower p light alpha|≤
          (compactOmegaGap eps W/4)*assignedHeavyPower p light alpha) →
      upperKappa alpha eps*powerSum p alpha+
          3*c*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d 1≤
        actualAssignedOracleMean p light heavy alpha eps Ch D cb lambda CL cL fL f M cu 1 C0 d ∧
        actualAssignedOracleMean p light heavy alpha eps Ch D cb lambda CL cL fL f M cu 1 C0 d+
          3*c*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d 1≤powerSum p alpha)
    {h : PilotHistogram k}
    (hgood : h∈actualHeavyGoodEvent n cp p alpha eps Ch (1/8) B
      (actualHeavyGap eps (1/8)) (compactOmegaGap eps W/4) (2+8*W/eps)) :
    let Q := actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu 1
    let b := upperB k alpha eps D cb CL cL
    let omega := upperRescaling k alpha eps cu 1*Real.exp (-upperE0 k alpha eps Ch/8)
    let correction := 2*actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d
    upperKappa alpha eps*powerSum p alpha+
        3*c*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d 1≤
      nonintegerHistogramIdeal n cp p Q b alpha B omega correction h ∧
      nonintegerHistogramIdeal n cp p Q b alpha B omega correction h+
        3*c*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d 1≤powerSum p alpha := by
  have hgeom := upper_pilot_cutoff_geometry (eps:=eps) hk ha hg hg1 hD hcb hCL hcL hB hscale
  have hn0 : 0<(n:ℝ) := hn.symm ▸ hgeom.1
  have hcut : B*alpha/2≤(n:ℝ)*upperB k alpha eps D cb CL cL := by
    rw [hn]
    have hBa : 0≤B*alpha := mul_nonneg (by linarith only [hB]) (by linarith only [ha])
    linarith only [hgeom.2.2.2.2.2.1,hBa]
  let light := actualPilotLight p n cp (upperB k alpha eps D cb CL cL) alpha B h
  let heavy := actualPilotAssignedHeavy p n cp (upperB k alpha eps D cb CL cL) alpha B
    (Real.exp (-upperE0 k alpha eps Ch/8)) h
  have hlight : ∀i,light i=true→p.mass i≤upperB k alpha eps D cb CL cL :=
    actualPilotLight_admissible p n cp hn0 hcut h
  have hheavy := actual_heavy_good_assigned_conditions n cp p (b:=upperB k alpha eps D cb CL cL)
    heps hCh ha hg hg1 hW hgood
  have hinterior := hInterior light heavy hlight hheavy.1 hheavy.2.1 hheavy.2.2
  have hid := nonintegerHistogramIdeal_eq_actualAssigned p n cp alpha eps Ch D cb lambda CL cL
    fL f M cu 1 C0 d B h
  dsimp only [actualSourcePolynomial]
  rw [hid]
  exact hinterior

end Renyi
