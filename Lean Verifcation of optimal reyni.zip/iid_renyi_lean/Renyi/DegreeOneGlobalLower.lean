import Renyi.DegreeOneBoundedCertificate
import Renyi.DegreeOneSaturationLower

/-! Global actual lower certificate for the canonical degree-one completion. -/
noncomputable section
namespace Renyi.DegreeOneCompletion

/-- The actual coupled profiles have the full global lower baseline and local gain.
The low endpoint scale is exactly x, so no degree-energy hypothesis is needed. -/
theorem coupledProfiles_global_lower {fL f qL qH Emin M lam0 : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hEmin : 0<Emin) (hM : 1≤M) (hlam0 : 0<lam0) (hlam1 : lam0≤1)
    (hqL : Real.exp (-Emin)<qL) (hqLf : qL<fL)
    (hqH : Real.exp (-7*Emin/8)<qH) (hqHf : qH<f) :
    ∃ C c : ℝ, 0≤C ∧ 0<c ∧ ∀ (N : ℕ) (γ z E x y : ℝ), 2≤N →
      0<γ → γ<1 → 0<z → z<1 → Emin≤E → overlapG γ z=Real.exp (-E) →
      0≤x → x≤1 → 0<y → y≤1 →
      lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤(x)*((N:ℝ)^2*y) →
      (x)*((N:ℝ)^2*y)≤
        Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) →
      Real.exp (-E)*Real.exp (-C*(γ*(1-γ)))+c*Real.exp (-E)*min ((N:ℝ)^2*y) 1≤
        coupledDampedExpression 2 N γ z M (Real.exp (-E/8)) fL f x y := by
  obtain ⟨Estar,CL,cL,hEstar,hCL,hcL,hlarge⟩ :=
    coupledProfiles_large_energy_lower hfL hfL1 hf hf1 hEmin hlam0 hlam1 hM
  let Emax := max Emin Estar
  let R : ℝ := 2
  have hEEmax : Emin≤Emax := le_max_left _ _
  have hR : 1≤R := by norm_num [R]
  obtain ⟨CB,cB,hCB,hcB,hbounded⟩ := coupledProfiles_bounded_energy_lower
    hfL hfL1 hf hf1 hEmin hEEmax hR hM hlam0 hlam1 hqL hqLf hqH hqHf
  let C := max CL CB
  let c := min cL cB
  have hC : 0≤C := hCL.trans (le_max_left _ _)
  have hc : 0<c := lt_min hcL hcB
  refine ⟨C,c,hC,hc,?_⟩
  intro N γ z E x y hN hγ hγ1 hz hz1 hEE hG hx hx1 hy hy1 hcaplo hcaphi
  have hh : 0≤γ*(1-γ) := mul_nonneg hγ.le (sub_nonneg.mpr hγ1.le)
  have hκ : 0≤Real.exp (-E) := (Real.exp_pos _).le
  have hY : 0≤min ((N:ℝ)^2*y) 1 := le_min (by positivity) (by norm_num)
  by_cases hEstarE : Estar≤E
  · have hbound := hlarge 2 N γ z E x y (by norm_num) hN hγ hγ1 hz hz1 hEstarE hG hx hx1 hy hy1 hcaplo hcaphi
    have he : Real.exp (-C*(γ*(1-γ)))≤Real.exp (-CL*(γ*(1-γ))) := Real.exp_le_exp.mpr (by
      have hm := mul_le_mul_of_nonneg_right (le_max_left CL CB) hh
      nlinarith only [hm])
    have hbase := mul_le_mul_of_nonneg_left he hκ
    have hgain := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right (min_le_left cL cB) hκ) hY
    nlinarith only [hbound,hbase,hgain]
  · have hEEmax' : E≤Emax := (lt_of_not_ge hEstarE).le.trans (le_max_right _ _)
    have hbound := hbounded 2 N γ z E x y (by norm_num) hN (by norm_num [R]) hγ hγ1 hz hz1 hEE hEEmax' hG hx hx1 hy hy1 hcaplo hcaphi
    have he : Real.exp (-C*(γ*(1-γ)))≤Real.exp (-CB*(γ*(1-γ))) := Real.exp_le_exp.mpr (by
      have hm := mul_le_mul_of_nonneg_right (le_max_right CL CB) hh
      nlinarith only [hm])
    have hbase := mul_le_mul_of_nonneg_left he hκ
    have hgain := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right (min_le_right cL cB) hκ) hY
    nlinarith only [hbound,hbase,hgain]

end Renyi.DegreeOneCompletion
