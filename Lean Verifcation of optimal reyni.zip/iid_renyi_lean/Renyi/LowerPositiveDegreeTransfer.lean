import Renyi.LowerActualNormalization

/-! The complete positive-degree statistical transfer with uniform exceptions. -/
noncomputable section
open scoped BigOperators NNReal
namespace Renyi
set_option maxHeartbeats 1500000

/-- At the actual root rule, calibrated finite priors rule out fixed-size
estimation uniformly in every positive-degree order. Normalization, overflow,
and availability bounds are all discharged by the accuracy-dependent cutoffs. -/
theorem lower_positive_degree_prior_transfer {eps : ℝ} (he : 0<eps) :
    ∃ k₀ : ℕ, ∃ X₀ : ℝ, lowerPriorRootCutoff eps≤X₀ ∧ ∀ k : ℕ, k₀≤k →
      ∀ alpha s : ℝ, 3/2≤alpha → 0<s → s≤1/2 →
      (s=fractionalPart alpha ∨ s=1-fractionalPart alpha) →
      X₀≤rootMultiplier k alpha eps →
      let x := rootMultiplier k alpha eps
      let L : ℝ := Nat.ceil (10*alpha*(1+Real.log x))
      let theta := lowerPriorIntensityConstant eps*alpha*(k:ℝ)^(-1/alpha)*x
      let B := (1/100)*L/theta
      let E := 2*eps*(alpha-1)
      let v := (alpha-1)/alpha*x^(-alpha)
      let w := s*(1-s)+v
      let zeta := lowerPriorCoefficient eps*w/(1-Real.exp (-E))
      ∀ (ι₀ ι₁ : Type) [Fintype ι₀] [Fintype ι₁]
        (P₀ : FiniteAtomicPrior ι₀) (P₁ : FiniteAtomicPrior ι₁),
      (∀ i, P₀.value i=0 ∨ (1≤P₀.value i ∧ P₀.value i≤B)) →
      (∀ i, P₁.value i=0 ∨ (1≤P₁.value i ∧ P₁.value i≤B)) →
      priorMoment P₀ 1=1 → priorMoment P₁ 1=1 →
      E+w≤Real.log (priorMoment P₁ alpha/priorMoment P₀ alpha) →
      priorMoment P₀ (2*alpha)/(priorMoment P₀ alpha)^2≤lowerPriorSecondConstant eps*zeta^2*B^alpha →
      priorMoment P₁ (2*alpha)/(priorMoment P₁ alpha)^2≤lowerPriorSecondConstant eps*zeta^2*B^alpha →
      (k:ℝ)*countDistance (poissonMixture P₀.mass P₀.value theta) (poissonMixture P₁.mass P₁.value theta)≤1/32 →
      ∀ n : ℕ, (n:ℝ)≤theta*(k:ℝ)/8 → ¬Achievable k n alpha eps := by
  obtain ⟨K,X,hX,hNorm⟩ := lower_actual_prior_normalization he
  have hcn : 0<lowerPriorIntensityConstant eps := Real.exp_pos _
  obtain ⟨Ke,hException⟩ := lower_positive_degree_exception_cutoff hcn
  refine ⟨max 1 (max K Ke),X,hX,?_⟩
  intro k hk alpha s ha hs hs1 hnearest hx
  let x := rootMultiplier k alpha eps
  let L : ℝ := Nat.ceil (10*alpha*(1+Real.log x))
  let theta := lowerPriorIntensityConstant eps*alpha*(k:ℝ)^(-1/alpha)*x
  let B := (1/100)*L/theta
  let E := 2*eps*(alpha-1)
  let v := (alpha-1)/alpha*x^(-alpha)
  let w := s*(1-s)+v
  let zeta := lowerPriorCoefficient eps*w/(1-Real.exp (-E))
  dsimp only
  intro ι₀ ι₁ inst₀ inst₁ P₀ P₁ hsupp₀ hsupp₁ hmean₀ hmean₁ hgap hsecond₀ hsecond₁ hD n hn
  have hk1 : 1≤k := (le_max_left _ _).trans hk
  have hk0 : 0<k := by omega
  have hkR : (0:ℝ)<k := by exact_mod_cast hk0
  have hK : K≤k := (le_trans (le_max_left _ _) (le_max_right _ _)).trans hk
  have hKe : Ke≤k := (le_trans (le_max_right _ _) (le_max_right _ _)).trans hk
  have ha1 : 1<alpha := by linarith
  have ha0 : 0<alpha := by linarith
  have hb0 : 0<alpha-1 := by linarith
  have hx4 : 4≤x := (le_trans (le_max_left _ _) hX).trans hx
  have hx1 : 1≤x := by linarith
  have hx0 : 0<x := by linarith
  have hL : 0<L := (show 0<10*alpha*(1+Real.log x) by have hh := Real.log_nonneg hx1; positivity).trans_le (Nat.le_ceil _)
  have htheta : 0<theta := by dsimp [theta]; positivity
  have hB0 : 0<B := by dsimp [B]; positivity
  have hB : 1≤B := by
    have hv (i) : P₀.value i≤B := (hsupp₀ i).elim (fun h => by rw [h]; exact hB0.le) (fun h => h.2)
    have hh : priorMoment P₀ 1≤B := by
      calc
        _ = ∑ i, P₀.mass i*P₀.value i := by simp only [priorMoment,Real.rpow_one]
        _ ≤ ∑ i, P₀.mass i*B := Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left (hv i) (P₀.mass_nonneg i))
        _ = B := by rw [←Finset.sum_mul,P₀.mass_sum,one_mul]
    rwa [hmean₀] at hh
  have hv0 : 0≤v := by dsimp [v]; positivity
  have hw0 : 0<w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv0
  have hxpow : x^(-alpha)≤1/x := by
    rw [one_div,←Real.rpow_neg_one x]
    exact Real.rpow_le_rpow_of_exponent_le hx1 (by linarith)
  have hinv : 1/x≤1/4 := (div_le_div_iff₀ hx0 (by norm_num : (0:ℝ)<4)).mpr (by linarith)
  have hratio : 0≤(alpha-1)/alpha ∧ (alpha-1)/alpha≤1 :=
    ⟨div_nonneg hb0.le ha0.le,(div_le_one ha0).mpr (by linarith)⟩
  have hv1 : v≤1/4 := (mul_le_mul hratio.2 (hxpow.trans hinv) (Real.rpow_nonneg hx0.le _) (by norm_num : (0:ℝ)≤1)).trans_eq (by ring)
  have hw1 : w≤1 := by dsimp [w]; nlinarith [sq_nonneg (s-1/2)]
  have hvalue₀ : ∀ i, 0≤P₀.value i := fun i => (hsupp₀ i).elim (fun h => h ▸ le_rfl) (fun h => zero_le_one.trans h.1)
  have hvalue₁ : ∀ i, 0≤P₁.value i := fun i => (hsupp₁ i).elim (fun h => h ▸ le_rfl) (fun h => zero_le_one.trans h.1)
  have hA₀ : 0<priorMoment P₀ alpha := zero_lt_one.trans_le (finite_prior_power_bounds P₀ alpha B ha1 hB hsupp₀ hmean₀).1
  have hA₁ : 0<priorMoment P₁ alpha := zero_lt_one.trans_le (finite_prior_power_bounds P₁ alpha B ha1 hB hsupp₁ hmean₁).1
  let b : ℝ≥0 := ⟨(k:ℝ)/2,by positivity⟩
  let thetaNN : ℝ≥0 := ⟨theta,htheta.le⟩
  have hb : (b:ℝ)=(k:ℝ)/2 := rfl
  have hbpos : 0<(b:ℝ) := by change 0<(k:ℝ)/2; positivity
  have hnorm₀ := hNorm k hK alpha s ha hs hs1 hnearest hx ι₀ P₀ b hb hsupp₀ hmean₀ hsecond₀
  have hnorm₁ := hNorm k hK alpha s ha hs hs1 hnearest hx ι₁ P₁ b hb hsupp₁ hmean₁ hsecond₁
  obtain ⟨hsupport,havailable⟩ := hException k hKe alpha x ha hx1
  apply fingerprint_transfer_finite_priors b thetaNN hbpos (by change 2*((k:ℝ)/2)≤k; linarith)
    P₀ P₁ hvalue₀ hvalue₁ ha1 hw0 hw1 hA₀ hA₁ hmean₀ hmean₁ hgap
  · change ((k:ℝ)/2)*countDistance (poissonMixture P₀.mass P₀.value theta) (poissonMixture P₁.mass P₁.value theta)≤1/16
    nlinarith only [hD]
  · exact hnorm₀
  · exact hnorm₁
  · exact hsupport
  · change Real.exp (-theta*((k:ℝ)/2)/16)≤1/128
    convert havailable using 1; congr 1; ring
  · change (n:ℝ)≤theta*((k:ℝ)/2)/4
    change (n:ℝ)≤theta*(k:ℝ)/8 at hn
    linarith

end Renyi
