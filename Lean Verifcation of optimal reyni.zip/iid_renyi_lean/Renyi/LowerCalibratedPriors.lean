import Renyi.LowerCalibration

/-!
# Actual entropy-separated finite priors after scalar calibration

The theorem here is a conditional construction: the principal-point and
perturbation inequalities still have to be derived from the common root
parameters. Its probability laws, moment cancellations, and entropy gap
are constructed and proved, not supplied as certificates.
-/

noncomputable section
open scoped BigOperators
namespace Renyi

/-- The first interpolation node supplies a strictly negative atom. -/
theorem normalizedInterpolation_negative_mass_pos {n : ℕ}
    (u : Fin (n + 1) → ℝ) (hu : StrictMono u) {a ρ e : ℝ}
    (ha : 0 < a) (hau : ∀ i, a < u i) (hρ : 0 ≤ ρ) :
    0 < ∑ i, negativeCoeff (normalizedInterpolation u a ρ e i) := by
  have hfirst := lagrangeWeight_first_ge_one u hu (hau 0).le
  have hu₀ : 0 < u 0 := ha.trans (hau 0)
  have hfactor : 0 < 1 + ρ * a / u 0 := by positivity
  have hweight : weightedInterpolation u a ρ e (some 0) < 0 := by
    simp only [weightedInterpolation, interpolationWeights, interpolationNodes, Option.elim_some]
    apply mul_neg_of_neg_of_pos
    · exact neg_neg_of_pos (mul_pos (by linarith) hfactor)
    · exact Real.rpow_pos_of_pos hu₀ _
  have hnorm : normalizedInterpolation u a ρ e (some 0) < 0 :=
    div_neg_of_neg_of_pos hweight (interpolationNormalizer_pos u ha hρ)
  have hterm : 0 < negativeCoeff (normalizedInterpolation u a ρ e (some 0)) :=
    (neg_pos.mpr hnorm).trans_le (le_max_left _ _)
  have hh := Finset.single_le_sum
    (s := (Finset.univ : Finset (Option (Fin (n + 1)))))
    (f := fun i => negativeCoeff (normalizedInterpolation u a ρ e i))
    (fun i _ => le_max_right _ _) (Finset.mem_univ (some 0))
  exact hterm.trans_le hh

/-- The positive-sign construction at positive active degree. Its only
unproved calibration inputs are the two explicit scalar inequalities on
the chosen principal point and perturbation, corresponding to Step 2.
No moment, entropy, or statistical-distance conclusion is assumed. -/
theorem positive_sign_constructed_priors (r L : ℕ) (s E w c a : ℝ)
    (hr : 2 ≤ r) (_hL : r ≤ L) (hs₀ : 0 < s) (hs₁ : s ≤ 1 / 2)
    (hE : 0 < E) (hw : 0 < w) (hc₀ : 0 < c) (hc₁ : c ≤ 1 / 2)
    (hζsmall : c * w / (1 - Real.exp (-E)) ≤ 1 / 8) (ha : 0 < a) :
    let ζ := c * w / (1 - Real.exp (-E))
    let κ := Real.exp (-E - 4 * w)
    let ξ := 1 - s
    let ns := r - 1
    let nc := L - r
    let bs := (ζ / 8) / ((ns : ℝ) + 1) ^ 2
    let bc := ξ / ((nc : ℝ) + 1) ^ 2
    let ac := Real.exp (-5) * bc * (ζ * κ) ^ (1 / ξ)
    let ρ := max (((a / bs) ^ s / κ) *
      Real.exp (4 * ζ * (ns : ℝ) / ((ns : ℝ) + 1)) - 1) 0
    a ≤ bs / 2 → ρ * a / bs ≤ ζ →
    ∃ p₀ p₁ : FiniteAtomicPrior
        (Option ((Option (Fin ((r - 1) + 1))) × (Option (Fin ((L - r) + 1))))),
      (∀ i, p₀.value i = 0 ∨ (1 ≤ p₀.value i ∧ p₀.value i ≤ (a * ac)⁻¹)) ∧
      (∀ i, p₁.value i = 0 ∨ (1 ≤ p₁.value i ∧ p₁.value i ≤ (a * ac)⁻¹)) ∧
      priorMoment p₀ 1 = 1 ∧ priorMoment p₁ 1 = 1 ∧
      (∀ j : ℕ, 1 ≤ j → j ≤ L + 1 → j ≠ r →
        priorMoment p₁ (j : ℝ) = priorMoment p₀ (j : ℝ)) ∧
      E + w ≤ Real.log (priorMoment p₁ ((r : ℝ) + s) / priorMoment p₀ ((r : ℝ) + s)) := by
  dsimp only
  let ζ := c * w / (1 - Real.exp (-E))
  let κ := Real.exp (-E - 4 * w)
  let ξ := 1 - s
  let ns := r - 1
  let nc := L - r
  let bs := (ζ / 8) / ((ns : ℝ) + 1) ^ 2
  let bc := ξ / ((nc : ℝ) + 1) ^ 2
  let ac := Real.exp (-5) * bc * (ζ * κ) ^ (1 / ξ)
  let ρ := max (((a / bs) ^ s / κ) *
    Real.exp (4 * ζ * (ns : ℝ) / ((ns : ℝ) + 1)) - 1) 0
  intro ha_small hpert
  change a ≤ bs / 2 at ha_small
  change ρ * a / bs ≤ ζ at hpert
  have hζ₀ : 0 < ζ := by
    apply div_pos (mul_pos hc₀ hw)
    apply sub_pos.mpr
    exact Real.exp_lt_one_iff.mpr (by linarith)
  have hζ₁ : ζ ≤ 1 / 8 := hζsmall
  have hκ₀ : 0 < κ := Real.exp_pos _
  have hκ₁ : κ ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
  have hξ₀ : 1 / 2 ≤ ξ := by dsimp [ξ]; linarith
  have hξ₁ : ξ < 1 := by dsimp [ξ]; linarith
  have hξpos : 0 < ξ := by linarith
  have hz₀ : 0 < ζ * κ := mul_pos hζ₀ hκ₀
  have hz₁ : ζ * κ ≤ 1 := by
    have hh := mul_le_mul_of_nonneg_left hκ₁ hζ₀.le
    nlinarith
  have hns : 0 < ns := by dsimp [ns]; omega
  have hbs₀ : 0 < bs := by dsimp [bs]; positivity
  have hbs₁ : bs < 1 := by
    apply (div_lt_one (by positivity : (0 : ℝ) < ((ns : ℝ) + 1) ^ 2)).mpr
    have hh : (0 : ℝ) ≤ ns := Nat.cast_nonneg _
    nlinarith
  have hbc₀ : 0 < bc := by dsimp [bc]; positivity
  have hbc₁ : bc < 1 := by
    apply (div_lt_one (by positivity : (0 : ℝ) < ((nc : ℝ) + 1) ^ 2)).mpr
    have hh : (0 : ℝ) ≤ nc := Nat.cast_nonneg _
    nlinarith
  have hac₀ : 0 < ac := by dsimp [ac]; positivity
  have hacbc : ac < bc := by
    have hzpow : (ζ * κ) ^ (1 / ξ) ≤ 1 := Real.rpow_le_one hz₀.le hz₁ (by positivity)
    have hh := mul_le_mul_of_nonneg_left hzpow (mul_nonneg (Real.exp_nonneg (-5)) hbc₀.le)
    have he : Real.exp (-5) < 1 := Real.exp_lt_one_iff.mpr (by norm_num)
    dsimp only [ac]
    nlinarith
  have habs : a < bs := by linarith
  have ha₁ : a < 1 := habs.trans hbs₁
  have hac₁ : ac < 1 := hacbc.trans hbc₁
  have hρ : 0 ≤ ρ := le_max_right _ _
  let us := chebyshevNode ns bs
  let uc := chebyshevNode nc bc
  let l := normalizedInterpolation us a ρ s
  let t := normalizedInterpolation uc ac 0 ξ
  let U := interpolationNodes us a
  let V := interpolationNodes uc ac
  let Rs := ∑ i, negativeCoeff (l i)
  let Rc := ∑ i, negativeCoeff (t i)
  have hus : Function.Injective us := chebyshevNode_injective ns bs hbs₁
  have huc : Function.Injective uc := chebyshevNode_injective nc bc hbc₁
  have has : ∀ i, a < us i := fun i => habs.trans_le (chebyshevNode_bounds ns bs hbs₁.le i).1
  have hac : ∀ i, ac < uc i := fun i => hacbc.trans_le (chebyshevNode_bounds nc bc hbc₁.le i).1
  have hus₁ : ∀ i, us i ≤ 1 := fun i => (chebyshevNode_bounds ns bs hbs₁.le i).2
  have huc₁ : ∀ i, uc i ≤ 1 := fun i => (chebyshevNode_bounds nc bc hbc₁.le i).2
  have hRs : Rs ≤ κ := (active_interpolation_mass_bound ns ζ a s κ hns hζ₀
    (by linarith) ha ha_small hs₀.le hκ₀ hκ₁ hpert).1
  have hRc : Rc ≤ ζ * κ := by
    have hh := (chebyshev_nodes_weighted nc ξ (ζ * κ) hξ₀ hξ₁ hz₀ hz₁).1
    have he : Real.exp (-ξ) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
    exact hh.trans (by simpa only [one_mul] using mul_le_mul_of_nonneg_right he hz₀.le)
  have hRs₀ : 0 ≤ Rs := Finset.sum_nonneg (fun i _ => le_max_right _ _)
  have hRc₀ : 0 ≤ Rc := Finset.sum_nonneg (fun i _ => le_max_right _ _)
  have hRcpos : 0 < Rc := normalizedInterpolation_negative_mass_pos uc
    (chebyshevNode_strictMono nc bc hbc₁) hac₀ hac (by norm_num)
  have hRpos : 0 < Rs + Rc := add_pos_of_nonneg_of_pos hRs₀ hRcpos
  have hgap := calibrated_parity_entropy_gap hE hw hc₀.le hc₁ hζsmall hRs₀ hRc₀ hRs hRc hRpos
  have hα : 1 < (r : ℝ) + s := by
    have hr' : (2 : ℝ) ≤ r := by exact_mod_cast hr
    linarith
  have hl : ∑ i, positiveCoeff (l i) = 1 := normalizedInterpolation_positive_mass us ha hρ
  have ht : ∑ i, positiveCoeff (t i) = 1 := normalizedInterpolation_positive_mass uc hac₀ (by norm_num)
  have hUa : ∀ i, a ≤ U i := by
    intro i
    cases i with
    | none => exact le_rfl
    | some i => exact (has i).le
  have hU₁ : ∀ i, U i ≤ 1 := by
    intro i
    cases i with
    | none => exact ha₁.le
    | some i => exact hus₁ i
  have hVac : ∀ i, ac ≤ V i := by
    intro i
    cases i with
    | none => exact le_rfl
    | some i => exact (hac i).le
  have hV₁ : ∀ i, V i ≤ 1 := by
    intro i
    cases i with
    | none => exact hac₁.le
    | some i => exact huc₁ i
  have hmean : (∑ i, l i * U i ^ ((r : ℝ) + s - 1)) *
      (∑ j, t j * V j ^ (1 - ((r : ℝ) + s))) = 0 := by
    have hz := low_integer_factor_zero us hus (ρ := ρ) (γ := s) ha has 1 (by omega) (by omega)
      (Or.inl (by omega))
    change (∑ i, l i * U i ^ ((r : ℝ) + s - (1 : ℕ))) = 0 at hz
    simpa only [Nat.cast_one, hz, zero_mul] using
      congrArg (fun q : ℝ => q * (∑ j, t j * V j ^ (1 - ((r : ℝ) + s)))) hz
  obtain ⟨_, p₀, p₁, hp₀, hp₁, hm₀, hm₁, hdiff, _, _, hlog⟩ :=
    tensor_priors l t U V hα ha hac₀ hUa hU₁ hVac hV₁ hl ht rfl rfl hRpos hmean
  refine ⟨p₀, p₁, hp₀, hp₁, hm₀, hm₁, ?_, ?_⟩
  · intro j hj₁ hjL hjr
    have hj : (0 : ℝ) < j := by exact_mod_cast (show 0 < j by omega)
    have hd := hdiff (j : ℝ) hj
    have hz := noninteger_tensor_factor_cancellation us uc hus huc (ρl := ρ) (ρr := 0) (γ := s)
      ha hac₀ has hac j hj₁ hjL (Or.inl hjr) (Or.inr rfl)
    change (∑ i, l i * (U i / a) ^ ((r : ℝ) + s - (j : ℝ))) *
      (∑ v, t v * V v ^ ((j : ℝ) - ((r : ℝ) + s))) = 0 at hz
    rw [hz, mul_zero] at hd
    exact sub_eq_zero.mp hd
  · rw [hlog]
    exact hgap

/-- The negative-sign construction. Here the nearest integer is `m+1`,
so `α=m+(1-s)` and its only possibly unmatched moment is `m+1`.
The degree-zero complementary factor is included. -/
theorem negative_sign_constructed_priors (m L : ℕ) (s E w c a : ℝ)
    (hm : 1 ≤ m) (hL : m + 1 ≤ L) (hs₀ : 0 < s) (hs₁ : s ≤ 1 / 2)
    (hE : 0 < E) (hw : 0 < w) (hc₀ : 0 < c) (hc₁ : c ≤ 1 / 2)
    (hζsmall : c * w / (1 - Real.exp (-E)) ≤ 1 / 8) (ha : 0 < a) :
    let ζ := c * w / (1 - Real.exp (-E))
    let κ := Real.exp (-E - 4 * w)
    let ξ := 1 - s
    let ns := L - m
    let nc := m - 1
    let bs := (ζ / 8) / ((ns : ℝ) + 1) ^ 2
    let bc := ξ / ((nc : ℝ) + 1) ^ 2
    let ac := Real.exp (-5) * bc * (ζ * κ) ^ (1 / ξ)
    let ρ := max (((a / bs) ^ s / κ) *
      Real.exp (4 * ζ * (ns : ℝ) / ((ns : ℝ) + 1)) - 1) 0
    a ≤ bs / 2 → ρ * a / bs ≤ ζ →
    ∃ p₀ p₁ : FiniteAtomicPrior
        (Option ((Option (Fin ((m - 1) + 1))) × (Option (Fin ((L - m) + 1))))),
      (∀ i, p₀.value i = 0 ∨ (1 ≤ p₀.value i ∧ p₀.value i ≤ (ac * a)⁻¹)) ∧
      (∀ i, p₁.value i = 0 ∨ (1 ≤ p₁.value i ∧ p₁.value i ≤ (ac * a)⁻¹)) ∧
      priorMoment p₀ 1 = 1 ∧ priorMoment p₁ 1 = 1 ∧
      (∀ j : ℕ, 1 ≤ j → j ≤ L + 1 → j ≠ m + 1 →
        priorMoment p₁ (j : ℝ) = priorMoment p₀ (j : ℝ)) ∧
      E + w ≤ Real.log (priorMoment p₁ ((m : ℝ) + (1 - s)) / priorMoment p₀ ((m : ℝ) + (1 - s))) := by
  dsimp only
  let ζ := c * w / (1 - Real.exp (-E))
  let κ := Real.exp (-E - 4 * w)
  let ξ := 1 - s
  let ns := L - m
  let nc := m - 1
  let bs := (ζ / 8) / ((ns : ℝ) + 1) ^ 2
  let bc := ξ / ((nc : ℝ) + 1) ^ 2
  let ac := Real.exp (-5) * bc * (ζ * κ) ^ (1 / ξ)
  let ρ := max (((a / bs) ^ s / κ) *
    Real.exp (4 * ζ * (ns : ℝ) / ((ns : ℝ) + 1)) - 1) 0
  intro ha_small hpert
  change a ≤ bs / 2 at ha_small
  change ρ * a / bs ≤ ζ at hpert
  have hζ₀ : 0 < ζ := by
    apply div_pos (mul_pos hc₀ hw)
    apply sub_pos.mpr
    exact Real.exp_lt_one_iff.mpr (by linarith)
  have hζ₁ : ζ ≤ 1 / 8 := hζsmall
  have hκ₀ : 0 < κ := Real.exp_pos _
  have hκ₁ : κ ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
  have hξ₀ : 1 / 2 ≤ ξ := by dsimp [ξ]; linarith
  have hξ₁ : ξ < 1 := by dsimp [ξ]; linarith
  have hξpos : 0 < ξ := by linarith
  have hz₀ : 0 < ζ * κ := mul_pos hζ₀ hκ₀
  have hz₁ : ζ * κ ≤ 1 := by
    have hh := mul_le_mul_of_nonneg_left hκ₁ hζ₀.le
    nlinarith
  have hns : 0 < ns := by dsimp [ns]; omega
  have hbs₀ : 0 < bs := by dsimp [bs]; positivity
  have hbs₁ : bs < 1 := by
    apply (div_lt_one (by positivity : (0 : ℝ) < ((ns : ℝ) + 1) ^ 2)).mpr
    have hh : (0 : ℝ) ≤ ns := Nat.cast_nonneg _
    nlinarith
  have hbc₀ : 0 < bc := by dsimp [bc]; positivity
  have hbc₁ : bc < 1 := by
    apply (div_lt_one (by positivity : (0 : ℝ) < ((nc : ℝ) + 1) ^ 2)).mpr
    have hh : (0 : ℝ) ≤ nc := Nat.cast_nonneg _
    nlinarith
  have hac₀ : 0 < ac := by dsimp [ac]; positivity
  have hacbc : ac < bc := by
    have hzpow : (ζ * κ) ^ (1 / ξ) ≤ 1 := Real.rpow_le_one hz₀.le hz₁ (by positivity)
    have hh := mul_le_mul_of_nonneg_left hzpow (mul_nonneg (Real.exp_nonneg (-5)) hbc₀.le)
    have he : Real.exp (-5) < 1 := Real.exp_lt_one_iff.mpr (by norm_num)
    dsimp only [ac]
    nlinarith
  have habs : a < bs := by linarith
  have ha₁ : a < 1 := habs.trans hbs₁
  have hac₁ : ac < 1 := hacbc.trans hbc₁
  have hρ : 0 ≤ ρ := le_max_right _ _
  let us := chebyshevNode ns bs
  let uc := chebyshevNode nc bc
  let l := normalizedInterpolation uc ac 0 ξ
  let t := normalizedInterpolation us a ρ s
  let U := interpolationNodes uc ac
  let V := interpolationNodes us a
  let Rs := ∑ i, negativeCoeff (t i)
  let Rc := ∑ i, negativeCoeff (l i)
  have hus : Function.Injective us := chebyshevNode_injective ns bs hbs₁
  have huc : Function.Injective uc := chebyshevNode_injective nc bc hbc₁
  have has : ∀ i, a < us i := fun i => habs.trans_le (chebyshevNode_bounds ns bs hbs₁.le i).1
  have hac : ∀ i, ac < uc i := fun i => hacbc.trans_le (chebyshevNode_bounds nc bc hbc₁.le i).1
  have hus₁ : ∀ i, us i ≤ 1 := fun i => (chebyshevNode_bounds ns bs hbs₁.le i).2
  have huc₁ : ∀ i, uc i ≤ 1 := fun i => (chebyshevNode_bounds nc bc hbc₁.le i).2
  have hRs : Rs ≤ κ := (active_interpolation_mass_bound ns ζ a s κ hns hζ₀
    (by linarith) ha ha_small hs₀.le hκ₀ hκ₁ hpert).1
  have hRc : Rc ≤ ζ * κ := by
    have hh := (chebyshev_nodes_weighted nc ξ (ζ * κ) hξ₀ hξ₁ hz₀ hz₁).1
    have he : Real.exp (-ξ) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
    exact hh.trans (by simpa only [one_mul] using mul_le_mul_of_nonneg_right he hz₀.le)
  have hRs₀ : 0 ≤ Rs := Finset.sum_nonneg (fun i _ => le_max_right _ _)
  have hRc₀ : 0 ≤ Rc := Finset.sum_nonneg (fun i _ => le_max_right _ _)
  have hRcpos : 0 < Rc := normalizedInterpolation_negative_mass_pos uc
    (chebyshevNode_strictMono nc bc hbc₁) hac₀ hac (by norm_num)
  have hRpos : 0 < Rs + Rc := add_pos_of_nonneg_of_pos hRs₀ hRcpos
  have hgap := calibrated_parity_entropy_gap hE hw hc₀.le hc₁ hζsmall hRs₀ hRc₀ hRs hRc hRpos
  have hα : 1 < (m : ℝ) + ξ := by
    have hm' : (1 : ℝ) ≤ m := by exact_mod_cast hm
    linarith
  have hl : ∑ i, positiveCoeff (l i) = 1 := normalizedInterpolation_positive_mass uc hac₀ (by norm_num)
  have ht : ∑ i, positiveCoeff (t i) = 1 := normalizedInterpolation_positive_mass us ha hρ
  have hUac : ∀ i, ac ≤ U i := by
    intro i
    cases i with
    | none => exact le_rfl
    | some i => exact (hac i).le
  have hU₁ : ∀ i, U i ≤ 1 := by
    intro i
    cases i with
    | none => exact hac₁.le
    | some i => exact huc₁ i
  have hVa : ∀ i, a ≤ V i := by
    intro i
    cases i with
    | none => exact le_rfl
    | some i => exact (has i).le
  have hV₁ : ∀ i, V i ≤ 1 := by
    intro i
    cases i with
    | none => exact ha₁.le
    | some i => exact hus₁ i
  have hmean : (∑ i, l i * U i ^ ((m : ℝ) + ξ - 1)) *
      (∑ j, t j * V j ^ (1 - ((m : ℝ) + ξ))) = 0 := by
    have hz := low_integer_factor_zero uc huc (ρ := 0) (γ := ξ) hac₀ hac 1 (by omega) hm (Or.inr rfl)
    change (∑ i, l i * U i ^ ((m : ℝ) + ξ - (1 : ℕ))) = 0 at hz
    simpa only [Nat.cast_one, hz, zero_mul] using
      congrArg (fun q : ℝ => q * (∑ j, t j * V j ^ (1 - ((m : ℝ) + ξ)))) hz
  have hRpos' : 0 < Rc + Rs := by linarith
  obtain ⟨_, p₀, p₁, hp₀, hp₁, hm₀, hm₁, hdiff, _, _, hlog⟩ :=
    tensor_priors l t U V hα hac₀ ha hUac hU₁ hVa hV₁ hl ht rfl rfl hRpos' hmean
  refine ⟨p₀, p₁, hp₀, hp₁, hm₀, hm₁, ?_, ?_⟩
  · intro j hj₁ hjL hjr
    have hj : (0 : ℝ) < j := by exact_mod_cast (show 0 < j by omega)
    have hd := hdiff (j : ℝ) hj
    have hz := noninteger_tensor_factor_cancellation uc us huc hus (ρl := 0) (ρr := ρ) (γ := ξ)
      hac₀ ha hac has j hj₁ hjL (Or.inr rfl) (Or.inl hjr)
    have hexp : 1 - ξ = s := by dsimp [ξ]; ring
    rw [hexp] at hz
    change (∑ i, l i * (U i / ac) ^ ((m : ℝ) + ξ - (j : ℝ))) *
      (∑ v, t v * V v ^ ((j : ℝ) - ((m : ℝ) + ξ))) = 0 at hz
    rw [hz, mul_zero] at hd
    exact sub_eq_zero.mp hd
  · rw [hlog]
    change E + w ≤ Real.log ((1 + Rc * Rs) / (Rc + Rs))
    rw [mul_comm Rc Rs, add_comm Rc Rs]
    exact hgap

end Renyi
