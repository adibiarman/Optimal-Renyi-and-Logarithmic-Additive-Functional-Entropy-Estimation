import Renyi.CoupledCountVariance
import Renyi.UpperBaseline

/-! Scalar normalization and power-mean bounds for conditional count noise. -/

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

/-- Uniform domination of a monomial by the square of its affine margin. -/
theorem monomial_over_affine_margin_sq {E v A θ : ℝ}
    (hE : 0 < E) (hv : 0 < v) (hA : 0 ≤ A) (hθ : 0 ≤ θ) (hθ2 : θ ≤ 2) :
    A ^ θ / (E + v * A) ^ 2 ≤ E ^ (θ - 2) * v ^ (-θ) := by
  have hs : 0 < E + v * A := by positivity
  have hm : 0 ≤ v * A := mul_nonneg hv.le hA
  have hid : A ^ θ = (v * A) ^ θ * v ^ (-θ) := by
    rw [Real.mul_rpow hv.le hA]
    rw [mul_assoc, mul_comm (A ^ θ), ← mul_assoc, ← Real.rpow_add hv]
    simp
  have hpow := Real.rpow_le_rpow hm (by linarith : v * A ≤ E + v * A) hθ
  have hdecr := Real.rpow_le_rpow_of_nonpos hE (by linarith : E ≤ E + v * A)
    (by linarith : θ - 2 ≤ 0)
  calc
    _ = ((v * A) ^ θ * v ^ (-θ)) * (E + v * A) ^ (-2 : ℝ) := by
      rw [hid, Real.rpow_neg hs.le, Real.rpow_two]
      rfl
    _ ≤ ((E + v * A) ^ θ * v ^ (-θ)) * (E + v * A) ^ (-2 : ℝ) := by
      gcongr
    _ = (E + v * A) ^ (θ - 2) * v ^ (-θ) := by
      rw [show θ - 2 = θ + (-2) by ring, Real.rpow_add hs]
      ring
    _ ≤ _ := mul_le_mul_of_nonneg_right hdecr (Real.rpow_nonneg hv.le _)

/-- The exact exponent cancellation responsible for a final negative power of D. -/
theorem count_degree_exponent_identity {alpha j : ℝ} (ha : alpha ≠ 0) :
    -2 * (alpha - j) - j + (alpha - 1) * (2 - j / alpha) = -2 + j / alpha := by
  field_simp
  ring

theorem count_degree_sample_multiplier {alpha j D : ℝ}
    (ha : 0 < alpha) (hj : j ≤ alpha) (hD : 1 ≤ D) :
    D ^ (-2 * (alpha - j) - j + (alpha - 1) * (2 - j / alpha)) ≤ D ^ (-1 : ℝ) := by
  rw [count_degree_exponent_identity ha.ne']
  exact Real.rpow_le_rpow_of_exponent_le hD (by
    have h := (div_le_one ha).mpr hj
    linarith)

/-- The reserved root width cancels every power of the root multiplier. -/
theorem count_degree_root_multiplier {alpha j X u cu : ℝ}
    (ha : 0 < alpha) (hj : 0 ≤ j) (hX : 0 < X) (hcu : 0 < cu)
    (hu : cu * X ^ (-alpha) ≤ u) :
    X ^ (-j) * u ^ (-(j / alpha)) ≤ cu ^ (-(j / alpha)) := by
  have ht : 0 ≤ j / alpha := div_nonneg hj ha.le
  have hb : 0 < cu * X ^ (-alpha) := by positivity
  have hup : 0 < u := hb.trans_le hu
  have h := Real.rpow_le_rpow_of_nonpos hb hu (neg_nonpos.mpr ht)
  have hm := mul_le_mul_of_nonneg_left h (Real.rpow_nonneg hX.le (-j))
  apply hm.trans_eq
  rw [Real.mul_rpow hcu.le (Real.rpow_nonneg hX.le _), ← Real.rpow_mul hX.le]
  have hid : -alpha * -(j / alpha) = j := by field_simp
  rw [hid]
  calc
    X ^ (-j) * (cu ^ (-(j / alpha)) * X ^ j) =
        (X ^ (-j) * X ^ j) * cu ^ (-(j / alpha)) := by ring
    _ = _ := by rw [← Real.rpow_add hX]; simp

/-- Power means for an actual finite nonnegative vector, at a lower integer order. -/
theorem finite_power_sum_interpolation {ι : Type*} [Fintype ι]
    (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) (hk : (0 : ℝ) < Fintype.card ι)
    {alpha : ℝ} {j : ℕ} (hj : 0 < j) (hja : (j : ℝ) ≤ alpha) :
    powerSumNat p j ≤ (Fintype.card ι : ℝ) ^ (1 - (j : ℝ) / alpha) *
      (∑ i, p i ^ alpha) ^ ((j : ℝ) / alpha) := by
  have hjR : 0 < (j : ℝ) := by exact_mod_cast hj
  have ha : 0 < alpha := hjR.trans_le hja
  let β := alpha / (j : ℝ)
  let θ := (j : ℝ) / alpha
  have hβ : 1 ≤ β := (one_le_div hjR).mpr hja
  have hθ : 0 < θ := div_pos hjR ha
  have hPj : 0 ≤ powerSumNat p j := Finset.sum_nonneg (fun i _ => pow_nonneg (hp i) _)
  have hPa : 0 ≤ ∑ i, p i ^ alpha := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (hp i) _)
  have hinner (i : ι) : (p i ^ j) ^ β = p i ^ alpha := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul (hp i)]
    congr 1
    dsimp [β]
    field_simp
  have hJ := Real.rpow_sum_le_const_mul_sum_rpow_of_nonneg
    (s := Finset.univ) (f := fun i => p i ^ j) hβ (fun i _ => pow_nonneg (hp i) _)
  simp only [Finset.card_univ] at hJ
  simp_rw [hinner] at hJ
  change (powerSumNat p j) ^ β ≤ (Fintype.card ι : ℝ) ^ (β - 1) * (∑ i, p i ^ alpha) at hJ
  have h := Real.rpow_le_rpow (Real.rpow_nonneg hPj β) hJ hθ.le
  rw [← Real.rpow_mul hPj, show β * θ = 1 by dsimp [β, θ]; field_simp, Real.rpow_one] at h
  rw [Real.mul_rpow (Real.rpow_nonneg hk.le _) hPa, ← Real.rpow_mul hk.le] at h
  have he : (β - 1) * θ = 1 - θ := by dsimp [β, θ]; field_simp
  rw [he] at h
  exact h

/-- The source normalization `P_j ≤ k^(1-j) A^(j/alpha)` for the actual vector. -/
theorem finite_power_sum_normalized {ι : Type*} [Fintype ι]
    (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) (hk : (0 : ℝ) < Fintype.card ι)
    {alpha : ℝ} {j : ℕ} (hj : 0 < j) (hja : (j : ℝ) ≤ alpha) :
    powerSumNat p j ≤ (Fintype.card ι : ℝ) ^ (1 - (j : ℝ)) *
      ((∑ i, p i ^ alpha) / (Fintype.card ι : ℝ) ^ (1 - alpha)) ^ ((j : ℝ) / alpha) := by
  have hjR : 0 < (j : ℝ) := by exact_mod_cast hj
  have ha : 0 < alpha := hjR.trans_le hja
  have hPa : 0 ≤ ∑ i, p i ^ alpha := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (hp i) _)
  have hid : (Fintype.card ι : ℝ) ^ (1 - (j : ℝ)) *
      ((∑ i, p i ^ alpha) / (Fintype.card ι : ℝ) ^ (1 - alpha)) ^ ((j : ℝ) / alpha) =
      (Fintype.card ι : ℝ) ^ (1 - (j : ℝ) / alpha) * (∑ i, p i ^ alpha) ^ ((j : ℝ) / alpha) := by
    rw [Real.div_rpow hPa (Real.rpow_nonneg hk.le _), ← Real.rpow_mul hk.le]
    calc
      _ = ((Fintype.card ι : ℝ) ^ (1 - (j : ℝ)) /
          (Fintype.card ι : ℝ) ^ ((1 - alpha) * ((j : ℝ) / alpha))) *
            (∑ i, p i ^ alpha) ^ ((j : ℝ) / alpha) := by ring
      _ = _ := by
        rw [← Real.rpow_sub hk]
        congr 1
        congr 1
        field_simp
        ring
  rw [hid]
  exact finite_power_sum_interpolation p hp hk hj hja

/-- Exact normalization of the lower-degree power sum by the affine variance margin. -/
theorem finite_power_sum_over_affine_margin {ι : Type*} [Fintype ι]
    (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) (hk : (0 : ℝ) < Fintype.card ι)
    {alpha E v : ℝ} {j : ℕ} (hj : 0 < j) (hja : (j : ℝ) ≤ alpha)
    (hE : 0 < E) (hv : 0 < v) :
    powerSumNat p j /
        (E + v * ((∑ i, p i ^ alpha) / (Fintype.card ι : ℝ) ^ (1 - alpha))) ^ 2 ≤
      (Fintype.card ι : ℝ) ^ (1 - (j : ℝ)) *
        E ^ ((j : ℝ) / alpha - 2) * v ^ (-((j : ℝ) / alpha)) := by
  have hjR : 0 < (j : ℝ) := by exact_mod_cast hj
  have ha : 0 < alpha := hjR.trans_le hja
  let A := (∑ i, p i ^ alpha) / (Fintype.card ι : ℝ) ^ (1 - alpha)
  have hA : 0 ≤ A := div_nonneg
    (Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (hp i) _)) (Real.rpow_nonneg hk.le _)
  have hmargin : 0 < E + v * A := by positivity
  have htheta0 : 0 ≤ (j : ℝ) / alpha := div_nonneg hjR.le ha.le
  have htheta1 : (j : ℝ) / alpha ≤ 1 := (div_le_one ha).mpr hja
  have hpow := finite_power_sum_normalized p hp hk hj hja
  have hmono := div_le_div_of_nonneg_right hpow (sq_nonneg (E + v * A))
  have h := monomial_over_affine_margin_sq hE hv hA htheta0 (by linarith : (j : ℝ) / alpha ≤ 2)
  have hmul := mul_le_mul_of_nonneg_left h (Real.rpow_nonneg hk.le (1 - (j : ℝ)))
  apply hmono.trans
  convert hmul using 1 <;> ring

/-- The degree profile can grow logarithmically without defeating the root multiplier. -/
theorem logarithmic_degree_count_budget {alpha L A cL C cb D X : ℝ}
    (ha : 0 < alpha) (hL : 0 < L) (hA : 0 < A) (hC : 0 ≤ C)
    (hcb : 0 < cb) (hD : 0 < D) (hX : 1 ≤ X)
    (hdegree : L ≤ alpha * (A + cL * Real.log X))
    (hsmall : cL * (C + 1 / A) ≤ 1 / 2) :
    Real.exp (C * L) * (cb * L / (D * alpha * X)) ^ alpha ≤
      (cb * A * Real.exp (C * A) / D) ^ alpha * X ^ (-alpha / 2) := by
  have hX0 : 0 < X := zero_lt_one.trans_le hX
  have hs : 0 ≤ Real.log X := Real.log_nonneg hX
  have hrat : L / alpha ≤ A * Real.exp ((cL / A) * Real.log X) := by
    have h : L / alpha ≤ A + cL * Real.log X := (div_le_iff₀ ha).mpr (by
      simpa only [mul_comm] using hdegree)
    have he := mul_le_mul_of_nonneg_left (Real.add_one_le_exp ((cL / A) * Real.log X)) hA.le
    have hid : A * ((cL / A) * Real.log X + 1) = A + cL * Real.log X := by field_simp; ring
    rw [hid] at he
    exact h.trans he
  have hlog := Real.log_le_log (div_pos hL ha) hrat
  rw [Real.log_div hL.ne' ha.ne', Real.log_mul hA.ne' (Real.exp_ne_zero _), Real.log_exp] at hlog
  have hscale := mul_le_mul_of_nonneg_left hdegree hC
  have hlogscale := mul_le_mul_of_nonneg_left hlog ha.le
  have hsmall' := mul_le_mul_of_nonneg_left hsmall (mul_nonneg ha.le hs)
  have hratio : 0 < cb * L / (D * alpha * X) := by positivity
  have hbase : 0 < cb * A * Real.exp (C * A) / D := by positivity
  have hlogbudget : C * L + Real.log (cb * L / (D * alpha * X)) * alpha ≤
      Real.log (cb * A * Real.exp (C * A) / D) * alpha + Real.log X * (-alpha / 2) := by
    rw [Real.log_div (by positivity : cb * L ≠ 0) (by positivity : D * alpha * X ≠ 0),
      Real.log_mul hcb.ne' hL.ne',
      Real.log_mul (mul_ne_zero hD.ne' ha.ne') hX0.ne', Real.log_mul hD.ne' ha.ne',
      Real.log_div (by positivity : cb * A * Real.exp (C * A) ≠ 0) hD.ne',
      Real.log_mul (mul_ne_zero hcb.ne' hA.ne') (Real.exp_ne_zero _),
      Real.log_mul hcb.ne' hA.ne', Real.log_exp]
    have hid : alpha * Real.log X * (cL * (C + 1 / A)) =
        C * alpha * (cL * Real.log X) + alpha * ((cL / A) * Real.log X) := by ring
    rw [hid] at hsmall'
    nlinarith
  have h := Real.exp_le_exp.mpr hlogbudget
  rw [Real.exp_add, Real.exp_add, ← Real.rpow_def_of_pos hratio,
    ← Real.rpow_def_of_pos hbase, ← Real.rpow_def_of_pos hX0] at h
  exact h

/-- The calibration applies to the actual integer ceiling used by the estimator. -/
theorem actual_degree_count_budget {alpha CL cL C cb D X : ℝ}
    (ha : 1 < alpha) (hCL : 1 ≤ CL) (hcL : 0 < cL) (hC : 0 ≤ C)
    (hcb : 0 < cb) (hD : 0 < D) (hX : 1 ≤ X)
    (hsmall : cL * (C + 1 / (CL + 1)) ≤ 1 / 2) :
    Real.exp (C * (upperDegree alpha CL cL X : ℝ)) *
      (cb * (upperDegree alpha CL cL X : ℝ) / (D * alpha * X)) ^ alpha ≤
      (cb * (CL + 1) * Real.exp (C * (CL + 1)) / D) ^ alpha * X ^ (-alpha / 2) := by
  exact logarithmic_degree_count_budget (by linarith)
    (by exact_mod_cast upperDegree_pos ha hCL hcL hX) (by linarith) hC hcb hD hX
    (upperDegree_bounds ha hCL hcL hX).2 hsmall

/-- A single sample multiplier uniformly controls the actual degree budget at every root. -/
theorem actual_degree_count_budget_uniform {CL cL C cb eta : ℝ}
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hC : 0 ≤ C) (hcb : 0 < cb) (heta : 0 < eta)
    (hsmall : cL * (C + 1 / (CL + 1)) ≤ 1 / 2) :
    ∃ D0 : ℝ, 0 < D0 ∧ ∀ alpha D X : ℝ, 1 < alpha → D0 ≤ D → 1 ≤ X →
      Real.exp (C * (upperDegree alpha CL cL X : ℝ)) *
        (cb * (upperDegree alpha CL cL X : ℝ) / (D * alpha * X)) ^ alpha ≤ eta := by
  let F := cb * (CL + 1) * Real.exp (C * (CL + 1))
  let t := min 1 eta
  have hF : 0 < F := by dsimp [F]; positivity
  have ht : 0 < t := lt_min zero_lt_one heta
  refine ⟨F / t, div_pos hF ht, ?_⟩
  intro alpha D X ha hD hX
  have hDpos : 0 < D := (div_pos hF ht).trans_le hD
  have hbase : F / D ≤ t := by
    apply (div_le_iff₀ hDpos).mpr
    have h := (div_le_iff₀ ht).mp hD
    nlinarith
  have hbase1 : F / D ≤ 1 := hbase.trans (min_le_left _ _)
  have hbase0 : 0 ≤ F / D := (div_pos hF hDpos).le
  have hpower := Real.rpow_le_self_of_le_one hbase0 hbase1 ha.le
  have hXpow : X ^ (-alpha / 2) ≤ 1 :=
    Real.rpow_le_one_of_one_le_of_nonpos hX (by linarith)
  have hbudget := actual_degree_count_budget ha hCL hcL hC hcb hDpos hX hsmall
  change _ ≤ (F / D) ^ alpha * X ^ (-alpha / 2) at hbudget
  apply hbudget.trans
  calc
    _ ≤ (F / D) ^ alpha * 1 := mul_le_mul_of_nonneg_left hXpow (Real.rpow_nonneg hbase0 _)
    _ = (F / D) ^ alpha := mul_one _
    _ ≤ F / D := hpower
    _ ≤ t := hbase
    _ ≤ eta := min_le_right _ _

end Renyi
