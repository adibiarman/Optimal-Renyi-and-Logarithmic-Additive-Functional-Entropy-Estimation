import Renyi.CompletedLocalizationSum
import Renyi.UpperCompact

/-! Uniform D-last decay of the actual compact-width localization and correction. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 800000

lemma small_square_rpow_le {x tau beta : ℝ} (hx : 0≤x) (ht : 0<tau)
    (ht1 : tau≤1) (hxt : x≤tau^2) (hb : 1/2≤beta) : x^beta≤tau := by
  have hp := Real.rpow_le_rpow hx hxt (by linarith only [hb] : 0≤beta)
  rw [←Real.rpow_natCast_mul ht.le] at hp
  norm_num only [Nat.cast_ofNat] at hp
  have he := Real.rpow_le_rpow_of_exponent_ge ht ht1 (by linarith only [hb] : (1:ℝ)≤2*beta)
  rw [Real.rpow_one] at he
  exact hp.trans he

lemma small_linear_rpow_le {x tau beta : ℝ} (hx : 0≤x) (ht : 0<tau)
    (ht1 : tau≤1) (hxt : x≤tau) (hb : 1≤beta) : x^beta≤tau := by
  exact (Real.rpow_le_rpow hx hxt (by linarith only [hb])).trans
    (by simpa only [Real.rpow_one] using Real.rpow_le_rpow_of_exponent_ge ht ht1 hb)

lemma simplex_cutoff_power_comparisons {k : ℕ} (hk : 0<k) (p : Simplex k)
    {alpha a : ℝ} (ha : 1≤alpha) (ha0 : 0<a) :
    (k:ℝ)*a^alpha≤((k:ℝ)*a)^alpha*powerSum p alpha ∧
      a^(alpha-1)≤((k:ℝ)*a)^(alpha-1)*powerSum p alpha := by
  have hK : (0:ℝ)<k := by exact_mod_cast hk
  have hP := simplex_powerSum_uniform_lower hk p ha
  constructor
  · have hh := mul_le_mul_of_nonneg_left hP (Real.rpow_nonneg (by positivity : 0≤(k:ℝ)*a) alpha)
    have hid : ((k:ℝ)*a)^alpha*(k:ℝ)^(1-alpha)=(k:ℝ)*a^alpha := by
      rw [Real.mul_rpow hK.le ha0.le]
      calc
        _ = ((k:ℝ)^alpha*(k:ℝ)^(1-alpha))*a^alpha := by ring
        _ = _ := by rw [←Real.rpow_add hK];simp
    rwa [hid] at hh
  · have hh := mul_le_mul_of_nonneg_left hP (Real.rpow_nonneg (by positivity : 0≤(k:ℝ)*a) (alpha-1))
    have hid : ((k:ℝ)*a)^(alpha-1)*(k:ℝ)^(1-alpha)=a^(alpha-1) := by
      rw [Real.mul_rpow hK.le ha0.le]
      calc
        _ = ((k:ℝ)^(alpha-1)*(k:ℝ)^(1-alpha))*a^(alpha-1) := by ring
        _ = _ := by rw [←Real.rpow_add hK];simp
    rwa [hid] at hh

/-- Actual localization, below-cutoff loss, and deterministic correction all
vanish at a common rate once k*a≤tau² and k*t≤tau. -/
theorem compact_localization_bias_budget {k m : ℕ} (hk : 0<k) (p : Simplex k)
    {alpha a t tau H C0 d : ℝ} (ha : 3/2≤alpha) (ha0 : 0<a) (ht : 0≤t)
    (htau : 0<tau) (htau1 : tau≤1) (hka : (k:ℝ)*a≤tau^2)
    (hkt : (k:ℝ)*t≤tau) (hm : (m:ℝ)+1≤H) (hC0 : 1≤C0) (hd : 0≤d) :
    (k:ℝ)*(100:ℝ)^(m+1)*a^alpha+
      2*completedLocalizationConstant*((k:ℝ)*t)^(min alpha 2)*powerSum p alpha+
      2*(min (alpha-1) 1*d*C0^m*a^(alpha-1))≤
      ((100:ℝ)^H+2*completedLocalizationConstant+2*d*C0^(H-1))*tau*powerSum p alpha := by
  have hK : (0:ℝ)<k := by exact_mod_cast hk
  have hP := simplex_powerSum_pos p alpha
  have hcmp := simplex_cutoff_power_comparisons hk p (by linarith only [ha]) ha0
  have hpowA := small_square_rpow_le (mul_nonneg hK.le ha0.le) htau htau1 hka
    (by linarith only [ha] : 1/2≤alpha)
  have hpowB := small_square_rpow_le (mul_nonneg hK.le ha0.le) htau htau1 hka
    (by linarith only [ha] : 1/2≤alpha-1)
  have hpowT := small_linear_rpow_le (mul_nonneg hK.le ht) htau htau1 hkt
    (le_min (by linarith only [ha]) (by norm_num) : 1≤min alpha 2)
  have hC1 : (100:ℝ)^(m+1)≤(100:ℝ)^H := by
    rw [←Real.rpow_natCast]
    apply Real.rpow_le_rpow_of_exponent_le (by norm_num)
    exact_mod_cast hm
  have hC2 : C0^m≤C0^(H-1) := by
    rw [←Real.rpow_natCast]
    exact Real.rpow_le_rpow_of_exponent_le hC0 (by linarith only [hm])
  have hpa : (k:ℝ)*a^alpha≤tau*powerSum p alpha :=
    hcmp.1.trans (mul_le_mul_of_nonneg_right hpowA hP.le)
  have hpb : a^(alpha-1)≤tau*powerSum p alpha :=
    hcmp.2.trans (mul_le_mul_of_nonneg_right hpowB hP.le)
  have hsmall := mul_le_mul hC1 hpa (by positivity : 0≤(k:ℝ)*a^alpha)
    (Real.rpow_nonneg (by norm_num) H)
  have hlocal := mul_le_mul_of_nonneg_left
    (mul_le_mul_of_nonneg_right hpowT hP.le) (mul_nonneg (by norm_num : (0:ℝ)≤2) completedLocalizationConstant_pos.le)
  have hcoef0 : 0≤min (alpha-1) 1*d := mul_nonneg (le_min (by linarith only [ha]) (by norm_num)) hd
  have hcoef : min (alpha-1) 1*d≤d := mul_le_of_le_one_left hd (min_le_right _ _)
  have hcor0 : 0≤C0^m*a^(alpha-1) := by positivity
  have hcor := mul_le_mul hC2 hpb (Real.rpow_nonneg ha0.le _) (Real.rpow_nonneg (by linarith only [hC0]) _)
  have hcor1 := mul_le_mul hcoef hcor hcor0 hd
  nlinarith only [hsmall,hlocal,hcor1]

/-- Source-root cutoffs become simultaneously small uniformly throughout the
bounded-width branch, with D chosen only after all fixed constants. -/
theorem upper_compact_small_scales {eps M Ch cb lambda CL cL u0 q tau : ℝ}
    (heps : 0<eps) (hM : 0<M) (hCh : 0≤Ch) (hcb : 0<cb) (hlambda : 0<lambda)
    (hCL : 1≤CL) (hcL : 0<cL) (hu0 : 0<u0) (hq : 0<q) (htau : 0<tau) :
    ∃ D0 : ℝ, 0<D0 ∧ ∀ (k : ℕ) (alpha D N : ℝ),
      0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → D0≤D →
      2*eps*(alpha-1)/(fractionalPart alpha*(1-fractionalPart alpha))≤M →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (k:ℝ)*upperA k alpha eps Ch D cb lambda CL cL≤tau^2 ∧
      (k:ℝ)*(upperB k alpha eps D cb CL cL/N^2)≤tau := by
  obtain ⟨rminus,R,_,hR,hcut⟩ := upper_actual_cutoff heps hCh hcb hlambda hCL hcL
  obtain ⟨cq,C,cu,_,hC,_,hcompact⟩ := upper_bounded_width_uniform heps hM hcb.le hCL hcL hu0 hq
  refine ⟨max 1 (max (R/tau^2) (C/tau)),lt_of_lt_of_le zero_lt_one (le_max_left _ _),?_⟩
  intro k alpha D N hk ha hg hg1 hD0 hwidth hN
  have hD : 0<D := lt_of_lt_of_le zero_lt_one ((le_max_left _ _).trans hD0)
  have ha1 : 1<alpha := by linarith only [ha]
  have hka := upper_cutoff_scaled_upper hk ha1 hg hg1 hR hD (hcut k alpha D hk ha1 hg hg1 hD).2
  have hkt := (hcompact k alpha D N hk ha hg hg1 hD hwidth hN).2.2.2.1
  have hDA : R/tau^2≤D := (le_max_left _ _).trans ((le_max_right _ _).trans hD0)
  have hDT : C/tau≤D := (le_max_right _ _).trans ((le_max_right _ _).trans hD0)
  refine ⟨hka.trans ?_,hkt.trans ?_⟩
  · apply (div_le_iff₀ hD).mpr
    have hh := (div_le_iff₀ (sq_pos_of_pos htau)).mp hDA
    nlinarith only [hh]
  · apply (div_le_iff₀ hD).mpr
    have hh := (div_le_iff₀ htau).mp hDT
    nlinarith only [hh]

end Renyi
