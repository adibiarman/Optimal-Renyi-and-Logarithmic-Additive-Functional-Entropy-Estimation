import Renyi.GeneralNonintegerIIDComplete
import Renyi.FinalAssembly

/-! The complete uniform iid minimax theorem, including min-entropy. -/
noncomputable section
namespace Renyi

/-- The remaining real noninteger orders have the public iid rate, uniformly
in the order and the alphabet size. -/
theorem remaining_noninteger_iid_upper_verified : RemainingNonintegerUpperClaim := by
  intro eps heps _heps1
  obtain ⟨C,hC,K,_hK,hupper⟩ := general_noninteger_iid_rate_upper_uniform heps
  refine ⟨C,hC,K,?_⟩
  intro k hk _hlog alpha ha horder hnotint
  exact hupper k hk alpha ha.le hnotint horder

/-- Matching iid minimax bounds for every real order greater than one, with
accuracy-dependent constants uniform in the order and alphabet, together with
the matching min-entropy endpoint. -/
theorem iid_renyi_full_verified : FullManuscriptClaim :=
  full_minimax_of_remaining_upper remaining_noninteger_iid_upper_verified

/-- The finite-order part of the complete iid minimax theorem. -/
theorem iid_renyi_uniform_minimax_verified : UniformMinimaxClaim :=
  iid_renyi_full_verified.1

end Renyi
