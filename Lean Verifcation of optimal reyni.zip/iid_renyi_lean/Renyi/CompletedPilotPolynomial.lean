import Renyi.UpperPilotPolynomialSum
import Renyi.CompletedPolynomialRange
import Renyi.CompletedGlobalCoefficients
import Renyi.CompletedBelowCutoff

/-! Pilot boundary control for the actual completed and rescaled source polynomial. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Polynomial
namespace Renyi
set_option maxHeartbeats 800000

variable {ι Ω : Type*} [Fintype ι] [MeasurableSpace Ω] {μ : Measure Ω}

theorem completed_polynomial_pilot_boundary {ell N m : ℕ}
    (hell : 0<ell) (hN : 0<N) (hm : 1≤m) (hdegree : 4*(ell-1)≤m)
    {gamma a b fL f A B omega sigma n L cp Bpilot cb cstar : ℝ}
    (hg : 0<gamma) (hg1 : gamma<1) (ha : 0<a) (hab : a≤b)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hA : 0≤A) (hA1 : A≤1) (hB : 0≤B) (hB1 : B≤1)
    (hw : 0≤omega) (hw1 : omega<1) (hs : 0≤sigma) (hs1 : sigma≤1)
    (hn : 0<n) (halpha : 3/2≤(m:ℝ)+gamma) (hL : 1≤L)
    (hellL : (ell:ℝ)≤L) (hNL : (N:ℝ)≤L) (hmL : (m:ℝ)+gamma≤L)
    (hcp0 : 1≤cp) (hBp : 16≤Bpilot) (hcs : 0≤cstar)
    (hnb : n*b=cb*L) (hcut : 2*Bpilot*((m:ℝ)+gamma)≤n*b) (hLn : 1≤L*(n*b))
    (hcp : 8*(coupledCoefficientExponentialConstant+20+cstar)≤cp*cb)
    (p : ι→ℝ) (hp : ∀i,0≤p i) (Y : ι→Ω→ℕ)
    (hY : ∀i,MeasurePreserving (Y i) μ
      (poissonMeasure ⟨cp*n*p i,mul_nonneg (mul_nonneg (by linarith only [hcp0]) hn.le) (hp i)⟩)) :
    let Q0 := completedCoupledPolynomial ell N m gamma a b
      (DegreeOneCompletion.coefficient gamma fL) fL f A B omega
    let Q : ι→ℝ := fun i => sigma*Q0.eval (p i)
    Integrable (pilotPolynomialBoundary p Q Y n b ((m:ℝ)+gamma) cp Bpilot (sigma*omega)) μ ∧
      (∫w,pilotPolynomialBoundary p Q Y n b ((m:ℝ)+gamma) cp Bpilot (sigma*omega) w ∂μ)≤
        (Fintype.card ι:ℝ)*((100:ℝ)^(m+1)*a^((m:ℝ)+gamma))+
        (2*Real.exp (-cstar*L)+3*Real.exp (-cp*((m:ℝ)+gamma)))*conditionalCountBonus p ((m:ℝ)+gamma) n L := by
  let alpha := (m:ℝ)+gamma
  let Q0 := completedCoupledPolynomial ell N m gamma a b
    (DegreeOneCompletion.coefficient gamma fL) fL f A B omega
  let P := C (sigma/b^alpha)*(Q0.comp (C b*X))
  have hb : 0<b := ha.trans_le hab
  have hbPow : 0<b^alpha := Real.rpow_pos_of_pos hb _
  have hc := (DegreeOneCompletion.coefficient_spec hg hfL1).1
  have hmass := completedCoupledPolynomial_scaled_mass_exponential hell hN hm hdegree hg hg1 ha.le hab hb hc
    hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1 hL hellL hNL
  change coefficientMass (Q0.comp (C b*X))≤b^alpha*Real.exp (coupledCoefficientExponentialConstant*L) at hmass
  have hPmass : coefficientMass P≤Real.exp (coupledCoefficientExponentialConstant*L) := by
    dsimp [P]
    rw [coefficientMass_C_mul,abs_of_nonneg (div_nonneg hs hbPow.le)]
    have hh := mul_le_mul_of_nonneg_left hmass (div_nonneg hs hbPow.le)
    have hid : (sigma/b^alpha)*(b^alpha*Real.exp (coupledCoefficientExponentialConstant*L))=
        sigma*Real.exp (coupledCoefficientExponentialConstant*L) := by field_simp
    rw [hid] at hh
    exact hh.trans (mul_le_of_le_one_left (Real.exp_pos _).le hs1)
  have hPdeg : (P.natDegree:ℝ)≤20*L := by
    have hcdeg : (Q0.comp (C b*X)).natDegree≤Q0.natDegree := by
      have hh := natDegree_comp_le (p:=Q0) (q:=C b*X)
      simpa only [natDegree_C_mul_X b hb.ne',mul_one] using hh
    have hh := (natDegree_C_mul_le (sigma/b^alpha) (Q0.comp (C b*X))).trans
      (hcdeg.trans (completedCoupledPolynomial_natDegree hm ell N gamma a b
        (DegreeOneCompletion.coefficient gamma fL) fL f A B omega))
    have hhR : (P.natDegree:ℝ)≤(m:ℝ)+1+18*((N-1:ℕ):ℝ) := by exact_mod_cast hh
    have hNsub : ((N-1:ℕ):ℝ)≤(N:ℝ) := by exact_mod_cast (Nat.sub_le N 1)
    nlinarith only [hhR,hNsub,hNL,hmL,hg,hL]
  have hrepr (i:ι) : sigma*Q0.eval (p i)=b^alpha*P.eval (p i/b) := by
    dsimp [P]
    simp only [eval_mul,eval_C,eval_comp,eval_X]
    rw [show b*(p i/b)=p i by field_simp]
    field_simp
  have hsmall (i:ι) (hpi : p i<a) : |sigma*Q0.eval (p i)|≤(100:ℝ)^(m+1)*a^alpha := by
    have hh := completedCoupledPolynomial_below_cutoff_exponential hell hN hm hdegree hg hg1 ha hab
      (hp i) hpi.le hc hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1
    change |Q0.eval (p i)|+p i^alpha≤(100:ℝ)^(m+1)*a^alpha at hh
    rw [abs_mul,abs_of_nonneg hs]
    have hnon := Real.rpow_nonneg (hp i) alpha
    exact (mul_le_of_le_one_left (abs_nonneg _) hs1).trans (by linarith only [hh,hnon])
  have hgood (i:ι) (hapi : a≤p i) (hpib : p i≤b) : |sigma*Q0.eval (p i)|≤3*p i^alpha := by
    have hh := completedCoupledPolynomial_absolute_envelope hell hN hm hdegree hg hg1 ha hapi hpib
      hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1
    rw [abs_mul,abs_of_nonneg hs]
    exact (mul_le_of_le_one_left (abs_nonneg _) hs1).trans hh
  have hsomega : 0≤sigma*omega := mul_nonneg hs hw
  have hsomega1 : sigma*omega≤1 := mul_le_one₀ hs1 hw hw1.le
  exact pilot_polynomial_boundary_bound hn hb ha halpha hL coupledCoefficientExponentialConstant_pos.le
    (by norm_num : (0:ℝ)≤20) hcs hcp0 hBp hnb hcut hLn hPdeg hPmass hcp hsomega hsomega1
    (by positivity) p (fun i => sigma*Q0.eval (p i)) hp hrepr hsmall hgood Y hY

end Renyi
