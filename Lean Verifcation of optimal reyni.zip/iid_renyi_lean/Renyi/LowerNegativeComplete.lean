import Renyi.LowerNegativeCountFinal
import Renyi.LowerPositiveDegreeTransfer

/-! Complete actual-prior iid lower bound in the negative-active orientation. -/
noncomputable section
open scoped BigOperators NNReal
namespace Renyi
set_option maxHeartbeats 2000000

/-- Actual negative-active root priors imply iid impossibility, with all
count, normalization, support, and availability bounds proved internally. -/
theorem lower_negative_nonachievable {eps : ℝ} (he : 0<eps) (he1 : eps≤1/2) :
    ∃ k₀ : ℕ, ∃ X₀ : ℝ, lowerPriorRootCutoff eps≤X₀ ∧ ∀ k : ℕ, k₀≤k →
      ∀ (m : ℕ) (s : ℝ), 1≤m → 0<s → s≤1/2 →
      X₀≤rootMultiplier k ((m:ℝ)+(1-s)) eps →
      ∀ n : ℕ, (n:ℝ)≤(lowerPriorIntensityConstant eps*((m:ℝ)+(1-s))*(k:ℝ)^(-1/((m:ℝ)+(1-s)))*
        rootMultiplier k ((m:ℝ)+(1-s)) eps)*(k:ℝ)/8 → ¬Achievable k n ((m:ℝ)+(1-s)) eps := by
  obtain ⟨K,X,hX,hTransfer⟩ := lower_positive_degree_prior_transfer he
  refine ⟨max 1 K,X,hX,?_⟩
  intro k hk m s hm hs hs1 hx n hn
  have hk1 : 1≤k := (le_max_left _ _).trans hk
  have hk0 : 0<k := by omega
  have hkR : (0:ℝ)<k := by exact_mod_cast hk0
  let alpha := (m:ℝ)+(1-s)
  let x := rootMultiplier k alpha eps
  let L := Nat.ceil (10*alpha*(1+Real.log x))
  let c := lowerPriorCoefficient eps
  let E := 2*eps*(alpha-1)
  let v := (alpha-1)/alpha*x^(-alpha)
  let w := s*(1-s)+v
  let zeta := c*w/(1-Real.exp (-E))
  let kappa := Real.exp (-E-4*w)
  let ds : ℝ := ((L-m:ℕ):ℝ)+1
  let dc : ℝ := ((m-1:ℕ):ℝ)+1
  let bs := (zeta/8)/ds^2
  let ac := Real.exp (-5)*((1-s)/dc^2)*(zeta*kappa)^(1/(1-s))
  let theta := lowerPriorIntensityConstant eps*alpha*(k:ℝ)^(-1/alpha)*x
  let a := theta/((1/100)*(L:ℝ)*ac)
  have hmR : (1:ℝ)≤m := by exact_mod_cast hm
  have ha : 3/2≤alpha := by dsimp [alpha]; linarith
  have ha1 : 1<alpha := by linarith
  have ha0 : 0<alpha := by linarith
  have hb0 : 0<alpha-1 := by linarith
  have hsource : lowerPriorRootCutoff eps≤x := hX.trans hx
  have hx4 : 4≤x := (le_max_left _ _).trans hsource
  have hx0 : 0<x := by linarith
  have hL : (0:ℝ)<L := (show 0<10*alpha*(1+Real.log x) by have hh := Real.log_nonneg (by linarith : 1≤x); positivity).trans_le (Nat.le_ceil _)
  have htheta : 0<theta := by dsimp [theta,lowerPriorIntensityConstant]; positivity
  have hE : 0<E := by dsimp [E]; positivity
  have hv : 0≤v := by dsimp [v]; positivity
  have hw : 0<w := by dsimp [w]; exact add_pos_of_pos_of_nonneg (mul_pos hs (by linarith)) hv
  have hzeta : 0<zeta := by
    dsimp [zeta]
    exact div_pos (mul_pos (lowerPriorCoefficient_bounds he).1 hw)
      (sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith)))
  have hxi : 0<1-s := by linarith only [hs1]
  have hdc : 0<dc := by dsimp [dc]; positivity
  have hac : 0<ac := by dsimp [ac,kappa]; positivity
  have hB : (ac*a)⁻¹=(1/100)*(L:ℝ)/theta := by dsimp [a]; field_simp
  have hmul : 4*zeta*((ds-1)/ds)=4*zeta*((L-m:ℕ):ℝ)/(((L-m:ℕ):ℝ)+1) := by dsimp [ds]; ring
  have hpriors := lower_actual_negative_small_count_priors hk0 hm hs hs1 he he1 hsource
  dsimp only [lowerNegativeSmallCountConclusion] at hpriors
  rw [←hmul] at hpriors
  obtain ⟨_,_,P₀,P₁,hsupp₀,hsupp₁,hmean₀,hmean₁,_,_,_,_,hmom₀,hmom₁,_,_,_,hgap,_,_,hD⟩ := hpriors
  have hsecond := lower_actual_negative_second_moments P₀ P₁ hk0 hm hs hs1 he hsource hmom₀ hmom₁
  change (priorMoment P₀ (2*alpha)/(priorMoment P₀ alpha)^2≤lowerPriorSecondConstant eps*zeta^2*((ac*a)⁻¹)^alpha) ∧
    (priorMoment P₁ (2*alpha)/(priorMoment P₁ alpha)^2≤lowerPriorSecondConstant eps*zeta^2*((ac*a)⁻¹)^alpha) at hsecond
  change ∀ i,P₀.value i=0 ∨ (1≤P₀.value i ∧ P₀.value i≤(ac*a)⁻¹) at hsupp₀
  change ∀ i,P₁.value i=0 ∨ (1≤P₁.value i ∧ P₁.value i≤(ac*a)⁻¹) at hsupp₁
  rw [hB] at hsupp₀ hsupp₁ hsecond
  exact hTransfer k ((le_max_right _ _).trans hk) alpha s ha hs hs1
    (Or.inr (by rw [show fractionalPart alpha=1-s from fractionalPart_nat_add_small m (by linarith) (by linarith)]; ring)) hx _ _ P₀ P₁ hsupp₀ hsupp₁ hmean₀ hmean₁ hgap hsecond.1 hsecond.2 hD n hn

/-- The negative-active branch has the actual root sample lower scale. -/
theorem lower_negative_sample_lower {eps : ℝ} (he : 0<eps) (he1 : eps≤1/2) :
    ∃ c : ℝ, 0<c ∧ ∃ k₀ : ℕ, ∃ X₀ : ℝ, lowerPriorRootCutoff eps≤X₀ ∧ ∀ k : ℕ, k₀≤k →
      ∀ (m : ℕ) (s : ℝ), 1≤m → 0<s → s≤1/2 → X₀≤rootMultiplier k ((m:ℝ)+(1-s)) eps →
      ∀ n : ℕ, Achievable k n ((m:ℝ)+(1-s)) eps →
      c*((m:ℝ)+(1-s))*(k:ℝ)^(1-1/((m:ℝ)+(1-s)))*rootMultiplier k ((m:ℝ)+(1-s)) eps≤n := by
  obtain ⟨K,X,hX,hLower⟩ := lower_negative_nonachievable he he1
  let c := lowerPriorIntensityConstant eps/8
  have hc : 0<c := by dsimp [c,lowerPriorIntensityConstant]; positivity
  refine ⟨c,hc,max 1 K,X,hX,?_⟩
  intro k hk m s hm hs hs1 hx n hach
  have hk1 : 1≤k := (le_max_left _ _).trans hk
  have hkR : (0:ℝ)<k := by exact_mod_cast (show 0<k by omega)
  let alpha := (m:ℝ)+(1-s)
  have hid : (k:ℝ)^(-1/alpha)*(k:ℝ)=(k:ℝ)^(1-1/alpha) := by
    calc
      _=(k:ℝ)^(-1/alpha)*(k:ℝ)^(1:ℝ) := by rw [Real.rpow_one]
      _=_ := by rw [←Real.rpow_add hkR]; congr 1; ring
  have hscale : (lowerPriorIntensityConstant eps*alpha*(k:ℝ)^(-1/alpha)*rootMultiplier k alpha eps)*(k:ℝ)/8=
      c*alpha*(k:ℝ)^(1-1/alpha)*rootMultiplier k alpha eps := by rw [←hid]; dsimp [c]; ring
  by_contra hsmall
  have hn : (n:ℝ)≤(lowerPriorIntensityConstant eps*alpha*(k:ℝ)^(-1/alpha)*rootMultiplier k alpha eps)*(k:ℝ)/8 := by
    rw [hscale]
    exact (lt_of_not_ge hsmall).le
  exact hLower k ((le_max_right _ _).trans hk) m s hm hs hs1 hx n hn hach

end Renyi
