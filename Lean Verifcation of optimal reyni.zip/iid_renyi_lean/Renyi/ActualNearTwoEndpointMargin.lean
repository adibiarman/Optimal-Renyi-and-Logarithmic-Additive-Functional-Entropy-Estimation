import Renyi.NearTwoEndpointCalibration

/-! The near-two summed margin for the actual regularized-root cutoffs. -/
noncomputable section
open scoped BigOperators
namespace Renyi

lemma upperOrderFloor_eq_one_near_two {alpha : ℝ} (ha : 1 < alpha) (ha2 : alpha < 2) :
    upperOrderFloor alpha = 1 := by
  have hlo := upperOrderFloor_one_le ha
  have hhi : upperOrderFloor alpha < 2 :=
    (Nat.floor_lt (by linarith : 0 ≤ alpha)).mpr (by exact_mod_cast ha2)
  omega

/-- There is one sample multiplier after which the actual near-two endpoint margin
pays a fixed positive multiple of the common cutoff power, for every simplex. -/
theorem upper_actual_endpoint_margin_near_two {eps Ch cb lambda CL cL : ℝ}
    (heps : 0 < eps) (hCh : 0 ≤ Ch) (hcb : 0 < cb) (hlambda : 0 < lambda)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) :
    ∃ D0 : ℝ, 1 ≤ D0 ∧ ∀ (k : ℕ) (alpha D : ℝ),
      0 < k → 3 / 2 ≤ alpha → alpha < 2 → D0 ≤ D → ∀ (p : Simplex k),
      let a := upperA k alpha eps Ch D cb lambda CL cL
      let b := upperB k alpha eps D cb CL cL
      let N := upperDegree alpha CL cL (rootMultiplier k alpha eps)
      nearTwoEndpointConstant eps lambda / 2 * a ^ (alpha - 1) ≤
        ∑ i, if a ≤ p.mass i then p.mass i ^ alpha *
          min (a / p.mass i + ((N : ℝ) ^ 2 / b) * p.mass i) 1 else 0 := by
  obtain ⟨D0, hD0, hsmall⟩ := upper_cutoff_eventually_small heps hCh hcb hlambda hCL hcL
    (by norm_num : (0 : ℝ) < 1 / 2)
  refine ⟨D0, hD0, ?_⟩
  intro k alpha D hk halpha halpha2 hD p
  dsimp only
  have ha1 : 1 < alpha := by linarith
  have hm := upperOrderFloor_eq_one_near_two ha1 halpha2
  have hgamma : fractionalPart alpha = alpha - 1 := by
    rw [fractionalPart_eq_upperOrderFloor ha1, hm]
    norm_num
  have hg : 0 < fractionalPart alpha := by rw [hgamma]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [hgamma]; linarith
  have hDpos : 0 < D := zero_lt_one.trans_le (hD0.trans hD)
  have hb := upperB_pos hk ha1 hg hg1 hDpos hcb hCL hcL (ε := eps)
  have hN := upperDegree_pos ha1 hCL hcL (one_le_rootMultiplier ha1 hg hg1 (k := k) (ε := eps))
  have hNpos : (0 : ℝ) < upperDegree alpha CL cL (rootMultiplier k alpha eps) := by exact_mod_cast hN
  have hcap := (upper_convolution hk ha1 hg hg1 heps hCh hDpos hcb hlambda hCL hcL).1
  rw [hm, hgamma] at hcap
  norm_num only [Nat.cast_one, one_pow, mul_one] at hcap
  let z := upperOverlapZ (alpha - 1) (upperE0 k alpha eps Ch)
  have hE := upper_reserved_interval (k := k) ha1 hg hg1 heps hCh
  have hEpos : 0 < upperE0 k alpha eps Ch := (mul_pos heps (by linarith : 0 < alpha - 1)).trans_le hE.1
  have hzspec := upperOverlapZ_spec (by linarith : 0 < alpha - 1) (by linarith : alpha - 1 < 1) hEpos
  have hz : 0 < z := hzspec.1.1
  have hz1 : z < 1 := hzspec.1.2
  have hzc := overlapG_coarse_parameter_lower (by linarith : 0 < alpha - 1)
    (by linarith : alpha - 1 < 1) hz hz1
  rw [hzspec.2] at hzc
  have hzlo : Real.exp (-(2 * eps + 2)) ≤ z := by
    have hupper : upperE0 k alpha eps Ch ≤ 2 * eps := by nlinarith only [hE.2, heps, halpha2]
    have hh := Real.exp_le_exp.mpr (show -(2 * eps + 2) ≤ -upperE0 k alpha eps Ch + -2 by linarith)
    rw [Real.exp_add] at hh
    exact hh.trans hzc
  have ha : 0 < upperA k alpha eps Ch D cb lambda CL cL := by
    have hbeta : 0 < alpha - 1 := by linarith
    have hdelta : 0 < 1 - (alpha - 1) := by linarith
    have hright : 0 < lambda * ((alpha - 1) * (1 - (alpha - 1))) *
        z ^ (1 / ((alpha - 1) * (1 - (alpha - 1)))) := by positivity
    have hleft : 0 < upperA k alpha eps Ch D cb lambda CL cL *
        (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ^ 2 /
          upperB k alpha eps D cb CL cL := by rw [hcap]; exact hright
    exact (mul_pos_iff_of_pos_right (by positivity : (0 : ℝ) <
      (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ^ 2)).mp
      ((div_pos_iff_of_pos_right hb).mp hleft)
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hcut : upperA k alpha eps Ch D cb lambda CL cL ≤ (1 : ℝ) / (2 * k) := by
    have hh := hsmall k alpha D hk ha1 hg hg1 hD
    apply hh.trans
    apply (le_div_iff₀ (by positivity : (0 : ℝ) < 2 * k)).mpr
    have hratio : (alpha - 1) / alpha ≤ 1 := (div_le_one (by linarith : 0 < alpha)).mpr (by linarith)
    convert hratio using 1
    field_simp
  have hcapacity : lambda * ((alpha - 1) * (1 - (alpha - 1))) *
      z ^ (1 / ((alpha - 1) * (1 - (alpha - 1)))) ≤
      upperA k alpha eps Ch D cb lambda CL cL *
        ((upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ^ 2 / upperB k alpha eps D cb CL cL) := by
    rw [← hcap]
    exact le_of_eq (by ring)
  have hsum := simplex_truncated_endpoint_margin_near_two hk p
    (by linarith : (1 : ℝ) / 2 ≤ alpha - 1) (by linarith : alpha - 1 < 1)
    heps.le ha (by positivity) hlambda hz hz1.le hzlo hcapacity hcut
  simpa only [show 1 + (alpha - 1) = alpha by ring] using hsum

end Renyi
