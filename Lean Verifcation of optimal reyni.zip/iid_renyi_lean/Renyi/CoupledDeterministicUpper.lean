import Renyi.CoupledGlobalUpper
import Renyi.CoupledPolynomial

/-! Actual polynomial form of the uniform deterministic strict upper certificate. -/
noncomputable section
namespace Renyi

/-- Source capacity in the original p coordinate implies the scaled reciprocal capacity. -/
lemma coupled_capacity_scaled {ℓ N m L : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    (hℓm : ℓ≤m) (hNL : N≤L) {γ a b p z : ℝ}
    (_hγ : 0<γ) (_hγ1 : γ<1) (ha : 0<a) (hap : a≤p) (hpb : p≤b)
    (hcapacity : a≤Real.exp (-2*coupledProfileConstant)*b*(γ*(1-γ))*z^(1/(γ*(1-γ))) /
      ((m:ℝ)^2*(L:ℝ)^2)) :
    ((ℓ:ℝ)^2*(a/p))*((N:ℝ)^2*(p/b))≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) := by
  have hp := ha.trans_le hap
  have hb := hp.trans_le hpb
  have hm : 0<(m:ℝ) := by exact_mod_cast hℓ.trans_le hℓm
  have hL : 0<(L:ℝ) := by exact_mod_cast hN.trans_le hNL
  have hcap := (le_div_iff₀ (mul_pos (sq_pos_of_pos hm) (sq_pos_of_pos hL))).mp hcapacity
  have hℓsq : (ℓ:ℝ)^2≤(m:ℝ)^2 := pow_le_pow_left₀ (Nat.cast_nonneg ℓ) (by exact_mod_cast hℓm) 2
  have hNsq : (N:ℝ)^2≤(L:ℝ)^2 := pow_le_pow_left₀ (Nat.cast_nonneg N) (by exact_mod_cast hNL) 2
  have hdeg := mul_le_mul hℓsq hNsq (sq_nonneg (N:ℝ)) (sq_nonneg (m:ℝ))
  calc
    _ = ((ℓ:ℝ)^2*(N:ℝ)^2)*(a/b) := by field_simp
    _ ≤ ((m:ℝ)^2*(L:ℝ)^2)*(a/b) := mul_le_mul_of_nonneg_right hdeg (div_nonneg ha.le hb.le)
    _ ≤ _ := by
      rw [←mul_div_assoc]
      apply (div_le_iff₀ hb).mpr
      nlinarith only [hcap]

/-- Strict upper bound for the actual polynomial, with the source capacity rather than profile premises. -/
theorem coupledQPolynomial_deterministic_upper {fL f E : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1) (hE : 0<E) :
    ∃ M c : ℝ, 1≤M ∧ 0<c ∧
      ∀ (ℓ N m L : ℕ) (γ z ω a b p : ℝ), 2≤ℓ → 2≤N → ℓ≤m → N≤L →
        4*(ℓ-1)≤m → 0<γ → γ<1 → 0<z → z≤Real.exp (-E) → 0≤ω → ω≤Real.exp (-E/8) →
        0<a → a≤p → p≤b →
        a≤Real.exp (-2*coupledProfileConstant)*b*(γ*(1-γ))*z^(1/(γ*(1-γ))) /
          ((m:ℝ)^2*(L:ℝ)^2) →
        (coupledQPolynomial ℓ N m γ a b fL f
          (overlapA γ z*Real.exp (-M*γ))
          (overlapB γ z*Real.exp (-M*(1-γ))) ω).eval p / p^((m:ℝ)+γ) ≤
          1-c*min (γ*(1-γ)+(N:ℝ)^2*(p/b)+min ((ℓ:ℝ)^2*(a/p)) 1) 1 := by
  obtain ⟨M,c,hM,hc,hupper⟩ := coupledProfiles_global_strict_upper hfL hfL1 hf hf1 hE
  refine ⟨M,c,hM,hc,?_⟩
  intro ℓ N m L γ z ω a b p hℓ hN hℓm hNL hdegree hγ hγ1 hz hzE hω hωE ha hap hpb hcapacity
  have hp := ha.trans_le hap
  have hb := hp.trans_le hpb
  have hcap := coupled_capacity_scaled (by omega : 0<ℓ) (by omega : 0<N) hℓm hNL hγ hγ1 ha hap hpb hcapacity
  have hbound := hupper ℓ N γ z ω (a/p) (p/b) hℓ hN hγ hγ1 hz hzE hω hωE
    (div_nonneg ha.le hp.le) ((div_le_one hp).mpr hap)
    (div_nonneg hp.le hb.le) ((div_le_one hb).mpr hpb) hcap
  rw [coupledQPolynomial_eval (by omega : 0<ℓ) (by omega : 0<N) hdegree hγ hγ1 ha hap hpb]
  unfold coupledQExpression
  rw [mul_div_cancel_left₀ _ (Real.rpow_pos_of_pos hp ((m:ℝ)+γ)).ne']
  exact hbound

end Renyi
