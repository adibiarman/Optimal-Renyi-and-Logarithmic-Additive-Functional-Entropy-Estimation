import Renyi.PoissonPilotModel
import Renyi.PoissonThinning

/-! Exact Poisson pilot histograms from independent labels on actual iid data. -/
noncomputable section
open scoped BigOperators ENNReal NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

section Categorical
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

def finiteCategoricalPMF (p : ι→ℝ≥0) (hp : ∑i,p i=1) : PMF ι :=
  PMF.ofFintype (fun i => (p i:ℝ≥0∞)) (by
    change (∑ i,(p i:ℝ≥0∞))=1
    exact_mod_cast hp)

@[simp] theorem finiteCategoricalPMF_apply (p : ι→ℝ≥0) (hp : ∑i,p i=1) (i:ι) :
    finiteCategoricalPMF p hp i=(p i:ℝ≥0∞) := rfl

@[simp] theorem finiteCategoricalPMF_toNNReal (p : ι→ℝ≥0) (hp : ∑i,p i=1) (i:ι) :
    (finiteCategoricalPMF p hp i).toNNReal=p i := by simp

variable [MeasurableSpace ι] [MeasurableSingletonClass ι]

@[simp] theorem iidCountablePMF_categorical (p : ι→ℝ≥0) (hp : ∑i,p i=1) (n:ℕ) :
    iidCountablePMF (finiteCategoricalPMF p hp) n=iidMarkPMF p hp n := by
  rw [iidCountablePMF_eq_finite]
  simp only [finiteCategoricalPMF_toNNReal]

end Categorical

/-- A sample record receives independent pilot labels with these exact probabilities. -/
def pilotFlagWeights (cp:ℝ≥0) (b:Bool) : ℝ≥0 := if b then cp/(1+cp) else 1/(1+cp)

theorem pilotFlagWeights_sum (cp:ℝ≥0) : ∑b,pilotFlagWeights cp b=1 := by
  simp only [Fintype.sum_bool,pilotFlagWeights,Bool.false_eq_true,if_false,if_true]
  field_simp
  ring

def pilotMarkedWeights {k:ℕ} (cp:ℝ≥0) (p:Simplex k) (ib:Fin k×Bool) : ℝ≥0 :=
  simplexNN p ib.1*pilotFlagWeights cp ib.2

theorem pilotMarkedWeights_sum {k:ℕ} (cp:ℝ≥0) (p:Simplex k) : ∑ib,pilotMarkedWeights cp p ib=1 := by
  simp only [pilotMarkedWeights,Fintype.sum_prod_type,←Finset.mul_sum,pilotFlagWeights_sum,mul_one,simplexNN_sum]

/-- Drawing a symbol and its independent flag gives the joint marked law. -/
theorem pilotMarkedWeights_categorical {k:ℕ} (cp:ℝ≥0) (p:Simplex k) :
    finiteCategoricalPMF (pilotMarkedWeights cp p) (pilotMarkedWeights_sum cp p)=
      (finiteCategoricalPMF (simplexNN p) (simplexNN_sum p)).bind (fun i =>
        (finiteCategoricalPMF (pilotFlagWeights cp) (pilotFlagWeights_sum cp)).map (fun b => (i,b))) := by
  ext ib
  rcases ib with ⟨i,b⟩
  simp only [PMF.bind_apply,PMF.map_apply,tsum_fintype,finiteCategoricalPMF_apply]
  rw [Finset.sum_eq_single i]
  · simp [pilotMarkedWeights]
  · intro j _ hj
    have hno (b':Bool) : (i,b)≠(j,b') := fun h => hj (congrArg Prod.fst h).symm
    simp only [hno,if_false,Finset.sum_const_zero,mul_zero]
  · simp

/-- Independent flag arrays applied to actual iid symbols give the iid joint marks. -/
theorem iid_pilot_flagging {k:ℕ} (cp:ℝ≥0) (p:Simplex k) (n:ℕ) :
    (iidMarkPMF (simplexNN p) (simplexNN_sum p) n).bind (fun x =>
      (iidMarkPMF (pilotFlagWeights cp) (pilotFlagWeights_sum cp) n).map
        (fun flags i => (x i,flags i)))=
      iidMarkPMF (pilotMarkedWeights cp p) (pilotMarkedWeights_sum cp p) n := by
  let q := finiteCategoricalPMF (simplexNN p) (simplexNN_sum p)
  let r := finiteCategoricalPMF (pilotFlagWeights cp) (pilotFlagWeights_sum cp)
  have hh := coordinateCountablePMF_bind (fun _ : Fin n => q)
    (fun _ i => r.map (fun b => (i,b)))
  change iidCountablePMF (q.bind (fun i => r.map (fun b => (i,b)))) n=
    (iidCountablePMF q n).bind (fun x => coordinateCountablePMF (fun i => r.map (fun b => (x i,b)))) at hh
  simp_rw [←iidCountablePMF_coordinate_map] at hh
  have hq : q.bind (fun i => r.map (fun b => (i,b)))=
      finiteCategoricalPMF (pilotMarkedWeights cp p) (pilotMarkedWeights_sum cp p) :=
    (pilotMarkedWeights_categorical cp p).symm
  rw [hq] at hh
  dsimp only [q,r] at hh
  simp only [iidCountablePMF_categorical] at hh
  exact hh.symm

/-- Internal pilot randomization on the supplied, unknown-law iid record. -/
def pilotFlagRecordKernel {k:ℕ} (cp:ℝ≥0) (x:PoissonMarkedSample (Fin k)) :
    PMF (PoissonMarkedSample (Fin k×Bool)) :=
  (iidMarkPMF (pilotFlagWeights cp) (pilotFlagWeights_sum cp) x.1).map
    (fun flags => ⟨x.1,fun i => (x.2 i,flags i)⟩)

/-- Exact law of the randomized marked Poisson record. -/
theorem poisson_pilot_flagging {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) :
    (poissonMarkedSamplePMF ((1+cp)*n) (simplexNN p) (simplexNN_sum p)).bind (pilotFlagRecordKernel cp)=
      poissonMarkedSamplePMF ((1+cp)*n) (pilotMarkedWeights cp p) (pilotMarkedWeights_sum cp p) := by
  rw [poissonMarkedSamplePMF,PMF.bind_bind]
  congr 1
  funext m
  rw [PMF.bind_map]
  rw [←iid_pilot_flagging cp p m,PMF.map_bind]
  simp only [pilotFlagRecordKernel,PMF.map_comp,Function.comp_def]

/-- The randomized flagging produces exactly the independent main/pilot
histogram model, with no assumed distributional identity. -/
theorem poisson_pilot_histogram_law {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) :
    ((poissonMarkedSamplePMF ((1+cp)*n) (simplexNN p) (simplexNN_sum p)).bind (pilotFlagRecordKernel cp)).map
      (fun x => markHistogram x.2)=pilotHistogramPMF n cp p := by
  rw [poisson_pilot_flagging,poissonMarkedSample_histogram]
  congr 1
  funext ib
  rcases ib with ⟨i,b⟩
  cases b <;> dsimp [pilotMarkedWeights,pilotFlagWeights,pilotHistogramRate,pilotHistogramPMF]
  all_goals field_simp

end Renyi
