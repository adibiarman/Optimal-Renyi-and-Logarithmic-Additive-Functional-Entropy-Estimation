import Renyi.TensorPowerBounds

/-! Refined normalized second moments for the same explicit tensor priors that
carry the count-experiment identities. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- The normalized Jordan mass hypotheses bound the full absolute mass. -/
theorem absolute_mass_le_two {ι : Type*} [Fintype ι] (l : ι→ℝ) {R : ℝ}
    (hl : ∑ i, positiveCoeff (l i)=1) (hR : ∑ i, negativeCoeff (l i)=R) (hR1 : R≤1) :
    (∑ i, |l i|)≤2 := by
  simp_rw [← positive_add_negative]
  rw [Finset.sum_add_distrib,hl,hR]
  linarith

/-- The full high inverse power is at most two for the actual normalized factors. -/
theorem high_inverse_power_upper {ι : Type*} [Fintype ι] (r w : ι→ℝ)
    {b beta R : ℝ} (hb : 0<b) (hbeta : 0≤beta) (hwb : ∀ j, b≤w j)
    (hr : ∑ j, positiveCoeff (r j)=1) (hR : ∑ j, negativeCoeff (r j)=R) (hR1 : R≤1) :
    (∑ j, |r j| *(b/w j)^beta)≤2 := by
  apply le_trans (Finset.sum_le_sum (fun j _ => ?_)) (absolute_mass_le_two r hr hR hR1)
  apply mul_le_of_le_one_right (abs_nonneg _)
  exact Real.rpow_le_one (div_nonneg hb.le (hb.trans_le (hwb j)).le)
    ((div_le_one (hb.trans_le (hwb j))).mpr (hwb j)) hbeta

/-- For either parity, the exact moments supplied by the tensor prior
construction obey the source's refined second-moment shape. The low Jordan
and high absolute moments are exposed separately so their actual node bounds
can be applied in either orientation. -/
theorem tensor_priors_refined_second_bound {ι κ τ : Type*}
    [Fintype ι] [Fintype κ] [Fintype τ]
    (l u : ι→ℝ) (r w : κ→ℝ) (p₀ p₁ : FiniteAtomicPrior τ)
    {a b alpha Rl Rr zeta kappa CJ CH c : ℝ}
    (ha : 0<a) (hb : 0<b) (halpha : 1<alpha)
    (hua : ∀ i, a≤u i) (hwb : ∀ j, b≤w j)
    (hl : ∑ i, positiveCoeff (l i)=1) (hr : ∑ j, positiveCoeff (r j)=1)
    (hnl : ∑ i, negativeCoeff (l i)=Rl) (hnr : ∑ j, negativeCoeff (r j)=Rr)
    (hRl : Rl≤1) (hRr : Rr≤1)
    (hz : 0≤zeta) (hk : 0<kappa) (hk1 : kappa≤1)
    (hc : 0<c) (hc1 : c≤1) (hCJ : 0≤CJ) (hCH : 0≤CH)
    (hcancel : ∑ i, l i*u i^(alpha-1)=0)
    (hJordan : (∑ i, positiveCoeff (l i)*u i^(alpha-1))≤CJ*zeta*kappa)
    (hHigh : (∑ j, |r j| *w j^alpha)≤CH*zeta*kappa)
    (hMass : c*kappa≤Rl+Rr)
    (hmom₀ : ∀ j:ℝ, 0<j → priorMoment p₀ j=((a*b)⁻¹)^(j-1)/tensorNormalizer l r u w a alpha *
      (∑ ij, tensorNegative l r ij*tensorAtom u w a ij^(j-alpha)))
    (hmom₁ : ∀ j:ℝ, 0<j → priorMoment p₁ j=((a*b)⁻¹)^(j-1)/tensorNormalizer l r u w a alpha *
      (∑ ij, tensorPositive l r ij*tensorAtom u w a ij^(j-alpha))) :
    priorMoment p₀ (2*alpha)/(priorMoment p₀ alpha)^2≤
      (4*CJ*CH/c^2)*zeta^2*((a*b)⁻¹)^alpha ∧
    priorMoment p₁ (2*alpha)/(priorMoment p₁ alpha)^2≤
      (4*CJ*CH/c^2)*zeta^2*((a*b)⁻¹)^alpha := by
  let B := (a*b)⁻¹
  let Z := tensorNormalizer l r u w a alpha
  have hB : 0<B := inv_pos.mpr (mul_pos ha hb)
  have hu (i) : 0<u i := ha.trans_le (hua i)
  have hw (j) : 0<w j := hb.trans_le (hwb j)
  have hRl0 : 0≤Rl := by rw [← hnl]; exact Finset.sum_nonneg (fun i _ => le_max_right _ _)
  have hRr0 : 0≤Rr := by rw [← hnr]; exact Finset.sum_nonneg (fun i _ => le_max_right _ _)
  have hM₀ : 0<Rl+Rr := (mul_pos hc hk).trans_le hMass
  have hM₁ : 0<1+Rl*Rr := by positivity
  have hZ : 0<Z := tensorNormalizer_pos l r u w ha hu hw hl hr hnl hnr hM₀
  have hscaled : Z/B^(alpha-1)≤(2*CJ)*zeta*kappa := by
    rw [tensorNormalizer_scaled_jordan l u r w ha hb hu hw hcancel]
    have hInv0 : 0≤∑ j, |r j| *(b/w j)^(alpha-1) :=
      Finset.sum_nonneg (fun j _ => mul_nonneg (abs_nonneg _) (Real.rpow_nonneg (div_nonneg hb.le (hw _).le) _))
    have hInv := high_inverse_power_upper r w (beta:=alpha-1) hb (by linarith) hwb hr hnr hRr
    have hh := mul_le_mul hJordan hInv hInv0 (by positivity : 0≤CJ*zeta*kappa)
    nlinarith only [hh]
  have hH := tensor_parity_power_bound l u r w ha hua hw (by linarith : 0≤alpha)
    (absolute_mass_le_two l hl hnl hRl) hHigh
  have hMass₁ : c*kappa≤1+Rl*Rr := by
    have hh := mul_le_mul hc1 hk1 hk.le (by norm_num : (0:ℝ)≤1)
    nlinarith [mul_nonneg hRl0 hRr0]
  have htm₀ : ∑ ij, tensorNegative l r ij=Rl+Rr := tensorNegative_mass l r hl hr hnl hnr
  have htm₁ : ∑ ij, tensorPositive l r ij=1+Rl*Rr := tensorPositive_mass l r hl hr hnl hnr
  have hr₀ := prior_second_ratio_of_moments p₀ (tensorNegative l r) (tensorAtom u w a)
    hB hZ (by linarith : 0<alpha) hmom₀ (by rw [htm₀]; exact hM₀)
  have hr₁ := prior_second_ratio_of_moments p₁ (tensorPositive l r) (tensorAtom u w a)
    hB hZ (by linarith : 0<alpha) hmom₁ (by rw [htm₁]; exact hM₁)
  have hH0₀ : 0≤∑ ij, tensorNegative l r ij*tensorAtom u w a ij^alpha :=
    Finset.sum_nonneg (fun ij _ => mul_nonneg (tensorNegative_nonneg l r _) (Real.rpow_nonneg (tensorAtom_pos u w ha hu hw _).le _))
  have hH0₁ : 0≤∑ ij, tensorPositive l r ij*tensorAtom u w a ij^alpha :=
    Finset.sum_nonneg (fun ij _ => mul_nonneg (tensorPositive_nonneg l r _) (Real.rpow_nonneg (tensorAtom_pos u w ha hu hw _).le _))
  rw [htm₀] at hr₀
  rw [htm₁] at hr₁
  rw [hr₀,hr₁]
  constructor
  · have hh := refined_second_ratio_bound hB hZ.le hH0₀ hz hk hc
      (by positivity : 0≤2*CJ) (by positivity : 0≤2*CH) hscaled
      (by convert hH.2 using 1; ring) hMass
    convert hh using 1; ring
  · have hh := refined_second_ratio_bound hB hZ.le hH0₁ hz hk hc
      (by positivity : 0≤2*CJ) (by positivity : 0≤2*CH) hscaled
      (by convert hH.1 using 1; ring) hMass₁
    convert hh using 1; ring

end Renyi
