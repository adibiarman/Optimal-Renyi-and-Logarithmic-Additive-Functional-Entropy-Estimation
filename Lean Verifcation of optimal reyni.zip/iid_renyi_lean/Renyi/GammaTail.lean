import Mathlib.Analysis.SpecialFunctions.Gamma.Basic

/-! Absolute convergence and integration by parts for the analytic-count tail. -/
noncomputable section
open Filter Set MeasureTheory Asymptotics
open scoped Topology
namespace Renyi

def gammaTailIntegrand (a lam t : ℝ) : ℝ := Real.exp (-lam * t) * t ^ (-a - 1)

def gammaTail (a lam : ℝ) : ℝ := ∫ t in Ioi (1 : ℝ), gammaTailIntegrand a lam t

theorem gammaTail_tendsto_zero (a : ℝ) {lam : ℝ} (hlam : 0 < lam) :
    Tendsto (gammaTailIntegrand a lam) atTop (𝓝 0) := by
  convert tendsto_rpow_mul_exp_neg_mul_atTop_nhds_zero (-a - 1) lam hlam using 1
  funext t
  unfold gammaTailIntegrand
  ring

theorem gammaTail_isLittleO (a : ℝ) {lam : ℝ} (hlam : 0 < lam) :
    (gammaTailIntegrand a lam) =o[atTop] (fun t : ℝ => Real.exp (-(lam / 2) * t)) := by
  apply isLittleO_of_tendsto (fun t ht => False.elim ((Real.exp_ne_zero _) ht))
  have hid : (fun t : ℝ => gammaTailIntegrand a lam t / Real.exp (-(lam / 2) * t)) =
      (fun t : ℝ => t ^ (-a - 1) * Real.exp (-(lam / 2) * t)) := by
    funext t
    unfold gammaTailIntegrand
    calc
      _ = t ^ (-a - 1) * Real.exp (-lam * t - (-(lam / 2) * t)) := by
        rw [Real.exp_sub]
        ring
      _ = _ := by congr 2; ring
  rw [hid]
  exact tendsto_rpow_mul_exp_neg_mul_atTop_nhds_zero (-a - 1) (lam / 2) (by positivity)

theorem gammaTail_integrable (a : ℝ) {lam : ℝ} (hlam : 0 < lam) :
    IntegrableOn (gammaTailIntegrand a lam) (Ioi (1 : ℝ)) := by
  apply integrable_of_isBigO_exp_neg (show 0 < lam / 2 by positivity) _
    (gammaTail_isLittleO a hlam).isBigO
  apply (continuousOn_const.mul continuousOn_id).rexp.mul
    (continuousOn_id.rpow_const ?_)
  intro t ht
  exact Or.inl (ne_of_gt (lt_of_lt_of_le zero_lt_one ht))

theorem gammaTail_integrand_hasDerivAt (a lam : ℝ) {t : ℝ} (ht : 0 < t) :
    HasDerivAt (gammaTailIntegrand a lam)
      (-lam * gammaTailIntegrand a lam t - (a + 1) * gammaTailIntegrand (a + 1) lam t) t := by
  have he := ((hasDerivAt_id t).const_mul (-lam)).exp
  have hp := (hasDerivAt_id t).rpow_const (p := -a - 1) (Or.inl (ne_of_gt ht))
  convert he.mul hp using 1
  unfold gammaTailIntegrand
  have hexp : -a - 1 - 1 = -(a + 1) - 1 := by ring
  simp only [id_eq, hexp, mul_one, one_mul]
  ring

/-- The exact boundary-term recurrence, valid for every real order. -/
theorem gammaTail_recurrence (a : ℝ) {lam : ℝ} (hlam : 0 < lam) :
    lam * gammaTail a lam + (a + 1) * gammaTail (a + 1) lam = Real.exp (-lam) := by
  have hderiv : ∀ t ∈ Ici (1 : ℝ), HasDerivAt (gammaTailIntegrand a lam)
      (-lam * gammaTailIntegrand a lam t - (a + 1) * gammaTailIntegrand (a + 1) lam t) t :=
    fun t ht => gammaTail_integrand_hasDerivAt a lam (lt_of_lt_of_le zero_lt_one ht)
  have hint := ((gammaTail_integrable a hlam).const_mul (-lam)).sub
    ((gammaTail_integrable (a + 1) hlam).const_mul (a + 1))
  have h := integral_Ioi_of_hasDerivAt_of_tendsto' hderiv hint (gammaTail_tendsto_zero a hlam)
  rw [integral_sub ((gammaTail_integrable a hlam).const_mul (-lam))
      ((gammaTail_integrable (a + 1) hlam).const_mul (a + 1)),
    integral_const_mul, integral_const_mul] at h
  simp only [gammaTailIntegrand, mul_one, Real.one_rpow, zero_sub] at h
  change -lam * gammaTail a lam - (a + 1) * gammaTail (a + 1) lam = -Real.exp (-lam) at h
  linarith

theorem gamma_total_integral {a lam : ℝ} (ha : a < 0) (hlam : 0 < lam) :
    (∫ t in Ioi (0 : ℝ), gammaTailIntegrand a lam t) =
      Real.Gamma (-a) * lam ^ a := by
  have h := Real.integral_rpow_mul_exp_neg_mul_Ioi (neg_pos.mpr ha) hlam
  have hp : (1 / lam) ^ (-a) = lam ^ a := by
    rw [one_div, Real.inv_rpow (le_of_lt hlam), Real.rpow_neg (le_of_lt hlam), inv_inv]
  rw [hp, mul_comm] at h
  convert h using 1
  apply setIntegral_congr_fun measurableSet_Ioi
  intro t _
  unfold gammaTailIntegrand
  rw [neg_mul, mul_comm]

theorem gamma_unit_add_tail {a lam : ℝ} (ha : a < 0) (hlam : 0 < lam) :
    (∫ t in (0 : ℝ)..1, gammaTailIntegrand a lam t) + gammaTail a lam =
      Real.Gamma (-a) * lam ^ a := by
  have htotal := gamma_total_integral ha hlam
  have hi : IntegrableOn (gammaTailIntegrand a lam) (Ioi (0 : ℝ)) := by
    by_contra hn
    rw [integral_undef hn] at htotal
    have hp := mul_pos (Real.Gamma_pos_of_pos (neg_pos.mpr ha)) (Real.rpow_pos_of_pos hlam a)
    linarith
  have hleft : IntegrableOn (gammaTailIntegrand a lam) (Ioc (0 : ℝ) 1) :=
    hi.mono_set (fun _ ht => ht.1)
  have hright := gammaTail_integrable a hlam
  rw [← Ioc_union_Ioi_eq_Ioi (show (0 : ℝ) ≤ 1 by norm_num),
    setIntegral_union (by exact disjoint_left.mpr (fun _ h₁ h₂ => (not_lt_of_ge h₁.2) h₂))
      measurableSet_Ioi hleft hright] at htotal
  simpa only [intervalIntegral.integral_of_le (show (0 : ℝ) ≤ 1 by norm_num), gammaTail]
    using htotal

end Renyi
