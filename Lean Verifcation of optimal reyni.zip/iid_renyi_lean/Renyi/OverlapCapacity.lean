import Renyi.OverlapBijection
import Renyi.OverlapCorrection
import Renyi.Model
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Topology.Order.Compact

/-!
# Uniform capacity of the exact scalar overlap

The lower linear bound is obtained directly from the actual derivative of the
overlap, uniformly in its two weights. This retains the prefactor near order one.
-/

noncomputable section
open Set
namespace Renyi

def overlapEntropy (γ : ℝ) : ℝ :=
  -γ * Real.log γ - (1 - γ) * Real.log (1 - γ)

theorem overlapF_correction_identity (γ t : ℝ) :
    overlapF γ t = γ * (1 - γ) * t - overlapEntropy γ + overlapCorrection γ t := by
  unfold overlapF overlapEntropy overlapCorrection overlapLogTail
  rw [show -(1 - γ) * t = -((1 - γ) * t) by ring,
    show -γ * t = -(γ * t) by ring]
  ring

/-- Away from the origin the derivative of the manuscript's auxiliary function
is bounded below by an absolute constant. -/
theorem overlapJ_deriv_tail {t : ℝ} (ht : 32 ≤ t) : 1 / 4 ≤ deriv overlapJ t := by
  have ht0 : 0 < t := by linarith
  rw [(overlapJ_hasDerivAt ht0).deriv]
  have he : 0 < Real.exp t - 1 := sub_pos.mpr (Real.one_lt_exp_iff.mpr ht0)
  have hquad := Real.quadratic_le_exp_of_nonneg ht0.le
  have htquad : 32 * t ≤ t ^ 2 := by nlinarith
  have he16 : 16 * t ≤ Real.exp t := by nlinarith
  have he2 : 2 ≤ Real.exp t := by linarith
  have hprod := mul_nonneg (sub_nonneg.mpr he16) (Real.exp_pos t).le
  have hsq : (Real.exp t) ^ 2 ≤ 4 * (Real.exp t - 1) ^ 2 := by nlinarith
  have hfour : 4 * t * Real.exp t ≤ (Real.exp t - 1) ^ 2 := by nlinarith
  have hfrac : -(1 / 4 : ℝ) ≤
      ((Real.exp t - 1) - t * Real.exp t) / (Real.exp t - 1) ^ 2 := by
    apply (le_div_iff₀ (sq_pos_of_pos he)).2
    nlinarith
  linarith

/-- A positive uniform derivative bound on every closed positive half-line.
Its constant depends only on the lower endpoint, not on the overlap weights. -/
theorem overlapJ_deriv_uniform {a : ℝ} (ha : 0 < a) :
    ∃ c : ℝ, 0 < c ∧ ∀ t, a ≤ t → c ≤ deriv overlapJ t := by
  have hc : ContinuousOn (fun t : ℝ =>
      1 / 2 + ((Real.exp t - 1) - t * Real.exp t) / (Real.exp t - 1) ^ 2)
      (Icc a 32) := by
    intro t ht
    have ht0 : 0 < t := ha.trans_le ht.1
    exact (continuousAt_const.add
      (((Real.continuous_exp.continuousAt.sub continuousAt_const).sub
        (continuousAt_id.mul Real.continuous_exp.continuousAt)).div
        ((Real.continuous_exp.continuousAt.sub continuousAt_const).pow 2)
        (pow_ne_zero 2 (sub_pos.mpr (Real.one_lt_exp_iff.mpr ht0)).ne'))).continuousWithinAt
  have hd : ContinuousOn (deriv overlapJ) (Icc a 32) := by
    apply hc.congr
    intro t ht
    exact (overlapJ_hasDerivAt (ha.trans_le ht.1)).deriv
  obtain ⟨c, hc0, hc⟩ := isCompact_Icc.exists_forall_le' hd
    (fun t ht => overlapJ_deriv_pos (ha.trans_le ht.1))
  refine ⟨min c (1 / 4), lt_min hc0 (by norm_num), ?_⟩
  intro t ht
  by_cases ht32 : t ≤ 32
  · exact (min_le_left _ _).trans (hc t ⟨ht, ht32⟩)
  · exact (min_le_right _ _).trans (overlapJ_deriv_tail (le_of_not_ge ht32))

/-- Integrating a lower derivative bound for the actual auxiliary function. -/
theorem overlapJ_increment_lower {a c x y : ℝ} (ha : 0 < a)
    (hc : ∀ t, a ≤ t → c ≤ deriv overlapJ t) (hx : a ≤ x) (hxy : x ≤ y) :
    c * (y - x) ≤ overlapJ y - overlapJ x := by
  apply (convex_Ici a).mul_sub_le_image_sub_of_le_deriv
    (fun t ht => (overlapJ_hasDerivAt (ha.trans_le ht)).continuousAt.continuousWithinAt)
    (fun t ht => (overlapJ_hasDerivAt (ha.trans (by simpa using ht))).differentiableAt.differentiableWithinAt)
    (fun t ht => hc t (le_of_lt (by simpa using ht)))
    x hx y (hx.trans hxy) hxy

/-- The derivative of the actual overlap is bounded below uniformly in its weights. -/
theorem overlapF_deriv_lower {a c γ t : ℝ} (ha : 0 < a)
    (hc : ∀ s, a ≤ s → c ≤ deriv overlapJ s)
    (hγ : 0 < γ) (hγ1 : γ < 1) (ht : 2 * a ≤ t) :
    c * (γ * (1 - γ)) ≤ deriv (overlapF γ) t := by
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  have ht0 : 0 < t := by linarith
  have hγt : 0 < γ * t := mul_pos hγ ht0
  have hdt : 0 < (1 - γ) * t := mul_pos hd ht0
  have hγle : γ * t ≤ t := by nlinarith
  have hdle : (1 - γ) * t ≤ t := by nlinarith
  have hγdiff : 0 ≤ overlapJ t - overlapJ (γ * t) :=
    sub_nonneg.mpr (overlapJ_strictMonoOn.monotoneOn hγt ht0 hγle)
  have hddiff : 0 ≤ overlapJ t - overlapJ ((1 - γ) * t) :=
    sub_nonneg.mpr (overlapJ_strictMonoOn.monotoneOn hdt ht0 hdle)
  rw [(overlapF_hasDerivAt hγ hγ1 ht0).deriv]
  apply (le_div_iff₀ ht0).2
  by_cases hhalf : γ ≤ 1 / 2
  · have hda : a ≤ (1 - γ) * t := by nlinarith
    have hi := overlapJ_increment_lower ha hc hda hdle
    calc
      c * (γ * (1 - γ)) * t = (1 - γ) * (c * (t - (1 - γ) * t)) := by ring
      _ ≤ (1 - γ) * (overlapJ t - overlapJ ((1 - γ) * t)) :=
        mul_le_mul_of_nonneg_left hi hd.le
      _ ≤ _ := by nlinarith [mul_nonneg hγ.le hγdiff]
  · have hγa : a ≤ γ * t := by nlinarith
    have hi := overlapJ_increment_lower ha hc hγa hγle
    calc
      c * (γ * (1 - γ)) * t = γ * (c * (t - γ * t)) := by ring
      _ ≤ γ * (overlapJ t - overlapJ (γ * t)) :=
        mul_le_mul_of_nonneg_left hi hγ.le
      _ ≤ _ := by nlinarith [mul_nonneg hd.le hddiff]

/-- The uniform lower linear estimate needed at exact accuracy. The constant
depends only on `η`, including as either weight tends to zero. -/
theorem overlapF_uniform_linear {η : ℝ} (hη : 0 < η) :
    ∃ c : ℝ, 0 < c ∧ c ≤ 1 ∧ ∀ γ t : ℝ,
      0 < γ → γ < 1 → η ≤ t → c * (γ * (1 - γ)) * t ≤ overlapF γ t := by
  have ha : 0 < η / 4 := by positivity
  obtain ⟨c, hc0, hc⟩ := overlapJ_deriv_uniform ha
  refine ⟨min (c / 2) 1, lt_min (by positivity) zero_lt_one, min_le_right _ _, ?_⟩
  intro γ t hγ hγ1 ht
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  have hh : 0 < γ * (1 - γ) := mul_pos hγ hd
  have hη2 : 0 < η / 2 := by positivity
  have hgrowth := (convex_Ici (η / 2)).mul_sub_le_image_sub_of_le_deriv
    (f := overlapF γ)
    (fun s hs => (overlapF_hasDerivAt hγ hγ1 (hη2.trans_le hs)).continuousAt.continuousWithinAt)
    (fun s hs => (overlapF_hasDerivAt hγ hγ1
      (hη2.trans (by simpa using hs))).differentiableAt.differentiableWithinAt)
    (C := c * (γ * (1 - γ)))
    (fun s hs => overlapF_deriv_lower ha hc hγ hγ1
      (by
        have hs' : η / 2 < s := by simpa using hs
        linarith))
    (η / 2) (by simp only [mem_Ici, le_refl])
    t (by change η / 2 ≤ t; linarith) (by linarith : η / 2 ≤ t)
  have hstart := overlapF_pos hγ hγ1 hη2
  have htpos : 0 < t := hη.trans_le ht
  have hstep : c / 2 * (γ * (1 - γ)) * t ≤ overlapF γ t := by
    nlinarith [mul_nonneg (mul_nonneg hc0.le hh.le) (by linarith : 0 ≤ t - η)]
  exact (mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_right (min_le_left (c / 2) 1) hh.le) htpos.le).trans hstep

private theorem exp_neg_log_one_add_inv {x : ℝ} (hx : 0 < x) :
    Real.exp (-Real.log (1 + 1 / x)) = x / (1 + x) := by
  rw [Real.exp_neg, Real.exp_log (by positivity : 0 < 1 + 1 / x)]
  field_simp
  ring

/-- Exponentiating the uniform correction retains its small-energy prefactor. -/
theorem overlapCorrection_exponential_bounds {γ t η : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (hη : 0 < η) (ht : η ≤ t) :
    Real.exp (-(2 + 2 / η)) * ((γ * (1 - γ) * t) / (1 + γ * (1 - γ) * t)) ≤
      Real.exp (-(overlapCorrection γ t / (γ * (1 - γ)))) ∧
    Real.exp (-(overlapCorrection γ t / (γ * (1 - γ)))) ≤
      Real.exp (2 + 2 / η) * ((γ * (1 - γ) * t) / (1 + γ * (1 - γ) * t)) := by
  have hx : 0 < γ * (1 - γ) * t := mul_pos (mul_pos hγ (sub_pos.mpr hγ1)) (hη.trans_le ht)
  have hb := abs_le.mp (overlapCorrection_uniform hγ hγ1 hη ht)
  have hl := Real.exp_le_exp.mpr (show -(2 + 2 / η) +
      -Real.log (1 + 1 / (γ * (1 - γ) * t)) ≤
        -(overlapCorrection γ t / (γ * (1 - γ))) by linarith)
  have hu := Real.exp_le_exp.mpr (show -(overlapCorrection γ t / (γ * (1 - γ))) ≤
      (2 + 2 / η) + -Real.log (1 + 1 / (γ * (1 - γ) * t)) by linarith)
  rw [Real.exp_add, exp_neg_log_one_add_inv hx] at hl hu
  exact ⟨hl, hu⟩

private theorem capacity_fraction_comparison {x E c : ℝ}
    (hx : 0 < x) (hE : 0 < E) (hc : 0 < c) (hc1 : c ≤ 1)
    (hEx : E ≤ x) (hcx : c * x ≤ E) :
    E / (1 + E) ≤ x / (1 + x) ∧ x / (1 + x) ≤ (1 / c) * (E / (1 + E)) := by
  have hx1 : 0 < 1 + x := by positivity
  have hE1 : 0 < 1 + E := by positivity
  constructor
  · apply (div_le_div_iff₀ hE1 hx1).2
    nlinarith
  · have hm : c * (x / (1 + x)) ≤ E / (1 + E) := by
      rw [← mul_div_assoc]
      apply (div_le_div_iff₀ hx1 hE1).2
      nlinarith [mul_nonneg (sub_nonneg.mpr hc1) (mul_nonneg hE.le hx.le)]
    have hd := (le_div_iff₀ hc).2 (by nlinarith : x / (1 + x) * c ≤ E / (1 + E))
    convert hd using 1; ring

def overlapCapacityScale (γ E : ℝ) : ℝ :=
  Real.exp ((E + overlapEntropy γ) / (γ * (1 - γ))) * (E / (1 + E))

/-- Full capacity comparison, uniform in both weights, whenever `E/h ≥ η > 0`.
The target and its positive solution are the actual scalar overlap, not an
assumed concentration or approximation certificate. -/
theorem overlap_capacity_uniform {η : ℝ} (hη : 0 < η) :
    ∃ C₁ C₂ : ℝ, 0 < C₁ ∧ 0 < C₂ ∧ ∀ γ E t : ℝ,
      0 < γ → γ < 1 → 0 < t → overlapF γ t = E → η ≤ E / (γ * (1 - γ)) →
      C₁ * overlapCapacityScale γ E ≤ Real.exp t ∧
        Real.exp t ≤ C₂ * overlapCapacityScale γ E := by
  obtain ⟨c, hc, hc1, hlinear⟩ := overlapF_uniform_linear hη
  refine ⟨Real.exp (-(2 + 2 / η)), Real.exp (2 + 2 / η) / c,
    Real.exp_pos _, div_pos (Real.exp_pos _) hc, ?_⟩
  intro γ E t hγ hγ1 ht hF hEη
  have hh : 0 < γ * (1 - γ) := mul_pos hγ (sub_pos.mpr hγ1)
  have hE : 0 < E := hF ▸ overlapF_pos hγ hγ1 ht
  have hupper : E ≤ γ * (1 - γ) * t := hF ▸ overlapF_le_linear hγ hγ1 ht
  have htη : η ≤ t := hEη.trans ((div_le_iff₀ hh).2 (by nlinarith))
  have hlower : c * (γ * (1 - γ) * t) ≤ E := by
    have h := hlinear γ t hγ hγ1 htη
    rw [hF] at h
    nlinarith
  have hfrac := capacity_fraction_comparison (mul_pos hh ht) hE hc hc1 hupper hlower
  have hcorr := overlapCorrection_exponential_bounds hγ hγ1 hη htη
  have hidentity : t = (E + overlapEntropy γ) / (γ * (1 - γ)) +
      -(overlapCorrection γ t / (γ * (1 - γ))) := by
    rw [overlapF_correction_identity] at hF
    rw [← neg_div, ← add_div, eq_div_iff hh.ne']
    nlinarith
  have hexp : Real.exp t = Real.exp ((E + overlapEntropy γ) / (γ * (1 - γ))) *
      Real.exp (-(overlapCorrection γ t / (γ * (1 - γ)))) := by
    rw [← Real.exp_add, ← hidentity]
  rw [hexp]
  unfold overlapCapacityScale
  constructor
  · have h := mul_le_mul_of_nonneg_left
      ((mul_le_mul_of_nonneg_left hfrac.1 (Real.exp_pos _).le).trans hcorr.1)
      (Real.exp_pos ((E + overlapEntropy γ) / (γ * (1 - γ)))).le
    convert h using 1; ring
  · have h := mul_le_mul_of_nonneg_left
      (hcorr.2.trans (mul_le_mul_of_nonneg_left hfrac.2 (Real.exp_pos _).le))
      (Real.exp_pos ((E + overlapEntropy γ) / (γ * (1 - γ)))).le
    convert h using 1; ring

def overlapPsi (γ : ℝ) : ℝ :=
  γ ^ (1 + 1 / (1 - γ)) * (1 - γ) ^ (1 + 1 / γ)

theorem overlapPsi_pos {γ : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) : 0 < overlapPsi γ :=
  mul_pos (Real.rpow_pos_of_pos hγ _)
    (Real.rpow_pos_of_pos (sub_pos.mpr hγ1) _)

/-- The entropy factor is precisely `h / Ψ`; no endpoint prefactor is dropped. -/
theorem overlap_entropy_factor {γ : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    Real.exp (overlapEntropy γ / (γ * (1 - γ))) = γ * (1 - γ) / overlapPsi γ := by
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  have hp := overlapPsi_pos hγ hγ1
  have hlog : Real.log (γ * (1 - γ) / overlapPsi γ) =
      overlapEntropy γ / (γ * (1 - γ)) := by
    rw [Real.log_div (mul_pos hγ hd).ne' hp.ne', Real.log_mul hγ.ne' hd.ne']
    unfold overlapPsi overlapEntropy
    rw [Real.log_mul (Real.rpow_pos_of_pos hγ _).ne' (Real.rpow_pos_of_pos hd _).ne',
      Real.log_rpow hγ, Real.log_rpow hd]
    field_simp
    ring
  rw [← hlog, Real.exp_log (div_pos (mul_pos hγ hd) hp)]

theorem overlapCapacityScale_eq {γ E : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    overlapCapacityScale γ E =
      (E / (1 + E)) * (γ * (1 - γ) / overlapPsi γ) *
        Real.exp (E / (γ * (1 - γ))) := by
  unfold overlapCapacityScale
  rw [add_div, Real.exp_add, overlap_entropy_factor hγ hγ1]
  ring

private theorem accuracy_prefactor {κ β : ℝ} (hκ : 0 < κ) (hβ : 0 < β) :
    (κ / (1 + κ)) * (β / (1 + β)) ≤ (κ * β) / (1 + κ * β) ∧
    (κ * β) / (1 + κ * β) ≤ (1 + κ) * (β / (1 + β)) := by
  have hκβ : 0 < κ * β := mul_pos hκ hβ
  have hden : 0 < 1 + κ * β := by positivity
  have hβ1 : 0 < 1 + β := by positivity
  constructor
  · calc
      (κ / (1 + κ)) * (β / (1 + β)) = κ * β / ((1 + κ) * (1 + β)) := by
        rw [div_mul_div_comm]
      _ ≤ _ := div_le_div_of_nonneg_left hκβ.le hden (by nlinarith)
  · rw [← mul_div_assoc]
    apply (div_le_div_iff₀ hden hβ1).2
    nlinarith [sq_nonneg (κ * β)]

/-- Exact-accuracy form in the logarithmic coordinate. The only relation required
between the order and its fractional weight is `γ ≤ α - 1`. -/
theorem overlap_capacity_exact_accuracy_t {ε : ℝ} (hε : 0 < ε) :
    ∃ C₁ C₂ : ℝ, 0 < C₁ ∧ 0 < C₂ ∧ ∀ α γ t : ℝ,
      1 < α → 0 < γ → γ < 1 → γ ≤ α - 1 → 0 < t →
      overlapF γ t = 2 * ε * (α - 1) →
      C₁ * (((α - 1) / α) * (γ * (1 - γ) / overlapPsi γ) *
        Real.exp ((2 * ε * (α - 1)) / (γ * (1 - γ)))) ≤ Real.exp t ∧
      Real.exp t ≤ C₂ * (((α - 1) / α) * (γ * (1 - γ) / overlapPsi γ) *
        Real.exp ((2 * ε * (α - 1)) / (γ * (1 - γ)))) := by
  obtain ⟨C₁, C₂, hC₁, hC₂, hcap⟩ := overlap_capacity_uniform (by positivity : 0 < 2 * ε)
  refine ⟨C₁ * ((2 * ε) / (1 + 2 * ε)), C₂ * (1 + 2 * ε),
    mul_pos hC₁ (div_pos (by positivity) (by positivity)),
    mul_pos hC₂ (by positivity), ?_⟩
  intro α γ t hα hγ hγ1 hγα ht hF
  have hh : 0 < γ * (1 - γ) := mul_pos hγ (sub_pos.mpr hγ1)
  have hratio : 2 * ε ≤ (2 * ε * (α - 1)) / (γ * (1 - γ)) := by
    apply (le_div_iff₀ hh).2
    have hhβ : γ * (1 - γ) ≤ α - 1 := by nlinarith
    exact mul_le_mul_of_nonneg_left hhβ (by positivity)
  have hc := hcap γ (2 * ε * (α - 1)) t hγ hγ1 ht hF hratio
  rw [overlapCapacityScale_eq hγ hγ1] at hc
  simp only [mul_assoc] at hc
  have hp := accuracy_prefactor (by positivity : 0 < 2 * ε) (sub_pos.mpr hα)
  rw [show 1 + (α - 1) = α by ring] at hp
  have hm : 0 ≤ (γ * (1 - γ) / overlapPsi γ) *
      Real.exp ((2 * ε * (α - 1)) / (γ * (1 - γ))) :=
    (mul_pos (div_pos hh (overlapPsi_pos hγ hγ1)) (Real.exp_pos _)).le
  simp only [mul_assoc] at hp hm
  constructor
  · have h := (mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hp.1 hm) hC₁.le).trans hc.1
    simpa only [mul_assoc] using h
  · have h := hc.2.trans (mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hp.2 hm) hC₂.le)
    simpa only [mul_assoc] using h

/-- The manuscript's second capacity scale, including both endpoint weights. -/
def overlapAccuracyScale (α γ ε : ℝ) : ℝ :=
  ((α - 1) / α) * (γ * (1 - γ) / overlapPsi γ) *
    Real.exp ((2 * ε * (α - 1)) / (γ * (1 - γ)))

/-- The equivalent weighted-geometric entropy factor in the first source formula. -/
theorem overlap_entropy_weighted_product {γ : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    Real.exp (overlapEntropy γ / (γ * (1 - γ))) =
      (γ ^ γ * (1 - γ) ^ (1 - γ)) ^ (-1 / (γ * (1 - γ))) := by
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  rw [Real.rpow_def_of_pos (mul_pos (Real.rpow_pos_of_pos hγ _) (Real.rpow_pos_of_pos hd _)),
    Real.log_mul (Real.rpow_pos_of_pos hγ _).ne' (Real.rpow_pos_of_pos hd _).ne',
    Real.log_rpow hγ, Real.log_rpow hd]
  congr 1
  unfold overlapEntropy
  ring

/-- Both displayed scales in the capacity theorem are exactly the same. -/
theorem overlapAccuracyScale_weighted_product {α γ ε : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1) :
    overlapAccuracyScale α γ ε =
      ((α - 1) / α) * (γ ^ γ * (1 - γ) ^ (1 - γ)) ^ (-1 / (γ * (1 - γ))) *
        Real.exp ((2 * ε * (α - 1)) / (γ * (1 - γ))) := by
  unfold overlapAccuracyScale
  rw [← overlap_entropy_factor hγ hγ1, overlap_entropy_weighted_product hγ hγ1]

/-- The exact-accuracy comparison for the actual solution `Gγ(z) = exp(-E)`. -/
theorem overlap_capacity_exact_accuracy_z {ε : ℝ} (hε : 0 < ε) :
    ∃ C₁ C₂ : ℝ, 0 < C₁ ∧ 0 < C₂ ∧ ∀ α γ z : ℝ,
      1 < α → 0 < γ → γ < 1 → γ ≤ α - 1 → 0 < z → z < 1 →
      overlapG γ z = Real.exp (-(2 * ε * (α - 1))) →
      C₁ * overlapAccuracyScale α γ ε ≤ z ^ (-1 / (γ * (1 - γ))) ∧
      z ^ (-1 / (γ * (1 - γ))) ≤ C₂ * overlapAccuracyScale α γ ε := by
  obtain ⟨C₁, C₂, hC₁, hC₂, hcap⟩ := overlap_capacity_exact_accuracy_t hε
  refine ⟨C₁, C₂, hC₁, hC₂, ?_⟩
  intro α γ z hα hγ hγ1 hγα hz hz1 hG
  have hd : 0 < 1 - γ := sub_pos.mpr hγ1
  have hh : 0 < γ * (1 - γ) := mul_pos hγ hd
  let t := -Real.log z / (γ * (1 - γ))
  have ht : 0 < t := div_pos (neg_pos.mpr (Real.log_neg hz hz1)) hh
  have hzrep : Real.exp (-γ * (1 - γ) * t) = z := by
    have heq : -γ * (1 - γ) * t = Real.log z := by
      dsimp [t]
      field_simp
    rw [heq, Real.exp_log hz]
  have hF : overlapF γ t = 2 * ε * (α - 1) := by
    rw [overlapF_eq_log hγ hγ1 ht, hzrep, hG, Real.log_exp, neg_neg]
  have hpow : z ^ (-1 / (γ * (1 - γ))) = Real.exp t := by
    rw [Real.rpow_def_of_pos hz]
    congr 1
    dsimp [t]
    ring
  rw [hpow]
  exact hcap α γ t hα hγ hγ1 hγα ht hF

/-- The capacity theorem for every noninteger order greater than one.
The constants depend only on the requested accuracy. Existence and uniqueness
are established for the original envelope, and both inequalities hold for that
unique solution, uniformly even as the order approaches an integer. -/
theorem overlap_capacity_exact_accuracy {ε : ℝ} (hε : 0 < ε) :
    ∃ C₁ C₂ : ℝ, 0 < C₁ ∧ 0 < C₂ ∧ ∀ α : ℝ,
      1 < α → (∀ n : ℤ, α ≠ (n : ℝ)) →
      ∃! z : ℝ, z ∈ Ioo (0 : ℝ) 1 ∧
        overlapG (fractionalPart α) z = Real.exp (-(2 * ε * (α - 1))) ∧
        C₁ * overlapAccuracyScale α (fractionalPart α) ε ≤
          z ^ (-1 / (fractionalPart α * (1 - fractionalPart α))) ∧
        z ^ (-1 / (fractionalPart α * (1 - fractionalPart α))) ≤
          C₂ * overlapAccuracyScale α (fractionalPart α) ε := by
  obtain ⟨C₁, C₂, hC₁, hC₂, hcap⟩ := overlap_capacity_exact_accuracy_z hε
  refine ⟨C₁, C₂, hC₁, hC₂, ?_⟩
  intro α hα hnonint
  have hγ : 0 < fractionalPart α := by
    unfold fractionalPart
    exact sub_pos.mpr (lt_of_le_of_ne (Int.floor_le α) (Ne.symm (hnonint ⌊α⌋)))
  have hγ1 : fractionalPart α < 1 := by
    have h := Int.lt_floor_add_one α
    unfold fractionalPart
    linarith
  have hγα : fractionalPart α ≤ α - 1 := by
    have hf : (1 : ℤ) ≤ ⌊α⌋ := Int.le_floor.mpr (by simpa using hα.le)
    have hf' : (1 : ℝ) ≤ (⌊α⌋ : ℝ) := by exact_mod_cast hf
    unfold fractionalPart
    linarith
  have hE : 0 < 2 * ε * (α - 1) :=
    mul_pos (mul_pos (by norm_num) hε) (sub_pos.mpr hα)
  obtain ⟨z, hz, hG⟩ := overlapG_surjOn hγ hγ1
    ⟨Real.exp_pos _, Real.exp_lt_one_iff.mpr (neg_neg_of_pos hE)⟩
  refine ⟨z, ⟨hz, hG, hcap α (fractionalPart α) z hα hγ hγ1 hγα hz.1 hz.2 hG⟩, ?_⟩
  intro y hy
  exact (overlapG_strictMonoOn hγ hγ1).injOn hy.1 hz (hy.2.1.trans hG.symm)

end Renyi
