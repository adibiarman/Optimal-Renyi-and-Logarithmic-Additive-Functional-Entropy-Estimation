import Renyi.LowerMassRatio

/-! Scalar sample/root identities for the calibrated count experiment. -/
noncomputable section
namespace Renyi

/-- The one-defect term at the common intensity factors into a small
velocity and exactly the nearest-integer correction power. -/
theorem lower_defect_scale_identity {k α x cn : ℝ} (r : ℕ)
    (hk : 0<k) (hα : 0<α) (hx : 0<x) :
    let θ := cn*α*k^(-1/α)*x
    let v := (α-1)/α*x^(-α)
    k*θ^r*v^2=(cn*α)^r*((α-1)/α)*v*(k*x^(-α))^((α-(r:ℝ))/α) := by
  let q := (α-(r:ℝ))/α
  have hkp : k*(k^(-1/α))^r=k^q := by
    calc
      _=k^(1+(-1/α)*(r:ℝ)) := by
        rw [Real.rpow_add hk,Real.rpow_mul hk.le,Real.rpow_one,Real.rpow_natCast]
      _=k^q := by congr 1; dsimp [q]; field_simp; ring
  have hxp : x^r*(x^(-α))^2=x^(-α)*(x^(-α))^q := by
    calc
      _=x^((r:ℝ)+(-α)*2) := by
        rw [Real.rpow_add hx,Real.rpow_mul hx.le,Real.rpow_natCast,Real.rpow_two]
      _=x^(-α+(-α)*q) := by congr 1; dsimp [q]; field_simp; ring
      _=_ := by rw [Real.rpow_add hx,Real.rpow_mul hx.le]
  have hratio : (k*x^(-α))^q=k^q*(x^(-α))^q :=
    Real.mul_rpow hk.le (Real.rpow_nonneg hx.le _)
  dsimp only
  change k*(cn*α*k^(-1/α)*x)^r*((α-1)/α*x^(-α))^2=
    (cn*α)^r*((α-1)/α)*((α-1)/α*x^(-α))*(k*x^(-α))^q
  rw [hratio,mul_pow,mul_pow,mul_pow]
  calc
    _=(cn*α)^r*((α-1)/α)^2*(k*(k^(-1/α))^r)*(x^r*(x^(-α))^2) := by ring
    _=_ := by rw [hkp,hxp]; ring

/-- The common support/intensity product gives the exact exponential-scale
identity for the Taylor-remainder prefactor. -/
theorem lower_remainder_scale_identity {k α x cn cm L : ℝ}
    (hk : 0<k) (hα : 0<α) (hx : 0<x) (hcn : 0<cn) (hcm : 0<cm) (hL : 0<L) :
    let θ := cn*α*k^(-1/α)*x
    let B := cm*L/θ
    k*B^(-α)=(cn*α/(cm*L))^α*x^α := by
  let θ := cn*α*k^(-1/α)*x
  have hθ : 0<θ := by dsimp [θ]; positivity
  have hkpow : (k^(-1/α))^α=k⁻¹ := by
    rw [←Real.rpow_mul hk.le]
    have he : (-1/α)*α=(-1:ℝ) := by field_simp
    rw [he,Real.rpow_neg_one]
  dsimp only
  rw [Real.rpow_neg (div_pos (mul_pos hcm hL) hθ).le,
    Real.div_rpow (mul_pos hcm hL).le hθ.le, inv_div]
  dsimp [θ]
  rw [Real.mul_rpow (by positivity) hx.le,
    Real.mul_rpow (mul_pos hcn hα).le (Real.rpow_nonneg hk.le _),hkpow,
    Real.div_rpow (mul_pos hcn hα).le (mul_pos hcm hL).le]
  field_simp

/-- A uniformly controlled exponential correction is absorbed by choosing
the common sample constant once; the selected degree is at least two. -/
theorem lower_defect_exponential_budget {r : ℕ} {cn C H : ℝ}
    (hr : 2≤r) (hcn : 0≤cn) (hH : 0≤H)
    (hscale : cn*Real.exp C≤1/(8*(H+1))) :
    H*(cn*Real.exp C)^r≤1/64 := by
  have hb : 0≤cn*Real.exp C := by positivity
  have hbase : cn*Real.exp C≤1 := by
    apply hscale.trans
    apply (div_le_one (by positivity : 0<8*(H+1))).mpr
    linarith
  have hp : (cn*Real.exp C)^r≤(cn*Real.exp C)^2 := pow_le_pow_of_le_one hb hbase hr
  have hsquare := pow_le_pow_left₀ hb hscale 2
  have hh := mul_le_mul_of_nonneg_left (hp.trans hsquare) hH
  apply hh.trans
  have hden : 0<(8*(H+1))^2 := by positivity
  rw [div_pow,one_pow,mul_one_div]
  apply (div_le_iff₀ hden).mpr
  nlinarith [sq_nonneg (H-1)]



/-- Exact nearest-integer form of the root equation, expressed at the
alphabet logarithm for the activation estimate. -/
theorem lower_root_log_alphabet {k : ℕ} {α ε s : ℝ}
    (hk : 0<k) (hα : 1<α) (hs : 0<s) (hs1 : s<1)
    (hg : 0<fractionalPart α) (hg1 : fractionalPart α<1)
    (hnearest : s=fractionalPart α ∨ s=1-fractionalPart α)
    (hx : 1<rootMultiplier k α ε) :
    let x := rootMultiplier k α ε
    let v := (α-1)/α*x^(-α)
    Real.log k/α=2*Real.log α+2*Real.log (α-1)+Real.log (1+Real.log x)+1+Real.log x-
      (1+1/(1-s))*Real.log s-(1+1/s)*Real.log (1-s)+(2*ε*(α-1)-v)/(s*(1-s)) := by
  let x := rootMultiplier k α ε
  have hα0 : 0<α := by linarith
  have hk0 : 0<(k:ℝ) := by exact_mod_cast hk
  have hx0 : 0<x := by dsimp [x]; linarith
  have hξ : 0<1-s := by linarith
  have hh : fractionalPart α*(1-fractionalPart α)=s*(1-s) := by
    rcases hnearest with h | h
    · rw [h]
    · rw [h]; ring
  have hΨ : (fractionalPart α)^(1+1/(1-fractionalPart α))*
      (1-fractionalPart α)^(1+1/fractionalPart α)=s^(1+1/(1-s))*(1-s)^(1+1/s) := by
    rcases hnearest with h | h
    · rw [h]
    · rw [h,show 1-(1-fractionalPart α)=fractionalPart α by ring]
      ring
  have hr := regularized_root_log_intensity hk hα hg hg1 hx
  dsimp only at hr ⊢
  rw [hh,hΨ,Real.log_mul (Real.rpow_pos_of_pos hs _).ne' (Real.rpow_pos_of_pos hξ _).ne',
    Real.log_rpow hs,Real.log_rpow hξ,
    Real.log_mul (mul_pos hα0 (Real.rpow_pos_of_pos hk0 _)).ne' hx0.ne',
    Real.log_mul hα0.ne' (Real.rpow_pos_of_pos hk0 _).ne',Real.log_rpow hk0] at hr
  linear_combination -hr

set_option maxHeartbeats 1000000 in
/-- Activation bounds the nearest-integer correction exponent at the actual
root. The constant is uniform for all orders at least three halves. -/
theorem lower_activated_log_correction {k : ℕ} {α ε s : ℝ}
    (hk : 0<k) (hα : 3/2≤α) (hε : ε≤1/2) (hs : 0<s) (hs1 : s≤1/2)
    (hg : 0<fractionalPart α) (hg1 : fractionalPart α<1)
    (hnearest : s=fractionalPart α ∨ s=1-fractionalPart α)
    (hx : 1<rootMultiplier k α ε)
    (hactive : 2*s≤(41/4)*((α-1)/α*rootMultiplier k α ε^(-α))) :
    s*(Real.log k/α+Real.log (rootMultiplier k α ε))≤16*α := by
  let x := rootMultiplier k α ε
  let ξ := 1-s
  let β := α-1
  let v := β/α*x^(-α)
  have hα1 : 1<α := by linarith
  have hα0 : 0<α := by linarith
  have hβ : 0<β := by dsimp [β]; linarith
  have hx0 : 0<x := by dsimp [x]; linarith
  have hlx : 0≤Real.log x := Real.log_nonneg hx.le
  have hξ : 1/2≤ξ := by dsimp [ξ]; linarith
  have hξ0 : 0<ξ := by linarith
  have hv : 0≤v := by dsimp [v]; positivity
  have hp : 0<x^α := Real.rpow_pos_of_pos hx0 _
  have hvinv : v≤(x^α)⁻¹ := by
    have hf : β/α≤1 := (div_le_one hα0).mpr (by dsimp [β]; linarith)
    have hh := mul_le_mul_of_nonneg_right hf (Real.rpow_nonneg hx0.le (-α))
    simpa only [v,one_mul,Real.rpow_neg hx0.le] using hh
  have hactive' : 2*s≤(41/4)*(x^α)⁻¹ := by
    exact hactive.trans (mul_le_mul_of_nonneg_left hvinv (by norm_num))
  have hsp : 2*s*x^α≤41/4 := by
    have hh := mul_le_mul_of_nonneg_right hactive' hp.le
    have he : (41/4:ℝ)*(x^α)⁻¹*x^α=41/4 := by
      rw [mul_assoc,inv_mul_cancel₀ hp.ne',mul_one]
    rw [he] at hh
    exact hh
  have hlogpow : α*Real.log x≤x^α := by
    have hh := Real.log_le_sub_one_of_pos hp
    rw [Real.log_rpow hx0] at hh
    linarith
  have hslog : 2*s*α*Real.log x≤41/4 := by
    have hh := mul_le_mul_of_nonneg_left hlogpow (show 0≤2*s by positivity)
    nlinarith only [hh,hsp]
  have hslog_bound : s*Real.log x≤4 := by nlinarith [mul_nonneg hs.le hlx]
  have hlogα : Real.log α≤α := (Real.log_le_sub_one_of_pos hα0).trans (by linarith)
  have hlogβ : Real.log β≤β := (Real.log_le_sub_one_of_pos hβ).trans (by linarith)
  have haTerm : 2*s*Real.log α≤α := by
    have hh := mul_le_mul_of_nonneg_left hlogα (show 0≤2*s by positivity)
    nlinarith
  have hbTerm : 2*s*Real.log β≤α := by
    have hh := mul_le_mul_of_nonneg_left hlogβ (show 0≤2*s by positivity)
    dsimp [β] at *
    nlinarith
  have hsmallLog : -s*Real.log s≤1 := by
    have hh := mul_le_mul_of_nonneg_left (Real.one_sub_inv_le_log_of_pos hs) hs.le
    rw [mul_sub,mul_inv_cancel₀ hs.ne',mul_one] at hh
    linarith
  have hcoeff : 1+1/ξ≤3 := by
    have hh : 1/ξ≤2 := (div_le_iff₀ hξ0).mpr (by linarith)
    linarith
  have hnegTerm : -(s*(1+1/ξ)*Real.log s)≤3 := by
    have hh := mul_le_mul_of_nonneg_left hsmallLog (show 0≤1+1/ξ by positivity)
    nlinarith only [hh,hcoeff]
  have hlogξ : -1≤Real.log ξ := by
    have hh := Real.one_sub_inv_le_log_of_pos hξ0
    have hc : ξ⁻¹≤2 := by rw [←one_div]; exact (div_le_iff₀ hξ0).mpr (by linarith)
    linarith
  have hξTerm : -(s+1)*Real.log ξ≤3/2 := by
    have hh := mul_le_mul_of_nonneg_left hlogξ (show 0≤s+1 by positivity)
    nlinarith
  have htime : (2*ε*β-v)/ξ≤2*α := by
    apply (div_le_iff₀ hξ0).mpr
    have hh := mul_le_mul_of_nonneg_left hε (show 0≤2*β by positivity)
    have hαξ := mul_le_mul_of_nonneg_left hξ (show 0≤2*α by positivity)
    dsimp [β] at *
    nlinarith
  have hloglog : s*Real.log (1+Real.log x)≤s*Real.log x := by
    have hh := Real.log_le_sub_one_of_pos (show 0<1+Real.log x by linarith)
    have hh' : Real.log (1+Real.log x)≤Real.log x := by linarith
    exact mul_le_mul_of_nonneg_left hh' hs.le
  have hroot := lower_root_log_alphabet hk hα1 hs (by linarith) hg hg1 hnearest hx
  have hid : s*Real.log k/α=2*s*Real.log α+2*s*Real.log β+s*Real.log (1+Real.log x)+s+
      s*Real.log x-s*(1+1/ξ)*Real.log s-(s+1)*Real.log ξ+(2*ε*β-v)/ξ := by
    dsimp only at hroot
    rw [show s*Real.log k/α=s*(Real.log k/α) by ring,hroot]
    dsimp [ξ,β,v]
    field_simp
    ring
  change s*(Real.log k/α+Real.log x)≤16*α
  have hkbound : s*Real.log k/α≤4*α+13 := by
    rw [hid]
    nlinarith only [haTerm,hbTerm,hloglog,hslog_bound,hnegTerm,hξTerm,htime,hs1]
  rw [mul_add,←mul_div_assoc]
  linarith only [hkbound,hslog_bound,hα]

/-- The apparent alphabet power in the defect term is uniformly exponential
in the selected integer degree whenever the perturbation is activated. -/
theorem lower_activated_power_correction {k r : ℕ} {α ε s : ℝ}
    (hk : 0<k) (hr : 2≤r) (hα : 3/2≤α) (hε : ε≤1/2)
    (hs : 0<s) (hs1 : s≤1/2)
    (hg : 0<fractionalPart α) (hg1 : fractionalPart α<1)
    (hnearest : s=fractionalPart α ∨ s=1-fractionalPart α)
    (hdegree : α-(r:ℝ)=s ∨ α-(r:ℝ)= -s)
    (hx : 1<rootMultiplier k α ε)
    (hactive : 2*s≤(41/4)*((α-1)/α*rootMultiplier k α ε^(-α))) :
    ((k:ℝ)*rootMultiplier k α ε^(-α))^((α-(r:ℝ))/α)≤Real.exp (20*r) := by
  let x := rootMultiplier k α ε
  have hk0 : 0<(k:ℝ) := by exact_mod_cast hk
  have hk1 : (1:ℝ)≤k := by exact_mod_cast hk
  have hα0 : 0<α := by linarith
  have hx0 : 0<x := by dsimp [x]; linarith
  have hlk : 0≤Real.log k := Real.log_nonneg hk1
  have hlx : 0≤Real.log x := Real.log_nonneg hx.le
  have hbound := lower_activated_log_correction hk hα hε hs hs1 hg hg1 hnearest hx hactive
  change s*(Real.log k/α+Real.log x)≤16*α at hbound
  have hlog : Real.log ((k:ℝ)*x^(-α))=Real.log k-α*Real.log x := by
    rw [Real.log_mul hk0.ne' (Real.rpow_pos_of_pos hx0 _).ne',Real.log_rpow hx0]
    ring
  have hcorr : (α-(r:ℝ))/α*(Real.log k-α*Real.log x)≤16*α := by
    rcases hdegree with hd | hd <;> rw [hd]
    · have he : s/α*(Real.log k-α*Real.log x)=s*(Real.log k/α-Real.log x) := by
        field_simp
      rw [he]
      nlinarith [mul_nonneg hs.le hlx]
    · have he : -s/α*(Real.log k-α*Real.log x)=s*(-Real.log k/α+Real.log x) := by
        field_simp
        ring
      rw [he]
      have hh : 0≤s*(Real.log k/α) := by positivity
      rw [neg_div,mul_add,mul_neg]
      rw [mul_add] at hbound
      linarith only [hbound,hh]
  have hαr : α≤(r:ℝ)+1/2 := by rcases hdegree with h | h <;> linarith
  have hrR : (2:ℝ)≤r := by exact_mod_cast hr
  change ((k:ℝ)*x^(-α))^((α-(r:ℝ))/α)≤Real.exp (20*r)
  rw [Real.rpow_def_of_pos (mul_pos hk0 (Real.rpow_pos_of_pos hx0 _))]
  apply Real.exp_le_exp.mpr
  rw [hlog]
  nlinarith only [hcorr,hαr,hrR]

end Renyi
