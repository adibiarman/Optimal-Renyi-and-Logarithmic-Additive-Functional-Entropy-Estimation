import Renyi.CompletedPilotPolynomial
import Renyi.UpperPilotBaseline

/-! Full actual random-pilot boundary envelope, including the signed Gamma arm. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Polynomial
namespace Renyi
set_option maxHeartbeats 800000
variable {ι Ω : Type*} [Fintype ι] [MeasurableSpace Ω] {μ : Measure Ω}

def pilotGammaBoundary (p : ι→ℝ) (Y N : ι→Ω→ℕ) (n alpha cp B omega : ℝ) : Ω→ℝ :=
  fun w => ∑i,if n*p i<B*alpha/2 then
    (if cp*B*alpha<(Y i w:ℝ) then |omega*analyticCount alpha (N i w)/n^alpha| else 0) else 0

def pilotTotalBoundary (p Q : ι→ℝ) (Y N : ι→Ω→ℕ) (n b alpha cp B omega : ℝ) : Ω→ℝ :=
  fun w => pilotPolynomialBoundary p Q Y n b alpha cp B omega w+
    pilotGammaBoundary p Y N n alpha cp B omega w

omit [MeasurableSpace Ω] in
lemma pilotTotalBoundary_nonneg (p Q : ι→ℝ) (hp : ∀i,0≤p i) (Y N : ι→Ω→ℕ)
    (n b alpha cp B omega : ℝ) (hw : 0≤omega) (w : Ω) :
    0≤pilotTotalBoundary p Q Y N n b alpha cp B omega w := by
  apply add_nonneg
  · apply Finset.sum_nonneg
    intro i _
    have hi : 0≤omega*p i^alpha := mul_nonneg hw (Real.rpow_nonneg (hp i) _)
    split_ifs <;> positivity
  · apply Finset.sum_nonneg
    intro i _
    split_ifs <;> positivity

theorem completed_polynomial_pilot_noise {ell N m : ℕ}
    (hell : 0<ell) (hN : 0<N) (hm : 1≤m) (hdegree : 4*(ell-1)≤m)
    {gamma a b fL f A B omega sigma n L cp Bpilot cb cstar : ℝ}
    (hg : 0<gamma) (hg1 : gamma<1) (ha : 0<a) (hab : a≤b)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hA : 0≤A) (hA1 : A≤1) (hB : 0≤B) (hB1 : B≤1)
    (hw : 0≤omega) (hw1 : omega<1) (hs : 0≤sigma) (hs1 : sigma≤1)
    (hn : 0<n) (halpha : 3/2≤(m:ℝ)+gamma) (hL : 1≤L)
    (hellL : (ell:ℝ)≤L) (hNL : (N:ℝ)≤L) (hmL : (m:ℝ)+gamma≤L)
    (hcp0 : 1≤cp) (hBp : 16≤Bpilot) (hcs : 0≤cstar)
    (hnb : n*b=cb*L) (hcut : 2*Bpilot*((m:ℝ)+gamma)≤n*b) (hLn : 1≤L*(n*b))
    (hcp : 8*(coupledCoefficientExponentialConstant+20+cstar)≤cp*cb)
    (hcpGamma : 2*Bpilot+cstar+11≤cp)
    (p : ι→ℝ) (hp : ∀i,0≤p i) (Y Counts : ι→Ω→ℕ)
    (hCounts : ∀i,MeasurePreserving (Counts i) μ (poissonMeasure ⟨n*p i,mul_nonneg hn.le (hp i)⟩))
    (hind : ∀i,IndepFun (Y i) (Counts i) μ)
    (hY : ∀i,MeasurePreserving (Y i) μ
      (poissonMeasure ⟨cp*n*p i,mul_nonneg (mul_nonneg (by linarith only [hcp0]) hn.le) (hp i)⟩)) :
    let Q0 := completedCoupledPolynomial ell N m gamma a b
      (DegreeOneCompletion.coefficient gamma fL) fL f A B omega
    let Q : ι→ℝ := fun i => sigma*Q0.eval (p i)
    Integrable (pilotTotalBoundary p Q Y Counts n b ((m:ℝ)+gamma) cp Bpilot (sigma*omega)) μ ∧
      (∫w,pilotTotalBoundary p Q Y Counts n b ((m:ℝ)+gamma) cp Bpilot (sigma*omega) w ∂μ)≤
        (Fintype.card ι:ℝ)*((100:ℝ)^(m+1)*a^((m:ℝ)+gamma))+
        (2*Real.exp (-cstar*L)+3*Real.exp (-cp*((m:ℝ)+gamma))+Real.exp (-cstar*((m:ℝ)+gamma)))*conditionalCountBonus p ((m:ℝ)+gamma) n L := by
  let alpha := (m:ℝ)+gamma
  let Q0 := completedCoupledPolynomial ell N m gamma a b
    (DegreeOneCompletion.coefficient gamma fL) fL f A B omega
  let Q : ι→ℝ := fun i => sigma*Q0.eval (p i)
  let lam : ι→ℝ≥0 := fun i => ⟨n*p i,mul_nonneg hn.le (hp i)⟩
  have hsomega : 0≤sigma*omega := mul_nonneg hs hw
  have hsomega1 : sigma*omega≤1 := mul_le_one₀ hs1 hw hw1.le
  have hpoly := completed_polynomial_pilot_boundary hell hN hm hdegree hg hg1 ha hab
    hfL hfL1 hf hf1 hA hA1 hB hB1 hw hw1 hs hs1 hn halpha hL hellL hNL hmL hcp0 hBp hcs
    hnb hcut hLn hcp p hp Y hY
  have hY' (i:ι) : MeasurePreserving (Y i) μ (poissonMeasure
      ⟨cp*lam i,mul_nonneg (by linarith only [hcp0]) (lam i).coe_nonneg⟩) := by
    have hid : (⟨cp*lam i,mul_nonneg (by linarith only [hcp0]) (lam i).coe_nonneg⟩:ℝ≥0)=
        ⟨cp*n*p i,mul_nonneg (mul_nonneg (by linarith only [hcp0]) hn.le) (hp i)⟩ := by
      ext
      dsimp [lam]
      ring
    rw [hid]
    exact hY i
  have hgamma := false_heavy_gamma_sum hBp halpha hcs hcpGamma hn hsomega hsomega1 hL
    p hp Y Counts lam (fun _ => rfl) hY' hCounts hind
  change Integrable (pilotPolynomialBoundary p Q Y n b alpha cp Bpilot (sigma*omega)) μ ∧ _ at hpoly
  change Integrable (pilotGammaBoundary p Y Counts n alpha cp Bpilot (sigma*omega)) μ ∧ _ at hgamma
  refine ⟨hpoly.1.add hgamma.1,?_⟩
  change (∫w,pilotPolynomialBoundary p Q Y n b alpha cp Bpilot (sigma*omega) w+
    pilotGammaBoundary p Y Counts n alpha cp Bpilot (sigma*omega) w ∂μ)≤_
  rw [integral_add hpoly.1 hgamma.1]
  have hpBound : (∫w,pilotPolynomialBoundary p Q Y n b alpha cp Bpilot (sigma*omega) w ∂μ)≤
      (Fintype.card ι:ℝ)*((100:ℝ)^(m+1)*a^alpha)+
      (2*Real.exp (-cstar*L)+3*Real.exp (-cp*alpha))*conditionalCountBonus p alpha n L := hpoly.2
  have hgBound : (∫w,pilotGammaBoundary p Y Counts n alpha cp Bpilot (sigma*omega) w ∂μ)≤
      Real.exp (-cstar*alpha)*conditionalCountBonus p alpha n L := hgamma.2
  change (∫w,pilotPolynomialBoundary p Q Y n b alpha cp Bpilot (sigma*omega) w ∂μ)+
      (∫w,pilotGammaBoundary p Y Counts n alpha cp Bpilot (sigma*omega) w ∂μ)≤
      (Fintype.card ι:ℝ)*((100:ℝ)^(m+1)*a^alpha)+
      (2*Real.exp (-cstar*L)+3*Real.exp (-cp*alpha)+Real.exp (-cstar*alpha))*conditionalCountBonus p alpha n L
  nlinarith only [hpBound,hgBound]

end Renyi
