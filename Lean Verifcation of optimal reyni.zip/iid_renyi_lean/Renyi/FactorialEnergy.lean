import Renyi.Foundations
import Mathlib.RingTheory.Binomial
import Mathlib.Algebra.Polynomial.Derivative

/-!
# General Poisson factorial products

Exact falling-factorial product and covariance identities used by the
polynomial derivative-energy formula.
-/

noncomputable section
open scoped BigOperators NNReal
open ProbabilityTheory
namespace Renyi

theorem descFactorial_add_real (m n r : ℕ) :
    ((m + n).descFactorial r : ℝ) =
      ∑ j ∈ Finset.range (r + 1),
        (r.choose j : ℝ) * ((m.descFactorial j : ℝ) * (n.descFactorial (r - j) : ℝ)) := by
  have h := Ring.descPochhammer_smeval_add (R := ℝ) (r := (m : ℝ)) (s := (n : ℝ))
    r (Commute.all _ _)
  rw [Finset.Nat.sum_antidiagonal_eq_sum_range_succ_mk] at h
  simpa only [← Nat.cast_add, Polynomial.descPochhammer_smeval_eq_descFactorial,
    Prod.fst, Prod.snd] using h

/-- Product linearization, with the second degree as the summation limit. -/
theorem factorial_product_range (n r s : ℕ) :
    (n.descFactorial r : ℝ) * (n.descFactorial s : ℝ) =
      ∑ j ∈ Finset.range (s + 1),
        (s.choose j : ℝ) * (r.descFactorial j : ℝ) * (n.descFactorial (r + s - j) : ℝ) := by
  by_cases hr : r ≤ n
  · have h := descFactorial_add_real r (n - r) s
    rw [Nat.add_sub_of_le hr] at h
    rw [h, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j hj
    have hjs : j ≤ s := by have := Finset.mem_range.mp hj; omega
    have hjr : r ≤ r + s - j := by omega
    have hi : r + s - j - r = s - j := by omega
    have hf : ((n - r).descFactorial (s - j) : ℝ) * (n.descFactorial r : ℝ) =
        (n.descFactorial (r + s - j) : ℝ) := by
      exact_mod_cast (show (n - r).descFactorial (s - j) * n.descFactorial r =
        n.descFactorial (r + s - j) by
          simpa only [hi] using Nat.descFactorial_mul_descFactorial (n := n) hjr)
    rw [← hf]
    ring
  · have hrn : n < r := by omega
    rw [Nat.descFactorial_eq_zero_iff_lt.mpr hrn]
    simp only [Nat.cast_zero, zero_mul]
    symm
    apply Finset.sum_eq_zero
    intro j hj
    have hjs : j ≤ s := by have := Finset.mem_range.mp hj; omega
    rw [Nat.descFactorial_eq_zero_iff_lt.mpr (by omega : n < r + s - j)]
    simp

/-- The complete falling-factorial product identity for all integer degrees. -/
theorem factorial_product (n r s : ℕ) :
    (n.descFactorial r : ℝ) * (n.descFactorial s : ℝ) =
      ∑ j ∈ Finset.range (min r s + 1),
        (r.choose j : ℝ) * (s.choose j : ℝ) * (j.factorial : ℝ) *
          (n.descFactorial (r + s - j) : ℝ) := by
  rw [factorial_product_range]
  have hsum :
      (∑ j ∈ Finset.range (min r s + 1),
        (r.choose j : ℝ) * (s.choose j : ℝ) * (j.factorial : ℝ) *
          (n.descFactorial (r + s - j) : ℝ)) =
      ∑ j ∈ Finset.range (s + 1),
        (r.choose j : ℝ) * (s.choose j : ℝ) * (j.factorial : ℝ) *
          (n.descFactorial (r + s - j) : ℝ) := by
    apply Finset.sum_subset (Finset.range_mono (by omega : min r s + 1 ≤ s + 1))
    intro j hj hjnot
    have hjs : j ≤ s := by have := Finset.mem_range.mp hj; omega
    have hjmin : ¬ j < min r s + 1 := by simpa only [Finset.mem_range] using hjnot
    have hrj : r < j := by omega
    rw [Nat.choose_eq_zero_of_lt hrj]
    simp
  rw [hsum]
  apply Finset.sum_congr rfl
  intro j _
  rw [Nat.descFactorial_eq_factorial_mul_choose]
  push_cast
  ring

/-- Convergent cross moment of two arbitrary Poisson factorial statistics. -/
theorem poisson_factorial_cross_hasSum (lam : ℝ≥0) (r s : ℕ) :
    HasSum (fun n : ℕ =>
      ((n.descFactorial r : ℝ) * (n.descFactorial s : ℝ)) * poissonPMFReal lam n)
      (∑ j ∈ Finset.range (min r s + 1),
        (r.choose j : ℝ) * (s.choose j : ℝ) * (j.factorial : ℝ) *
          (lam : ℝ) ^ (r + s - j)) := by
  have h := hasSum_sum (s := Finset.range (min r s + 1))
    (fun j _ => (poisson_factorial_hasSum lam (r + s - j)).mul_left
      ((r.choose j : ℝ) * (s.choose j : ℝ) * (j.factorial : ℝ)))
  have heq : (fun n : ℕ =>
      ((n.descFactorial r : ℝ) * (n.descFactorial s : ℝ)) * poissonPMFReal lam n) =
      (fun n : ℕ => ∑ j ∈ Finset.range (min r s + 1),
        ((r.choose j : ℝ) * (s.choose j : ℝ) * (j.factorial : ℝ)) *
          ((n.descFactorial (r + s - j) : ℝ) * poissonPMFReal lam n)) := by
    funext n
    rw [factorial_product, Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro j _
    ring
  rw [heq]
  exact h

/-- The bilinear contribution of derivative order j to a factorial cross moment. -/
def factorialEnergyTerm (lam : ℝ) (r s j : ℕ) : ℝ :=
  lam ^ j / (j.factorial : ℝ) *
    ((r.descFactorial j : ℝ) * lam ^ (r - j)) *
    ((s.descFactorial j : ℝ) * lam ^ (s - j))

theorem factorialEnergyTerm_eq (lam : ℝ) (r s j : ℕ)
    (hjr : j ≤ r) (hjs : j ≤ s) :
    factorialEnergyTerm lam r s j =
      (r.choose j : ℝ) * (s.choose j : ℝ) * (j.factorial : ℝ) *
        lam ^ (r + s - j) := by
  have hjf : (j.factorial : ℝ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero j
  have hexp : r + s - j = j + (r - j) + (s - j) := by omega
  unfold factorialEnergyTerm
  rw [Nat.descFactorial_eq_factorial_mul_choose, Nat.descFactorial_eq_factorial_mul_choose,
    hexp, pow_add, pow_add]
  push_cast
  field_simp

theorem factorialEnergyTerm_zero (lam : ℝ) (r s j : ℕ) (h : min r s < j) :
    factorialEnergyTerm lam r s j = 0 := by
  by_cases hr : r < j
  ·
    simp [factorialEnergyTerm, Nat.descFactorial_eq_zero_iff_lt.mpr hr]
  · have hs : s < j := by omega
    simp [factorialEnergyTerm, Nat.descFactorial_eq_zero_iff_lt.mpr hs]

/-- The same cross moment with a common polynomial degree cutoff. -/
theorem poisson_factorial_cross_energy_hasSum (lam : ℝ≥0) (r s L : ℕ)
    (hr : r ≤ L) (hs : s ≤ L) :
    HasSum (fun n : ℕ =>
      ((n.descFactorial r : ℝ) * (n.descFactorial s : ℝ)) * poissonPMFReal lam n)
      (∑ j ∈ Finset.range (L + 1), factorialEnergyTerm lam r s j) := by
  have hsum :
      (∑ j ∈ Finset.range (min r s + 1),
        (r.choose j : ℝ) * (s.choose j : ℝ) * (j.factorial : ℝ) *
          (lam : ℝ) ^ (r + s - j)) =
      ∑ j ∈ Finset.range (L + 1), factorialEnergyTerm lam r s j := by
    calc
      _ = ∑ j ∈ Finset.range (min r s + 1), factorialEnergyTerm lam r s j := by
        apply Finset.sum_congr rfl
        intro j hj
        have hjmin : j ≤ min r s := by have := Finset.mem_range.mp hj; omega
        exact (factorialEnergyTerm_eq lam r s j (le_trans hjmin (min_le_left _ _))
          (le_trans hjmin (min_le_right _ _))).symm
      _ = _ := by
        apply Finset.sum_subset (Finset.range_mono (by omega : min r s + 1 ≤ L + 1))
        intro j _ hj
        apply factorialEnergyTerm_zero
        have : ¬ j < min r s + 1 := by simpa only [Finset.mem_range] using hj
        omega
  rw [← hsum]
  exact poisson_factorial_cross_hasSum lam r s

def factorialStatistic (L : ℕ) (c : ℕ → ℝ) (n : ℕ) : ℝ :=
  ∑ r ∈ Finset.range (L + 1), c r * (n.descFactorial r : ℝ)

def derivativeValue (L : ℕ) (c : ℕ → ℝ) (j : ℕ) (x : ℝ) : ℝ :=
  ∑ r ∈ Finset.range (L + 1), c r * (r.descFactorial j : ℝ) * x ^ (r - j)

theorem factorialStatistic_square (L : ℕ) (c : ℕ → ℝ) (n : ℕ) :
    factorialStatistic L c n ^ 2 =
      ∑ r ∈ Finset.range (L + 1), ∑ s ∈ Finset.range (L + 1),
        (c r * c s) * ((n.descFactorial r : ℝ) * (n.descFactorial s : ℝ)) := by
  unfold factorialStatistic
  rw [pow_two, Finset.sum_mul]
  simp_rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r _
  apply Finset.sum_congr rfl
  intro s _
  ring

theorem energy_term_sum (L : ℕ) (c : ℕ → ℝ) (lam : ℝ) (j : ℕ) :
    (∑ r ∈ Finset.range (L + 1), ∑ s ∈ Finset.range (L + 1),
      (c r * c s) * factorialEnergyTerm lam r s j) =
      lam ^ j / (j.factorial : ℝ) * derivativeValue L c j lam ^ 2 := by
  unfold derivativeValue
  rw [pow_two, Finset.sum_mul]
  simp_rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r _
  apply Finset.sum_congr rfl
  intro s _
  unfold factorialEnergyTerm
  ring

theorem energy_sum_reorder (L : ℕ) (c : ℕ → ℝ) (lam : ℝ) :
    (∑ r ∈ Finset.range (L + 1), ∑ s ∈ Finset.range (L + 1),
      (c r * c s) * (∑ j ∈ Finset.range (L + 1), factorialEnergyTerm lam r s j)) =
      ∑ j ∈ Finset.range (L + 1),
        lam ^ j / (j.factorial : ℝ) * derivativeValue L c j lam ^ 2 := by
  simp_rw [Finset.mul_sum]
  calc
    _ = ∑ r ∈ Finset.range (L + 1), ∑ j ∈ Finset.range (L + 1),
        ∑ s ∈ Finset.range (L + 1), (c r * c s) * factorialEnergyTerm lam r s j := by
      apply Finset.sum_congr rfl
      intro r _
      rw [Finset.sum_comm]
    _ = ∑ j ∈ Finset.range (L + 1), ∑ r ∈ Finset.range (L + 1),
        ∑ s ∈ Finset.range (L + 1), (c r * c s) * factorialEnergyTerm lam r s j := by
      rw [Finset.sum_comm]
    _ = _ := by simp_rw [energy_term_sum]

/-- The exact second moment of an arbitrary finite factorial polynomial. -/
theorem poisson_polynomial_second_hasSum (lam : ℝ≥0) (L : ℕ) (c : ℕ → ℝ) :
    HasSum (fun n : ℕ => factorialStatistic L c n ^ 2 * poissonPMFReal lam n)
      (∑ j ∈ Finset.range (L + 1),
        (lam : ℝ) ^ j / (j.factorial : ℝ) * derivativeValue L c j lam ^ 2) := by
  have h := hasSum_sum (s := Finset.range (L + 1)) (fun r hr =>
    hasSum_sum (s := Finset.range (L + 1)) (fun s hs =>
      (poisson_factorial_cross_energy_hasSum lam r s L
        (by have := Finset.mem_range.mp hr; omega)
        (by have := Finset.mem_range.mp hs; omega)).mul_left (c r * c s)))
  rw [energy_sum_reorder] at h
  have hf : (fun n : ℕ => factorialStatistic L c n ^ 2 * poissonPMFReal lam n) =
      (fun n : ℕ => ∑ r ∈ Finset.range (L + 1), ∑ s ∈ Finset.range (L + 1),
        (c r * c s) * (((n.descFactorial r : ℝ) * (n.descFactorial s : ℝ)) *
          poissonPMFReal lam n)) := by
    funext n
    rw [factorialStatistic_square]
    simp_rw [Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro r _
    apply Finset.sum_congr rfl
    intro s _
    ring
  rw [hf]
  exact h

def polynomialOfCoefficients (L : ℕ) (c : ℕ → ℝ) : Polynomial ℝ :=
  ∑ r ∈ Finset.range (L + 1), Polynomial.C (c r) * Polynomial.X ^ r

/-- The coefficient expression is the actual iterated polynomial derivative. -/
theorem derivativeValue_eq_iterate_derivative (L : ℕ) (c : ℕ → ℝ) (j : ℕ) (x : ℝ) :
    derivativeValue L c j x =
      ((Polynomial.derivative^[j]) (polynomialOfCoefficients L c)).eval x := by
  unfold polynomialOfCoefficients derivativeValue
  rw [Polynomial.iterate_derivative_sum, Polynomial.eval_finset_sum]
  simp only [Polynomial.iterate_derivative_C_mul,
    Polynomial.iterate_derivative_X_pow_eq_C_mul, Polynomial.eval_mul,
    Polynomial.eval_C, Polynomial.eval_pow, Polynomial.eval_X]
  apply Finset.sum_congr rfl
  intro r _
  ring

theorem derivativeValue_zero (L : ℕ) (c : ℕ → ℝ) (x : ℝ) :
    derivativeValue L c 0 x = ∑ r ∈ Finset.range (L + 1), c r * x ^ r := by
  simp [derivativeValue]

/-- Exact scalar Poisson variance with all polynomial cross terms included. -/
theorem poisson_polynomial_variance (lam : ℝ≥0) (L : ℕ) (c : ℕ → ℝ) :
    (∑' n : ℕ, factorialStatistic L c n ^ 2 * poissonPMFReal lam n) -
      (∑' n : ℕ, factorialStatistic L c n * poissonPMFReal lam n) ^ 2 =
      ∑ j ∈ Finset.range L,
        (lam : ℝ) ^ (j + 1) / ((j + 1).factorial : ℝ) *
          derivativeValue L c (j + 1) lam ^ 2 := by
  rw [(poisson_polynomial_second_hasSum lam L c).tsum_eq]
  have hmean : (∑' n : ℕ, factorialStatistic L c n * poissonPMFReal lam n) =
      ∑ r ∈ Finset.range (L + 1), c r * (lam : ℝ) ^ r :=
    (poisson_polynomial_hasSum lam L c).tsum_eq
  rw [hmean, Finset.sum_range_succ']
  simp [derivativeValue_zero]

/-- The derivative-energy formula, stated with Mathlib's polynomial derivative. -/
theorem poisson_polynomial_derivative_energy (lam : ℝ≥0) (L : ℕ) (c : ℕ → ℝ) :
    (∑' n : ℕ, factorialStatistic L c n ^ 2 * poissonPMFReal lam n) -
      (∑' n : ℕ, factorialStatistic L c n * poissonPMFReal lam n) ^ 2 =
      ∑ j ∈ Finset.range L,
        (lam : ℝ) ^ (j + 1) / ((j + 1).factorial : ℝ) *
          (((Polynomial.derivative^[j + 1]) (polynomialOfCoefficients L c)).eval (lam : ℝ)) ^ 2 := by
  simpa only [derivativeValue_eq_iterate_derivative] using poisson_polynomial_variance lam L c

theorem derivativeValue_rescale (L : ℕ) (c : ℕ → ℝ) (j : ℕ) (n p : ℝ)
    (hn : n ≠ 0) :
    derivativeValue L (fun r => c r / n ^ r) j (n * p) =
      derivativeValue L c j p / n ^ j := by
  unfold derivativeValue
  rw [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro r _
  by_cases hjr : j ≤ r
  · have hpow : n ^ r = n ^ (r - j) * n ^ j := by
      rw [← pow_add]
      congr 1
      omega
    rw [mul_pow]
    field_simp [hn]
    rw [hpow]
    ring
  · have hrj : r < j := by omega
    simp [Nat.descFactorial_eq_zero_iff_lt.mpr hrj]

/-- Scalar version of the manuscript's energy formula for intensity n*p and
the statistic sum c_r (N)_r/n^r. Independence of separate coordinates is not
assumed or used in this scalar statement. -/
theorem poisson_scaled_polynomial_derivative_energy (lam : ℝ≥0)
    (L : ℕ) (c : ℕ → ℝ) (n p : ℝ) (hn : n ≠ 0) (hlam : (lam : ℝ) = n * p) :
    (∑' a : ℕ, factorialStatistic L (fun r => c r / n ^ r) a ^ 2 * poissonPMFReal lam a) -
      (∑' a : ℕ, factorialStatistic L (fun r => c r / n ^ r) a * poissonPMFReal lam a) ^ 2 =
      ∑ j ∈ Finset.range L,
        p ^ (j + 1) / (((j + 1).factorial : ℝ) * n ^ (j + 1)) *
          (((Polynomial.derivative^[j + 1]) (polynomialOfCoefficients L c)).eval p) ^ 2 := by
  rw [poisson_polynomial_variance]
  apply Finset.sum_congr rfl
  intro j _
  rw [hlam, derivativeValue_rescale L c (j + 1) n p hn,
    derivativeValue_eq_iterate_derivative]
  rw [mul_pow]
  field_simp

end Renyi
