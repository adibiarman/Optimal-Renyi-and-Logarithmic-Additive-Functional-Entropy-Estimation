import Renyi.LowerCalibrationFinal

/-! Exact moment defects and actual count-probability denominators for the
lower interpolation experiment. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- The unperturbed factor's inverse shifted moment, including its normalizer. -/
theorem normalizedInterpolation_inverse_shift {n : ℕ} (u : Fin (n+1)→ℝ)
    (hu : Function.Injective u) {a e : ℝ} (ha : 0<a) (hau : ∀ i, a<u i) :
    (∑ i, normalizedInterpolation u a 0 e i*interpolationNodes u a i^(e-1))=
      interpolationProduct u a/(a*interpolationNormalizer u a 0 e) := by
  have hterm (i : Option (Fin (n+1))) :
      normalizedInterpolation u a 0 e i*interpolationNodes u a i^(e-1)=
        (interpolationWeights u a 0 i/interpolationNodes u a i)/interpolationNormalizer u a 0 e := by
    unfold normalizedInterpolation weightedInterpolation
    have hx := interpolationNodes_pos u ha hau i
    have hp : interpolationNodes u a i^(-e)*interpolationNodes u a i^(e-1)=
        (interpolationNodes u a i)⁻¹ := by
      rw [←Real.rpow_add hx, show -e+(e-1)=(-1:ℝ) by ring, Real.rpow_neg_one]
    rw [div_mul_eq_mul_div, mul_assoc, hp]
    ring
  simp_rw [hterm]
  rw [←Finset.sum_div, interpolationWeights_inverse_moment u hu (fun i => (ha.trans (hau i)).ne') ha.ne']
  ring

/-- The positive-sign tensor has exactly the source's one-moment defect,
including both nodal-product factors. -/
theorem positive_tensor_defect_exact {ns nc : ℕ}
    (u : Fin (ns+1)→ℝ) (w : Fin (nc+1)→ℝ)
    (hu : Function.Injective u) (hw : Function.Injective w)
    {a b ρ s : ℝ} (ha : 0<a) (hb : 0<b)
    (hau : ∀ i, a<u i) (hbw : ∀ j, b<w j) :
    (∑ i, normalizedInterpolation u a ρ s i*(interpolationNodes u a i/a)^s)*
      (∑ j, normalizedInterpolation w b 0 (1-s) j*interpolationNodes w b j^(-s))=
      ρ*interpolationProduct u a*interpolationProduct w b*
        (a^(-s)*b⁻¹/(interpolationNormalizer u a ρ s*interpolationNormalizer w b 0 (1-s))) := by
  rw [scaled_signed_power_sum _ _ ha (interpolationNodes_pos u ha hau),
    normalizedInterpolation_lowest_moment u hu ha hau]
  have hi := normalizedInterpolation_inverse_shift w hw (e:=1-s) hb hbw
  rw [show 1-s-1= -s by ring] at hi
  rw [hi, Real.rpow_neg ha.le]
  ring

/-- The negative-sign tensor has the complementary exact one-moment defect. -/
theorem negative_tensor_defect_exact {nc ns : ℕ}
    (u : Fin (nc+1)→ℝ) (w : Fin (ns+1)→ℝ)
    (hu : Function.Injective u) (hw : Function.Injective w)
    {a b ρ s : ℝ} (ha : 0<a) (hb : 0<b)
    (hau : ∀ i, a<u i) (hbw : ∀ j, b<w j) :
    (∑ i, normalizedInterpolation u a 0 (1-s) i*(interpolationNodes u a i/a)^(-s))*
      (∑ j, normalizedInterpolation w b ρ s j*interpolationNodes w b j^s)=
      ρ*interpolationProduct u a*interpolationProduct w b*
        (a^(s-1)/(interpolationNormalizer u a 0 (1-s)*interpolationNormalizer w b ρ s)) := by
  rw [scaled_signed_power_sum _ _ ha (interpolationNodes_pos u ha hau),
    normalizedInterpolation_lowest_moment w hw hb hbw]
  have hi := normalizedInterpolation_inverse_shift u hu (e:=1-s) ha hau
  rw [show 1-s-1= -s by ring] at hi
  rw [hi, Real.rpow_neg ha.le, Real.rpow_sub_one ha.ne']
  simp only [div_inv_eq_mul]
  ring

/-- Nodal products are in `(0,1]`, so the exact defect is bounded by the
perturbation times its principal normalization factor. -/
theorem interpolationProduct_le_one {n : ℕ} (u : Fin (n+1)→ℝ)
    {a : ℝ} (ha : 0<a) (hau : ∀ i, a<u i) : interpolationProduct u a≤1 := by
  unfold interpolationProduct
  apply Finset.prod_le_one
  · intro i _
    have hui := ha.trans (hau i)
    have hh := (div_lt_one hui).mpr (hau i)
    linarith
  · intro i _
    have hh : 0≤a/u i := div_nonneg ha.le (ha.trans (hau i)).le
    linarith

/-- Any actual atom with small count mean gives a Poisson likelihood lower
bound for every count up to its selected moment degree. -/
theorem poissonMixture_atom_lower {ι : Type*} [Fintype ι]
    (p : FiniteAtomicPrior ι) {θ D : ℝ} {r j : ℕ} (i : ι)
    (hθ : 0≤θ) (hv : ∀ t, 0≤p.value t) (hD : D≤p.mass i*p.value i^r)
    (hsmall : θ*p.value i≤1) (hjr : j≤r) :
    Real.exp (-1)*θ^r*D/(j.factorial:ℝ)≤poissonMixture p.mass p.value θ j := by
  have hz : 0≤θ*p.value i := mul_nonneg hθ (hv i)
  have hpow : (θ*p.value i)^r≤(θ*p.value i)^j :=
    pow_le_pow_of_le_one hz hsmall hjr
  have he : Real.exp (-1)≤Real.exp (-(θ*p.value i)) := Real.exp_le_exp.mpr (by linarith)
  have hsingle := Finset.single_le_sum (s:=(Finset.univ:Finset ι))
    (f:=fun t => p.mass t*(Real.exp (-(θ*p.value t))*(θ*p.value t)^j/(j.factorial:ℝ)))
    (fun t _ => by
      have hm := p.mass_nonneg t
      have hv := hv t
      positivity) (Finset.mem_univ i)
  apply le_trans _ hsingle
  have hd := mul_le_mul_of_nonneg_left hD (show 0≤Real.exp (-1)*θ^r by positivity)
  have hpe := mul_le_mul he hpow (pow_nonneg hz _) (Real.exp_nonneg _)
  have hm := mul_le_mul_of_nonneg_left hpe (p.mass_nonneg i)
  have hnum : Real.exp (-1)*θ^r*D≤p.mass i*(Real.exp (-(θ*p.value i))*(θ*p.value i)^j) := by
    rw [mul_pow] at hm
    nlinarith only [hd, hm]
  have hdiv := div_le_div_of_nonneg_right hnum (by positivity : (0:ℝ)≤j.factorial)
  convert hdiv using 1
  ring



/-- The contribution of one reweighted atom to any positive real moment. -/
theorem reweightedPrior_atom_moment {ι : Type*} [Fintype ι]
    (μ z : ι→ℝ) (B Z α : ℝ) (hμ : ∀ i, 0≤μ i) (hB : 0<B) (hZ : 0<Z)
    (hz : ∀ i, 0<z i) (hv : ∀ i, 1≤B*z i)
    (hZdef : Z=∑ i, μ i*z i^(1-α)) (i : ι) (j : ℝ) :
    let p := reweightedPrior μ z B Z α hμ hB hZ hz hv hZdef
    p.mass (some i)*p.value (some i)^j=
      B^(j-1)/Z*(μ i*z i^(j-α)) := by
  change reweightedMass μ z B Z α i*(B*z i)^j=_
  have hpz : z i^(-α)*z i^j=z i^(j-α) := by
    rw [←Real.rpow_add (hz i)]
    congr 1
    ring
  have hpB : B^(j-1)=B^j/B := Real.rpow_sub_one hB.ne' j
  unfold reweightedMass
  rw [Real.mul_rpow hB.le (hz i).le, hpB]
  calc
    μ i/(B*Z)*z i^(-α)*(B^j*z i^j)=(B^j/B)/Z*(μ i*(z i^(-α)*z i^j)) := by ring
    _=_ := by rw [hpz]

/-- The two designated positive-sign atoms carry the full principal defect
scale in opposite parity measures. -/
theorem positive_tensor_designated_atoms {ns nc : ℕ}
    (u : Fin (ns+1)→ℝ) (w : Fin (nc+1)→ℝ) {a b ρ s : ℝ}
    (ha : 0<a) (hb : 0<b) (hu : ∀ i, 0<u i) (_hw : ∀ j, 0<w j)
    (hρ : 0≤ρ) (hfirst : 1≤lagrangeWeight u a 0) :
    let l := normalizedInterpolation u a ρ s
    let t := normalizedInterpolation w b 0 (1-s)
    let U := interpolationNodes u a
    let W := interpolationNodes w b
    let z := tensorAtom U W a
    let D := a^(-s)*b⁻¹/(interpolationNormalizer u a ρ s*interpolationNormalizer w b 0 (1-s))
    D≤tensorPositive l t (none,none)*z (none,none)^(-s) ∧
      D≤tensorNegative l t (some 0,none)*z (some 0,none)^(-s) := by
  let Ps := interpolationNormalizer u a ρ s
  let Pc := interpolationNormalizer w b 0 (1-s)
  have hPs : 0<Ps := interpolationNormalizer_pos u ha hρ
  have hPc : 0<Pc := interpolationNormalizer_pos w hb (by norm_num)
  have hn : 0≤(1+ρ)*a^(-s)/Ps := by positivity
  have ht : 0≤b^(-(1-s))/Pc := by positivity
  have hnode : 0≤lagrangeWeight u a 0*(1+ρ*a/u 0)*(u 0)^(-s)/Ps := by
    have hp : 0≤lagrangeWeight u a 0 := by linarith
    have hu0 := hu 0
    positivity
  have hlnone : normalizedInterpolation u a ρ s none=(1+ρ)*a^(-s)/Ps := rfl
  have htnone : normalizedInterpolation w b 0 (1-s) none=b^(-(1-s))/Pc := by
    simp [normalizedInterpolation, weightedInterpolation, interpolationWeights, interpolationNodes, Pc]
  have hlsome : normalizedInterpolation u a ρ s (some 0)=
      -(lagrangeWeight u a 0*(1+ρ*a/u 0)*(u 0)^(-s)/Ps) := by
    simp only [normalizedInterpolation, weightedInterpolation, interpolationWeights, interpolationNodes, Option.elim_some]
    dsimp [Ps]
    ring
  have hp : tensorPositive (normalizedInterpolation u a ρ s)
      (normalizedInterpolation w b 0 (1-s)) (none,none)=
      ((1+ρ)*a^(-s)/Ps)*(b^(-(1-s))/Pc) := by
    simp only [tensorPositive, hlnone, htnone, positiveCoeff, negativeCoeff,
      max_eq_left hn, max_eq_left ht, max_eq_right (neg_nonpos.mpr hn),
      max_eq_right (neg_nonpos.mpr ht), zero_mul, add_zero]
  have hm : tensorNegative (normalizedInterpolation u a ρ s)
      (normalizedInterpolation w b 0 (1-s)) (some 0,none)=
      (lagrangeWeight u a 0*(1+ρ*a/u 0)*(u 0)^(-s)/Ps)*(b^(-(1-s))/Pc) := by
    simp only [tensorNegative, hlsome, htnone, positiveCoeff, negativeCoeff, neg_neg,
      max_eq_right (neg_nonpos.mpr hnode), max_eq_left hnode, max_eq_left ht,
      zero_mul, zero_add]
  have hz0 : tensorAtom (interpolationNodes u a) (interpolationNodes w b) a (none,none)=b := by
    simp [tensorAtom, interpolationNodes, ha.ne']
  have hz1 : tensorAtom (interpolationNodes u a) (interpolationNodes w b) a (some 0,none)=a*b/u 0 := rfl
  have hpb : b^(-(1-s))*b^(-s)=b⁻¹ := by
    rw [←Real.rpow_add hb, show -(1-s)+(-s)=(-1:ℝ) by ring, Real.rpow_neg_one]
  have hpu : (u 0)^(-s)*(a*b/u 0)^(-s)=a^(-s)*b^(-s) := by
    rw [←Real.mul_rpow (hu 0).le (div_pos (mul_pos ha hb) (hu 0)).le]
    rw [show u 0*(a*b/u 0)=a*b by field_simp [(hu 0).ne']]
    rw [Real.mul_rpow ha.le hb.le]
  dsimp only
  rw [hp, hm, hz0, hz1]
  have hDp : 0≤a^(-s)*b⁻¹/(Ps*Pc) := by positivity
  constructor
  · have heq : ((1+ρ)*a^(-s)/Ps)*(b^(-(1-s))/Pc)*b^(-s)=
        (1+ρ)*(a^(-s)*b⁻¹/(Ps*Pc)) := by
      calc
        _=(1+ρ)*a^(-s)*(b^(-(1-s))*b^(-s))/(Ps*Pc) := by ring
        _=_ := by rw [hpb]; ring
    rw [heq]
    nlinarith
  · have heq : (lagrangeWeight u a 0*(1+ρ*a/u 0)*(u 0)^(-s)/Ps)*
        (b^(-(1-s))/Pc)*(a*b/u 0)^(-s)=
        (lagrangeWeight u a 0*(1+ρ*a/u 0))*(a^(-s)*b⁻¹/(Ps*Pc)) := by
      calc
        _=(lagrangeWeight u a 0*(1+ρ*a/u 0))*b^(-(1-s))*
          ((u 0)^(-s)*(a*b/u 0)^(-s))/(Ps*Pc) := by ring
        _=(lagrangeWeight u a 0*(1+ρ*a/u 0))*a^(-s)*
          (b^(-(1-s))*b^(-s))/(Ps*Pc) := by rw [hpu]; ring
        _=_ := by rw [hpb]; ring
    rw [heq]
    have hf : 1≤lagrangeWeight u a 0*(1+ρ*a/u 0) :=
      one_le_mul_of_one_le_of_one_le hfirst (by
        have hh : 0≤ρ*a/u 0 := div_nonneg (mul_nonneg hρ ha.le) (hu 0).le
        linarith)
    nlinarith



/-- The analogous two atoms for a high active factor lie in opposite parity
measures and carry the same principal defect scale. -/
theorem negative_tensor_designated_atoms {nc ns : ℕ}
    (u : Fin (nc+1)→ℝ) (w : Fin (ns+1)→ℝ) {a b ρ s : ℝ}
    (ha : 0<a) (hb : 0<b) (_hu : ∀ i, 0<u i) (hw : ∀ j, 0<w j)
    (hρ : 0≤ρ) (hfirst : 1≤lagrangeWeight w b 0) :
    let l := normalizedInterpolation u a 0 (1-s)
    let t := normalizedInterpolation w b ρ s
    let U := interpolationNodes u a
    let W := interpolationNodes w b
    let z := tensorAtom U W a
    let D := a^(s-1)/(interpolationNormalizer u a 0 (1-s)*interpolationNormalizer w b ρ s)
    D≤tensorPositive l t (none,none)*z (none,none)^s ∧
      D≤tensorNegative l t (none,some 0)*z (none,some 0)^s := by
  let Pc := interpolationNormalizer u a 0 (1-s)
  let Ps := interpolationNormalizer w b ρ s
  have hPc : 0<Pc := interpolationNormalizer_pos u ha (by norm_num)
  have hPs : 0<Ps := interpolationNormalizer_pos w hb hρ
  have hn : 0≤a^(-(1-s))/Pc := by positivity
  have ht : 0≤(1+ρ)*b^(-s)/Ps := by positivity
  have hnode : 0≤lagrangeWeight w b 0*(1+ρ*b/w 0)*(w 0)^(-s)/Ps := by
    have hp : 0≤lagrangeWeight w b 0 := by linarith
    have hw0 := hw 0
    positivity
  have hlnone : normalizedInterpolation u a 0 (1-s) none=a^(-(1-s))/Pc := by
    simp [normalizedInterpolation, weightedInterpolation, interpolationWeights, interpolationNodes, Pc]
  have htnone : normalizedInterpolation w b ρ s none=(1+ρ)*b^(-s)/Ps := rfl
  have htsome : normalizedInterpolation w b ρ s (some 0)=
      -(lagrangeWeight w b 0*(1+ρ*b/w 0)*(w 0)^(-s)/Ps) := by
    simp only [normalizedInterpolation, weightedInterpolation, interpolationWeights, interpolationNodes, Option.elim_some]
    dsimp [Ps]
    ring
  have hp : tensorPositive (normalizedInterpolation u a 0 (1-s))
      (normalizedInterpolation w b ρ s) (none,none)=
      (a^(-(1-s))/Pc)*((1+ρ)*b^(-s)/Ps) := by
    simp only [tensorPositive, hlnone, htnone, positiveCoeff, negativeCoeff,
      max_eq_left hn, max_eq_left ht, max_eq_right (neg_nonpos.mpr hn),
      max_eq_right (neg_nonpos.mpr ht), zero_mul, add_zero]
  have hm : tensorNegative (normalizedInterpolation u a 0 (1-s))
      (normalizedInterpolation w b ρ s) (none,some 0)=
      (a^(-(1-s))/Pc)*(lagrangeWeight w b 0*(1+ρ*b/w 0)*(w 0)^(-s)/Ps) := by
    simp only [tensorNegative, hlnone, htsome, positiveCoeff, negativeCoeff, neg_neg,
      max_eq_right (neg_nonpos.mpr hn), max_eq_left hn, max_eq_left hnode,
      zero_mul, add_zero]
  have hz0 : tensorAtom (interpolationNodes u a) (interpolationNodes w b) a (none,none)=b := by
    simp [tensorAtom, interpolationNodes, ha.ne']
  have hz1 : tensorAtom (interpolationNodes u a) (interpolationNodes w b) a (none,some 0)=w 0 := by
    simp [tensorAtom, interpolationNodes, ha.ne']
  have hpb : b^(-s)*b^s=1 := by rw [←Real.rpow_add hb]; simp
  have hpw : (w 0)^(-s)*(w 0)^s=1 := by rw [←Real.rpow_add (hw 0)]; simp
  have hex : -(1-s)=s-1 := by ring
  dsimp only
  rw [hp, hm, hz0, hz1]
  have hDp : 0≤a^(s-1)/(Pc*Ps) := by positivity
  constructor
  · have heq : (a^(-(1-s))/Pc)*((1+ρ)*b^(-s)/Ps)*b^s=(1+ρ)*(a^(s-1)/(Pc*Ps)) := by
      calc
        _=(1+ρ)*a^(-(1-s))*(b^(-s)*b^s)/(Pc*Ps) := by ring
        _=_ := by rw [hpb, hex]; ring
    rw [heq]
    nlinarith
  · have heq : (a^(-(1-s))/Pc)*(lagrangeWeight w b 0*(1+ρ*b/w 0)*(w 0)^(-s)/Ps)*(w 0)^s=
        (lagrangeWeight w b 0*(1+ρ*b/w 0))*(a^(s-1)/(Pc*Ps)) := by
      calc
        _=(lagrangeWeight w b 0*(1+ρ*b/w 0))*a^(-(1-s))*((w 0)^(-s)*(w 0)^s)/(Pc*Ps) := by ring
        _=_ := by rw [hpw, hex]; ring
    rw [heq]
    have hf : 1≤lagrangeWeight w b 0*(1+ρ*b/w 0) :=
      one_le_mul_of_one_le_of_one_le hfirst (by
        have hh : 0≤ρ*b/w 0 := div_nonneg (mul_nonneg hρ hb.le) (hw 0).le
        linarith)
    nlinarith



/-- Reweighting transfers a designated tensor atom into the exact likelihood
lower bound used by the one-defect count-distance theorem. -/
theorem reweightedPrior_count_atom_lower {ι : Type*} [Fintype ι]
    (μ z : ι→ℝ) (B Z α : ℝ) (hμ : ∀ i, 0≤μ i) (hB : 0<B) (hZ : 0<Z)
    (hz : ∀ i, 0<z i) (hv : ∀ i, 1≤B*z i)
    (hZdef : Z=∑ i, μ i*z i^(1-α))
    {θ D : ℝ} {r j : ℕ} (i : ι) (hθ : 0≤θ)
    (hD : D≤μ i*z i^((r:ℝ)-α)) (hsmall : θ*(B*z i)≤1) (hjr : j≤r) :
    let p := reweightedPrior μ z B Z α hμ hB hZ hz hv hZdef
    Real.exp (-1)*θ^r*(B^((r:ℝ)-1)/Z*D)/(j.factorial:ℝ)≤
      poissonMixture p.mass p.value θ j := by
  let p := reweightedPrior μ z B Z α hμ hB hZ hz hv hZdef
  have hpv : ∀ t, 0≤p.value t := by
    intro t
    cases t with
    | none => exact le_rfl
    | some t => exact (mul_pos hB (hz t)).le
  have hmoment := reweightedPrior_atom_moment μ z B Z α hμ hB hZ hz hv hZdef i (r:ℝ)
  change p.mass (some i)*p.value (some i)^(r:ℝ)=_ at hmoment
  rw [Real.rpow_natCast] at hmoment
  have hd : B^((r:ℝ)-1)/Z*D≤p.mass (some i)*p.value (some i)^r := by
    rw [hmoment]
    exact mul_le_mul_of_nonneg_left hD (by positivity)
  exact poissonMixture_atom_lower p (some i) hθ hpv hd hsmall hjr



/-- The actual complementary principal point is no larger than its
normalization scale divided by the squared interpolation dimension. -/
theorem complementary_principal_point_upper {ξ ζ κ d : ℝ}
    (hξ : 0<ξ) (hξ1 : ξ≤1) (hζ : 0<ζ) (hζ1 : ζ≤1)
    (hκ : 0<κ) (hκ1 : κ≤1) (hd : 0<d) :
    Real.exp (-5)*(ξ/d^2)*(ζ*κ)^(1/ξ)≤ζ/d^2 := by
  have hz : 0≤ζ*κ := mul_nonneg hζ.le hκ.le
  have hz1 : ζ*κ≤1 := mul_le_one₀ hζ1 hκ.le hκ1
  have he : 1≤1/ξ := (le_div_iff₀ hξ).mpr (by linarith)
  have hp := Real.rpow_le_self_of_le_one hz hz1 he
  have hpζ : (ζ*κ)^(1/ξ)≤ζ := hp.trans (mul_le_of_le_one_right hζ.le hκ1)
  have hbase : Real.exp (-5)*(ξ/d^2)≤1/d^2 := by
    have hexp : Real.exp (-5)≤1 := Real.exp_le_one_iff.mpr (by norm_num)
    have hh := mul_le_mul hexp hξ1 hξ.le (by norm_num : (0:ℝ)≤1)
    have hh' := div_le_div_of_nonneg_right hh (sq_nonneg d)
    convert hh' using 1 <;> ring
  have hh := mul_le_mul hbase hpζ (Real.rpow_nonneg hz _) (by positivity : 0≤1/d^2)
  convert hh using 1
  ring

/-- A degree at least ten times the order leaves at least half the nodes
in the long interpolation factor, in either sign convention. -/
theorem lower_long_dimension {L r : ℕ} {α : ℝ}
    (hr : (r:ℝ)≤α) (hL : 10*α≤L) :
    (L:ℝ)≤2*(((L-r:ℕ):ℝ)+1) := by
  have hrL : r≤L := by
    have hr0 : (0:ℝ)≤r := Nat.cast_nonneg _
    have hh : (r:ℝ)≤L := by nlinarith
    exact_mod_cast hh
  rw [Nat.cast_sub hrL]
  nlinarith [Nat.cast_nonneg (α:=ℝ) r]

/-- Both designated atoms in the positive sign have count means below one
at the common support/intensity product. -/
theorem positive_designated_count_means {L d ζ κ ξ a θ u : ℝ}
    (hL : 0≤L) (hd : 1≤d) (hLd : L≤2*d)
    (hζ : 0<ζ) (hζ1 : ζ≤1/8) (hκ : 0<κ) (hκ1 : κ≤1)
    (hξ : 0<ξ) (hξ1 : ξ≤1) (ha : 0<a) (hau : a≤u) (hθ : 0≤θ)
    (hscale : θ/a=(1/100)*L*(Real.exp (-5)*(ξ/d^2)*(ζ*κ)^(1/ξ))) :
    θ/a≤1 ∧ θ/u≤1 := by
  have hd0 : 0<d := by linarith
  have hac := complementary_principal_point_upper hξ hξ1 hζ (by linarith) hκ hκ1 hd0
  have hh := mul_le_mul_of_nonneg_left hac (show 0≤(1/100)*L by positivity)
  have hl : L/d^2≤2 := (div_le_iff₀ (sq_pos_of_pos hd0)).mpr (by nlinarith)
  have hnum : (1/100)*L*(ζ/d^2)≤1 := by
    have hh := mul_le_mul_of_nonneg_left hl (show 0≤ζ/100 by positivity)
    ring_nf at hh ⊢
    nlinarith only [hh, hζ1]
  have hsmall : θ/a≤1 := by rw [hscale]; exact hh.trans hnum
  refine ⟨hsmall, (div_le_div_of_nonneg_left hθ ha hau).trans hsmall⟩

/-- The corresponding high-active atom is also small in the negative sign. -/
theorem negative_designated_count_means {L d ζ a b θ : ℝ}
    (_hL : 0≤L) (hd : 1≤d) (hLd : L≤2*d)
    (hζ : 0<ζ) (hζ1 : ζ≤1/8) (ha : 0<a) (hb : 0<b) (hθ : 0≤θ)
    (hbsmall : b≤(ζ/8)/d^2)
    (hscale : θ*(a*b)⁻¹=(1/100)*L) :
    θ/a≤1 ∧ θ*(a*b)⁻¹*((ζ/8)/d^2)≤1 := by
  have hd0 : 0<d := by linarith
  have hl : L/d^2≤2 := (div_le_iff₀ (sq_pos_of_pos hd0)).mpr (by nlinarith)
  have hsmall : θ*(a*b)⁻¹*((ζ/8)/d^2)≤1 := by
    rw [hscale]
    have hh := mul_le_mul_of_nonneg_left hl (show 0≤ζ/800 by positivity)
    ring_nf at hh ⊢
    nlinarith only [hh, hζ1]
  refine ⟨?_, hsmall⟩
  calc
    θ/a=θ*(a*b)⁻¹*b := by field_simp
    _≤θ*(a*b)⁻¹*((ζ/8)/d^2) := mul_le_mul_of_nonneg_left hbsmall (by positivity)
    _≤1 := hsmall



/-- In the positive-sign construction the actual signed moment defect is
at most rho times the same scale supplied by the designated atoms. -/
theorem positive_tensor_defect_bound {ns nc : ℕ}
    (u : Fin (ns+1)→ℝ) (w : Fin (nc+1)→ℝ)
    (hu : Function.Injective u) (hw : Function.Injective w)
    {a b ρ s F : ℝ} (ha : 0<a) (hb : 0<b) (hρ : 0≤ρ) (hF : 0≤F)
    (hau : ∀ i, a<u i) (hbw : ∀ j, b<w j) :
    |F*((∑ i, normalizedInterpolation u a ρ s i*(interpolationNodes u a i/a)^s)*
      (∑ j, normalizedInterpolation w b 0 (1-s) j*interpolationNodes w b j^(-s)))|≤
      ρ*(F*(a^(-s)*b⁻¹/(interpolationNormalizer u a ρ s*interpolationNormalizer w b 0 (1-s)))) := by
  rw [positive_tensor_defect_exact u w hu hw ha hb hau hbw]
  have hC₀ := (interpolationProduct_pos u ha hau).le
  have hC₁ := (interpolationProduct_pos w hb hbw).le
  have hC := mul_le_one₀ (interpolationProduct_le_one u ha hau) hC₁ (interpolationProduct_le_one w hb hbw)
  have hPs := interpolationNormalizer_pos u (e:=s) ha hρ
  have hPc := interpolationNormalizer_pos w (e:=1-s) hb (show (0:ℝ)≤0 by norm_num)
  have hD : 0≤a^(-s)*b⁻¹/(interpolationNormalizer u a ρ s*interpolationNormalizer w b 0 (1-s)) := by positivity
  rw [abs_of_nonneg (by positivity)]
  have hh := mul_le_mul_of_nonneg_left hC (show 0≤ρ*F*(a^(-s)*b⁻¹/
    (interpolationNormalizer u a ρ s*interpolationNormalizer w b 0 (1-s))) by positivity)
  nlinarith only [hh]

/-- The negative-sign defect is controlled by its designated-atom scale. -/
theorem negative_tensor_defect_bound {nc ns : ℕ}
    (u : Fin (nc+1)→ℝ) (w : Fin (ns+1)→ℝ)
    (hu : Function.Injective u) (hw : Function.Injective w)
    {a b ρ s F : ℝ} (ha : 0<a) (hb : 0<b) (hρ : 0≤ρ) (hF : 0≤F)
    (hau : ∀ i, a<u i) (hbw : ∀ j, b<w j) :
    |F*((∑ i, normalizedInterpolation u a 0 (1-s) i*(interpolationNodes u a i/a)^(-s))*
      (∑ j, normalizedInterpolation w b ρ s j*interpolationNodes w b j^s))|≤
      ρ*(F*(a^(s-1)/(interpolationNormalizer u a 0 (1-s)*interpolationNormalizer w b ρ s))) := by
  rw [negative_tensor_defect_exact u w hu hw ha hb hau hbw]
  have hC₀ := (interpolationProduct_pos u ha hau).le
  have hC₁ := (interpolationProduct_pos w hb hbw).le
  have hC := mul_le_one₀ (interpolationProduct_le_one u ha hau) hC₁ (interpolationProduct_le_one w hb hbw)
  have hPc := interpolationNormalizer_pos u (e:=1-s) ha (show (0:ℝ)≤0 by norm_num)
  have hPs := interpolationNormalizer_pos w (e:=s) hb hρ
  have hD : 0≤a^(s-1)/(interpolationNormalizer u a 0 (1-s)*interpolationNormalizer w b ρ s) := by positivity
  rw [abs_of_nonneg (by positivity)]
  have hh := mul_le_mul_of_nonneg_left hC (show 0≤ρ*F*(a^(s-1)/
    (interpolationNormalizer u a 0 (1-s)*interpolationNormalizer w b ρ s)) by positivity)
  nlinarith only [hh]



/-- The atom moment identity only uses the explicit coefficient and value;
it applies directly to the priors returned by `tensor_priors_with_atoms`. -/
theorem prior_atom_moment_of_reweightedMass {ι : Type*} [Fintype ι]
    (p : FiniteAtomicPrior ι) {μ z B Z α : ℝ} (i : ι)
    (hB : 0<B) (hz : 0<z)
    (hmass : p.mass i=μ/(B*Z)*z^(-α)) (hvalue : p.value i=B*z) (j : ℝ) :
    p.mass i*p.value i^j=B^(j-1)/Z*(μ*z^(j-α)) := by
  rw [hmass,hvalue,Real.mul_rpow hB.le hz.le,Real.rpow_sub_one hB.ne']
  have hp : z^(-α)*z^j=z^(j-α) := by
    rw [←Real.rpow_add hz]
    congr 1
    ring
  calc
    _=(B^j/B)/Z*(μ*(z^(-α)*z^j)) := by ring
    _=_ := by rw [hp]

/-- Direct likelihood transfer for a designated atom of either explicit
parity prior. The supplied inputs are its actual coefficient identities. -/
theorem prior_count_atom_of_reweightedMass {ι : Type*} [Fintype ι]
    (p : FiniteAtomicPrior ι) {μ z B Z α θ D : ℝ} {r j : ℕ} (i : ι)
    (hB : 0<B) (hZ : 0<Z) (hz : 0<z) (hθ : 0≤θ)
    (hv : ∀ t, 0≤p.value t)
    (hmass : p.mass i=μ/(B*Z)*z^(-α)) (hvalue : p.value i=B*z)
    (hD : D≤μ*z^((r:ℝ)-α)) (hsmall : θ*(B*z)≤1) (hjr : j≤r) :
    Real.exp (-1)*θ^r*(B^((r:ℝ)-1)/Z*D)/(j.factorial:ℝ)≤
      poissonMixture p.mass p.value θ j := by
  have hmoment := prior_atom_moment_of_reweightedMass p i hB hz hmass hvalue (r:ℝ)
  rw [Real.rpow_natCast] at hmoment
  have hd : B^((r:ℝ)-1)/Z*D≤p.mass i*p.value i^r := by
    rw [hmoment]
    exact mul_le_mul_of_nonneg_left hD (by positivity)
  exact poissonMixture_atom_lower p i hθ hv hd (by rwa [hvalue]) hjr

end Renyi
