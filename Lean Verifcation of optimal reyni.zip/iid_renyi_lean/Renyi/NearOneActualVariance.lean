import Renyi.NearOneVariance
import Renyi.NearOneUniformDegree

/-! Full variance of the actual calibrated near-one polynomial/Gamma statistic.
The coefficient constant is chosen before the logarithmic degree slope. -/
set_option maxHeartbeats 800000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Polynomial
namespace Renyi

def simplexPoissonMeans {k : ℕ} (n : ℝ) (p : Simplex k) : Fin k → ℝ≥0 :=
  fun i => Real.toNNReal (n * p.mass i)

def nearOneHybridVarianceBudget {iota : Type*} [Fintype iota] (lam : iota → ℝ≥0)
    (n t b beta A Cw Cq T M : ℝ) (d : ℕ) : ℝ :=
  4 * beta ^ 2 / n ^ (2 * (1 + beta)) * (∑ i, nearOneGammaVarianceEnvelope beta (n * t) Cw (lam i)) +
  8 * (Fintype.card iota : ℝ) * (((d : ℝ) + 1) ^ 2 * (beta * A) ^ 2 * Real.exp (T + M * d) * b ^ (2 * (1 + beta))) +
  8 * (Fintype.card iota : ℝ) * ((6 : ℝ) ^ (6 : ℕ) * Real.exp T * gammaResidualPilotConstant Cw ^ 2 * beta ^ 2 /
    n ^ (2 * (1 + beta)) * (1 + |Real.log (n * t)|) ^ 2) +
  2 * Cq ^ 2 * beta ^ 2 * t ^ (2 * beta) / n

variable {Omega : Type*} [MeasurableSpace Omega]

def polynomialNearOneCountStatistic {k : ℕ} (Counts Pilot : Fin k → Omega → ℕ) (P : ℝ[X])
    (n t beta omega T repair : ℝ) (d : ℕ) : Omega → ℝ :=
  nearOneHybridStatistic Counts Pilot n t beta omega T (P.coeff 1) repair d
    ((P - C (t ^ beta) * X).coeff)

def actualNearOneCountStatistic {k : ℕ} (Counts Pilot : Fin k → Omega → ℕ) (N : ℕ)
    (alpha eps Ch D cb lambda CL cL c M cw f cu u0 cp Bpilot repair : ℝ) : Omega → ℝ :=
  let n := upperSample k alpha eps D
  let b := upperB k alpha eps D cb CL cL
  let t := b / (N : ℝ) ^ 2
  let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f (upperRescaling k alpha eps cu u0)
  polynomialNearOneCountStatistic Counts Pilot P n t (alpha - 1) (upperOmega k alpha eps Ch cw)
    (cp * Bpilot * alpha) repair (20 * N)

variable {mu : Measure Omega} [IsProbabilityMeasure mu]

theorem polynomial_near_one_hybrid_variance {k d : ℕ} (Counts Pilot : Fin k → Omega → ℕ)
    (P : ℝ[X]) (lam : Fin k → ℝ≥0) {n t b beta omega A Cw Cq T M cp repair : ℝ}
    (hn : 0 < n) (ht : 0 < t) (hb : 0 < b) (hnt : n * t ≤ 1)
    (hbeta : 0 < beta) (hbeta1 : beta ≤ 1 / 2) (hA : 0 ≤ A)
    (hw0 : 0 ≤ omega) (hw1 : omega ≤ 1) (hCw : 0 ≤ Cw)
    (hwdiff : |omega - 1| ≤ Cw * beta) (hCq : 0 ≤ Cq)
    (hq : |P.coeff 1 - t ^ beta| ≤ Cq * beta * t ^ beta)
    (hcp0 : 0 < cp) (hT : 0 ≤ T) (hM : 0 ≤ M) (hcp : 4 * M ≤ cp) (hcpExp : 2 * Real.exp 1 ≤ cp)
    (hCounts : ∀ i, MeasurePreserving (Counts i) mu (poissonMeasure (lam i)))
    (hPilot : ∀ i, MeasurePreserving (Pilot i) mu
      (poissonMeasure ⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩))
    (hind : ∀ i, IndepFun (Pilot i) (Counts i) mu)
    (hpair : Pairwise (fun i j => IndepFun (fun w => (Pilot i w, Counts i w))
      (fun w => (Pilot j w, Counts j w)) mu))
    (hsum : ∑ i, (lam i : ℝ) = n) (hdegree : (d : ℝ) ≤ M * (n * b))
    (hco : ∀ j : ℕ, j ≤ d → |(P - C (t ^ beta) * X).coeff j| ≤ beta * A * b ^ (1 + beta - j)) :
    MemLp (polynomialNearOneCountStatistic Counts Pilot P n t beta omega T repair d) 2 mu ∧
      variance (polynomialNearOneCountStatistic Counts Pilot P n t beta omega T repair d) mu ≤
        nearOneHybridVarianceBudget lam n t b beta A Cw Cq T M d := by
  have h := near_one_hybrid_variance (μ := mu) (ι := Fin k) (n := n) (t := t) (b := b) (beta := beta) (A := A)
    (omega := omega) (Cw := Cw) (Cq := Cq) (cp := cp) (T := T) (M := M)
    (q := P.coeff 1) (repair := repair) hn ht hb hnt hbeta hbeta1 hA hw0 hw1 hCw hwdiff hCq hq hcp0 hT hM hcp hcpExp
    Counts Pilot lam hCounts hPilot hind hpair hsum d hdegree ((P - C (t ^ beta) * X).coeff) hco
  simpa only [polynomialNearOneCountStatistic, nearOneHybridVarianceBudget] using h

/-- The full actual near-one variance, with all coefficient and affine
premises discharged for the calibrated polynomial. K is uniform in cL. -/
theorem actual_near_one_variance_degree_uniform
    {eps cb lambda CL cmin q Q M cw f cu u0 cp Bpilot : ℝ}
    (heps : 0 < eps) (hcb : 0 < cb) (hlambda : 0 < lambda) (hCL : 1 ≤ CL)
    (hCLq : cb ≤ q ^ 2 * CL) (hcmin : 0 < cmin) (hq : 0 < q) (hQ : 0 < Q)
    (hM : 0 ≤ M) (hcw : 0 < cw) (hcw1 : cw < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hcu : 0 ≤ cu) (hu0 : 0 < u0) (hcp0 : 0 < cp) (hcp : 4 * (20 * Q / cb) ≤ cp)
    (hcpExp : 2 * Real.exp 1 ≤ cp) (hBpilot : 0 ≤ Bpilot) :
    ∃ K : ℝ, 0 < K ∧ ∀ (cL : ℝ), 0 < cL → ∀ (k N : ℕ) (alpha Ch D c repair : ℝ),
      0 < k → 1 < alpha → alpha ≤ 3 / 2 → 0 ≤ Ch → 0 < D → cmin ≤ c → c ≤ 1 →
      q * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ≤ N →
      (N : ℝ) ≤ Q * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) →
      ∀ (p : Simplex k) (Counts Pilot : Fin k → Omega → ℕ),
      let n := upperSample k alpha eps D
      let b := upperB k alpha eps D cb CL cL
      let L := (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)
      let t := b / (N : ℝ) ^ 2
      let lam := simplexPoissonMeans n p
      (∀ i, MeasurePreserving (Counts i) mu (poissonMeasure (lam i))) →
      (∀ i, MeasurePreserving (Pilot i) mu
        (poissonMeasure ⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩)) →
      (∀ i, IndepFun (Pilot i) (Counts i) mu) →
      Pairwise (fun i j => IndepFun (fun w => (Pilot i w, Counts i w)) (fun w => (Pilot j w, Counts j w)) mu) →
      MemLp (actualNearOneCountStatistic Counts Pilot N alpha eps Ch D cb lambda CL cL c M cw f cu u0 cp Bpilot repair) 2 mu ∧
      variance (actualNearOneCountStatistic Counts Pilot N alpha eps Ch D cb lambda CL cL c M cw f cu u0 cp Bpilot repair) mu ≤
        nearOneHybridVarianceBudget lam n t b (alpha - 1) (K * Real.exp (K * L)) (2 * cw * eps) K
          (cp * Bpilot * alpha) (20 * Q / cb) (20 * N) := by
  obtain ⟨K0, hK0, haff⟩ := actual_near_one_affine_degree_uniform (f := f) heps hcb hlambda hCL hcmin hq hQ hM hcw hcw1 hcu hu0
  obtain ⟨K1, hK1, hcoeff⟩ := actual_near_one_residual_coefficients_degree_uniform heps hcb hlambda hCL hcmin hq hQ hM hcw hcw1 hf hf1 hcu hu0
  let K := K0 + K1 + 1
  have hK : 0 < K := by dsimp [K]; positivity
  have hK0K : K0 ≤ K := by dsimp [K]; linarith
  have hK1K : K1 ≤ K := by dsimp [K]; linarith
  refine ⟨K, hK, ?_⟩
  intro cL hcL k N alpha Ch D c repair hk halpha halpha1 hCh hD hc hc1 hNlo hNhi p Counts Pilot
  dsimp only
  intro hCounts hPilot hind hpair
  let n := upperSample k alpha eps D
  let b := upperB k alpha eps D cb CL cL
  let L := (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)
  let t := b / (N : ℝ) ^ 2
  let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f (upperRescaling k alpha eps cu u0)
  let omega := upperOmega k alpha eps Ch cw
  let lam := simplexPoissonMeans n p
  have hbeta : 0 < alpha - 1 := sub_pos.mpr halpha
  have hg : 0 < fractionalPart alpha := by rw [(near_one_order halpha halpha1).2]; exact hbeta
  have hg1 : fractionalPart alpha < 1 := by rw [(near_one_order halpha halpha1).2]; linarith
  have hn : 0 < n := upperSample_pos hk halpha hg hg1 hD
  have hb : 0 < b := upperB_pos hk halpha hg hg1 hD hcb hCL hcL
  have hL : 0 < L := upperDegree_pos halpha hCL hcL (one_le_rootMultiplier halpha hg hg1)
  have hNpos : (0 : ℝ) < N := (mul_pos hq hL).trans_le hNlo
  have ht : 0 < t := div_pos hb (sq_pos_of_pos hNpos)
  have hLge : CL ≤ L := by
    have hh := (upperDegree_bounds halpha hCL hcL (one_le_rootMultiplier (k := k) (ε := eps) halpha hg hg1)).1
    have hm := mul_le_mul_of_nonneg_right halpha.le (by linarith : 0 ≤ CL)
    dsimp [L]
    linarith
  have hcbL : cb ≤ q ^ 2 * L := hCLq.trans (mul_le_mul_of_nonneg_left hLge (sq_nonneg q))
  have hN2 : cb * L ≤ (N : ℝ) ^ 2 := by
    have hs := mul_self_le_mul_self (mul_nonneg hq.le hL.le) hNlo
    have hm := mul_le_mul_of_nonneg_right hcbL hL.le
    nlinarith only [hs, hm]
  have hnb : n * b = cb * L := by
    change n * (cb * L / n) = cb * L
    calc
      n * (cb * L / n) = (n / n) * (cb * L) := by ring
      _ = _ := by rw [div_self hn.ne', one_mul]
  have hnt : n * t ≤ 1 := by
    have he : n * t = n * b / (N : ℝ) ^ 2 := by dsimp [t]; ring
    rw [he, div_le_one (sq_pos_of_pos hNpos), hnb]
    exact hN2
  have hdegree : ((20 * N : ℕ) : ℝ) ≤ (20 * Q / cb) * (n * b) := by
    have he : (20 * Q / cb) * (n * b) = 20 * Q * L := by rw [hnb]; field_simp
    rw [he]
    push_cast
    nlinarith only [hNhi]
  have hE := upper_reserved_interval (k := k) halpha hg hg1 heps hCh
  have hE0 : 0 < upperE0 k alpha eps Ch := (mul_pos heps hbeta).trans_le hE.1
  have hw0 : 0 ≤ omega := (Real.exp_pos _).le
  have hw1 : omega ≤ 1 := Real.exp_le_one_iff.mpr (by nlinarith only [hcw, hE0])
  have hwdiff : |omega - 1| ≤ (2 * cw * eps) * (alpha - 1) := by
    rw [abs_of_nonpos (by linarith : omega - 1 ≤ 0)]
    have hh := (upperOmega_near_one_margins (k := k) halpha halpha1 hg hg1 heps hCh hcw hcw1).2
    change 1 - omega ≤ _ at hh
    linarith
  have hqcoeff := (haff cL hcL k N alpha Ch D c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi).2.1
  have hqbound : |P.coeff 1 - t ^ (alpha - 1)| ≤ K * (alpha - 1) * t ^ (alpha - 1) := by
    have hm := mul_le_mul_of_nonneg_right hK0K (by positivity : 0 ≤ (alpha - 1) * t ^ (alpha - 1))
    exact hqcoeff.trans (by nlinarith only [hm])
  have hco (j : ℕ) (_hj : j ≤ 20 * N) :
      |(P - C (t ^ (alpha - 1)) * X).coeff j| ≤ (alpha - 1) * (K * Real.exp (K * L)) * b ^ (1 + (alpha - 1) - j) := by
    have hh := hcoeff cL hcL k N j alpha Ch D c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
    have he := Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_right hK1K hL.le)
    have hm := mul_le_mul hK1K he (Real.exp_pos _).le hK.le
    have hm' := mul_le_mul_of_nonneg_right hm
      (by positivity : 0 ≤ (alpha - 1) * b ^ (alpha - j))
    rw [show 1 + (alpha - 1) = alpha by ring]
    exact hh.trans (by nlinarith only [hm'])
  have hsum : ∑ i, (lam i : ℝ) = n := by
    have hl (i : Fin k) : (lam i : ℝ) = n * p.mass i := by
      exact Real.coe_toNNReal _ (mul_nonneg hn.le (p.nonneg i))
    simp only [hl, ← Finset.mul_sum, p.normalized, mul_one]
  simp only [actualNearOneCountStatistic]
  change MemLp (polynomialNearOneCountStatistic Counts Pilot P n t (alpha - 1) omega
    (cp * Bpilot * alpha) repair (20 * N)) 2 mu ∧
    variance (polynomialNearOneCountStatistic Counts Pilot P n t (alpha - 1) omega
      (cp * Bpilot * alpha) repair (20 * N)) mu ≤
      nearOneHybridVarianceBudget lam n t b (alpha - 1) (K * Real.exp (K * L)) (2 * cw * eps) K
        (cp * Bpilot * alpha) (20 * Q / cb) (20 * N)
  exact polynomial_near_one_hybrid_variance (repair := repair) Counts Pilot P lam hn ht hb hnt hbeta (by linarith) (by positivity)
    hw0 hw1 (by positivity) hwdiff hK.le hqbound hcp0 (by positivity) (by positivity) hcp hcpExp
      hCounts hPilot hind hpair hsum hdegree hco

theorem actual_near_one_variance_degree_uniform_experiments
    {eps cb lambda CL cmin q Q M cw f cu u0 cp Bpilot : ℝ}
    (heps : 0 < eps) (hcb : 0 < cb) (hlambda : 0 < lambda) (hCL : 1 ≤ CL)
    (hCLq : cb ≤ q ^ 2 * CL) (hcmin : 0 < cmin) (hq : 0 < q) (hQ : 0 < Q)
    (hM : 0 ≤ M) (hcw : 0 < cw) (hcw1 : cw < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hcu : 0 ≤ cu) (hu0 : 0 < u0) (hcp0 : 0 < cp) (hcp : 4 * (20 * Q / cb) ≤ cp)
    (hcpExp : 2 * Real.exp 1 ≤ cp) (hBpilot : 0 ≤ Bpilot) :
    ∃ K : ℝ, 0 < K ∧ ∀ {Omega : Type*} [MeasurableSpace Omega] (mu : Measure Omega) [IsProbabilityMeasure mu], ∀ (cL : ℝ), 0 < cL → ∀ (k N : ℕ) (alpha Ch D c repair : ℝ),
      0 < k → 1 < alpha → alpha ≤ 3 / 2 → 0 ≤ Ch → 0 < D → cmin ≤ c → c ≤ 1 →
      q * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ≤ N →
      (N : ℝ) ≤ Q * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) →
      ∀ (p : Simplex k) (Counts Pilot : Fin k → Omega → ℕ),
      let n := upperSample k alpha eps D
      let b := upperB k alpha eps D cb CL cL
      let L := (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)
      let t := b / (N : ℝ) ^ 2
      let lam := simplexPoissonMeans n p
      (∀ i, MeasurePreserving (Counts i) mu (poissonMeasure (lam i))) →
      (∀ i, MeasurePreserving (Pilot i) mu
        (poissonMeasure ⟨cp * lam i, mul_nonneg hcp0.le (lam i).coe_nonneg⟩)) →
      (∀ i, IndepFun (Pilot i) (Counts i) mu) →
      Pairwise (fun i j => IndepFun (fun w => (Pilot i w, Counts i w)) (fun w => (Pilot j w, Counts j w)) mu) →
      MemLp (actualNearOneCountStatistic Counts Pilot N alpha eps Ch D cb lambda CL cL c M cw f cu u0 cp Bpilot repair) 2 mu ∧
      variance (actualNearOneCountStatistic Counts Pilot N alpha eps Ch D cb lambda CL cL c M cw f cu u0 cp Bpilot repair) mu ≤
        nearOneHybridVarianceBudget lam n t b (alpha - 1) (K * Real.exp (K * L)) (2 * cw * eps) K
          (cp * Bpilot * alpha) (20 * Q / cb) (20 * N) := by
  obtain ⟨K0, hK0, haff⟩ := actual_near_one_affine_degree_uniform (f := f) heps hcb hlambda hCL hcmin hq hQ hM hcw hcw1 hcu hu0
  obtain ⟨K1, hK1, hcoeff⟩ := actual_near_one_residual_coefficients_degree_uniform heps hcb hlambda hCL hcmin hq hQ hM hcw hcw1 hf hf1 hcu hu0
  let K := K0 + K1 + 1
  have hK : 0 < K := by dsimp [K]; positivity
  have hK0K : K0 ≤ K := by dsimp [K]; linarith
  have hK1K : K1 ≤ K := by dsimp [K]; linarith
  refine ⟨K, hK, ?_⟩
  intro Omega instOmega mu instMu cL hcL k N alpha Ch D c repair hk halpha halpha1 hCh hD hc hc1 hNlo hNhi p Counts Pilot
  dsimp only
  intro hCounts hPilot hind hpair
  let n := upperSample k alpha eps D
  let b := upperB k alpha eps D cb CL cL
  let L := (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)
  let t := b / (N : ℝ) ^ 2
  let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f (upperRescaling k alpha eps cu u0)
  let omega := upperOmega k alpha eps Ch cw
  let lam := simplexPoissonMeans n p
  have hbeta : 0 < alpha - 1 := sub_pos.mpr halpha
  have hg : 0 < fractionalPart alpha := by rw [(near_one_order halpha halpha1).2]; exact hbeta
  have hg1 : fractionalPart alpha < 1 := by rw [(near_one_order halpha halpha1).2]; linarith
  have hn : 0 < n := upperSample_pos hk halpha hg hg1 hD
  have hb : 0 < b := upperB_pos hk halpha hg hg1 hD hcb hCL hcL
  have hL : 0 < L := upperDegree_pos halpha hCL hcL (one_le_rootMultiplier halpha hg hg1)
  have hNpos : (0 : ℝ) < N := (mul_pos hq hL).trans_le hNlo
  have ht : 0 < t := div_pos hb (sq_pos_of_pos hNpos)
  have hLge : CL ≤ L := by
    have hh := (upperDegree_bounds halpha hCL hcL (one_le_rootMultiplier (k := k) (ε := eps) halpha hg hg1)).1
    have hm := mul_le_mul_of_nonneg_right halpha.le (by linarith : 0 ≤ CL)
    dsimp [L]
    linarith
  have hcbL : cb ≤ q ^ 2 * L := hCLq.trans (mul_le_mul_of_nonneg_left hLge (sq_nonneg q))
  have hN2 : cb * L ≤ (N : ℝ) ^ 2 := by
    have hs := mul_self_le_mul_self (mul_nonneg hq.le hL.le) hNlo
    have hm := mul_le_mul_of_nonneg_right hcbL hL.le
    nlinarith only [hs, hm]
  have hnb : n * b = cb * L := by
    change n * (cb * L / n) = cb * L
    calc
      n * (cb * L / n) = (n / n) * (cb * L) := by ring
      _ = _ := by rw [div_self hn.ne', one_mul]
  have hnt : n * t ≤ 1 := by
    have he : n * t = n * b / (N : ℝ) ^ 2 := by dsimp [t]; ring
    rw [he, div_le_one (sq_pos_of_pos hNpos), hnb]
    exact hN2
  have hdegree : ((20 * N : ℕ) : ℝ) ≤ (20 * Q / cb) * (n * b) := by
    have he : (20 * Q / cb) * (n * b) = 20 * Q * L := by rw [hnb]; field_simp
    rw [he]
    push_cast
    nlinarith only [hNhi]
  have hE := upper_reserved_interval (k := k) halpha hg hg1 heps hCh
  have hE0 : 0 < upperE0 k alpha eps Ch := (mul_pos heps hbeta).trans_le hE.1
  have hw0 : 0 ≤ omega := (Real.exp_pos _).le
  have hw1 : omega ≤ 1 := Real.exp_le_one_iff.mpr (by nlinarith only [hcw, hE0])
  have hwdiff : |omega - 1| ≤ (2 * cw * eps) * (alpha - 1) := by
    rw [abs_of_nonpos (by linarith : omega - 1 ≤ 0)]
    have hh := (upperOmega_near_one_margins (k := k) halpha halpha1 hg hg1 heps hCh hcw hcw1).2
    change 1 - omega ≤ _ at hh
    linarith
  have hqcoeff := (haff cL hcL k N alpha Ch D c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi).2.1
  have hqbound : |P.coeff 1 - t ^ (alpha - 1)| ≤ K * (alpha - 1) * t ^ (alpha - 1) := by
    have hm := mul_le_mul_of_nonneg_right hK0K (by positivity : 0 ≤ (alpha - 1) * t ^ (alpha - 1))
    exact hqcoeff.trans (by nlinarith only [hm])
  have hco (j : ℕ) (_hj : j ≤ 20 * N) :
      |(P - C (t ^ (alpha - 1)) * X).coeff j| ≤ (alpha - 1) * (K * Real.exp (K * L)) * b ^ (1 + (alpha - 1) - j) := by
    have hh := hcoeff cL hcL k N j alpha Ch D c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
    have he := Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_right hK1K hL.le)
    have hm := mul_le_mul hK1K he (Real.exp_pos _).le hK.le
    have hm' := mul_le_mul_of_nonneg_right hm
      (by positivity : 0 ≤ (alpha - 1) * b ^ (alpha - j))
    rw [show 1 + (alpha - 1) = alpha by ring]
    exact hh.trans (by nlinarith only [hm'])
  have hsum : ∑ i, (lam i : ℝ) = n := by
    have hl (i : Fin k) : (lam i : ℝ) = n * p.mass i := by
      exact Real.coe_toNNReal _ (mul_nonneg hn.le (p.nonneg i))
    simp only [hl, ← Finset.mul_sum, p.normalized, mul_one]
  simp only [actualNearOneCountStatistic]
  change MemLp (polynomialNearOneCountStatistic Counts Pilot P n t (alpha - 1) omega
    (cp * Bpilot * alpha) repair (20 * N)) 2 mu ∧
    variance (polynomialNearOneCountStatistic Counts Pilot P n t (alpha - 1) omega
      (cp * Bpilot * alpha) repair (20 * N)) mu ≤
      nearOneHybridVarianceBudget lam n t b (alpha - 1) (K * Real.exp (K * L)) (2 * cw * eps) K
        (cp * Bpilot * alpha) (20 * Q / cb) (20 * N)
  exact polynomial_near_one_hybrid_variance (repair := repair) Counts Pilot P lam hn ht hb hnt hbeta (by linarith) (by positivity)
    hw0 hw1 (by positivity) hwdiff hK.le hqbound hcp0 (by positivity) (by positivity) hcp hcpExp
      hCounts hPilot hind hpair hsum hdegree hco


end Renyi
