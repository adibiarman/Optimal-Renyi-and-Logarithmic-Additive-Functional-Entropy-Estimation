import Renyi.CoupledProfileFloors

/-! Complete global lower envelope of the actual raised low profile. -/
noncomputable section
namespace Renyi

def coupledMinEnvelopeConstant (f q : ℝ) : ℝ :=
  max (288+Real.log (endpointReserveConstant f))
    (max (24*raisedFloorScale f q+Real.log (endpointReserveConstant f))
      (Real.log (raisedFloorScale f q)-24*raisedFloorScale f q*Real.log (coupledFloorConstant f)))

lemma profile_rescaled_power {y C s : ℝ} (hy : 0≤y) (hC : 0<C) (hs : 0<s) :
    (y/(C*s))^s = (y/s)^s*Real.exp (-Real.log C*s) := by
  rw [show y/(C*s)=(y/s)/C by ring, Real.div_rpow (div_nonneg hy hs.le) hC.le,
    Real.rpow_def_of_pos hC, div_eq_mul_inv, ←Real.exp_neg]
  congr 2
  ring

lemma global_min_power_on_middle {s y D c M : ℝ} (hs : 0<s) (hD : 1≤D)
    (hc : 0<c) (hc1 : c≤1) (hy : 0<y) (hyD : y≤D*s) (hy0 : (1:ℝ)/24≤y)
    (hM : Real.log D-24*D*Real.log c≤M) :
    Real.exp (-M*s)*(y/s)^s≤c := by
  have hDp : 0<D := zero_lt_one.trans_le hD
  have hq : y/s≤D := (div_le_iff₀ hs).mpr hyD
  have hp := Real.rpow_le_rpow (div_pos hy hs).le hq hs.le
  have hm := mul_le_mul_of_nonneg_left hp (Real.exp_pos (-M*s)).le
  apply hm.trans
  rw [Real.rpow_def_of_pos hDp, ←Real.exp_add]
  apply (Real.exp_le_exp.mpr _).trans_eq (Real.exp_log hc)
  have hlog := Real.log_nonpos hc.le hc1
  have hDs : 1≤24*D*s := by nlinarith only [hyD,hy0]
  have hb := mul_le_mul_of_nonpos_right hDs hlog
  have hMmul := mul_le_mul_of_nonneg_right hM hs.le
  nlinarith only [hb,hMmul]

/-- A fixed exponential loss gives the valid global min-envelope, uniformly in the order. -/
theorem lowProfile_global_min_lower {N : ℕ} (hN : 2≤N) {s f q x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0<f) (hf1 : f<1) (hqf : q<f)
    (hx : 0≤x) (hx1 : x≤1) :
    min q (Real.exp (-coupledMinEnvelopeConstant f q*s)*(((N:ℝ)^2*x)/s)^s) ≤
      lowProfile N s f x := by
  have hN0 : 0<N := by omega
  have hCf := endpointReserveConstant_pos hf1
  have hCf1 := endpointReserveConstant_one_le hf.le hf1
  have hD1 : 1≤raisedFloorScale f q := hCf1.trans (le_max_left _ _)
  have hy : 0≤(N:ℝ)^2*x := by positivity
  have hM0 : 288+Real.log (endpointReserveConstant f)≤coupledMinEnvelopeConstant f q := le_max_left _ _
  have hM1 : 24*raisedFloorScale f q+Real.log (endpointReserveConstant f)≤coupledMinEnvelopeConstant f q :=
    (le_max_left _ _).trans (le_max_right _ _)
  have hM2 : Real.log (raisedFloorScale f q)-24*raisedFloorScale f q*Real.log (coupledFloorConstant f)≤
      coupledMinEnvelopeConstant f q := (le_max_right _ _).trans (le_max_right _ _)
  by_cases hys : (N:ℝ)^2*x≤s
  · apply (min_le_right _ _).trans
    apply le_trans _ (lowProfile_local_lower hN hs hs1 hf.le hf1 hx hx1 hys)
    rw [profile_rescaled_power hy hCf hs]
    have he : Real.exp (-coupledMinEnvelopeConstant f q*s) ≤
        Real.exp (-Real.log (endpointReserveConstant f)*s)*Real.exp (-288*s) := by
      rw [←Real.exp_add]
      apply Real.exp_le_exp.mpr
      nlinarith only [mul_le_mul_of_nonneg_right hM0 hs.le]
    have hm := mul_le_mul_of_nonneg_right he (Real.rpow_nonneg (div_nonneg hy hs.le) s)
    nlinarith only [hm]
  by_cases hyD : raisedFloorScale f q*s≤(N:ℝ)^2*x
  · exact (min_le_left _ _).trans (lowProfile_raised_floor hN hs hs1 hf.le hf1 hqf hx hx1 hyD)
  have hypos : 0<(N:ℝ)^2*x := hs.trans (lt_of_not_ge hys)
  have hyD' := (lt_of_not_ge hyD).le
  by_cases hysmall : (N:ℝ)^2*x≤1/24
  · have hk := endpointKernel_local_exp_lower hN0 (by norm_num : 2≤6) hx hx1 hysmall
    have hfirst := coupledProfile_first_term_lower (d:=2) hN0 hs hCf hx
      (lowNormalizer_pos hN0 hs hf.le hf1) (lowNormalizer_sharp_upper hN hs hs1 hf.le hf1)
    have hm := mul_le_mul_of_nonneg_left hk
      (Real.rpow_nonneg (div_nonneg hy (mul_pos hCf hs).le) s)
    have he : Real.exp (-coupledMinEnvelopeConstant f q*s) ≤
        Real.exp (-Real.log (endpointReserveConstant f)*s)*Real.exp (-24*((N:ℝ)^2*x)) := by
      rw [←Real.exp_add]
      apply Real.exp_le_exp.mpr
      nlinarith only [mul_le_mul_of_nonneg_right hM1 hs.le,hyD']
    have hmul := mul_le_mul_of_nonneg_right he (Real.rpow_nonneg (div_nonneg hy hs.le) s)
    rw [profile_rescaled_power hy hCf hs] at hm hfirst
    have hshoulder := (lowShoulder_range hN0 hs hf.le hx hx1).1
    apply (min_le_right _ _).trans
    change _≤x^s*endpointKernel N 2 x/lowNormalizer N s f+lowShoulder N s f x
    change _≤x^s*endpointKernel N 2 x/lowNormalizer N s f at hfirst
    nlinarith only [hmul,hm,hfirst,hshoulder]
  · have hcf := coupledFloorConstant_pos hf hf1
    have hcf1 : coupledFloorConstant f≤1 := by
      have hmin : coupledFloorConstant f≤(endpointReserveConstant f)⁻¹ := min_le_left _ _
      exact hmin.trans ((inv_le_one₀ hCf).mpr hCf1)
    have hp := global_min_power_on_middle hs hD1 hcf hcf1 hypos hyD' (lt_of_not_ge hysmall).le hM2
    exact (min_le_right _ _).trans (hp.trans (lowProfile_transition_floor hN hs hs1 hf.le hf1 hx hx1 (lt_of_not_ge hys).le))


def coupledHighMinEnvelopeConstant (f q Ω : ℝ) : ℝ :=
  max (288+Real.log (endpointReserveConstant f))
    (max (24*raisedFloorScale f q+Real.log (endpointReserveConstant f))
      (Real.log (raisedFloorScale f q)-24*raisedFloorScale f q*Real.log (Ω*coupledFloorConstant f)))

/-- On a fixed positive omega range, the actual high profile has its global min-envelope. -/
theorem highProfile_global_min_lower {N : ℕ} (hN : 2≤N) {s f q ω Ω x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0<f) (hf1 : f<1) (hqf : q<f)
    (hΩ : 0<Ω) (hΩω : Ω≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) :
    min (q*ω) (Real.exp (-coupledHighMinEnvelopeConstant f q Ω*s)*(((N:ℝ)^2*x)/s)^s) ≤
      highProfile N s f ω x := by
  have hN0 : 0<N := by omega
  have hω : 0≤ω := hΩ.le.trans hΩω
  have hΩ1 : Ω≤1 := hΩω.trans hω1.le
  have hCf := endpointReserveConstant_pos hf1
  have hCf1 := endpointReserveConstant_one_le hf.le hf1
  have hD1 : 1≤raisedFloorScale f q := hCf1.trans (le_max_left _ _)
  have hy : 0≤(N:ℝ)^2*x := by positivity
  have hM0 : 288+Real.log (endpointReserveConstant f)≤coupledHighMinEnvelopeConstant f q Ω := le_max_left _ _
  have hM1 : 24*raisedFloorScale f q+Real.log (endpointReserveConstant f)≤coupledHighMinEnvelopeConstant f q Ω :=
    (le_max_left _ _).trans (le_max_right _ _)
  have hM2 : Real.log (raisedFloorScale f q)-24*raisedFloorScale f q*Real.log (Ω*coupledFloorConstant f)≤
      coupledHighMinEnvelopeConstant f q Ω := (le_max_right _ _).trans (le_max_right _ _)
  by_cases hys : (N:ℝ)^2*x≤s
  · apply (min_le_right _ _).trans
    apply le_trans _ (highProfile_local_lower hN hs hs1 hf.le hf1 hω hω1 hx hx1 hys)
    rw [profile_rescaled_power hy hCf hs]
    have he : Real.exp (-coupledHighMinEnvelopeConstant f q Ω*s) ≤
        Real.exp (-Real.log (endpointReserveConstant f)*s)*Real.exp (-288*s) := by
      rw [←Real.exp_add]
      apply Real.exp_le_exp.mpr
      nlinarith only [mul_le_mul_of_nonneg_right hM0 hs.le]
    have hm := mul_le_mul_of_nonneg_right he (Real.rpow_nonneg (div_nonneg hy hs.le) s)
    nlinarith only [hm]
  by_cases hyD : raisedFloorScale f q*s≤(N:ℝ)^2*x
  · exact (min_le_left _ _).trans (highProfile_raised_floor hN hs hs1 hf.le hf1 hqf hω hω1 hx hx1 hyD)
  have hypos : 0<(N:ℝ)^2*x := hs.trans (lt_of_not_ge hys)
  have hyD' := (lt_of_not_ge hyD).le
  by_cases hysmall : (N:ℝ)^2*x≤1/24
  · have hk := endpointKernel_local_exp_lower hN0 (by norm_num : 6≤6) hx hx1 hysmall
    have hfirst := coupledProfile_first_term_lower (d:=6) hN0 hs hCf hx
      (highNormalizer_pos hN0 hs hf.le hf1.le hω hω1) (highNormalizer_sharp_upper hN hs hs1 hf.le hf1 hω hω1)
    have hm := mul_le_mul_of_nonneg_left hk
      (Real.rpow_nonneg (div_nonneg hy (mul_pos hCf hs).le) s)
    have he : Real.exp (-coupledHighMinEnvelopeConstant f q Ω*s) ≤
        Real.exp (-Real.log (endpointReserveConstant f)*s)*Real.exp (-24*((N:ℝ)^2*x)) := by
      rw [←Real.exp_add]
      apply Real.exp_le_exp.mpr
      nlinarith only [mul_le_mul_of_nonneg_right hM1 hs.le,hyD']
    have hmul := mul_le_mul_of_nonneg_right he (Real.rpow_nonneg (div_nonneg hy hs.le) s)
    rw [profile_rescaled_power hy hCf hs] at hm hfirst
    have hshoulder := (highShoulder_range hN0 hs hf.le hf1.le hω hx hx1).1
    apply (min_le_right _ _).trans
    change _≤x^s*endpointKernel N 6 x/highNormalizer N s f ω+highShoulder N s f ω x
    change _≤x^s*endpointKernel N 6 x/highNormalizer N s f ω at hfirst
    nlinarith only [hmul,hm,hfirst,hshoulder]
  · have hcf := mul_pos hΩ (coupledFloorConstant_pos hf hf1)
    have hcf1 : Ω*coupledFloorConstant f≤1 := by
      have hmin : coupledFloorConstant f≤(endpointReserveConstant f)⁻¹ := min_le_left _ _
      have hbase := hmin.trans ((inv_le_one₀ hCf).mpr hCf1)
      exact mul_le_one₀ hΩ1 (coupledFloorConstant_pos hf hf1).le hbase
    have hp := global_min_power_on_middle hs hD1 hcf hcf1 hypos hyD' (lt_of_not_ge hysmall).le hM2
    have hfloor := highProfile_transition_floor hN hs hs1 hf.le hf1 hω hω1 hx hx1 (lt_of_not_ge hys).le
    have hfloor' := (mul_le_mul_of_nonneg_right hΩω (coupledFloorConstant_pos hf hf1).le).trans hfloor
    exact (min_le_right _ _).trans (hp.trans hfloor')

end Renyi
