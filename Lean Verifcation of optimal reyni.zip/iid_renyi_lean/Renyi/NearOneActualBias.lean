import Renyi.NearOneBias
import Renyi.NearOne

/-! Actual-parameter calibration of localized near-one bias. -/
noncomputable section
namespace Renyi

theorem attenuated_unit_difference {A M beta : ℝ} (hA : 0≤A) (hA1 : A≤1)
    (hM : 0≤M) (hb : 0≤beta) :
    0≤A-A*Real.exp (-M*beta) ∧ A-A*Real.exp (-M*beta)≤M*beta := by
  have he : Real.exp (-M*beta)≤1 := Real.exp_le_one_iff.mpr (by nlinarith)
  have hh := Real.add_one_le_exp (-M*beta)
  have hprod := mul_le_of_le_one_left (by linarith : 0≤1-Real.exp (-M*beta)) hA1
  constructor
  · have := mul_le_mul_of_nonneg_left he hA; nlinarith
  · nlinarith only [hprod,hh]

theorem near_one_attenuated_amplitudes_uniform {eps M cw : ℝ}
    (heps : 0<eps) (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) :
    ∃ C : ℝ, 0<C ∧ ∀ (k : ℕ) (alpha Ch : ℝ),
      1<alpha → alpha≤3/2 → 0≤Ch →
      |overlapA (fractionalPart alpha)
        (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(alpha-1))-
        upperOmega k alpha eps Ch cw|≤C*(alpha-1) ∧
      |overlapB (fractionalPart alpha)
        (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*Real.exp (-M*(2-alpha))|≤
          C*(alpha-1) := by
  obtain ⟨Ca,hCa,ha⟩ := near_one_amplitudes_uniform heps
  refine ⟨Ca+M+2*cw*eps,by positivity,?_⟩
  intro k alpha Ch halpha halpha1 hCh
  have hb : 0<alpha-1 := sub_pos.mpr halpha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order halpha halpha1).2]; exact hb
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order halpha halpha1).2]; linarith
  have hE := upper_reserved_interval (k:=k) halpha hg hg1 heps hCh
  have hEpos : 0<upperE0 k alpha eps Ch := (mul_pos heps hb).trans_le hE.1
  have hz := (upperOverlapZ_spec hg hg1 hEpos).1
  have hcoeff := overlap_coefficients hg hg1 hz.1 hz.2
  have hparams := ha k alpha Ch halpha halpha1 hCh
  have hA0 : 0≤overlapA (fractionalPart alpha)
      (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch)) := by linarith [hcoeff.1]
  have hA1 : overlapA (fractionalPart alpha)
      (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))≤1 := by linarith [hparams.2.2.1]
  have hatt := attenuated_unit_difference hA0 hA1 hM hb.le
  have hw := upperOmega_near_one_margins (k:=k) halpha halpha1 hg hg1 heps hCh hcw hcw1
  have hw1 : upperOmega k alpha eps Ch cw≤1 := by
    unfold upperOmega
    exact Real.exp_le_one_iff.mpr (by nlinarith)
  constructor
  · apply abs_le.mpr
    constructor <;> nlinarith [hparams.2.2.2,hw.2,mul_nonneg hM hb.le,
      mul_nonneg hCa.le hb.le,mul_nonneg (mul_nonneg hcw.le heps.le) hb.le]
  · have he : Real.exp (-M*(2-alpha))≤1 := Real.exp_le_one_iff.mpr (by nlinarith)
    rw [abs_of_nonneg (mul_nonneg hparams.1 (Real.exp_pos _).le)]
    have hh := mul_le_mul_of_nonneg_left he hparams.1
    nlinarith [hparams.2.1,mul_nonneg hM hb.le,mul_nonneg (mul_nonneg hcw.le heps.le) hb.le]

theorem log_abs_of_compact {r lo hi : ℝ} (hlo : 0<lo) (hloR : lo≤r) (hhi : r≤hi) :
    |Real.log r|≤|Real.log lo|+|Real.log hi| := by
  have hr : 0<r := hlo.trans_le hloR
  have hl := Real.log_le_log hlo hloR
  have hh := Real.log_le_log hr hhi
  have ha := abs_le.mp (le_refl |Real.log lo|)
  have hb := abs_le.mp (le_refl |Real.log hi|)
  exact abs_le.mpr ⟨by linarith [abs_nonneg (Real.log hi)],by linarith [abs_nonneg (Real.log lo)]⟩

/-- The actual variable degree-one coefficient remains in a fixed compact
cutoff-ratio interval; constants are independent of k, alpha and D. -/
theorem near_one_variable_tangent_compact {eps cb lambda CL cL cmin q Q : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcL : 0<cL) (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q) :
    ∃ lo hi : ℝ, 0<lo ∧ 0<hi ∧ ∀ (k : ℕ) (alpha Ch D N c : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      N≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) →
      lo≤(c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))/
        (upperB k alpha eps D cb CL cL/N^2) ∧
      (c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))/
        (upperB k alpha eps D cb CL cL/N^2)≤hi := by
  obtain ⟨T,_,ht⟩ := near_one_overlap_time_uniform heps
  refine ⟨cmin*lambda*q^2*(3/4)*Real.exp (-T),lambda*Q^2,by positivity,by positivity,?_⟩
  intro k alpha Ch D N c hk ha ha1 hCh hD hc hc1 hNlo hNhi
  have hc0 : 0<c := hcmin.trans_le hc
  have htime := ht k alpha Ch ha ha1 hCh
  have h := near_one_tangent_comparison hk ha ha1 hD hcb hCL hcL hc0 hlambda hq hQ
    hNlo hNhi (heps.le.trans htime.1) htime.2
  constructor
  · apply le_trans _ h.1
    exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hc hlambda.le) (sq_nonneg q))
      (by norm_num : (0:ℝ)≤3/4)) (Real.exp_pos _).le
  · apply h.2.trans
    have hh := mul_le_mul_of_nonneg_right hc1 (mul_nonneg hlambda.le (sq_nonneg Q))
    nlinarith only [hh]


def actualNearOneExpression (k N : ℕ) (alpha eps Ch D cb lambda CL cL c M cw f s0 p : ℝ) : ℝ :=
  nearOneExpression N (c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1))
    (alpha-1) f (upperOmega k alpha eps Ch cw)
    (overlapA (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*
      Real.exp (-M*(alpha-1)))
    (overlapB (fractionalPart alpha) (upperOverlapZ (fractionalPart alpha) (upperE0 k alpha eps Ch))*
      Real.exp (-M*(2-alpha))) s0 (upperB k alpha eps D cb CL cL) p

/-- Full localized source bias for the actual root, overlap, attenuation and
cutoff parameters. No bias or approximation certificate is assumed. -/
theorem actual_near_one_bias_uniform {eps cb lambda CL cL cmin q Q M cw f : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcL : 0<cL) (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hf : 0≤f) (hf1 : f≤1) :
    ∃ K : ℝ, 0<K ∧ ∀ (k N : ℕ) (alpha Ch D c s0 p : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) →
      0≤s0 → s0≤1 → 0≤p → p≤upperB k alpha eps D cb CL cL →
      |actualNearOneExpression k N alpha eps Ch D cb lambda CL cL c M cw f s0 p-
        s0*upperOmega k alpha eps Ch cw*p^alpha|≤
          K*(alpha-1)*(upperB k alpha eps D cb CL cL/(N:ℝ)^2)^alpha := by
  obtain ⟨Ca,hCa,ha⟩ := near_one_attenuated_amplitudes_uniform heps hM hcw hcw1
  obtain ⟨lo,hi,hlo,hhi,hratio⟩ := near_one_variable_tangent_compact heps hcb hlambda
    hCL hcL hcmin hq hQ
  let ML := |Real.log lo|+|Real.log hi|
  let K := nearOneTangentConstant+tangentReplacementConstant ML+
    Ca*(tangentCutoffConstant ML+coupledLocalizationConstant)
  have hML : 0≤ML := add_nonneg (abs_nonneg _) (abs_nonneg _)
  have hK : 0<K := by
    dsimp [K,nearOneTangentConstant,tangentReplacementConstant,tangentCutoffConstant,
      coupledLocalizationConstant]
    positivity
  refine ⟨K,hK,?_⟩
  intro k N alpha Ch D c s0 p hk halpha halpha1 hCh hD hc hc1 hNlo hNhi hs0 hs1 hp hpb
  have hbeta : 0<alpha-1 := sub_pos.mpr halpha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order halpha halpha1).2]; exact hbeta
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order halpha halpha1).2]; linarith
  have hL := upperDegree_pos halpha hCL hcL (one_le_rootMultiplier (k:=k) (ε:=eps) halpha hg hg1)
  have hNr : 0<(N:ℝ) := (mul_pos hq hL).trans_le hNlo
  have hN : 0<N := by exact_mod_cast hNr
  have hb := upperB_pos (ε:=eps) hk halpha hg hg1 hD hcb hCL hcL
  have ht : 0<upperB k alpha eps D cb CL cL/(N:ℝ)^2 := div_pos hb (sq_pos_of_pos hNr)
  have hr := hratio k alpha Ch D N c hk halpha halpha1 hCh hD hc hc1 hNlo hNhi
  have htau : 0<c*alpha*upperA k alpha eps Ch D cb lambda CL cL/(alpha-1) := by
    have hh := (lt_div_iff₀ ht).mp (hlo.trans_le hr.1)
    simpa only [zero_mul] using hh
  have hlog := log_abs_of_compact hlo hr.1 hr.2
  have hamp := ha k alpha Ch halpha halpha1 hCh
  have hE := upper_reserved_interval (k:=k) halpha hg hg1 heps hCh
  have hEpos : 0<upperE0 k alpha eps Ch := (mul_pos heps hbeta).trans_le hE.1
  have hw : 0≤upperOmega k alpha eps Ch cw := (Real.exp_pos _).le
  have hw1 : upperOmega k alpha eps Ch cw<1 := Real.exp_lt_one_iff.mpr (by nlinarith)
  have h := near_one_expression_bias hN htau hb hbeta.le (by linarith) hlog hf hf1 hw hw1
    hs0 hs1 hCa.le hamp.1 hamp.2 hp hpb
  change |nearOneExpression N _ (alpha-1) f _ _ _ s0 _ p-
    s0*upperOmega k alpha eps Ch cw*p^alpha|≤K*(alpha-1)*_ at ⊢
  simpa only [show 1+(alpha-1)=alpha by ring] using h

end Renyi
