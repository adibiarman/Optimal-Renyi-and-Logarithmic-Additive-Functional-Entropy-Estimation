import Renyi.NearOneExpectation
import Renyi.PoissonPairMoments

/-! Exact unconditional moments of the pilot-selected centered count noise. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi
set_option maxHeartbeats 600000
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

def pilotCenteredCoordinate (Y N : Ω→ℕ) (T : ℝ) (f : ℕ→ℝ) (lam : ℝ≥0) : Ω→ℝ :=
  fun w => if (Y w:ℝ)≤T then f (N w)-(∫j,f j ∂poissonMeasure lam) else 0

omit [IsProbabilityMeasure μ] in
/-- The selector's randomness adds no variance to conditionally centered
count noise; its exact variance is selector mass times count variance. -/
theorem pilot_centered_coordinate_moments (Y N : Ω→ℕ) (pilotLam lam : ℝ≥0)
    (hY : MeasurePreserving Y μ (poissonMeasure pilotLam))
    (hN : MeasurePreserving N μ (poissonMeasure lam)) (hind : IndepFun Y N μ)
    (T : ℝ) (f : ℕ→ℝ) (hf : MemLp f 2 (poissonMeasure lam)) :
    MemLp (pilotCenteredCoordinate Y N T f lam) 2 μ ∧
    (∫w,pilotCenteredCoordinate Y N T f lam w ∂μ)=0 ∧
    variance (pilotCenteredCoordinate Y N T f lam) μ=
      poissonLowerMass pilotLam T*variance f (poissonMeasure lam) := by
  let c := ∫j,f j ∂poissonMeasure lam
  let g : ℕ→ℝ := fun j => f j-c
  have hg : MemLp g 2 (poissonMeasure lam) := hf.sub (memLp_const c)
  have hgN : MemLp (fun w => g (N w)) 2 μ := hg.comp_measurePreserving hN
  have hsel : MemLp (pilotCenteredCoordinate Y N T f lam) 2 μ := by
    apply hgN.norm.mono' ((measurable_of_countable (fun z:ℕ×ℕ => if (z.1:ℝ)≤T then g z.2 else 0)).comp
      (hY.measurable.prodMk hN.measurable)).aestronglyMeasurable
    exact Filter.Eventually.of_forall (fun w => by
      change ‖if (Y w:ℝ)≤T then g (N w) else 0‖≤‖g (N w)‖
      split_ifs <;> simp)
  have hgc : (∫j,g j ∂poissonMeasure lam)=0 := by
    rw [show g=fun j => f j-c by rfl,integral_sub (hf.integrable one_le_two) (integrable_const c)]
    simp only [integral_const,measureReal_univ_eq_one,one_smul,c,sub_self]
  have hm := poisson_selected_mean Y N pilotLam lam hY hN hind T g (hg.integrable one_le_two)
  have hzero : (∫w,pilotCenteredCoordinate Y N T f lam w ∂μ)=0 := by
    change (∫w,(if (Y w:ℝ)≤T then g (N w) else 0) ∂μ)=0
    rw [hm.2,hgc,mul_zero]
  have hs := poisson_selected_mean Y N pilotLam lam hY hN hind T (fun j => (g j)^2) hg.integrable_sq
  have hsq : (∫w,(pilotCenteredCoordinate Y N T f lam w)^2 ∂μ)=
      poissonLowerMass pilotLam T*(∫j,(g j)^2 ∂poissonMeasure lam) := by
    convert hs.2 using 1
    congr 1
    funext w
    dsimp [pilotCenteredCoordinate,g,c]
    split_ifs <;> simp
  refine ⟨hsel,hzero,?_⟩
  rw [variance_of_integral_eq_zero hsel.aemeasurable hzero,hsq,
    variance_eq_integral hf.aemeasurable]

/-- Pair independence makes the entire selected centered count noise exactly
additive in variance, under the actual joint pilot/main experiment. -/
theorem pilot_centered_sum_moments {ι : Type*} [Fintype ι]
    (Y N : ι→Ω→ℕ) (pilotLam lam : ι→ℝ≥0)
    (hY : ∀i,MeasurePreserving (Y i) μ (poissonMeasure (pilotLam i)))
    (hN : ∀i,MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hind : ∀i,IndepFun (Y i) (N i) μ)
    (hpair : Pairwise (fun i j => IndepFun (fun w => (Y i w,N i w)) (fun w => (Y j w,N j w)) μ))
    (T : ℝ) (f : ι→ℕ→ℝ) (hf : ∀i,MemLp (f i) 2 (poissonMeasure (lam i))) :
    let Z := fun w => ∑i,pilotCenteredCoordinate (Y i) (N i) T (f i) (lam i) w
    MemLp Z 2 μ ∧ (∫w,Z w ∂μ)=0 ∧
      variance Z μ=∑i,poissonLowerMass (pilotLam i) T*variance (f i) (poissonMeasure (lam i)) := by
  let H : ι→Ω→ℝ := fun i => pilotCenteredCoordinate (Y i) (N i) T (f i) (lam i)
  have hm (i) := pilot_centered_coordinate_moments (Y i) (N i) (pilotLam i) (lam i) (hY i) (hN i) (hind i) T (f i) (hf i)
  have hH (i) : MemLp (H i) 2 μ := (hm i).1
  have hsum : MemLp (fun w => ∑i,H i w) 2 μ := memLp_finset_sum _ (fun i _ => hH i)
  have hpairH : Pairwise (fun i j => IndepFun (H i) (H j) μ) := by
    intro i j hij
    exact (hpair hij).comp
      (measurable_of_countable (fun z:ℕ×ℕ => if (z.1:ℝ)≤T then f i z.2-(∫j,f i j ∂poissonMeasure (lam i)) else 0))
      (measurable_of_countable (fun z:ℕ×ℕ => if (z.1:ℝ)≤T then f j z.2-(∫z,f j z ∂poissonMeasure (lam j)) else 0))
  refine ⟨hsum,?_,?_⟩
  · rw [integral_finset_sum Finset.univ (fun i _ => (hH i).integrable one_le_two)]
    change (∑i,(∫w,H i w ∂μ))=0
    simp only [show ∀i,(∫w,H i w ∂μ)=0 from fun i => (hm i).2.1,Finset.sum_const_zero]
  · have hv := IndepFun.variance_sum (s:=Finset.univ) (X:=H)
      (fun i _ => hH i) (fun i _ j _ hij => hpairH hij)
    convert hv using 1
    · congr 1
      funext w
      simp only [Finset.sum_apply,H]
    · apply Finset.sum_congr rfl
      intro i _
      exact (hm i).2.2.symm

end Renyi
