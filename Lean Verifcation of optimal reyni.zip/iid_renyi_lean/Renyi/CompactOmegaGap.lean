import Renyi.UpperCompact
import Renyi.UpperRescaling

/-! Fixed two-sided power-interval gaps throughout bounded order width. -/
noncomputable section
namespace Renyi
set_option maxHeartbeats 700000

def compactOmegaLowerGap (eps W : ℝ) : ℝ :=
  Real.exp (-W/4)*(Real.exp (7*eps/8)-1)

def compactOmegaUpperGap (eps : ℝ) : ℝ := 1-Real.exp (-eps/16)

def compactOmegaGap (eps W : ℝ) : ℝ :=
  min (compactOmegaLowerGap eps W/2) (compactOmegaUpperGap eps)

lemma compactOmegaGap_pos {eps W : ℝ} (heps : 0<eps) : 0<compactOmegaGap eps W := by
  have hl : 0<compactOmegaLowerGap eps W :=
    mul_pos (Real.exp_pos _) (sub_pos.mpr (Real.one_lt_exp_iff.mpr (by linarith only [heps])))
  have hu : 0<compactOmegaUpperGap eps := sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith only [heps]))
  exact lt_min (div_pos hl (by norm_num)) hu

lemma upperRescaling_deficit {k : ℕ} {alpha eps cu u0 : ℝ}
    (ha : 1<alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (hcu : 0≤cu) (hu0 : 0<u0) : 1-upperRescaling k alpha eps cu u0≤cu*u0 := by
  have hu := upperU_pos (k:=k) (eps:=eps) ha hg hg1 hu0
  have hu1 : upperU k alpha eps u0≤u0 := min_le_right _ _
  have hx : 0≤cu*upperU k alpha eps u0 := mul_nonneg hcu hu.le
  have hden : 0<1+cu*upperU k alpha eps u0 := by positivity
  have hid : 1-upperRescaling k alpha eps cu u0=
      (cu*upperU k alpha eps u0)/(1+cu*upperU k alpha eps u0) := by
    unfold upperRescaling
    field_simp
    ring
  rw [hid]
  exact (div_le_self hx (by linarith only [hx])).trans (mul_le_mul_of_nonneg_left hu1 hcu)

/-- Before rescaling, the actual omega lies a uniform positive distance from
both endpoints in the compact-width branch. -/
theorem compact_omega_unscaled_gaps {alpha eps W E0 : ℝ}
    (ha : 3/2≤alpha) (heps : 0<eps) (hg : 0<fractionalPart alpha)
    (hg1 : fractionalPart alpha<1)
    (hwidth : 2*eps*(alpha-1)/(fractionalPart alpha*(1-fractionalPart alpha))≤W)
    (hElow : eps*(alpha-1)≤E0) (hEhigh : E0≤2*eps*(alpha-1)) :
    upperKappa alpha eps+compactOmegaLowerGap eps W≤Real.exp (-E0/8) ∧
      Real.exp (-E0/8)+compactOmegaUpperGap eps≤1 := by
  let E := 2*eps*(alpha-1)
  have hEeps : eps≤E := by dsimp [E];nlinarith only [heps,ha]
  have hhh : 0<fractionalPart alpha*(1-fractionalPart alpha) := mul_pos hg (sub_pos.mpr hg1)
  have hEpos : 0<E := heps.trans_le hEeps
  have hW : 0<W := (div_pos hEpos hhh).trans_le hwidth
  have hquarter : fractionalPart alpha*(1-fractionalPart alpha)≤1/4 := by
    nlinarith only [sq_nonneg (fractionalPart alpha-1/2)]
  have hEmax : E≤W/4 := by
    have hh := (div_le_iff₀ hhh).mp hwidth
    have hh' := mul_le_mul_of_nonneg_left hquarter hW.le
    dsimp [E] at *
    nlinarith only [hh,hh']
  have hkap : Real.exp (-W/4)≤Real.exp (-E) := Real.exp_le_exp.mpr (by linarith only [hEmax])
  have hextra : Real.exp (7*eps/8)≤Real.exp (E-E0/8) := Real.exp_le_exp.mpr (by
    change E0≤E at hEhigh
    linarith only [hEeps,hEhigh])
  have hgap0 : 0≤Real.exp (7*eps/8)-1 := sub_nonneg.mpr (Real.one_le_exp_iff.mpr (by linarith only [heps]))
  have hextra0 : 0≤Real.exp (E-E0/8)-1 := hgap0.trans (sub_le_sub_right hextra 1)
  have hmul := mul_le_mul hkap (sub_le_sub_right hextra 1) hgap0 (Real.exp_pos _).le
  have hid : Real.exp (-E)*(Real.exp (E-E0/8)-1)=Real.exp (-E0/8)-Real.exp (-E) := by
    rw [mul_sub,←Real.exp_add,mul_one]
    rw [show -E+(E-E0/8)= -E0/8 by ring]
  rw [hid] at hmul
  have hElow' : eps/2≤E0 := by
    have hh := mul_le_mul_of_nonneg_left ha heps.le
    nlinarith only [hh,hElow]
  have hupper : Real.exp (-E0/8)≤Real.exp (-eps/16) := Real.exp_le_exp.mpr (by linarith only [hElow'])
  constructor
  · have hidk : upperKappa alpha eps=Real.exp (-E) := by
      unfold upperKappa
      congr 1
      dsimp [E]
      ring
    rw [hidk]
    change Real.exp (-E)+Real.exp (-W/4)*(Real.exp (7*eps/8)-1)≤_
    linarith only [hmul]
  · dsimp [compactOmegaUpperGap]
    linarith only [hupper]

/-- The same fixed small rescaling preserves half the compact lower gap. -/
theorem actual_compact_omega_gaps {k : ℕ} {alpha eps W Ch cu u0 : ℝ}
    (ha : 3/2≤alpha) (heps : 0<eps) (hg : 0<fractionalPart alpha)
    (hg1 : fractionalPart alpha<1) (hCh : 0≤Ch) (hcu : 0≤cu) (hu0 : 0<u0)
    (hsmall : cu*u0≤compactOmegaLowerGap eps W/2)
    (hwidth : 2*eps*(alpha-1)/(fractionalPart alpha*(1-fractionalPart alpha))≤W) :
    upperKappa alpha eps+compactOmegaGap eps W≤
      upperRescaling k alpha eps cu u0*Real.exp (-upperE0 k alpha eps Ch/8) ∧
      upperRescaling k alpha eps cu u0*Real.exp (-upperE0 k alpha eps Ch/8)+compactOmegaGap eps W≤1 := by
  have ha1 : 1<alpha := by linarith only [ha]
  have hres := upperRescaling_range (k:=k) (eps:=eps) ha1 hg hg1 hcu hu0
  have hE := upper_reserved_interval (k:=k) ha1 hg hg1 heps hCh
  have hgaps := compact_omega_unscaled_gaps ha heps hg hg1 hwidth hE.1 hE.2
  have hdef := (upperRescaling_deficit (k:=k) (eps:=eps) ha1 hg hg1 hcu hu0).trans hsmall
  have hEpos : 0<upperE0 k alpha eps Ch := (mul_pos heps (sub_pos.mpr ha1)).trans_le hE.1
  have hw0 : 0≤Real.exp (-upperE0 k alpha eps Ch/8) := (Real.exp_pos _).le
  have hw1 : Real.exp (-upperE0 k alpha eps Ch/8)≤1 := Real.exp_le_one_iff.mpr (by linarith only [hEpos])
  have hdefprod := mul_le_of_le_one_right (sub_nonneg.mpr hres.2) hw1
  have hscaled := mul_le_of_le_one_left hw0 hres.2
  have hl := min_le_left (compactOmegaLowerGap eps W/2) (compactOmegaUpperGap eps)
  have hu := min_le_right (compactOmegaLowerGap eps W/2) (compactOmegaUpperGap eps)
  change compactOmegaGap eps W≤_ at hl hu
  constructor <;> nlinarith only [hgaps.1,hgaps.2,hdef,hdefprod,hscaled,hl,hu]

end Renyi
