import Renyi.PoissonCentralMoments
import Renyi.HighOrderNorm
import Renyi.AnalyticNoise

/-! High-mean concentration for the actual signed Gamma count statistic. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

theorem finiteLNorm_rpow {k : ℕ} {a : ℝ} (ha : 0 < a) (v : Fin k → ℝ) :
    finiteLNorm a v ^ a = ∑ i, |v i| ^ a := by
  unfold finiteLNorm
  rw [← Real.rpow_mul (Finset.sum_nonneg (fun _ _ => Real.rpow_nonneg (abs_nonneg _) _)),
    one_div_mul_cancel ha.ne', Real.rpow_one]

theorem finiteLNorm_positiveCountRoot_rpow {k : ℕ} {a : ℝ} (ha : 1 ≤ a)
    (n : Fin k → ℕ) :
    finiteLNorm a (fun i => positiveCountRoot a (n i)) ^ a = ∑ i, positiveCount a (n i) := by
  have ha0 : 0 < a := by linarith
  rw [finiteLNorm_rpow ha0]
  apply Finset.sum_congr rfl
  intro i _
  unfold positiveCountRoot
  rw [abs_of_nonneg (Real.rpow_nonneg (positiveCount_nonneg a (n i)) _)]
  rw [← Real.rpow_mul (positiveCount_nonneg a (n i)), one_div_mul_cancel ha0.ne', Real.rpow_one]

theorem analyticCount_positiveCount_abs_difference {a : ℝ} (ha : 1 ≤ a) (j : ℕ) :
    |analyticCount a j - positiveCount a j| ≤ a ^ a := by
  by_cases hj : a ≤ (j : ℝ)
  · simp only [positiveCount, if_pos hj, sub_self, abs_zero]
    exact Real.rpow_nonneg (by linarith) _
  · simpa only [positiveCount, if_neg hj, sub_zero] using
      analyticCount_abs_below_order ha j (lt_of_not_ge hj)

theorem positiveCountRoot_norm_error {k : ℕ} {a B : ℝ}
    (ha : 1 ≤ a) (hB : 0 < B) (n : Fin k → ℕ) (lam : Fin k → ℝ)
    (hl : ∀ i, B * a ≤ lam i) :
    finiteLNorm a (fun i => positiveCountRoot a (n i) - lam i) ≤
      finiteLNorm a (fun i => (n i : ℝ) - lam i) + (1 / B) * finiteLNorm a lam := by
  have ha0 : 0 < a := by linarith
  have hlam (i) : 0 ≤ lam i := (by positivity : 0 ≤ B * a).trans (hl i)
  have hsplit := finiteLNorm_add_le ha
    (fun i => (n i : ℝ) - lam i) (fun i => positiveCountRoot a (n i) - n i)
  have hid : (fun i => ((n i : ℝ) - lam i) + (positiveCountRoot a (n i) - n i)) =
      (fun i => positiveCountRoot a (n i) - lam i) := by funext i; ring
  rw [hid] at hsplit
  have hshift := finiteLNorm_mono ha0 (fun i => positiveCountRoot a (n i) - n i)
    (fun i => (1 / B) * lam i) (fun i => ?_)
  · rw [finiteLNorm_smul ha0 (by positivity)] at hshift
    linarith
  · rw [abs_of_nonneg (mul_nonneg (by positivity) (hlam i))]
    apply (positiveCountRoot_error ha (n i)).trans
    have h := (le_div_iff₀ hB).2 (by nlinarith [hl i] : a * B ≤ lam i)
    simpa only [one_div, div_eq_mul_inv, mul_comm, mul_one] using h

theorem signed_count_sum_correction {k : ℕ} {a B : ℝ}
    (ha : 1 ≤ a) (hB : 0 < B) (n : Fin k → ℕ) (lam : Fin k → ℝ)
    (hl : ∀ i, B * a ≤ lam i) :
    |(∑ i, analyticCount a (n i)) - ∑ i, positiveCount a (n i)| ≤
      (1 / B) ^ a * ∑ i, (lam i) ^ a := by
  have ha0 : 0 < a := by linarith
  rw [← Finset.sum_sub_distrib, Finset.mul_sum]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply Finset.sum_le_sum
  intro i _
  have hlam : 0 ≤ lam i := (by positivity : 0 ≤ B * a).trans (hl i)
  apply (analyticCount_positiveCount_abs_difference ha (n i)).trans
  have hbound : a ≤ (1 / B) * lam i := by
    have h := (le_div_iff₀ hB).2 (by nlinarith [hl i] : a * B ≤ lam i)
    simpa only [one_div, div_eq_mul_inv, mul_comm, mul_one] using h
  have h := Real.rpow_le_rpow ha0.le hbound ha0.le
  rwa [Real.mul_rpow (by positivity) hlam] at h

theorem heavy_lower_gap {a t : ℝ} (ha : 1 ≤ a) (ht : 0 < t) (ht1 : t < 1 / 2) :
    (1 - 2 * t) ^ a + t * (1 - 2 * t) ^ a ≤ (1 - t) ^ a := by
  have hx : 0 < 1 - 2 * t := by linarith
  have hprod : (1 - 2 * t) * (1 + t) ≤ 1 - t := by nlinarith [sq_nonneg t]
  have h := Real.rpow_le_rpow (mul_nonneg hx.le (by positivity)) hprod (by linarith : 0 ≤ a)
  rw [Real.mul_rpow hx.le (by positivity)] at h
  have hratio := Real.self_le_rpow_of_one_le (by linarith : 1 ≤ 1 + t) ha
  have hm := mul_le_mul_of_nonneg_left hratio (Real.rpow_nonneg hx.le a)
  nlinarith

theorem heavy_upper_gap {a t : ℝ} (ha : 1 ≤ a) (ht : 0 < t) (ht1 : t < 1 / 2) :
    (1 + t) ^ a + t * (1 - 2 * t) ^ a ≤ (1 + 2 * t) ^ a := by
  have hx : 0 < 1 + t := by positivity
  have hv := Real.self_le_rpow_of_one_le (by linarith : 1 ≤ 1 + t) ha
  have hr := Real.self_le_rpow_of_one_le (by linarith [div_pos ht hx] : 1 ≤ 1 + t / (1 + t)) ha
  have hid : (1 + t) * (1 + t / (1 + t)) = 1 + 2 * t := by field_simp; ring
  have hp : (1 + t) ^ a * (1 + t / (1 + t)) ^ a = (1 + 2 * t) ^ a := by
    rw [← Real.mul_rpow hx.le (by positivity), hid]
  have hmul := mul_le_mul_of_nonneg_left hr (Real.rpow_nonneg hx.le a)
  rw [hp] at hmul
  have hdiv : 1 ≤ (1 + t) ^ a / (1 + t) := (one_le_div hx).2 hv
  have hident : (1 + t) ^ a * (1 + t / (1 + t)) =
      (1 + t) ^ a + t * ((1 + t) ^ a / (1 + t)) := by ring
  rw [hident] at hmul
  have hlow : (1 - 2 * t) ^ a ≤ 1 := Real.rpow_le_one (by linarith) (by linarith) (by linarith)
  nlinarith

theorem signed_count_heavy_enclosure {k : ℕ} {a B t : ℝ}
    (ha : 1 ≤ a) (ht : 0 < t) (ht1 : t < 1 / 2) (hB : 0 < B)
    (hshift : 1 / B ≤ t / 2) (hcorr : 1 / B ≤ t * (1 - 2 * t))
    (n : Fin k → ℕ) (lam : Fin k → ℝ) (hl : ∀ i, B * a ≤ lam i)
    (hclose : finiteLNorm a (fun i => (n i : ℝ) - lam i) ≤
      (t / 2) * finiteLNorm a lam) :
    (1 - 2 * t) ^ a * ∑ i, lam i ^ a ≤ ∑ i, analyticCount a (n i) ∧
    (∑ i, analyticCount a (n i)) ≤ (1 + 2 * t) ^ a * ∑ i, lam i ^ a := by
  have ha0 : 0 < a := by linarith
  have hlam (i) : 0 ≤ lam i := (by positivity : 0 ≤ B * a).trans (hl i)
  let R := finiteLNorm a lam
  let S := ∑ i, lam i ^ a
  have hR : 0 ≤ R := finiteLNorm_nonneg _ _
  have hS : 0 ≤ S := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (hlam i) _)
  have hRS : R ^ a = S := by
    dsimp [R, S]
    simpa only [abs_of_nonneg (hlam _)] using finiteLNorm_rpow ha0 lam
  have he := positiveCountRoot_norm_error ha hB n lam hl
  have hrev := finiteLNorm_reverse_triangle ha (fun i => positiveCountRoot a (n i)) lam
  have habs : |finiteLNorm a (fun i => positiveCountRoot a (n i)) - R| ≤ t * R := by
    have hh := mul_le_mul_of_nonneg_right hshift hR
    dsimp [R] at *
    linarith
  have hlo : (1 - t) * R ≤ finiteLNorm a (fun i => positiveCountRoot a (n i)) := by
    have := (abs_le.mp habs).1
    linarith
  have hhi : finiteLNorm a (fun i => positiveCountRoot a (n i)) ≤ (1 + t) * R := by
    have := (abs_le.mp habs).2
    linarith
  have hplo := Real.rpow_le_rpow (mul_nonneg (by linarith : 0 ≤ 1 - t) hR) hlo ha0.le
  have hphi := Real.rpow_le_rpow (finiteLNorm_nonneg _ _) hhi ha0.le
  rw [Real.mul_rpow (by linarith : 0 ≤ 1 - t) hR, hRS,
    finiteLNorm_positiveCountRoot_rpow ha] at hplo
  rw [Real.mul_rpow (by positivity : 0 ≤ 1 + t) hR, hRS,
    finiteLNorm_positiveCountRoot_rpow ha] at hphi
  have hcp : (1 / B) ^ a ≤ t * (1 - 2 * t) ^ a := by
    have h := Real.rpow_le_rpow (by positivity : 0 ≤ 1 / B) hcorr ha0.le
    rw [Real.mul_rpow ht.le (by linarith)] at h
    have htPow : t ^ a ≤ t := Real.rpow_le_self_of_le_one ht.le (by linarith) ha
    exact h.trans (mul_le_mul_of_nonneg_right htPow (Real.rpow_nonneg (by linarith) _))
  have hcor := signed_count_sum_correction ha hB n lam hl
  have hcor' : |(∑ i, analyticCount a (n i)) - ∑ i, positiveCount a (n i)| ≤
      (t * (1 - 2 * t) ^ a) * S :=
    hcor.trans (mul_le_mul_of_nonneg_right hcp hS)
  have hlg := mul_le_mul_of_nonneg_right (heavy_lower_gap ha ht ht1) hS
  have hug := mul_le_mul_of_nonneg_right (heavy_upper_gap ha ht ht1) hS
  have hcl := (abs_le.mp hcor').1
  have hch := (abs_le.mp hcor').2
  constructor <;> change _ ≤ _
  · dsimp [S] at *
    nlinarith
  · dsimp [S] at *
    nlinarith

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

omit [IsProbabilityMeasure μ] in
theorem poisson_vector_central_moment {k : ℕ} {a B : ℝ}
    (ha : 0 < a) (hB : 1 ≤ B) (N : Fin k → Ω → ℕ) (lam : Fin k → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hl : ∀ i, B * a ≤ (lam i : ℝ)) :
    Integrable (fun ω => ∑ i, |(N i ω : ℝ) - lam i| ^ a) μ ∧
    (∫ ω, ∑ i, |(N i ω : ℝ) - lam i| ^ a ∂μ) ≤
      2 * (1 / Real.sqrt B) ^ a * ∑ i, (lam i : ℝ) ^ a := by
  have hi (i) : Integrable (fun ω => |(N i ω : ℝ) - lam i| ^ a) μ :=
    (hLaw i).integrable_comp_of_integrable (poisson_centered_rpow_integrable (lam i) ha)
  refine ⟨integrable_finset_sum _ (fun i _ => hi i), ?_⟩
  rw [integral_finset_sum _ (fun i _ => hi i), Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i _
  have hid := (hLaw i).hasLaw.integral_comp
    (measurable_of_countable (fun n : ℕ => |(n : ℝ) - lam i| ^ a)).aestronglyMeasurable
  change (∫ ω, ((fun n : ℕ => |(n : ℝ) - lam i| ^ a) ∘ N i) ω ∂μ) ≤ _
  rw [hid]
  exact poisson_centered_rpow_le_relative (lam i) ha hB (hl i)

/-- The high-mean norm tail needs only Poisson marginals, not independence. -/
theorem poisson_vector_norm_tail {k : ℕ} (hk : 0 < k) {a B t : ℝ}
    (ha : 0 < a) (hB : 1 ≤ B) (ht : 0 < t)
    (N : Fin k → Ω → ℕ) (lam : Fin k → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hl : ∀ i, B * a ≤ (lam i : ℝ)) :
    μ.real {ω | t * finiteLNorm a (fun i => (lam i : ℝ)) <
      finiteLNorm a (fun i => (N i ω : ℝ) - lam i)} ≤
        2 * (1 / (t * Real.sqrt B)) ^ a := by
  let S := ∑ i, (lam i : ℝ) ^ a
  have hB0 : 0 < B := lt_of_lt_of_le zero_lt_one hB
  have hlam (i) : 0 < (lam i : ℝ) := (mul_pos hB0 ha).trans_le (hl i)
  have hS : 0 < S := by
    apply Finset.sum_pos
    · intro i _
      exact Real.rpow_pos_of_pos (hlam i) a
    · exact Finset.univ_nonempty_iff.mpr ⟨⟨0, hk⟩⟩
  have hn := poisson_vector_central_moment ha hB N lam hLaw hl
  have hmark := mul_meas_ge_le_integral_of_nonneg
    (Filter.Eventually.of_forall (fun ω => Finset.sum_nonneg
      (fun i _ => Real.rpow_nonneg (abs_nonneg _) a))) hn.1 (t ^ a * S)
  have hsub : {ω | t * finiteLNorm a (fun i => (lam i : ℝ)) <
      finiteLNorm a (fun i => (N i ω : ℝ) - lam i)} ⊆
      {ω | t ^ a * S ≤ ∑ i, |(N i ω : ℝ) - lam i| ^ a} := by
    intro ω hw
    have h := Real.rpow_le_rpow (mul_nonneg ht.le (finiteLNorm_nonneg _ _)) hw.le ha.le
    rw [Real.mul_rpow ht.le (finiteLNorm_nonneg _ _), finiteLNorm_rpow ha,
      finiteLNorm_rpow ha] at h
    simpa only [abs_of_nonneg (hlam _).le] using h
  have hmeas := measureReal_mono (μ := μ) hsub
  have hden : 0 < t ^ a * S := mul_pos (Real.rpow_pos_of_pos ht _) hS
  have h : μ.real {ω | t ^ a * S ≤ ∑ i, |(N i ω : ℝ) - lam i| ^ a} ≤
      (2 * (1 / Real.sqrt B) ^ a * S) / (t ^ a * S) := by
    apply (le_div_iff₀ hden).2
    have hh := hmark.trans hn.2
    dsimp [S] at *
    nlinarith only [hh]
  apply hmeas.trans (h.trans_eq ?_)
  dsimp [S]
  rw [mul_div_mul_right _ _ hS.ne', mul_div_assoc, ← Real.div_rpow (by positivity) ht.le]
  congr 2
  field_simp

/-- Uniform concentration of the signed Gamma transform, including its negative counts. -/
theorem analyticCount_heavy_concentration {t rho : ℝ}
    (ht : 0 < t) (ht1 : t < 1 / 8) (hrho : 0 < rho) (hrho1 : rho < 1) :
    ∃ B : ℝ, 1 ≤ B ∧ ∀ (k : ℕ) (a : ℝ), 1 ≤ a →
      ∀ (N : Fin k → Ω → ℕ) (lam : Fin k → ℝ≥0),
        (∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i))) →
        (∀ i, B * a ≤ (lam i : ℝ)) →
        μ.real {ω | ¬ ((1 - 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a ≤
          ∑ i, analyticCount a (N i ω) ∧
          (∑ i, analyticCount a (N i ω)) ≤ (1 + 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a)}
          ≤ rho := by
  let B := 1 + 2 / t + 1 / (t * (1 - 2 * t)) + (4 / (t * rho)) ^ 2
  have hinner : 0 < t * (1 - 2 * t) := mul_pos ht (by linarith)
  have hB1 : 1 ≤ B := by dsimp [B]; nlinarith [div_pos (by norm_num : (0:ℝ)<2) ht, div_pos (by norm_num : (0:ℝ)<1) hinner, sq_nonneg (4 / (t * rho))]
  have hB0 : 0 < B := zero_lt_one.trans_le hB1
  have h2 : 2 / t ≤ B := by dsimp [B]; nlinarith [div_pos (by norm_num : (0:ℝ)<1) hinner, sq_nonneg (4 / (t * rho))]
  have h3 : 1 / (t * (1 - 2 * t)) ≤ B := by dsimp [B]; nlinarith [div_pos (by norm_num : (0:ℝ)<2) ht, sq_nonneg (4 / (t * rho))]
  have h4 : (4 / (t * rho)) ^ 2 ≤ B := by dsimp [B]; nlinarith [div_pos (by norm_num : (0:ℝ)<2) ht, div_pos (by norm_num : (0:ℝ)<1) hinner]
  have hshift : 1 / B ≤ t / 2 := by
    have h := (div_le_iff₀ ht).mp h2
    apply (div_le_iff₀ hB0).2
    nlinarith
  have hcorr : 1 / B ≤ t * (1 - 2 * t) := by
    have h := (div_le_iff₀ hinner).mp h3
    apply (div_le_iff₀ hB0).2
    nlinarith
  have hsqrt : 4 / (t * rho) ≤ Real.sqrt B := by
    have h := Real.sqrt_le_sqrt h4
    rwa [Real.sqrt_sq (by positivity)] at h
  have hsqrt0 : 0 < Real.sqrt B := Real.sqrt_pos.mpr hB0
  have htail : 1 / ((t / 2) * Real.sqrt B) ≤ rho / 2 := by
    have h := (div_le_iff₀ (mul_pos ht hrho)).mp hsqrt
    apply (div_le_iff₀ (mul_pos (by positivity) hsqrt0)).2
    nlinarith
  refine ⟨B, hB1, ?_⟩
  intro k a ha N lam hLaw hl
  rcases eq_or_lt_of_le (Nat.zero_le k) with rfl | hk
  · simp only [Finset.univ_eq_empty, Finset.sum_empty, mul_zero, le_refl, and_self,
      not_true_eq_false, Set.setOf_false, measureReal_empty]
    exact hrho.le
  have hsub : {ω | ¬ ((1 - 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a ≤
      ∑ i, analyticCount a (N i ω) ∧
      (∑ i, analyticCount a (N i ω)) ≤ (1 + 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a)} ⊆
      {ω | (t / 2) * finiteLNorm a (fun i => (lam i : ℝ)) <
        finiteLNorm a (fun i => (N i ω : ℝ) - lam i)} := by
    intro ω hw
    by_contra hc
    exact hw (signed_count_heavy_enclosure ha ht (by linarith) hB0 hshift hcorr
      (fun i => N i ω) (fun i => (lam i : ℝ)) hl (le_of_not_gt hc))
  apply (measureReal_mono (μ := μ) hsub).trans
  apply (poisson_vector_norm_tail hk (by linarith) hB1 (by positivity) N lam hLaw hl).trans
  have hx0 : 0 ≤ 1 / ((t / 2) * Real.sqrt B) := by positivity
  have hx1 : 1 / ((t / 2) * Real.sqrt B) ≤ 1 := by linarith
  have hp := Real.rpow_le_self_of_le_one hx0 hx1 ha
  nlinarith

/-- The source high-mean event has probability at least one minus the chosen error. -/
theorem high_mean_gamma_concentration {t rho : ℝ}
    (ht : 0 < t) (ht1 : t < 1 / 8) (hrho : 0 < rho) (hrho1 : rho < 1) :
    ∃ B : ℝ, 1 ≤ B ∧ ∀ (k : ℕ) (a : ℝ), 3 / 2 ≤ a →
      ∀ (N : Fin k → Ω → ℕ) (lam : Fin k → ℝ≥0),
        (∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i))) →
        (∀ i, B * a ≤ (lam i : ℝ)) →
        1 - rho ≤ μ.real {ω | (1 - 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a ≤
          ∑ i, analyticCount a (N i ω) ∧
          (∑ i, analyticCount a (N i ω)) ≤ (1 + 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a} := by
  obtain ⟨B, hB, hconc⟩ := analyticCount_heavy_concentration (μ := μ) ht ht1 hrho hrho1
  refine ⟨B, hB, ?_⟩
  intro k a ha N lam hLaw hl
  have h := hconc k a (by linarith) N lam hLaw hl
  have hmeas : Measurable (fun ω => ∑ i, analyticCount a (N i ω)) := by
    apply Finset.measurable_sum
    intro i _
    exact (measurable_of_countable (analyticCount a)).comp (hLaw i).measurable
  have hset : MeasurableSet {ω | (1 - 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a ≤
      ∑ i, analyticCount a (N i ω) ∧
      (∑ i, analyticCount a (N i ω)) ≤ (1 + 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a} :=
    (measurableSet_le measurable_const hmeas).inter (measurableSet_le hmeas measurable_const)
  have hadd := measureReal_add_measureReal_compl (μ := μ) hset
  simp only [measureReal_univ_eq_one] at hadd
  change _ + μ.real {ω | ¬ ((1 - 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a ≤
    ∑ i, analyticCount a (N i ω) ∧
    (∑ i, analyticCount a (N i ω)) ≤ (1 + 2 * t) ^ a * ∑ i, (lam i : ℝ) ^ a)} = 1 at hadd
  linarith

end Renyi
