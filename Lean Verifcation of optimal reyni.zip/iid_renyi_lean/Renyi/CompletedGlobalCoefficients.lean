import Renyi.DegreeOneGlobalCoefficients

/-! The full global coefficient budget including the degree-one completion. -/
noncomputable section
open Polynomial
namespace Renyi

theorem coupledQPolynomial_scaled_mass_budget {ℓ N m : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    (hdegree : 4*(ℓ-1) ≤ m) {γ a b fL f A B ω : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 ≤ a) (hab : a ≤ b) (hb : 0 < b)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1) :
    coefficientMass ((coupledQPolynomial ℓ N m γ a b fL f A B ω).comp (C b*X)) ≤
      b^((m:ℝ)+γ)*coupledCoefficientBudget ℓ N γ a b A B ω := by
  have hmass := coupledQPolynomial_scaled_mass_factored (N:=N) (γ:=γ) (fL:=fL) (f:=f) hdegree ha hab hb hA hB hB1 hω
  have hl := lowProfilePolynomial_coefficientMass hℓ hγ hγ1.le hfL hfL1
  have hv := highProfilePolynomial_coefficientMass hN (by linarith : 0<1-γ)
    (by linarith : 1-γ≤1) hf hf1 hω hω1
  have hj1 := endpointProfilePolynomial_coefficientMass hN (by norm_num : 6≤6)
    (by norm_num : (0:ℝ)<1) (by norm_num : (1:ℝ)≤1)
  have hjδ := endpointProfilePolynomial_coefficientMass hN (by norm_num : 6≤6)
    (by linarith : 0<1-γ) (by linarith : 1-γ≤1)
  have hl' := mul_le_mul
    (mul_le_mul_of_nonneg_left hl (mul_nonneg hA (Real.rpow_nonneg (div_nonneg ha hb.le) γ)))
    (add_le_add_left hj1 1)
    (show 0 ≤ 1+coefficientMass (endpointProfilePolynomial N 6 1) by linarith [coefficientMass_nonneg (endpointProfilePolynomial N 6 1)])
    (show 0 ≤ A*(a/b)^γ*(96*(ℓ:ℝ)^2*(9:ℝ)^(4*(ℓ-1))) by positivity)
  have hv' := mul_le_mul_of_nonneg_left hv hB
  have hj' := mul_le_mul_of_nonneg_left hjδ (mul_nonneg hω (sub_nonneg.mpr hB1))
  have hbgt : A*(a/b)^γ*coefficientMass (lowProfilePolynomial ℓ γ fL)*
      (1+coefficientMass (endpointProfilePolynomial N 6 1)) +
      B*coefficientMass (highProfilePolynomial N (1-γ) f ω) +
      ω*(1-B)*coefficientMass (endpointProfilePolynomial N 6 (1-γ)) ≤
      coupledCoefficientBudget ℓ N γ a b A B ω := by
    unfold coupledCoefficientBudget
    nlinarith
  exact hmass.trans (mul_le_mul_of_nonneg_left hbgt (Real.rpow_nonneg hb.le _))

/-- The exact completed polynomial has the same explicit coefficient budget. -/
theorem completedCoupledPolynomial_scaled_mass_budget {ℓ N m : ℕ}
    (hℓ : 0<ℓ) (hN : 0<N) (hm : 1≤m) (hdegree : 4*(ℓ-1)≤m)
    {γ a b c fL f A B ω : ℝ} (hγ : 0<γ) (hγ1 : γ<1)
    (ha : 0≤a) (hab : a≤b) (hb : 0<b) (hc : c∈Set.Ioo (γ/(1+γ)) 1)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hA : 0≤A) (hB : 0≤B) (hB1 : B≤1) (hω : 0≤ω) (hω1 : ω<1) :
    coefficientMass ((completedCoupledPolynomial ℓ N m γ a b c fL f A B ω).comp (C b*X))≤
      b^((m:ℝ)+γ)*coupledCoefficientBudget ℓ N γ a b A B ω := by
  by_cases hℓ1 : ℓ=1
  · subst ℓ
    simp only [completedCoupledPolynomial,if_true]
    exact degreeOneCoupledPolynomial_scaled_mass_budget hN hm hγ hγ1 ha hab hb hc hf hf1 hA hB hB1 hω hω1
  · simp only [completedCoupledPolynomial,if_neg hℓ1]
    exact coupledQPolynomial_scaled_mass_budget hℓ hN hdegree hγ hγ1 ha hab hb hfL hfL1 hf hf1 hA hB hB1 hω hω1

/-- A fixed exponential coefficient budget for both completed source branches. -/
theorem completedCoupledPolynomial_scaled_mass_exponential {ℓ N m : ℕ}
    (hℓ : 0<ℓ) (hN : 0<N) (hm : 1≤m) (hdegree : 4*(ℓ-1)≤m)
    {γ a b c fL f A B ω L : ℝ} (hγ : 0<γ) (hγ1 : γ<1)
    (ha : 0≤a) (hab : a≤b) (hb : 0<b) (hc : c∈Set.Ioo (γ/(1+γ)) 1)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hA : 0≤A) (hA1 : A≤1) (hB : 0≤B) (hB1 : B≤1) (hω : 0≤ω) (hω1 : ω<1)
    (hL : 1≤L) (hℓL : (ℓ:ℝ)≤L) (hNL : (N:ℝ)≤L) :
    coefficientMass ((completedCoupledPolynomial ℓ N m γ a b c fL f A B ω).comp (C b*X))≤
      b^((m:ℝ)+γ)*Real.exp (coupledCoefficientExponentialConstant*L) := by
  apply (completedCoupledPolynomial_scaled_mass_budget hℓ hN hm hdegree hγ hγ1 ha hab hb hc
    hfL hfL1 hf hf1 hA hB hB1 hω hω1).trans
  exact mul_le_mul_of_nonneg_left
    (coupledCoefficientBudget_exponential hγ.le ha hab hb hA hA1 hB hB1 hω hω1.le hL hℓL hNL)
    (Real.rpow_nonneg hb.le _)

/-- Every actual coefficient obeys the count-estimator scaling bound. -/
theorem completedCoupledPolynomial_coefficient_bound {ℓ N m : ℕ}
    (hℓ : 0<ℓ) (hN : 0<N) (hm : 1≤m) (hdegree : 4*(ℓ-1)≤m)
    {γ a b c fL f A B ω : ℝ} (hγ : 0<γ) (hγ1 : γ<1)
    (ha : 0≤a) (hab : a≤b) (hb : 0<b) (hc : c∈Set.Ioo (γ/(1+γ)) 1)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hA : 0≤A) (hB : 0≤B) (hB1 : B≤1) (hω : 0≤ω) (hω1 : ω<1) (j : ℕ) :
    |(completedCoupledPolynomial ℓ N m γ a b c fL f A B ω).coeff j| * b^j≤
      b^((m:ℝ)+γ)*coupledCoefficientBudget ℓ N γ a b A B ω := by
  have hh := abs_coeff_le_coefficientMass
    ((completedCoupledPolynomial ℓ N m γ a b c fL f A B ω).comp (C b*X)) j
  rw [comp_C_mul_X_coeff,abs_mul,abs_of_nonneg (pow_nonneg hb.le j)] at hh
  exact hh.trans (completedCoupledPolynomial_scaled_mass_budget hℓ hN hm hdegree hγ hγ1 ha hab hb hc
    hfL hfL1 hf hf1 hA hB hB1 hω hω1)

end Renyi
