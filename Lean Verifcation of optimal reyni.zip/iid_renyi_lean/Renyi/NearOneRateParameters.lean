import Renyi.NearOne

/-! Uniform rate-scale exposure and degree bounds near order one. -/
set_option maxHeartbeats 600000
noncomputable section
namespace Renyi

theorem near_one_root_upper {k : ℕ} {alpha eps : ℝ} (hk : 0 < k)
    (ha : 1 < alpha) (ha1 : alpha ≤ 3 / 2) (heps : 0 < eps) :
    rootMultiplier k alpha eps ≤ 3 * (k : ℝ) ^ (1 / alpha) := by
  have hk0 : (0 : ℝ) < k := by exact_mod_cast hk
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have ha0 : 0 < alpha := by linarith
  have hbeta : 0 < alpha - 1 := by linarith
  have hgamma := (near_one_order ha ha1).2
  have hg : 0 < fractionalPart alpha := by rw [hgamma]; exact hbeta
  have hg1 : fractionalPart alpha < 1 := by rw [hgamma]; linarith
  let y := 3 * (k : ℝ) ^ (1 / alpha)
  have hkp : 1 ≤ (k : ℝ) ^ (1 / alpha) := Real.one_le_rpow hk1 (by positivity)
  have hy3 : 3 ≤ y := by dsimp [y]; linarith
  have hy1 : 1 ≤ y := by linarith
  have hy0 : 0 < y := by linarith
  have hQ0 := rootQSquared_pos (k := k) (ε := eps) ha hg hg1
  have hQ := (near_one_Q_bounds hk ha ha1 heps).2
  have hQy : rootQSquared k alpha eps ≤ y := by dsimp [y]; nlinarith only [hQ, hkp]
  have hlogy : 0 ≤ Real.log y := Real.log_nonneg hy1
  have harg : 1 ≤ y * (1 + Real.log y) / rootQSquared k alpha eps := by
    apply (one_le_div hQ0).2
    have hm := mul_le_mul_of_nonneg_left (show (1 : ℝ) ≤ 1 + Real.log y by linarith) hy0.le
    nlinarith only [hQy, hm]
  have hbracket : 1 ≤ max (1 + Real.log (y * (1 + Real.log y) / rootQSquared k alpha eps)) 0 :=
    (show (1 : ℝ) ≤ 1 + Real.log (y * (1 + Real.log y) / rootQSquared k alpha eps) by
      linarith [Real.log_nonneg harg]).trans (le_max_left _ _)
  have hc : alpha * (fractionalPart alpha * (1 - fractionalPart alpha)) / (alpha - 1) =
      alpha * (2 - alpha) := by
    rw [hgamma]
    field_simp
    ring
  have hc34 : (3 / 4 : ℝ) ≤ alpha * (fractionalPart alpha * (1 - fractionalPart alpha)) / (alpha - 1) := by
    rw [hc]
    nlinarith
  have hyp : 3 ≤ y ^ alpha := by
    have h := Real.rpow_le_rpow_of_exponent_le hy1 ha.le
    rw [Real.rpow_one] at h
    exact hy3.trans h
  have hprod := mul_le_mul hc34 hyp (by norm_num : (0 : ℝ) ≤ 3) (by linarith :
    0 ≤ alpha * (fractionalPart alpha * (1 - fractionalPart alpha)) / (alpha - 1))
  have hprod0 : 0 ≤ alpha * (fractionalPart alpha * (1 - fractionalPart alpha)) / (alpha - 1) * y ^ alpha := by positivity
  have hcrit := mul_le_mul_of_nonneg_left hbracket hprod0
  unfold rootMultiplier
  apply csInf_le
  · exact ⟨1, fun _ hx => hx.1⟩
  · refine ⟨hy1, ?_⟩
    nlinarith only [hprod, hcrit]

theorem near_one_log_root_upper {k : ℕ} {alpha eps : ℝ} (hk : 0 < k)
    (ha : 1 < alpha) (ha1 : alpha ≤ 3 / 2) (heps : 0 < eps) :
    Real.log (rootMultiplier k alpha eps) ≤ Real.log 3 + Real.log k := by
  have hk0 : (0 : ℝ) < k := by exact_mod_cast hk
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hg := (near_one_order ha ha1).2
  have hγ : 0 < fractionalPart alpha := by rw [hg]; linarith
  have hγ1 : fractionalPart alpha < 1 := by rw [hg]; linarith
  have hx0 : 0 < rootMultiplier k alpha eps := zero_lt_one.trans_le (one_le_rootMultiplier ha hγ hγ1)
  have h := Real.log_le_log hx0 (near_one_root_upper hk ha ha1 heps)
  rw [Real.log_mul (by norm_num : (3 : ℝ) ≠ 0) (Real.rpow_pos_of_pos hk0 _).ne', Real.log_rpow hk0] at h
  have hfrac : 1 / alpha ≤ 1 := (div_le_one (by linarith : 0 < alpha)).2 ha.le
  have hm := mul_le_mul_of_nonneg_right hfrac (Real.log_nonneg hk1)
  nlinarith only [h, hm]

theorem near_one_sample_lower {k : ℕ} {alpha eps D : ℝ} (hk : 0 < k)
    (ha : 1 < alpha) (ha1 : alpha ≤ 3 / 2) (heps : 0 < eps) (hD : 0 < D) :
    nearOneQConstant eps * D * k /
      (Real.exp 1 * (1 + Real.log 3 + Real.log k)) ≤ upperSample k alpha eps D := by
  have hk0 : (0 : ℝ) < k := by exact_mod_cast hk
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hgamma := (near_one_order ha ha1).2
  have hg : 0 < fractionalPart alpha := by rw [hgamma]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [hgamma]; linarith
  have hx : 0 < rootMultiplier k alpha eps := zero_lt_one.trans_le (one_le_rootMultiplier ha hg hg1)
  have hq := (near_one_Q_bounds hk ha ha1 heps).1.trans (upper_root_Q_bound ha hg hg1)
  have hlog := near_one_log_root_upper hk ha ha1 heps
  have hlogmul := mul_le_mul_of_nonneg_left (add_le_add_left hlog 1)
    (mul_nonneg (Real.exp_pos 1).le hx.le)
  have hq' := hq.trans hlogmul
  have hprod := mul_le_mul_of_nonneg_left hq'
    (mul_nonneg hD.le (Real.rpow_nonneg hk0.le (1 - 1 / alpha)))
  have hkp : (k : ℝ) ^ (1 - 1 / alpha) * (k : ℝ) ^ (1 / alpha) = (k : ℝ) := by
    rw [← Real.rpow_add hk0, show 1 - 1 / alpha + 1 / alpha = 1 by ring, Real.rpow_one]
  have hleft : D * (k : ℝ) ^ (1 - 1 / alpha) * (nearOneQConstant eps * (k : ℝ) ^ (1 / alpha)) =
      nearOneQConstant eps * D * k := by
    calc
      _ = nearOneQConstant eps * D * ((k : ℝ) ^ (1 - 1 / alpha) * (k : ℝ) ^ (1 / alpha)) := by ring
      _ = _ := by rw [hkp]
  rw [hleft] at hprod
  have hbase : D * (k : ℝ) ^ (1 - 1 / alpha) * rootMultiplier k alpha eps ≤ upperSample k alpha eps D := by
    have hm := mul_le_mul_of_nonneg_left ha.le
      (by positivity : 0 ≤ D * (k : ℝ) ^ (1 - 1 / alpha) * rootMultiplier k alpha eps)
    unfold upperSample
    nlinarith only [hm]
  have hW : 0 < 1 + Real.log 3 + Real.log k := by
    have h3 : 0 ≤ Real.log 3 := Real.log_nonneg (by norm_num)
    have hklog := Real.log_nonneg hk1
    linarith
  apply (div_le_iff₀ (mul_pos (Real.exp_pos 1) hW)).2
  have hlast := mul_le_mul_of_nonneg_left hbase (mul_nonneg (Real.exp_pos 1).le hW.le)
  nlinarith only [hprod, hlast]

theorem near_one_degree_log_bound {k : ℕ} {alpha eps CL cL : ℝ} (hk : 0 < k)
    (ha : 1 < alpha) (ha1 : alpha ≤ 3 / 2) (heps : 0 < eps) (hCL : 1 ≤ CL) (hcL : 0 < cL) :
    (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ) ≤
      (3 / 2 : ℝ) * (CL + 1 + cL * Real.log 3) + (3 / 2 : ℝ) * cL * Real.log k := by
  have hgamma := (near_one_order ha ha1).2
  have hg : 0 < fractionalPart alpha := by rw [hgamma]; linarith
  have hg1 : fractionalPart alpha < 1 := by rw [hgamma]; linarith
  have hdegree := (upperDegree_bounds ha hCL hcL (one_le_rootMultiplier (k := k) (ε := eps) ha hg hg1)).2
  have hlog := near_one_log_root_upper hk ha ha1 heps
  have hm := mul_le_mul_of_nonneg_left hlog hcL.le
  have hm' := mul_le_mul_of_nonneg_left hm (by linarith : 0 ≤ alpha)
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hbracket : 0 ≤ CL + 1 + cL * (Real.log 3 + Real.log k) := by
    have h3 : 0 ≤ Real.log 3 := Real.log_nonneg (by norm_num)
    have hklog := Real.log_nonneg hk1
    positivity
  have hlast := mul_le_mul_of_nonneg_right ha1 hbracket
  nlinarith only [hdegree, hm', hlast]

theorem near_one_sample_upper {k : ℕ} {alpha eps D : ℝ} (hk : 0 < k)
    (ha : 1 < alpha) (ha1 : alpha ≤ 3 / 2) (heps : 0 < eps) (hD : 0 < D) :
    upperSample k alpha eps D ≤ (9 / 2 : ℝ) * D * k := by
  have hk0 : (0 : ℝ) < k := by exact_mod_cast hk
  have hroot := mul_le_mul_of_nonneg_left (near_one_root_upper hk ha ha1 heps)
    (by positivity : 0 ≤ D * alpha * (k : ℝ) ^ (1 - 1 / alpha))
  have hpow : (k : ℝ) ^ (1 - 1 / alpha) * (k : ℝ) ^ (1 / alpha) = (k : ℝ) := by
    rw [← Real.rpow_add hk0, show 1 - 1 / alpha + 1 / alpha = 1 by ring, Real.rpow_one]
  have hnorm : D * alpha * (k : ℝ) ^ (1 - 1 / alpha) * (3 * (k : ℝ) ^ (1 / alpha)) =
      3 * D * alpha * k := by
    calc
      _ = 3 * D * alpha * ((k : ℝ) ^ (1 - 1 / alpha) * (k : ℝ) ^ (1 / alpha)) := by ring
      _ = _ := by rw [hpow]
  rw [hnorm] at hroot
  have hlast := mul_le_mul_of_nonneg_left ha1 (by positivity : 0 ≤ 3 * D * (k : ℝ))
  unfold upperSample
  nlinarith only [hroot, hlast]

/-- A sufficiently small logarithmic degree slope turns every fixed
exponential degree cost into an arbitrarily small power of k. -/
theorem near_one_exp_degree_bound {k : ℕ} {alpha eps CL cL C r : ℝ} (hk : 0 < k)
    (ha : 1 < alpha) (ha1 : alpha ≤ 3 / 2) (heps : 0 < eps)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hcL1 : cL ≤ 1) (hC : 0 ≤ C)
    (hsmall : (3 / 2 : ℝ) * C * cL ≤ r) :
    Real.exp (C * (upperDegree alpha CL cL (rootMultiplier k alpha eps) : ℝ)) ≤
      Real.exp (C * (3 / 2 : ℝ) * (CL + 1 + Real.log 3)) * (k : ℝ) ^ r := by
  have hk0 : (0 : ℝ) < k := by exact_mod_cast hk
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hdegree := mul_le_mul_of_nonneg_left (near_one_degree_log_bound hk ha ha1 heps hCL hcL) hC
  have h3 : 0 ≤ Real.log 3 := Real.log_nonneg (by norm_num)
  have hconst := mul_le_mul_of_nonneg_right hcL1 h3
  have hconst' := mul_le_mul_of_nonneg_left hconst (show 0 ≤ C * (3 / 2 : ℝ) by positivity)
  have hlog := mul_le_mul_of_nonneg_right hsmall (Real.log_nonneg hk1)
  rw [Real.rpow_def_of_pos hk0, ← Real.exp_add]
  apply Real.exp_le_exp.mpr
  nlinarith only [hdegree, hconst', hlog]

end Renyi
