import Renyi.EndpointIntegral
import Mathlib.Topology.Order.Compact

/-! Actual normalized-integral polynomials and coupled endpoint profiles. -/
noncomputable section
open scoped BigOperators
open MeasureTheory Set Polynomial
namespace Renyi

/-- Dividing coefficient `j` by `s+j` integrates a polynomial against `x^(s-1)`. -/
def weightedPrimitivePolynomial (P : ℝ[X]) (s : ℝ) : ℝ[X] :=
  ∑ j ∈ P.support, monomial j (P.coeff j / (s+j))

lemma weightedPrimitivePolynomial_eval (P : ℝ[X]) (s x : ℝ) :
    (weightedPrimitivePolynomial P s).eval x =
      ∑ j ∈ P.support, P.coeff j / (s+j) * x^j := by
  simp [weightedPrimitivePolynomial, eval_finset_sum, eval_monomial]

lemma weighted_primitive_identity (P : ℝ[X]) {s x : ℝ} (hs : 0 < s) (hx : 0 ≤ x) :
    (∫ t in (0:ℝ)..x, t^(s-1)*P.eval t) =
      x^s * (weightedPrimitivePolynomial P s).eval x := by
  have heq : (∫ t in (0:ℝ)..x, t^(s-1)*P.eval t) =
      ∫ t in (0:ℝ)..x, ∑ j ∈ P.support, P.coeff j * t^(s+j-1) := by
    apply intervalIntegral.integral_congr_ae
    filter_upwards [] with t ht
    rw [uIoc_of_le hx] at ht
    have ht0 : 0 < t := ht.1
    rw [eval_eq_sum, Polynomial.sum, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j _
    rw [show s+(j:ℝ)-1 = (s-1)+(j:ℝ) by ring, Real.rpow_add ht0,
      Real.rpow_natCast]
    ring
  rw [heq, intervalIntegral.integral_finset_sum]
  · rw [weightedPrimitivePolynomial_eval, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j _
    rw [intervalIntegral.integral_const_mul,
      integral_rpow (Or.inl (by have := Nat.cast_nonneg (α := ℝ) j; linarith)),
      show s+(j:ℝ)-1+1=s+j by ring,
      Real.zero_rpow (by have := Nat.cast_nonneg (α := ℝ) j; linarith : s+(j:ℝ) ≠ 0),
      sub_zero]
    rcases hx.eq_or_lt with rfl | hx
    · simp [Real.zero_rpow hs.ne', Real.zero_rpow (by have := Nat.cast_nonneg (α := ℝ) j; linarith : s+(j:ℝ) ≠ 0)]
    · rw [Real.rpow_add hx, Real.rpow_natCast]
      ring
  · intro j _
    exact (intervalIntegral.intervalIntegrable_rpow'
      (by have := Nat.cast_nonneg (α := ℝ) j; linarith : -1 < s+(j:ℝ)-1)).const_mul _

/-- The polynomial factor of the manuscript's actual normalized integral. -/
def endpointProfilePolynomial (N d : ℕ) (s : ℝ) : ℝ[X] :=
  C (endpointIntegral N d s)⁻¹ * weightedPrimitivePolynomial (endpointKernelPolynomial N d) s

theorem endpointProfile_polynomial {N : ℕ} (hN : 0 < N) (d : ℕ)
    {s x : ℝ} (hs : 0 < s) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    endpointProfile N d s x = x^s * (endpointProfilePolynomial N d s).eval x := by
  have heq : endpointPrimitive N d s x =
      ∫ t in (0:ℝ)..x, t^(s-1)*(endpointKernelPolynomial N d).eval t := by
    apply intervalIntegral.integral_congr
    intro t ht
    rw [uIcc_of_le hx] at ht
    dsimp only
    rw [endpointKernelPolynomial_eval hN d (ht.2.trans hx1)]
  rw [endpointProfile, heq, weighted_primitive_identity _ hs hx]
  simp [endpointProfilePolynomial, div_eq_mul_inv]
  ring

/-- The normalizing supremum used in both actual profiles. -/
def coupledNormalizer (s : ℝ) (K H : ℝ → ℝ) : ℝ :=
  sSup ((fun x : ℝ => x^s*K x/(1-H x)) '' Icc 0 1)

def coupledProfile (s : ℝ) (K H : ℝ → ℝ) (x : ℝ) : ℝ :=
  x^s*K x / coupledNormalizer s K H + H x

lemma coupledNormalizer_bdd {s b : ℝ} {K H : ℝ → ℝ}
    (hs : 0 ≤ s) (hb : b < 1)
    (hK : ∀ x ∈ Icc (0:ℝ) 1, 0 ≤ K x ∧ K x ≤ 1)
    (hH : ∀ x ∈ Icc (0:ℝ) 1, H x ≤ b) :
    BddAbove ((fun x : ℝ => x^s*K x/(1-H x)) '' Icc 0 1) := by
  refine ⟨(1-b)⁻¹, ?_⟩
  rintro z ⟨x, hx, rfl⟩
  have hden : 0 < 1-H x := by have := hH x hx; linarith
  have hnum : x^s*K x ≤ 1 := by
    exact (mul_le_mul (Real.rpow_le_one hx.1 hx.2 hs) (hK x hx).2
      (hK x hx).1 (by norm_num)).trans_eq (by ring)
  apply (div_le_iff₀ hden).mpr
  have hm := mul_le_mul_of_nonneg_left (show 1-b ≤ 1-H x by have := hH x hx; linarith)
    (inv_nonneg.mpr (by linarith : 0 ≤ 1-b))
  rw [inv_mul_cancel₀ (by linarith : 1-b ≠ 0)] at hm
  exact hnum.trans hm

lemma coupledNormalizer_pos {s b : ℝ} {K H : ℝ → ℝ}
    (hs : 0 ≤ s) (hb : b < 1)
    (hK : ∀ x ∈ Icc (0:ℝ) 1, 0 ≤ K x ∧ K x ≤ 1)
    (hH : ∀ x ∈ Icc (0:ℝ) 1, H x ≤ b)
    (hw : ∃ x ∈ Icc (0:ℝ) 1, 0 < x ∧ 0 < K x) :
    0 < coupledNormalizer s K H := by
  rcases hw with ⟨x, hx, hxp, hkp⟩
  have hden : 0 < 1-H x := by have := hH x hx; linarith
  exact (div_pos (mul_pos (Real.rpow_pos_of_pos hxp s) hkp) hden).trans_le
    (le_csSup (coupledNormalizer_bdd hs hb hK hH) ⟨x, hx, rfl⟩)

lemma coupledProfile_range {s b x : ℝ} {K H : ℝ → ℝ}
    (hs : 0 ≤ s) (hb : b < 1)
    (hK : ∀ x ∈ Icc (0:ℝ) 1, 0 ≤ K x ∧ K x ≤ 1)
    (hH : ∀ x ∈ Icc (0:ℝ) 1, 0 ≤ H x ∧ H x ≤ b)
    (hw : ∃ x ∈ Icc (0:ℝ) 1, 0 < x ∧ 0 < K x) (hx : x ∈ Icc (0:ℝ) 1) :
    0 ≤ coupledProfile s K H x ∧ coupledProfile s K H x ≤ 1 := by
  have ha := coupledNormalizer_pos hs hb hK (fun x hx => (hH x hx).2) hw
  have hden : 0 < 1-H x := by have := (hH x hx).2; linarith
  have hext : x^s*K x/(1-H x) ≤ coupledNormalizer s K H :=
    le_csSup (coupledNormalizer_bdd hs hb hK (fun x hx => (hH x hx).2)) ⟨x, hx, rfl⟩
  have hnum := (div_le_iff₀ hden).mp hext
  unfold coupledProfile
  constructor
  · exact add_nonneg (div_nonneg (mul_nonneg (Real.rpow_nonneg hx.1 s) (hK x hx).1) ha.le)
      (hH x hx).1
  · have := (div_le_iff₀ ha).mpr (show x^s*K x ≤ (1-H x)*coupledNormalizer s K H by nlinarith)
    linarith

lemma endpointKernel_positive_witness {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6) :
    ∃ x ∈ Icc (0:ℝ) 1, 0 < x ∧ 0 < endpointKernel N d x := by
  let x : ℝ := (24*(N:ℝ)^2)⁻¹
  have hn : (1:ℝ) ≤ N := by exact_mod_cast hN
  have hx : 0 < x := by dsimp [x]; positivity
  have hx1 : x ≤ 1 := by
    dsimp [x]
    apply inv_le_one_of_one_le₀
    nlinarith
  refine ⟨x, ⟨hx.le, hx1⟩, hx, ?_⟩
  have hid : 24*(N:ℝ)^2*x=1 := by dsimp [x]; field_simp
  have hlow := endpointKernel_linear_deficit hN hd hx.le hx1
  linarith

def lowShoulder (N : ℕ) (s f x : ℝ) : ℝ :=
  f * endpointProfile N 2 s x * (1-endpointKernel N 2 x)

def lowNormalizer (N : ℕ) (s f : ℝ) : ℝ :=
  coupledNormalizer s (endpointKernel N 2) (lowShoulder N s f)

def lowProfile (N : ℕ) (s f x : ℝ) : ℝ :=
  coupledProfile s (endpointKernel N 2) (lowShoulder N s f) x

def highShoulderWeight (N : ℕ) (f x : ℝ) : ℝ :=
  f + (1-f)*(1-endpointKernel N 3 x)^2

def highShoulder (N : ℕ) (s f ω x : ℝ) : ℝ :=
  ω * endpointProfile N 6 s x * (1-endpointKernel N 6 x) * highShoulderWeight N f x

def highNormalizer (N : ℕ) (s f ω : ℝ) : ℝ :=
  coupledNormalizer s (endpointKernel N 6) (highShoulder N s f ω)

def highProfile (N : ℕ) (s f ω x : ℝ) : ℝ :=
  coupledProfile s (endpointKernel N 6) (highShoulder N s f ω) x

lemma lowShoulder_range {N : ℕ} (hN : 0 < N) {s f x : ℝ}
    (hs : 0 < s) (hf : 0 ≤ f) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    0 ≤ lowShoulder N s f x ∧ lowShoulder N s f x ≤ f := by
  have hj := endpointProfile_range hN (by norm_num : 2 ≤ 6) hs hx hx1
  have hk0 := endpointKernel_nonneg N 2 x
  have hk1 := endpointKernel_le_one hN 2 hx hx1
  unfold lowShoulder
  constructor
  · exact mul_nonneg (mul_nonneg hf hj.1) (sub_nonneg.mpr hk1)
  · have hfj : f*endpointProfile N 2 s x ≤ f := mul_le_of_le_one_right hf hj.2
    exact (mul_le_of_le_one_right (mul_nonneg hf hj.1) (by linarith : 1-endpointKernel N 2 x ≤ 1)).trans hfj

lemma highShoulderWeight_range {N : ℕ} (hN : 0 < N) {f x : ℝ}
    (hf : 0 ≤ f) (hf1 : f ≤ 1) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    0 ≤ highShoulderWeight N f x ∧ highShoulderWeight N f x ≤ 1 := by
  have hr0 := endpointKernel_nonneg N 3 x
  have hr1 := endpointKernel_le_one hN 3 hx hx1
  have hr2 : (1-endpointKernel N 3 x)^2 ≤ 1 := by nlinarith
  unfold highShoulderWeight
  constructor
  · exact add_nonneg hf (mul_nonneg (sub_nonneg.mpr hf1) (sq_nonneg _))
  · nlinarith [mul_nonneg (sub_nonneg.mpr hf1) (sub_nonneg.mpr hr2)]

lemma highShoulder_range {N : ℕ} (hN : 0 < N) {s f ω x : ℝ}
    (hs : 0 < s) (hf : 0 ≤ f) (hf1 : f ≤ 1) (hω : 0 ≤ ω)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    0 ≤ highShoulder N s f ω x ∧ highShoulder N s f ω x ≤ ω := by
  have hj := endpointProfile_range hN (by norm_num : 6 ≤ 6) hs hx hx1
  have hk0 := endpointKernel_nonneg N 6 x
  have hk1 := endpointKernel_le_one hN 6 hx hx1
  have hw := highShoulderWeight_range hN hf hf1 hx hx1
  unfold highShoulder
  have hbase : 0 ≤ ω*endpointProfile N 6 s x*(1-endpointKernel N 6 x) :=
    mul_nonneg (mul_nonneg hω hj.1) (sub_nonneg.mpr hk1)
  constructor
  · exact mul_nonneg hbase hw.1
  · calc
      _ ≤ ω*endpointProfile N 6 s x*(1-endpointKernel N 6 x) := mul_le_of_le_one_right hbase hw.2
      _ ≤ ω*endpointProfile N 6 s x := mul_le_of_le_one_right (mul_nonneg hω hj.1) (by linarith)
      _ ≤ ω := mul_le_of_le_one_right hω hj.2

theorem lowNormalizer_pos {N : ℕ} (hN : 0 < N) {s f : ℝ}
    (hs : 0 < s) (hf : 0 ≤ f) (hf1 : f < 1) : 0 < lowNormalizer N s f := by
  exact coupledNormalizer_pos hs.le hf1
    (fun x hx => ⟨endpointKernel_nonneg N 2 x, endpointKernel_le_one hN 2 hx.1 hx.2⟩)
    (fun _x hx => (lowShoulder_range hN hs hf hx.1 hx.2).2)
    (endpointKernel_positive_witness hN (by norm_num))

theorem lowProfile_range {N : ℕ} (hN : 0 < N) {s f x : ℝ}
    (hs : 0 < s) (hf : 0 ≤ f) (hf1 : f < 1) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    0 ≤ lowProfile N s f x ∧ lowProfile N s f x ≤ 1 := by
  exact coupledProfile_range hs.le hf1
    (fun x hx => ⟨endpointKernel_nonneg N 2 x, endpointKernel_le_one hN 2 hx.1 hx.2⟩)
    (fun x hx => lowShoulder_range hN hs hf hx.1 hx.2)
    (endpointKernel_positive_witness hN (by norm_num)) ⟨hx, hx1⟩

theorem highNormalizer_pos {N : ℕ} (hN : 0 < N) {s f ω : ℝ}
    (hs : 0 < s) (hf : 0 ≤ f) (hf1 : f ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1) :
    0 < highNormalizer N s f ω := by
  exact coupledNormalizer_pos hs.le hω1
    (fun x hx => ⟨endpointKernel_nonneg N 6 x, endpointKernel_le_one hN 6 hx.1 hx.2⟩)
    (fun _x hx => (highShoulder_range hN hs hf hf1 hω hx.1 hx.2).2)
    (endpointKernel_positive_witness hN (by norm_num))

theorem highProfile_range {N : ℕ} (hN : 0 < N) {s f ω x : ℝ}
    (hs : 0 < s) (hf : 0 ≤ f) (hf1 : f ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    0 ≤ highProfile N s f ω x ∧ highProfile N s f ω x ≤ 1 := by
  exact coupledProfile_range hs.le hω1
    (fun x hx => ⟨endpointKernel_nonneg N 6 x, endpointKernel_le_one hN 6 hx.1 hx.2⟩)
    (fun x hx => highShoulder_range hN hs hf hf1 hω hx.1 hx.2)
    (endpointKernel_positive_witness hN (by norm_num)) ⟨hx, hx1⟩

@[simp] theorem lowProfile_zero (N : ℕ) {s : ℝ} (hs : 0 < s) (f : ℝ) :
    lowProfile N s f 0 = 0 := by
  simp [lowProfile, coupledProfile, lowShoulder, Real.zero_rpow hs.ne']

@[simp] theorem highProfile_zero (N : ℕ) {s : ℝ} (hs : 0 < s) (f ω : ℝ) :
    highProfile N s f ω 0 = 0 := by
  simp [highProfile, coupledProfile, highShoulder, Real.zero_rpow hs.ne']

def lowProfilePolynomial (N : ℕ) (s f : ℝ) : ℝ[X] :=
  C (lowNormalizer N s f)⁻¹ * endpointKernelPolynomial N 2 +
    C f * endpointProfilePolynomial N 2 s * (1-endpointKernelPolynomial N 2)

def highShoulderWeightPolynomial (N : ℕ) (f : ℝ) : ℝ[X] :=
  C f + C (1-f)*(1-endpointKernelPolynomial N 3)^2

def highProfilePolynomial (N : ℕ) (s f ω : ℝ) : ℝ[X] :=
  C (highNormalizer N s f ω)⁻¹ * endpointKernelPolynomial N 6 +
    C ω * endpointProfilePolynomial N 6 s * (1-endpointKernelPolynomial N 6) *
      highShoulderWeightPolynomial N f

lemma highShoulderWeightPolynomial_eval {N : ℕ} (hN : 0 < N) (f : ℝ)
    {x : ℝ} (hx1 : x ≤ 1) :
    (highShoulderWeightPolynomial N f).eval x = highShoulderWeight N f x := by
  simp [highShoulderWeightPolynomial, highShoulderWeight, endpointKernelPolynomial_eval hN 3 hx1]

theorem lowProfile_polynomial {N : ℕ} (hN : 0 < N) {s f x : ℝ}
    (hs : 0 < s) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    lowProfile N s f x = x^s * (lowProfilePolynomial N s f).eval x := by
  simp only [lowProfile, coupledProfile, lowShoulder, lowProfilePolynomial,
    eval_add, eval_mul, eval_C, eval_sub, eval_one, endpointKernelPolynomial_eval hN 2 hx1,
    endpointProfile_polynomial hN 2 hs hx hx1]
  unfold lowNormalizer
  ring

theorem highProfile_polynomial {N : ℕ} (hN : 0 < N) {s f ω x : ℝ}
    (hs : 0 < s) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    highProfile N s f ω x = x^s * (highProfilePolynomial N s f ω).eval x := by
  simp only [highProfile, coupledProfile, highShoulder, highProfilePolynomial,
    eval_add, eval_mul, eval_C, eval_sub, eval_one, endpointKernelPolynomial_eval hN 6 hx1,
    endpointProfile_polynomial hN 6 hs hx hx1, highShoulderWeightPolynomial_eval hN f hx1]
  unfold highNormalizer
  ring

theorem lowProfile_one {N : ℕ} (hN : 0 < N) {s : ℝ} (hs : 0 < s) (f : ℝ) :
    lowProfile N s f 1 = endpointKernel N 2 1 / lowNormalizer N s f +
      f * (1-endpointKernel N 2 1) := by
  simp [lowProfile, coupledProfile, lowShoulder, lowNormalizer,
    endpointProfile_one hN (by norm_num : 2 ≤ 6) hs]

theorem highProfile_one {N : ℕ} (hN : 0 < N) {s : ℝ} (hs : 0 < s) (f ω : ℝ) :
    highProfile N s f ω 1 = endpointKernel N 6 1 / highNormalizer N s f ω +
      ω * (1-endpointKernel N 6 1) * highShoulderWeight N f 1 := by
  simp [highProfile, coupledProfile, highShoulder, highNormalizer,
    endpointProfile_one hN (by norm_num : 6 ≤ 6) hs]

lemma weightedPrimitivePolynomial_natDegree (P : ℝ[X]) (s : ℝ) :
    (weightedPrimitivePolynomial P s).natDegree ≤ P.natDegree := by
  apply natDegree_sum_le_of_forall_le
  intro j hj
  exact (natDegree_monomial_le _).trans (le_natDegree_of_mem_supp j hj)

lemma endpointSquarePolynomial_natDegree (n : ℕ) :
    (endpointSquarePolynomial n).natDegree ≤ n := by
  have hlinear : ((2:ℝ[X])-4*X).natDegree ≤ 1 := by compute_degree
  induction n using Nat.twoStepInduction with
  | zero => simp [endpointSquarePolynomial]
  | one => simp only [endpointSquarePolynomial]; compute_degree
  | more n h0 h1 =>
    rw [endpointSquarePolynomial]
    have hmul := natDegree_mul_le_of_le hlinear h1
    have hsub := natDegree_sub_le_of_le hmul h0
    have hadd := natDegree_add_le_of_le hsub (show (2:ℝ[X]).natDegree ≤ 0 by simp)
    exact hadd.trans (by omega)

lemma endpointKernelPolynomial_natDegree (N d : ℕ) :
    (endpointKernelPolynomial N d).natDegree ≤ d*(N-1) := by
  unfold endpointKernelPolynomial
  apply natDegree_pow_le_of_le
  exact (natDegree_C_mul_le _ _).trans (endpointSquarePolynomial_natDegree _)

lemma endpointProfilePolynomial_natDegree (N d : ℕ) (s : ℝ) :
    (endpointProfilePolynomial N d s).natDegree ≤ d*(N-1) := by
  exact (natDegree_C_mul_le _ _).trans
    ((weightedPrimitivePolynomial_natDegree _ _).trans (endpointKernelPolynomial_natDegree N d))

lemma highShoulderWeightPolynomial_natDegree (N : ℕ) (f : ℝ) :
    (highShoulderWeightPolynomial N f).natDegree ≤ 6*(N-1) := by
  have hK := endpointKernelPolynomial_natDegree N 3
  have hsub : (1-endpointKernelPolynomial N 3).natDegree ≤ 3*(N-1) :=
    (natDegree_sub_le _ _).trans (by simpa using hK)
  have hp : ((1-endpointKernelPolynomial N 3)^2).natDegree ≤ 6*(N-1) := by
    exact (natDegree_pow_le_of_le 2 hsub).trans (by omega)
  have hm := (natDegree_C_mul_le (1-f) ((1-endpointKernelPolynomial N 3)^2)).trans hp
  unfold highShoulderWeightPolynomial
  exact (natDegree_add_le _ _).trans (by simpa using hm)

/-- The actual low profile has the manuscript's degree bound `4(N-1)`. -/
theorem lowProfilePolynomial_natDegree (N : ℕ) (s f : ℝ) :
    (lowProfilePolynomial N s f).natDegree ≤ 4*(N-1) := by
  have hK := endpointKernelPolynomial_natDegree N 2
  have hJ := endpointProfilePolynomial_natDegree N 2 s
  have hsub : (1-endpointKernelPolynomial N 2).natDegree ≤ 2*(N-1) :=
    (natDegree_sub_le _ _).trans (by simpa using hK)
  have hleft := (natDegree_C_mul_le (lowNormalizer N s f)⁻¹ _).trans hK
  have hright := natDegree_mul_le_of_le ((natDegree_C_mul_le f _).trans hJ) hsub
  unfold lowProfilePolynomial
  exact (natDegree_add_le _ _).trans (by omega)

/-- The actual high profile has the manuscript's degree bound `18(N-1)`. -/
theorem highProfilePolynomial_natDegree (N : ℕ) (s f ω : ℝ) :
    (highProfilePolynomial N s f ω).natDegree ≤ 18*(N-1) := by
  have hK := endpointKernelPolynomial_natDegree N 6
  have hJ := endpointProfilePolynomial_natDegree N 6 s
  have hW := highShoulderWeightPolynomial_natDegree N f
  have hsub : (1-endpointKernelPolynomial N 6).natDegree ≤ 6*(N-1) :=
    (natDegree_sub_le _ _).trans (by simpa using hK)
  have hleft := (natDegree_C_mul_le (highNormalizer N s f ω)⁻¹ _).trans hK
  have hright := natDegree_mul_le_of_le
    (natDegree_mul_le_of_le ((natDegree_C_mul_le ω _).trans hJ) hsub) hW
  unfold highProfilePolynomial
  exact (natDegree_add_le _ _).trans (by omega)

lemma endpointProfile_continuousOn {N : ℕ} (hN : 0 < N) (d : ℕ)
    {s : ℝ} (hs : 0 < s) : ContinuousOn (endpointProfile N d s) (Icc (0:ℝ) 1) := by
  have hc : Continuous (fun x : ℝ => x^s*(endpointProfilePolynomial N d s).eval x) :=
    (Real.continuous_rpow_const hs.le).mul (endpointProfilePolynomial N d s).continuous
  exact hc.continuousOn.congr (fun x hx => endpointProfile_polynomial hN d hs hx.1 hx.2)

lemma lowShoulder_continuousOn {N : ℕ} (hN : 0 < N) {s : ℝ} (hs : 0 < s) (f : ℝ) :
    ContinuousOn (lowShoulder N s f) (Icc (0:ℝ) 1) :=
  (continuousOn_const.mul (endpointProfile_continuousOn hN 2 hs)).mul
    (continuousOn_const.sub (endpointKernel_continuous N 2).continuousOn)

lemma highShoulder_continuousOn {N : ℕ} (hN : 0 < N) {s : ℝ} (hs : 0 < s) (f ω : ℝ) :
    ContinuousOn (highShoulder N s f ω) (Icc (0:ℝ) 1) := by
  have hw : Continuous (highShoulderWeight N f) :=
    continuous_const.add (continuous_const.mul
      ((continuous_const.sub (endpointKernel_continuous N 3)).pow 2))
  exact ((continuousOn_const.mul (endpointProfile_continuousOn hN 6 hs)).mul
    (continuousOn_const.sub (endpointKernel_continuous N 6).continuousOn)).mul hw.continuousOn

lemma coupledNormalizer_attained {s b : ℝ} {K H : ℝ → ℝ} (hs : 0 ≤ s) (hb : b < 1)
    (hK : ContinuousOn K (Icc (0:ℝ) 1)) (hHc : ContinuousOn H (Icc (0:ℝ) 1))
    (hH : ∀ x ∈ Icc (0:ℝ) 1, H x ≤ b) :
    ∃ x ∈ Icc (0:ℝ) 1, coupledNormalizer s K H = x^s*K x/(1-H x) := by
  have hc : ContinuousOn (fun x : ℝ => x^s*K x/(1-H x)) (Icc (0:ℝ) 1) :=
    ((Real.continuous_rpow_const hs).continuousOn.mul hK).div (continuousOn_const.sub hHc)
      (fun x hx => by have := hH x hx; linarith)
  have hi := isCompact_Icc.image_of_continuousOn hc
  have hn : ((fun x : ℝ => x^s*K x/(1-H x)) '' Icc (0:ℝ) 1).Nonempty :=
    (nonempty_Icc.mpr (by norm_num : (0:ℝ) ≤ 1)).image _
  rcases hi.sSup_mem hn with ⟨x, hx, heq⟩
  exact ⟨x, hx, heq.symm⟩

theorem lowNormalizer_attained {N : ℕ} (hN : 0 < N) {s f : ℝ}
    (hs : 0 < s) (hf : 0 ≤ f) (hf1 : f < 1) :
    ∃ x ∈ Icc (0:ℝ) 1, lowNormalizer N s f =
      x^s*endpointKernel N 2 x/(1-lowShoulder N s f x) :=
  coupledNormalizer_attained hs.le hf1 (endpointKernel_continuous N 2).continuousOn
    (lowShoulder_continuousOn hN hs f) (fun _x hx => (lowShoulder_range hN hs hf hx.1 hx.2).2)

theorem highNormalizer_attained {N : ℕ} (hN : 0 < N) {s f ω : ℝ}
    (hs : 0 < s) (hf : 0 ≤ f) (hf1 : f ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1) :
    ∃ x ∈ Icc (0:ℝ) 1, highNormalizer N s f ω =
      x^s*endpointKernel N 6 x/(1-highShoulder N s f ω x) :=
  coupledNormalizer_attained hs.le hω1 (endpointKernel_continuous N 6).continuousOn
    (highShoulder_continuousOn hN hs f ω)
    (fun _x hx => (highShoulder_range hN hs hf hf1 hω hx.1 hx.2).2)

lemma weightedPrimitivePolynomial_coefficientMass (P : ℝ[X]) {s : ℝ} (hs : 0 < s) :
    coefficientMass (weightedPrimitivePolynomial P s) ≤ coefficientMass P / s := by
  calc
    _ ≤ ∑ j ∈ P.support, |P.coeff j/(s+j)| := by
      simpa only [coefficientMass_monomial] using
        coefficientMass_sum_le P.support (fun j => monomial j (P.coeff j/(s+j)))
    _ ≤ ∑ j ∈ P.support, |P.coeff j|/s := by
      apply Finset.sum_le_sum
      intro j _
      rw [abs_div, abs_of_pos (by positivity : 0 < s+(j:ℝ))]
      exact div_le_div_of_nonneg_left (abs_nonneg _) hs (le_add_of_nonneg_right (Nat.cast_nonneg j))
    _ = coefficientMass P/s := by simp [coefficientMass, Polynomial.sum_def, Finset.sum_div]

lemma endpointIntegral_inverse_weight_bound {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) :
    (s*endpointIntegral N d s)⁻¹ ≤ 24*(N:ℝ)^2 := by
  let a : ℝ := (12*(N:ℝ)^2)⁻¹
  have hn : (1:ℝ) ≤ N := by exact_mod_cast hN
  have ha : 0 < a := by dsimp [a]; positivity
  have ha1 : a ≤ 1 := by
    dsimp [a]
    apply inv_le_one_of_one_le₀
    nlinarith
  have hr := Real.self_le_rpow_of_le_one ha.le ha1 hs1
  have hi := endpointIntegral_pos hN hd hs
  have hl := (div_le_iff₀ (mul_pos hs (by linarith : 0 < s+1))).mp
    (endpointIntegral_lower hN hd hs)
  have hm : 0 ≤ s*endpointIntegral N d s := mul_nonneg hs.le hi.le
  have hh : a ≤ 2*(s*endpointIntegral N d s) := by
    change a^s ≤ endpointIntegral N d s*(s*(s+1)) at hl
    nlinarith [mul_nonneg hm (sub_nonneg.mpr hs1)]
  have hid : 12*(N:ℝ)^2*a=1 := by dsimp [a]; field_simp
  rw [inv_eq_one_div]
  apply (div_le_iff₀ (mul_pos hs hi)).mpr
  nlinarith [mul_le_mul_of_nonneg_left hh (show 0 ≤ 12*(N:ℝ)^2 by positivity)]

/-- A bound independent of the fractional exponent, for the actual integral polynomial. -/
theorem endpointProfilePolynomial_coefficientMass {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s : ℝ} (hs : 0 < s) (hs1 : s ≤ 1) :
    coefficientMass (endpointProfilePolynomial N d s) ≤
      24*(N:ℝ)^2 * (9:ℝ)^((N-1)*d) := by
  have hi := endpointIntegral_pos hN hd hs
  have hw := weightedPrimitivePolynomial_coefficientMass (endpointKernelPolynomial N d) hs
  have hk := endpointKernelPolynomial_coefficientMass hN d
  have hi' := endpointIntegral_inverse_weight_bound hN hd hs hs1
  unfold endpointProfilePolynomial
  rw [coefficientMass_C_mul, abs_of_pos (inv_pos.mpr hi)]
  calc
    _ ≤ (endpointIntegral N d s)⁻¹ * (coefficientMass (endpointKernelPolynomial N d)/s) :=
      mul_le_mul_of_nonneg_left hw (inv_nonneg.mpr hi.le)
    _ = (s*endpointIntegral N d s)⁻¹ * coefficientMass (endpointKernelPolynomial N d) := by field_simp
    _ ≤ (24*(N:ℝ)^2) * (9:ℝ)^((N-1)*d) :=
      mul_le_mul hi' hk (coefficientMass_nonneg _) (by positivity)

lemma coupledNormalizer_inv_bound {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s b : ℝ} {H : ℝ → ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hb : b < 1)
    (hH : ∀ x ∈ Icc (0:ℝ) 1, 0 ≤ H x ∧ H x ≤ b) :
    (coupledNormalizer s (endpointKernel N d) H)⁻¹ ≤ 48*(N:ℝ)^2 := by
  let x : ℝ := (24*(N:ℝ)^2)⁻¹
  have hn : (1:ℝ) ≤ N := by exact_mod_cast hN
  have hx : 0 < x := by dsimp [x]; positivity
  have hx1 : x ≤ 1 := by
    dsimp [x]
    apply inv_le_one_of_one_le₀
    nlinarith
  have hid : 24*(N:ℝ)^2*x=1 := by dsimp [x]; field_simp
  have hK := fun y (hy : y ∈ Icc (0:ℝ) 1) =>
    And.intro (endpointKernel_nonneg N d y) (endpointKernel_le_one hN d hy.1 hy.2)
  have ha := coupledNormalizer_pos hs.le hb hK (fun y hy => (hH y hy).2)
    (endpointKernel_positive_witness hN hd)
  have hden : 0 < 1-H x := by have := (hH x ⟨hx.le,hx1⟩).2; linarith
  have hnum : 0 ≤ x^s*endpointKernel N d x :=
    mul_nonneg (Real.rpow_nonneg hx.le s) (endpointKernel_nonneg N d x)
  have hratio : x^s*endpointKernel N d x ≤ x^s*endpointKernel N d x/(1-H x) := by
    apply (le_div_iff₀ hden).mpr
    nlinarith [mul_nonneg hnum (hH x ⟨hx.le,hx1⟩).1]
  have hext : x^s*endpointKernel N d x ≤ coupledNormalizer s (endpointKernel N d) H :=
    hratio.trans (le_csSup (coupledNormalizer_bdd hs.le hb hK (fun y hy => (hH y hy).2))
      ⟨x, ⟨hx.le,hx1⟩, rfl⟩)
  have hr := Real.self_le_rpow_of_le_one hx.le hx1 hs1
  have hk := endpointKernel_linear_deficit hN hd hx.le hx1
  have hhalf : (1:ℝ)/2 ≤ endpointKernel N d x := by linarith
  have hl : x/2 ≤ coupledNormalizer s (endpointKernel N d) H := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hr) (endpointKernel_nonneg N d x),
      mul_nonneg hx.le (sub_nonneg.mpr hhalf)]
  rw [inv_eq_one_div]
  apply (div_le_iff₀ ha).mpr
  nlinarith [mul_le_mul_of_nonneg_left hl (show 0 ≤ 48*(N:ℝ)^2 by positivity)]

theorem lowProfilePolynomial_coefficientMass {N : ℕ} (hN : 0 < N) {s f : ℝ}
    (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f < 1) :
    coefficientMass (lowProfilePolynomial N s f) ≤
      96*(N:ℝ)^2 * (9:ℝ)^(4*(N-1)) := by
  let r : ℝ := 9^((N-1)*2)
  have hr : 1 ≤ r := one_le_pow₀ (by norm_num)
  have hk : coefficientMass (endpointKernelPolynomial N 2) ≤ r := endpointKernelPolynomial_coefficientMass hN 2
  have hj : coefficientMass (endpointProfilePolynomial N 2 s) ≤ 24*(N:ℝ)^2*r :=
    endpointProfilePolynomial_coefficientMass hN (by norm_num) hs hs1
  have ha := coupledNormalizer_inv_bound hN (by norm_num : 2 ≤ 6) hs hs1 hf1
    (fun _x hx => lowShoulder_range hN hs hf hx.1 hx.2)
  have hap := lowNormalizer_pos hN hs hf hf1
  change (lowNormalizer N s f)⁻¹ ≤ 48*(N:ℝ)^2 at ha
  have hleft : coefficientMass (C (lowNormalizer N s f)⁻¹ * endpointKernelPolynomial N 2) ≤
      48*(N:ℝ)^2*r := by
    rw [coefficientMass_C_mul, abs_of_pos (inv_pos.mpr hap)]
    exact mul_le_mul ha hk (coefficientMass_nonneg _) (by positivity)
  have hsub : coefficientMass (1-endpointKernelPolynomial N 2) ≤ 1+r := by
    simpa using (coefficientMass_sub_le 1 (endpointKernelPolynomial N 2)).trans (by simpa using add_le_add_left hk 1)
  have hscaled : coefficientMass (C f * endpointProfilePolynomial N 2 s) ≤ 24*(N:ℝ)^2*r := by
    rw [coefficientMass_C_mul, abs_of_nonneg hf]
    exact (mul_le_of_le_one_left (coefficientMass_nonneg _) hf1.le).trans hj
  have hright := (coefficientMass_mul_le (C f*endpointProfilePolynomial N 2 s)
    (1-endpointKernelPolynomial N 2)).trans
      (mul_le_mul hscaled hsub (coefficientMass_nonneg _) (by positivity))
  have hsum := (coefficientMass_add_le
    (C (lowNormalizer N s f)⁻¹*endpointKernelPolynomial N 2)
    (C f*endpointProfilePolynomial N 2 s*(1-endpointKernelPolynomial N 2))).trans
      (add_le_add hleft hright)
  have hr2 : r^2 = (9:ℝ)^(4*(N-1)) := by dsimp [r]; rw [← pow_mul]; congr 1; omega
  change coefficientMass (lowProfilePolynomial N s f) ≤ _ at hsum
  rw [← hr2]
  nlinarith [mul_nonneg (show 0 ≤ 48*(N:ℝ)^2 by positivity)
    (show 0 ≤ r^2-r by nlinarith)]

lemma highShoulderWeightPolynomial_coefficientMass {N : ℕ} (hN : 0 < N) {f : ℝ}
    (hf : 0 ≤ f) (hf1 : f ≤ 1) :
    coefficientMass (highShoulderWeightPolynomial N f) ≤ 5*(9:ℝ)^((N-1)*6) := by
  let r : ℝ := 9^((N-1)*3)
  have hr : 1 ≤ r := one_le_pow₀ (by norm_num)
  have hk : coefficientMass (endpointKernelPolynomial N 3) ≤ r := endpointKernelPolynomial_coefficientMass hN 3
  have hsub : coefficientMass (1-endpointKernelPolynomial N 3) ≤ 1+r := by
    simpa using (coefficientMass_sub_le 1 (endpointKernelPolynomial N 3)).trans (by simpa using add_le_add_left hk 1)
  have hp := (coefficientMass_pow_le (1-endpointKernelPolynomial N 3) 2).trans
    (pow_le_pow_left₀ (coefficientMass_nonneg _) hsub 2)
  have hm : coefficientMass (C (1-f)*(1-endpointKernelPolynomial N 3)^2) ≤ (1+r)^2 := by
    rw [coefficientMass_C_mul, abs_of_nonneg (sub_nonneg.mpr hf1)]
    exact (mul_le_of_le_one_left (coefficientMass_nonneg _) (by linarith : 1-f ≤ 1)).trans hp
  have hsum := (coefficientMass_add_le (C f) (C (1-f)*(1-endpointKernelPolynomial N 3)^2)).trans
    (add_le_add (show coefficientMass (C f) ≤ 1 by simpa [abs_of_nonneg hf] using hf1) hm)
  have hr2 : r^2=(9:ℝ)^((N-1)*6) := by dsimp [r]; rw [← pow_mul]; congr 1; omega
  change coefficientMass (highShoulderWeightPolynomial N f) ≤ _ at hsum
  rw [← hr2]
  nlinarith

theorem highProfilePolynomial_coefficientMass {N : ℕ} (hN : 0 < N) {s f ω : ℝ}
    (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hω : 0 ≤ ω) (hω1 : ω < 1) :
    coefficientMass (highProfilePolynomial N s f ω) ≤
      288*(N:ℝ)^2 * (9:ℝ)^(18*(N-1)) := by
  let r : ℝ := 9^((N-1)*6)
  have hr : 1 ≤ r := one_le_pow₀ (by norm_num)
  have hk : coefficientMass (endpointKernelPolynomial N 6) ≤ r := endpointKernelPolynomial_coefficientMass hN 6
  have hj : coefficientMass (endpointProfilePolynomial N 6 s) ≤ 24*(N:ℝ)^2*r :=
    endpointProfilePolynomial_coefficientMass hN (by norm_num) hs hs1
  have hw : coefficientMass (highShoulderWeightPolynomial N f) ≤ 5*r :=
    highShoulderWeightPolynomial_coefficientMass hN hf hf1
  have ha := coupledNormalizer_inv_bound hN (by norm_num : 6 ≤ 6) hs hs1 hω1
    (fun _x hx => highShoulder_range hN hs hf hf1 hω hx.1 hx.2)
  have hap := highNormalizer_pos hN hs hf hf1 hω hω1
  change (highNormalizer N s f ω)⁻¹ ≤ 48*(N:ℝ)^2 at ha
  have hleft : coefficientMass (C (highNormalizer N s f ω)⁻¹ * endpointKernelPolynomial N 6) ≤
      48*(N:ℝ)^2*r := by
    rw [coefficientMass_C_mul, abs_of_pos (inv_pos.mpr hap)]
    exact mul_le_mul ha hk (coefficientMass_nonneg _) (by positivity)
  have hsub : coefficientMass (1-endpointKernelPolynomial N 6) ≤ 2*r := by
    have ht : coefficientMass (1-endpointKernelPolynomial N 6) ≤ 1+r :=
      (coefficientMass_sub_le 1 (endpointKernelPolynomial N 6)).trans
      (by simpa using add_le_add_left hk 1)
    linarith
  have hscaled : coefficientMass (C ω * endpointProfilePolynomial N 6 s) ≤ 24*(N:ℝ)^2*r := by
    rw [coefficientMass_C_mul, abs_of_nonneg hω]
    exact (mul_le_of_le_one_left (coefficientMass_nonneg _) hω1.le).trans hj
  have hmid := (coefficientMass_mul_le (C ω*endpointProfilePolynomial N 6 s)
    (1-endpointKernelPolynomial N 6)).trans
      (mul_le_mul hscaled hsub (coefficientMass_nonneg _) (by positivity))
  have hright := (coefficientMass_mul_le
    (C ω*endpointProfilePolynomial N 6 s*(1-endpointKernelPolynomial N 6))
    (highShoulderWeightPolynomial N f)).trans
      (mul_le_mul hmid hw (coefficientMass_nonneg _) (by positivity))
  have hsum := (coefficientMass_add_le
    (C (highNormalizer N s f ω)⁻¹*endpointKernelPolynomial N 6)
    (C ω*endpointProfilePolynomial N 6 s*(1-endpointKernelPolynomial N 6)*highShoulderWeightPolynomial N f)).trans
      (add_le_add hleft hright)
  have hr3 : r^3 = (9:ℝ)^(18*(N-1)) := by dsimp [r]; rw [← pow_mul]; congr 1; omega
  have hr13 : r ≤ r^3 := by nlinarith [sq_nonneg (r-1)]
  have hmul := mul_le_mul_of_nonneg_left hr13 (show 0 ≤ 48*(N:ℝ)^2 by positivity)
  change coefficientMass (highProfilePolynomial N s f ω) ≤ _ at hsum
  rw [← hr3]
  nlinarith

end Renyi
