import Renyi.InterpolationMomentBounds

/-! Uniform lower mass at the actual near node of the active interpolation factor. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- A large normalized principal atom controls the normalizer after multiplication
by its principal power, independently of the interpolation degree. -/
theorem active_principal_normalizer_upper {n : ℕ} (u : Fin (n+1) → ℝ)
    {a rho e : ℝ} (ha : 0 < a) (hrho : 0 ≤ rho)
    (hprincipal : 1/2 ≤ normalizedInterpolation u a rho e none) :
    interpolationNormalizer u a rho e*a^e ≤ 2*(1+rho) := by
  have hP := interpolationNormalizer_pos u (e := e) ha hrho
  change (1/2 : ℝ) ≤ ((1+rho)*a^(-e))/interpolationNormalizer u a rho e at hprincipal
  have hp := (le_div_iff₀ hP).mp hprincipal
  have hh := mul_le_mul_of_nonneg_right hp (Real.rpow_pos_of_pos ha e).le
  have hc : a^(-e)*a^e=1 := by rw [← Real.rpow_add ha]; simp
  have heq : ((1+rho)*a^(-e))*a^e=1+rho := by rw [mul_assoc,hc,mul_one]
  rw [heq] at hh
  nlinarith

/-- The negative mass contains the designated near node and is uniformly at
least a quarter of the active principal ratio. -/
theorem active_negative_mass_lower {n : ℕ} (u : Fin (n+1) → ℝ)
    {a b rho s : ℝ} (ha : 0 < a) (hb : 0 < b) (hrho : 0 ≤ rho) (hrho1 : rho ≤ 1)
    (hu0 : u 0=b) (hell : 1 ≤ lagrangeWeight u a 0)
    (hprincipal : 1/2 ≤ normalizedInterpolation u a rho s none) :
    (a/b)^s/4 ≤ ∑ i, negativeCoeff (normalizedInterpolation u a rho s i) := by
  let P := interpolationNormalizer u a rho s
  let ell := lagrangeWeight u a 0
  have hell0 : 0 < ell := zero_lt_one.trans_le hell
  have hP : 0 < P := interpolationNormalizer_pos u (e := s) ha hrho
  have hfactor : 1 ≤ 1+rho*a/b := by
    have hnonneg : 0 ≤ rho*a/b := by positivity
    linarith
  have hatom : negativeCoeff (normalizedInterpolation u a rho s (some 0)) =
      ell*(1+rho*a/b)*b^(-s)/P := by
    unfold negativeCoeff
    change max (-((-(ell*(1+rho*a/u 0)))*u 0^(-s)/P)) 0 = _
    rw [hu0]
    have hid : -((-(ell*(1+rho*a/b)))*b^(-s)/P)=ell*(1+rho*a/b)*b^(-s)/P := by ring
    rw [hid]
    apply max_eq_left
    positivity
  have hatomlow : b^(-s)/P ≤ negativeCoeff (normalizedInterpolation u a rho s (some 0)) := by
    rw [hatom]
    have hprod : 1 ≤ ell*(1+rho*a/b) :=
      one_le_mul_of_one_le_of_one_le hell hfactor
    exact div_le_div_of_nonneg_right
      (by have hh := mul_le_mul_of_nonneg_right hprod (Real.rpow_pos_of_pos hb (-s)).le; simpa only [one_mul] using hh) hP.le
  have hmass := Finset.single_le_sum
    (s := (Finset.univ : Finset (Option (Fin (n+1)))))
    (f := fun i => negativeCoeff (normalizedInterpolation u a rho s i))
    (fun i _ => le_max_right _ _) (Finset.mem_univ (some 0))
  have hPupper := active_principal_normalizer_upper u ha hrho hprincipal
  have hratio : (a/b)^s/4 ≤ b^(-s)/P := by
    rw [Real.div_rpow ha.le hb.le, Real.rpow_neg hb.le]
    apply (div_le_div_iff₀ (by norm_num : (0 : ℝ) < 4) hP).mpr
    have hbpow : 0 < b^s := Real.rpow_pos_of_pos hb s
    have hlim : P*a^s ≤ 4 := by dsimp [P]; linarith
    calc
      a^s/b^s*P = (P*a^s)/b^s := by ring
      _ ≤ 4/b^s := div_le_div_of_nonneg_right hlim hbpow.le
      _ = (b^s)⁻¹*4 := by ring
  exact hratio.trans (hatomlow.trans hmass)

end Renyi
