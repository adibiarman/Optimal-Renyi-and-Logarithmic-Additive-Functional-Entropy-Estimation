import Renyi.ActualNoiseBudget
import Renyi.ActualPilotReserveMean
import Renyi.NonintegerHistogram

/-! Numerical source-noise budgets imply the band for the one actual histogram statistic. -/
set_option maxHeartbeats 1000000
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory Polynomial
namespace Renyi

theorem nonintegerHistogramBoundary_eq_actualPilotTotalBoundary {k : ℕ} (p : Simplex k)
    (cp : ℝ≥0) {alpha eps Ch D cb lambda CL cL fL f M cu u0 B : ℝ}
    (hk : 0 < k) (ha : 1 < alpha) (hg : 0 < fractionalPart alpha)
    (hg1 : fractionalPart alpha < 1) (hD : 0 < D) :
    nonintegerHistogramBoundary (nonintegerPoissonMean k alpha eps D) cp p
      (actualSourcePolynomial k alpha eps Ch D cb lambda CL cL fL f M cu u0)
      (upperB k alpha eps D cb CL cL) alpha B
      (upperRescaling k alpha eps cu u0 * Real.exp (-upperE0 k alpha eps Ch / 8)) =
      actualPilotTotalBoundary p pilotSelectionCount pilotMainCount
        alpha eps Ch D cb lambda CL cL fL f M cu u0 cp B := by
  simp only [nonintegerHistogramBoundary, actualPilotTotalBoundary, actualSourcePolynomial,
    eval_mul, eval_C, nonintegerPoissonMean_coe hk ha hg hg1 hD]

/-- All three calibrated noise terms fit the same positive source margin.
Only the heavy-event interior remains to be supplied by deterministic calibration. -/
theorem general_noninteger_histogram_band {k : ℕ} (p : Simplex k) (cp : ℝ≥0)
    {alpha eps Ch D lambda CL cL C0 db u0 fL f M cu B c : ℝ}
    (hk : 0 < k) (ha : 3 / 2 ≤ alpha) (hg : 0 < fractionalPart alpha)
    (hg1 : fractionalPart alpha < 1) (heps : 0 < eps) (hCh : 0 ≤ Ch)
    (hD : 1 ≤ D) (hlambda : 0 < lambda) (hlambda4 : lambda ≤ 4)
    (hCL : 1 ≤ CL) (hcL : 0 < cL) (hC0 : 0 ≤ C0) (hdb : 0 ≤ db)
    (hcu : 0 ≤ cu) (hu0 : 0 < u0) (hc : 0 < c)
    (G : Set (PilotHistogram k))
    (hgood : (pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure.real Gᶜ ≤ 1 / 16)
    (hideal : ∀ h ∈ G,
      upperKappa alpha eps * powerSum p alpha +
        3 * c * actualBiasBudget p alpha eps Ch D 1 lambda CL cL C0 db u0 ≤
        nonintegerHistogramIdeal (nonintegerPoissonMean k alpha eps D) cp p
          (actualSourcePolynomial k alpha eps Ch D 1 lambda CL cL fL f M cu u0)
          (upperB k alpha eps D 1 CL cL) alpha B
          (upperRescaling k alpha eps cu u0 * Real.exp (-upperE0 k alpha eps Ch / 8))
          (2 * actualCutoffBudget k alpha eps Ch D 1 lambda CL cL C0 db) h ∧
      nonintegerHistogramIdeal (nonintegerPoissonMean k alpha eps D) cp p
          (actualSourcePolynomial k alpha eps Ch D 1 lambda CL cL fL f M cu u0)
          (upperB k alpha eps D 1 CL cL) alpha B
          (upperRescaling k alpha eps cu u0 * Real.exp (-upperE0 k alpha eps Ch / 8))
          (2 * actualCutoffBudget k alpha eps Ch D 1 lambda CL cL C0 db) h +
        3 * c * actualBiasBudget p alpha eps Ch D 1 lambda CL cL C0 db u0 ≤ powerSum p alpha)
    (hcount : pilotAveragedCountVariance pilotMainCount pilotSelectionCount ((cp : ℝ) * B * alpha)
      (upperCountDegree k alpha eps CL cL)
      (actualSourcePolynomial k alpha eps Ch D 1 lambda CL cL fL f M cu u0).coeff
      (upperSample k alpha eps D)
      (pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure
      (pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure ≤
        (c ^ 2 / 16) * (actualCountBudget p alpha eps Ch D 1 lambda CL cL C0 db u0) ^ 2)
    (hanchor : (actualSourcePolynomial k alpha eps Ch D 1 lambda CL cL fL f M cu u0).coeff 1 ^ 2 /
      upperSample k alpha eps D ≤ (c ^ 2 / 16) * (actualCountBudget p alpha eps Ch D 1 lambda CL cL C0 db u0) ^ 2)
    (hboundary : Integrable (actualPilotTotalBoundary p pilotSelectionCount pilotMainCount
      alpha eps Ch D 1 lambda CL cL fL f M cu u0 cp B)
      (pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure)
    (hboundaryMean : (∫ h, actualPilotTotalBoundary p pilotSelectionCount pilotMainCount
      alpha eps Ch D 1 lambda CL cL fL f M cu u0 cp B h
      ∂(pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure) ≤
        (c / 16) * actualCountBudget p alpha eps Ch D 1 lambda CL cL C0 db u0) :
    (pilotHistogramPMF (nonintegerPoissonMean k alpha eps D) cp p).toMeasure.real
      {h | nonintegerHistogramStatistic (nonintegerPoissonMean k alpha eps D) cp
          (actualSourcePolynomial k alpha eps Ch D 1 lambda CL cL fL f M cu u0)
          (upperCountDegree k alpha eps CL cL) alpha B
          (upperRescaling k alpha eps cu u0 * Real.exp (-upperE0 k alpha eps Ch / 8))
          (2 * actualCutoffBudget k alpha eps Ch D 1 lambda CL cL C0 db) h <
          upperKappa alpha eps * powerSum p alpha ∨
        powerSum p alpha < nonintegerHistogramStatistic (nonintegerPoissonMean k alpha eps D) cp
          (actualSourcePolynomial k alpha eps Ch D 1 lambda CL cL fL f M cu u0)
          (upperCountDegree k alpha eps CL cL) alpha B
          (upperRescaling k alpha eps cu u0 * Real.exp (-upperE0 k alpha eps Ch / 8))
          (2 * actualCutoffBudget k alpha eps Ch D 1 lambda CL cL C0 db) h} ≤ 1 / 4 := by
  have ha1 : 1 < alpha := by linarith
  have hDpos : 0 < D := zero_lt_one.trans_le hD
  have hn := upperSample_pos (ε := eps) hk ha1 hg hg1 hDpos
  have hncoe := nonintegerPoissonMean_coe (eps := eps) hk ha1 hg hg1 hDpos
  have hs := upperRescaling_range (k := k) (eps := eps) ha1 hg hg1 hcu hu0
  have hbudget := actual_noise_budgets p hk ha hg hg1 heps hCh hDpos (by norm_num : (0 : ℝ) < 1)
    hlambda hlambda4 hCL hcL (by simpa only [one_mul] using hCL) hC0 hdb hu0
  have hcompare := actualCountBudget_le_actualBiasBudget_cb_one p hk ha hg hg1 heps hCh hDpos
    hlambda hlambda4 hCL hcL hC0 hdb hu0
  have hsq := pow_le_pow_left₀ hbudget.1.le hcompare 2
  have hvar := mul_le_mul_of_nonneg_left hsq (show 0 ≤ c ^ 2 / 16 by positivity)
  have hmean := mul_le_mul_of_nonneg_left hcompare (show 0 ≤ c / 16 by positivity)
  have hcount' := hcount.trans hvar
  have hanchor' := hanchor.trans hvar
  have hboundaryMean' := hboundaryMean.trans hmean
  have hboundaryEq := nonintegerHistogramBoundary_eq_actualPilotTotalBoundary p cp hk ha1 hg hg1 hDpos
    (eps := eps) (Ch := Ch) (cb := 1) (lambda := lambda) (CL := CL) (cL := cL) (fL := fL) (f := f) (M := M) (cu := cu) (u0 := u0) (B := B)
  have hh := nonintegerHistogram_band
    (lo := upperKappa alpha eps * powerSum p alpha) (hi := powerSum p alpha)
    (deltaH := (1 / 16 : ℝ)) (deltaC := (1 / 16 : ℝ))
    (deltaA := (1 / 16 : ℝ)) (deltaE := (1 / 16 : ℝ))
    (nonintegerPoissonMean k alpha eps D) cp
    (by rw [hncoe]; exact hn) p _ (actualSourcePolynomial_natDegree ha1) _ alpha B _ _
    (mul_nonneg hs.1.le (Real.exp_pos _).le) G (mul_pos hc hbudget.2.1) hgood
    (by intro h hh; simpa only [mul_assoc] using hideal h hh)
    (by rw [hncoe]; convert hcount' using 1; ring)
    (by rw [hncoe]; convert hanchor' using 1; ring)
    (hboundaryEq.symm ▸ hboundary)
    (by rw [hboundaryEq]; convert hboundaryMean' using 1; ring)
  convert hh using 1
  norm_num

end Renyi
