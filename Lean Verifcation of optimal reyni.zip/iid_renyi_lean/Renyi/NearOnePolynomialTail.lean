import Renyi.NearOneFalseLight
import Renyi.NearOneUniformDegree

/-! Beta-preserving polynomial and affine mean tails under the actual pilot. -/
noncomputable section
open scoped BigOperators NNReal
open Polynomial
namespace Renyi

/-- A coefficient mass bound retains any small multiplicative factor under
exponential damping, with decay in the actual scaled argument. -/
theorem scaled_polynomial_tail_damping {P : ℝ[X]} {F L C Cd D H z : ℝ}
    (hF : 0≤F) (hL : 0≤L) (hC : 0≤C) (hCd : 0≤Cd)
    (hz : 1≤z) (hd : (P.natDegree:ℝ)≤Cd*L)
    (hc : coefficientMass P≤F*Real.exp (C*L)) (hH : C+Cd+D≤H) :
    Real.exp (-H*L*z)*|P.eval z|≤F*Real.exp (-D*L*z) := by
  have hz0 : 0<z := zero_lt_one.trans_le hz
  have hlog0 : 0≤Real.log z := Real.log_nonneg hz
  have hlog1 : Real.log z≤z := (Real.log_le_sub_one_of_pos hz0).trans (by linarith)
  have hdlog := (mul_le_mul_of_nonneg_right hd hlog0).trans
    (mul_le_mul_of_nonneg_left hlog1 (mul_nonneg hCd hL))
  have hCz := mul_le_mul_of_nonneg_left hz (mul_nonneg hC hL)
  have hscale := mul_le_mul_of_nonneg_right hH (mul_nonneg hL hz0.le)
  have hex : C*L+(P.natDegree:ℝ)*Real.log z-H*L*z≤-D*L*z := by
    nlinarith only [hdlog,hCz,hscale]
  calc
    _≤Real.exp (-H*L*z)*(F*Real.exp (C*L)*z^P.natDegree) :=
      mul_le_mul_of_nonneg_left ((polynomial_abs_eval_large hz).trans
        (mul_le_mul_of_nonneg_right hc (pow_nonneg hz0.le _))) (Real.exp_pos _).le
    _=F*Real.exp (C*L+(P.natDegree:ℝ)*Real.log z-H*L*z) := by
      rw [←Real.rpow_natCast,Real.rpow_def_of_pos hz0]
      rw [show Real.exp (-H*L*z)*(F*Real.exp (C*L)*Real.exp (Real.log z*(P.natDegree:ℝ)))=
        F*(Real.exp (-H*L*z)*Real.exp (C*L)*Real.exp (Real.log z*(P.natDegree:ℝ))) by ring,
        ←Real.exp_add,←Real.exp_add]
      congr 2
      ring
    _≤_ := mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr hex) hF

/-- The scaled polynomial inherits a beta-sized mass from the actual all-j
coefficient bound; all degree factors are absorbed exponentially. -/
theorem scaled_coefficient_mass_beta {P : ℝ[X]} {b alpha beta K Cd L : ℝ}
    (hb : 0<b) (hbeta : 0≤beta) (hK : 0<K) (hL : 1≤L)
    (hd : (P.natDegree:ℝ)≤Cd*L)
    (hc : ∀j,|P.coeff j|≤K*beta*b^(alpha-(j:ℝ))*Real.exp (K*L)) :
    coefficientMass (P.comp (Polynomial.C b*X))≤beta*b^alpha*Real.exp ((2*K+Cd+1)*L) := by
  have hbpow (j:ℕ) : b^(alpha-(j:ℝ))*b^j=b^alpha := by
    rw [←Real.rpow_natCast,←Real.rpow_add hb]
    congr 1
    ring
  have hcoef (j:ℕ) : |(P.comp (Polynomial.C b*X)).coeff j|≤K*beta*b^alpha*Real.exp (K*L) := by
    rw [Polynomial.comp_C_mul_X_coeff,abs_mul,abs_of_nonneg (pow_nonneg hb.le j)]
    have hh := mul_le_mul_of_nonneg_right (hc j) (pow_nonneg hb.le j)
    calc
      _≤K*beta*b^(alpha-(j:ℝ))*Real.exp (K*L)*b^j := hh
      _=K*beta*b^alpha*Real.exp (K*L) := by rw [mul_right_comm _ (Real.exp _) _,mul_assoc (K*beta),hbpow]
  have hdeg : (P.comp (Polynomial.C b*X)).natDegree≤P.natDegree := by
    have hlin : (C b*X : ℝ[X]).natDegree≤1 := by compute_degree
    exact Polynomial.natDegree_comp_le.trans (by simpa using Nat.mul_le_mul_left P.natDegree hlin)
  have hmass : coefficientMass (P.comp (Polynomial.C b*X))≤
      (((P.comp (Polynomial.C b*X)).natDegree:ℝ)+1)*(K*beta*b^alpha*Real.exp (K*L)) := by
    rw [coefficientMass,Polynomial.sum_over_range _ (by simp)]
    calc
      _≤∑ j∈Finset.range ((P.comp (Polynomial.C b*X)).natDegree+1),K*beta*b^alpha*Real.exp (K*L) :=
        Finset.sum_le_sum (fun j _ => hcoef j)
      _=_ := by simp [Finset.sum_const,Nat.cast_add,Nat.cast_one,nsmul_eq_mul]
  have hdegR : ((P.comp (Polynomial.C b*X)).natDegree:ℝ)+1≤(Cd+1)*L := by
    have hh : ((P.comp (Polynomial.C b*X)).natDegree:ℝ)≤P.natDegree := by exact_mod_cast hdeg
    nlinarith only [hh,hd,hL]
  have hde : ((P.comp (Polynomial.C b*X)).natDegree:ℝ)+1≤Real.exp ((Cd+1)*L) :=
    hdegR.trans ((by linarith : (Cd+1)*L≤(Cd+1)*L+1).trans (Real.add_one_le_exp _))
  have hKe : K≤Real.exp (K*L) := by
    have hh := mul_le_mul_of_nonneg_left hL hK.le
    have hh' := Real.add_one_le_exp (K*L)
    nlinarith only [hh,hh']
  have hfinal := mul_le_mul hde hKe hK.le (Real.exp_pos _).le
  have hfinal' := mul_le_mul_of_nonneg_right hfinal
    (show 0≤beta*b^alpha*Real.exp (K*L) by positivity)
  apply hmass.trans
  calc
    _=(((P.comp (Polynomial.C b*X)).natDegree:ℝ)+1)*K*(beta*b^alpha*Real.exp (K*L)) := by ring
    _≤Real.exp ((Cd+1)*L)*Real.exp (K*L)*(beta*b^alpha*Real.exp (K*L)) := hfinal'
    _=beta*b^alpha*Real.exp ((2*K+Cd+1)*L) := by
      rw [show Real.exp ((Cd+1)*L)*Real.exp (K*L)*(beta*b^alpha*Real.exp (K*L))=
        beta*b^alpha*(Real.exp ((Cd+1)*L)*Real.exp (K*L)*Real.exp (K*L)) by ring,
        ←Real.exp_add,←Real.exp_add]
      congr 2
      ring

/-- The actual Poisson light selector makes the residual polynomial and its
remaining affine-to-power error arbitrarily small, retaining beta. -/
theorem near_one_false_light_mean {P : ℝ[X]}
    {n b p beta L N CN C Cd Cw D cp cb B omega : ℝ}
    (hn : 0<n) (hb : 0<b) (hp : b≤p) (hbeta : 0≤beta)
    (hL : 1≤L) (hN : 1≤N) (hCN : 0≤CN) (hNL : N≤CN*L)
    (hC : 0≤C) (hCd : 0≤Cd) (hCw : 0≤Cw) (hD : 1≤D)
    (hcp : 0<cp) (hnb : n*b=cb*L) (hcut : 2*B*(1+beta)≤n*b)
    (hdegree : (P.natDegree:ℝ)≤Cd*L)
    (hcoef : coefficientMass (P.comp (Polynomial.C b*X))≤beta*b^(1+beta)*Real.exp (C*L))
    (hw : |omega-1|≤Cw*beta) (hpilot : 8*(C+Cd+D)≤cp*cb) :
    poissonLowerMass ⟨cp*n*p,mul_nonneg (mul_nonneg hcp.le hn.le) (hb.le.trans hp)⟩
      (cp*B*(1+beta))*|P.eval p+(b/N^2)^beta*p-omega*p^(1+beta)|≤
      (Real.exp (-D)+(Cw+1+2*CN)*Real.exp (1-D))*beta*p^(1+beta) := by
  have hp0 : 0<p := hb.trans_le hp
  let w := p/b
  let H := cp*cb/8
  let pilot : ℝ≥0 := ⟨cp*n*p,by positivity⟩
  let mass := poissonLowerMass pilot (cp*B*(1+beta))
  have hw1 : 1≤w := (one_le_div hb).mpr hp
  have hw0 : 0<w := zero_lt_one.trans_le hw1
  have hx : 1≤L*w := by nlinarith only [mul_le_mul hL hw1 zero_le_one (by linarith : 0≤L)]
  have hnp : n*b≤n*p := mul_le_mul_of_nonneg_left hp hn.le
  have hthreshold : cp*B*(1+beta)≤(pilot:ℝ)/2 := by
    change cp*B*(1+beta)≤cp*n*p/2
    nlinarith only [mul_le_mul_of_nonneg_left (hcut.trans hnp) hcp.le]
  have htail0 := poissonLowerMass_half pilot hthreshold
  have htail : mass≤Real.exp (-H*L*w) := by
    convert htail0 using 1
    congr 1
    dsimp [H,w,pilot]
    rw [show -(cp*n*p)/8= -(cp*(n*b)*(p/b))/8 by field_simp,hnb]
    ring
  have hmass0 : 0≤mass := poissonLowerMass_nonneg pilot _
  have hH : C+Cd+D≤H := by dsimp [H]; linarith only [hpilot]
  have hDH : D≤H := by linarith only [hH,hC,hCd]
  have hlin : (Polynomial.C b*X : ℝ[X]).natDegree≤1 := by compute_degree
  have hd : ((P.comp (Polynomial.C b*X)).natDegree:ℝ)≤Cd*L :=
    (show ((P.comp (Polynomial.C b*X)).natDegree:ℝ)≤P.natDegree by
      exact_mod_cast (Polynomial.natDegree_comp_le.trans (by simpa using Nat.mul_le_mul_left P.natDegree hlin))).trans hdegree
  have heval : (P.comp (Polynomial.C b*X)).eval w=P.eval p := by
    simp only [Polynomial.eval_comp,Polynomial.eval_mul,Polynomial.eval_C,Polynomial.eval_X]
    congr 1
    dsimp [w]
    field_simp
  have hpoly := scaled_polynomial_tail_damping (P:=P.comp (Polynomial.C b*X))
    (show 0≤beta*b^(1+beta) by positivity) (by linarith : 0≤L) hC hCd hw1 hd hcoef hH
  rw [heval] at hpoly
  have hpbpow := Real.rpow_le_rpow hb.le hp (show 0≤1+beta by linarith)
  have heD : Real.exp (-D*L*w)≤Real.exp (-D) := Real.exp_le_exp.mpr (by nlinarith only [hx,hD])
  have hpolyFinal : mass*|P.eval p|≤Real.exp (-D)*beta*p^(1+beta) := by
    apply (mul_le_mul_of_nonneg_right htail (abs_nonneg _)).trans (hpoly.trans _)
    calc
      _≤(beta*p^(1+beta))*Real.exp (-D) :=
        mul_le_mul (mul_le_mul_of_nonneg_left hpbpow hbeta) heD (Real.exp_pos _).le (by positivity)
      _=_ := by ring
  have hN0 : 0<N := zero_lt_one.trans_le hN
  have hN2 : 0<N^2 := sq_pos_of_pos hN0
  have hscale : (b/N^2)^beta*p-omega*p^(1+beta)=
      b^(1+beta)*((1/N^2)^beta*w-omega*w^(1+beta)) := by
    have hpw : p=b*w := by dsimp [w]; field_simp
    rw [hpw,show b/N^2=b*(1/N^2) by ring,
      Real.mul_rpow hb.le (by positivity : 0≤1/N^2),Real.mul_rpow hb.le hw0.le,
      Real.rpow_add hb,Real.rpow_one]
    ring
  have htailD : mass≤Real.exp (-D*L*w) := htail.trans
    (Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_right hDH (show 0≤L*w by positivity)]))
  have haff := near_one_affine_tail_damping hbeta hCw hw hD hL hN hCN hNL hw1
  have haffFinal : mass*|(b/N^2)^beta*p-omega*p^(1+beta)|≤
      (Cw+1+2*CN)*Real.exp (1-D)*beta*p^(1+beta) := by
    rw [hscale,abs_mul,abs_of_nonneg (Real.rpow_nonneg hb.le _)]
    calc
      _≤b^(1+beta)*(Real.exp (-D*L*w)*|(1/N^2)^beta*w-omega*w^(1+beta)|) := by
        convert mul_le_mul_of_nonneg_right htailD
          (mul_nonneg (Real.rpow_nonneg hb.le (1+beta)) (abs_nonneg ((1/N^2)^beta*w-omega*w^(1+beta)))) using 1; ring
      _≤b^(1+beta)*((Cw+1+2*CN)*Real.exp (1-D)*beta*w^(1+beta)) :=
        mul_le_mul_of_nonneg_left haff (Real.rpow_nonneg hb.le _)
      _=_ := by
        rw [show b^(1+beta)*((Cw+1+2*CN)*Real.exp (1-D)*beta*w^(1+beta))=
          ((Cw+1+2*CN)*Real.exp (1-D)*beta)*(b^(1+beta)*w^(1+beta)) by ring,
          ←Real.mul_rpow hb.le hw0.le,show b*w=p by dsimp [w]; field_simp]
  have htriangle := abs_add_le (P.eval p) ((b/N^2)^beta*p-omega*p^(1+beta))
  have ht := mul_le_mul_of_nonneg_left htriangle hmass0
  change mass*|P.eval p+(b/N^2)^beta*p-omega*p^(1+beta)|≤_
  rw [show P.eval p+(b/N^2)^beta*p-omega*p^(1+beta)=
    P.eval p+((b/N^2)^beta*p-omega*p^(1+beta)) by ring]
  nlinarith only [ht,hpolyFinal,haffFinal]

/-- One fixed tail exponent makes both terms arbitrarily small. -/
theorem near_one_tail_factor_small {Cw CN eta : ℝ}
    (hCw : 0≤Cw) (hCN : 0≤CN) (heta : 0<eta) :
    ∃ D : ℝ, 1≤D ∧ Real.exp (-D)+(Cw+1+2*CN)*Real.exp (1-D)≤eta := by
  let F := 1+(Cw+1+2*CN)*Real.exp 1
  have hF : 0<F := by dsimp [F]; positivity
  let D := max 1 (Real.log (F/eta))
  refine ⟨D,le_max_left _ _,?_⟩
  have hD : Real.log (F/eta)≤D := le_max_right _ _
  have hde : Real.exp (-D)≤eta/F := by
    have hh := Real.exp_le_exp.mpr (neg_le_neg hD)
    simp only [Real.exp_neg,Real.exp_log (div_pos hF heta),inv_div] at hh
    simpa only [Real.exp_neg] using hh
  have heq : Real.exp (-D)+(Cw+1+2*CN)*Real.exp (1-D)=F*Real.exp (-D) := by
    rw [Real.exp_sub]
    rw [Real.exp_neg]
    dsimp [F]
    ring
  rw [heq]
  calc
    _≤F*(eta/F) := mul_le_mul_of_nonneg_left hde hF.le
    _=eta := by field_simp

end Renyi
