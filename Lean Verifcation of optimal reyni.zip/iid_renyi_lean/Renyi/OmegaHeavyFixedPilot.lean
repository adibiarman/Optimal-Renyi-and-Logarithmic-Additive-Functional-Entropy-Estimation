import Renyi.OmegaHeavyFixed
import Renyi.OmegaHeavyTrueSelection

/-! Fixed heavy upper margins for the actual random pilot and source rescaling. -/
set_option maxHeartbeats 800000
noncomputable section
open scoped BigOperators NNReal
open Set MeasureTheory ProbabilityTheory
namespace Renyi

theorem omega_heavy_fixed_pilot_subset_concentration {eps c0 rho : ℝ}
    (heps : 0<eps) (hc0 : 0<c0) (hc01 : c0<1) (hrho : 0<rho) (hrho1 : rho<1)
    {k : ℕ} (n cp : ℝ≥0) (p : Simplex k) {a E0 : ℝ} (ha : 3/2≤a)
    (hElow : eps*(a-1)≤E0) (hEhigh : E0≤2*eps*(a-1))
    (S : (Fin k→ℕ)→Finset (Fin k)) (G : Set (Fin k→ℕ))
    (hmean : ∀y∈G,∀i∈S y,omegaHeavyScale eps c0 rho*a≤(n:ℝ)*p.mass i) :
    1-rho≤(pilotHistogramPMF n cp p).toMeasure.real {h |
      (fun i => pilotSelectionCount i h)∈G →
      h∈omegaHeavyFixedSubsetEvent (fun i => pilotMainCount i) (fun i => n*simplexNN p i)
        a E0 eps c0 (omegaHeavyMargin eps c0) (S (fun i => pilotSelectionCount i h))} := by
  let mu := (finitePoissonPMF (fun i => n*simplexNN p i)).toMeasure
  let nu := (finitePoissonPMF (fun i => cp*(n*simplexNN p i))).toMeasure
  have hlaw (i : Fin k) : MeasurePreserving (fun x:Fin k→ℕ => x i) mu (poissonMeasure (n*simplexNN p i)) := by
    dsimp [mu]
    rw [finitePoissonPMF,Measure.toPMF_toMeasure]
    exact measurePreserving_eval (fun i => poissonMeasure (n*simplexNN p i)) i
  let E : Set ((Fin k→ℕ)×(Fin k→ℕ)) := {xy | xy.2∈G →
    xy.1∈omegaHeavyFixedSubsetEvent (fun i (x:Fin k→ℕ) => x i) (fun i => n*simplexNN p i)
      a E0 eps c0 (omegaHeavyMargin eps c0) (S xy.2)}
  have hh : 1-rho≤(mu.prod nu).real E := by
    apply product_section_probability_lower (Set.to_countable _).measurableSet (by linarith only [hrho1])
    intro y
    by_cases hy : y∈G
    · have hs := omega_heavy_fixed_subset_concentration heps hc0 hc01 hrho hrho1 mu k a E0 ha hElow hEhigh
        (fun i x => x i) (fun i => n*simplexNN p i) hlaw (S y) (by
          intro i hi
          simpa only [NNReal.coe_mul,simplexNN_coe] using hmean y hy i hi)
      simpa only [E,preimage_setOf_eq,hy,true_implies] using hs
    · simp only [E,preimage_setOf_eq,hy,false_implies,setOf_true,measureReal_univ_eq_one]
      linarith only [hrho]
  have htransfer := (pilotHistogram_split_law n cp p).measureReal_preimage
    (s:=E) (Set.to_countable E).measurableSet.nullMeasurableSet
  change (pilotHistogramPMF n cp p).toMeasure.real (splitPilotHistogram⁻¹' E)=(mu.prod nu).real E at htransfer
  rw [←htransfer] at hh
  exact hh

/-- Probability-unit heavy enclosure with a fixed upper deficit. -/
def omegaHeavyFixedNormalizedSubsetEvent {Omega : Type*} {k : ℕ} (N : Fin k→Omega→ℕ) (p : Simplex k)
    (n : ℝ≥0) (a E0 eps c0 c sigma : ℝ) (S : Finset (Fin k)) : Set Omega :=
  {w | (Real.exp (-(2*eps*(a-1)))+c*Real.exp (-(2*eps*(a-1))))*
      ∑i∈S,(p.mass i)^a≤∑i∈S,(sigma*Real.exp (-c0*E0))*analyticCount a (N i w)/(n:ℝ)^a ∧
    (∑i∈S,(sigma*Real.exp (-c0*E0))*analyticCount a (N i w)/(n:ℝ)^a)≤
      (1-c)*∑i∈S,(p.mass i)^a}

/-- Downward rescaling preserves the fixed upper deficit and half the lower margin. -/
theorem omegaHeavyFixedSubsetEvent_normalized {Omega : Type*} {k : ℕ}
    (N : Fin k→Omega→ℕ) (p : Simplex k) {n : ℝ≥0} (hn : 0<(n:ℝ))
    {a E0 eps c0 c sigma : ℝ} (hc : 0≤c) (hc1 : c≤1) (hsigma : 0≤sigma) (hsigma1 : sigma≤1)
    (hheadroom : 1+c/2≤sigma*(1+c)) (S : Finset (Fin k)) :
    omegaHeavyFixedSubsetEvent N (fun i => n*simplexNN p i) a E0 eps c0 c S ⊆
      omegaHeavyFixedNormalizedSubsetEvent N p n a E0 eps c0 (c/2) sigma S := by
  intro w hw
  have hnα := Real.rpow_pos_of_pos hn a
  have hsum : (∑i∈S,((n*simplexNN p i:ℝ≥0):ℝ)^a)=(n:ℝ)^a*∑i∈S,(p.mass i)^a := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    simp only [NNReal.coe_mul,simplexNN_coe,Real.mul_rpow n.coe_nonneg (p.nonneg i)]
  have hstat : (∑i∈S,(sigma*Real.exp (-c0*E0))*analyticCount a (N i w)/(n:ℝ)^a)=
      (sigma/(n:ℝ)^a)*(Real.exp (-c0*E0)*∑i∈S,analyticCount a (N i w)) := by
    rw [←Finset.sum_div,←Finset.mul_sum]
    ring
  have hS : 0≤∑i∈S,(p.mass i)^a := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (p.nonneg i) a)
  change _∧_ at hw
  rw [hsum] at hw
  have hl := mul_le_mul_of_nonneg_left hw.1 (div_nonneg hsigma hnα.le)
  have hu := mul_le_mul_of_nonneg_left hw.2 (div_nonneg hsigma hnα.le)
  have hl' : sigma*(Real.exp (-(2*eps*(a-1)))+c*Real.exp (-(2*eps*(a-1))))*
      (∑i∈S,(p.mass i)^a)≤(sigma/(n:ℝ)^a)*(Real.exp (-c0*E0)*∑i∈S,analyticCount a (N i w)) := by
    convert hl using 1; field_simp
  have hu' : (sigma/(n:ℝ)^a)*(Real.exp (-c0*E0)*∑i∈S,analyticCount a (N i w))≤
      sigma*((1-c)*∑i∈S,(p.mass i)^a) := by
    convert hu using 1; field_simp
  have hupper := mul_le_of_le_one_left (mul_nonneg (sub_nonneg.mpr hc1) hS) hsigma1
  have hmargin := mul_le_mul_of_nonneg_right hheadroom
    (mul_nonneg (Real.exp_pos (-(2*eps*(a-1)))).le hS)
  have hcS := mul_nonneg hc hS
  change _∧_
  rw [hstat]
  constructor <;> nlinarith only [hl',hu',hmargin,hupper,hcS]

/-- The exact random selected true-heavy term has a fixed upper power-sum deficit. -/
theorem omega_heavy_true_selection_fixed_concentration {eps c0 rho : ℝ}
    (heps : 0<eps) (hc0 : 0<c0) (hc01 : c0<1) (hrho : 0<rho) (hrho1 : rho<1)
    {k : ℕ} (n cp : ℝ≥0) (hn : 0<(n:ℝ)) (p : Simplex k) {a E0 sigma B : ℝ}
    (ha : 3/2≤a) (hElow : eps*(a-1)≤E0) (hEhigh : E0≤2*eps*(a-1))
    (hsigma : 0≤sigma) (hsigma1 : sigma≤1)
    (hheadroom : 1+omegaHeavyMargin eps c0/2≤sigma*(1+omegaHeavyMargin eps c0))
    (hB : 2*omegaHeavyScale eps c0 rho≤B) :
    1-rho≤(pilotHistogramPMF n cp p).toMeasure.real {h |
      (Real.exp (-(2*eps*(a-1)))+(omegaHeavyMargin eps c0/2)*Real.exp (-(2*eps*(a-1))))*
        (∑i∈trueHeavyPilotSubset p n a cp B (fun i => pilotSelectionCount i h),(p.mass i)^a)≤
          pilotTrueHeavyPower p.mass (fun i => pilotSelectionCount i) (fun i => pilotMainCount i)
            n a cp B (sigma*Real.exp (-c0*E0)) h ∧
      pilotTrueHeavyPower p.mass (fun i => pilotSelectionCount i) (fun i => pilotMainCount i)
        n a cp B (sigma*Real.exp (-c0*E0)) h≤
          (1-omegaHeavyMargin eps c0/2)*
            (∑i∈trueHeavyPilotSubset p n a cp B (fun i => pilotSelectionCount i h),(p.mass i)^a)} := by
  have hc := (omega_heavy_fixed_concentration_uniform.{0} heps hc0 hc01 hrho hrho1).1
  have hc1 : omegaHeavyMargin eps c0≤1 := by unfold omegaHeavyMargin; linarith only [Real.exp_pos (-(omegaHeavyDistance c0*eps/2))]
  have hmean : ∀y∈(Set.univ:Set (Fin k→ℕ)),∀i∈trueHeavyPilotSubset p n a cp B y,
      omegaHeavyScale eps c0 rho*a≤(n:ℝ)*p.mass i := by
    intro y _ i hi
    have hh := (Finset.mem_filter.mp hi).2.1
    have hmul := mul_le_mul_of_nonneg_right hB (show 0≤a by linarith only [ha])
    linarith only [hh,hmul]
  have hh := omega_heavy_fixed_pilot_subset_concentration heps hc0 hc01 hrho hrho1 n cp p ha hElow hEhigh
    (trueHeavyPilotSubset p n a cp B) Set.univ hmean
  simp only [Set.mem_univ,true_implies] at hh
  apply hh.trans
  refine measureReal_mono ?_ (by finiteness)
  intro h he
  have hnorm := omegaHeavyFixedSubsetEvent_normalized (fun i => pilotMainCount i) p hn hc.le hc1 hsigma hsigma1
    hheadroom (trueHeavyPilotSubset p n a cp B (fun i => pilotSelectionCount i h)) he
  simpa only [omegaHeavyFixedNormalizedSubsetEvent,Set.mem_setOf_eq,pilotTrueHeavyPower_subset_sum] using hnorm

/-- Source omega and the actual final rescaling satisfy the heavy fixed-deficit
band whenever the scalar rescaling reserve is chosen below the heavy margin. -/
theorem omega_heavy_true_selection_actual_fixed {eps cw rho cu u0 Ch : ℝ}
    (heps : 0<eps) (hcw : 0<cw) (hcw1 : cw<1) (hrho : 0<rho) (hrho1 : rho<1)
    (hcu : 0≤cu) (hu0 : 0<u0) (hCh : 0≤Ch)
    (hsmall : cu*u0*(2+omegaHeavyMargin eps cw)≤omegaHeavyMargin eps cw)
    {k : ℕ} (n cp : ℝ≥0) (hn : 0<(n:ℝ)) (p : Simplex k) {alpha B : ℝ}
    (ha : 3/2≤alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (hB : 2*omegaHeavyScale eps cw rho≤B) :
    1-rho≤(pilotHistogramPMF n cp p).toMeasure.real {h |
      (upperKappa alpha eps+(omegaHeavyMargin eps cw/2)*upperKappa alpha eps)*
        (∑i∈trueHeavyPilotSubset p n alpha cp B (fun i => pilotSelectionCount i h),(p.mass i)^alpha)≤
          pilotTrueHeavyPower p.mass (fun i => pilotSelectionCount i) (fun i => pilotMainCount i)
            n alpha cp B (upperRescaling k alpha eps cu u0*upperOmega k alpha eps Ch cw) h ∧
      pilotTrueHeavyPower p.mass (fun i => pilotSelectionCount i) (fun i => pilotMainCount i)
        n alpha cp B (upperRescaling k alpha eps cu u0*upperOmega k alpha eps Ch cw) h≤
          (1-omegaHeavyMargin eps cw/2)*
            (∑i∈trueHeavyPilotSubset p n alpha cp B (fun i => pilotSelectionCount i h),(p.mass i)^alpha)} := by
  have ha1 : 1<alpha := by linarith only [ha]
  have hE := upper_reserved_interval (k:=k) ha1 hg hg1 heps hCh
  have hs := upperRescaling_range (k:=k) (eps:=eps) ha1 hg hg1 hcu hu0
  have hc := (omega_heavy_fixed_concentration_uniform.{0} heps hcw hcw1 hrho hrho1).1
  have hheadroom := upperRescaling_heavy_headroom (k:=k) (eps:=eps) ha1 hg hg1 hcu hu0 hc.le hsmall
  have hh := omega_heavy_true_selection_fixed_concentration heps hcw hcw1 hrho hrho1 n cp hn p
    ha hE.1 hE.2 hs.1.le hs.2 hheadroom hB
  simpa only [upperKappa,upperOmega,neg_mul] using hh

end Renyi
