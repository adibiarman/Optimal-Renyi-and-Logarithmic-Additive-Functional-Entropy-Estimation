import Renyi.PoissonPilotModel

/-! Real-parameter marginal laws for the concrete Poisson pilot experiment. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

theorem pilotHistogram_main_independent {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) :
    iIndepFun (pilotMainCount (k:=k)) (pilotHistogramPMF n cp p).toMeasure := by
  have hi:Function.Injective (fun i:Fin k => (i,false)) := by
    intro i j hij
    exact congrArg Prod.fst hij
  exact (pilotHistogram_independent n cp p).precomp (g:=fun i:Fin k => (i,false)) hi

theorem pilotMainCount_independent {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) :
    Pairwise (fun i j => IndepFun (pilotMainCount i) (pilotMainCount j)
      (pilotHistogramPMF n cp p).toMeasure) := by
  intro i j hij
  exact (pilotHistogram_main_independent n cp p).indepFun hij

theorem pilotSelectionCount_law_real {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) (i:Fin k) :
    MeasurePreserving (pilotSelectionCount i) (pilotHistogramPMF n cp p).toMeasure
      (poissonMeasure (Real.toNNReal ((cp:ℝ)*(n:ℝ)*p.mass i))) := by
  have heq:cp*(n*simplexNN p i)=Real.toNNReal ((cp:ℝ)*(n:ℝ)*p.mass i) := by
    apply NNReal.coe_injective
    simp only [NNReal.coe_mul,simplexNN_coe,
      Real.coe_toNNReal _ (mul_nonneg (mul_nonneg cp.coe_nonneg n.coe_nonneg) (p.nonneg i))]
    ring
  rw [←heq]
  exact pilotSelectionCount_law n cp p i

theorem pilotSelectionCount_law_amplified {k:ℕ} (n cp:ℝ≥0) (p:Simplex k) (i:Fin k) :
    MeasurePreserving (pilotSelectionCount i) (pilotHistogramPMF n cp p).toMeasure
      (poissonMeasure ⟨(cp:ℝ)*(Real.toNNReal ((n:ℝ)*p.mass i):ℝ),
        mul_nonneg cp.coe_nonneg (Real.toNNReal _).coe_nonneg⟩) := by
  have hmain:n*simplexNN p i=Real.toNNReal ((n:ℝ)*p.mass i) := by
    apply NNReal.coe_injective
    simp only [NNReal.coe_mul,simplexNN_coe,
      Real.coe_toNNReal _ (mul_nonneg n.coe_nonneg (p.nonneg i))]
  have hr:cp*(n*simplexNN p i)=⟨(cp:ℝ)*(Real.toNNReal ((n:ℝ)*p.mass i):ℝ),
      mul_nonneg cp.coe_nonneg (Real.toNNReal _).coe_nonneg⟩ := by rw [hmain]; rfl
  rw [←hr]
  exact pilotSelectionCount_law n cp p i

end Renyi
