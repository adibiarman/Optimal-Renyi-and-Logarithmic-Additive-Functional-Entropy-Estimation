import Renyi.Root
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Topology.Order.Monotone

/-! Continuity, attainment, and the exact crossing identity of the scalar root. -/

noncomputable section
open Set
namespace Renyi

def scalarRootExpression (c α q x : ℝ) : ℝ :=
  c * x ^ α * max (1 + Real.log (x * (1 + Real.log x) / q)) 0

def scalarRootSet (c α q : ℝ) : Set ℝ :=
  {x | 1 ≤ x ∧ 1 ≤ scalarRootExpression c α q x}

theorem rootExpression_continuousAt (c α : ℝ) {q x : ℝ}
    (hq : 0 < q) (hx : 1 ≤ x) : ContinuousAt (scalarRootExpression c α q) x := by
  have hxpos : 0 < x := lt_of_lt_of_le zero_lt_one hx
  have hxlog : 0 ≤ Real.log x := Real.log_nonneg hx
  have harg : 0 < x * (1 + Real.log x) / q := by positivity
  have hlogx := Real.continuousAt_log (ne_of_gt hxpos)
  have hinner : ContinuousAt (fun y : ℝ => y * (1 + Real.log y) / q) x :=
    (continuousAt_id.mul (continuousAt_const.add hlogx)).div_const q
  exact (continuousAt_const.mul
    (Real.continuousAt_rpow_const x α (.inl (ne_of_gt hxpos)))).mul
    ((continuousAt_const.add (hinner.log (ne_of_gt harg))).max continuousAt_const)

theorem scalarRootSet_isClosed (c α : ℝ) {q : ℝ} (hq : 0 < q) :
    IsClosed (scalarRootSet c α q) := by
  have hc : ContinuousOn (scalarRootExpression c α q) (Ici 1) :=
    fun x hx => (rootExpression_continuousAt c α hq hx).continuousWithinAt
  have hclip : Continuous (fun x : ℝ => scalarRootExpression c α q (max 1 x)) :=
    hc.comp_continuous (continuous_const.max continuous_id)
      (fun x => by simpa only [Set.mem_Ici] using le_max_left (1 : ℝ) x)
  have hclosed : IsClosed ((Ici (1 : ℝ)) ∩
      {x : ℝ | (1 : ℝ) ≤ scalarRootExpression c α q (max 1 x)}) :=
    isClosed_Ici.inter (isClosed_le continuous_const hclip)
  convert hclosed using 1
  ext x
  change (1 ≤ x ∧ 1 ≤ scalarRootExpression c α q x) ↔
    (1 ≤ x ∧ 1 ≤ scalarRootExpression c α q (max 1 x))
  constructor
  · intro hx
    exact ⟨hx.1, by simpa only [max_eq_right hx.1] using hx.2⟩
  · intro hx
    exact ⟨hx.1, by simpa only [max_eq_right hx.1] using hx.2⟩

theorem scalarRoot_attained {c α q : ℝ} (hc : 0 < c) (hα : 0 < α) (hq : 0 < q) :
    sInf (scalarRootSet c α q) ∈ scalarRootSet c α q := by
  exact (scalarRootSet_isClosed c α hq).csInf_mem
    (scalar_root_set_nonempty hc hα hq) ⟨1, fun _ hx => hx.1⟩

/-- Away from the floor at one, the root is an exact level-one crossing. -/
theorem scalarRoot_crossing {c α q : ℝ} (hc : 0 < c) (hα : 0 < α) (hq : 0 < q)
    (hroot : 1 < sInf (scalarRootSet c α q)) :
    scalarRootExpression c α q (sInf (scalarRootSet c α q)) = 1 := by
  let x := sInf (scalarRootSet c α q)
  have hx : x ∈ scalarRootSet c α q := scalarRoot_attained hc hα hq
  have hx1 : 1 < x := hroot
  apply le_antisymm _ hx.2
  by_contra h
  have hfx : 1 < scalarRootExpression c α q x := lt_of_not_ge h
  have heps : 0 < (scalarRootExpression c α q x - 1) / 2 := by linarith
  obtain ⟨δ, hδ, hcont⟩ := Metric.continuousAt_iff.mp
    (rootExpression_continuousAt c α hq hx.1) _ heps
  let e := min δ (x - 1) / 2
  have he : 0 < e :=
    div_pos (lt_min hδ (sub_pos.mpr hx1)) (by norm_num)
  have heδ : e < δ := by have := min_le_left δ (x - 1); dsimp [e]; linarith
  have heleft : e ≤ (x - 1) / 2 := by
    exact div_le_div_of_nonneg_right (min_le_right _ _) (by norm_num)
  have hy1 : 1 ≤ x - e := by linarith
  have hydist : dist (x - e) x < δ := by
    rw [Real.dist_eq]
    have habs : |x - e - x| = e := by rw [show x - e - x = -e by ring, abs_neg,
      abs_of_pos he]
    rwa [habs]
  have hfnear := hcont hydist
  rw [Real.dist_eq] at hfnear
  have hfy : 1 ≤ scalarRootExpression c α q (x - e) := by
    have hl := (abs_lt.mp hfnear).1
    linarith
  have hy : x - e ∈ scalarRootSet c α q := ⟨hy1, hfy⟩
  have hbound : x ≤ x - e := csInf_le ⟨1, fun _ hz => hz.1⟩ hy
  linarith

/-- The bracket is positive at the root, so the positive-part operation disappears. -/
theorem scalarRoot_bracket {c α q : ℝ} (hc : 0 < c) (hα : 0 < α) (hq : 0 < q) :
    1 / (c * (sInf (scalarRootSet c α q)) ^ α) ≤
      1 + Real.log ((sInf (scalarRootSet c α q)) *
        (1 + Real.log (sInf (scalarRootSet c α q))) / q) := by
  let x := sInf (scalarRootSet c α q)
  have hx := scalarRoot_attained hc hα hq
  have hxpos : 0 < x := lt_of_lt_of_le zero_lt_one hx.1
  have hfactor : 0 < c * x ^ α := by positivity
  have hcrit : 1 ≤ c * x ^ α * max (1 + Real.log (x * (1 + Real.log x) / q)) 0 := hx.2
  have hbrpos : 0 < 1 + Real.log (x * (1 + Real.log x) / q) := by
    by_contra h
    rw [max_eq_right (le_of_not_gt h)] at hcrit
    simp only [mul_zero] at hcrit
    norm_num at hcrit
  rw [max_eq_left hbrpos.le] at hcrit
  apply (div_le_iff₀ hfactor).2
  simpa only [mul_comm] using hcrit

/-- The defining criterion is strictly increasing once its bracket is positive. -/
theorem scalarRootExpression_strict {c α q x y : ℝ} (hc : 0 < c)
    (hα : 0 < α) (hq : 0 < q) (hx : 1 ≤ x) (hxy : x < y)
    (hbr : 0 < 1 + Real.log (x * (1 + Real.log x) / q)) :
    scalarRootExpression c α q x < scalarRootExpression c α q y := by
  have hxpos : 0 < x := lt_of_lt_of_le zero_lt_one hx
  have hypos : 0 < y := lt_trans hxpos hxy
  have hxlog : 0 ≤ Real.log x := Real.log_nonneg hx
  have hlogs : Real.log x ≤ Real.log y := (Real.log_lt_log hxpos hxy).le
  have hargx : 0 < x * (1 + Real.log x) / q := by positivity
  have hargs : x * (1 + Real.log x) / q ≤ y * (1 + Real.log y) / q :=
    div_le_div_of_nonneg_right
      (mul_le_mul hxy.le (by linarith) (by linarith) (by linarith)) hq.le
  have hlogargs := Real.log_le_log hargx hargs
  have hbry : 0 < 1 + Real.log (y * (1 + Real.log y) / q) := by linarith
  unfold scalarRootExpression
  rw [max_eq_left hbr.le, max_eq_left hbry.le]
  exact mul_lt_mul (mul_lt_mul_of_pos_left (Real.rpow_lt_rpow hxpos.le hxy hα) hc)
    (by linarith) hbr (by positivity)

/-- Any level-one crossing above the endpoint equals the defined infimum. -/
theorem scalarRoot_unique_crossing {c α q y : ℝ} (hc : 0 < c)
    (hα : 0 < α) (hq : 0 < q) (hy : 1 ≤ y)
    (hfy : scalarRootExpression c α q y = 1) :
    y = sInf (scalarRootSet c α q) := by
  let x := sInf (scalarRootSet c α q)
  have hx := scalarRoot_attained hc hα hq
  have hle : x ≤ y := csInf_le ⟨1, fun _ hz => hz.1⟩ ⟨hy, hfy.ge⟩
  apply le_antisymm _ hle
  by_contra h
  have hxy : x < y := lt_of_not_ge h
  have hxpos : 0 < x := lt_of_lt_of_le zero_lt_one hx.1
  have hbr : 0 < 1 + Real.log (x * (1 + Real.log x) / q) := by
    by_contra hn
    have hz : scalarRootExpression c α q x = 0 := by
      simp only [scalarRootExpression, max_eq_right (le_of_not_gt hn), mul_zero]
    have := hx.2
    change 1 ≤ scalarRootExpression c α q x at this
    rw [hz] at this
    norm_num at this
  have hstrict := scalarRootExpression_strict hc hα hq hx.1 hxy hbr
  rw [hfy] at hstrict
  exact (not_lt_of_ge hx.2) hstrict

/-- Nonnegative slack records whether the root is clipped at one. -/
def scalarRootSlack (c α q : ℝ) : ℝ :=
  let x := sInf (scalarRootSet c α q)
  1 + Real.log (x * (1 + Real.log x) / q) - 1 / (c * x ^ α)

theorem scalarRootSlack_nonneg {c α q : ℝ} (hc : 0 < c)
    (hα : 0 < α) (hq : 0 < q) : 0 ≤ scalarRootSlack c α q :=
  sub_nonneg.mpr (scalarRoot_bracket hc hα hq)

theorem scalarRootSlack_eq_zero {c α q : ℝ} (hc : 0 < c)
    (hα : 0 < α) (hq : 0 < q) (hx : 1 < sInf (scalarRootSet c α q)) :
    scalarRootSlack c α q = 0 := by
  let x := sInf (scalarRootSet c α q)
  have hmem := scalarRoot_attained hc hα hq
  have hxpos : 0 < x := lt_of_lt_of_le zero_lt_one hmem.1
  have hfactor : 0 < c * x ^ α := by positivity
  have hbr := scalarRoot_bracket hc hα hq
  have hbrpos : 0 < 1 + Real.log (x * (1 + Real.log x) / q) :=
    lt_of_lt_of_le (by positivity : 0 < 1 / (c * x ^ α)) hbr
  have heq := scalarRoot_crossing hc hα hq hx
  change c * x ^ α * max (1 + Real.log (x * (1 + Real.log x) / q)) 0 = 1 at heq
  rw [max_eq_left hbrpos.le] at heq
  unfold scalarRootSlack
  dsimp only
  apply sub_eq_zero.mpr
  exact (eq_div_iff (ne_of_gt hfactor)).2 (by simpa only [mul_comm] using heq)

/-- Exact logarithmic identity used by the regularized parameter calibration. -/
theorem scalarRoot_log_identity {c α q : ℝ} (hc : 0 < c)
    (hα : 0 < α) (hq : 0 < q) :
    let x := sInf (scalarRootSet c α q)
    q / x = (1 + Real.log x) *
      Real.exp (1 - 1 / (c * x ^ α) - scalarRootSlack c α q) := by
  dsimp only
  let x := sInf (scalarRootSet c α q)
  have hx := scalarRoot_attained hc hα hq
  have hxpos : 0 < x := lt_of_lt_of_le zero_lt_one hx.1
  have hlog : 0 ≤ Real.log x := Real.log_nonneg hx.1
  have hp : 0 < x * (1 + Real.log x) / q := by positivity
  have hexponent : 1 - 1 / (c * x ^ α) - scalarRootSlack c α q =
      -Real.log (x * (1 + Real.log x) / q) := by
    unfold scalarRootSlack
    dsimp only
    change 1 - 1 / (c * x ^ α) -
      (1 + Real.log (x * (1 + Real.log x) / q) - 1 / (c * x ^ α)) = _
    ring
  change q / x = (1 + Real.log x) * Real.exp _
  rw [hexponent, Real.exp_neg, Real.exp_log hp]
  field_simp

/-- The exact root identities used in the source's regularized parameter rule.
This proves the slack identities, not the remaining uniform scale estimates. -/
theorem regularized_root_slack {k : ℕ} {α ε : ℝ} (hα : 1 < α)
    (hγ0 : 0 < fractionalPart α) (hγ1 : fractionalPart α < 1) :
    let x := rootMultiplier k α ε
    let q := rootQSquared k α ε
    let h := fractionalPart α * (1 - fractionalPart α)
    let v := (α - 1) / α * x ^ (-α)
    let σ := 1 + Real.log (x * (1 + Real.log x) / q) - v / h
    0 ≤ σ ∧ (1 < x → σ = 0) ∧
      q / x = (1 + Real.log x) * Real.exp (1 - v / h - σ) := by
  let h := fractionalPart α * (1 - fractionalPart α)
  let c := α * h / (α - 1)
  let q := rootQSquared k α ε
  let x := rootMultiplier k α ε
  have hα0 : 0 < α := by linarith
  have hh : 0 < h := mul_pos hγ0 (sub_pos.mpr hγ1)
  have hc : 0 < c := div_pos (mul_pos hα0 hh) (sub_pos.mpr hα)
  have hq : 0 < q := rootQSquared_pos hα hγ0 hγ1
  have hxdef : x = sInf (scalarRootSet c α q) := rfl
  have hxpos : 0 < x := lt_of_lt_of_le zero_lt_one
    (one_le_rootMultiplier hα hγ0 hγ1)
  have hrecip : 1 / (c * x ^ α) = ((α - 1) / α * x ^ (-α)) / h := by
    rw [Real.rpow_neg hxpos.le]
    dsimp [c]
    field_simp
  have hσ : 1 + Real.log (x * (1 + Real.log x) / q) -
      ((α - 1) / α * x ^ (-α)) / h = scalarRootSlack c α q := by
    unfold scalarRootSlack
    dsimp only
    rw [← hxdef, hrecip]
  change 0 ≤ 1 + Real.log (x * (1 + Real.log x) / q) -
      ((α - 1) / α * x ^ (-α)) / h ∧ _
  rw [hσ]
  refine ⟨scalarRootSlack_nonneg hc hα0 hq, ?_, ?_⟩
  · intro hx
    exact scalarRootSlack_eq_zero hc hα0 hq hx
  · have hid := scalarRoot_log_identity hc hα0 hq
    dsimp only at hid
    rw [← hxdef, hrecip] at hid
    exact hid

end Renyi
