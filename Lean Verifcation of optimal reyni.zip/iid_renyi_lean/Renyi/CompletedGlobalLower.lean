import Renyi.DegreeOneGlobalLower
import Renyi.CoupledGlobalLower
import Renyi.CompletedCoupledPolynomial

/-! The complete actual lower certificate, including the prescribed degree-one branch. -/
noncomputable section
namespace Renyi

/-- Both source low branches share one actual global lower baseline and local gain. -/
theorem completedProfiles_global_lower {fL f qL qH Emin ν M lam0 : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hEmin : 0<Emin) (hν : 0<ν) (hM : 1≤M) (hlam0 : 0<lam0) (hlam1 : lam0≤1)
    (hqL : Real.exp (-Emin)<qL) (hqLf : qL<fL)
    (hqH : Real.exp (-7*Emin/8)<qH) (hqHf : qH<f) :
    ∃ C c : ℝ, 0≤C ∧ 0<c ∧ ∀ (ℓ N : ℕ) (γ z E x y : ℝ), 0<ℓ → 2≤N →
      0<γ → γ<1 → 0<z → z<1 → Emin≤E → overlapG γ z=Real.exp (-E) →
      ν*((ℓ:ℝ)-1)≤E → 0≤x → x≤1 → 0<y → y≤1 →
      lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤((ℓ:ℝ)^2*x)*((N:ℝ)^2*y) →
      ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y)≤
        Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) →
      Real.exp (-E)*Real.exp (-C*(γ*(1-γ)))+c*Real.exp (-E)*min ((N:ℝ)^2*y) 1≤
        (overlapA γ z*Real.exp (-M*γ))*
          completedLowProfile ℓ γ (DegreeOneCompletion.coefficient γ fL) fL x*(1-endpointProfile N 6 1 y)+
          (overlapB γ z*Real.exp (-M*(1-γ)))*highProfile N (1-γ) f (Real.exp (-E/8)) y+
          Real.exp (-E/8)*(1-overlapB γ z*Real.exp (-M*(1-γ)))*endpointProfile N 6 (1-γ) y := by
  obtain ⟨CC,cC,hCC,hcC,hC⟩ := coupledProfiles_global_lower
    hfL hfL1 hf hf1 hEmin hν hM hlam0 hlam1 hqL hqLf hqH hqHf
  obtain ⟨CD,cD,hCD,hcD,hD⟩ := DegreeOneCompletion.coupledProfiles_global_lower
    hfL hfL1 hf hf1 hEmin hM hlam0 hlam1 hqL hqLf hqH hqHf
  refine ⟨max CC CD,min cC cD,hCC.trans (le_max_left _ _),lt_min hcC hcD,?_⟩
  intro ℓ N γ z E x y hℓ hN hγ hγ1 hz hz1 hEE hG hdegree hx hx1 hy hy1 hcaplo hcaphi
  have hh : 0≤γ*(1-γ) := mul_nonneg hγ.le (sub_nonneg.mpr hγ1.le)
  have hκ : 0≤Real.exp (-E) := (Real.exp_pos _).le
  have hY : 0≤min ((N:ℝ)^2*y) 1 := le_min (by positivity) (by norm_num)
  by_cases hℓ1 : ℓ=1
  · subst ℓ
    simp only [Nat.cast_one,one_pow,one_mul] at hcaplo hcaphi
    have hb := hD N γ z E x y hN hγ hγ1 hz hz1 hEE hG hx hx1 hy hy1 hcaplo hcaphi
    have he : Real.exp (-max CC CD*(γ*(1-γ)))≤Real.exp (-CD*(γ*(1-γ))) :=
      Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_right (le_max_right CC CD) hh])
    have hbase := mul_le_mul_of_nonneg_left he hκ
    have hgain := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right (min_le_right cC cD) hκ) hY
    simp only [completedLowProfile,if_true]
    dsimp only [DegreeOneCompletion.coupledDampedExpression,DegreeOneCompletion.lowProfile] at hb
    linarith only [hb,hbase,hgain]
  · have hb := hC ℓ N γ z E x y (by omega) hN hγ hγ1 hz hz1 hEE hG hdegree hx hx1 hy hy1 hcaplo hcaphi
    have he : Real.exp (-max CC CD*(γ*(1-γ)))≤Real.exp (-CC*(γ*(1-γ))) :=
      Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_right (le_max_left CC CD) hh])
    have hbase := mul_le_mul_of_nonneg_left he hκ
    have hgain := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right (min_le_left cC cD) hκ) hY
    simp only [completedLowProfile,if_neg hℓ1]
    dsimp only [coupledDampedExpression] at hb
    linarith only [hb,hbase,hgain]

/-- Actual polynomial evaluation, with global lower baseline and the forward margin. -/
theorem completedCoupledPolynomial_global_lower {fL f qL qH Emin ν M lam0 : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hEmin : 0<Emin) (hν : 0<ν) (hM : 1≤M) (hlam0 : 0<lam0) (hlam1 : lam0≤1)
    (hqL : Real.exp (-Emin)<qL) (hqLf : qL<fL)
    (hqH : Real.exp (-7*Emin/8)<qH) (hqHf : qH<f) :
    ∃ C c : ℝ, 0≤C ∧ 0<c ∧ ∀ (ℓ N m : ℕ) (γ z E a b p : ℝ),
      0<ℓ → 2≤N → 1≤m → 4*(ℓ-1)≤m → 0<γ → γ<1 → 0<z → z<1 →
      Emin≤E → overlapG γ z=Real.exp (-E) → ν*((ℓ:ℝ)-1)≤E →
      0<a → a≤p → p≤b →
      lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤((ℓ:ℝ)^2*(a/p))*((N:ℝ)^2*(p/b)) →
      ((ℓ:ℝ)^2*(a/p))*((N:ℝ)^2*(p/b))≤
        Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) →
      p^((m:ℝ)+γ)*(Real.exp (-E)*Real.exp (-C*(γ*(1-γ)))+
        c*Real.exp (-E)*min ((N:ℝ)^2*(p/b)) 1)≤
      (completedCoupledPolynomial ℓ N m γ a b (DegreeOneCompletion.coefficient γ fL) fL f
        (overlapA γ z*Real.exp (-M*γ)) (overlapB γ z*Real.exp (-M*(1-γ))) (Real.exp (-E/8))).eval p := by
  obtain ⟨C,c,hC,hc,hbound⟩ := completedProfiles_global_lower
    hfL hfL1 hf hf1 hEmin hν hM hlam0 hlam1 hqL hqLf hqH hqHf
  refine ⟨C,c,hC,hc,?_⟩
  intro ℓ N m γ z E a b p hℓ hN hm hdegree hγ hγ1 hz hz1 hEE hG henergy ha hap hpb hcaplo hcaphi
  have hp : 0<p := ha.trans_le hap
  have hb : 0<b := hp.trans_le hpb
  have hh := hbound ℓ N γ z E (a/p) (p/b) hℓ hN hγ hγ1 hz hz1 hEE hG henergy
    (div_nonneg ha.le hp.le) ((div_le_one hp).mpr hap)
    (div_pos hp hb) ((div_le_one hb).mpr hpb) hcaplo hcaphi
  rw [completedCoupledPolynomial_eval hℓ (by omega : 0<N) hm hdegree hγ hγ1
    (DegreeOneCompletion.coefficient_pos hγ hfL1) ha hap hpb]
  exact mul_le_mul_of_nonneg_left hh (Real.rpow_nonneg hp.le _)

end Renyi
