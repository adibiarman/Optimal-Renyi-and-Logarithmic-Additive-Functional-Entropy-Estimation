import Renyi.IntegerCollision

/-!
# Actual count variance after pilot selection

The pilot is frozen before the main Poisson counts are drawn independently.
The averaged variance below is therefore the conditional count noise of the
product experiment, and does not include randomness of the pilot means.
-/

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

theorem poisson_pilot_switch_integrable (lam : ℝ≥0) (T V : ℝ) :
    Integrable (fun y : ℕ => if (y : ℝ) ≤ T then V else 0) (poissonMeasure lam) := by
  apply (integrable_const |V|).mono' (measurable_of_countable _).aestronglyMeasurable
  apply Filter.Eventually.of_forall
  intro y
  split_ifs <;> simp [Real.norm_eq_abs, abs_nonneg]

theorem poisson_pilot_switch_integral (lam : ℝ≥0) (T V : ℝ) :
    (∫ y : ℕ, (if (y : ℝ) ≤ T then V else 0) ∂poissonMeasure lam) =
      poissonLowerMass lam T * V := by
  rw [poisson_integral_eq_tsum lam _ (poisson_pilot_switch_integrable lam T V)]
  calc
    _ = ∑' y : ℕ, (if (y : ℝ) ≤ T then poissonPMFReal lam y else 0) * V := by
      apply tsum_congr
      intro y
      split_ifs <;> ring
    _ = _ := (poissonLowerMass_summable lam T).tsum_mul_right V

variable {ι Ω Ξ : Type*} [Fintype ι] [MeasurableSpace Ω] [MeasurableSpace Ξ]
variable {μ : Measure Ω} {ν : Measure Ξ}

/-- The actual polynomial estimator for one realized pilot vector. -/
def pilotSelectedCountEstimator (N : ι → Ω → ℕ) (y : ι → ℕ) (T : ℝ)
    (L : ℕ) (c : ℕ → ℝ) (n : ℝ) : Ω → ℝ :=
  fun ω => ∑ i, if (y i : ℝ) ≤ T then
    factorialStatistic L (fun r => c r / n ^ r) (N i ω) else 0

/-- Freeze the pilot first, then compute variance only under the main-count law. -/
def pilotAveragedCountVariance (N : ι → Ω → ℕ) (Y : ι → Ξ → ℕ) (T : ℝ)
    (L : ℕ) (c : ℕ → ℝ) (n : ℝ) (μ : Measure Ω) (ν : Measure Ξ) : ℝ :=
  ∫ ξ, variance (pilotSelectedCountEstimator N (fun i => Y i ξ) T L c n) μ ∂ν

/-- Independence of main counts makes the frozen-pilot variance exactly additive. -/
theorem pilot_selected_count_variance (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (y : ι → ℕ) (T : ℝ) (L : ℕ) (c : ℕ → ℝ) (n : ℝ) :
    variance (pilotSelectedCountEstimator N y T L c n) μ =
      ∑ i, if (y i : ℝ) ≤ T then
        variance (factorialStatistic L (fun r => c r / n ^ r)) (poissonMeasure (lam i)) else 0 := by
  let F : ι → Ω → ℝ := fun i ω => if (y i : ℝ) ≤ T then
    factorialStatistic L (fun r => c r / n ^ r) (N i ω) else 0
  have hF (i : ι) : MemLp (F i) 2 μ := by
    dsimp [F]
    split_ifs
    · exact countPolynomial_coordinate_memLp N lam hLaw L c n i
    · exact MemLp.zero
  have hpairF : Pairwise (fun i j => IndepFun (F i) (F j) μ) := by
    intro i j hij
    exact (hpair hij).comp
      (φ := fun z : ℕ => if (y i : ℝ) ≤ T then factorialStatistic L (fun r => c r / n ^ r) z else 0)
      (ψ := fun z : ℕ => if (y j : ℝ) ≤ T then factorialStatistic L (fun r => c r / n ^ r) z else 0)
      (measurable_of_countable _) (measurable_of_countable _)
  have hadd : variance (pilotSelectedCountEstimator N y T L c n) μ = ∑ i, variance (F i) μ := by
    convert (IndepFun.variance_sum (s := Finset.univ) (X := F)
      (fun i _ => hF i) (fun i _ j _ hij => hpairF hij)) using 1
    congr 1
    funext ω
    simp only [pilotSelectedCountEstimator, F, Finset.sum_apply]
  rw [hadd]
  apply Finset.sum_congr rfl
  intro i _
  dsimp [F]
  split_ifs with hy
  · exact (hLaw i).variance_fun_comp
      (measurable_of_countable (factorialStatistic L (fun r => c r / n ^ r))).aemeasurable
  · exact variance_zero μ

/-- The exact pilot-averaged conditional count variance for the actual product experiment. -/
theorem pilot_averaged_count_variance (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (Y : ι → Ξ → ℕ) (pilotLam : ι → ℝ≥0)
    (hY : ∀ i, MeasurePreserving (Y i) ν (poissonMeasure (pilotLam i)))
    (T : ℝ) (L : ℕ) (c : ℕ → ℝ) (n : ℝ) :
    pilotAveragedCountVariance N Y T L c n μ ν =
      ∑ i, poissonLowerMass (pilotLam i) T *
        variance (factorialStatistic L (fun r => c r / n ^ r)) (poissonMeasure (lam i)) := by
  let V : ι → ℝ := fun i => variance (factorialStatistic L (fun r => c r / n ^ r))
    (poissonMeasure (lam i))
  have hInt (i : ι) : Integrable (fun ξ => if (Y i ξ : ℝ) ≤ T then V i else 0) ν :=
    (hY i).integrable_comp_of_integrable (poisson_pilot_switch_integrable (pilotLam i) T (V i))
  unfold pilotAveragedCountVariance
  simp_rw [pilot_selected_count_variance N lam hLaw hpair]
  rw [integral_finset_sum]
  · apply Finset.sum_congr rfl
    intro i _
    have hc := (hY i).hasLaw.integral_comp
      (measurable_of_countable (fun y : ℕ => if (y : ℝ) ≤ T then V i else 0)).aestronglyMeasurable
    change (∫ ξ, ((fun y : ℕ => if (y : ℝ) ≤ T then V i else 0) ∘ Y i) ξ ∂ν) = _
    rw [hc, poisson_pilot_switch_integral]
  · intro i _
    exact hInt i

/-- Removing the deterministic constant gives a coefficientwise Poisson variance bound. -/
theorem poisson_polynomial_variance_le_factorial_second (lam : ℝ≥0)
    (L : ℕ) (c : ℕ → ℝ) :
    variance (factorialStatistic L c) (poissonMeasure lam) ≤
      (L : ℝ) * ∑ r ∈ Finset.range L,
        c (r + 1) ^ 2 * poissonFactorialSecond lam (r + 1) := by
  let R : ℕ → ℝ := fun j => ∑ r ∈ Finset.range L, c (r + 1) * (j.descFactorial (r + 1) : ℝ)
  have hF : factorialStatistic L c = fun j => c 0 + R j := by
    funext j
    dsimp [factorialStatistic, R]
    rw [Finset.sum_range_succ']
    simp [add_comm]
  have hR : MemLp R 2 (poissonMeasure lam) := by
    have heq : R = fun j => factorialStatistic L c j - c 0 := by
      funext j
      rw [hF]
      ring
    rw [heq]
    exact (poisson_polynomial_memLp lam L c).sub (memLp_const (c 0))
  have hterm (r : ℕ) : Integrable (fun j : ℕ => c (r + 1) ^ 2 *
      (j.descFactorial (r + 1) : ℝ) ^ 2) (poissonMeasure lam) :=
    (poisson_factorial_memLp lam (r + 1)).integrable_sq.const_mul _
  have hpoint (j : ℕ) : R j ^ 2 ≤ (L : ℝ) *
      ∑ r ∈ Finset.range L, c (r + 1) ^ 2 * (j.descFactorial (r + 1) : ℝ) ^ 2 := by
    have h := Finset.sum_mul_sq_le_sq_mul_sq (Finset.range L) (fun _ => (1 : ℝ))
      (fun r => c (r + 1) * (j.descFactorial (r + 1) : ℝ))
    simpa only [one_mul, one_pow, Finset.sum_const, Finset.card_range, nsmul_eq_mul,
      mul_one, mul_pow, R] using h
  have hsum : Integrable (fun j : ℕ => ∑ r ∈ Finset.range L,
      c (r + 1) ^ 2 * (j.descFactorial (r + 1) : ℝ) ^ 2) (poissonMeasure lam) :=
    integrable_finset_sum _ (fun r _ => hterm r)
  have hmono := integral_mono hR.integrable_sq (hsum.const_mul (L : ℝ)) hpoint
  rw [integral_const_mul, integral_finset_sum (Finset.range L) (fun r _ => hterm r)] at hmono
  simp_rw [integral_const_mul] at hmono
  have hmom (r : ℕ) : (∫ j : ℕ, (j.descFactorial r : ℝ) ^ 2 ∂poissonMeasure lam) =
      poissonFactorialSecond lam r := by
    rw [poisson_integral_eq_tsum lam _ (poisson_factorial_memLp lam r).integrable_sq]
    rfl
  simp_rw [hmom] at hmono
  rw [hF, variance_const_add hR.aestronglyMeasurable]
  exact (variance_le_expectation_sq hR.1).trans hmono

/-- Coefficientwise moment control under the actual pilot-averaged experiment. -/
theorem pilot_averaged_count_variance_le (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (Y : ι → Ξ → ℕ) (pilotLam : ι → ℝ≥0)
    (hY : ∀ i, MeasurePreserving (Y i) ν (poissonMeasure (pilotLam i)))
    (T : ℝ) (L : ℕ) (c : ℕ → ℝ) (n : ℝ) :
    pilotAveragedCountVariance N Y T L c n μ ν ≤
      (L : ℝ) * ∑ i, ∑ r ∈ Finset.range L,
        (c (r + 1) / n ^ (r + 1)) ^ 2 *
          poissonPilotSecond (lam i) (pilotLam i) T (r + 1) := by
  rw [pilot_averaged_count_variance N lam hLaw hpair Y pilotLam hY]
  calc
    _ ≤ ∑ i, poissonLowerMass (pilotLam i) T * ((L : ℝ) *
          ∑ r ∈ Finset.range L, (c (r + 1) / n ^ (r + 1)) ^ 2 *
            poissonFactorialSecond (lam i) (r + 1)) := by
      apply Finset.sum_le_sum
      intro i _
      exact mul_le_mul_of_nonneg_left
        (poisson_polynomial_variance_le_factorial_second (lam i) L (fun r => c r / n ^ r))
        (poissonLowerMass_nonneg _ _)
    _ = _ := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro i _
      simp only [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro r _
      rw [poissonPilotSecond_factor]
      ring

/-- Every degree below the real order has the source's actual pilot moment bound. -/
theorem pilot_low_degree_count_variance (B cp alpha : ℝ) (hB : 0 < B) (hcp : 0 < cp)
    (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (Y : ι → Ξ → ℕ)
    (hY : ∀ i, MeasurePreserving (Y i) ν
      (poissonMeasure ⟨cp * lam i, mul_nonneg hcp.le (lam i).coe_nonneg⟩))
    (L : ℕ) (hL : (L : ℝ) ≤ alpha) (c : ℕ → ℝ) (n : ℝ) :
    pilotAveragedCountVariance N Y (cp * B * alpha) L c n μ ν ≤
      (L : ℝ) * ∑ r ∈ Finset.range L,
        (c (r + 1) / n ^ (r + 1)) ^ 2 * (pilotConstant B cp * alpha) ^ (r + 1) *
          (∑ i, (lam i : ℝ) ^ (r + 1)) := by
  have hbound := pilot_averaged_count_variance_le N lam hLaw hpair Y
    (fun i => (⟨cp * lam i, mul_nonneg hcp.le (lam i).coe_nonneg⟩ : ℝ≥0)) hY
    (cp * B * alpha) L c n
  apply hbound.trans
  calc
    _ ≤ (L : ℝ) * ∑ i, ∑ r ∈ Finset.range L,
        (c (r + 1) / n ^ (r + 1)) ^ 2 * (pilotConstant B cp * alpha) ^ (r + 1) *
          (lam i : ℝ) ^ (r + 1) := by
      apply mul_le_mul_of_nonneg_left _ (Nat.cast_nonneg _)
      apply Finset.sum_le_sum
      intro i _
      apply Finset.sum_le_sum
      intro r hr
      have hrL : r + 1 ≤ L := by have := Finset.mem_range.mp hr; omega
      have hra : ((r + 1 : ℕ) : ℝ) ≤ alpha := (by exact_mod_cast hrL : ((r + 1 : ℕ) : ℝ) ≤ L).trans hL
      have h := poisson_pilot_factorial_second_bound B cp alpha hB hcp (lam i)
        (j := r + 1) (by omega) hra
      have hm := mul_le_mul_of_nonneg_left h (sq_nonneg (c (r + 1) / n ^ (r + 1)))
      convert hm using 1
      ring
    _ = _ := by
      rw [Finset.sum_comm]
      congr 1
      apply Finset.sum_congr rfl
      intro r _
      rw [Finset.mul_sum]

/-- The low-degree variance bound in probability units, with all sample powers explicit. -/
theorem pilot_low_degree_count_variance_probability_units (B cp alpha : ℝ)
    (hB : 0 < B) (hcp : 0 < cp) (N : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (N i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (N i) (N j) μ))
    (Y : ι → Ξ → ℕ)
    (hY : ∀ i, MeasurePreserving (Y i) ν
      (poissonMeasure ⟨cp * lam i, mul_nonneg hcp.le (lam i).coe_nonneg⟩))
    (L : ℕ) (hL : (L : ℝ) ≤ alpha) (c : ℕ → ℝ) (n : ℝ) (hn : n ≠ 0)
    (p : ι → ℝ) (hlam : ∀ i, (lam i : ℝ) = n * p i) :
    pilotAveragedCountVariance N Y (cp * B * alpha) L c n μ ν ≤
      (L : ℝ) * ∑ r ∈ Finset.range L,
        c (r + 1) ^ 2 * (pilotConstant B cp * alpha) ^ (r + 1) /
          n ^ (r + 1) * powerSumNat p (r + 1) := by
  apply (pilot_low_degree_count_variance B cp alpha hB hcp N lam hLaw hpair Y hY L hL c n).trans_eq
  congr 1
  apply Finset.sum_congr rfl
  intro r _
  have hsum : (∑ i, (lam i : ℝ) ^ (r + 1)) = n ^ (r + 1) * powerSumNat p (r + 1) := by
    simp_rw [hlam, mul_pow]
    exact (Finset.mul_sum _ _ _).symm
  rw [hsum]
  field_simp

end Renyi
