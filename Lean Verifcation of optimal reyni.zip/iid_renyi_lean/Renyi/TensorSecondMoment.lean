import Renyi.TensorPriorMoments

/-! Exact positive tensor moments and second-moment ratios used by lower calibration. -/
noncomputable section
open scoped BigOperators
namespace Renyi

theorem positive_add_negative (x : ℝ) : positiveCoeff x + negativeCoeff x = |x| := by
  rcases le_total 0 x with h | h
  · simp [positiveCoeff, negativeCoeff, max_eq_left h, max_eq_right (by linarith : -x ≤ 0), abs_of_nonneg h]
  · simp [positiveCoeff, negativeCoeff, max_eq_right h, max_eq_left (by linarith : 0 ≤ -x), abs_of_nonpos h]

/-- A canceled signed power moment has equal positive and negative moments. -/
theorem jordan_power_moments_equal {ι : Type*} [Fintype ι] (l u : ι → ℝ) (beta : ℝ)
    (hcancel : ∑ i, l i*u i^beta = 0) :
    (∑ i, positiveCoeff (l i)*u i^beta) = ∑ i, negativeCoeff (l i)*u i^beta := by
  have hdiff : (∑ i, positiveCoeff (l i)*u i^beta) -
      (∑ i, negativeCoeff (l i)*u i^beta) = ∑ i, l i*u i^beta := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i _
    rw [← sub_mul, positive_sub_negative]
  rw [hcancel] at hdiff
  exact sub_eq_zero.mp hdiff

/-- The absolute power moment is twice either Jordan moment at a cancellation. -/
theorem absolute_power_moment_eq_twice {ι : Type*} [Fintype ι]
    (l u : ι → ℝ) (beta : ℝ) (hcancel : ∑ i, l i*u i^beta = 0) :
    (∑ i, |l i| *u i^beta) = 2*(∑ i, positiveCoeff (l i)*u i^beta) := by
  simp_rw [← positive_add_negative, add_mul]
  rw [Finset.sum_add_distrib, ← jordan_power_moments_equal l u beta hcancel]
  ring

/-- The common normalizer factors into the equal low Jordan power moment and
the absolute high inverse moment. This is the exact factorization used by Step6. -/
theorem tensorNormalizer_jordan_factorization {ι κ : Type*} [Fintype ι] [Fintype κ]
    (l u : ι → ℝ) (r w : κ → ℝ) {a alpha : ℝ}
    (ha : 0 < a) (hu : ∀ i, 0 < u i) (hw : ∀ j, 0 < w j)
    (hcancel : ∑ i, l i*u i^(alpha-1) = 0) :
    tensorNormalizer l r u w a alpha = a^(1-alpha) *
      (∑ i, positiveCoeff (l i)*u i^(alpha-1)) *
      (∑ j, |r j| *w j^(1-alpha)) := by
  have hpower (ij : ι × κ) : tensorAtom u w a ij^(1-alpha) =
      a^(1-alpha)*(u ij.1^(alpha-1)*w ij.2^(1-alpha)) := by
    rw [tensorAtom_power u w ha hu hw, show -(1-alpha)=alpha-1 by ring,
      Real.div_rpow (hu _).le ha.le,
      show 1-alpha=-(alpha-1) by ring, Real.rpow_neg ha.le]
    ring
  have hterm (ij : ι × κ) : tensorNegative l r ij*tensorAtom u w a ij^(1-alpha) =
      a^(1-alpha)*((positiveCoeff (l ij.1)*u ij.1^(alpha-1))*
        (negativeCoeff (r ij.2)*w ij.2^(1-alpha)) +
        (negativeCoeff (l ij.1)*u ij.1^(alpha-1))*
        (positiveCoeff (r ij.2)*w ij.2^(1-alpha))) := by
    rw [hpower]
    unfold tensorNegative
    ring
  have hhigh : (∑ j, |r j| *w j^(1-alpha)) =
      (∑ j, negativeCoeff (r j)*w j^(1-alpha)) +
      (∑ j, positiveCoeff (r j)*w j^(1-alpha)) := by
    simp_rw [← positive_add_negative, add_mul]
    rw [Finset.sum_add_distrib]
    ring
  unfold tensorNormalizer
  simp_rw [hterm]
  rw [← Finset.mul_sum, Finset.sum_add_distrib,
    finite_tensor_factor (fun i => positiveCoeff (l i)*u i^(alpha-1))
      (fun j => negativeCoeff (r j)*w j^(1-alpha)),
    finite_tensor_factor (fun i => negativeCoeff (l i)*u i^(alpha-1))
      (fun j => positiveCoeff (r j)*w j^(1-alpha)),
    ← jordan_power_moments_equal l u (alpha-1) hcancel, hhigh]
  ring

/-- Exact normalized second moment of the actual reweighted prior. -/
theorem reweightedPrior_second_ratio {ι : Type*} [Fintype ι]
    (mu z : ι → ℝ) (B Z alpha : ℝ)
    (hmu : ∀ i, 0 ≤ mu i) (hB : 0 < B) (hZ : 0 < Z)
    (hz : ∀ i, 0 < z i) (hv : ∀ i, 1 ≤ B*z i)
    (hZdef : Z = ∑ i, mu i*z i^(1-alpha)) (ha : 0 < alpha)
    (hM : 0 < ∑ i, mu i) :
    let P := reweightedPrior mu z B Z alpha hmu hB hZ hz hv hZdef
    priorMoment P (2*alpha)/(priorMoment P alpha)^2 =
      B*Z*(∑ i, mu i*z i^alpha)/(∑ i, mu i)^2 := by
  dsimp only
  rw [reweightedPrior_power_moment _ _ _ _ _ _ _ _ _ _ _ (by positivity : 0 < 2*alpha),
    reweightedPrior_power_moment _ _ _ _ _ _ _ _ _ _ _ ha]
  simp only [sub_self, Real.rpow_zero, mul_one, show 2*alpha-alpha=alpha by ring]
  have hpow : B*(B^(alpha-1))^2 = B^(2*alpha-1) := by
    calc
      _ = B^(1 : ℝ)*B^((alpha-1)*(2 : ℝ)) := by rw [Real.rpow_one, Real.rpow_mul hB.le, Real.rpow_two]
      _ = B^(1+(alpha-1)*2) := (Real.rpow_add hB _ _).symm
      _ = _ := by congr 1; ring
  rw [← hpow]
  have hBp : B^(alpha-1) ≠ 0 := (Real.rpow_pos_of_pos hB _).ne'
  field_simp


/-- The exact source factorization `Z/B^(alpha-1)=J*high`, for
`B=1/(a*b)`, with no asymptotic estimates substituted. -/
theorem tensorNormalizer_scaled_jordan {ι κ : Type*} [Fintype ι] [Fintype κ]
    (l u : ι → ℝ) (r w : κ → ℝ) {a b alpha : ℝ}
    (ha : 0 < a) (hb : 0 < b) (hu : ∀ i, 0 < u i) (hw : ∀ j, 0 < w j)
    (hcancel : ∑ i, l i*u i^(alpha-1) = 0) :
    tensorNormalizer l r u w a alpha / ((a*b)⁻¹)^(alpha-1) =
      (∑ i, positiveCoeff (l i)*u i^(alpha-1)) *
        (∑ j, |r j| * (b/w j)^(alpha-1)) := by
  have hhigh : (∑ j, |r j| * (b/w j)^(alpha-1)) =
      b^(alpha-1)*(∑ j, |r j| * w j^(1-alpha)) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j _
    rw [Real.div_rpow hb.le (hw j).le,
      show 1-alpha=-(alpha-1) by ring, Real.rpow_neg (hw j).le]
    ring
  rw [Real.inv_rpow (mul_pos ha hb).le, div_inv_eq_mul,
    tensorNormalizer_jordan_factorization l u r w ha hu hw hcancel,
    Real.mul_rpow ha.le hb.le, hhigh]
  have hcancelA : a^(1-alpha)*a^(alpha-1) = 1 := by
    rw [← Real.rpow_add ha]
    simp only [show 1-alpha+(alpha-1)=0 by ring, Real.rpow_zero]
  calc
    _ = (a^(1-alpha)*a^(alpha-1))*
      ((∑ i, positiveCoeff (l i)*u i^(alpha-1))*
        (b^(alpha-1)*(∑ j, |r j| * w j^(1-alpha)))) := by ring
    _ = _ := by rw [hcancelA, one_mul]

/-- The high inverse-moment factor is between an actual principal mass and
the full absolute mass; the latter is at most two under the normalized masses. -/
theorem high_inverse_moment_bounds {κ : Type*} [Fintype κ] (r w : κ → ℝ)
    {b beta R c : ℝ} (hb : 0 < b) (hbeta : 0 ≤ beta) (hwb : ∀ j, b ≤ w j)
    (hpos : ∑ j, positiveCoeff (r j) = 1)
    (hneg : ∑ j, negativeCoeff (r j) = R) (hR : R ≤ 1)
    (j0 : κ) (hw0 : w j0 = b) (hc : c ≤ |r j0|) :
    c ≤ (∑ j, |r j| * (b/w j)^beta) ∧ (∑ j, |r j| * (b/w j)^beta) ≤ 2 := by
  have hw (j : κ) : 0 < w j := hb.trans_le (hwb j)
  have hfactor (j : κ) : 0 ≤ (b/w j)^beta ∧ (b/w j)^beta ≤ 1 := by
    have hratio : 0 ≤ b/w j := div_nonneg hb.le (hw j).le
    exact ⟨Real.rpow_nonneg hratio _, Real.rpow_le_one hratio ((div_le_one (hw j)).mpr (hwb j)) hbeta⟩
  constructor
  · have hsingle := Finset.single_le_sum
      (s := (Finset.univ : Finset κ)) (f := fun j => |r j| * (b/w j)^beta)
      (fun j _ => mul_nonneg (abs_nonneg _) (hfactor j).1) (Finset.mem_univ j0)
    have hsingle' : |r j0| ≤ (∑ j, |r j| * (b/w j)^beta) := by
      simpa only [hw0, div_self hb.ne', Real.one_rpow, mul_one] using hsingle
    exact hc.trans hsingle' 
  · calc
      _ ≤ ∑ j, |r j| := Finset.sum_le_sum (fun j _ =>
        mul_le_of_le_one_right (abs_nonneg _) (hfactor j).2)
      _ = 1+R := by
        simp_rw [← positive_add_negative]
        rw [Finset.sum_add_distrib,hpos,hneg]
      _ ≤ 2 := by linarith

end Renyi
