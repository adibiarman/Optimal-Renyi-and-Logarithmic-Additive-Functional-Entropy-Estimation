import Renyi.UpperBaseline

/-! The actual simplex upper-margin budget for orders at least two. -/
noncomputable section
open scoped BigOperators
namespace Renyi

lemma endpoint_margin_point_lower {α D t p : ℝ} (hα : 2≤α) (hD : 0≤D)
    (ht : 0<t) (htp : t≤p) :
    p*min (D*t^(α-2)) (t^(α-1))≤p^α*min (D/p) 1 := by
  have hp : 0<p := ht.trans_le htp
  have hpow1 := Real.rpow_le_rpow ht.le htp (show 0≤α-1 by linarith only [hα])
  have hpow2 := Real.rpow_le_rpow ht.le htp (show 0≤α-2 by linarith only [hα])
  have hid1 : p^α=p^(α-1)*p := by
    have h := Real.rpow_add hp (α-1) 1
    simpa only [sub_add_cancel,Real.rpow_one] using h
  have hid2 : p^(α-1)=p^(α-2)*p := by
    have h := Real.rpow_add hp (α-2) 1
    have hh : α-2+1=α-1 := by ring
    simpa only [hh,Real.rpow_one] using h
  have hleft := mul_le_mul_of_nonneg_left hpow2 (mul_nonneg hp.le hD)
  have hright := mul_le_mul_of_nonneg_left hpow1 hp.le
  have hleft' : p*(D*t^(α-2))≤p^α*(D/p) := by
    rw [hid1,hid2]
    have hc : (p^(α-2)*p*p)*(D/p)=(p*D)*p^(α-2) := by field_simp
    rw [hc]
    nlinarith only [hleft]
  have hright' : p*t^(α-1)≤p^α := by rw [hid1];nlinarith only [hright]
  rw [mul_min_of_nonneg _ _ hp.le,mul_min_of_nonneg _ _ (Real.rpow_nonneg hp.le α),mul_one]
  exact min_le_min hleft' hright'

/-- At least half the actual simplex mass lies above 1/(2k). -/
theorem simplex_half_mass_above_uniform_threshold {k : ℕ} (hk : 0<k) (p : Simplex k) :
    (1:ℝ)/2≤∑ i, if (1:ℝ)/(2*k)≤p.mass i then p.mass i else 0 := by
  have hkR : (0:ℝ)<k := by exact_mod_cast hk
  let t := (1:ℝ)/(2*k)
  have ht : 0<t := by dsimp [t];positivity
  have hsmall : (∑ i, if t≤p.mass i then 0 else p.mass i)≤(1:ℝ)/2 := by
    have hpoint (i : Fin k) : (if t≤p.mass i then 0 else p.mass i)≤t := by
      by_cases hi : t≤p.mass i
      · simp only [hi,ite_true];exact ht.le
      · simp only [hi,ite_false];exact (lt_of_not_ge hi).le
    have hs := Finset.sum_le_sum (fun (i : Fin k) (_hi : i∈Finset.univ) => hpoint i)
    have hid : (k:ℝ)*t=(1:ℝ)/2 := by dsimp [t];field_simp
    simpa only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,hid] using hs
  have hsplit : (∑ i, if t≤p.mass i then p.mass i else 0)+
      (∑ i, if t≤p.mass i then 0 else p.mass i)=1 := by
    rw [←Finset.sum_add_distrib]
    have hid (i : Fin k) : (if t≤p.mass i then p.mass i else 0)+(if t≤p.mass i then 0 else p.mass i)=p.mass i := by split <;> simp_all
    simp only [hid,p.normalized]
  linarith only [hsplit,hsmall]

/-- The explicit summed endpoint margin that pays the below-cutoff correction for alpha>=2. -/
theorem simplex_truncated_endpoint_margin {k : ℕ} (hk : 0<k) (p : Simplex k)
    {α a D : ℝ} (hα : 2≤α) (hD : 0≤D) (ha : a≤(1:ℝ)/(2*k)) :
    (1:ℝ)/2*min (D*((1:ℝ)/(2*k))^(α-2)) (((1:ℝ)/(2*k))^(α-1))≤
      ∑ i, if a≤p.mass i then p.mass i^α*min (D/p.mass i) 1 else 0 := by
  have hkR : (0:ℝ)<k := by exact_mod_cast hk
  let t := (1:ℝ)/(2*k)
  let C := min (D*t^(α-2)) (t^(α-1))
  have ht : 0<t := by dsimp [t];positivity
  have hC : 0≤C := le_min (mul_nonneg hD (Real.rpow_nonneg ht.le _)) (Real.rpow_nonneg ht.le _)
  have hpoint (i : Fin k) : C*(if t≤p.mass i then p.mass i else 0)≤
      if a≤p.mass i then p.mass i^α*min (D/p.mass i) 1 else 0 := by
    by_cases hi : t≤p.mass i
    · have hai : a≤p.mass i := ha.trans hi
      simp only [hi,hai,ite_true]
      have hh := endpoint_margin_point_lower hα hD ht hi
      nlinarith only [hh]
    · simp only [hi,ite_false,mul_zero]
      split
      · exact mul_nonneg (Real.rpow_nonneg (p.nonneg i) α)
          (le_min (div_nonneg hD (p.nonneg i)) (by norm_num))
      · exact le_refl 0
  have hsum := Finset.sum_le_sum (fun (i : Fin k) (_hi : i∈Finset.univ) => hpoint i)
  have hmass := mul_le_mul_of_nonneg_left (simplex_half_mass_above_uniform_threshold hk p) hC
  rw [Finset.mul_sum] at hmass
  nlinarith only [hsum,hmass]

end Renyi
