import Renyi.CoupledUpperGap
import Renyi.CoupledHighDeficit
import Renyi.CoupledMinEnvelope

/-! Strict spatial margins of the actual coupled deterministic expression. -/
noncomputable section
namespace Renyi

/-- Fractional parts in a fixed interior interval have a fixed strict upper margin. -/
theorem coupledProfiles_interior_upper_gap {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z M ω ρ σ fL f x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1)
    (hM : 0≤M) (hσγ : σ≤γ) (hσδ : σ≤1-γ)
    (hρ : 0<ρ) (hω : 0≤ω) (hωρ : ω≤1-ρ)
    (hsmall : Real.exp (-M*σ)≤ρ/4)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hz1 : z<1) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤1-ρ/2 := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hy hy1
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have ha : a≤ρ/4 := by
    exact (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
      ((Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_left hσγ hM])).trans hsmall)
  have hb : b≤ρ/4 := by
    exact (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      ((Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_left hσδ hM])).trans hsmall)
  have hb1 : b≤1 := by
    have hρ1 : ρ≤1 := by linarith only [hω,hωρ]
    linarith only [hb,hρ1]
  have hlow := (mul_le_of_le_one_right ha0 hu.2).trans ha
  have hlowcut := mul_le_of_le_one_right (mul_nonneg ha0 hu.1)
    (by linarith only [hH.1] : 1-endpointProfile N 6 1 y≤1)
  have hhigh := (mul_le_of_le_one_right hb0 hv.2).trans hb
  have hlast := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hb1)) hJ.2
  have hlastω := mul_le_of_le_one_right hω (by linarith only [hb0] : 1-b≤1)
  unfold coupledDampedExpression
  change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+
    b*highProfile N (1-γ) f ω y+ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
  nlinarith only [hlow,hlowcut,hhigh,hlast,hlastω,hωρ]

lemma fractional_power_min_linear {s y C q : ℝ} (hs : 0<s) (hs1 : s≤1)
    (hy : 0≤y) (hC : 0≤C) (hq : 0<q) :
    min q (Real.exp (-C))*min y 1≤min q (Real.exp (-C*s)*(y/s)^s) := by
  have hm0 : 0≤min y 1 := le_min hy (by norm_num)
  have hmq : min q (Real.exp (-C))≤q := min_le_left _ _
  have hme : min q (Real.exp (-C))≤Real.exp (-C) := min_le_right _ _
  have he : Real.exp (-C)≤Real.exp (-C*s) := Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_left hs1 hC])
  have hpow : min y 1≤(y/s)^s := by
    have hscale : y≤y/s := (le_div_iff₀ hs).mpr (mul_le_of_le_one_right hy hs1)
    by_cases hy1 : y≤1
    · rw [min_eq_left hy1]
      have hself : y≤y^s := by
        by_cases hy0 : y=0
        · rw [hy0,Real.zero_rpow hs.ne']
        · have hh := Real.rpow_le_rpow_of_exponent_ge (lt_of_le_of_ne hy (Ne.symm hy0)) hy1 hs1
          simpa only [Real.rpow_one] using hh
      exact hself.trans (Real.rpow_le_rpow hy hscale hs.le)
    · rw [min_eq_right (le_of_not_ge hy1)]
      exact Real.one_le_rpow (by linarith only [hscale,hy1] : 1≤y/s) hs.le
  apply le_min
  · exact (mul_le_of_le_one_right (le_min hq.le (Real.exp_pos _).le) (min_le_right _ _)).trans hmq
  · exact mul_le_mul (hme.trans he) hpow hm0 (Real.exp_pos _).le

def lowProfileLinearConstant (f : ℝ) : ℝ :=
  min (f/2) (Real.exp (-coupledMinEnvelopeConstant f (f/2)))

theorem lowProfileLinearConstant_pos {f : ℝ} (hf : 0<f) : 0<lowProfileLinearConstant f := by
  unfold lowProfileLinearConstant
  exact lt_min (by positivity) (Real.exp_pos _)

/-- A genuine linear lower comparison of the actual low profile, valid at every order. -/
theorem lowProfile_min_linear_lower {N : ℕ} (hN : 2≤N) {s f x : ℝ}
    (hs : 0<s) (hs1 : s≤1) (hf : 0<f) (hf1 : f<1) (hx : 0≤x) (hx1 : x≤1) :
    lowProfileLinearConstant f*min ((N:ℝ)^2*x) 1≤lowProfile N s f x := by
  have hCf1 := endpointReserveConstant_one_le hf.le hf1
  have hC : 0≤coupledMinEnvelopeConstant f (f/2) := by
    have hb : 0≤288+Real.log (endpointReserveConstant f) := add_nonneg (by norm_num) (Real.log_nonneg hCf1)
    exact hb.trans (le_max_left _ _)
  exact (fractional_power_min_linear hs hs1 (by positivity) hC (by positivity : 0<f/2)).trans
    (lowProfile_global_min_lower hN hs hs1 hf hf1 (by linarith) hx hx1)

lemma small_order_exp_div_linear {δ c E : ℝ} (hδ : 0<δ) (hc : 0<c)
    (hroot : 8*Real.sqrt δ≤E) (hlog : 4*δ*(-Real.log c)≤E) :
    Real.exp (-E/δ)≤c*δ := by
  have hp := small_order_scaled_power_lower hδ hc hroot hlog
  rw [Real.rpow_def_of_pos (mul_pos hc hδ)] at hp
  have he := Real.exp_le_exp.mp hp
  have hE : 0≤E := (by positivity : 0≤8*Real.sqrt δ).trans hroot
  apply (Real.le_log_iff_exp_le (mul_pos hc hδ)).mp
  apply (div_le_iff₀ hδ).mpr
  nlinarith only [he,hE]

/-- Exact capacity makes the actual reverse profile exponentially small past the high transition. -/
theorem lowProfile_capacity_outer_upper {ℓ : ℕ} (hℓ : 0<ℓ) {γ z E f x Y : ℝ}
    (hγ : 0<γ) (hγ1 : γ<1) (hf : 0≤f) (hf1 : f<1)
    (hx : 0≤x) (hx1 : x≤1) (hz : 0<z) (hzE : z≤Real.exp (-E))
    (hY : 1-γ≤Y)
    (hcap : ((ℓ:ℝ)^2*x)*Y≤Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    lowProfile ℓ γ f x≤Real.exp (-E/(1-γ)) := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hYp : 0<Y := hd.trans_le hY
  have hu := (lowProfile_upper_power hℓ hγ hγ1.le hf hf1 hx hx1).trans
    (reverse_capacity_power hγ hγ1 (by positivity) hYp hz hcap)
  have hquot := Real.rpow_le_one (div_nonneg hd.le hYp.le) ((div_le_one hYp).mpr hY) hγ.le
  have hzpow := Real.rpow_le_rpow hz.le hzE (one_div_pos.mpr hd).le
  rw [←Real.exp_mul] at hzpow
  have hid : -E*(1/(1-γ))=-E/(1-γ) := by ring
  rw [hid] at hzpow
  exact hu.trans ((mul_le_of_le_one_right (Real.rpow_nonneg hz.le _) hquot).trans hzpow)

/-- Spatial strict margin near fractional part one, outside the high transition neighborhood. -/
theorem coupledProfiles_complement_outer_spatial_gap {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z E M ω ρ fL f x y : ℝ} (hγhalf : (1:ℝ)/2≤γ) (hγ1 : γ<1)
    (hM : 1≤M) (hMd : M*(1-γ)≤1) (hρ : 0<ρ) (hρ1 : ρ≤1)
    (hroot : 8*Real.sqrt (1-γ)≤E) (hlog : 4*(1-γ)*(-Real.log (ρ/4))≤E)
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωρ : ω≤1-ρ) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hzE : z≤Real.exp (-E))
    (hsmall : 1-γ≤lowDeficitOrder (1-ρ))
    (hY : lowDeficitLocalScale (1-ρ)*(1-γ)≤(N:ℝ)^2*y)
    (hcap : ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤1-
      (ρ/8)*(1-γ)-(Real.exp (-1)/2*lowDeficitConstant (1-ρ))*min ((N:ℝ)^2*y) 1-
      (ρ*lowProfileLinearConstant fL/8)*min ((ℓ:ℝ)^2*x) 1 := by
  have hγ : 0<γ := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hM0 : 0≤M := by linarith only [hM]
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hE : 0<E := lt_of_lt_of_le (by positivity : 0<8*Real.sqrt (1-γ)) hroot
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hcoef := overlap_coefficients hγ hγ1 hz hz1
  have hu := lowProfile_range (by omega : 0<ℓ) hγ hfL.le hfL1 hx hx1
  have hv := highProfile_range (by omega : 0<N) hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range (by omega : 0<N) (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range (by omega : 0<N) (by norm_num : 6≤6) hd hy hy1
  have hYd : 1-γ≤(N:ℝ)^2*y := by
    have hscale : 1≤lowDeficitLocalScale (1-ρ) := le_max_left _ _
    simpa only [one_mul] using (mul_le_mul_of_nonneg_right hscale hd.le).trans hY
  have hus := (lowProfile_capacity_outer_upper (by omega : 0<ℓ) hγ hγ1 hfL.le hfL1 hx hx1 hz hzE hYd hcap).trans
    (small_order_exp_div_linear hd (by positivity : 0<ρ/4) hroot hlog)
  have hus' : lowProfile ℓ γ fL x≤1-γ := by nlinarith only [hus,hρ1,hd]
  have hZ := (lowProfile_min_linear_lower hℓ hγ hγ1.le hfL hfL1 hx hx1).trans hus'
  have hvg := highProfile_deficit hN hd hd1 hf hf1 hω hωρ (by linarith only [hρ] : 1-ρ<1) hy hy1 hsmall hY
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have ha1 : a≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM0,hγ]))
  have hb1 : b≤1-(1-γ)/2 := by
    have he : Real.exp (-M*(1-γ))≤Real.exp (-(1-γ)) := Real.exp_le_exp.mpr (by nlinarith only [hM,hd])
    exact (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      (he.trans (exp_neg_le_linear_half hd.le hd1))
  have hb1' : b≤1 := by linarith only [hb1,hd]
  have hblow : Real.exp (-1)/2≤b := by
    have hbc : (1:ℝ)/2≤overlapB γ z := hγhalf.trans hcoef.2.le
    have he : Real.exp (-1)≤Real.exp (-M*(1-γ)) := Real.exp_le_exp.mpr (by nlinarith only [hMd])
    have hm := mul_le_mul hbc he (Real.exp_pos (-1)).le hc.2.2.1.le
    dsimp [b]
    nlinarith only [hm]
  have hlow := (mul_le_of_le_one_left hu.1 ha1).trans hus
  have hlowcut := mul_le_of_le_one_right (mul_nonneg ha0 hu.1)
    (by linarith only [hH.1] : 1-endpointProfile N 6 1 y≤1)
  have hhigh := mul_le_mul_of_nonneg_left hvg hb0
  have hhighgap := mul_le_mul_of_nonneg_right hblow
    (mul_nonneg (lowDeficitConstant_pos (by linarith only [hρ] : 1-ρ<1)).le
      (show 0≤min ((N:ℝ)^2*y) 1 from le_min (by positivity) (by norm_num)))
  have hlast := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hb1')) hJ.2
  have hlastω := mul_le_mul_of_nonneg_right hωρ (sub_nonneg.mpr hb1')
  have hδgap := mul_le_mul_of_nonneg_left hb1 hρ.le
  have hZgap := mul_le_mul_of_nonneg_left hZ (show 0≤ρ/8 by positivity)
  unfold coupledDampedExpression
  change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+
    b*highProfile N (1-γ) f ω y+ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
  nlinarith only [hlow,hlowcut,hhigh,hhighgap,hlast,hlastω,hδgap,hZgap]

/-- Product separation yields a fixed strict margin when the reverse profile exceeds the tiny-order scale. -/
theorem coupledProfiles_complement_separated_gap {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 0<N)
    {γ z E M ω ρ fL f x y : ℝ} (hγhalf : (1:ℝ)/2≤γ) (hγ1 : γ<1)
    (hM : 1≤M) (hρ : 0<ρ) (_hρ1 : ρ≤1)
    (hMρ : Real.exp (-M/2)≤ρ/2) (hEρ : Real.exp (-E/2)≤1-ρ)
    (hroot : 8*Real.sqrt (1-γ)≤E) (hlog : 4*(1-γ)*(-Real.log (ρ/4))≤E)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωρ : ω≤1-ρ) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hzE : z≤Real.exp (-E))
    (hus : ρ*(1-γ)/4<lowProfile ℓ γ fL x)
    (hcap : ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y ≤1-ρ/2 := by
  have hγ : 0<γ := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hM0 : 0≤M := by linarith only [hM]
  have hω1 : ω<1 := by linarith only [hωρ,hρ]
  have hE : 0<E := lt_of_lt_of_le (by positivity : 0<8*Real.sqrt (1-γ)) hroot
  have hz1 : z<1 := hzE.trans_lt (Real.exp_lt_one_iff.mpr (by linarith only [hE]))
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := lowProfile_range hℓ hγ hfL hfL1 hx hx1
  have hv := highProfile_range hN hd hf hf1 hω hω1 hy hy1
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hd hy hy1
  let a := overlapA γ z*Real.exp (-M*γ)
  let b := overlapB γ z*Real.exp (-M*(1-γ))
  have ha0 : 0≤a := mul_nonneg hc.1.le (Real.exp_pos _).le
  have hb0 : 0≤b := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have hb1 : b≤1-(1-γ)/2 := by
    have he : Real.exp (-M*(1-γ))≤Real.exp (-(1-γ)) := Real.exp_le_exp.mpr (by nlinarith only [hM,hd])
    exact (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      (he.trans (exp_neg_le_linear_half hd.le hd1))
  have hb1' : b≤1 := by linarith only [hb1,hd]
  have ha1 : a≤1 := (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
    (Real.exp_le_one_iff.mpr (by nlinarith only [hM0,hγ]))
  have hT : coupledDampedExpression ℓ N γ z M ω fL f x y ≤
      a*lowProfile ℓ γ fL x+b*highProfile N (1-γ) f ω y+ω*(1-b) := by
    have hlow := mul_le_of_le_one_right (mul_nonneg ha0 hu.1) (by linarith only [hH.1] : 1-endpointProfile N 6 1 y≤1)
    have hlast := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hb1')) hJ.2
    unfold coupledDampedExpression
    change a*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y)+b*highProfile N (1-γ) f ω y+
      ω*(1-b)*endpointProfile N 6 (1-γ) y≤_
    linarith only [hlow,hlast]
  have hp := small_order_scaled_power_lower hd (by positivity : 0<ρ/4) hroot hlog
  have hprod := coupledProfiles_product_le hℓ hN hγ hγ1 hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hz hcap
  have hcpos : 0<ρ*(1-γ)/4 := by positivity
  have hp' : Real.exp (-E/2)≤(ρ*(1-γ)/4)^(1-γ) := by convert hp using 1;congr 1;ring
  have hvsep := (product_high_separation hγ hγ1 hus.le hcpos hv.1 hv.2 hp' hprod hzE).trans hEρ
  have haρ : a≤ρ/2 := by
    apply (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.1.le).trans
    apply le_trans _ hMρ
    apply Real.exp_le_exp.mpr
    nlinarith only [mul_le_mul_of_nonneg_left hγhalf hM0]
  have hlow := (mul_le_of_le_one_right ha0 hu.2).trans haρ
  have hhigh := mul_le_mul_of_nonneg_left hvsep hb0
  have hωb := mul_le_mul_of_nonneg_right hωρ (sub_nonneg.mpr hb1')
  nlinarith only [hT,hlow,hhigh,hωb]

def complementMarginInnerConstant (f ρ : ℝ) : ℝ :=
  ρ*lowProfileLinearConstant f/(4*(lowProfileLinearConstant f*(1+lowDeficitLocalScale (1-ρ))+1))

def complementMarginConstant (f ρ : ℝ) : ℝ :=
  min (complementMarginInnerConstant f ρ)
    (min (ρ/6) (min (ρ/8)
      (min (Real.exp (-1)/2*lowDeficitConstant (1-ρ)) (ρ*lowProfileLinearConstant f/8))))

theorem complementMarginConstant_pos {f ρ : ℝ} (hf : 0<f) (hρ : 0<ρ) :
    0<complementMarginConstant f ρ := by
  have hc := lowProfileLinearConstant_pos hf
  have hD : 0<lowDeficitLocalScale (1-ρ) := zero_lt_one.trans_le (le_max_left _ _)
  have hg := lowDeficitConstant_pos (by linarith only [hρ] : 1-ρ<1)
  unfold complementMarginConstant complementMarginInnerConstant
  positivity

lemma three_margin_sum {T a b c d X Y Z : ℝ} (hX : 0≤X) (hY : 0≤Y) (hZ : 0≤Z)
    (ha : d≤a) (hb : d≤b) (hc : d≤c) (hT : T≤1-a*X-b*Y-c*Z) :
    T≤1-d*(X+Y+Z) := by
  have hx := mul_le_mul_of_nonneg_right ha hX
  have hy := mul_le_mul_of_nonneg_right hb hY
  have hz := mul_le_mul_of_nonneg_right hc hZ
  nlinarith only [hx,hy,hz,hT]

/-- Complete actual strict spatial margin for fractional parts close to one. -/
theorem coupledProfiles_complement_spatial_gap {ℓ N : ℕ} (hℓ : 2≤ℓ) (hN : 2≤N)
    {γ z E M ω ρ fL f x y : ℝ} (hγhalf : (1:ℝ)/2≤γ) (hγ1 : γ<1)
    (hM : 1≤M) (hMd : M*(1-γ)≤1) (hρ : 0<ρ) (hρ1 : ρ≤1)
    (hMρ : Real.exp (-M/2)≤ρ/2) (hEρ : Real.exp (-E/2)≤1-ρ)
    (hroot : 8*Real.sqrt (1-γ)≤E) (hlog : 4*(1-γ)*(-Real.log (ρ/4))≤E)
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1)
    (hω : 0≤ω) (hωρ : ω≤1-ρ) (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hz : 0<z) (hzE : z≤Real.exp (-E)) (hsmall : 1-γ≤lowDeficitOrder (1-ρ))
    (hcap : ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y)≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    coupledDampedExpression ℓ N γ z M ω fL f x y≤1-complementMarginConstant fL ρ*
      ((1-γ)+min ((N:ℝ)^2*y) 1+min ((ℓ:ℝ)^2*x) 1) := by
  have hγ : 0<γ := by linarith only [hγhalf]
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hY0 : 0≤min ((N:ℝ)^2*y) 1 := le_min (by positivity) (by norm_num)
  have hZ0 : 0≤min ((ℓ:ℝ)^2*x) 1 := le_min (by positivity) (by norm_num)
  have hc := (complementMarginConstant_pos hfL hρ).le
  by_cases houter : lowDeficitLocalScale (1-ρ)*(1-γ)≤(N:ℝ)^2*y
  · have hca : complementMarginConstant fL ρ≤ρ/8 := by
      unfold complementMarginConstant
      exact (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
    have hcb : complementMarginConstant fL ρ≤Real.exp (-1)/2*lowDeficitConstant (1-ρ) := by
      unfold complementMarginConstant
      exact (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _)))
    have hcc : complementMarginConstant fL ρ≤ρ*lowProfileLinearConstant fL/8 := by
      unfold complementMarginConstant
      exact (min_le_right _ _).trans ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _)))
    exact three_margin_sum hd.le hY0 hZ0 hca hcb hcc
      (coupledProfiles_complement_outer_spatial_gap hℓ hN hγhalf hγ1 hM hMd hρ hρ1 hroot hlog
        hfL hfL1 hf hf1 hω hωρ hx hx1 hy hy1 hz hzE hsmall houter hcap)
  by_cases hus : lowProfile ℓ γ fL x≤ρ*(1-γ)/4
  · have hbase := coupledProfiles_small_complement_upper_gap (by omega : 0<ℓ) (by omega : 0<N)
      hγhalf hγ1 hM hρ hρ1 hMρ hEρ hroot hlog hfL.le hfL1 hf hf1 hω hωρ hx hx1 hy hy1 hz hzE hcap
    have hY := (min_le_left ((N:ℝ)^2*y) 1).trans (le_of_lt (lt_of_not_ge houter))
    have hZ := (lowProfile_min_linear_lower hℓ hγ hγ1.le hfL hfL1 hx hx1).trans hus
    let L := lowProfileLinearConstant fL
    let D := lowDeficitLocalScale (1-ρ)
    let S := (1-γ)+min ((N:ℝ)^2*y) 1+min ((ℓ:ℝ)^2*x) 1
    have hL := lowProfileLinearConstant_pos hfL
    have hD : 0<D := zero_lt_one.trans_le (le_max_left _ _)
    have hZ' : L*min ((ℓ:ℝ)^2*x) 1≤1-γ := by dsimp [L];nlinarith only [hZ,hρ1,hd]
    have hYs := mul_le_mul_of_nonneg_left hY hL.le
    have hbudget : L*S≤(L*(1+D)+1)*(1-γ) := by dsimp [S];nlinarith only [hYs,hZ']
    have hcoef : complementMarginConstant fL ρ≤complementMarginInnerConstant fL ρ := min_le_left _ _
    have hmul := mul_le_mul_of_nonneg_left hbudget hc
    have hcoefmul := mul_le_mul_of_nonneg_right hcoef
      (mul_nonneg (show 0≤L*(1+D)+1 by positivity) hd.le)
    have hid : complementMarginInnerConstant fL ρ*(L*(1+D)+1)=ρ*L/4 := by
      have hden : 0<L*(1+D)+1 := by positivity
      change (ρ*L/(4*(L*(1+D)+1)))*(L*(1+D)+1)=ρ*L/4
      field_simp [ne_of_gt hden]
    simp only [←mul_assoc] at hcoefmul
    rw [hid] at hcoefmul
    have hfinal : complementMarginConstant fL ρ*S≤ρ*(1-γ)/4 := by
      apply (mul_le_mul_iff_right₀ hL).mp
      nlinarith only [hmul,hcoefmul]
    dsimp [S] at hfinal
    linarith only [hbase,hfinal]
  · have hsep := coupledProfiles_complement_separated_gap (by omega : 0<ℓ) (by omega : 0<N)
      hγhalf hγ1 hM hρ hρ1 hMρ hEρ hroot hlog hfL.le hfL1 hf hf1 hω hωρ hx hx1 hy hy1 hz hzE
      (lt_of_not_ge hus) hcap
    have hsum : (1-γ)+min ((N:ℝ)^2*y) 1+min ((ℓ:ℝ)^2*x) 1≤3 := by
      nlinarith only [min_le_right ((N:ℝ)^2*y) 1,min_le_right ((ℓ:ℝ)^2*x) 1,hγ]
    have hcoef : complementMarginConstant fL ρ≤ρ/6 := (min_le_right _ _).trans (min_le_left _ _)
    have hm := mul_le_mul_of_nonneg_left hsum hc
    nlinarith only [hsep,hm,hcoef]

end Renyi
