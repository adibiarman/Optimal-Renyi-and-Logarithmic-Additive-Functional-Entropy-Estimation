import Renyi.CoupledProfiles

/-! The actual coupled expression extends to a single ordinary polynomial. -/
noncomputable section
open scoped BigOperators
open Polynomial
namespace Renyi

/-- Reverse a polynomial through degree `m`, scaling its argument by `a`. -/
def reverseScaledPolynomial (P : ℝ[X]) (m : ℕ) (a : ℝ) : ℝ[X] :=
  ∑ j ∈ P.support, monomial (m-j) (P.coeff j*a^j)

lemma reverseScaledPolynomial_eval (P : ℝ[X]) {m : ℕ} (hm : P.natDegree ≤ m)
    (a : ℝ) {p : ℝ} (hp : p ≠ 0) :
    (reverseScaledPolynomial P m a).eval p = p^m*P.eval (a/p) := by
  rw [eval_eq_sum (p := P), Polynomial.sum, Finset.mul_sum]
  simp only [reverseScaledPolynomial, eval_finset_sum, eval_monomial]
  apply Finset.sum_congr rfl
  intro j hj
  have hjm := (le_natDegree_of_mem_supp j hj).trans hm
  have he : p^m=p^(m-j)*p^j := by rw [← pow_add, Nat.sub_add_cancel hjm]
  rw [he, div_pow]
  field_simp

lemma reverseScaledPolynomial_natDegree (P : ℝ[X]) (m : ℕ) (a : ℝ) :
    (reverseScaledPolynomial P m a).natDegree ≤ m := by
  apply natDegree_sum_le_of_forall_le
  intro j _
  exact (natDegree_monomial_le _).trans (Nat.sub_le _ _)

lemma reverse_fractional_identity (m : ℕ) (γ : ℝ) {a p : ℝ} (ha : 0 ≤ a) (hp : 0 < p) :
    p^((m:ℝ)+γ)*(a/p)^γ = a^γ*p^m := by
  rw [Real.rpow_add hp, Real.rpow_natCast, Real.div_rpow ha hp.le]
  have hpow := (Real.rpow_pos_of_pos hp γ).ne'
  field_simp

lemma forward_fractional_identity (m : ℕ) (γ : ℝ) {b p : ℝ} (hb : 0 < b) (hp : 0 < p) :
    p^((m:ℝ)+γ)*(p/b)^(1-γ) = p^(m+1)/b^(1-γ) := by
  rw [Real.div_rpow hp.le hb.le, ← mul_div_assoc,
    ← Real.rpow_add hp, show (m:ℝ)+γ+(1-γ)=(m+1:ℕ) by push_cast; ring,
    Real.rpow_natCast]

/-- The single polynomial in the deterministic construction (Chebyshev low branch). -/
def coupledQPolynomial (ℓ N m : ℕ) (γ a b fL f A B ω : ℝ) : ℝ[X] :=
  C (A*a^γ) * reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a *
    (1 - (C b⁻¹*X) * (endpointProfilePolynomial N 6 1).comp (C b⁻¹*X)) +
  C (B/b^(1-γ)) * X^(m+1) * (highProfilePolynomial N (1-γ) f ω).comp (C b⁻¹*X) +
  C (ω*(1-B)/b^(1-γ)) * X^(m+1) *
    (endpointProfilePolynomial N 6 (1-γ)).comp (C b⁻¹*X)

def coupledQExpression (ℓ N m : ℕ) (γ a b fL f A B ω p : ℝ) : ℝ :=
  p^((m:ℝ)+γ) *
    (A*lowProfile ℓ γ fL (a/p)*(1-endpointProfile N 6 1 (p/b)) +
      B*highProfile N (1-γ) f ω (p/b) + ω*(1-B)*endpointProfile N 6 (1-γ) (p/b))

/-- No polynomial-existence assumption: evaluation equals the manuscript expression. -/
theorem coupledQPolynomial_eval {ℓ N m : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    (hdegree : 4*(ℓ-1) ≤ m) {γ a b p fL f A B ω : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 < a) (hap : a ≤ p) (hpb : p ≤ b) :
    (coupledQPolynomial ℓ N m γ a b fL f A B ω).eval p =
      coupledQExpression ℓ N m γ a b fL f A B ω p := by
  have hp : 0 < p := ha.trans_le hap
  have hb : 0 < b := hp.trans_le hpb
  have hr0 : 0 ≤ a/p := div_nonneg ha.le hp.le
  have hr1 : a/p ≤ 1 := (div_le_one hp).mpr hap
  have hf0 : 0 ≤ p/b := div_nonneg hp.le hb.le
  have hf1 : p/b ≤ 1 := (div_le_one hb).mpr hpb
  have hδ : 0 < 1-γ := by linarith
  have hrev := reverseScaledPolynomial_eval (lowProfilePolynomial ℓ γ fL)
    ((lowProfilePolynomial_natDegree ℓ γ fL).trans hdegree) a hp.ne'
  have hrpow := reverse_fractional_identity m γ ha.le hp
  have hfpow := forward_fractional_identity m γ hb hp
  simp only [coupledQPolynomial, eval_add, eval_mul, eval_C, eval_X, eval_sub,
    eval_one, eval_pow, eval_comp, hrev]
  have hscale : b⁻¹*p=p/b := by ring
  rw [hscale]
  unfold coupledQExpression
  rw [lowProfile_polynomial hℓ hγ hr0 hr1,
    highProfile_polynomial hN hδ hf0 hf1,
    endpointProfile_polynomial hN 6 hδ hf0 hf1,
    endpointProfile_polynomial hN 6 (by norm_num : (0:ℝ)<1) hf0 hf1, Real.rpow_one]
  calc
    _ = (a^γ*p^m)*A*(lowProfilePolynomial ℓ γ fL).eval (a/p)*
          (1-p/b*(endpointProfilePolynomial N 6 1).eval (p/b)) +
        (p^(m+1)/b^(1-γ))*B*(highProfilePolynomial N (1-γ) f ω).eval (p/b) +
        (p^(m+1)/b^(1-γ))*ω*(1-B)*(endpointProfilePolynomial N 6 (1-γ)).eval (p/b) := by ring
    _ = _ := by rw [← hrpow, ← hfpow]; ring

lemma scaledPolynomial_natDegree (P : ℝ[X]) (b : ℝ) :
    (P.comp (C b⁻¹*X)).natDegree ≤ P.natDegree := by
  have hlin : (C b⁻¹*X : ℝ[X]).natDegree ≤ 1 := by compute_degree
  exact natDegree_comp_le.trans (by simpa using Nat.mul_le_mul_left P.natDegree hlin)

/-- Degree of the actual combined polynomial, before choosing `N` from the light budget. -/
theorem coupledQPolynomial_natDegree (ℓ N m : ℕ) (γ a b fL f A B ω : ℝ) :
    (coupledQPolynomial ℓ N m γ a b fL f A B ω).natDegree ≤ m+1+18*(N-1) := by
  have hlin : (C b⁻¹*X : ℝ[X]).natDegree ≤ 1 := by compute_degree
  have hJ1 := (scaledPolynomial_natDegree (endpointProfilePolynomial N 6 1) b).trans
    (endpointProfilePolynomial_natDegree N 6 1)
  have hJδ := (scaledPolynomial_natDegree (endpointProfilePolynomial N 6 (1-γ)) b).trans
    (endpointProfilePolynomial_natDegree N 6 (1-γ))
  have hv := (scaledPolynomial_natDegree (highProfilePolynomial N (1-γ) f ω) b).trans
    (highProfilePolynomial_natDegree N (1-γ) f ω)
  have hcutmul := natDegree_mul_le_of_le hlin hJ1
  have hcut : (1-(C b⁻¹*X)*(endpointProfilePolynomial N 6 1).comp (C b⁻¹*X)).natDegree ≤
      1+6*(N-1) := (natDegree_sub_le _ _).trans (by simpa using hcutmul)
  have hreverse := (natDegree_C_mul_le (A*a^γ) _).trans
    (reverseScaledPolynomial_natDegree (lowProfilePolynomial ℓ γ fL) m a)
  have hlow := natDegree_mul_le_of_le hreverse hcut
  have hhigh := natDegree_mul_le_of_le
    ((natDegree_C_mul_le (B/b^(1-γ)) _).trans (natDegree_X_pow_le (m+1))) hv
  have hrest := natDegree_mul_le_of_le
    ((natDegree_C_mul_le (ω*(1-B)/b^(1-γ)) _).trans (natDegree_X_pow_le (m+1))) hJδ
  unfold coupledQPolynomial
  have hadd := natDegree_add_le_of_le (natDegree_add_le_of_le hlow hhigh) hrest
  exact hadd.trans (by omega)

lemma reverseScaledPolynomial_abs_eval (P : ℝ[X]) {m : ℕ} (hm : P.natDegree ≤ m)
    {a p : ℝ} (hp : 0 ≤ p) (hpa : p ≤ a) :
    |(reverseScaledPolynomial P m a).eval p| ≤ coefficientMass P*a^m := by
  have ha := hp.trans hpa
  simp only [reverseScaledPolynomial, eval_finset_sum, eval_monomial]
  calc
    _ ≤ ∑ j ∈ P.support, |P.coeff j*a^j*p^(m-j)| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ j ∈ P.support, |P.coeff j| *a^m := by
      apply Finset.sum_le_sum
      intro j hj
      have hjm := (le_natDegree_of_mem_supp j hj).trans hm
      rw [abs_mul, abs_mul, abs_of_nonneg (pow_nonneg ha _), abs_of_nonneg (pow_nonneg hp _)]
      have hpow := pow_le_pow_left₀ hp hpa (m-j)
      have hmulpow := mul_le_mul_of_nonneg_left hpow (show 0 ≤ |P.coeff j| *a^j by positivity)
      convert hmulpow using 1
      rw [mul_assoc, ←pow_add, Nat.add_sub_of_le hjm]
    _ = coefficientMass P*a^m := by simp [coefficientMass, Polynomial.sum_def, Finset.sum_mul]

/-- Evaluation below the reverse cutoff, retaining the ordinary reversed polynomial. -/
theorem coupledQPolynomial_eval_forward {ℓ N m : ℕ} (hN : 0 < N)
    {γ a b p fL f A B ω : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hb : 0 < b) (hp : 0 ≤ p) (hpb : p ≤ b) :
    (coupledQPolynomial ℓ N m γ a b fL f A B ω).eval p =
      A*a^γ*(reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a).eval p *
        (1-endpointProfile N 6 1 (p/b)) +
      p^((m:ℝ)+γ)*(B*highProfile N (1-γ) f ω (p/b) +
        ω*(1-B)*endpointProfile N 6 (1-γ) (p/b)) := by
  rcases hp.eq_or_lt with rfl | hp
  · have hα : (m:ℝ)+γ ≠ 0 := by positivity
    simp [coupledQPolynomial, Real.zero_rpow hα]
  have hf0 : 0 ≤ p/b := div_nonneg hp.le hb.le
  have hf1 : p/b ≤ 1 := (div_le_one hb).mpr hpb
  have hδ : 0 < 1-γ := by linarith
  have hfpow := forward_fractional_identity m γ hb hp
  simp only [coupledQPolynomial, eval_add, eval_mul, eval_C, eval_X, eval_sub,
    eval_one, eval_pow, eval_comp]
  have hscale : b⁻¹*p=p/b := by ring
  rw [hscale, highProfile_polynomial hN hδ hf0 hf1,
    endpointProfile_polynomial hN 6 hδ hf0 hf1,
    endpointProfile_polynomial hN 6 (by norm_num : (0:ℝ)<1) hf0 hf1, Real.rpow_one]
  calc
    _ = A*a^γ*(reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a).eval p *
          (1-p/b*(endpointProfilePolynomial N 6 1).eval (p/b)) +
        (p^(m+1)/b^(1-γ))*(B*(highProfilePolynomial N (1-γ) f ω).eval (p/b) +
          ω*(1-B)*(endpointProfilePolynomial N 6 (1-γ)).eval (p/b)) := by ring
    _ = _ := by rw [←hfpow]; ring

/-- Actual below-cutoff contribution, prior to the exponential simplification of the constant. -/
theorem coupledQPolynomial_below_cutoff {ℓ N m : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    (hdegree : 4*(ℓ-1) ≤ m) {γ a b p fL f A B ω : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 < a) (hab : a ≤ b)
    (hp : 0 ≤ p) (hpa : p ≤ a) (hfL : 0 ≤ fL) (hfL1 : fL < 1)
    (hf : 0 ≤ f) (hf1 : f ≤ 1) (hA : 0 ≤ A) (hA1 : A ≤ 1)
    (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1) :
    |(coupledQPolynomial ℓ N m γ a b fL f A B ω).eval p| + p^((m:ℝ)+γ) ≤
      (96*(ℓ:ℝ)^2*(9:ℝ)^(4*(ℓ-1))+2)*a^((m:ℝ)+γ) := by
  have hb := ha.trans_le hab
  have hpb := hpa.trans hab
  have hx := div_nonneg hp hb.le
  have hx1 := (div_le_one hb).mpr hpb
  have hδ : 0 < 1-γ := by linarith
  have hH := endpointProfile_range hN (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hx hx1
  have hJ := endpointProfile_range hN (by norm_num : 6≤6) hδ hx hx1
  have hv := highProfile_range hN hδ hf hf1 hω hω1 hx hx1
  have hbr0 : 0 ≤ B*highProfile N (1-γ) f ω (p/b) + ω*(1-B)*endpointProfile N 6 (1-γ) (p/b) := by
    exact add_nonneg (mul_nonneg hB hv.1) (mul_nonneg (mul_nonneg hω (sub_nonneg.mpr hB1)) hJ.1)
  have hbr1 : B*highProfile N (1-γ) f ω (p/b) + ω*(1-B)*endpointProfile N 6 (1-γ) (p/b) ≤ 1 := by
    have hvb := mul_le_of_le_one_right hB hv.2
    have hjb := mul_le_of_le_one_right (mul_nonneg hω (sub_nonneg.mpr hB1)) hJ.2
    have hw := mul_le_of_le_one_left (sub_nonneg.mpr hB1) hω1.le
    linarith
  have hα : 0 < (m:ℝ)+γ := by positivity
  have hpα := Real.rpow_le_rpow hp hpa hα.le
  have haid : a^γ*a^m=a^((m:ℝ)+γ) := by rw [mul_comm, ←Real.rpow_natCast, ←Real.rpow_add ha]
  have hrev := reverseScaledPolynomial_abs_eval (lowProfilePolynomial ℓ γ fL)
    ((lowProfilePolynomial_natDegree ℓ γ fL).trans hdegree) hp hpa
  have hmass := lowProfilePolynomial_coefficientMass hℓ hγ hγ1.le hfL hfL1
  have hrev' : |(reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a).eval p| ≤
      (96*(ℓ:ℝ)^2*9^(4*(ℓ-1)))*a^m :=
    hrev.trans (mul_le_mul_of_nonneg_right hmass (pow_nonneg ha.le m))
  have hlow : |A*a^γ*(reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a).eval p *
      (1-endpointProfile N 6 1 (p/b))| ≤
      (96*(ℓ:ℝ)^2*9^(4*(ℓ-1)))*a^((m:ℝ)+γ) := by
    rw [abs_mul, abs_mul, abs_mul, abs_of_nonneg hA, abs_of_nonneg (Real.rpow_nonneg ha.le γ),
      abs_of_nonneg (sub_nonneg.mpr hH.2)]
    have hscale := mul_le_mul_of_nonneg_left hrev' (show 0 ≤ A*a^γ by positivity)
    have hc := mul_le_of_le_one_right
      (show 0 ≤ A*a^γ*|(reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a).eval p| by positivity)
      (show 1-endpointProfile N 6 1 (p/b) ≤ 1 by linarith [hH.1])
    have hcoef : A*a^γ*((96*(ℓ:ℝ)^2*9^(4*(ℓ-1)))*a^m) ≤
        (96*(ℓ:ℝ)^2*9^(4*(ℓ-1)))*a^((m:ℝ)+γ) := by
      have haA := mul_le_of_le_one_left
        (show 0 ≤ (96*(ℓ:ℝ)^2*9^(4*(ℓ-1)))*a^((m:ℝ)+γ) by positivity) hA1
      calc
        _ = A*((96*(ℓ:ℝ)^2*9^(4*(ℓ-1)))*a^((m:ℝ)+γ)) := by rw [←haid]; ring
        _ ≤ _ := haA
    exact hc.trans (hscale.trans hcoef)
  rw [coupledQPolynomial_eval_forward hN hγ hγ1 hb hp hpb]
  have hhigh : |p^((m:ℝ)+γ)*(B*highProfile N (1-γ) f ω (p/b) +
      ω*(1-B)*endpointProfile N 6 (1-γ) (p/b))| ≤ a^((m:ℝ)+γ) := by
    rw [abs_of_nonneg (mul_nonneg (Real.rpow_nonneg hp _) hbr0)]
    exact (mul_le_of_le_one_right (Real.rpow_nonneg hp _) hbr1).trans hpα
  have ht := abs_add_le
    (A*a^γ*(reverseScaledPolynomial (lowProfilePolynomial ℓ γ fL) m a).eval p *
      (1-endpointProfile N 6 1 (p/b)))
    (p^((m:ℝ)+γ)*(B*highProfile N (1-γ) f ω (p/b) + ω*(1-B)*endpointProfile N 6 (1-γ) (p/b)))
  nlinarith

lemma low_coefficient_constant_exponential {ℓ m : ℕ} (hdegree : 4*(ℓ-1) ≤ m) :
    96*(ℓ:ℝ)^2*(9:ℝ)^(4*(ℓ-1))+2 ≤ (100:ℝ)^(m+1) := by
  have hm2 : (m:ℝ)+1 ≤ (2:ℝ)^m := by
    clear hdegree
    induction m with
    | zero => norm_num
    | succ n ih =>
      rw [pow_succ]
      push_cast
      have hn : 0 ≤ (n:ℝ) := Nat.cast_nonneg n
      nlinarith
  have hℓm : ℓ ≤ m+1 := by omega
  have hℓ2 : (ℓ:ℝ) ≤ (2:ℝ)^m := (by exact_mod_cast hℓm : (ℓ:ℝ) ≤ (m:ℝ)+1).trans hm2
  have hsquare : (ℓ:ℝ)^2 ≤ (4:ℝ)^m := by
    have hh := pow_le_pow_left₀ (Nat.cast_nonneg ℓ) hℓ2 2
    have he : ((2:ℝ)^m)^2 = (4:ℝ)^m := by rw [←pow_mul, Nat.mul_comm, pow_mul]; norm_num
    exact hh.trans_eq he
  have hp9 : (9:ℝ)^(4*(ℓ-1)) ≤ (9:ℝ)^m := pow_le_pow_right₀ (by norm_num) hdegree
  have hp36 : 1 ≤ (36:ℝ)^m := one_le_pow₀ (by norm_num)
  have hp100 : (36:ℝ)^m ≤ (100:ℝ)^m := pow_le_pow_left₀ (by norm_num) (by norm_num) m
  calc
    _ ≤ 96*(4:ℝ)^m*(9:ℝ)^m+2 := by
      have hh := mul_le_mul hsquare hp9 (by positivity) (by positivity)
      nlinarith
    _ = 96*(36:ℝ)^m+2 := by rw [mul_assoc, ←mul_pow]; norm_num
    _ ≤ 98*(36:ℝ)^m := by linarith
    _ ≤ 100*(100:ℝ)^m := by nlinarith
    _ = (100:ℝ)^(m+1) := by rw [pow_succ]; ring

/-- The source's below-cutoff assertion with an explicit universal constant. -/
theorem coupledQPolynomial_below_cutoff_exponential {ℓ N m : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    (hdegree : 4*(ℓ-1) ≤ m) {γ a b p fL f A B ω : ℝ}
    (hγ : 0 < γ) (hγ1 : γ < 1) (ha : 0 < a) (hab : a ≤ b)
    (hp : 0 ≤ p) (hpa : p ≤ a) (hfL : 0 ≤ fL) (hfL1 : fL < 1)
    (hf : 0 ≤ f) (hf1 : f ≤ 1) (hA : 0 ≤ A) (hA1 : A ≤ 1)
    (hB : 0 ≤ B) (hB1 : B ≤ 1) (hω : 0 ≤ ω) (hω1 : ω < 1) :
    |(coupledQPolynomial ℓ N m γ a b fL f A B ω).eval p| + p^((m:ℝ)+γ) ≤
      (100:ℝ)^(m+1)*a^((m:ℝ)+γ) :=
  (coupledQPolynomial_below_cutoff hℓ hN hdegree hγ hγ1 ha hab hp hpa hfL hfL1
    hf hf1 hA hA1 hB hB1 hω hω1).trans
      (mul_le_mul_of_nonneg_right (low_coefficient_constant_exponential hdegree) (Real.rpow_nonneg ha.le _))

end Renyi
