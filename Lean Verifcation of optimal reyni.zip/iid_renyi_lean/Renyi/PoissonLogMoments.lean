import Renyi.NormalizationProbability
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Real.Sqrt

/-! Uniform real-order logarithmic moments of a shifted Poisson count. -/
noncomputable section
open MeasureTheory ProbabilityTheory
open scoped NNReal
namespace Renyi

def shiftedCountRatio (lam : ℝ≥0) (j : ℕ) : ℝ := ((j : ℝ) + 1) / lam

theorem shiftedCountRatio_pos {lam : ℝ≥0} (hlam : 0 < (lam : ℝ)) (j : ℕ) :
    0 < shiftedCountRatio lam j := by unfold shiftedCountRatio; positivity

private theorem log_sq_le_four_mul {v : ℝ} (hv : 1 ≤ v) :
    (Real.log v) ^ 2 ≤ 4 * v := by
  have hvpos : 0 < v := lt_of_lt_of_le zero_lt_one hv
  have hlog0 : 0 ≤ Real.log v := Real.log_nonneg hv
  have h := Real.log_le_sub_one_of_pos (Real.sqrt_pos.mpr hvpos)
  rw [Real.log_sqrt hvpos.le] at h
  have hb : Real.log v ≤ 2 * Real.sqrt v := by linarith
  have hs := mul_le_mul hb hb hlog0 (by positivity : 0 ≤ 2 * Real.sqrt v)
  nlinarith [Real.sq_sqrt hvpos.le]

/-- A single deterministic bound controls both tails of the logarithm. -/
theorem rpow_log_sq_uniform_bound {v q : ℝ} (hv : 0 < v) (hq0 : 0 ≤ q) (hq1 : q ≤ 1) :
    v ^ q * (Real.log v) ^ 2 ≤ 4 * (v ^ 2 + v⁻¹) := by
  by_cases hv1 : 1 ≤ v
  · have hp := Real.rpow_le_self_of_one_le hv1 hq1
    have hh := mul_le_mul hp (log_sq_le_four_mul hv1) (sq_nonneg _) hv.le
    nlinarith [inv_nonneg.mpr hv.le]
  · have hvle : v ≤ 1 := (lt_of_not_ge hv1).le
    have hp := Real.rpow_le_one hv.le hvle hq0
    have hinv : 1 ≤ v⁻¹ := (one_le_inv₀ hv).2 hvle
    have hh := log_sq_le_four_mul hinv
    rw [Real.log_inv, neg_sq] at hh
    have hprod := mul_le_mul hp hh (sq_nonneg _) (by norm_num : (0 : ℝ) ≤ 1)
    nlinarith [sq_nonneg v]

theorem rpow_le_one_add_sq {v q : ℝ} (hv : 0 < v) (hq0 : 0 ≤ q) (hq1 : q ≤ 1) :
    v ^ q ≤ 1 + v ^ 2 := by
  by_cases hv1 : 1 ≤ v
  · have hp := Real.rpow_le_self_of_one_le hv1 hq1
    nlinarith [sq_nonneg (v - 1)]
  · have hp := Real.rpow_le_one hv.le (lt_of_not_ge hv1).le hq0
    nlinarith [sq_nonneg v]

/-- The reciprocal-ratio weight shifts the actual Poisson pmf by one. -/
theorem shiftedCountRatio_inverse_pmf (lam : ℝ≥0) (j : ℕ) :
    (shiftedCountRatio lam j)⁻¹ * poissonPMFReal lam j = poissonPMFReal lam (j + 1) := by
  have h := poisson_factorial_shift lam j 1
  simp only [Nat.descFactorial_one, pow_one, Nat.cast_add, Nat.cast_one] at h
  unfold shiftedCountRatio
  rw [inv_div, div_mul_eq_mul_div]
  apply (div_eq_iff (by positivity : (j : ℝ) + 1 ≠ 0)).2
  nlinarith [h]

/-- The reciprocal moment exists, with its exact endpoint correction. -/
theorem shiftedCountRatio_inverse_hasSum (lam : ℝ≥0) :
    HasSum (fun j => (shiftedCountRatio lam j)⁻¹ * poissonPMFReal lam j)
      (1 - Real.exp (-(lam : ℝ))) := by
  simp_rw [shiftedCountRatio_inverse_pmf]
  apply (hasSum_nat_add_iff (f := poissonPMFReal lam) 1).2
  convert poissonPMFRealSum lam using 1
  simp [poissonPMFReal]

/-- The second moment exists with its exact numerator. -/
theorem shiftedCountRatio_sq_hasSum (lam : ℝ≥0) :
    HasSum (fun j => (shiftedCountRatio lam j) ^ 2 * poissonPMFReal lam j)
      (((lam : ℝ) ^ 2 + 3 * (lam : ℝ) + 1) / (lam : ℝ) ^ 2) := by
  have h := (((poisson_nat_second_hasSum lam).add
    ((poisson_factorial_hasSum lam 1).mul_left 2)).add (poissonPMFRealSum lam)).div_const
      ((lam : ℝ) ^ 2)
  convert h using 1
  · funext j
    simp only [Nat.descFactorial_one]
    unfold shiftedCountRatio
    ring
  · ring

theorem shiftedCountRatio_sq_integrable (lam : ℝ≥0) :
    Integrable (fun j => shiftedCountRatio lam j ^ 2) (poissonMeasure lam) := by
  apply poisson_integrable_of_summable
  simpa only [Real.norm_of_nonneg (sq_nonneg _)] using (shiftedCountRatio_sq_hasSum lam).summable

theorem shiftedCountRatio_inverse_integrable (lam : ℝ≥0) :
    Integrable (fun j => (shiftedCountRatio lam j)⁻¹) (poissonMeasure lam) := by
  apply poisson_integrable_of_summable
  have hv : ∀ j, 0 ≤ (shiftedCountRatio lam j)⁻¹ := by
    intro j
    unfold shiftedCountRatio
    positivity
  simpa only [Real.norm_of_nonneg (hv _)] using (shiftedCountRatio_inverse_hasSum lam).summable

theorem shiftedCountRatio_rpow_integrable {lam : ℝ≥0} (hlam : 0 < (lam : ℝ))
    {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q ≤ 1) :
    Integrable (fun j => shiftedCountRatio lam j ^ q) (poissonMeasure lam) := by
  have hdom : Integrable (fun j => 1 + shiftedCountRatio lam j ^ 2) (poissonMeasure lam) :=
    (integrable_const 1).add (shiftedCountRatio_sq_integrable lam)
  apply hdom.mono' (measurable_of_countable _).aestronglyMeasurable
  exact Filter.Eventually.of_forall (fun j => by
    rw [Real.norm_of_nonneg (Real.rpow_nonneg (shiftedCountRatio_pos hlam j).le q)]
    exact rpow_le_one_add_sq (shiftedCountRatio_pos hlam j) hq0 hq1)

theorem shiftedCountRatio_rpow_log_sq_integrable {lam : ℝ≥0} (hlam : 0 < (lam : ℝ))
    {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q ≤ 1) :
    Integrable (fun j => shiftedCountRatio lam j ^ q * (Real.log (shiftedCountRatio lam j)) ^ 2)
      (poissonMeasure lam) := by
  have hdom := ((shiftedCountRatio_sq_integrable lam).add
    (shiftedCountRatio_inverse_integrable lam)).const_mul 4
  apply hdom.mono' (measurable_of_countable _).aestronglyMeasurable
  exact Filter.Eventually.of_forall (fun j => by
    rw [Real.norm_of_nonneg (mul_nonneg
      (Real.rpow_nonneg (shiftedCountRatio_pos hlam j).le q) (sq_nonneg _))]
    exact rpow_log_sq_uniform_bound (shiftedCountRatio_pos hlam j) hq0 hq1)

theorem shiftedCountRatio_sq_integral_le {lam : ℝ≥0} (hlam : 1 ≤ (lam : ℝ)) :
    (∫ j, shiftedCountRatio lam j ^ 2 ∂poissonMeasure lam) ≤ 5 := by
  rw [poisson_integral_eq_tsum lam _ (shiftedCountRatio_sq_integrable lam),
    (shiftedCountRatio_sq_hasSum lam).tsum_eq]
  apply (div_le_iff₀ (sq_pos_of_pos (by linarith : 0 < (lam : ℝ)))).2
  nlinarith [mul_nonneg (by linarith : 0 ≤ (lam : ℝ) - 1) (show 0 ≤ (lam : ℝ) by positivity)]

theorem shiftedCountRatio_inverse_integral_le (lam : ℝ≥0) :
    (∫ j, (shiftedCountRatio lam j)⁻¹ ∂poissonMeasure lam) ≤ 1 := by
  rw [poisson_integral_eq_tsum lam _ (shiftedCountRatio_inverse_integrable lam),
    (shiftedCountRatio_inverse_hasSum lam).tsum_eq]
  linarith [Real.exp_pos (-(lam : ℝ))]

/-- Uniform fractional moment, including both endpoints q=0 and q=1. -/
theorem shiftedCountRatio_rpow_integral_le {lam : ℝ≥0} (hlam : 1 ≤ (lam : ℝ))
    {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q ≤ 1) :
    (∫ j, shiftedCountRatio lam j ^ q ∂poissonMeasure lam) ≤ 6 := by
  have hlam0 : 0 < (lam : ℝ) := by linarith
  have hf := shiftedCountRatio_rpow_integrable hlam0 hq0 hq1
  have hg : Integrable (fun j => 1 + shiftedCountRatio lam j ^ 2) (poissonMeasure lam) :=
    (integrable_const 1).add (shiftedCountRatio_sq_integrable lam)
  have h := integral_mono hf hg (fun j => rpow_le_one_add_sq (shiftedCountRatio_pos hlam0 j) hq0 hq1)
  rw [integral_add (integrable_const 1) (shiftedCountRatio_sq_integrable lam)] at h
  simp only [integral_const, measureReal_univ_eq_one, smul_eq_mul, one_mul] at h
  linarith [shiftedCountRatio_sq_integral_le hlam]

/-- Uniform logarithmic fractional moment, proved for the actual Poisson law.
The explicit constant is independent of intensity and q. -/
theorem shiftedCountRatio_rpow_log_sq_integral_le {lam : ℝ≥0} (hlam : 1 ≤ (lam : ℝ))
    {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q ≤ 1) :
    (∫ j, shiftedCountRatio lam j ^ q * (Real.log (shiftedCountRatio lam j)) ^ 2
      ∂poissonMeasure lam) ≤ 24 := by
  have hlam0 : 0 < (lam : ℝ) := by linarith
  have hf := shiftedCountRatio_rpow_log_sq_integrable hlam0 hq0 hq1
  have hg := ((shiftedCountRatio_sq_integrable lam).add
    (shiftedCountRatio_inverse_integrable lam)).const_mul 4
  have h := integral_mono hf hg (fun j =>
    rpow_log_sq_uniform_bound (shiftedCountRatio_pos hlam0 j) hq0 hq1)
  rw [integral_const_mul] at h
  simp only [Pi.add_apply] at h
  rw [integral_add (shiftedCountRatio_sq_integrable lam)
    (shiftedCountRatio_inverse_integrable lam)] at h
  linarith [shiftedCountRatio_sq_integral_le hlam, shiftedCountRatio_inverse_integral_le lam]

/-- Complete uniform shifted-Poisson moment certificate, with integrability. -/
theorem poisson_shifted_rpow_log_moments :
    ∃ C : ℝ, 0 < C ∧ ∀ lam : ℝ≥0, 1 ≤ (lam : ℝ) →
      ∀ q : ℝ, 0 ≤ q → q ≤ 1 →
        Integrable (fun j => shiftedCountRatio lam j ^ q) (poissonMeasure lam) ∧
        Integrable (fun j => shiftedCountRatio lam j ^ q *
          (Real.log (shiftedCountRatio lam j)) ^ 2) (poissonMeasure lam) ∧
        (∫ j, shiftedCountRatio lam j ^ q ∂poissonMeasure lam) ≤ C ∧
        (∫ j, shiftedCountRatio lam j ^ q * (Real.log (shiftedCountRatio lam j)) ^ 2
          ∂poissonMeasure lam) ≤ C := by
  refine ⟨24, by norm_num, ?_⟩
  intro lam hlam q hq0 hq1
  have hlam0 : 0 < (lam : ℝ) := by linarith
  exact ⟨shiftedCountRatio_rpow_integrable hlam0 hq0 hq1,
    shiftedCountRatio_rpow_log_sq_integrable hlam0 hq0 hq1,
    (shiftedCountRatio_rpow_integral_le hlam hq0 hq1).trans (by norm_num),
    shiftedCountRatio_rpow_log_sq_integral_le hlam hq0 hq1⟩

end Renyi
