import Renyi.DegreeOneCentralCertificate
import Renyi.CoupledOuterLower

/-! Actual canonical degree-one lower certificate. -/
noncomputable section
namespace Renyi.DegreeOneCompletion

/-- The actual high arm and actual primitive together supply the full q*omega floor. -/
theorem coupledProfiles_outer_floor {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 2≤N)
    {γ z M fL f q ω x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hM : 0≤M) (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1)
    (hq : 0<q) (hqf : q<f) (hω : 0≤ω) (hω1 : ω<1)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hY : coupledOuterFloorScale f q*(1-γ)≤(N:ℝ)^2*y) :
    q*ω≤coupledDampedExpression ℓ N γ z M ω fL f x y := by
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hq1 : q<1 := hqf.trans hf1
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  have hu := (lowProfile_range hℓ hγ hfL hfL1 hx hx1).1
  have hH := endpointProfile_range (by omega : 0<N) (by norm_num : 6≤6) (by norm_num : (0:ℝ)<1) hy hy1
  have hYv := (mul_le_mul_of_nonneg_right (le_max_left (raisedFloorScale f q) (endpointProfileFloorScale q)) hd.le).trans hY
  have hYJ := (mul_le_mul_of_nonneg_right (le_max_right (raisedFloorScale f q) (endpointProfileFloorScale q)) hd.le).trans hY
  have hv := highProfile_raised_floor hN hd hd1 hf hf1 hqf hω hω1 hy hy1 hYv
  have hJ := endpointProfile_raised_floor (by omega : 0<N) hd hd1 hq hq1 hy hy1 hYJ
  have hb0 : 0≤overlapB γ z*Real.exp (-M*(1-γ)) := mul_nonneg hc.2.2.1.le (Real.exp_pos _).le
  have hb1 : overlapB γ z*Real.exp (-M*(1-γ))≤1 :=
    (mul_le_of_le_one_left (Real.exp_pos _).le hc.2.2.2.le).trans
      (Real.exp_le_one_iff.mpr (by nlinarith only [hM,hd]))
  have hlow : 0≤(overlapA γ z*Real.exp (-M*γ))*lowProfile ℓ γ fL x*(1-endpointProfile N 6 1 y) :=
    mul_nonneg (mul_nonneg (mul_nonneg hc.1.le (Real.exp_pos _).le) hu) (sub_nonneg.mpr hH.2)
  have hhigh := mul_le_mul_of_nonneg_left hv hb0
  have hprimitive := mul_le_mul_of_nonneg_left hJ
    (mul_nonneg hω (sub_nonneg.mpr hb1))
  unfold coupledDampedExpression
  nlinarith only [hlow,hhigh,hprimitive]

/-- The far-forward region has the full actual lower baseline and a fixed extra gain. -/
theorem coupledProfiles_outer_lower_certificate {ℓ N : ℕ} (hℓ : 0<ℓ) (hN : 2≤N)
    {γ z E Emin M C fL f q x y : ℝ} (hγ : 0<γ) (hγ1 : γ<1) (hz : 0<z) (hz1 : z<1)
    (hEmin : 0<Emin) (hEE : Emin≤E) (hM : 0≤M) (hC : 0≤C)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f<1)
    (hq : Real.exp (-7*Emin/8)<q) (hqf : q<f)
    (hx : 0≤x) (hx1 : x≤1) (hy : 0≤y) (hy1 : y≤1)
    (hY : coupledOuterFloorScale f q*(1-γ)≤(N:ℝ)^2*y) :
    Real.exp (-E)*Real.exp (-C*(γ*(1-γ)))+
      coupledOuterGain q Emin*Real.exp (-E)*min ((N:ℝ)^2*y) 1≤
      coupledDampedExpression ℓ N γ z M (Real.exp (-E/8)) fL f x y := by
  have hE : 0<E := hEmin.trans_le hEE
  have hq0 : 0<q := (Real.exp_pos _).trans hq
  have hω : 0≤Real.exp (-E/8) := (Real.exp_pos _).le
  have hω1 : Real.exp (-E/8)<1 := Real.exp_lt_one_iff.mpr (by linarith only [hE])
  have hfloor := coupledProfiles_outer_floor hℓ hN hγ hγ1 hz hz1 hM hfL hfL1 hf hf1 hq0 hqf hω hω1 hx hx1 hy hy1 hY
  have hg := coupledOuterGain_pos hq
  have he := Real.exp_le_exp.mpr (show 7*Emin/8≤7*E/8 by linarith only [hEE])
  have hratio := mul_le_mul_of_nonneg_left he hq0.le
  have hratio' := mul_le_mul_of_nonneg_right hratio (Real.exp_pos (-E)).le
  have hid : (q*Real.exp (7*E/8))*Real.exp (-E)=q*Real.exp (-E/8) := by
    rw [mul_assoc,←Real.exp_add]
    congr 2
    ring
  rw [hid] at hratio'
  have hbase : Real.exp (-E)*Real.exp (-C*(γ*(1-γ)))≤Real.exp (-E) :=
    mul_le_of_le_one_right (Real.exp_pos (-E)).le
    (Real.exp_le_one_iff.mpr (by nlinarith only [mul_nonneg hC (mul_nonneg hγ.le (show 0≤1-γ by linarith only [hγ1]))]))
  have hgain := mul_le_of_le_one_right (mul_nonneg hg.le (Real.exp_pos (-E)).le) (min_le_right ((N:ℝ)^2*y) 1)
  unfold coupledOuterGain at *
  nlinarith only [hfloor,hratio',hbase,hgain,mul_nonneg hg.le (Real.exp_pos (-E)).le]


end Renyi.DegreeOneCompletion
