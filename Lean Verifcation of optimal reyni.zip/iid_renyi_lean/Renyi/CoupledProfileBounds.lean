import Renyi.CoupledProfiles
import Renyi.OverlapEnvelope

/-! Quantitative bounds for the actual coupled profiles. -/
noncomputable section
open Set
namespace Renyi

def coupledProfileConstant : ℝ := Real.log 24 + 13

lemma exp_neg_le_linear_half {s : ℝ} (hs : 0 ≤ s) (hs1 : s ≤ 1) :
    Real.exp (-s) ≤ 1-s/2 := by
  rw [Real.exp_neg, inv_eq_one_div]
  calc
    _ ≤ 1/(1+s) := one_div_le_one_div_of_le (by linarith) (by simpa [add_comm] using Real.add_one_le_exp s)
    _ ≤ 1-s/2 := by
      apply (div_le_iff₀ (by linarith : 0<1+s)).mpr
      nlinarith [mul_nonneg hs (sub_nonneg.mpr hs1)]

/-- Evaluate the actual normalizing supremum at `s/(24N²)`; the exponent error is O(s). -/
theorem coupledNormalizer_sharp_lower {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s b : ℝ} {H : ℝ → ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hb : b < 1)
    (hH : ∀ x ∈ Icc (0:ℝ) 1, 0 ≤ H x ∧ H x ≤ b) :
    (s/(24*(N:ℝ)^2))^s * Real.exp (-s) ≤
      coupledNormalizer s (endpointKernel N d) H := by
  let x : ℝ := s/(24*(N:ℝ)^2)
  have hn : (1:ℝ) ≤ N := by exact_mod_cast hN
  have hdenN : 0 < 24*(N:ℝ)^2 := by positivity
  have hx : 0 < x := div_pos hs hdenN
  have hx1 : x ≤ 1 := by
    apply (div_le_one hdenN).mpr
    nlinarith
  have hid : 24*(N:ℝ)^2*x=s := by dsimp [x]; field_simp
  have hK := fun y (hy : y ∈ Icc (0:ℝ) 1) =>
    And.intro (endpointKernel_nonneg N d y) (endpointKernel_le_one hN d hy.1 hy.2)
  have hden : 0 < 1-H x := by have := (hH x ⟨hx.le,hx1⟩).2; linarith
  have hnum : 0 ≤ x^s*endpointKernel N d x :=
    mul_nonneg (Real.rpow_nonneg hx.le s) (endpointKernel_nonneg N d x)
  have hratio : x^s*endpointKernel N d x ≤ x^s*endpointKernel N d x/(1-H x) := by
    apply (le_div_iff₀ hden).mpr
    nlinarith [mul_nonneg hnum (hH x ⟨hx.le,hx1⟩).1]
  have hext : x^s*endpointKernel N d x ≤ coupledNormalizer s (endpointKernel N d) H :=
    hratio.trans (le_csSup (coupledNormalizer_bdd hs.le hb hK (fun y hy => (hH y hy).2))
      ⟨x, ⟨hx.le,hx1⟩, rfl⟩)
  have hk := endpointKernel_linear_deficit hN hd hx.le hx1
  have hkernel : Real.exp (-s) ≤ endpointKernel N d x :=
    (exp_neg_le_linear_half hs.le hs1).trans (by linarith)
  exact (mul_le_mul_of_nonneg_left hkernel (Real.rpow_nonneg hx.le s)).trans hext

lemma coupled_sharp_scale_identity {N : ℕ} (hN : 0 < N) {s x : ℝ}
    (hs : 0 < s) (hx : 0 ≤ x) :
    (Real.exp ((Real.log 24+1)*s)*((N:ℝ)^2*x/s)^s) *
      ((s/(24*(N:ℝ)^2))^s*Real.exp (-s)) = x^s := by
  have hn : 0 < (N:ℝ) := by exact_mod_cast hN
  have hq : 0 ≤ s/(24*(N:ℝ)^2) := by positivity
  have hy : 0 ≤ (N:ℝ)^2*x/s := by positivity
  have heq : (N:ℝ)^2*x/s * (s/(24*(N:ℝ)^2)) = x/24 := by field_simp
  calc
    _ = (Real.exp ((Real.log 24+1)*s)*Real.exp (-s)) *
        (((N:ℝ)^2*x/s)^s*(s/(24*(N:ℝ)^2))^s) := by ring
    _ = Real.exp (Real.log 24*s) * (x/24)^s := by
      rw [←Real.exp_add, ←Real.mul_rpow hy hq, heq]
      congr 2; ring
    _ = (24:ℝ)^s*(x/24)^s := by rw [Real.rpow_def_of_pos (by norm_num : (0:ℝ)<24)]
    _ = x^s := by rw [←Real.mul_rpow (by norm_num : (0:ℝ)≤24) (by positivity), mul_div_cancel₀ _ (by norm_num : (24:ℝ)≠0)]

theorem coupled_bump_upper {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s b x : ℝ} {H : ℝ → ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hb : b < 1)
    (hH : ∀ x ∈ Icc (0:ℝ) 1, 0 ≤ H x ∧ H x ≤ b)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    x^s*endpointKernel N d x / coupledNormalizer s (endpointKernel N d) H ≤
      Real.exp ((Real.log 24+1)*s)*((N:ℝ)^2*x/s)^s := by
  have hK := fun y (hy : y ∈ Icc (0:ℝ) 1) =>
    And.intro (endpointKernel_nonneg N d y) (endpointKernel_le_one hN d hy.1 hy.2)
  have ha := coupledNormalizer_pos hs.le hb hK (fun y hy => (hH y hy).2)
    (endpointKernel_positive_witness hN hd)
  have hl := coupledNormalizer_sharp_lower hN hd hs hs1 hb hH
  apply (div_le_iff₀ ha).mpr
  have hm := mul_le_mul_of_nonneg_left hl
    (show 0 ≤ Real.exp ((Real.log 24+1)*s)*((N:ℝ)^2*x/s)^s by positivity)
  rw [coupled_sharp_scale_identity hN hs hx] at hm
  exact (mul_le_of_le_one_right (Real.rpow_nonneg hx s) (endpointKernel_le_one hN d hx hx1)).trans hm

/-- Global sharp upper bound for a normalized actual profile and an integral shoulder. -/
theorem coupledProfile_upper_power {N d : ℕ} (hN : 0 < N) (hd : d ≤ 6)
    {s b x : ℝ} {H : ℝ → ℝ} (hs : 0 < s) (hs1 : s ≤ 1) (hb : b < 1)
    (hH : ∀ x ∈ Icc (0:ℝ) 1, 0 ≤ H x ∧ H x ≤ b)
    (hHJ : H x ≤ endpointProfile N d s x*(1-endpointKernel N d x))
    (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    coupledProfile s (endpointKernel N d) H x ≤
      Real.exp (coupledProfileConstant*s)*((N:ℝ)^2*x/s)^s := by
  let y : ℝ := (N:ℝ)^2*x
  let r : ℝ := (y/s)^s
  let E : ℝ := Real.exp ((Real.log 24+1)*s)
  have hy : 0 ≤ y := by dsimp [y]; positivity
  have hr : 0 ≤ r := Real.rpow_nonneg (div_nonneg hy hs.le) s
  have hE : 0 < E := Real.exp_pos _
  have hK := fun z (hz : z ∈ Icc (0:ℝ) 1) =>
    And.intro (endpointKernel_nonneg N d z) (endpointKernel_le_one hN d hz.1 hz.2)
  by_cases hys : y ≤ s
  · have hratio : y ≤ y/s := by
      apply (le_div_iff₀ hs).mpr
      nlinarith [mul_nonneg hy (sub_nonneg.mpr hs1)]
    have hyr : y^s ≤ r := Real.rpow_le_rpow hy hratio hs.le
    have he12 : Real.exp ((Real.log 12+1)*s) ≤ E := by
      apply Real.exp_le_exp.mpr
      have hl : Real.log 12 ≤ Real.log 24 := Real.log_le_log (by norm_num) (by norm_num)
      nlinarith
    have hj : endpointProfile N d s x ≤ E*r :=
      (endpointProfile_upper_power hN hd hs hx hx1).trans
        (mul_le_mul he12 hyr (Real.rpow_nonneg hy s) hE.le)
    have hk := endpointKernel_linear_deficit hN hd hx hx1
    have hdef : 1-endpointKernel N d x ≤ 12*s := by dsimp [y] at hys; linarith
    have hj0 := (endpointProfile_range hN hd hs hx hx1).1
    have hh : H x ≤ E*r*(12*s) :=
      hHJ.trans (mul_le_mul hj hdef (sub_nonneg.mpr (endpointKernel_le_one hN d hx hx1))
        (mul_nonneg hE.le hr))
    have hbump := coupled_bump_upper hN hd hs hs1 hb hH hx hx1
    have hsum : coupledProfile s (endpointKernel N d) H x ≤ (1+12*s)*(E*r) := by
      unfold coupledProfile
      change x^s*endpointKernel N d x/coupledNormalizer s (endpointKernel N d) H ≤ E*r at hbump
      nlinarith
    have hexp := Real.add_one_le_exp (12*s)
    have heq : Real.exp (12*s)*E=Real.exp (coupledProfileConstant*s) := by
      dsimp [E, coupledProfileConstant]
      rw [←Real.exp_add]
      congr 1; ring
    calc
      _ ≤ (1+12*s)*(E*r) := hsum
      _ ≤ Real.exp (12*s)*(E*r) := mul_le_mul_of_nonneg_right (by linarith) (mul_nonneg hE.le hr)
      _ = _ := by rw [←mul_assoc, heq]
  · have hu := (coupledProfile_range hs.le hb hK hH (endpointKernel_positive_witness hN hd) ⟨hx,hx1⟩).2
    have hy1 : 1 ≤ y/s := (le_div_iff₀ hs).mpr (by linarith)
    have hr1 : 1 ≤ r := Real.one_le_rpow hy1 hs.le
    have hC : 0 ≤ coupledProfileConstant := by
      dsimp [coupledProfileConstant]
      have := Real.log_nonneg (by norm_num : (1:ℝ)≤24)
      linarith
    have he1 : 1 ≤ Real.exp (coupledProfileConstant*s) := Real.one_le_exp (mul_nonneg hC hs.le)
    exact hu.trans (one_le_mul_of_one_le_of_one_le he1 hr1)

theorem lowProfile_upper_power {N : ℕ} (hN : 0 < N) {s f x : ℝ}
    (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f < 1)
    (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    lowProfile N s f x ≤ Real.exp (coupledProfileConstant*s)*((N:ℝ)^2*x/s)^s := by
  apply coupledProfile_upper_power hN (by norm_num) hs hs1 hf1
    (fun _z hz => lowShoulder_range hN hs hf hz.1 hz.2) _ hx hx1
  have hj := (endpointProfile_range hN (by norm_num : 2≤6) hs hx hx1).1
  have hk := endpointKernel_le_one hN 2 hx hx1
  unfold lowShoulder
  have hmul := mul_le_of_le_one_left (mul_nonneg hj (sub_nonneg.mpr hk)) hf1.le
  nlinarith

theorem highProfile_upper_power {N : ℕ} (hN : 0 < N) {s f ω x : ℝ}
    (hs : 0 < s) (hs1 : s ≤ 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hω : 0 ≤ ω) (hω1 : ω < 1) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    highProfile N s f ω x ≤ Real.exp (coupledProfileConstant*s)*((N:ℝ)^2*x/s)^s := by
  apply coupledProfile_upper_power hN (by norm_num) hs hs1 hω1
    (fun _z hz => highShoulder_range hN hs hf hf1 hω hz.1 hz.2) _ hx hx1
  have hj := (endpointProfile_range hN (by norm_num : 6≤6) hs hx hx1).1
  have hk := endpointKernel_le_one hN 6 hx hx1
  have hw := highShoulderWeight_range hN hf hf1 hx hx1
  have hbase : 0 ≤ ω*endpointProfile N 6 s x*(1-endpointKernel N 6 x) :=
    mul_nonneg (mul_nonneg hω hj) (sub_nonneg.mpr hk)
  unfold highShoulder
  calc
    _ ≤ ω*endpointProfile N 6 s x*(1-endpointKernel N 6 x) := mul_le_of_le_one_right hbase hw.2
    _ = ω*(endpointProfile N 6 s x*(1-endpointKernel N 6 x)) := by ring
    _ ≤ _ := mul_le_of_le_one_left (mul_nonneg hj (sub_nonneg.mpr hk)) hω1.le

lemma coupled_power_product_identity {γ Z Y : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hZ : 0 ≤ Z) (hY : 0 ≤ Y) :
    (Real.exp (coupledProfileConstant*γ)*(Z/γ)^γ)^(1-γ) *
      (Real.exp (coupledProfileConstant*(1-γ))*(Y/(1-γ))^(1-γ))^γ =
    Real.exp (2*coupledProfileConstant*(γ*(1-γ))) *
      (Z*Y/(γ*(1-γ)))^(γ*(1-γ)) := by
  have hd : 0 < 1-γ := by linarith
  have hZq := div_nonneg hZ hγ.le
  have hYq := div_nonneg hY hd.le
  rw [Real.mul_rpow (Real.exp_pos _).le (Real.rpow_nonneg hZq γ),
    Real.mul_rpow (Real.exp_pos _).le (Real.rpow_nonneg hYq (1-γ)),
    ←Real.exp_mul, ←Real.exp_mul, ←Real.rpow_mul hZq, ←Real.rpow_mul hYq,
    show (1-γ)*γ=γ*(1-γ) by ring]
  calc
    _ = (Real.exp (coupledProfileConstant*γ*(1-γ))*Real.exp (coupledProfileConstant*(1-γ)*γ)) *
        ((Z/γ)^(γ*(1-γ))*(Y/(1-γ))^(γ*(1-γ))) := by ring
    _ = _ := by
      rw [←Real.exp_add, ←Real.mul_rpow hZq hYq]
      have hq : Z/γ*(Y/(1-γ))=Z*Y/(γ*(1-γ)) := by field_simp
      rw [hq]
      congr 2; ring

/-- The exact capacity inequality yields the scalar product constraint. -/
lemma coupled_power_product_le {γ Z Y z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hZ : 0 ≤ Z) (hY : 0 ≤ Y) (hz : 0 < z)
    (hcap : Z*Y ≤ Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    (Real.exp (coupledProfileConstant*γ)*(Z/γ)^γ)^(1-γ) *
      (Real.exp (coupledProfileConstant*(1-γ))*(Y/(1-γ))^(1-γ))^γ ≤ z := by
  let h : ℝ := γ*(1-γ)
  have hh : 0 < h := mul_pos hγ (by linarith)
  have hquot : Z*Y/h ≤ Real.exp (-2*coupledProfileConstant)*z^(1/h) := by
    apply (div_le_iff₀ hh).mpr
    change Z*Y ≤ Real.exp (-2*coupledProfileConstant)*h*z^(1/h) at hcap
    nlinarith
  have hr := Real.rpow_le_rpow (div_nonneg (mul_nonneg hZ hY) hh.le) hquot hh.le
  have heq : (Real.exp (-2*coupledProfileConstant)*z^(1/h))^h =
      Real.exp (-2*coupledProfileConstant*h)*z := by
    rw [Real.mul_rpow (Real.exp_pos _).le (Real.rpow_nonneg hz.le _), ←Real.exp_mul,
      ←Real.rpow_mul hz.le, one_div_mul_cancel hh.ne', Real.rpow_one]
  rw [heq] at hr
  rw [coupled_power_product_identity hγ hγ1 hZ hY]
  have hm := mul_le_mul_of_nonneg_left hr (Real.exp_pos (2*coupledProfileConstant*h)).le
  have he : Real.exp (2*coupledProfileConstant*h)*
      (Real.exp (-2*coupledProfileConstant*h)*z)=z := by
    rw [←mul_assoc, ←Real.exp_add]
    have he0 : 2*coupledProfileConstant*h + -2*coupledProfileConstant*h=0 := by ring
    rw [he0, Real.exp_zero, one_mul]
  exact hm.trans_eq he

/-- Product feasibility for the two actual profiles, with no profile-certificate premise. -/
theorem coupledProfiles_product_le {ℓ N : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    {γ fL f ω x y z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hω : 0 ≤ ω) (hω1 : ω < 1) (hx : 0 ≤ x) (hx1 : x ≤ 1)
    (hy : 0 ≤ y) (hy1 : y ≤ 1) (hz : 0 < z)
    (hcap : ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    (lowProfile ℓ γ fL x)^(1-γ) * (highProfile N (1-γ) f ω y)^γ ≤ z := by
  have hd : 0 < 1-γ := by linarith
  have hu := lowProfile_upper_power hℓ hγ hγ1.le hfL hfL1 hx hx1
  have hv := highProfile_upper_power hN hd (by linarith) hf hf1 hω hω1 hy hy1
  have hu0 := (lowProfile_range hℓ hγ hfL hfL1 hx hx1).1
  have hv0 := (highProfile_range hN hd hf hf1 hω hω1 hy hy1).1
  have hup := Real.rpow_le_rpow hu0 hu hd.le
  have hvp := Real.rpow_le_rpow hv0 hv hγ.le
  have hp := mul_le_mul hup hvp (Real.rpow_nonneg hv0 γ)
    (Real.rpow_nonneg (by positivity) (1-γ))
  exact hp.trans (coupled_power_product_le hγ hγ1 (by positivity) (by positivity) hz hcap)

/-- The manuscript's exact scalar upper envelope now applies to the actual profiles. -/
theorem coupledProfiles_scalar_upper {ℓ N : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    {γ fL f ω x y z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hω : 0 ≤ ω) (hω1 : ω < 1) (hx : 0 ≤ x) (hx1 : x ≤ 1)
    (hy : 0 ≤ y) (hy1 : y ≤ 1) (hz : 0 < z) (hz1 : z < 1)
    (hcap : ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y) ≤
      Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ)))) :
    overlapA γ z*lowProfile ℓ γ fL x + overlapB γ z*highProfile N (1-γ) f ω y ≤ 1 := by
  apply (overlap_maximum hγ hγ1 hz hz1).1
    (lowProfile ℓ γ fL x) (lowProfile_range hℓ hγ hfL hfL1 hx hx1)
    (highProfile N (1-γ) f ω y) (highProfile_range hN (by linarith) hf hf1 hω hω1 hy hy1)
  exact coupledProfiles_product_le hℓ hN hγ hγ1 hfL hfL1 hf hf1 hω hω1 hx hx1 hy hy1 hz hcap

/-- Exact reciprocal arguments cancel, converting the source capacity equation into feasibility. -/
theorem coupledProfiles_capacity_product {ℓ N m L : ℕ} (hℓ : 0 < ℓ) (hN : 0 < N)
    (hℓm : ℓ ≤ m) (hNL : N ≤ L)
    {γ fL f ω a b p z : ℝ} (hγ : 0 < γ) (hγ1 : γ < 1)
    (hfL : 0 ≤ fL) (hfL1 : fL < 1) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (hω : 0 ≤ ω) (hω1 : ω < 1) (ha : 0 < a) (hap : a ≤ p) (hpb : p ≤ b)
    (hz : 0 < z)
    (hcapacity : a ≤ Real.exp (-2*coupledProfileConstant)*b*(γ*(1-γ))*z^(1/(γ*(1-γ))) /
      ((m:ℝ)^2*(L:ℝ)^2)) :
    (lowProfile ℓ γ fL (a/p))^(1-γ) * (highProfile N (1-γ) f ω (p/b))^γ ≤ z := by
  have hp := ha.trans_le hap
  have hb := hp.trans_le hpb
  have hm : 0 < (m:ℝ) := by exact_mod_cast hℓ.trans_le hℓm
  have hL : 0 < (L:ℝ) := by exact_mod_cast hN.trans_le hNL
  have hcap := (le_div_iff₀ (mul_pos (sq_pos_of_pos hm) (sq_pos_of_pos hL))).mp hcapacity
  have hℓsq : (ℓ:ℝ)^2 ≤ (m:ℝ)^2 := pow_le_pow_left₀ (Nat.cast_nonneg ℓ) (by exact_mod_cast hℓm) 2
  have hNsq : (N:ℝ)^2 ≤ (L:ℝ)^2 := pow_le_pow_left₀ (Nat.cast_nonneg N) (by exact_mod_cast hNL) 2
  have hdeg := mul_le_mul hℓsq hNsq (sq_nonneg (N:ℝ)) (sq_nonneg (m:ℝ))
  apply coupledProfiles_product_le hℓ hN hγ hγ1 hfL hfL1 hf hf1 hω hω1
    (div_nonneg ha.le hp.le) ((div_le_one hp).mpr hap)
    (div_nonneg hp.le hb.le) ((div_le_one hb).mpr hpb) hz
  calc
    _ = ((ℓ:ℝ)^2*(N:ℝ)^2)*(a/b) := by field_simp
    _ ≤ ((m:ℝ)^2*(L:ℝ)^2)*(a/b) := mul_le_mul_of_nonneg_right hdeg (div_nonneg ha.le hb.le)
    _ ≤ _ := by
      rw [←mul_div_assoc]
      apply (div_le_iff₀ hb).mpr
      nlinarith

end Renyi
