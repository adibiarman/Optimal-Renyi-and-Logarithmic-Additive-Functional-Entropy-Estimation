import Renyi.Model
import Renyi.PoissonMarking
import Renyi.Pilot
import Renyi.IntegerScalar

/-!
# Returning from Poissonized samples to a fixed iid sample

The estimator constructed here draws its own independent Poisson sample size,
uses a prefix of the supplied iid observations when possible, and returns a
fixed fallback otherwise. Its output is an actual probability measure, as
required by `Model.Estimator`.
-/

noncomputable section
open scoped BigOperators ENNReal NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

def simplexNN {k : ℕ} (p : Simplex k) (i : Fin k) : ℝ≥0 := ⟨p.mass i, p.nonneg i⟩

@[simp] theorem simplexNN_coe {k : ℕ} (p : Simplex k) (i : Fin k) :
    (simplexNN p i : ℝ) = p.mass i := rfl

theorem simplexNN_sum {k : ℕ} (p : Simplex k) : ∑ i, simplexNN p i = 1 := by
  apply NNReal.coe_injective
  simpa using p.normalized

def samplePrefix {k n m : ℕ} (h : n ≤ m) (x : Sample k m) : Sample k n :=
  fun i => x (Fin.castLE h i)

def truncatedSampleOutput {k m : ℕ} (f : PoissonMarkedSample (Fin k) → ℝ)
    (fallback : ℝ) (x : Sample k m) (q : ℕ) : ℝ :=
  if h : q ≤ m then f ⟨q, samplePrefix h x⟩ else fallback

/-- Each fixed sample is mapped to the distribution of the randomized answer. -/
def poissonToIIDEstimator {k m : ℕ} (b : ℝ≥0)
    (f : PoissonMarkedSample (Fin k) → ℝ) (fallback : ℝ) : Estimator k m :=
  fun x => ⟨((poissonPMF b).map (truncatedSampleOutput f fallback x)).toMeasure,
    inferInstance⟩

def truncatedPoissonLaw (b : ℝ≥0) (K : ℕ → PMF ℝ) (fallback : ℝ) (m : ℕ) : PMF ℝ :=
  (poissonPMF b).bind (fun q => if q ≤ m then K q else PMF.pure fallback)

/-- Truncating the random sample size costs at most its actual Poisson tail. -/
theorem truncatedPoissonLaw_event_le (b : ℝ≥0) (K : ℕ → PMF ℝ)
    (fallback : ℝ) (m : ℕ) {B : Set ℝ} (hB : MeasurableSet B) :
    (truncatedPoissonLaw b K fallback m).toMeasure B ≤
      ((poissonPMF b).bind K).toMeasure B +
        (poissonPMF b).toMeasure {q : ℕ | m < q} := by
  unfold truncatedPoissonLaw
  rw [PMF.toMeasure_bind_apply _ _ _ hB, PMF.toMeasure_bind_apply _ _ _ hB,
    PMF.toMeasure_apply_eq_tsum]
  have ht : (∑' q : ℕ, ({q : ℕ | m < q}).indicator (poissonPMF b) q) =
      ∑' q : ℕ, poissonPMF b q * (if m < q then 1 else 0) := by
    apply tsum_congr
    intro q
    by_cases hq : m < q <;> simp [hq]
  rw [ht, ← ENNReal.tsum_add]
  apply ENNReal.tsum_le_tsum
  intro q
  by_cases hq : q ≤ m
  · simp [hq, not_lt.mpr hq]
  · have hp : (PMF.pure fallback).toMeasure B ≤ (1 : ℝ≥0∞) := prob_le_one
    have h := mul_le_mul_left' hp (poissonPMF b q)
    simpa [hq, Nat.lt_of_not_ge hq] using
      h.trans (le_add_of_nonneg_left (zero_le (poissonPMF b q * (K q).toMeasure B)))

theorem truncatedPoissonLaw_real_event_le (b : ℝ≥0) (K : ℕ → PMF ℝ)
    (fallback : ℝ) (m : ℕ) {B : Set ℝ} (hB : MeasurableSet B) :
    (truncatedPoissonLaw b K fallback m).toMeasure.real B ≤
      ((poissonPMF b).bind K).toMeasure.real B +
        (poissonPMF b).toMeasure.real {q : ℕ | m < q} := by
  have h := ENNReal.toReal_mono (by finiteness)
    (truncatedPoissonLaw_event_le b K fallback m hB)
  simpa only [ENNReal.toReal_add (measure_ne_top _ _) (measure_ne_top _ _)] using h

/-- The abstract model's finite sum is exactly the risk of the PMF mixture. -/
theorem errorProbability_of_pmf {k m : ℕ} (p : Simplex k) (alpha eps : ℝ)
    (G : Sample k m → PMF ℝ) :
    errorProbability p alpha eps (fun x => ⟨(G x).toMeasure, inferInstance⟩) =
      ((iidMarkPMF (simplexNN p) (simplexNN_sum p) m).bind G).toMeasure.real
        {z : ℝ | eps < |z - entropy p alpha|} := by
  have hB : MeasurableSet {z : ℝ | eps < |z - entropy p alpha|} :=
    measurableSet_lt measurable_const (by fun_prop)
  unfold errorProbability Measure.real
  rw [PMF.toMeasure_bind_apply _ _ _ hB, tsum_fintype, ENNReal.toReal_sum]
  · apply Finset.sum_congr rfl
    intro x _
    rw [ENNReal.toReal_mul]
    have hm : (iidMarkPMF (simplexNN p) (simplexNN_sum p) m x).toReal =
        iidMass p m x := by
      simp [iidMarkPMF_apply, ENNReal.toReal_prod, iidMass, simplexNN]
    rw [hm]
    rfl
  · intro x _
    exact ENNReal.mul_ne_top (PMF.apply_ne_top _ _) (measure_ne_top _ _)

theorem poisson_tail_real_summable (b : ℝ≥0) (m : ℕ) :
    Summable (fun q : ℕ => if m < q then poissonPMFReal b q else 0) := by
  apply (poissonPMFRealSum b).summable.of_nonneg_of_le
  · intro q; split_ifs <;> simp [poissonPMFReal_nonneg]
  · intro q; split_ifs <;> simp [poissonPMFReal_nonneg]

theorem poisson_tail_real_eq_tsum (b : ℝ≥0) (m : ℕ) :
    (poissonPMF b).toMeasure.real {q : ℕ | m < q} =
      ∑' q : ℕ, if m < q then poissonPMFReal b q else 0 := by
  unfold Measure.real
  rw [PMF.toMeasure_apply_eq_tsum]
  have hnon : ∀ q : ℕ, 0 ≤ (if m < q then poissonPMFReal b q else 0) := by
    intro q; split_ifs <;> simp [poissonPMFReal_nonneg]
  have heq : (∑' q : ℕ, ({q : ℕ | m < q}).indicator (poissonPMF b) q) =
      ENNReal.ofReal (∑' q : ℕ, if m < q then poissonPMFReal b q else 0) := by
    rw [ENNReal.ofReal_tsum_of_nonneg hnon (poisson_tail_real_summable b m)]
    apply tsum_congr
    intro q
    by_cases hq : m < q <;> simp [hq, poissonPMF]
    rfl
  rw [heq, ENNReal.toReal_ofReal (tsum_nonneg hnon)]

/-- Exponential Markov, proved by comparing each Poisson mass. -/
theorem poisson_tail_exponential (b : ℝ≥0) (m : ℕ) {t : ℝ} (ht : 0 ≤ t) :
    (poissonPMF b).toMeasure.real {q : ℕ | m < q} ≤
      Real.exp (-t * m + (b : ℝ) * (Real.exp t - 1)) := by
  rw [poisson_tail_real_eq_tsum]
  have hg := (poisson_exp_hasSum b t).mul_left (Real.exp (-t * m))
  have hbound (q : ℕ) :
      (if m < q then poissonPMFReal b q else 0) ≤
        Real.exp (-t * m) * (Real.exp (t * q) * poissonPMFReal b q) := by
    split_ifs with hq
    · have hqr : (m : ℝ) ≤ q := by exact_mod_cast Nat.le_of_lt hq
      have he : 1 ≤ Real.exp (t * ((q : ℝ) - m)) :=
        Real.one_le_exp_iff.mpr (mul_nonneg ht (sub_nonneg.mpr hqr))
      have hh := mul_le_mul_of_nonneg_right he (poissonPMFReal_nonneg (r := b) (n := q))
      have hid : Real.exp (-t * m) * Real.exp (t * q) =
          Real.exp (t * ((q : ℝ) - m)) := by
        rw [← Real.exp_add]
        congr 1
        ring
      simpa only [one_mul, ← hid, mul_assoc] using hh
    · exact mul_nonneg (Real.exp_pos _).le
        (mul_nonneg (Real.exp_pos _).le poissonPMFReal_nonneg)
  have h := (poisson_tail_real_summable b m).tsum_le_tsum hbound hg.summable
  rw [hg.tsum_eq, ← Real.exp_add] at h
  exact h

/-- The manuscript's upper Poisson tail, with no Chernoff bound assumed. -/
theorem poisson_tail_twice_mean (b : ℝ≥0) {m : ℕ} (hm : 2 * (b : ℝ) ≤ m) :
    (poissonPMF b).toMeasure.real {q : ℕ | m < q} ≤ Real.exp (-(b : ℝ) / 3) := by
  have hlog : (2 : ℝ) / 3 ≤ Real.log 2 := by
    have h := Real.le_log_one_add_of_nonneg (by norm_num : (0 : ℝ) ≤ 1)
    norm_num at h ⊢
    exact h
  have ht : 0 ≤ Real.log (2 : ℝ) := by positivity
  apply (poisson_tail_exponential b m ht).trans
  apply Real.exp_le_exp.mpr
  rw [Real.exp_log (by norm_num : (0 : ℝ) < 2)]
  have h1 := mul_le_mul_of_nonneg_left hm ht
  have h2 := mul_le_mul_of_nonneg_right hlog b.coe_nonneg
  nlinarith

theorem poisson_tail_ceil_twice (b : ℝ≥0) :
    (poissonPMF b).toMeasure.real {q : ℕ | ⌈2 * (b : ℝ)⌉₊ < q} ≤
      Real.exp (-(b : ℝ) / 3) :=
  poisson_tail_twice_mean b (Nat.le_ceil _)

/-- Swapping the independent choices and taking iid prefixes identifies the
entire distribution of the randomized fixed-sample answer. -/
theorem poissonToIID_output_law {k m : ℕ} (b : ℝ≥0) (p : Simplex k)
    (f : PoissonMarkedSample (Fin k) → ℝ) (fallback : ℝ) :
    (iidMarkPMF (simplexNN p) (simplexNN_sum p) m).bind
      (fun x => (poissonPMF b).map (truncatedSampleOutput f fallback x)) =
      truncatedPoissonLaw b
        (fun q => (iidMarkPMF (simplexNN p) (simplexNN_sum p) q).map
          (fun x => f ⟨q, x⟩)) fallback m := by
  unfold truncatedPoissonLaw
  change (iidMarkPMF (simplexNN p) (simplexNN_sum p) m).bind
      (fun x => (poissonPMF b).bind
        (fun q => PMF.pure (truncatedSampleOutput f fallback x q))) = _
  rw [PMF.bind_comm]
  congr 1
  funext q
  by_cases hq : q ≤ m
  · rw [if_pos hq]
    change (iidMarkPMF (simplexNN p) (simplexNN_sum p) m).map
        (fun x => truncatedSampleOutput f fallback x q) = _
    have heq : (fun x : Sample k m => truncatedSampleOutput f fallback x q) =
        (fun x => f ⟨q, samplePrefix hq x⟩) := by
      funext x
      simp [truncatedSampleOutput, hq]
    rw [heq]
    change (iidMarkPMF (simplexNN p) (simplexNN_sum p) m).map
      ((fun x : Sample k q => f ⟨q, x⟩) ∘ samplePrefix hq) = _
    rw [← PMF.map_comp]
    rw [show (iidMarkPMF (simplexNN p) (simplexNN_sum p) m).map (samplePrefix hq) =
      iidMarkPMF (simplexNN p) (simplexNN_sum p) q from
        iidMarkPMF_prefix (simplexNN p) (simplexNN_sum p) hq]
  · simp [truncatedSampleOutput, hq, PMF.bind_const]

/-- The full risk transfer to the model: only the overflow event is lost. -/
theorem poissonToIID_error_le {k m : ℕ} (b : ℝ≥0) (p : Simplex k)
    (alpha eps : ℝ) (f : PoissonMarkedSample (Fin k) → ℝ) (fallback : ℝ) :
    errorProbability p alpha eps (poissonToIIDEstimator (m := m) b f fallback) ≤
      (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure.real
        {x | eps < |f x - entropy p alpha|} +
      (poissonPMF b).toMeasure.real {q : ℕ | m < q} := by
  have hB : MeasurableSet {z : ℝ | eps < |z - entropy p alpha|} :=
    measurableSet_lt measurable_const (by fun_prop)
  unfold poissonToIIDEstimator
  rw [errorProbability_of_pmf, poissonToIID_output_law]
  have h := truncatedPoissonLaw_real_event_le b
    (fun q => (iidMarkPMF (simplexNN p) (simplexNN_sum p) q).map
      (fun x => f ⟨q, x⟩)) fallback m hB
  have hout : ((poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).map f) =
      (poissonPMF b).bind (fun q =>
        (iidMarkPMF (simplexNN p) (simplexNN_sum p) q).map (fun x => f ⟨q, x⟩)) := by
    rw [poissonMarkedSamplePMF, PMF.map_bind]
    simp only [PMF.map_comp, Function.comp_def]
  rw [← hout] at h
  have hm := PMF.toMeasure_map_apply f
    (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)) _
    (measurable_of_countable f) hB
  change _ ≤ _ + _
  simpa only [Measure.real, hm] using h

/-- An actual randomized estimator establishes Achievable after truncation. -/
theorem achievable_of_poissonized_error {k m : ℕ} (b : ℝ≥0)
    (alpha eps delta : ℝ) (f : PoissonMarkedSample (Fin k) → ℝ)
    (herror : ∀ p : Simplex k,
      (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure.real
        {x | eps < |f x - entropy p alpha|} ≤ delta)
    (hbudget : delta + (poissonPMF b).toMeasure.real {q : ℕ | m < q} ≤ 1 / 3) :
    Achievable k m alpha eps := by
  refine ⟨poissonToIIDEstimator b f 0, ?_⟩
  intro p
  exact (poissonToIID_error_le b p alpha eps f 0).trans
    ((add_le_add_right (herror p) _).trans hbudget)

/-- The fixed sample size ceil(2 b), with a proved exponential overflow bound. -/
theorem achievable_of_poissonized_error_ceil_twice {k : ℕ} (b : ℝ≥0)
    (alpha eps delta : ℝ) (f : PoissonMarkedSample (Fin k) → ℝ)
    (herror : ∀ p : Simplex k,
      (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure.real
        {x | eps < |f x - entropy p alpha|} ≤ delta)
    (hbudget : delta + Real.exp (-(b : ℝ) / 3) ≤ 1 / 3) :
    Achievable k ⌈2 * (b : ℝ)⌉₊ alpha eps := by
  apply achievable_of_poissonized_error b alpha eps delta f herror
  exact (add_le_add_left (poisson_tail_ceil_twice b) delta).trans hbudget

/-- The source integer budget transfers directly to the model's fixed-sample target. -/
theorem integer_achievable_of_poissonized_error {k : ℕ} (b : ℝ≥0)
    {eps : ℝ} (heps : 0 < eps) (hepshalf : eps ≤ 1 / 2)
    {r : ℕ} (hr : 2 ≤ r) (hsize : integerSampleConstant eps * r ≤ (b : ℝ))
    (f : PoissonMarkedSample (Fin k) → ℝ)
    (herror : ∀ p : Simplex k,
      (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure.real
        {x | eps < |f x - entropy p (r : ℝ)|} ≤ 1 / 12) :
    Achievable k ⌈2 * (b : ℝ)⌉₊ (r : ℝ) eps := by
  apply achievable_of_poissonized_error_ceil_twice b (r : ℝ) eps (1 / 12) f herror
  have h := integer_fixed_sample_scalar_budget heps hepshalf hr hsize
  linarith

/-- Ceiling costs at most one additional observation. -/
theorem poisson_fixed_sample_size_le (b : ℝ≥0) (hb : 1 ≤ (b : ℝ)) :
    (⌈2 * (b : ℝ)⌉₊ : ℝ) ≤ 3 * (b : ℝ) := by
  have h := Nat.ceil_lt_add_one (by positivity : 0 ≤ 2 * (b : ℝ))
  linarith

/-- The output-mixture identity holds for every measurable error event. -/
theorem iid_pmf_mixture_event {k m : ℕ} (p : Simplex k)
    (G : Sample k m → PMF ℝ) {B : Set ℝ} (hB : MeasurableSet B) :
    (∑ x : Sample k m, iidMass p m x * (G x).toMeasure.real B) =
      ((iidMarkPMF (simplexNN p) (simplexNN_sum p) m).bind G).toMeasure.real B := by
  unfold Measure.real
  rw [PMF.toMeasure_bind_apply _ _ _ hB, tsum_fintype, ENNReal.toReal_sum]
  · apply Finset.sum_congr rfl
    intro x _
    rw [ENNReal.toReal_mul]
    have hm : (iidMarkPMF (simplexNN p) (simplexNN_sum p) m x).toReal =
        iidMass p m x := by
      simp [iidMarkPMF_apply, ENNReal.toReal_prod, iidMass, simplexNN]
    rw [hm]
  · intro x _
    exact ENNReal.mul_ne_top (PMF.apply_ne_top _ _) (measure_ne_top _ _)

/-- The risk transfer works for any deterministic target center, including min-entropy. -/
theorem poissonToIID_centered_error_le {k m : ℕ} (b : ℝ≥0) (p : Simplex k)
    (target eps : ℝ) (f : PoissonMarkedSample (Fin k) → ℝ) (fallback : ℝ) :
    (∑ x : Sample k m, iidMass p m x *
      (poissonToIIDEstimator b f fallback x {z : ℝ | eps < |z - target|} : ℝ)) ≤
      (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure.real
        {x | eps < |f x - target|} +
      (poissonPMF b).toMeasure.real {q : ℕ | m < q} := by
  have hB : MeasurableSet {z : ℝ | eps < |z - target|} :=
    measurableSet_lt measurable_const (by fun_prop)
  unfold poissonToIIDEstimator
  change (∑ x : Sample k m, iidMass p m x *
    ((poissonPMF b).map (truncatedSampleOutput f fallback x)).toMeasure.real
      {z : ℝ | eps < |z - target|}) ≤ _
  rw [iid_pmf_mixture_event p _ hB, poissonToIID_output_law]
  have h := truncatedPoissonLaw_real_event_le b
    (fun q => (iidMarkPMF (simplexNN p) (simplexNN_sum p) q).map
      (fun x => f ⟨q, x⟩)) fallback m hB
  have hout : ((poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).map f) =
      (poissonPMF b).bind (fun q =>
        (iidMarkPMF (simplexNN p) (simplexNN_sum p) q).map (fun x => f ⟨q, x⟩)) := by
    rw [poissonMarkedSamplePMF, PMF.map_bind]
    simp only [PMF.map_comp, Function.comp_def]
  rw [← hout] at h
  have hm := PMF.toMeasure_map_apply f
    (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)) _
    (measurable_of_countable f) hB
  simpa only [Measure.real, hm] using h

theorem minEntropyAchievable_of_poissonized_error {k m : ℕ} (b : ℝ≥0)
    (eps delta : ℝ) (f : PoissonMarkedSample (Fin k) → ℝ)
    (herror : ∀ p : Simplex k,
      (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure.real
        {x | eps < |f x - minEntropy p|} ≤ delta)
    (hbudget : delta + (poissonPMF b).toMeasure.real {q : ℕ | m < q} ≤ 1 / 3) :
    MinEntropyAchievable k m eps := by
  refine ⟨poissonToIIDEstimator b f 0, ?_⟩
  intro p
  exact (poissonToIID_centered_error_le b p (minEntropy p) eps f 0).trans
    ((add_le_add_right (herror p) _).trans hbudget)

theorem minEntropyAchievable_of_poissonized_error_ceil_twice {k : ℕ} (b : ℝ≥0)
    (eps delta : ℝ) (f : PoissonMarkedSample (Fin k) → ℝ)
    (herror : ∀ p : Simplex k,
      (poissonMarkedSamplePMF b (simplexNN p) (simplexNN_sum p)).toMeasure.real
        {x | eps < |f x - minEntropy p|} ≤ delta)
    (hbudget : delta + Real.exp (-(b : ℝ) / 3) ≤ 1 / 3) :
    MinEntropyAchievable k ⌈2 * (b : ℝ)⌉₊ eps := by
  apply minEntropyAchievable_of_poissonized_error b eps delta f herror
  exact (add_le_add_left (poisson_tail_ceil_twice b) delta).trans hbudget

end Renyi
