import Renyi.Pilot
import Renyi.RawPoissonMoments

/-! Medium and large intensity moment bounds for the high polynomial block. -/
noncomputable section
open scoped NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

theorem poissonPilotSecond_exponential_bound (lam : ℝ≥0) {cp B a : ℝ}
    (hcp : 0 < cp) (j : ℕ) :
    poissonPilotSecond lam ⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ (cp * B * a) j ≤
      Real.exp (cp * B * a - cp * (lam : ℝ) / 2) *
        (lam : ℝ) ^ j * ((lam : ℝ) + j) ^ j := by
  rw [poissonPilotSecond_factor]
  have ht := poissonLowerMass_exp_bound
    (⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ : ℝ≥0) (cp * B * a)
  have htail : poissonLowerMass (⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ : ℝ≥0)
      (cp * B * a) ≤ Real.exp (cp * B * a - cp * (lam : ℝ) / 2) := by
    apply ht.trans
    apply Real.exp_le_exp.mpr
    have he := mul_le_mul_of_nonneg_left exp_neg_one_le_three_eighths
      (mul_nonneg hcp.le lam.coe_nonneg)
    simp only [NNReal.coe_mk]
    have hnon : 0 ≤ cp * (lam : ℝ) := mul_nonneg hcp.le lam.coe_nonneg
    nlinarith
  have h := mul_le_mul htail (poissonFactorialSecond_le lam j)
    (poissonFactorialSecond_nonneg lam j) (Real.exp_pos _).le
  simpa only [mul_assoc] using h

private theorem high_moment_medium_scalar {H lam a : ℝ} {j : ℕ}
    (hH : 0 < H) (hlam : 0 < lam) (hlamH : lam ≤ H) (_ha : 0 < a) (hj : a ≤ (j : ℝ)) :
    H ^ (2 * a - 2 * j) * lam ^ j * (lam + j) ^ j ≤
      H ^ a * lam ^ a * (1 + (j : ℝ) / H) ^ j := by
  have hj0 : (0 : ℝ) ≤ j := Nat.cast_nonneg _
  have hsum : 0 < lam + j := by positivity
  have hsumH : 0 < H + j := by positivity
  have hratio : 0 < 1 + (j : ℝ) / H := by positivity
  have hleft : 0 < H ^ (2 * a - 2 * j) * lam ^ j * (lam + j) ^ j := by positivity
  have hright : 0 < H ^ a * lam ^ a * (1 + (j : ℝ) / H) ^ j := by positivity
  apply (Real.log_le_log_iff hleft hright).1
  rw [Real.log_mul (by positivity) (by positivity),
    Real.log_mul (by positivity) (by positivity), Real.log_rpow hH,
    Real.log_pow, Real.log_pow,
    Real.log_mul (by positivity) (by positivity),
    Real.log_mul (by positivity) (by positivity), Real.log_rpow hH,
    Real.log_rpow hlam, Real.log_pow]
  have hloglam := Real.log_le_log hlam hlamH
  have hlogsum : Real.log (lam + j) ≤ Real.log H + Real.log (1 + (j : ℝ) / H) := by
    have h := Real.log_le_log hsum (show lam + j ≤ H + j by linarith)
    have hid : H + (j : ℝ) = H * (1 + (j : ℝ) / H) := by field_simp
    rw [hid, Real.log_mul hH.ne' hratio.ne'] at h
    exact h
  have hdiff := mul_le_mul_of_nonneg_left hloglam (sub_nonneg.mpr hj)
  have hterm := mul_le_mul_of_nonneg_left hlogsum hj0
  nlinarith

/-- The source medium-mean envelope, for every degree above the real order. -/
theorem poisson_high_moment_medium (lam : ℝ≥0) {H a : ℝ} {j : ℕ}
    (hH : 0 < H) (ha : 0 < a) (hj : a ≤ (j : ℝ)) (hlamH : (lam : ℝ) ≤ H) :
    H ^ (2 * a - 2 * j) * poissonFactorialSecond lam j ≤
      H ^ a * (lam : ℝ) ^ a * (1 + (j : ℝ) / H) ^ j := by
  have hjpos : 0 < j := by exact_mod_cast (lt_of_lt_of_le ha hj)
  have h := mul_le_mul_of_nonneg_left (poissonFactorialSecond_le lam j)
    (Real.rpow_nonneg hH.le (2 * a - 2 * j))
  rcases eq_or_lt_of_le lam.coe_nonneg with hz | hl0
  · rw [← hz, zero_pow hjpos.ne', zero_mul, mul_zero] at h
    rw [← hz, Real.zero_rpow ha.ne', mul_zero, zero_mul]
    exact h
  · exact h.trans (by
      simpa only [mul_assoc] using high_moment_medium_scalar hH hl0 hlamH ha hj)

private theorem high_moment_large_scalar {H lam a cp B M : ℝ} {j : ℕ}
    (hH : 0 < H) (hHlam : H ≤ lam) (ha : 0 < a) (hj : a ≤ (j : ℝ))
    (hM : 0 ≤ M) (hjM : (j : ℝ) ≤ M * H) (hcp : 4 * M ≤ cp) :
    H ^ (2 * a - 2 * j) *
      (Real.exp (cp * B * a - cp * lam / 2) * lam ^ j * (lam + j) ^ j) ≤
      Real.exp (cp * B * a + M * j) * H ^ a * lam ^ a := by
  have hlam : 0 < lam := hH.trans_le hHlam
  have hj0 : (0 : ℝ) ≤ j := Nat.cast_nonneg _
  have hratio : 0 < lam / H := div_pos hlam hH
  have hq : 0 ≤ 2 * (j : ℝ) - a := by linarith
  have hleft : 0 < H ^ (2 * a - 2 * j) *
      (Real.exp (cp * B * a - cp * lam / 2) * lam ^ j * (lam + j) ^ j) := by positivity
  have hright : 0 < Real.exp (cp * B * a + M * j) * H ^ a * lam ^ a := by positivity
  apply (Real.log_le_log_iff hleft hright).1
  rw [Real.log_mul (by positivity) (by positivity), Real.log_rpow hH,
    Real.log_mul (by positivity) (by positivity),
    Real.log_mul (by positivity) (by positivity), Real.log_exp,
    Real.log_pow, Real.log_pow,
    Real.log_mul (by positivity) (by positivity),
    Real.log_mul (by positivity) (by positivity), Real.log_exp,
    Real.log_rpow hH, Real.log_rpow hlam]
  have hlogratio : Real.log lam - Real.log H ≤ lam / H := by
    rw [← Real.log_div hlam.ne' hH.ne']
    exact (Real.log_le_sub_one_of_pos hratio).trans (by linarith)
  have hlogsum : Real.log (lam + j) ≤ Real.log lam + M := by
    have hx : 0 < 1 + (j : ℝ) / lam := by positivity
    have hjlam : (j : ℝ) / lam ≤ M := (div_le_iff₀ hlam).2
      (hjM.trans (mul_le_mul_of_nonneg_left hHlam hM))
    have h := Real.log_le_sub_one_of_pos hx
    have heq : lam + (j : ℝ) = lam * (1 + (j : ℝ) / lam) := by field_simp
    rw [heq, Real.log_mul hlam.ne' hx.ne']
    linarith
  have hterm := mul_le_mul_of_nonneg_left hlogsum hj0
  have hqr := mul_le_mul_of_nonneg_left hlogratio hq
  have hqH : (2 * (j : ℝ) - a) / H ≤ 2 * M := by
    apply (div_le_iff₀ hH).2
    nlinarith
  have hmul := mul_le_mul_of_nonneg_right hqH hlam.le
  have hcp := mul_le_mul_of_nonneg_right hcp hlam.le
  have hcancel : (2 * (j : ℝ) - a) * (lam / H) =
      ((2 * (j : ℝ) - a) / H) * lam := by ring
  rw [hcancel] at hqr
  nlinarith

/-- Pilot suppression controls the high block above its endpoint scale. -/
theorem poisson_high_moment_large (lam : ℝ≥0) {H a cp B M : ℝ} {j : ℕ}
    (hH : 0 < H) (hHlam : H ≤ (lam : ℝ)) (ha : 0 < a) (hj : a ≤ (j : ℝ))
    (hcp0 : 0 < cp) (hM : 0 ≤ M) (hjM : (j : ℝ) ≤ M * H) (hcp : 4 * M ≤ cp) :
    H ^ (2 * a - 2 * j) *
      poissonPilotSecond lam ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp * B * a) j ≤
      Real.exp (cp * B * a + M * j) * H ^ a * (lam : ℝ) ^ a := by
  have h := mul_le_mul_of_nonneg_left (poissonPilotSecond_exponential_bound (B := B) (a := a) lam hcp0 j)
    (Real.rpow_nonneg hH.le (2 * a - 2 * j))
  exact h.trans (high_moment_large_scalar hH hHlam ha hj hM hjM hcp)

/-- A tiny-mean factorial second moment, with the extra mean power retained. -/
theorem poisson_factorial_second_tiny (lam : ℝ≥0) (j : ℕ) (hj : 1 ≤ j)
    (hlam : (lam : ℝ) ≤ 1) :
    poissonFactorialSecond lam j ≤ (2 * (j : ℝ)) ^ j * (lam : ℝ) ^ j := by
  have hjR : (1 : ℝ) ≤ j := by exact_mod_cast hj
  have hbase : (lam : ℝ) + j ≤ 2 * (j : ℝ) := by linarith
  have hp := pow_le_pow_left₀ (by positivity : 0 ≤ (lam : ℝ) + j) hbase j
  exact (poissonFactorialSecond_le lam j).trans (by
    have h := mul_le_mul_of_nonneg_left hp (pow_nonneg lam.coe_nonneg j)
    simpa only [mul_comm] using h)

/-- The degree growth in the tiny-mean block reduces to a geometric factor. -/
theorem high_degree_power_geometric {r j d : ℕ} (hr : 0 < r) (hrj : r ≤ j) (hjd : j ≤ d) :
    (2 * (j : ℝ)) ^ j ≤ Real.exp (2 * (d : ℝ)) * (r : ℝ) ^ r * (d : ℝ) ^ (j - r) := by
  have hrR : (0 : ℝ) < r := by exact_mod_cast hr
  have hjpos : 0 < j := hr.trans_le hrj
  have hjR : (0 : ℝ) < j := by exact_mod_cast hjpos
  have hopt := rpow_le_scaled_exponential (Nat.cast_nonneg j) hrR (by norm_num : (0 : ℝ) < 1)
  simp only [div_one, one_mul, Real.rpow_natCast] at hopt
  have htwo : (2 : ℝ) ^ j ≤ Real.exp (j : ℝ) := by
    have h2 : (2 : ℝ) ≤ Real.exp 1 := by linarith [Real.add_one_le_exp (1 : ℝ)]
    have h := pow_le_pow_left₀ (by norm_num : (0 : ℝ) ≤ 2) h2 j
    simpa only [← Real.exp_nat_mul, mul_one] using h
  have hp := pow_le_pow_left₀ (Nat.cast_nonneg j) (by exact_mod_cast hjd : (j : ℝ) ≤ d) (j - r)
  have hjpow : (j : ℝ) ^ j = (j : ℝ) ^ r * (j : ℝ) ^ (j - r) := by
    rw [← pow_add, Nat.add_sub_of_le hrj]
  rw [mul_pow, hjpow]
  have hm := mul_le_mul hopt hp (pow_nonneg (Nat.cast_nonneg _) _) (by positivity : 0 ≤ (r : ℝ) ^ r * Real.exp ((j : ℝ) - r))
  have hmult := mul_le_mul htwo hm (by positivity : 0 ≤ (j : ℝ) ^ r * (j : ℝ) ^ (j - r)) (Real.exp_pos _).le
  have hexp : Real.exp (j : ℝ) * Real.exp ((j : ℝ) - r) ≤ Real.exp (2 * (d : ℝ)) := by
    rw [← Real.exp_add]
    apply Real.exp_le_exp.mpr
    have hijd : (j : ℝ) ≤ d := by exact_mod_cast hjd
    have hrnon : (0 : ℝ) ≤ r := Nat.cast_nonneg _
    linarith
  have hfinal := mul_le_mul_of_nonneg_right hexp
    (by positivity : 0 ≤ (r : ℝ) ^ r * (d : ℝ) ^ (j - r))
  nlinarith [hmult, hfinal]

/-- The actual tiny-mean high block admits the needed geometric degree factor. -/
theorem poisson_factorial_second_tiny_geometric (lam : ℝ≥0) {r j d : ℕ}
    (hr : 0 < r) (hrj : r ≤ j) (hjd : j ≤ d) (hlam : (lam : ℝ) ≤ 1) :
    poissonFactorialSecond lam j ≤ Real.exp (2 * (d : ℝ)) *
      (r : ℝ) ^ r * (d : ℝ) ^ (j - r) * (lam : ℝ) ^ j := by
  have hj : 1 ≤ j := by omega
  exact (poisson_factorial_second_tiny lam j hj hlam).trans
    (mul_le_mul_of_nonneg_right (high_degree_power_geometric hr hrj hjd) (pow_nonneg lam.coe_nonneg j))

/-- One high-degree envelope covers every intensity, including zero. -/
theorem poisson_high_moment_all (lam : ℝ≥0) {H a cp B M : ℝ} {j : ℕ}
    (hH : 0 < H) (ha : 0 < a) (hj : a ≤ (j : ℝ)) (hB : 0 ≤ B)
    (hcp0 : 0 < cp) (hM : 0 ≤ M) (hjM : (j : ℝ) ≤ M * H) (hcp : 4 * M ≤ cp) :
    H ^ (2 * a - 2 * j) *
      poissonPilotSecond lam ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp * B * a) j ≤
      Real.exp (cp * B * a + M * j) * H ^ a * (lam : ℝ) ^ a := by
  by_cases hlam : (lam : ℝ) ≤ H
  · have hp : poissonPilotSecond lam ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ (cp * B * a) j ≤
        poissonFactorialSecond lam j := by
      rw [poissonPilotSecond_factor]
      exact mul_le_of_le_one_left (poissonFactorialSecond_nonneg lam j) (poissonLowerMass_le_one _ _)
    have hbase : (1 + (j : ℝ) / H) ^ j ≤ Real.exp (M * j) := by
      have hx : 0 < 1 + (j : ℝ) / H := by positivity
      have hlog := Real.log_le_sub_one_of_pos hx
      have hjH : (j : ℝ) / H ≤ M := (div_le_iff₀ hH).2 hjM
      have hb := mul_le_mul_of_nonneg_left (show Real.log (1 + (j : ℝ) / H) ≤ M by linarith) (Nat.cast_nonneg j)
      rw [← Real.rpow_natCast, Real.rpow_def_of_pos hx]
      exact Real.exp_le_exp.mpr (by nlinarith [hb])
    have hmono : Real.exp (M * j) ≤ Real.exp (cp * B * a + M * j) :=
      Real.exp_le_exp.mpr (by nlinarith [mul_nonneg (mul_nonneg hcp0.le hB) ha.le])
    have hfirst := (mul_le_mul_of_nonneg_left hp (Real.rpow_nonneg hH.le _)).trans
      (poisson_high_moment_medium lam hH ha hj hlam)
    have hsecond := mul_le_mul_of_nonneg_left (hbase.trans hmono)
      (mul_nonneg (Real.rpow_nonneg hH.le a) (Real.rpow_nonneg lam.coe_nonneg a))
    exact hfirst.trans (by nlinarith [hsecond])
  · exact poisson_high_moment_large lam hH (le_of_not_ge hlam) ha hj hcp0 hM hjM hcp

/-- Pilot damping at an arbitrary threshold, rather than only cp*B*a. -/
theorem poissonPilotSecond_exponential_threshold_bound (lam : ℝ≥0) {cp T : ℝ}
    (hcp : 0 < cp) (j : ℕ) :
    poissonPilotSecond lam ⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ T j ≤
      Real.exp (T - cp * (lam : ℝ) / 2) * (lam : ℝ) ^ j * ((lam : ℝ) + j) ^ j := by
  rw [poissonPilotSecond_factor]
  have ht := poissonLowerMass_exp_bound (⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ : ℝ≥0) T
  have htail : poissonLowerMass (⟨cp * lam, mul_nonneg hcp.le lam.coe_nonneg⟩ : ℝ≥0) T ≤
      Real.exp (T - cp * (lam : ℝ) / 2) := by
    apply ht.trans
    apply Real.exp_le_exp.mpr
    have he := mul_le_mul_of_nonneg_left exp_neg_one_le_three_eighths (mul_nonneg hcp.le lam.coe_nonneg)
    simp only [NNReal.coe_mk]
    have hnon : 0 ≤ cp * (lam : ℝ) := mul_nonneg hcp.le lam.coe_nonneg
    nlinarith
  have h := mul_le_mul htail (poissonFactorialSecond_le lam j) (poissonFactorialSecond_nonneg lam j) (Real.exp_pos _).le
  simpa only [mul_assoc] using h

private theorem selected_normalized_large_scalar {H lam cp T M : ℝ} {j : ℕ}
    (hH : 0 < H) (hHlam : H ≤ lam) (hM : 0 ≤ M)
    (hjM : (j : ℝ) ≤ M * H) (hcp : 4 * M ≤ cp) :
    Real.exp (T - cp * lam / 2) * lam ^ j * (lam + j) ^ j ≤
      Real.exp (T + M * j) * H ^ (2 * j) := by
  have hlam : 0 < lam := hH.trans_le hHlam
  have hj0 : (0 : ℝ) ≤ j := Nat.cast_nonneg _
  have hleft : 0 < Real.exp (T - cp * lam / 2) * lam ^ j * (lam + j) ^ j := by positivity
  have hright : 0 < Real.exp (T + M * j) * H ^ (2 * j) := by positivity
  apply (Real.log_le_log_iff hleft hright).1
  rw [Real.log_mul (by positivity) (by positivity), Real.log_mul (by positivity) (by positivity),
    Real.log_exp, Real.log_pow, Real.log_pow,
    Real.log_mul (by positivity) (by positivity), Real.log_exp, Real.log_pow]
  have hlogratio : Real.log lam - Real.log H ≤ lam / H := by
    rw [← Real.log_div hlam.ne' hH.ne']
    exact (Real.log_le_sub_one_of_pos (div_pos hlam hH)).trans (by linarith)
  have hlogsum : Real.log (lam + j) ≤ Real.log lam + M := by
    have hx : 0 < 1 + (j : ℝ) / lam := by positivity
    have hjlam : (j : ℝ) / lam ≤ M := (div_le_iff₀ hlam).2
      (hjM.trans (mul_le_mul_of_nonneg_left hHlam hM))
    have h := Real.log_le_sub_one_of_pos hx
    have heq : lam + (j : ℝ) = lam * (1 + (j : ℝ) / lam) := by field_simp
    rw [heq, Real.log_mul hlam.ne' hx.ne']
    linarith
  have hterm := mul_le_mul_of_nonneg_left hlogsum hj0
  have hqr := mul_le_mul_of_nonneg_left hlogratio (show 0 ≤ 2 * (j : ℝ) by positivity)
  have hjH : (j : ℝ) / H ≤ M := (div_le_iff₀ hH).2 hjM
  have hmul := mul_le_mul_of_nonneg_right hjH hlam.le
  have hcp := mul_le_mul_of_nonneg_right hcp hlam.le
  have hcancel : 2 * (j : ℝ) * (lam / H) = 2 * (((j : ℝ) / H) * lam) := by ring
  rw [hcancel] at hqr
  push_cast
  nlinarith

/-- Uniform selected factorial moments in endpoint count units. This includes
j=0 and j=1, and therefore also controls pilot switching of affine residuals. -/
theorem poissonPilotSecond_normalized_bound (lam : ℝ≥0) {H cp T M : ℝ} {j : ℕ}
    (hH : 0 < H) (hcp0 : 0 < cp) (hT : 0 ≤ T) (hM : 0 ≤ M)
    (hjM : (j : ℝ) ≤ M * H) (hcp : 4 * M ≤ cp) :
    poissonPilotSecond lam ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ T j ≤
      Real.exp (T + M * j) * H ^ (2 * j) := by
  by_cases hlam : (lam : ℝ) ≤ H
  · have hp : poissonPilotSecond lam ⟨cp * lam, mul_nonneg hcp0.le lam.coe_nonneg⟩ T j ≤
        poissonFactorialSecond lam j := by
      rw [poissonPilotSecond_factor]
      exact mul_le_of_le_one_left (poissonFactorialSecond_nonneg lam j) (poissonLowerMass_le_one _ _)
    have hraw : poissonFactorialSecond lam j ≤ H ^ j * (H + j) ^ j :=
      (poissonFactorialSecond_le lam j).trans (mul_le_mul
        (pow_le_pow_left₀ lam.coe_nonneg hlam j)
        (pow_le_pow_left₀ (by positivity : 0 ≤ (lam : ℝ) + j) (by linarith : (lam : ℝ) + j ≤ H + j) j)
        (pow_nonneg (by positivity : 0 ≤ (lam : ℝ) + j) j) (pow_nonneg hH.le j))
    have hbase : (1 + (j : ℝ) / H) ^ j ≤ Real.exp (M * j) := by
      have hx : 0 < 1 + (j : ℝ) / H := by positivity
      have hlog := Real.log_le_sub_one_of_pos hx
      have hjH : (j : ℝ) / H ≤ M := (div_le_iff₀ hH).2 hjM
      have hb := mul_le_mul_of_nonneg_left (show Real.log (1 + (j : ℝ) / H) ≤ M by linarith) (Nat.cast_nonneg j)
      rw [← Real.rpow_natCast, Real.rpow_def_of_pos hx]
      exact Real.exp_le_exp.mpr (by nlinarith)
    have heq : H ^ j * (H + (j : ℝ)) ^ j = H ^ (2 * j) * (1 + (j : ℝ) / H) ^ j := by
      rw [show H + (j : ℝ) = H * (1 + (j : ℝ) / H) by field_simp, mul_pow,
        show 2 * j = j + j by omega, pow_add]
      ring
    rw [heq] at hraw
    have hmono : Real.exp (M * j) ≤ Real.exp (T + M * j) := Real.exp_le_exp.mpr (by linarith)
    have hm := mul_le_mul_of_nonneg_left (hbase.trans hmono) (pow_nonneg hH.le (2 * j))
    exact (hp.trans hraw).trans (by nlinarith [hm])
  · exact (poissonPilotSecond_exponential_threshold_bound lam hcp0 j).trans
      (selected_normalized_large_scalar hH (le_of_not_ge hlam) hM hjM hcp)

end Renyi
