import Renyi.NearOneActualTail
import Renyi.NearOneUniformBias
import Renyi.NearOneExpectation
import Renyi.UpperPilotBoundary

/-! Actual polynomial mean errors and their finite-sum hybrid assembly. -/
noncomputable section
open scoped BigOperators NNReal
open Polynomial MeasureTheory ProbabilityTheory
namespace Renyi
set_option maxHeartbeats 700000

lemma polynomialOfCoefficients_eq_of_natDegree (P : ℝ[X]) {d : ℕ} (hd : P.natDegree≤d) :
    polynomialOfCoefficients d P.coeff=P := by
  exact (P.as_sum_range_C_mul_X_pow' (lt_of_le_of_lt hd (Nat.lt_succ_self d))).symm

theorem actual_near_one_local_mean_uniform
    {eps cb lambda CL cmin q Q M cw f cu u0 : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hf : 0≤f) (hf1 : f≤1)
    (hcu : 0≤cu) (hu0 : 0<u0) :
    ∃ K : ℝ, 0<K ∧ ∀ cL : ℝ, 0<cL → ∀ (k N : ℕ) (alpha Ch D c p : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) →
      0≤p → p≤upperB k alpha eps D cb CL cL →
      let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
        (upperRescaling k alpha eps cu u0)
      |P.eval p-upperOmega k alpha eps Ch cw*p^alpha|≤
        K*(alpha-1)*(upperB k alpha eps D cb CL cL/(N:ℝ)^2)^alpha+2*cu*(alpha-1)*p^alpha := by
  obtain ⟨K,hK,hbias⟩ := actual_near_one_bias_degree_uniform heps hcb hlambda hCL hcmin hq hQ hM hcw hcw1 hf hf1
  refine ⟨K,hK,?_⟩
  intro cL hcL k N alpha Ch D c p hk ha ha1 hCh hD hc hc1 hNlo hNhi hp hpb
  have hbeta : 0<alpha-1 := sub_pos.mpr ha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order ha ha1).2];exact hbeta
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order ha ha1).2];linarith only [ha1]
  have hb := upperB_pos (ε:=eps) hk ha hg hg1 hD hcb hCL hcL
  have hL := upperDegree_pos ha hCL hcL (one_le_rootMultiplier (k:=k) (ε:=eps) ha hg hg1)
  have hNr : 0<(N:ℝ) := (mul_pos hq hL).trans_le hNlo
  have hN : 0<N := by exact_mod_cast hNr
  have hs := upperRescaling_near_one (k:=k) (eps:=eps) ha ha1 hcu hu0
  have h := hbias cL hcL k N alpha Ch D c (upperRescaling k alpha eps cu u0) p hk ha ha1 hCh hD hc hc1 hNlo hNhi hs.1.le hs.2.1 hp hpb
  rw [←actualNearOnePolynomial_eval hN ha ha1 hb hp hpb] at h
  let omega := upperOmega k alpha eps Ch cw
  have hE := upper_reserved_interval (k:=k) ha hg hg1 heps hCh
  have hE0 : 0<upperE0 k alpha eps Ch := (mul_pos heps hbeta).trans_le hE.1
  have hw0 : 0≤omega := (Real.exp_pos _).le
  have hw1 : omega≤1 := Real.exp_le_one_iff.mpr (by nlinarith only [hcw,hE0])
  have heq : upperRescaling k alpha eps cu u0*omega*p^alpha-omega*p^alpha=
      (upperRescaling k alpha eps cu u0-1)*omega*p^alpha := by ring
  have herr : |upperRescaling k alpha eps cu u0*omega*p^alpha-omega*p^alpha|≤2*cu*(alpha-1)*p^alpha := by
    rw [heq,abs_mul,abs_mul,abs_of_nonneg hw0,abs_of_nonneg (Real.rpow_nonneg hp _)]
    have hh := mul_le_mul hs.2.2 hw1 hw0 (show 0≤2*cu*(alpha-1) by positivity)
    simpa only [mul_one] using mul_le_mul_of_nonneg_right hh (Real.rpow_nonneg hp alpha)
  have ht := abs_sub_le ((actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
    (upperRescaling k alpha eps cu u0)).eval p) (upperRescaling k alpha eps cu u0*omega*p^alpha) (omega*p^alpha)
  exact ht.trans (add_le_add h herr)

/-- The actual selected polynomial mean has one uniform beta-sized error
bound over all probabilities, including the false-light tail. -/
theorem actual_near_one_polynomial_mean_uniform
    {eps cb lambda CL cmin q Q M cw f cu u0 B eta : ℝ}
    (heps : 0<eps) (hcb : 0<cb) (hlambda : 0<lambda) (hCL : 1≤CL)
    (hcmin : 0<cmin) (hq : 0<q) (hQ : 0<Q)
    (hM : 0≤M) (hcw : 0<cw) (hcw1 : cw<1) (hf : 0≤f) (hf1 : f≤1)
    (hcu : 0≤cu) (hu0 : 0<u0) (hCLB : 2*B≤cb*CL) (heta : 0<eta) :
    ∃ K cp0 : ℝ, 0<K ∧ 0<cp0 ∧ ∀ cp : ℝ, cp0≤cp → ∀ cL : ℝ, 0<cL →
      ∀ (k N : ℕ) (alpha Ch D c p : ℝ),
      0<k → 1<alpha → alpha≤3/2 → 0≤Ch → 0<D → cmin≤c → c≤1 →
      q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ)≤N →
      (N:ℝ)≤Q*(upperDegree alpha CL cL (rootMultiplier k alpha eps):ℝ) → 0≤p →
      let n := upperSample k alpha eps D
      let b := upperB k alpha eps D cb CL cL
      let P := actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f
        (upperRescaling k alpha eps cu u0)
      poissonLowerMass (Real.toNNReal (cp*n*p)) (cp*B*alpha)*
        |P.eval p-upperOmega k alpha eps Ch cw*p^alpha|≤
        K*(alpha-1)*(b/(N:ℝ)^2)^alpha+(2*cu+eta)*(alpha-1)*p^alpha := by
  obtain ⟨K,hK,hlocal⟩ := actual_near_one_local_mean_uniform heps hcb hlambda hCL hcmin hq hQ hM hcw hcw1 hf hf1 hcu hu0
  obtain ⟨cp0,hcp0,htail⟩ := actual_near_one_false_light_uniform heps hcb hlambda hCL hcmin hq hQ hM hcw hcw1 hf hf1 hcu hu0 hCLB heta
  refine ⟨K,cp0,hK,hcp0,?_⟩
  intro cp hcp cL hcL k N alpha Ch D c p hk ha ha1 hCh hD hc hc1 hNlo hNhi hp
  have hbeta : 0<alpha-1 := sub_pos.mpr ha
  have hg : 0<fractionalPart alpha := by rw [(near_one_order ha ha1).2];exact hbeta
  have hg1 : fractionalPart alpha<1 := by rw [(near_one_order ha ha1).2];linarith only [ha1]
  have hb := upperB_pos (ε:=eps) hk ha hg hg1 hD hcb hCL hcL
  have hnonneg : 0≤K*(alpha-1)*(upperB k alpha eps D cb CL cL/(N:ℝ)^2)^alpha := by positivity
  by_cases hpb : p≤upperB k alpha eps D cb CL cL
  · have hh := hlocal cL hcL k N alpha Ch D c p hk ha ha1 hCh hD hc hc1 hNlo hNhi hp hpb
    have hs := poissonLowerMass_le_one (Real.toNNReal (cp*upperSample k alpha eps D*p)) (cp*B*alpha)
    have hm := mul_le_of_le_one_left (abs_nonneg ((actualNearOnePolynomial k N alpha eps Ch D cb lambda CL cL c M cw f (upperRescaling k alpha eps cu u0)).eval p-upperOmega k alpha eps Ch cw*p^alpha)) hs
    have hetaTerm : 0≤eta*(alpha-1)*p^alpha := by positivity
    exact (hm.trans hh).trans (by nlinarith only [hetaTerm])
  · have hh := htail cp hcp cL hcL k N alpha Ch D c p hk ha ha1 hCh hD hc hc1 hNlo hNhi (le_of_not_ge hpb)
    have hcuTerm : 0≤2*cu*(alpha-1)*p^alpha := by positivity
    exact hh.trans (by nlinarith only [hnonneg,hcuTerm])

end Renyi
