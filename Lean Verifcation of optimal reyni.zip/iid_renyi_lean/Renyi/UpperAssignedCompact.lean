import Renyi.ActualCompactInterior
import Renyi.ActualAssignedMean

/-! Compact-width interior for the same realized assigned heavy aggregate. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 700000

lemma assignedHeavyPower_nonneg {k : ℕ} (p : Simplex k) (light : Fin k→Bool) (alpha : ℝ) :
    0≤assignedHeavyPower p light alpha := by
  apply Finset.sum_nonneg
  intro i _
  split_ifs
  · exact le_rfl
  · exact Real.rpow_nonneg (p.nonneg i) _

lemma assignedHeavyPower_le_powerSum {k : ℕ} (p : Simplex k) (light : Fin k→Bool) (alpha : ℝ) :
    assignedHeavyPower p light alpha≤powerSum p alpha := by
  apply Finset.sum_le_sum
  intro i _
  split_ifs
  · exact Real.rpow_nonneg (p.nonneg i) _
  · exact le_rfl

/-- Rescaling is applied once, after inserting the raw heavy aggregate. -/
theorem actualAssignedOracleMean_compact_error {k : ℕ} (p : Simplex k) (light : Fin k→Bool)
    {alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d heavy eta : ℝ}
    (ha : 1<alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (hcu : 0≤cu) (hu0 : 0<u0) (heta : 0≤eta)
    (hheavy : |heavy-Real.exp (-upperE0 k alpha eps Ch/8)*assignedHeavyPower p light alpha|≤
      eta*assignedHeavyPower p light alpha) :
    |actualAssignedOracleMean p light heavy alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d-
      actualCorrectedOracleMean p light alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d|≤
      eta*powerSum p alpha := by
  have hr := upperRescaling_range (k:=k) (eps:=eps) ha hg hg1 hcu hu0
  have hid : actualAssignedOracleMean p light heavy alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d-
      actualCorrectedOracleMean p light alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d=
      upperRescaling k alpha eps cu u0*(heavy-Real.exp (-upperE0 k alpha eps Ch/8)*assignedHeavyPower p light alpha) := by
    unfold actualAssignedOracleMean actualCorrectedOracleMean
    rw [actual_hybrid_mean_partition]
    ring
  rw [hid,abs_mul,abs_of_nonneg hr.1.le]
  exact (mul_le_of_le_one_left (abs_nonneg _) hr.2).trans
    (hheavy.trans (mul_le_mul_of_nonneg_left (assignedHeavyPower_le_powerSum p light alpha) heta))

/-- The compact-width conclusion requires only the raw assigned heavy error. -/
theorem upper_actual_assigned_compact_interior {eps W Ch cb lambda CL cL fL f M cu u0 C0 d : ℝ}
    (heps : 0<eps) (hW : 0<W) (hCh : 0≤Ch) (hcb : 0<cb)
    (hlambda : 0<lambda) (hlambda4 : lambda≤4) (hCL : 1≤CL) (hcL : 0<cL) (hcbCL : 1≤cb*CL)
    (hfL : 0≤fL) (hfL1 : fL<1) (hf : 0≤f) (hf1 : f≤1) (hM : 0≤M)
    (hcu : 0≤cu) (hu0 : 0<u0) (hC0 : 1≤C0) (hd : 0≤d) (hd1 : d≤1)
    (hsmall : cu*u0≤compactOmegaLowerGap eps W/2) :
    ∃ D0 : ℝ, 0<D0 ∧ ∀ (k : ℕ) (alpha D heavy : ℝ),
      0<k → 3/2≤alpha → 0<fractionalPart alpha → fractionalPart alpha<1 → D0≤D →
      2*eps*(alpha-1)/(fractionalPart alpha*(1-fractionalPart alpha))≤W →
      ∀ (p : Simplex k) (light : Fin k→Bool),
        (∀i,light i=true→p.mass i≤upperB k alpha eps D cb CL cL) →
        |heavy-Real.exp (-upperE0 k alpha eps Ch/8)*assignedHeavyPower p light alpha|≤
          (compactOmegaGap eps W/4)*assignedHeavyPower p light alpha →
        upperKappa alpha eps*powerSum p alpha+
            3*compactInteriorCoefficient eps W u0*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d u0≤
          actualAssignedOracleMean p light heavy alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d ∧
          actualAssignedOracleMean p light heavy alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d+
            3*compactInteriorCoefficient eps W u0*actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d u0≤powerSum p alpha := by
  obtain ⟨D0,hD0,hmain⟩ := actual_compact_ideal_interior heps hW hCh hcb hlambda hlambda4 hCL hcL hcbCL
    hfL hfL1 hf hf1 hM hcu hu0 hC0 hd hd1 hsmall
  refine ⟨D0,hD0,?_⟩
  intro k alpha D heavy hk ha hg hg1 hD hwidth p light hlight hheavy
  apply hmain k alpha D hk ha hg hg1 hD hwidth p light hlight
    (actualAssignedOracleMean p light heavy alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d)
  exact actualAssignedOracleMean_compact_error p light (by linarith only [ha]) hg hg1 hcu hu0
    (div_nonneg (compactOmegaGap_pos heps).le (by norm_num)) hheavy

lemma actualBiasBudget_nonneg {k : ℕ} (p : Simplex k)
    {alpha eps Ch D cb lambda CL cL C0 d u0 : ℝ}
    (ha : 1<alpha) (hg : 0<fractionalPart alpha) (hg1 : fractionalPart alpha<1)
    (hu0 : 0<u0) (hC0 : 0≤C0) (hd : 0≤d)
    (ha0 : 0≤upperA k alpha eps Ch D cb lambda CL cL)
    (hb : 0<upperB k alpha eps D cb CL cL) :
    0≤actualBiasBudget p alpha eps Ch D cb lambda CL cL C0 d u0 := by
  have hchi : 0≤min (alpha-1) 1 := le_min (sub_pos.mpr ha).le (by norm_num)
  have hu := (upperU_pos (k:=k) (eps:=eps) ha hg hg1 hu0).le
  have hP := (simplex_powerSum_pos p alpha).le
  have hbonus : 0≤actualForwardBonus p alpha eps D cb CL cL := by
    apply Finset.sum_nonneg
    intro i _
    exact mul_nonneg (Real.rpow_nonneg (p.nonneg i) _)
      (le_min (mul_nonneg (sq_nonneg _) (div_nonneg (p.nonneg i) hb.le)) (by norm_num))
  unfold actualBiasBudget actualCutoffBudget upperActualBaseline upperKappa
  positivity

end Renyi
