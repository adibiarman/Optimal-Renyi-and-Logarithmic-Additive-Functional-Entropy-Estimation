import Renyi.NonintegerHistogram
import Renyi.ActualAssignedMean
import Renyi.PilotOracleComparison

/-! Exact actual-histogram ideal and assigned-oracle bridge, retaining false-light bins. -/
noncomputable section
open scoped BigOperators NNReal
open Polynomial
namespace Renyi
set_option maxHeartbeats 800000

def actualPilotLight {k : ℕ} (p : Simplex k) (n cp : ℝ≥0) (b alpha B : ℝ)
    (h : PilotHistogram k) : Fin k→Bool :=
  pilotOracleLight p.mass pilotSelectionCount n b alpha cp B h

/-- The assigned heavy complement includes both the selected true-heavy Gamma
sum and the ideal power contribution on false-light bins. -/
def actualPilotAssignedHeavy {k : ℕ} (p : Simplex k) (n cp : ℝ≥0) (b alpha B omega : ℝ)
    (h : PilotHistogram k) : ℝ :=
  pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B omega h+
    omega*(assignedHeavyPower p (actualPilotLight p n cp b alpha B h) alpha-
      pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h)

lemma actualPilotLight_admissible {k : ℕ} (p : Simplex k) (n cp : ℝ≥0)
    {b alpha B : ℝ} (hn : 0<(n:ℝ)) (hcut : B*alpha/2≤(n:ℝ)*b) (h : PilotHistogram k) :
    ∀i,actualPilotLight p n cp b alpha B h i=true→p.mass i≤b :=
  pilotOracleLight_admissible p.mass pilotSelectionCount hn hcut h

lemma pilotTrueHeavyPower_scaled {ι Ω : Type*} [Fintype ι] (p : ι→ℝ) (Y Counts : ι→Ω→ℕ)
    (n alpha cp B sigma omega : ℝ) (w : Ω) :
    pilotTrueHeavyPower p Y Counts n alpha cp B (sigma*omega) w=
      sigma*pilotTrueHeavyPower p Y Counts n alpha cp B omega w := by
  unfold pilotTrueHeavyPower
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  split_ifs <;> ring

lemma actualPilotTrueHeavyMass_le_assigned {k : ℕ} (p : Simplex k) (n cp : ℝ≥0)
    (b alpha B : ℝ) (h : PilotHistogram k) :
    pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h≤
      assignedHeavyPower p (actualPilotLight p n cp b alpha B h) alpha := by
  apply Finset.sum_le_sum
  intro i _
  have hp := Real.rpow_nonneg (p.nonneg i) alpha
  by_cases hs : (n:ℝ)*p.mass i<B*alpha/2 <;>
    by_cases hl : (pilotSelectionCount i h:ℝ)≤(cp:ℝ)*B*alpha <;>
      by_cases hb : p.mass i≤b <;>
        simp [actualPilotLight,pilotOracleLight,hs,hl,hb,not_le.mpr,not_lt.mpr,not_le.mp,not_lt.mp,hp]

/-- The raw heavy interval extends to the complete assigned heavy complement. -/
theorem actualPilotAssignedHeavy_band {k : ℕ} (p : Simplex k) (n cp : ℝ≥0)
    {b alpha B omega lo hi : ℝ} (h : PilotHistogram k)
    (hl : lo≤omega) (hu : omega≤hi)
    (hheavy : lo*pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h≤
      pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B omega h ∧
      pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B omega h≤
        hi*pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h) :
    lo*assignedHeavyPower p (actualPilotLight p n cp b alpha B h) alpha≤
      actualPilotAssignedHeavy p n cp b alpha B omega h ∧
      actualPilotAssignedHeavy p n cp b alpha B omega h≤
        hi*assignedHeavyPower p (actualPilotLight p n cp b alpha B h) alpha := by
  have hF := sub_nonneg.mpr (actualPilotTrueHeavyMass_le_assigned p n cp b alpha B h)
  have hlo := mul_le_mul_of_nonneg_right hl hF
  have hhi := mul_le_mul_of_nonneg_right hu hF
  unfold actualPilotAssignedHeavy
  constructor <;> nlinarith only [hheavy.1,hheavy.2,hlo,hhi]

/-- Compact closeness is preserved when the ideal false-light power is added. -/
theorem actualPilotAssignedHeavy_closeness {k : ℕ} (p : Simplex k) (n cp : ℝ≥0)
    {b alpha B omega eta : ℝ} (heta : 0≤eta) (h : PilotHistogram k)
    (hheavy : |pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B omega h-
      omega*pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h|≤
      eta*pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h) :
    |actualPilotAssignedHeavy p n cp b alpha B omega h-
      omega*assignedHeavyPower p (actualPilotLight p n cp b alpha B h) alpha|≤
      eta*assignedHeavyPower p (actualPilotLight p n cp b alpha B h) alpha := by
  unfold actualPilotAssignedHeavy
  have hid : ∀H P T w : ℝ,H+w*(P-T)-w*P=H-w*T := by intros;ring
  rw [hid]
  exact hheavy.trans (mul_le_mul_of_nonneg_left
    (actualPilotTrueHeavyMass_le_assigned p n cp b alpha B h) heta)

/-- Exact equality for the actual scaled polynomial, correction, and pilot ideal. -/
theorem nonintegerHistogramIdeal_eq_actualAssigned {k : ℕ} (p : Simplex k) (n cp : ℝ≥0)
    (alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d B : ℝ) (h : PilotHistogram k) :
    let b := upperB k alpha eps D cb CL cL
    let sigma := upperRescaling k alpha eps cu u0
    let omega := Real.exp (-upperE0 k alpha eps Ch/8)
    let Q := C sigma*actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M
    nonintegerHistogramIdeal n cp p Q b alpha B (sigma*omega)
      (2*actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d) h=
      actualAssignedOracleMean p (actualPilotLight p n cp b alpha B h)
        (actualPilotAssignedHeavy p n cp b alpha B omega h)
        alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d := by
  let b := upperB k alpha eps D cb CL cL
  let sigma := upperRescaling k alpha eps cu u0
  let omega := Real.exp (-upperE0 k alpha eps Ch/8)
  let light := actualPilotLight p n cp b alpha B h
  let Q0 := actualCoupledPolynomial k alpha eps Ch D cb lambda CL cL fL f M
  have hcmp := pilot_ideal_oracle_difference p.mass (fun i => sigma*Q0.eval (p.mass i))
    pilotSelectionCount pilotMainCount n b alpha cp B (sigma*omega) h
  rw [pilotTrueHeavyPower_scaled] at hcmp
  have hsum : (∑i,if light i then sigma*Q0.eval (p.mass i) else sigma*omega*p.mass i^alpha)=
      sigma*(actualLightPolynomialMean p light alpha eps Ch D cb lambda CL cL fL f M+
        omega*assignedHeavyPower p light alpha) := by
    unfold actualLightPolynomialMean assignedHeavyPower
    rw [mul_add,Finset.mul_sum,Finset.mul_sum,Finset.mul_sum,←Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro i _
    dsimp [Q0]
    split_ifs <;> ring
  change pilotIdealPower p.mass (fun i => sigma*Q0.eval (p.mass i)) pilotSelectionCount pilotMainCount
    n b alpha cp B (sigma*omega) h-(∑i,if light i then sigma*Q0.eval (p.mass i) else sigma*omega*p.mass i^alpha)=_ at hcmp
  rw [hsum] at hcmp
  dsimp only
  unfold nonintegerHistogramIdeal actualAssignedOracleMean actualPilotAssignedHeavy
  simp only [eval_mul,eval_C]
  change 2*actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d+
      pilotIdealPower p.mass (fun i => sigma*Q0.eval (p.mass i)) pilotSelectionCount pilotMainCount n b alpha cp B (sigma*omega) h=
    sigma*(actualLightPolynomialMean p light alpha eps Ch D cb lambda CL cL fL f M+
      (pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B omega h+
        omega*(assignedHeavyPower p light alpha-pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h)))+
      2*actualCutoffBudget k alpha eps Ch D cb lambda CL cL C0 d
  nlinarith only [hcmp]

/-- Raw true-heavy closeness gives precisely the perturbation admitted by the
proved compact oracle interior, with the same final rescaling. -/
theorem actualPilotAssignedHeavy_compact_error {k : ℕ} (p : Simplex k) (n cp : ℝ≥0)
    (alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d B : ℝ) {eta : ℝ}
    (heta : 0≤eta) (hs : 0≤upperRescaling k alpha eps cu u0)
    (hs1 : upperRescaling k alpha eps cu u0≤1) (h : PilotHistogram k)
    (hheavy : |pilotTrueHeavyPower p.mass pilotSelectionCount pilotMainCount n alpha cp B
        (Real.exp (-upperE0 k alpha eps Ch/8)) h-
      Real.exp (-upperE0 k alpha eps Ch/8)*pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h|≤
      eta*pilotTrueHeavyMass p.mass pilotSelectionCount n alpha cp B h) :
    let b := upperB k alpha eps D cb CL cL
    let light := actualPilotLight p n cp b alpha B h
    |actualAssignedOracleMean p light (actualPilotAssignedHeavy p n cp b alpha B (Real.exp (-upperE0 k alpha eps Ch/8)) h)
      alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d-
      actualCorrectedOracleMean p light alpha eps Ch D cb lambda CL cL fL f M cu u0 C0 d|≤eta*powerSum p alpha := by
  dsimp only
  unfold actualAssignedOracleMean actualCorrectedOracleMean
  rw [actual_hybrid_mean_partition]
  unfold actualPilotAssignedHeavy
  have hid : ∀L H P T s w c : ℝ, s*(L+(H+w*(P-T)))+2*c-(s*(L+w*P)+2*c)=s*(H-w*T) := by intros;ring
  rw [hid,abs_mul,abs_of_nonneg hs]
  exact (mul_le_of_le_one_left (abs_nonneg _) hs1).trans
    (hheavy.trans (mul_le_mul_of_nonneg_left
      (pilotTrueHeavyMass_le_powerSum p pilotSelectionCount n alpha cp B h) heta))
end Renyi
