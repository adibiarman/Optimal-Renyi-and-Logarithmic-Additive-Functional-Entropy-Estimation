import Renyi.LowCountCalibration
import Renyi.CompletedLowCoefficients

/-! Actual calibrated low count variance including the degree-one completion. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi

variable {ι Ω Ξ : Type*} [Fintype ι] [MeasurableSpace Ω] [MeasurableSpace Ξ]
variable {μ : Measure Ω} {ν : Measure Ξ}

/-- The actual low-degree part of Q, compared to the reference affine margin. -/
theorem completed_low_count_variance_affine_margin (Bp cp : ℝ) (hBp : 0 < Bp) (hcp : 0 < cp)
    (Ncount : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (Ncount i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (Ncount i) (Ncount j) μ))
    (Y : ι → Ξ → ℕ)
    (hY : ∀ i, MeasurePreserving (Y i) ν
      (poissonMeasure ⟨cp * lam i, mul_nonneg hcp.le (lam i).coe_nonneg⟩))
    (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) (hk : (0 : ℝ) < Fintype.card ι)
    {ℓ Nk m : ℕ} (hℓ : 0 < ℓ) (hNk : 0 < Nk) (hdegree : 4 * (ℓ - 1) ≤ m) (hmDegree : 1 ≤ m)
    {γ a b cProfile fL f A B ω n E v : ℝ} (hγ : 0 < γ) (hγ1 : γ ≤ 1)
    (ha : 0 < a) (hb : 0 < b) (hcProfile : cProfile ∈ Set.Ioo (γ / (1 + γ)) 1) (hf : 0 ≤ fL) (hf1 : fL < 1)
    (hA : 0 ≤ A) (hA1 : A ≤ 1) (hZ : (Nk : ℝ) ^ 2 * (a / b) ≤ 1)
    (hn : 0 < n) (hlam : ∀ i, (lam i : ℝ) = n * p i) (hE : 0 < E) (hv : 0 < v) :
    pilotAveragedCountVariance Ncount Y (cp * Bp * ((m : ℝ) + γ)) m
        (completedCoupledPolynomial ℓ Nk m γ a b cProfile fL f A B ω).coeff n μ ν /
      (((Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + γ))) *
        (E + v * ((∑ i, p i ^ ((m : ℝ) + γ)) /
          (Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + γ))))) ^ 2 ≤
    (m : ℝ) * ∑ r ∈ Finset.range m,
      ((coupledLowCoefficientConstant ^ (m + 1) * a ^ ((m : ℝ) + γ - ((r + 1 : ℕ) : ℝ))) ^ 2 *
        (pilotConstant Bp cp * ((m : ℝ) + γ)) ^ (r + 1) / n ^ (r + 1) /
        ((Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + γ))) ^ 2) *
      ((Fintype.card ι : ℝ) ^ (1 - ((r + 1 : ℕ) : ℝ)) *
        E ^ (((r + 1 : ℕ) : ℝ) / ((m : ℝ) + γ) - 2) *
        v ^ (-(((r + 1 : ℕ) : ℝ) / ((m : ℝ) + γ)))) := by
  let alpha := (m : ℝ) + γ
  let Pstar := (Fintype.card ι : ℝ) ^ (1 - alpha)
  let Anorm := (∑ i, p i ^ alpha) / Pstar
  have hPa : 0 ≤ ∑ i, p i ^ alpha := Finset.sum_nonneg (fun i _ => Real.rpow_nonneg (hp i) _)
  have hPstar : 0 < Pstar := Real.rpow_pos_of_pos hk _
  have hAnorm : 0 ≤ Anorm := div_nonneg hPa hPstar.le
  have hmargin : 0 < E + v * Anorm := by positivity
  have hbase := pilot_low_degree_count_variance_probability_units Bp cp alpha hBp hcp Ncount lam hLaw hpair Y hY
    m (by dsimp [alpha]; linarith) (completedCoupledPolynomial ℓ Nk m γ a b cProfile fL f A B ω).coeff n hn.ne' p hlam
  have hden : 0 ≤ (Pstar * (E + v * Anorm)) ^ 2 := sq_nonneg _
  apply (div_le_div_of_nonneg_right hbase hden).trans
  have heq : ((m : ℝ) * ∑ r ∈ Finset.range m,
      (completedCoupledPolynomial ℓ Nk m γ a b cProfile fL f A B ω).coeff (r + 1) ^ 2 *
        (pilotConstant Bp cp * alpha) ^ (r + 1) / n ^ (r + 1) * powerSumNat p (r + 1)) /
      (Pstar * (E + v * Anorm)) ^ 2 =
    (m : ℝ) * ∑ r ∈ Finset.range m,
      ((completedCoupledPolynomial ℓ Nk m γ a b cProfile fL f A B ω).coeff (r + 1) ^ 2 *
        (pilotConstant Bp cp * alpha) ^ (r + 1) / n ^ (r + 1) / Pstar ^ 2) *
        (powerSumNat p (r + 1) / (E + v * Anorm) ^ 2) := by
    rw [mul_div_assoc, Finset.sum_div]
    congr 1
    apply Finset.sum_congr rfl
    intro r _
    field_simp
  rw [heq]
  apply mul_le_mul_of_nonneg_left _ (Nat.cast_nonneg m)
  apply Finset.sum_le_sum
  intro r hr
  have hrm : r + 1 ≤ m := by have := Finset.mem_range.mp hr; omega
  have hrma : ((r + 1 : ℕ) : ℝ) ≤ alpha := by
    have h : ((r + 1 : ℕ) : ℝ) ≤ m := by exact_mod_cast hrm
    dsimp [alpha]
    linarith
  have hcoef := completedCoupledPolynomial_low_coefficient_exponential (f := f) (B := B) (ω := ω)
    hℓ hNk hmDegree hdegree hrm hγ hγ1 ha hb hcProfile hf hf1 hA hA1 hZ
  have hcoef2 : (completedCoupledPolynomial ℓ Nk m γ a b cProfile fL f A B ω).coeff (r + 1) ^ 2 ≤
      (coupledLowCoefficientConstant ^ (m + 1) * a ^ (alpha - ((r + 1 : ℕ) : ℝ))) ^ 2 := by
    have hc : 0 ≤ coupledLowCoefficientConstant := by unfold coupledLowCoefficientConstant; positivity
    simpa only [sq_abs] using (sq_le_sq₀ (abs_nonneg _) (by positivity)).mpr hcoef
  have hcp : 0 ≤ pilotConstant Bp cp * alpha := by
    have hpc : 0 < pilotConstant Bp cp :=
      (by linarith : 0 < 2 * Bp + 1).trans_le (le_max_left _ _)
    dsimp [alpha]
    positivity
  have hleft := div_le_div_of_nonneg_right
    (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right hcoef2 (pow_nonneg hcp (r + 1)))
      (pow_nonneg hn.le (r + 1))) (sq_nonneg Pstar)
  have hright := finite_power_sum_over_affine_margin p hp hk (by omega : 0 < r + 1) hrma hE hv
  have hPj : 0 ≤ powerSumNat p (r + 1) :=
    Finset.sum_nonneg (fun i _ => pow_nonneg (hp i) _)
  exact mul_le_mul hleft hright (by positivity) (by positivity)


/-- Complete actual low-count calibration: one fixed baseline leaves a uniform D^-1 margin ratio. -/
theorem completed_low_count_variance_calibrated (Bp cp : ℝ) (hBp : 0 < Bp) (hcp : 0 < cp)
    (Ncount : ι → Ω → ℕ) (lam : ι → ℝ≥0)
    (hLaw : ∀ i, MeasurePreserving (Ncount i) μ (poissonMeasure (lam i)))
    (hpair : Pairwise (fun i j => IndepFun (Ncount i) (Ncount j) μ))
    (Y : ι → Ξ → ℕ)
    (hY : ∀ i, MeasurePreserving (Y i) ν
      (poissonMeasure ⟨cp * lam i, mul_nonneg hcp.le (lam i).coe_nonneg⟩))
    (p : ι → ℝ) (hp : ∀ i, 0 ≤ p i) (hk : (0 : ℝ) < Fintype.card ι)
    {ℓ Nk m : ℕ} (hm : 0 < m) (hℓ : 0 < ℓ) (hNk : 0 < Nk) (hdegree : 4 * (ℓ - 1) ≤ m) (hmDegree : 1 ≤ m)
    {γ a b cProfile fL f A B ω n E v rho D X R E0 u0 c : ℝ}
    (hγ : 0 < γ) (hγ1 : γ ≤ 1) (halpha : 3 / 2 ≤ (m : ℝ) + γ)
    (ha : 0 < a) (hb : 0 < b) (hcProfile : cProfile ∈ Set.Ioo (γ / (1 + γ)) 1) (hf : 0 ≤ fL) (hf1 : fL < 1) (hA : 0 ≤ A) (hA1 : A ≤ 1)
    (hZ : (Nk : ℝ) ^ 2 * (a / b) ≤ 1) (hrho : 0 < rho) (hD : 1 ≤ D) (hX : 1 ≤ X)
    (hE0 : 0 < E0) (hu0 : 0 < u0) (hc : 0 ≤ c)
    (hR : Real.exp (3 * (Real.log (lowCountExponentialConstant rho (pilotConstant Bp cp)) + c)) ≤ R)
    (hcut : (Fintype.card ι : ℝ) * a ≤ rho / D)
    (hE : E0 * (R / D) ^ ((m : ℝ) + γ - 1) ≤ E)
    (hv : u0 * Real.exp (-c * ((m : ℝ) + γ)) * X ^ (-((m : ℝ) + γ)) ≤ v)
    (hnsize : n = D * ((m : ℝ) + γ) * (Fintype.card ι : ℝ) ^ (1 - 1 / ((m : ℝ) + γ)) * X)
    (hlam : ∀ i, (lam i : ℝ) = n * p i) :
    pilotAveragedCountVariance Ncount Y (cp * Bp * ((m : ℝ) + γ)) m
        (completedCoupledPolynomial ℓ Nk m γ a b cProfile fL f A B ω).coeff n μ ν /
      (((Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + γ))) *
        (E + v * ((∑ i, p i ^ ((m : ℝ) + γ)) /
          (Fintype.card ι : ℝ) ^ (1 - ((m : ℝ) + γ))))) ^ 2 ≤
        (max (E0 ^ (-2 : ℝ)) (E0 ^ (-1 : ℝ)) * max 1 (u0 ^ (-1 : ℝ))) / D := by
  let alpha := (m : ℝ) + γ
  let k := (Fintype.card ι : ℝ)
  let Pstar := k ^ (1 - alpha)
  let Cp := pilotConstant Bp cp
  let K := max (E0 ^ (-2 : ℝ)) (E0 ^ (-1 : ℝ)) * max 1 (u0 ^ (-1 : ℝ))
  have hCp : 0 < Cp := (by linarith : 0 < 2 * Bp + 1).trans_le (le_max_left _ _)
  have hD0 : 0 < D := zero_lt_one.trans_le hD
  have hX0 : 0 < X := zero_lt_one.trans_le hX
  have hR0 : 0 < R := (Real.exp_pos _).trans_le hR
  have halpha0 : 0 < alpha := by dsimp [alpha]; linarith
  have hn : 0 < n := by rw [hnsize]; positivity
  have hEpos : 0 < E := (by positivity : 0 < E0 * (R / D) ^ ((m : ℝ) + γ - 1)).trans_le hE
  have hvpos : 0 < v := (by positivity : 0 < u0 * Real.exp (-c * ((m : ℝ) + γ)) * X ^ (-((m : ℝ) + γ))).trans_le hv
  have hk1 : 1 ≤ k := by
    have hkNat : 0 < Fintype.card ι := by exact_mod_cast hk
    dsimp [k]
    exact_mod_cast hkNat
  have hmR : 0 < (m : ℝ) := by exact_mod_cast hm
  let T : ℕ → ℝ := fun r =>
    ((coupledLowCoefficientConstant ^ (m + 1) * a ^ (alpha - ((r + 1 : ℕ) : ℝ))) ^ 2 *
      (Cp * alpha) ^ (r + 1) / n ^ (r + 1) / Pstar ^ 2) *
      (k ^ (1 - ((r + 1 : ℕ) : ℝ)) * E ^ (((r + 1 : ℕ) : ℝ) / alpha - 2) *
        v ^ (-(((r + 1 : ℕ) : ℝ) / alpha)))
  have hbase := completed_low_count_variance_affine_margin (f := f) (B := B) (ω := ω) Bp cp hBp hcp Ncount lam hLaw hpair Y hY p hp hk
    hℓ hNk hdegree hmDegree hγ hγ1 ha hb hcProfile hf hf1 hA hA1 hZ hn hlam hEpos hvpos
  have hterm : ∀ r ∈ Finset.range m, T r ≤ (K / D) / (m : ℝ) ^ 2 := by
    intro r hr
    have hrm : r + 1 ≤ m := by have := Finset.mem_range.mp hr; omega
    have hrma : ((r + 1 : ℕ) : ℝ) ≤ alpha := by
      have h : ((r + 1 : ℕ) : ℝ) ≤ m := by exact_mod_cast hrm
      dsimp [alpha]
      linarith
    have hscalar := low_count_single_degree_calibration hm halpha (by linarith)
      (by positivity : 0 ≤ ((r + 1 : ℕ) : ℝ)) hrma hk1 ha hrho hCp hD hX hE0 hu0 hc hR hcut hE hv
    rw [← hnsize] at hscalar
    simp only [Real.rpow_natCast] at hscalar
    apply (le_div_iff₀ (sq_pos_of_pos hmR)).mpr
    convert hscalar using 1
    dsimp [T, K, Pstar, k, Cp, alpha]
    ring
  calc
    _ ≤ (m : ℝ) * ∑ r ∈ Finset.range m, T r := hbase
    _ ≤ (m : ℝ) * ∑ _r ∈ Finset.range m, (K / D) / (m : ℝ) ^ 2 :=
      mul_le_mul_of_nonneg_left (Finset.sum_le_sum hterm) hmR.le
    _ = _ := by
      simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
      dsimp [K]
      field_simp

end Renyi
