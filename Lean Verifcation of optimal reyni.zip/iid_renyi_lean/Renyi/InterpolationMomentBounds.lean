import Renyi.LowerCalibration
import Renyi.TensorSecondMoment

/-! Quantitative power moments of the actual weighted interpolation factors. -/
noncomputable section
open scoped BigOperators
namespace Renyi

/-- Exact absolute power moment of a normalized weighted interpolation factor. -/
theorem normalizedInterpolation_abs_power {n : ℕ} (u : Fin (n+1) → ℝ)
    {a rho e q : ℝ} (ha : 0 < a) (hrho : 0 ≤ rho) (hu : ∀ i, 0 < u i) :
    (∑ i, |normalizedInterpolation u a rho e i| *
      interpolationNodes u a i^(e+q)) =
      ((1+rho)*a^q + ∑ i, |lagrangeWeight u a i| *
        (1+rho*a/u i)*u i^q) / interpolationNormalizer u a rho e := by
  have hP := interpolationNormalizer_pos u (e := e) ha hrho
  have hpower {v : ℝ} (hv : 0 < v) : v^(-e)*v^(e+q) = v^q := by
    rw [← Real.rpow_add hv]
    congr 1
    ring
  have hnone : |normalizedInterpolation u a rho e none| *a^(e+q) =
      (1+rho)*a^q/interpolationNormalizer u a rho e := by
    simp only [normalizedInterpolation,weightedInterpolation,interpolationWeights,
      interpolationNodes,Option.elim_none,abs_div,abs_mul,abs_of_pos hP,
      abs_of_nonneg (by linarith : 0 ≤ 1+rho),abs_of_pos (Real.rpow_pos_of_pos ha (-e))]
    rw [div_mul_eq_mul_div, mul_assoc,hpower ha]
  have hsome (i : Fin (n+1)) : |normalizedInterpolation u a rho e (some i)| *u i^(e+q) =
      (|lagrangeWeight u a i| *(1+rho*a/u i)*u i^q)/interpolationNormalizer u a rho e := by
    have hui : 0 < u i := hu i
    have hfactor : 0 ≤ 1+rho*a/u i := by positivity
    simp only [normalizedInterpolation,weightedInterpolation,interpolationWeights,
      interpolationNodes,Option.elim_some,abs_div,abs_mul,abs_neg,abs_of_pos hP,
      abs_of_nonneg hfactor,abs_of_pos (Real.rpow_pos_of_pos (hu i) (-e))]
    rw [div_mul_eq_mul_div, mul_assoc,hpower (hu i)]
  rw [Fintype.sum_option]
  change |normalizedInterpolation u a rho e none| *a^(e+q) +
    (∑ i, |normalizedInterpolation u a rho e (some i)| *u i^(e+q)) = _
  rw [hnone]
  simp_rw [hsome]
  rw [← Finset.sum_div, ← add_div]

/-- The principal atom supplies an exact lower bound on the positive normalizer. -/
theorem interpolationNormalizer_principal_lower {n : ℕ} (u : Fin (n+1) → ℝ)
    {a rho e : ℝ} (ha : 0 < a) (hrho : 0 ≤ rho) :
    (1+rho)*a^(-e) ≤ interpolationNormalizer u a rho e := by
  have hh := Finset.single_le_sum
    (s := (Finset.univ : Finset (Option (Fin (n+1)))))
    (f := fun i => max (weightedInterpolation u a rho e i) 0)
    (fun i _ => le_max_right _ _) (Finset.mem_univ none)
  have hweight : weightedInterpolation u a rho e none = (1+rho)*a^(-e) := rfl
  have hnonneg : 0 ≤ (1+rho)*a^(-e) := by positivity
  simpa only [hweight,max_eq_left hnonneg] using hh

/-- A complementary interpolation factor has every higher absolute power
moment bounded by its exact normalizing principal power. -/
theorem unperturbed_abs_power_bound {n : ℕ} (u : Fin (n+1) → ℝ)
    {a e q S : ℝ} (ha : 0 < a) (ha1 : a ≤ 1)
    (hu : ∀ i, 0 < u i) (hu1 : ∀ i, u i ≤ 1) (hq : 0 ≤ q)
    (hS : (∑ i, |lagrangeWeight u a i|) ≤ S) :
    (∑ i, |normalizedInterpolation u a 0 e i| * interpolationNodes u a i^(e+q)) ≤
      a^e*(1+S) := by
  have hP := interpolationNormalizer_pos u (ρ := 0) (e := e) ha (by norm_num)
  have hPlow := interpolationNormalizer_principal_lower u (rho := 0) (e := e) ha (by norm_num)
  simp only [add_zero,one_mul] at hPlow
  have haQ : a^q ≤ 1 := Real.rpow_le_one ha.le ha1 hq
  have huQ (i : Fin (n+1)) : u i^q ≤ 1 := Real.rpow_le_one (hu i).le (hu1 i) hq
  have hraw : a^q+(∑ i, |lagrangeWeight u a i| * u i^q) ≤ 1+S := by
    have hh := Finset.sum_le_sum (s := Finset.univ) (fun i _ =>
      mul_le_of_le_one_right (abs_nonneg (lagrangeWeight u a i)) (huQ i))
    linarith
  have hS0 : 0 ≤ S := (Finset.sum_nonneg (fun i _ => abs_nonneg _)).trans hS
  rw [normalizedInterpolation_abs_power u (rho := 0) (e := e) (q := q) ha (by norm_num) hu]
  simp only [add_zero,zero_mul,zero_div,one_mul,mul_one]
  calc
    _ ≤ (1+S)/interpolationNormalizer u a 0 e := div_le_div_of_nonneg_right hraw hP.le
    _ ≤ (1+S)/a^(-e) := div_le_div_of_nonneg_left (by linarith) (Real.rpow_pos_of_pos ha _) hPlow
    _ = _ := by rw [Real.rpow_neg ha.le,div_inv_eq_mul]; ring

/-- Every complementary factor used in the construction has absolute moments
at all higher powers bounded by a universal multiple of its target mass. -/
theorem complementary_absolute_power_bound (n : ℕ) (xi z beta : ℝ)
    (hxi0 : 1/2 ≤ xi) (hxi1 : xi < 1) (hz0 : 0 < z) (hz1 : z ≤ 1)
    (hbeta : xi ≤ beta) :
    let b := xi/((n : ℝ)+1)^2
    let a := Real.exp (-5)*b*z^(1/xi)
    let u := chebyshevNode n b
    (∑ i, |normalizedInterpolation u a 0 xi i| * interpolationNodes u a i^beta) ≤
      (1+Real.exp 2)*z := by
  let b := xi/((n : ℝ)+1)^2
  let a := Real.exp (-5)*b*z^(1/xi)
  let u := chebyshevNode n b
  have hxi : 0 < xi := by linarith
  have hb0 : 0 < b := by dsimp [b]; positivity
  have hnp : (1 : ℝ) ≤ ((n : ℝ)+1)^2 := by
    have hn0 : (0 : ℝ) ≤ n := Nat.cast_nonneg n
    nlinarith
  have hb1 : b < 1 := by apply (div_lt_one (by positivity)).mpr; linarith
  have hzpow : z^(1/xi) ≤ 1 := Real.rpow_le_one hz0.le hz1 (by positivity)
  have ha0 : 0 < a := by dsimp [a]; positivity
  have haB : a < b := by
    have he : Real.exp (-5) < 1 := Real.exp_lt_one_iff.mpr (by norm_num)
    have hh := mul_le_mul_of_nonneg_left hzpow (show 0 ≤ Real.exp (-5)*b by positivity)
    dsimp [a]
    nlinarith [mul_lt_mul_of_pos_right he hb0]
  have ha1 : a ≤ 1 := haB.le.trans hb1.le
  have hu0 (i) : 0 < u i := hb0.trans_le (chebyshevNode_bounds n b hb1.le i).1
  have hu1 (i) : u i ≤ 1 := (chebyshevNode_bounds n b hb1.le i).2
  have hsum := chebyshev_absolute_sum_le_exp_all n xi a hxi.le hxi1.le ha0.le haB
  have hsum2 : (∑ i, |lagrangeWeight u a i|) ≤ Real.exp 2 :=
    hsum.trans (Real.exp_le_exp.mpr (by linarith))
  have hbound := unperturbed_abs_power_bound u (e := xi) (q := beta-xi) ha0 ha1 hu0 hu1
    (sub_nonneg.mpr hbeta) hsum2
  have haPower : a^xi = Real.exp (-5*xi)*b^xi*z := by
    dsimp [a]
    rw [Real.mul_rpow (by positivity : 0 ≤ Real.exp (-5)*b) (Real.rpow_pos_of_pos hz0 _).le,
      Real.mul_rpow (Real.exp_pos _).le hb0.le, ← Real.exp_mul,
      ← Real.rpow_mul hz0.le, one_div_mul_cancel hxi.ne', Real.rpow_one]
  have haPowerLe : a^xi ≤ z := by
    rw [haPower]
    have hbpow : b^xi ≤ 1 := Real.rpow_le_one hb0.le hb1.le hxi.le
    have he : Real.exp (-5*xi) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
    have hh := mul_le_mul he hbpow (Real.rpow_nonneg hb0.le _) (by norm_num : (0 : ℝ) ≤ 1)
    have hz := mul_le_mul_of_nonneg_right hh hz0.le
    simpa only [one_mul] using hz
  dsimp only
  have heq : xi+(beta-xi)=beta := by ring
  rw [heq] at hbound
  exact hbound.trans (by nlinarith [mul_le_mul_of_nonneg_right haPowerLe (show 0 ≤ 1+Real.exp 2 by positivity)])

/-- At positive active degree, every power at least one beyond the weighting
exponent has absolute mass of order `zeta*a^s`, with a uniform constant. -/
theorem active_absolute_power_bound (n : ℕ) (zeta a rho s beta : ℝ)
    (hn : 0 < n) (hz0 : 0 < zeta) (hz1 : zeta ≤ 3/5)
    (ha : 0 < a) (hrho : 0 ≤ rho)
    (haB : a ≤ ((zeta/8)/((n : ℝ)+1)^2)/2)
    (hpert : rho*a/((zeta/8)/((n : ℝ)+1)^2) ≤ zeta)
    (hbeta : s+1 ≤ beta) :
    let b := (zeta/8)/((n : ℝ)+1)^2
    let u := chebyshevNode n b
    (∑ i, |normalizedInterpolation u a rho s i| * interpolationNodes u a i^beta) ≤
      3*zeta*a^s := by
  let b := (zeta/8)/((n : ℝ)+1)^2
  let u := chebyshevNode n b
  let q := beta-s
  let P := interpolationNormalizer u a rho s
  have hq1 : 1 ≤ q := by dsimp [q]; linarith
  have hq0 : 0 ≤ q := by linarith
  have hb0 : 0 < b := by dsimp [b]; positivity
  have hn0 : (0 : ℝ) ≤ n := Nat.cast_nonneg n
  have hden : (1 : ℝ) ≤ ((n : ℝ)+1)^2 := by nlinarith
  have hbz : b ≤ zeta/8 := by
    apply (div_le_iff₀ (by positivity : (0 : ℝ) < ((n : ℝ)+1)^2)).mpr
    dsimp [b]
    nlinarith
  have hb1 : b < 1 := by linarith
  have hab : a < b := by change a ≤ b/2 at haB; linarith
  have ha1 : a ≤ 1 := hab.le.trans hb1.le
  have huB (i) : b ≤ u i := (chebyshevNode_bounds n b hb1.le i).1
  have hu0 (i) : 0 < u i := hb0.trans_le (huB i)
  have hu1 (i) : u i ≤ 1 := (chebyshevNode_bounds n b hb1.le i).2
  have hcoeff := chebyshev_nodes_small_interval n zeta a hn hz0 hz1 ha haB
  change (∑ i, |lagrangeWeight u a i|) ≤ 1+zeta/2 ∧ _ at hcoeff
  have hfirst : |lagrangeWeight u a 0| ≤ 1+zeta/2 :=
    (Finset.single_le_sum (fun i _ => abs_nonneg (lagrangeWeight u a i))
      (Finset.mem_univ (0 : Fin (n+1)))).trans hcoeff.1
  have hrest : (∑ i ∈ (Finset.univ.erase (0 : Fin (n+1))), |lagrangeWeight u a i|) ≤ zeta/2 := hcoeff.2.2.1
  have hnode0 : u 0 = b := chebyshevNode_zero n b hn
  have huQ (i) : u i^q ≤ 1 := Real.rpow_le_one (hu0 i).le (hu1 i) hq0
  have hbQ : b^q ≤ b := by
    simpa only [Real.rpow_one] using Real.rpow_le_rpow_of_exponent_ge hb0 hb1.le hq1
  have haQ : a^q ≤ b := by
    have hh := Real.rpow_le_rpow_of_exponent_ge ha ha1 hq1
    have hh' : a^q ≤ a := by simpa only [Real.rpow_one] using hh
    exact hh'.trans hab.le
  have hbare : (∑ i, |lagrangeWeight u a i| * u i^q) ≤ (1+zeta/2)*b+zeta/2 := by
    have hsplit := Finset.sum_erase_add (s := (Finset.univ : Finset (Fin (n+1))))
      (fun i => |lagrangeWeight u a i| * u i^q) (Finset.mem_univ (0 : Fin (n+1)))
    have htail : (∑ i ∈ (Finset.univ.erase (0 : Fin (n+1))), |lagrangeWeight u a i| * u i^q) ≤ zeta/2 :=
      (Finset.sum_le_sum (fun i _ => mul_le_of_le_one_right (abs_nonneg _) (huQ i))).trans hrest
    have hhead := mul_le_mul hfirst hbQ (Real.rpow_nonneg hb0.le _) (by linarith : 0 ≤ 1+zeta/2)
    dsimp only at hsplit
    rw [hnode0] at hsplit
    linarith
  have hfactor (i) : 1+rho*a/u i ≤ 1+zeta := by
    have hh := div_le_div_of_nonneg_left (mul_nonneg hrho ha.le) hb0 (huB i)
    change rho*a/b ≤ zeta at hpert
    linarith
  have hnodal : (∑ i, |lagrangeWeight u a i| *(1+rho*a/u i)*u i^q) ≤ 2*zeta := by
    have hh : (∑ i, |lagrangeWeight u a i| *(1+rho*a/u i)*u i^q) ≤
        (1+zeta)*(∑ i, |lagrangeWeight u a i| *u i^q) := by
      rw [Finset.mul_sum]
      apply Finset.sum_le_sum
      intro i _
      have h := mul_le_mul_of_nonneg_left (hfactor i)
        (mul_nonneg (abs_nonneg (lagrangeWeight u a i)) (Real.rpow_nonneg (hu0 i).le q))
      convert h using 1 <;> ring
    have hcoefb : (1+zeta/2)*b ≤ zeta/4 := by
      have hh := mul_le_mul_of_nonneg_right (show 1+zeta/2 ≤ 2 by linarith) hb0.le
      linarith
    have hbare2 : (∑ i, |lagrangeWeight u a i| * u i^q) ≤ 3*zeta/4 := by linarith
    have hh2 := mul_le_mul_of_nonneg_left hbare2 (show 0 ≤ 1+zeta by positivity)
    have hpoly : (1+zeta)*(3*zeta/4) ≤ 2*zeta := by
      have hh := mul_le_mul_of_nonneg_right (show 1+zeta ≤ 2 by linarith) (show 0 ≤ 3*zeta/4 by positivity)
      nlinarith
    exact hh.trans (hh2.trans hpoly)
  have hraw : (1+rho)*a^q+(∑ i, |lagrangeWeight u a i| *(1+rho*a/u i)*u i^q) ≤
      3*(1+rho)*zeta := by
    have hh := mul_le_mul_of_nonneg_left haQ (show 0 ≤ 1+rho by positivity)
    have hh' := mul_le_mul_of_nonneg_left hbz (show 0 ≤ 1+rho by positivity)
    nlinarith [mul_nonneg hrho hz0.le]
  have hP := interpolationNormalizer_pos u (e := s) ha hrho
  have hPlow := interpolationNormalizer_principal_lower u (e := s) ha hrho
  have heq : s+q=beta := by dsimp [q]; ring
  dsimp only
  rw [← heq, normalizedInterpolation_abs_power u ha hrho hu0]
  calc
    _ ≤ (3*(1+rho)*zeta)/P := div_le_div_of_nonneg_right hraw hP.le
    _ ≤ (3*(1+rho)*zeta)/((1+rho)*a^(-s)) :=
      div_le_div_of_nonneg_left (by positivity) (by positivity) hPlow
    _ = _ := by rw [Real.rpow_neg ha.le]; field_simp

end Renyi
