import Renyi.CoupledBoundedSupport

/-! Actual high-arm baseline on compact fractional ranges and bounded resolution. -/
noncomputable section
namespace Renyi

/-- A positive h lower bound and bounded low resolution force a fixed positive actual reserved high arm. -/
theorem coupledProfiles_compact_high_baseline {f Emin Emax R h0 M lam0 : ℝ}
    (hf : 0<f) (hf1 : f<1) (hEmin : 0<Emin) (hEEmax : Emin≤Emax)
    (hR : 1≤R) (hh0 : 0<h0) (hM : 0≤M) (hlam0 : 0<lam0) :
    ∃ η : ℝ, 0<η ∧ ∀ (ℓ N : ℕ) (γ z E x y : ℝ), 0<ℓ → 2≤N → (ℓ:ℝ)≤R →
      0<γ → γ<1 → 0<z → z<1 → Emin≤E → E≤Emax → overlapG γ z=Real.exp (-E) →
      0≤x → x≤1 → 0≤y → y≤1 → h0≤γ*(1-γ) →
      lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤((ℓ:ℝ)^2*x)*((N:ℝ)^2*y) →
      η≤(overlapB γ z*Real.exp (-(M+1)*(1-γ)))*highProfile N (1-γ) f (Real.exp (-E/8)) y := by
  let Ω := Real.exp (-Emax/8)
  let z0 := Real.exp (-Emax-2)
  let Y0 := lam0*h0*z0^(1/h0)/R^2
  let q := f/2
  let CH := coupledHighMinEnvelopeConstant f q Ω
  let v0 := min (q*Ω) (Real.exp (-CH)*min Y0 1)
  let η := coupledSaturationCoefficient Emin (M+1)*v0
  have hEmax : 0<Emax := hEmin.trans_le hEEmax
  have hRp : 0<R := zero_lt_one.trans_le hR
  have hΩ : 0<Ω := Real.exp_pos _
  have hz0 : 0<z0 := Real.exp_pos _
  have hz01 : z0≤1 := Real.exp_le_one_iff.mpr (by nlinarith only [hEmax])
  have hY0 : 0<Y0 := div_pos (mul_pos (mul_pos hlam0 hh0) (Real.rpow_pos_of_pos hz0 _)) (sq_pos_of_pos hRp)
  have hq : 0<q := by dsimp [q];positivity
  have hqf : q<f := by dsimp [q];linarith only [hf]
  have hCH : 0≤CH := by
    have hloc := coupledLocalLowerConstant_nonneg hf.le hf1
    exact hloc.trans (le_max_left _ _)
  have hv0 : 0<v0 := lt_min (mul_pos hq hΩ) (mul_pos (Real.exp_pos _) (lt_min hY0 (by norm_num)))
  have hη : 0<η := mul_pos (coupledSaturationCoefficient_pos hEmin) hv0
  refine ⟨η,hη,?_⟩
  intro ℓ N γ z E x y hℓ hN hℓR hγ hγ1 hz hz1 hEE hEEmax' hG hx hx1 hy hy1 hh hcap
  let Y := (N:ℝ)^2*y
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hd1 : 1-γ≤1 := by linarith only [hγ]
  have hhpos : 0<γ*(1-γ) := mul_pos hγ hd
  have hE : 0<E := hEmin.trans_le hEE
  have hω : 0<Real.exp (-E/8) := Real.exp_pos _
  have hω1 : Real.exp (-E/8)<1 := Real.exp_lt_one_iff.mpr (by linarith only [hE])
  have hΩω : Ω≤Real.exp (-E/8) := Real.exp_le_exp.mpr (by linarith only [hEEmax'])
  have hzEmin : z≤Real.exp (-Emin) := by
    have hh := overlapG_ge_parameter hγ hγ1 hz hz1
    rw [hG] at hh
    exact hh.trans (Real.exp_le_exp.mpr (by linarith only [hEE]))
  have hzlo : z0≤z := by
    have hcoarse := overlapG_coarse_parameter_lower hγ hγ1 hz hz1
    rw [hG,←Real.exp_add] at hcoarse
    have he : Real.exp (-Emax-2)≤Real.exp (-E+-2) := Real.exp_le_exp.mpr (by linarith only [hEEmax'])
    exact he.trans hcoarse
  have hpow : z0^(1/h0)≤z^(1/(γ*(1-γ))) := by
    have hinv := one_div_le_one_div_of_le hh0 hh
    have hmono := Real.rpow_le_rpow_of_exponent_ge hz0 hz01 hinv
    exact hmono.trans (Real.rpow_le_rpow hz0.le hzlo (one_div_pos.mpr hhpos).le)
  have hprod := mul_le_mul hh hpow (Real.rpow_nonneg hz0.le (1/h0)) hhpos.le
  have hlamprod := mul_le_mul_of_nonneg_left hprod hlam0.le
  have hZ : (ℓ:ℝ)^2*x≤R^2 := by
    exact (mul_le_of_le_one_right (sq_nonneg (ℓ:ℝ)) hx1).trans
      (pow_le_pow_left₀ (Nat.cast_nonneg ℓ) hℓR 2)
  have hZY := mul_le_mul_of_nonneg_right hZ (show 0≤Y by dsimp [Y];positivity)
  have hYlo : Y0≤Y := by
    apply (div_le_iff₀ (sq_pos_of_pos hRp)).mpr
    dsimp [Y] at hZY ⊢
    nlinarith only [hlamprod,hcap,hZY]
  have hminY : min Y0 1≤(Y/(1-γ))^(1-γ) := by
    have hp := fractional_power_min_linear hd hd1 (show 0≤Y by dsimp [Y];positivity)
      (by norm_num : (0:ℝ)≤0) (by norm_num : (0:ℝ)<1)
    norm_num only [neg_zero,zero_mul,Real.exp_zero,min_self,one_mul] at hp
    exact (min_le_min hYlo (le_refl (1:ℝ))).trans (hp.trans (min_le_right _ _))
  have he : Real.exp (-CH)≤Real.exp (-CH*(1-γ)) := Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_left hd1 hCH])
  have hV := mul_le_mul he hminY (show 0≤min Y0 1 by exact (lt_min hY0 (by norm_num)).le) (Real.exp_pos _).le
  have hfloor := highProfile_global_min_lower hN hd hd1 hf hf1 hqf hΩ hΩω hω1 hy hy1
  have hv : v0≤highProfile N (1-γ) f (Real.exp (-E/8)) y :=
    (min_le_min (mul_le_mul_of_nonneg_left hΩω hq.le) hV).trans hfloor
  have hweight := (coupled_saturation_weights hγ hγ1 hz hz1 hEmin hzEmin (show 0≤M+1 by positivity)).2
  have hc := overlap_coefficients_unit hγ hγ1 hz hz1
  exact mul_le_mul hweight hv hv0.le (mul_nonneg hc.2.2.1.le (Real.exp_pos _).le)

end Renyi
