import Renyi.Foundations
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Data.Fin.Tuple.Basic

/-!
# Exact overlap of independent Poisson likelihoods

All expectations in this module are convergent sums against the actual
Poisson probability masses. Zero alternative intensities are allowed.
-/

noncomputable section
open scoped BigOperators NNReal
open ProbabilityTheory
namespace Renyi

/-- The probability-generating identity, including absolute convergence. -/
theorem poisson_pgf_hasSum (r : ℝ≥0) (t : ℝ) :
    HasSum (fun n : ℕ => poissonPMFReal r n * t ^ n)
      (Real.exp ((r : ℝ) * (t - 1))) := by
  have h := (NormedSpace.expSeries_div_hasSum_exp ℝ ((r : ℝ) * t)).mul_left
    (Real.exp (-(r : ℝ)))
  have hterm : (fun n : ℕ => Real.exp (-(r : ℝ)) *
      (((r : ℝ) * t) ^ n / (n.factorial : ℝ))) =
      (fun n : ℕ => poissonPMFReal r n * t ^ n) := by
    funext n
    simp only [poissonPMFReal, mul_pow]
    ring
  rw [hterm] at h
  have hvalue : Real.exp (-(r : ℝ)) * NormedSpace.exp ℝ ((r : ℝ) * t) =
      Real.exp ((r : ℝ) * (t - 1)) := by
    rw [← Real.exp_eq_exp_ℝ, ← Real.exp_add]
    congr 1
    ring
  exact hvalue ▸ h

/-- The coordinate likelihood formula is defined also when the alternative is zero. -/
def poissonLikelihood (ν base alt : ℝ≥0) (n : ℕ) : ℝ :=
  Real.exp (-(ν : ℝ) * ((alt : ℝ) - base)) * ((alt : ℝ) / base) ^ n

theorem poissonLikelihood_nonneg (ν base alt : ℝ≥0) (n : ℕ) :
    0 ≤ poissonLikelihood ν base alt n := by
  unfold poissonLikelihood
  positivity

/-- Multiplying the reference mass by the likelihood gives the alternative mass. -/
theorem poissonLikelihood_density (ν base alt : ℝ≥0) (hbase : 0 < base) (n : ℕ) :
    poissonLikelihood ν base alt n * poissonPMFReal (ν * base) n =
      poissonPMFReal (ν * alt) n := by
  have hb : (base : ℝ) ≠ 0 := by exact_mod_cast ne_of_gt hbase
  have hp : ((alt : ℝ) / base) ^ n * ((ν : ℝ) * base) ^ n =
      ((ν : ℝ) * alt) ^ n := by
    rw [← mul_pow]
    congr 1
    field_simp
  have he : Real.exp (-(ν : ℝ) * ((alt : ℝ) - base)) *
      Real.exp (-((ν : ℝ) * base)) = Real.exp (-((ν : ℝ) * alt)) := by
    rw [← Real.exp_add]
    congr 1
    ring
  unfold poissonLikelihood poissonPMFReal
  push_cast
  calc
    Real.exp (-(ν : ℝ) * ((alt : ℝ) - base)) * ((alt : ℝ) / base) ^ n *
        (Real.exp (-((ν : ℝ) * base)) * ((ν : ℝ) * base) ^ n / n.factorial) =
      (Real.exp (-(ν : ℝ) * ((alt : ℝ) - base)) * Real.exp (-((ν : ℝ) * base))) *
        (((alt : ℝ) / base) ^ n * ((ν : ℝ) * base) ^ n) / n.factorial := by ring
    _ = _ := by rw [he, hp]

/-- Exact cross-likelihood expectation for one Poisson coordinate. -/
theorem poisson_overlap_hasSum (ν base alt other : ℝ≥0) (hbase : 0 < base) :
    HasSum (fun n : ℕ => poissonLikelihood ν base alt n *
      poissonLikelihood ν base other n * poissonPMFReal (ν * base) n)
      (Real.exp ((ν : ℝ) * ((alt : ℝ) - base) * ((other : ℝ) - base) / base)) := by
  have hb : (base : ℝ) ≠ 0 := by exact_mod_cast ne_of_gt hbase
  let c := Real.exp (-(ν : ℝ) * ((alt : ℝ) - base)) *
    Real.exp (-(ν : ℝ) * ((other : ℝ) - base))
  let t := ((alt : ℝ) / base) * ((other : ℝ) / base)
  have h := (poisson_pgf_hasSum (ν * base) t).mul_left c
  have hterm : (fun n : ℕ => c * (poissonPMFReal (ν * base) n * t ^ n)) =
      (fun n : ℕ => poissonLikelihood ν base alt n *
        poissonLikelihood ν base other n * poissonPMFReal (ν * base) n) := by
    funext n
    dsimp [c, t, poissonLikelihood]
    rw [mul_pow]
    ring
  rw [hterm] at h
  have hvalue : c * Real.exp (((ν * base : ℝ≥0) : ℝ) * (t - 1)) =
      Real.exp ((ν : ℝ) * ((alt : ℝ) - base) * ((other : ℝ) - base) / base) := by
    dsimp [c, t]
    rw [← Real.exp_add, ← Real.exp_add]
    congr 1
    field_simp
    ring
  exact hvalue ▸ h

/-- A finite product of nonnegative summable factors defines the corresponding
independent joint sum. This supplies the independence step explicitly. -/
theorem hasSum_mul_nonneg_real {ι κ : Type*} {f : ι → ℝ} {g : κ → ℝ} {a b : ℝ}
    (hf : HasSum f a) (hg : HasSum g b)
    (hf0 : ∀ i, 0 ≤ f i) (hg0 : ∀ i, 0 ≤ g i) :
    HasSum (fun x : ι × κ => f x.1 * g x.2) (a * b) := by
  exact hf.mul hg (Summable.mul_of_nonneg hf.summable hg.summable hf0 hg0)

theorem hasSum_fin_product_nonneg (d : ℕ) (f : Fin d → ℕ → ℝ) (a : Fin d → ℝ)
    (hf0 : ∀ i n, 0 ≤ f i n) (hf : ∀ i, HasSum (f i) (a i)) :
    HasSum (fun x : Fin d → ℕ => ∏ i, f i (x i)) (∏ i, a i) := by
  induction d with
  | zero =>
      simp
  | succ d ih =>
      have htail : HasSum (fun x : Fin d → ℕ => ∏ i, f i.succ (x i))
          (∏ i : Fin d, a i.succ) := ih (fun i => f i.succ) (fun i => a i.succ)
        (fun i n => hf0 i.succ n) (fun i => hf i.succ)
      have hsum := hasSum_mul_nonneg_real (hf 0) htail
        (fun n => hf0 0 n) (fun x => Finset.prod_nonneg (fun i _ => hf0 i.succ (x i)))
      have heq := (Fin.consEquiv (fun _ : Fin (d + 1) => ℕ)).hasSum_iff
        (f := fun x : Fin (d + 1) → ℕ => ∏ i, f i (x i))
        (a := ∏ i, a i)
      apply heq.mp
      simpa [Fin.prod_univ_succ] using hsum

def poissonProductMass {d : ℕ} (rate : Fin d → ℝ≥0) (x : Fin d → ℕ) : ℝ :=
  ∏ i, poissonPMFReal (rate i) (x i)

def poissonProductLikelihood {d : ℕ} (ν base alt : Fin d → ℝ≥0)
    (x : Fin d → ℕ) : ℝ :=
  ∏ i, poissonLikelihood (ν i) (base i) (alt i) (x i)

theorem poissonProductMass_nonneg {d : ℕ} (rate : Fin d → ℝ≥0) (x : Fin d → ℕ) :
    0 ≤ poissonProductMass rate x :=
  Finset.prod_nonneg (fun _ _ => poissonPMFReal_nonneg)

theorem poissonProductMass_hasSum {d : ℕ} (rate : Fin d → ℝ≥0) :
    HasSum (poissonProductMass rate) 1 := by
  have h := hasSum_fin_product_nonneg d
    (fun i n => poissonPMFReal (rate i) n) (fun _ => (1 : ℝ))
    (fun _ _ => poissonPMFReal_nonneg) (fun i => poissonPMFRealSum (rate i))
  simpa only [Finset.prod_const_one] using h

theorem poissonProductLikelihood_density {d : ℕ} (ν base alt : Fin d → ℝ≥0)
    (hbase : ∀ i, 0 < base i) (x : Fin d → ℕ) :
    poissonProductLikelihood ν base alt x *
      poissonProductMass (fun i => ν i * base i) x =
      poissonProductMass (fun i => ν i * alt i) x := by
  unfold poissonProductLikelihood poissonProductMass
  rw [← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro i _
  exact poissonLikelihood_density (ν i) (base i) (alt i) (hbase i) (x i)

theorem poissonProductLikelihood_hasSum {d : ℕ} (ν base alt : Fin d → ℝ≥0)
    (hbase : ∀ i, 0 < base i) :
    HasSum (fun x => poissonProductLikelihood ν base alt x *
      poissonProductMass (fun i => ν i * base i) x) 1 := by
  have heq : (fun x => poissonProductLikelihood ν base alt x *
      poissonProductMass (fun i => ν i * base i) x) =
      poissonProductMass (fun i => ν i * alt i) := by
    funext x
    exact poissonProductLikelihood_density ν base alt hbase x
  rw [heq]
  exact poissonProductMass_hasSum _

def poissonOverlapExponent {d : ℕ} (ν base alt other : Fin d → ℝ≥0) : ℝ :=
  ∑ i, (ν i : ℝ) * ((alt i : ℝ) - base i) * ((other i : ℝ) - base i) / base i

/-- The complete independent-coordinate overlap identity. -/
theorem poisson_product_overlap_hasSum {d : ℕ} (ν base alt other : Fin d → ℝ≥0)
    (hbase : ∀ i, 0 < base i) :
    HasSum (fun x => poissonProductLikelihood ν base alt x *
      poissonProductLikelihood ν base other x *
      poissonProductMass (fun i => ν i * base i) x)
      (Real.exp (poissonOverlapExponent ν base alt other)) := by
  have h := hasSum_fin_product_nonneg d
    (fun i n => poissonLikelihood (ν i) (base i) (alt i) n *
      poissonLikelihood (ν i) (base i) (other i) n * poissonPMFReal (ν i * base i) n)
    (fun i => Real.exp ((ν i : ℝ) * ((alt i : ℝ) - base i) *
      ((other i : ℝ) - base i) / base i))
    (fun i n => mul_nonneg
      (mul_nonneg (poissonLikelihood_nonneg _ _ _ _) (poissonLikelihood_nonneg _ _ _ _))
      poissonPMFReal_nonneg)
    (fun i => poisson_overlap_hasSum (ν i) (base i) (alt i) (other i) (hbase i))
  simpa only [Finset.prod_mul_distrib, ← Real.exp_sum,
    poissonOverlapExponent, poissonProductLikelihood, poissonProductMass] using h

def poissonMixtureLikelihood {d m : ℕ} (ν base : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (x : Fin d → ℕ) : ℝ :=
  (∑ s, poissonProductLikelihood ν base (alt s) x) / (m : ℝ)

def poissonMixtureMass {d m : ℕ} (ν : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (x : Fin d → ℕ) : ℝ :=
  (∑ s, poissonProductMass (fun i => ν i * alt s i) x) / (m : ℝ)

/-- The proposed likelihood is genuinely the density of the mixture law. -/
theorem poissonMixtureLikelihood_density {d m : ℕ} (ν base : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (hbase : ∀ i, 0 < base i) (x : Fin d → ℕ) :
    poissonMixtureLikelihood ν base alt x * poissonProductMass (fun i => ν i * base i) x =
      poissonMixtureMass ν alt x := by
  unfold poissonMixtureLikelihood poissonMixtureMass
  rw [div_mul_eq_mul_div, Finset.sum_mul]
  congr 1
  apply Finset.sum_congr rfl
  intro s _
  exact poissonProductLikelihood_density ν base (alt s) hbase x

/-- The mixture likelihood has expectation one under the reference law. -/
theorem poissonMixtureLikelihood_hasSum {d m : ℕ} (ν base : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (hbase : ∀ i, 0 < base i) (hm : 0 < m) :
    HasSum (fun x => poissonMixtureLikelihood ν base alt x *
      poissonProductMass (fun i => ν i * base i) x) 1 := by
  have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast ne_of_gt hm
  have h := (hasSum_sum (s := (Finset.univ : Finset (Fin m)))
    (fun s _ => poissonProductLikelihood_hasSum ν base (alt s) hbase)).div_const (m : ℝ)
  have hvalue : (∑ _ : Fin m, (1 : ℝ)) / (m : ℝ) = 1 := by simp [hmR]
  rw [hvalue] at h
  apply h.congr_fun
  intro x
  simp only [poissonMixtureLikelihood, ← Finset.sum_mul]
  ring

theorem poissonMixtureMass_hasSum {d m : ℕ} (ν : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (hm : 0 < m) :
    HasSum (poissonMixtureMass ν alt) 1 := by
  have h := (hasSum_sum (s := (Finset.univ : Finset (Fin m)))
    (fun s _ => poissonProductMass_hasSum (fun i => ν i * alt s i))).div_const (m : ℝ)
  have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast ne_of_gt hm
  simpa [poissonMixtureMass, hmR] using h

theorem poissonMixtureMass_nonneg {d m : ℕ} (ν : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (x : Fin d → ℕ) :
    0 ≤ poissonMixtureMass ν alt x := by
  unfold poissonMixtureMass
  exact div_nonneg (Finset.sum_nonneg (fun _ _ => poissonProductMass_nonneg _ _))
    (Nat.cast_nonneg _)

/-- A probability mass function for the actual independent-coordinate law. -/
def poissonJointPMF {d : ℕ} (rate : Fin d → ℝ≥0) : PMF (Fin d → ℕ) := by
  refine ⟨fun x => ENNReal.ofReal (poissonProductMass rate x), ?_⟩
  apply ENNReal.hasSum_coe.mpr
  rw [← Real.toNNReal_one]
  exact (poissonProductMass_hasSum rate).toNNReal (poissonProductMass_nonneg rate)

/-- A probability mass function for the uniform mixture of alternatives. -/
def poissonMixturePMF {d m : ℕ} (ν : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (hm : 0 < m) : PMF (Fin d → ℕ) := by
  refine ⟨fun x => ENNReal.ofReal (poissonMixtureMass ν alt x), ?_⟩
  apply ENNReal.hasSum_coe.mpr
  rw [← Real.toNNReal_one]
  exact (poissonMixtureMass_hasSum ν alt hm).toNNReal (poissonMixtureMass_nonneg ν alt)

/-- The exact second moment of the uniform mixture likelihood. -/
theorem poissonMixtureLikelihood_second_hasSum {d m : ℕ} (ν base : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (hbase : ∀ i, 0 < base i) :
    HasSum (fun x => poissonMixtureLikelihood ν base alt x ^ 2 *
      poissonProductMass (fun i => ν i * base i) x)
      ((∑ s, ∑ t, Real.exp (poissonOverlapExponent ν base (alt s) (alt t))) /
        (m : ℝ) ^ 2) := by
  have h := (hasSum_sum (s := (Finset.univ : Finset (Fin m)))
    (fun s _ => hasSum_sum (s := (Finset.univ : Finset (Fin m)))
      (fun t _ => poisson_product_overlap_hasSum ν base (alt s) (alt t) hbase))).div_const
        ((m : ℝ) ^ 2)
  apply h.congr_fun
  intro x
  simp only [poissonMixtureLikelihood, div_pow, ← Finset.sum_mul, ← Finset.mul_sum]
  ring

/-- Chi-square divergence as its defining expectation of `(L-1)^2`. -/
def poissonMixtureChiSq {d m : ℕ} (ν base : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) : ℝ :=
  ∑' x, (poissonMixtureLikelihood ν base alt x - 1) ^ 2 *
    poissonProductMass (fun i => ν i * base i) x

theorem poissonMixtureChiSq_hasSum {d m : ℕ} (ν base : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (hbase : ∀ i, 0 < base i) (hm : 0 < m) :
    HasSum (fun x => (poissonMixtureLikelihood ν base alt x - 1) ^ 2 *
      poissonProductMass (fun i => ν i * base i) x)
      ((∑ s, ∑ t, Real.exp (poissonOverlapExponent ν base (alt s) (alt t))) /
        (m : ℝ) ^ 2 - 1) := by
  have hsecond := poissonMixtureLikelihood_second_hasSum ν base alt hbase
  have hfirst := poissonMixtureLikelihood_hasSum ν base alt hbase hm
  have hbaseSum := poissonProductMass_hasSum (fun i => ν i * base i)
  have h := (hsecond.sub (hfirst.mul_left 2)).add hbaseSum
  convert h using 1
  · funext x
    ring
  · ring

theorem poissonMixtureChiSq_identity {d m : ℕ} (ν base : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (hbase : ∀ i, 0 < base i) (hm : 0 < m) :
    poissonMixtureChiSq ν base alt =
      (∑ s, ∑ t, Real.exp (poissonOverlapExponent ν base (alt s) (alt t))) /
        (m : ℝ) ^ 2 - 1 :=
  (poissonMixtureChiSq_hasSum ν base alt hbase hm).tsum_eq

/-- Disjoint perturbations have overlap exactly one. -/
theorem poisson_overlap_disjoint {d : ℕ} (ν base alt other : Fin d → ℝ≥0)
    (hdisj : ∀ i, alt i = base i ∨ other i = base i) :
    poissonOverlapExponent ν base alt other = 0 := by
  unfold poissonOverlapExponent
  apply Finset.sum_eq_zero
  intro i _
  rcases hdisj i with h | h <;> simp [h]

/-- The finite diagonal/off-diagonal calculation behind the mixture bound. -/
theorem finite_mixture_overlap_bound {m : ℕ} (hm : 0 < m)
    (A : Fin m → Fin m → ℝ) (J : ℝ)
    (hdiag : ∀ s, A s s ≤ Real.exp J)
    (hoff : ∀ s t, s ≠ t → A s t = 1) :
    (∑ s, ∑ t, A s t) / (m : ℝ) ^ 2 - 1 ≤ (Real.exp J - 1) / (m : ℝ) := by
  have hmpos : 0 < (m : ℝ) := by exact_mod_cast hm
  have hrow (s : Fin m) : ∑ t, A s t ≤ (m : ℝ) + Real.exp J - 1 := by
    calc
      ∑ t, A s t ≤ ∑ t, (1 + if s = t then Real.exp J - 1 else 0) := by
        apply Finset.sum_le_sum
        intro t _
        by_cases hst : s = t
        · subst t
          simpa using hdiag s
        · simp [hst, hoff s t hst]
      _ = (m : ℝ) + Real.exp J - 1 := by
        simp [Finset.sum_add_distrib]
        ring
  have hsum : (∑ s, ∑ t, A s t) ≤ (m : ℝ) * ((m : ℝ) + Real.exp J - 1) := by
    simpa only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] using
      Finset.sum_le_sum (s := Finset.univ) (fun s _ => hrow s)
  apply (sub_le_iff_le_add).2
  apply (div_le_iff₀ (sq_pos_of_pos hmpos)).2
  have hrewrite : ((Real.exp J - 1) / (m : ℝ) + 1) * (m : ℝ) ^ 2 =
      (m : ℝ) * ((m : ℝ) + Real.exp J - 1) := by
    field_simp
    ring
  rw [hrewrite]
  exact hsum

/-- Exponential-overlap mixture bound for actual independent Poisson laws.
The disjointness hypothesis says that every coordinate is perturbed by at
most one of the two alternatives, exactly as in the manuscript.
-/
theorem poisson_disjoint_mixture_chisq_bound {d m : ℕ} (ν base : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (hbase : ∀ i, 0 < base i) (hm : 0 < m)
    (J : ℝ)
    (henergy : ∀ s, (∑ i, (ν i : ℝ) * ((alt s i : ℝ) - base i) ^ 2 / base i) ≤ J)
    (hdisj : ∀ s t, s ≠ t → ∀ i, alt s i = base i ∨ alt t i = base i) :
    poissonMixtureChiSq ν base alt ≤ (Real.exp J - 1) / (m : ℝ) := by
  rw [poissonMixtureChiSq_identity ν base alt hbase hm]
  apply finite_mixture_overlap_bound hm
  · intro s
    apply Real.exp_le_exp.mpr
    have heq : poissonOverlapExponent ν base (alt s) (alt s) =
        ∑ i, (ν i : ℝ) * ((alt s i : ℝ) - base i) ^ 2 / base i := by
      unfold poissonOverlapExponent
      apply Finset.sum_congr rfl
      intro i _
      ring
    rw [heq]
    exact henergy s
  · intro s t hst
    rw [poisson_overlap_disjoint ν base (alt s) (alt t) (hdisj s t hst), Real.exp_zero]

/-- The discrete total-variation/chi-square inequality, proved directly from
the nonnegativity of a quadratic expectation. -/
theorem discrete_tv_le_sqrt_chisq {ι : Type*} (p q L : ι → ℝ)
    (hp0 : ∀ x, 0 ≤ p x) (hq0 : ∀ x, 0 ≤ q x)
    (hp : HasSum p 1) (hq : Summable q)
    (hdensity : ∀ x, L x * p x = q x)
    (hchi : Summable (fun x => (L x - 1) ^ 2 * p x)) :
    (∑' x, |q x - p x|) / 2 ≤
      Real.sqrt (∑' x, (L x - 1) ^ 2 * p x) / 2 := by
  have habssum : Summable (fun x => |q x - p x|) :=
    Summable.of_nonneg_of_le (fun x => abs_nonneg _)
      (fun x => by
        calc
          |q x - p x| ≤ |q x| + |p x| := abs_sub _ _
          _ = q x + p x := by rw [abs_of_nonneg (hq0 x), abs_of_nonneg (hp0 x)])
      (hq.add hp.summable)
  let a := ∑' x, |q x - p x|
  let c := ∑' x, (L x - 1) ^ 2 * p x
  have habseq (x : ι) : |L x - 1| * p x = |q x - p x| := by
    calc
      |L x - 1| * p x = |(L x - 1) * p x| := by rw [abs_mul, abs_of_nonneg (hp0 x)]
      _ = |q x - p x| := by rw [sub_mul, one_mul, hdensity x]
  have habs : HasSum (fun x => |L x - 1| * p x) a := by
    have heq : (fun x => |L x - 1| * p x) = (fun x => |q x - p x|) := funext habseq
    rw [heq]
    exact habssum.hasSum
  have h := (hchi.hasSum.sub (habs.mul_left (2 * a))).add (hp.mul_left (a ^ 2))
  have hquad : HasSum (fun x => (|L x - 1| - a) ^ 2 * p x) (c - a ^ 2) := by
    convert h using 1
    · funext x
      rw [sub_sq, sq_abs]
      ring
    · dsimp [c]
      ring
  have hnonneg : 0 ≤ c - a ^ 2 := by
    rw [← hquad.tsum_eq]
    exact tsum_nonneg (fun x => mul_nonneg (sq_nonneg _) (hp0 x))
  have hroot : a ≤ Real.sqrt c := Real.le_sqrt_of_sq_le (by linarith)
  exact div_le_div_of_nonneg_right hroot (by norm_num)

def poissonMixtureTV {d m : ℕ} (ν base : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) : ℝ :=
  (∑' x, |poissonMixtureMass ν alt x - poissonProductMass (fun i => ν i * base i) x|) / 2

theorem poissonMixtureTV_le_sqrt_chisq {d m : ℕ} (ν base : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (hbase : ∀ i, 0 < base i) (hm : 0 < m) :
    poissonMixtureTV ν base alt ≤ Real.sqrt (poissonMixtureChiSq ν base alt) / 2 := by
  exact discrete_tv_le_sqrt_chisq
    (poissonProductMass (fun i => ν i * base i)) (poissonMixtureMass ν alt)
    (poissonMixtureLikelihood ν base alt)
    (poissonProductMass_nonneg _) (poissonMixtureMass_nonneg ν alt)
    (poissonProductMass_hasSum _) (poissonMixtureMass_hasSum ν alt hm).summable
    (poissonMixtureLikelihood_density ν base alt hbase)
    (poissonMixtureChiSq_hasSum ν base alt hbase hm).summable

theorem poisson_disjoint_mixture_tv_bound {d m : ℕ} (ν base : Fin d → ℝ≥0)
    (alt : Fin m → Fin d → ℝ≥0) (hbase : ∀ i, 0 < base i) (hm : 0 < m)
    (J : ℝ)
    (henergy : ∀ s, (∑ i, (ν i : ℝ) * ((alt s i : ℝ) - base i) ^ 2 / base i) ≤ J)
    (hdisj : ∀ s t, s ≠ t → ∀ i, alt s i = base i ∨ alt t i = base i) :
    poissonMixtureTV ν base alt ≤ Real.sqrt ((Real.exp J - 1) / (m : ℝ)) / 2 := by
  exact (poissonMixtureTV_le_sqrt_chisq ν base alt hbase hm).trans
    (div_le_div_of_nonneg_right (Real.sqrt_le_sqrt
      (poisson_disjoint_mixture_chisq_bound ν base alt hbase hm J henergy hdisj))
      (by norm_num))

end Renyi
