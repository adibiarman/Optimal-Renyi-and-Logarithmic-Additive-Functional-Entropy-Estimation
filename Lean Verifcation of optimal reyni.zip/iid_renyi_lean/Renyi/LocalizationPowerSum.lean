import Renyi.CompletedLocalization
import Renyi.HighOrderNorm
import Renyi.UpperBaseline

/-! Exact finite-alphabet summation of quadratic spatial localization. -/
noncomputable section
open scoped BigOperators
namespace Renyi
set_option maxHeartbeats 800000

lemma quadratic_truncation_le_rpow {x nu : ℝ} (hx : 0≤x) (hn : 0≤nu) (hn2 : nu≤2) :
    min 1 (x^2)≤x^nu := by
  by_cases hx1 : x≤1
  · exact (min_le_right _ _).trans (by
      rw [←Real.rpow_two]
      exact Real.rpow_le_rpow_of_exponent_ge' hx hx1 hn hn2)
  · exact (min_le_left _ _).trans (Real.one_le_rpow (le_of_not_ge hx1) hn)

lemma weighted_localization_le {p t alpha nu : ℝ} (hp : 0<p) (ht : 0≤t)
    (hn : 0≤nu) (hn2 : nu≤2) :
    p^alpha*min 1 ((t/p)^2)≤t^nu*p^(alpha-nu) := by
  have hh := mul_le_mul_of_nonneg_left
    (quadratic_truncation_le_rpow (div_nonneg ht hp.le) hn hn2) (Real.rpow_nonneg hp.le alpha)
  apply hh.trans_eq
  rw [Real.div_rpow ht hp.le,Real.rpow_sub hp]
  ring

lemma localization_small_coordinate {p t K alpha nu : ℝ}
    (hp : 0≤p) (ht : 0≤t) (hK : 0<K) (ha : 0<alpha)
    (hn : 0≤nu) (hn2 : nu≤2) (hna : nu≤alpha) (hpK : p≤1/K) :
    p^alpha*min 1 ((t/p)^2)≤t^nu*(1/K)^(alpha-nu) := by
  rcases hp.eq_or_lt with rfl | hp
  · simp only [Real.zero_rpow ha.ne',zero_mul]
    positivity
  exact (weighted_localization_le hp ht hn hn2).trans
    (mul_le_mul_of_nonneg_left (Real.rpow_le_rpow hp.le hpK (sub_nonneg.mpr hna)) (Real.rpow_nonneg ht nu))

lemma localization_large_coordinate {p t K alpha nu : ℝ}
    (ht : 0≤t) (hK : 0<K) (hn : 0≤nu) (hn2 : nu≤2) (hpK : 1/K≤p) :
    p^alpha*min 1 ((t/p)^2)≤(K*t)^nu*p^alpha := by
  have hp : 0<p := (one_div_pos.mpr hK).trans_le hpK
  have hdiv : t/p≤K*t := by
    apply (div_le_iff₀ hp).mpr
    have hh := (div_le_iff₀ hK).mp hpK
    nlinarith only [mul_le_mul_of_nonneg_right hh ht]
  have hpow := (quadratic_truncation_le_rpow (div_nonneg ht hp.le) hn hn2).trans
    (Real.rpow_le_rpow (div_nonneg ht hp.le) hdiv hn)
  convert mul_le_mul_of_nonneg_left hpow (Real.rpow_nonneg hp.le alpha) using 1
  ring

lemma localization_baseline_identity {K t alpha nu : ℝ} (hK : 0<K) (ht : 0≤t) :
    K*(t^nu*(1/K)^(alpha-nu))=(K*t)^nu*K^(1-alpha) := by
  rw [Real.mul_rpow hK.le ht,one_div,Real.inv_rpow hK.le,Real.rpow_sub hK,
    Real.rpow_sub hK,Real.rpow_one]
  simp only [div_eq_mul_inv,mul_inv_rev,inv_inv]
  ring

/-- Splitting at the uniform mass 1/k proves the exact min(alpha,2) rate,
with no dependence on the number of occupied bins. -/
theorem localization_power_sum {k : ℕ} (hk : 0<k) (p : Simplex k)
    {alpha nu t : ℝ} (ha : 1≤alpha) (ht : 0≤t)
    (hn : 0≤nu) (hn2 : nu≤2) (hna : nu≤alpha) :
    (∑i,p.mass i^alpha*min 1 ((t/p.mass i)^2))≤
      2*((k:ℝ)*t)^nu*powerSum p alpha := by
  have hK : (0:ℝ)<k := by exact_mod_cast hk
  have hterm (i:Fin k) : p.mass i^alpha*min 1 ((t/p.mass i)^2)≤
      ((k:ℝ)*t)^nu*p.mass i^alpha+t^nu*(1/(k:ℝ))^(alpha-nu) := by
    by_cases hpK : p.mass i≤1/(k:ℝ)
    · have hh := localization_small_coordinate (p.nonneg i) ht hK
        (by linarith only [ha]) hn hn2 hna hpK
      have h0 : 0≤((k:ℝ)*t)^nu*p.mass i^alpha :=
        mul_nonneg (Real.rpow_nonneg (mul_nonneg hK.le ht) _) (Real.rpow_nonneg (p.nonneg i) _)
      linarith only [hh,h0]
    · have hh := localization_large_coordinate (alpha:=alpha) ht hK hn hn2 (le_of_not_ge hpK)
      have h0 : 0≤t^nu*(1/(k:ℝ))^(alpha-nu) := by positivity
      linarith only [hh,h0]
  have hsum := Finset.sum_le_sum (fun i (_:i∈Finset.univ) => hterm i)
  rw [Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at hsum
  rw [localization_baseline_identity hK ht] at hsum
  have hbase := mul_le_mul_of_nonneg_left (simplex_powerSum_uniform_lower hk p ha)
    (Real.rpow_nonneg (mul_nonneg hK.le ht) nu)
  change (∑i,p.mass i^alpha*min 1 ((t/p.mass i)^2))≤
    ((k:ℝ)*t)^nu*powerSum p alpha+((k:ℝ)*t)^nu*(k:ℝ)^(1-alpha) at hsum
  nlinarith only [hsum,hbase]

end Renyi
