import Renyi.UpperPilotPolynomialSum

/-! Exact ideal-comparison identity and probability calibration for pilot boundary errors. -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory ProbabilityTheory
namespace Renyi
set_option maxHeartbeats 500000

def pilotIdealCoordinate (p Q G n b alpha B omega : ℝ) (light : Prop) [Decidable light] : ℝ :=
  if n*p<B*alpha/2 then Q else
    if p≤b then (if light then Q else G) else (if light then omega*p^alpha else G)

/-- Exact coordinate comparison: the only noncentered random-pilot errors are
false-light polynomial replacement and false-heavy polynomial/Gamma replacement. -/
theorem pilot_coordinate_comparison {p Q Qhat G n b alpha B omega : ℝ}
    (hp : 0≤p) (hw : 0≤omega) (light : Prop) [Decidable light] :
    |(if light then Qhat else G)-pilotIdealCoordinate p Q G n b alpha B omega light-
      (if light then Qhat-Q else 0)|≤
      (if b<p then (if light then |Q|+omega*p^alpha else 0) else 0)+
      (if n*p<B*alpha/2 then (if light then 0 else |Q|+|G|) else 0) := by
  have hpow : 0≤omega*p^alpha := mul_nonneg hw (Real.rpow_nonneg hp _)
  have hleft : 0≤|Q|+omega*p^alpha := add_nonneg (abs_nonneg Q) hpow
  have hright : 0≤|Q|+|G| := add_nonneg (abs_nonneg Q) (abs_nonneg G)
  unfold pilotIdealCoordinate
  by_cases hl : light
  · simp only [if_pos hl]
    by_cases hs : n*p<B*alpha/2
    · simp only [if_pos hs,add_zero]
      have hid : Qhat-Q-(Qhat-Q)=0 := by ring
      rw [hid,abs_zero]
      split_ifs <;> first | exact hleft | exact le_rfl
    · simp only [if_neg hs,add_zero]
      by_cases hb : p≤b
      · simp only [if_pos hb,if_neg (not_lt.mpr hb),sub_self,abs_zero,le_refl]
      · simp only [if_neg hb,if_pos (lt_of_not_ge hb)]
        have hid : Qhat-omega*p^alpha-(Qhat-Q)=Q-omega*p^alpha := by ring
        rw [hid]
        simpa only [abs_of_nonneg hpow] using abs_sub Q (omega*p^alpha)
  · simp only [if_neg hl,sub_zero]
    by_cases hs : n*p<B*alpha/2
    · simp only [if_pos hs]
      have hh : |G-Q|≤|Q|+|G| := by simpa only [add_comm] using abs_sub G Q
      split_ifs <;> simpa only [zero_add] using hh
    · simp only [if_neg hs]
      split_ifs <;> simp only [sub_self,abs_zero,add_zero,le_refl]

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}

/-- Markov transfer at the actual deterministic reserve; it applies to the
single nonnegative boundary envelope, independently of alphabet size. -/
theorem pilot_boundary_markov [IsFiniteMeasure μ] {F : Ω→ℝ} (hF : Integrable F μ)
    (hF0 : ∀w,0≤F w) {eta delta M : ℝ} (hd : 0<delta) (hM : 0<M)
    (hmean : (∫w,F w ∂μ)≤eta*M) :
    μ.real {w | delta*M<F w}≤eta/delta := by
  have hh := (mul_meas_ge_le_integral_of_nonneg (Filter.Eventually.of_forall hF0) hF (delta*M)).trans hmean
  have hge : μ.real {w | delta*M≤F w}≤eta/delta := by
    apply (le_div_iff₀ hd).mpr
    apply (mul_le_mul_iff_right₀ hM).mp
    nlinarith only [hh]
  have hsub : {w | delta*M<F w}⊆{w | delta*M≤F w} := by
    intro w h
    exact (show delta*M<F w from h).le
  exact (measureReal_mono hsub).trans hge

/-- One fixed pilot exponent absorbs every accuracy-dependent logarithmic loss
in the false-classification terms, uniformly over every alpha≥1. -/
theorem pilot_exponential_margin_budget {eps eta alpha L cstar cp : ℝ}
    (he : 0≤eps) (heta : 0<eta) (heta6 : eta≤6) (ha : 1≤alpha) (hL : alpha≤L)
    (hc : 2*eps+Real.log (6/eta)≤cstar) (hcp : cstar≤cp) :
    2*Real.exp (-cstar*L)+3*Real.exp (-cp*alpha)+Real.exp (-cstar*alpha)≤
      eta*Real.exp (-2*eps*(alpha-1)) := by
  have hratio : 1≤6/eta := (le_div_iff₀ heta).mpr (by linarith only [heta6])
  have hlog : 0≤Real.log (6/eta) := Real.log_nonneg hratio
  have hc0 : 0≤cstar := by linarith only [hc,he,hlog]
  have hlogmul := mul_le_mul_of_nonneg_left ha hlog
  have hcmul := mul_le_mul_of_nonneg_right hc (by linarith only [ha] : 0≤alpha)
  have hexp : -cstar*alpha≤Real.log (eta/6)+(-2*eps*(alpha-1)) := by
    have hlogeq : Real.log (eta/6)= -Real.log (6/eta) := by
      rw [show eta/6=(6/eta)⁻¹ by field_simp,Real.log_inv]
    rw [hlogeq]
    nlinarith only [hcmul,hlogmul,he]
  have hmain := Real.exp_le_exp.mpr hexp
  rw [Real.exp_add,Real.exp_log (by positivity : 0<eta/6)] at hmain
  have hlong : Real.exp (-cstar*L)≤Real.exp (-cstar*alpha) :=
    Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_left hL hc0])
  have hpilot : Real.exp (-cp*alpha)≤Real.exp (-cstar*alpha) :=
    Real.exp_le_exp.mpr (by nlinarith only [mul_le_mul_of_nonneg_right hcp (by linarith only [ha] : 0≤alpha)])
  nlinarith only [hmain,hlong,hpilot]

/-- The proved L1 polynomial and signed Gamma budgets fit a single reserve. -/
theorem pilot_boundary_reserve_budget {K A0 base Bonus M eta eps alpha L cstar cp : ℝ}
    (hBonus : 0≤Bonus) (he : 0≤eps) (heta : 0<eta) (heta6 : eta≤6)
    (ha : 1≤alpha) (hL : alpha≤L) (hc : 2*eps+Real.log (6/eta)≤cstar) (hcp : cstar≤cp)
    (hbase : K*A0≤eta*base)
    (hM : base+Real.exp (-2*eps*(alpha-1))*Bonus≤M) :
    K*A0+(2*Real.exp (-cstar*L)+3*Real.exp (-cp*alpha)+Real.exp (-cstar*alpha))*Bonus≤eta*M := by
  have hh := mul_le_mul_of_nonneg_right (pilot_exponential_margin_budget he heta heta6 ha hL hc hcp) hBonus
  have hm := mul_le_mul_of_nonneg_left hM heta.le
  nlinarith only [hh,hm,hbase]

end Renyi
