import Renyi.CoupledCompactLower

/-! The complete actual lower certificate on bounded energy and resolution ranges. -/
noncomputable section
namespace Renyi

/-- Bounded-energy clipping, cutoff cancellation, and the reserved arm give the actual full lower certificate. -/
theorem coupledProfiles_bounded_energy_lower {fL f qL qH Emin Emax R M lam0 : ℝ}
    (hfL : 0<fL) (hfL1 : fL<1) (hf : 0<f) (hf1 : f<1)
    (hEmin : 0<Emin) (hEEmax : Emin≤Emax) (hR : 1≤R) (hM : 1≤M)
    (hlam0 : 0<lam0) (hlam1 : lam0≤1)
    (hqL : Real.exp (-Emin)<qL) (hqLf : qL<fL)
    (hqH : Real.exp (-7*Emin/8)<qH) (hqHf : qH<f) :
    ∃ C c : ℝ, 0≤C ∧ 0<c ∧ ∀ (ℓ N : ℕ) (γ z E x y : ℝ), 2≤ℓ → 2≤N → (ℓ:ℝ)≤R →
      0<γ → γ<1 → 0<z → z<1 → Emin≤E → E≤Emax → overlapG γ z=Real.exp (-E) →
      0≤x → x≤1 → 0<y → y≤1 →
      lam0*(γ*(1-γ))*z^(1/(γ*(1-γ)))≤((ℓ:ℝ)^2*x)*((N:ℝ)^2*y) →
      ((ℓ:ℝ)^2*x)*((N:ℝ)^2*y)≤
        Real.exp (-2*coupledProfileConstant)*(γ*(1-γ))*z^(1/(γ*(1-γ))) →
      Real.exp (-E)*Real.exp (-C*(γ*(1-γ)))+c*Real.exp (-E)*min ((N:ℝ)^2*y) 1≤
        coupledDampedExpression ℓ N γ z M (Real.exp (-E/8)) fL f x y := by
  let Ω := Real.exp (-Emax/8)
  let D := max 1 (coupledOuterFloorScale f qH)
  have hD : 1≤D := le_max_left _ _
  have hDp : 0<D := zero_lt_one.trans_le hD
  have hΩ : 0<Ω := Real.exp_pos _
  have hM0 : 0≤M := by linarith only [hM]
  obtain ⟨K,hK,hbase⟩ := coupledProfiles_bounded_energy_base_lower (D:=D)
    hfL hfL1 hf hf1 hEmin hEEmax hR hD hM0 hlam0 hlam1 hqL hqLf hqH hqHf
  let L := Real.exp (Real.log 12+1)*Real.exp (K/4)
  have hL : 0<L := mul_pos (Real.exp_pos _) (Real.exp_pos _)
  let h0 := min (1/4) (1/(2*L))
  have hh0 : 0<h0 := lt_min (by norm_num) (by positivity)
  obtain ⟨η,hη,hcompact⟩ := coupledProfiles_compact_high_baseline hf hf1 hEmin hEEmax hR hh0 hM0 hlam0
  let C := max (K+2*L) (1/(h0*η))
  let c := min (coupledBandReserveConstant f Ω D Emin M) (coupledOuterGain qH Emin)
  have hC : 0≤C := (add_nonneg hK (by positivity : 0≤2*L)).trans (le_max_left _ _)
  have hc1 := coupledBandReserveConstant_pos (M:=M) hf hf1 hΩ hDp hEmin
  have hc2 := coupledOuterGain_pos hqH
  have hc : 0<c := lt_min hc1 hc2
  refine ⟨C,c,hC,hc,?_⟩
  intro ℓ N γ z E x y hℓ hN hℓR hγ hγ1 hz hz1 hEE hEEmax' hG hx hx1 hy hy1 hcaplo hcaphi
  have hd : 0<1-γ := sub_pos.mpr hγ1
  have hh : 0≤γ*(1-γ) := mul_nonneg hγ.le hd.le
  have hh1 : γ*(1-γ)≤1/4 := by nlinarith only [sq_nonneg (γ-1/2)]
  have hE : 0<E := hEmin.trans_le hEE
  have hκ : 0<Real.exp (-E) := Real.exp_pos _
  have hκ1 : Real.exp (-E)≤1 := Real.exp_le_one_iff.mpr (by linarith only [hE])
  have hω : 0≤Real.exp (-E/8) := (Real.exp_pos _).le
  have hω1 : Real.exp (-E/8)<1 := Real.exp_lt_one_iff.mpr (by linarith only [hE])
  have hΩω : Ω≤Real.exp (-E/8) := Real.exp_le_exp.mpr (by linarith only [hEEmax'])
  have hzE : z≤Real.exp (-E) := by have hh := overlapG_ge_parameter hγ hγ1 hz hz1;rwa [hG] at hh
  have hzEmin : z≤Real.exp (-Emin) := hzE.trans (Real.exp_le_exp.mpr (by linarith only [hEE]))
  have hY0 : 0≤(N:ℝ)^2*y := by positivity
  have hminY0 : 0≤min ((N:ℝ)^2*y) 1 := le_min hY0 (by norm_num)
  by_cases houter : coupledOuterFloorScale f qH*(1-γ)≤(N:ℝ)^2*y
  · have hfloor := coupledProfiles_outer_lower_certificate (by omega : 0<ℓ) hN hγ hγ1 hz hz1
      hEmin hEE hM0 hC hfL.le hfL1 hf.le hf1 hqH hqHf hx hx1 hy.le hy1 houter
    have hgain := mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right (min_le_right (coupledBandReserveConstant f Ω D Emin M) (coupledOuterGain qH Emin)) hκ.le) hminY0
    nlinarith only [hfloor,hgain]
  have hYband : (N:ℝ)^2*y≤D*(1-γ) := by
    have hm := mul_le_mul_of_nonneg_right (le_max_right (1:ℝ) (coupledOuterFloorScale f qH)) hd.le
    exact (lt_of_not_ge houter).le.trans hm
  have hS := hbase ℓ N γ z E x y hℓ hN hℓR hγ hγ1 hz hz1 hEE hEEmax' hG hx hx1 hy.le hy1 hYband hcaplo
  have hcut := coupledProfiles_reserved_cutoff_linear (f:=f) (by omega : 0<ℓ) (by omega : 0<N)
    hγ hγ1 hz hz1 hE.le hzE hM hfL.le hfL1 hx hx1 hy hy1 hcaphi
  have hreserve := coupledProfiles_band_reserve_lower hN hγ hγ1 hz hz1 hEmin hzEmin hM0
    hf hf1 hΩ hΩω hω1 hDp hy.le hy1 hYband
  rw [hG] at hreserve
  have hmain : Real.exp (-E)*Real.exp (-C*(γ*(1-γ)))≤
      coupledDampedExpression ℓ N γ z M (Real.exp (-E/8)) fL f x y-
        coupledHighReserve N γ z M f (Real.exp (-E/8)) y := by
    by_cases hsmall : γ*(1-γ)≤h0
    · have hscale : 2*L*(γ*(1-γ))≤1 := by
        have hh' := hsmall.trans (min_le_right _ _)
        have hm := (le_div_iff₀ (show 0<2*L by positivity)).mp hh'
        nlinarith only [hm]
      have hbase' := small_affine_exponential_lower hκ.le hK (Real.exp_pos (Real.log 12+1)).le hh hh1 hscale hS hcut
      have he : Real.exp (-C*(γ*(1-γ)))≤Real.exp (-(K+2*L)*(γ*(1-γ))) := Real.exp_le_exp.mpr (by
        have hm := mul_le_mul_of_nonneg_right (le_max_left (K+2*L) (1/(h0*η))) hh
        nlinarith only [hm])
      exact (mul_le_mul_of_nonneg_left he hκ.le).trans hbase'
    · have hhigh := hcompact ℓ N γ z E x y (by omega : 0<ℓ) hN hℓR hγ hγ1 hz hz1 hEE hEEmax' hG
        hx hx1 hy.le hy1 (lt_of_not_ge hsmall).le hcaplo
      have hretained := coupledProfiles_reserved_high_lower (by omega : 0<ℓ) (by omega : 0<N)
        hγ hγ1 hz hz1 hM0 hω hω1 hfL.le hfL1 hf.le hf1.le hx hx1 hy.le hy1
      have hscale : 1/η≤C*(γ*(1-γ)) := by
        have hcoef : 1/(h0*η)≤C := le_max_right _ _
        have hm := (div_le_iff₀ (mul_pos hh0 hη)).mp hcoef
        have hs := mul_le_mul_of_nonneg_left (lt_of_not_ge hsmall).le hC
        apply (div_le_iff₀ hη).mpr
        nlinarith only [hm,hs,mul_nonneg hη.le (show 0≤C*(γ*(1-γ))-C*h0 by linarith only [hs])]
      have he := exp_neg_le_of_large hη hscale
      rw [show -(C*(γ*(1-γ)))=-C*(γ*(1-γ)) by ring] at he
      have hmul := (mul_le_of_le_one_left (Real.exp_pos (-C*(γ*(1-γ)))).le hκ1).trans he
      exact hmul.trans (hhigh.trans hretained)
  have hgain := mul_le_mul
    (mul_le_mul_of_nonneg_right (min_le_left (coupledBandReserveConstant f Ω D Emin M) (coupledOuterGain qH Emin)) hκ.le)
    (min_le_left ((N:ℝ)^2*y) 1) hminY0 (mul_nonneg hc1.le hκ.le)
  nlinarith only [hmain,hgain,hreserve]

end Renyi
