import Renyi
import Lean.Util.CollectAxioms
import Lean.AddDecl

/-! Inspect every theorem whose defining module is part of this project,
including private helpers and generated theorem declarations. The capstone
is independently required to have the exact full iid theorem type. -/

example : Renyi.FullManuscriptClaim := Renyi.iid_renyi_full_verified

open Lean Elab Command

run_cmd do
  let env ← getEnv
  let allowed : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let mut checked := 0
  let mut auditState : CollectAxioms.State := {}
  for (name, _) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let moduleName := env.header.moduleNames[idx]!
      if (`Renyi).isPrefixOf moduleName then
        if Lean.wasOriginallyTheorem env name then
          let (_, nextState) := ((CollectAxioms.collect name).run env).run auditState
          auditState := nextState
          checked := checked + 1
  for ax in auditState.axioms do
    unless allowed.contains ax do
      throwError "Unapproved axiom in project theorem dependencies: {ax}"
  if checked == 0 then
    throwError "No project theorems were found"
  logInfo m!"PASS: {checked} project theorem declarations, including private helpers; only standard axioms."
  logInfo "PASS: FullManuscriptClaim has the checked proof Renyi.iid_renyi_full_verified."
